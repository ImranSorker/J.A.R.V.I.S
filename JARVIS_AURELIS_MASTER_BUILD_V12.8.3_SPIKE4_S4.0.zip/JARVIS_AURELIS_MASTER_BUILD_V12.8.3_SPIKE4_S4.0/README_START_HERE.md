# JARVIS + AURELIS Master Worktree — V12.8.3 / Spike 4 S4.0

**Purpose:** one consolidated worktree containing the latest supplied JARVIS+AURELIS V12.8.3 source, the implemented Spike 1/2/3 modules and Gate 2 patch as isolated engineering overlays, the native Agent Forge manifest bridge prototype, curated donor source, audit/reference documents, and Spike 4 S4.0 decision record.

## Important truth about the build

This is the **complete packaged worktree of the supplied work**, not a claim that every overlay has been merged into the production runtime or that the upstream source is release-certified. The source bundle itself labels TURN 8-R incomplete and final seal unverified. Spike 4 S4.0 is a read-only inventory/design stage; S4.1 implementation was not started. Agent Forge's separate runtime source is not present in the supplied current source package; only its fail-closed bridge prototype is integrated into the source tree, and that bridge is not wired to the production composition root.

## Structure

- Existing JARVIS+AURELIS source at project root, including all source files from V12.8.3 TURN8R release (source SHA-256 `e1ead2719fafe064e4eb0bb2cb9943530d9b9746b5df0a7ce360c69c2946130b`).
- `super_agent/integrations/agent_forge_bridge/` — native declarative-manifest bridge prototype. It registers disabled drafts only; no agent execution.
- `schemas/agent_forge/`, `docs/agent_forge_integration/`, `tests/agent_forge_bridge/` — schema, integration contract and tests.
- `engineering/implemented_spikes_and_gates/` — Spike 1 execution fabric and sandbox acceptance materials; Spike 2 durable agents; Spike 3 memory/skills/model POC; Gate 2 idempotency patch and evidence; closure plans. Each stays isolated from production imports.
- `engineering/external_donor_extracts/` — curated donor code from DeepSeek Harness, Prime Agent, Hermes Agent, REA and Moli.
- `docs/integration_audit/` — crosswalk, inventories and next-step plan.
- `docs/spike4_native_super_agent_mission_orchestration/` — S4.0 mapping and decision; no S4.1 implementation.
- `docs/source_identity/` — supplied source/evidence identity and incomplete terminal report.

## Safety / feature activation

- Gate 1: **OPEN**. Do not enable untrusted-code execution based on the POC alone; real disposable-VM sandbox acceptance is required.
- Gate 2: **OPEN / NOT ENABLED**. Do not enable broad side-effect retries or claim universal exactly-once effects. Provider, storage-owner and receiver-side provenance/dedup checks remain outstanding.
- Spike 2: ambiguous external effects must remain in review/indeterminate state rather than being retried blindly.
- Spike 3: deterministic adapter POC only; live provider, quota, residency and production memory acceptance remain outstanding.
- Agent Forge bridge: disabled-draft registration only; it does not generate or launch super-agents.

## Verification run for this package

See `BUILD_VERIFICATION_REPORT.md`. Compilation and bridge tests are package-level checks only. They do not establish full application startup, GUI integration, live provider behavior, Gate 1/Gate 2 closure or production certification.

## Next engineering sequence

1. Run the complete baseline regression suite and record its existing failures.
2. Close Gate 1 and Gate 2 with required external/VM evidence.
3. Trace and consolidate mission authority/state ownership before S4.1.
4. Obtain the exact Agent Forge runtime source and pin its commit/license, then map its factory/generation flow to JARVIS Garage/Factory/Workshop/Genome.
5. Apply integrations incrementally with full regression-delta reports.

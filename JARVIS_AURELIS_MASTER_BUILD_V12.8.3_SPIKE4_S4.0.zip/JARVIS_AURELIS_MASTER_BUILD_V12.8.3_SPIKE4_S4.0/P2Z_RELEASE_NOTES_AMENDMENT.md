# P2-Z Release Notes Amendment

## Deferred gateway transport coupling

The P2-Z release retains a known medium-high architecture finding, `P2Z_GATEWAY_TRANSPORT_COUPLING`, in `core/cognitive_command_center/gateway.py`.

The gateway currently hosts the FastAPI/Starlette HTTP transport and WebSocket lifecycle in the same module as Command Center gateway logic. This is intentionally **deferred to a separate approved extraction workstream** described in `TURN8_GATEWAY_BOUNDARY_PLAN.md`.

No gateway transport refactor is included in the Turn 9 fix sequence. The architecture boundary test is tracked as `xfail(strict=True)` so the current known violation remains visible and an unexpected pass cannot be ignored after the extraction lands.

# J.A.R.V.I.S. V12.8.3 Cognitive Command Center

Client-only Flutter application. It calls the Python gateway exclusively. Direct phase API calls are intentionally absent.

The source declares Flutter 3.24.x / Dart 3.5.x compatible constraints, but this campaign environment does not contain the Flutter or Dart executables. Therefore no APK/web/desktop bundle was built and no bundle hash or signature is claimed.

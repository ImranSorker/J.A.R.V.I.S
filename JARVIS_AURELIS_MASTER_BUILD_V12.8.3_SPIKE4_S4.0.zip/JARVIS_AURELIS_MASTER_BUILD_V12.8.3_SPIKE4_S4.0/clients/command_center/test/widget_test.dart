import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_command_center/main.dart';
import 'package:jarvis_command_center/gateway_client/gateway_client.dart';

void main() {
  testWidgets('home exposes the 18 frozen surfaces', (tester) async {
    await tester.pumpWidget(const CommandCenterApp());
    expect(find.text('J.A.R.V.I.S. Cognitive Command Center'), findsOneWidget);
    expect(find.text('HOME'), findsOneWidget);
    expect(find.text('SETTINGS'), findsOneWidget);
  });
  test('view-model verifier refuses unsigned or incomplete views', () {
    expect(GatewayClient.verifyViewModel({'surface':'HOME','tenant_id':'t'}), isFalse);
  });
}

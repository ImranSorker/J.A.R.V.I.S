import '../surface_screen.dart';
import '../../gateway_client/gateway_client.dart';

class SurfaceScreenEntry extends SurfaceScreen {
  const SurfaceScreenEntry({super.key, required super.gateway, required super.sessionId, required super.surface});
}

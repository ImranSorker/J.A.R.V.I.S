import 'package:flutter/material.dart';
import '../gateway_client/gateway_client.dart';
import '../models/view_models.dart';

class SurfaceScreen extends StatefulWidget {
  const SurfaceScreen({super.key, required this.surface, required this.gateway, required this.sessionId});
  final String surface;
  final GatewayClient gateway;
  final String sessionId;
  @override State<SurfaceScreen> createState() => _SurfaceScreenState();
}

class _SurfaceScreenState extends State<SurfaceScreen> {
  ViewModelEnvelope? view;
  String? error;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await widget.gateway.view(widget.sessionId, widget.surface, <String, dynamic>{});
      if (!mounted) return;
      final valid = widget.gateway.gatewayPublicKeyHex == null ||
          await GatewayClient.verifyViewModelSignature(result, publicKeyHex: widget.gateway.gatewayPublicKeyHex!);
      if (!valid) throw StateError('gateway view signature verification failed');
      setState(() { view = ViewModelEnvelope(result); loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.surface.replaceAll('_', ' ');
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(children: [
          if (loading) const LinearProgressIndicator(),
          if (error != null) ListTile(title: const Text('Gateway error'), subtitle: Text(error!)),
          if (view != null) ...[
            ListTile(title: Text(title), subtitle: Text(view!.stale ? 'STALE VIEW — re-fetch required.' : 'Gateway view verified.')),
            if (view!.redactions.isNotEmpty) const ListTile(title: Text('Redactions applied'), subtitle: Text('Sensitive values were withheld by the gateway.')),
            ListTile(title: const Text('Available actions'), subtitle: Text('${view!.availableActions.length} action(s) authorized for this surface.')),
            if (view!.data is Map) ...((view!.data as Map<String, dynamic>).entries.map((e) => ListTile(title: Text('${e.key}'), subtitle: Text('${e.value}')))),
          ],
        ]),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'dart:convert';
import 'gateway_client/gateway_client.dart';
import 'gateway_client/gateway_transport.dart';
import 'surfaces/surface_screen.dart';
import 'models/command_center_models.dart';

void main() => runApp(const CommandCenterApp());

class CommandCenterApp extends StatelessWidget {
  const CommandCenterApp({super.key});
  @override
  Widget build(BuildContext context) {
    const gatewayUri = String.fromEnvironment('JARVIS_GATEWAY_URI', defaultValue: 'https://gateway.invalid');
    const gatewayPublicKey = String.fromEnvironment('JARVIS_GATEWAY_PUBLIC_KEY_HEX');
    const sessionId = String.fromEnvironment('JARVIS_SESSION_ID');
    // Bundle/session provisioning remains deployment-owned. Never embed private keys or fabricate a signed bundle.
    assert(() { if (clientBundleManifestJson.isNotEmpty && clientBundleB64.isEmpty) { debugPrint('JARVIS_CLIENT_BUNDLE_B64 missing for configured manifest'); } return true; }());
    const gatewayCert = String.fromEnvironment('JARVIS_GATEWAY_CERT_SHA256');
    const clientBundleManifestJson = String.fromEnvironment('JARVIS_CLIENT_BUNDLE_MANIFEST_JSON');
    const clientBundleB64 = String.fromEnvironment('JARVIS_CLIENT_BUNDLE_B64');
    final transport = gatewayCert.isEmpty ? null : GatewayTransport(
      baseUri: Uri.parse(gatewayUri),
      gatewayCertSha256: gatewayCert,
    );
    final gateway = GatewayClient(
      baseUri: Uri.parse(gatewayUri),
      gatewayPublicKeyHex: gatewayPublicKey.isEmpty ? null : gatewayPublicKey,
      transport: transport,
    );
    return MaterialApp(
      title: 'J.A.R.V.I.S. Cognitive Command Center',
      home: HomeShell(gateway: gateway, sessionId: sessionId),
    );
  }
}

class HomeShell extends StatelessWidget {
  const HomeShell({super.key, required this.gateway, required this.sessionId});
  final GatewayClient gateway;
  final String sessionId;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('J.A.R.V.I.S. Cognitive Command Center')),
    body: sessionId.isEmpty
        ? const Center(child: Text('No operator session configured. Authenticate through the gateway before entering the Command Center.'))
        : ListView.builder(
            itemCount: surfaces.length,
            itemBuilder: (context, index) {
              final surface = surfaces[index];
              return ListTile(
                title: Text(surface.replaceAll('_', ' ')),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => SurfaceScreen(surface: surface, gateway: gateway, sessionId: sessionId),
                )),
              );
            },
          ),
  );
}

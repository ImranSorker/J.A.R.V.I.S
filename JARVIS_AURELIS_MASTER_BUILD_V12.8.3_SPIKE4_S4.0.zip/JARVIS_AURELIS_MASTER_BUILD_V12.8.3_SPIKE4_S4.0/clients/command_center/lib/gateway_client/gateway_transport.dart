import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart' as crypto;

class GatewayTransport {
  GatewayTransport({
    required this.baseUri,
    required this.gatewayCertSha256,
    this.clientChain,
    this.clientPrivateKey,
  });

  final Uri baseUri;
  final String gatewayCertSha256;
  final Uint8List? clientChain;
  final Uint8List? clientPrivateKey;

  SecurityContext _securityContext() {
    final context = SecurityContext(withTrustedRoots: true);
    if (clientChain != null && clientPrivateKey != null) {
      context.useCertificateChainBytes(clientChain!);
      context.usePrivateKeyBytes(clientPrivateKey!);
    }
    return context;
  }

  Future<Map<String, dynamic>> request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    String? sessionId,
  }) async {
    final client = HttpClient(context: _securityContext())
      ..badCertificateCallback = (X509Certificate cert, String host, int port) {
        final digest = crypto.sha256.convert(cert.der).toString();
        return digest.toLowerCase() == gatewayCertSha256.toLowerCase();
      };
    try {
      final request = await client.openUrl(method, baseUri.resolve(path));
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      if (sessionId != null) {
        request.headers.set('X-JARVIS-Session', sessionId);
      }
      if (body != null) {
        request.write(jsonEncode(body));
      }
      final response = await request.close();
      final text = await response.transform(utf8.decoder).join();
      final decoded = text.isEmpty ? <String, dynamic>{} : jsonDecode(text);
      if (decoded is! Map<String, dynamic>) {
        throw StateError('gateway returned a non-object response (${response.statusCode})');
      }
      if (response.statusCode >= 400) {
        throw HttpException('gateway HTTP ${response.statusCode}: ${decoded['detail'] ?? text}');
      }
      return decoded;
    } finally {
      client.close(force: true);
    }
  }

  Future<Map<String, dynamic>> get(String path, {String? sessionId}) =>
      request('GET', path, sessionId: sessionId);
}

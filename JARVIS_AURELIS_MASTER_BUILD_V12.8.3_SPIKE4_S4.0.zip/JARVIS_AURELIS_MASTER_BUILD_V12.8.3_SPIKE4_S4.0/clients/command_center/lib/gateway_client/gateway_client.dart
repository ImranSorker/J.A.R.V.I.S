import 'dart:convert';
import 'package:cryptography/cryptography.dart';
import 'package:crypto/crypto.dart' as crypto;
import 'gateway_transport.dart';

class GatewayClient {
  GatewayClient({required this.baseUri, this.gatewayPublicKeyHex, GatewayTransport? transport})
      : transport = transport;

  final Uri baseUri;
  final String? gatewayPublicKeyHex;
  final GatewayTransport? transport;

  Future<Map<String, dynamic>> health() => _send('GET', '/health');
  Future<Map<String, dynamic>> ready() => _send('GET', '/ready');

  Future<Map<String, dynamic>> openSession(
    Map<String, dynamic> credentials, {
    required String tenantId,
    required Map<String, dynamic> clientBundle,
    String userAgent = '',
    String deviceFingerprint = '',
  }) => _send('POST', '/v1/session', body: {
    'auth_credentials': credentials,
    'tenant_id': tenantId,
    'client_bundle': clientBundle,
    'user_agent': userAgent,
    'device_fingerprint': deviceFingerprint,
  });

  Future<Map<String, dynamic>> view(String sessionId, String surface, Map<String, dynamic> spec) =>
      _send('POST', '/v1/view', sessionId: sessionId, body: {
        'session_id': sessionId,
        'surface': surface,
        'view_spec': spec,
      });

  Future<Map<String, dynamic>> act(String sessionId, Map<String, dynamic> action) =>
      _send('POST', '/v1/action', sessionId: sessionId, body: {'session_id': sessionId, 'action': action});

  Future<Map<String, dynamic>> confirm(String sessionId, String actionId, String confirmationRef) =>
      _send('POST', '/v1/action/confirm', sessionId: sessionId, body: {
        'session_id': sessionId,
        'action_id': actionId,
        'confirmation_ref': confirmationRef,
      });

  Future<Map<String, dynamic>> stream(String sessionId, String kind, Map<String, dynamic> filter) =>
      _send('POST', '/v1/stream', sessionId: sessionId, body: {
        'session_id': sessionId,
        'stream_kind': kind,
        'filter': filter,
      });

  Future<Map<String, dynamic>> pollStream(String sessionId, String streamId, {int limit = 20}) =>
      _send('GET', '/v1/stream/$sessionId/$streamId?limit=$limit', sessionId: sessionId);

  Future<Map<String, dynamic>> query(String sessionId, Map<String, dynamic> query) =>
      _send('POST', '/v1/query', sessionId: sessionId, body: {'session_id': sessionId, 'query_spec': query});

  Future<Map<String, dynamic>> export(String sessionId, String targetRef, String format) =>
      _send('POST', '/v1/export', sessionId: sessionId, body: {
        'session_id': sessionId,
        'target_ref': targetRef,
        'format': format,
      });

  Future<Map<String, dynamic>> _send(
    String method,
    String path, {
    String? sessionId,
    Map<String, dynamic>? body,
  }) async {
    final t = transport;
    if (t == null) {
      throw StateError('GatewayTransport must be supplied by the signed production client configuration');
    }
    return t.request(method, path, body: body, sessionId: sessionId);
  }

  static String _canonical(Object? value) {
    if (value is Map) {
      final entries = value.entries.map((e) => MapEntry(e.key.toString(), e.value)).toList()
        ..sort((a, b) => a.key.compareTo(b.key));
      return '{${entries.map((e) => '${jsonEncode(e.key)}:${_canonical(e.value)}').join(',')}}';
    }
    if (value is List) return '[${value.map(_canonical).join(',')}]';
    return jsonEncode(value);
  }

  static Future<bool> verifyViewModelSignature(
    Map<String, dynamic> model, {
    required String publicKeyHex,
  }) async {
    final signatureB64 = model['signature'];
    final integrityHash = model['integrity_hash'];
    if (signatureB64 is! String || integrityHash is! String) return false;
    final unsigned = Map<String, dynamic>.from(model)
      ..remove('signature')
      ..remove('integrity_hash');
    final canonical = utf8.encode(_canonical(unsigned));
    final digest = crypto.sha256.convert(canonical).toString();
    if (digest != integrityHash) return false;
    final keyBytes = <int>[];
    for (var i = 0; i < publicKeyHex.length; i += 2) {
      keyBytes.add(int.parse(publicKeyHex.substring(i, i + 2), radix: 16));
    }
    final pub = SimplePublicKey(keyBytes, type: KeyPairType.ed25519);
    final sig = base64Decode(signatureB64);
    return Ed25519().verify(canonical, signature: Signature(sig, publicKey: pub));
  }
}

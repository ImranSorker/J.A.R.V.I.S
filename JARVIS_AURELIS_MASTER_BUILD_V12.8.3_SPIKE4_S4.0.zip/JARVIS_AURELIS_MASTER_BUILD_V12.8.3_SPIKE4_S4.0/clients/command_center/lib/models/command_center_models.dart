const surfaces = <String>[
  'HOME','COGNITIVE_ASSISTANT','WORLD_MODEL','TASKS','AGENTS','AGENT_WORKSHOP','AGENT_GARAGE','SKILLS','MEMORY_RAG','MODELS','SIMULATION','EVOLUTION_LAB','SECURITY_SOC','SYSTEMS','ROBOTICS','TELEMETRY','DIAGNOSTICS','SETTINGS',
];

const actionKinds = <String>['read','stream','query','request','authorize','confirm','cancel','escalate','export','configure'];
const streamKinds = <String>['event_stream','telemetry_stream','log_stream','health_stream','security_stream','recovery_stream','evolution_stream'];

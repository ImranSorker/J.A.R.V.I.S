class ViewModelEnvelope {
  ViewModelEnvelope(this.raw);

  final Map<String, dynamic> raw;

  bool get stale => raw['stale'] == true;
  List<dynamic> get redactions => (raw['redactions_applied'] as List<dynamic>?) ?? const [];
  List<dynamic> get availableActions => (raw['available_actions'] as List<dynamic>?) ?? const [];
  dynamic get data => raw['data'];
}

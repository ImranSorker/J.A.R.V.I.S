import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:jarvis_command_center/main.dart';
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('command center renders with a gateway-only client', (tester) async {
    await tester.pumpWidget(const CommandCenterApp());
    expect(find.text('J.A.R.V.I.S. Cognitive Command Center'), findsOneWidget);
  });
}

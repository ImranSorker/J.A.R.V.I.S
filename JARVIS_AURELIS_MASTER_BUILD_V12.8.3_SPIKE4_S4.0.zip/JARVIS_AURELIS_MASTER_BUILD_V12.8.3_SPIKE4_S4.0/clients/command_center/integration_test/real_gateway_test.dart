import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:jarvis_command_center/gateway_client/gateway_client.dart';
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  test('real gateway contract test requires deployment-supplied endpoint and signed bundle', () async {
    final client = GatewayClient(baseUri: Uri.parse('https://gateway.invalid'));
    final result = await client.health();
    expect(result, containsPair('operation', 'health'));
  });
}

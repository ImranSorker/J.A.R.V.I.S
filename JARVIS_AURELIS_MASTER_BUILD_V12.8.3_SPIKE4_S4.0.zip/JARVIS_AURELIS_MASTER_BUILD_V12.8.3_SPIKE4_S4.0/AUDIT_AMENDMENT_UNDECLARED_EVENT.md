# J.A.R.V.I.S. V12.8.3 — Audit Amendment: UNDECLARED_EVENT

## Resolution

The original P2-Z `UNDECLARED_EVENT` category is **RECLASSIFIED — SCANNER DEFECT / OUT OF SCOPE**, with zero taxonomy additions required. The authoritative event taxonomy registry is `core/schemas/event_taxonomy.json["events"]`, as confirmed by `core/event_fabric.py` (`EventTaxonomy._ensure`: `cls._events = dict(data["events"])`). The original audit evidence repeatedly described the lookup as a failure to find a literal event as a **top-level declaration** in `event_taxonomy.json`; that is the wrong JSON level. The supplied P2-Z source ZIP does not contain the original audit scanner implementation, so the exact scanner line cannot be quoted and this amendment relies on the emitted finding evidence plus direct re-verification against the authoritative runtime path.

## Breakdown

| Bucket | Count | Classification | Resolution |
|---|---:|---|---|
| CommandCenter.* production event finding instances | 27 | False positive — declared correctly | All 25 unique literal production `CommandCenter.*` event names are present under `events`; the 27 findings are duplicate finding instances from the wrong-path scan. |
| Test-only event finding instances | 22 | Out of scope | Test event names are not production EventTaxonomy declarations and are not backfilled. |
| Scanner artifacts from scanning `event_taxonomy.json` itself | 135 | False positive — scanner defect | The scanner treated taxonomy-file strings as event emissions. |
| Non-P2-U / legacy event finding instances | 22 | Out of scope — do not use EventTaxonomy | These emissions use other event buses/journals/sentinels and do not route through `EventTaxonomy.get()`. |
| **Total** | **206** | **RECLASSIFIED** | **No taxonomy additions.** |

## Scanner defect

The original scanner is not present in the supplied source tree or in the preserved audit deliverables. The finding evidence itself contains the tell: literals were reported as missing when they were not found as a **top-level declaration** in `core/schemas/event_taxonomy.json`. P2-U does not treat the top level as the event registry; it loads the nested `events` mapping. No source fix should be made for a scanner-path error.

## Corrected verification

Direct enumeration against `event_taxonomy.json["events"]` found 25 unique production literal `CommandCenter.*` emissions and all 25 are declared. There are three additional `CommandCenter.*` taxonomy declarations that were not observed as literal production emissions in this scan; those are existing declarations, not defects.

### Non-P2-U event finding instances (22)

These are retained here so the original findings are not silently discarded. Duplicates are shown where the scanner found two emission sites for the same event.

| Event literal / construction | Source | Mechanism | Classification |
|---|---|---|---|
| `context.assembled` | `core/context_manager.py:115` | `self.event_bus.publish(...)` | out-of-scope non-P2-U |
| `mission.cancel_requested` | `core/desktop_command_gateway.py:457` | `kernel.publish(...)` | out-of-scope non-P2-U |
| `execution.requested` | `core/execution_broker.py:243` | `_kernel.publish(...)` | out-of-scope non-P2-U |
| `execution.completed` | `core/execution_broker.py:362` | `_kernel.publish(...)` | out-of-scope non-P2-U |
| `doctor.probe` | `core/jarvis_doctor.py:76` | legacy `EventFabric.publish(...)` compatibility journal | out-of-scope non-P2-U |
| `certification.runtime` | `core/kernel_12_8_0/certification.py:176` | `kernel.publish(...)` | out-of-scope non-P2-U |
| `security.decision` | `core/kernel_12_8_0/runtime.py:109` | kernel runtime publish | out-of-scope non-P2-U |
| `command.started` | `core/kernel_12_8_0/runtime.py:131` | kernel runtime publish | out-of-scope non-P2-U |
| `command.failed` | `core/kernel_12_8_0/runtime.py:134` | kernel runtime publish | out-of-scope non-P2-U |
| `command.completed` | `core/kernel_12_8_0/runtime.py:136` | kernel runtime publish | out-of-scope non-P2-U |
| `evidence.recorded` | `core/kernel_12_8_0/runtime.py:139` | kernel runtime publish | out-of-scope non-P2-U |
| `runtime.started` | `core/kernel_12_8_0/runtime.py:197` | kernel runtime publish | out-of-scope non-P2-U |
| `runtime.stopping` | `core/kernel_12_8_0/runtime.py:201` | kernel runtime publish | out-of-scope non-P2-U |
| `Evolution.<event_name>` (publish) | `core/learning_pipeline.py:439` | dynamic concatenation + EventFabric publish | concatenation_constructed / needs separate design decision |
| `Evolution.<event_name>` (emit) | `core/learning_pipeline.py:441` | dynamic concatenation + EventFabric emit | concatenation_constructed / needs separate design decision |
| `health` | `core/runtime_lifecycle.py:183` | sentinel emit | out-of-scope non-P2-U |
| `world.model.changed` | `core/world_model_3.py:502` | `sink.publish(...)` | out-of-scope non-P2-U |
| `world.model.changed` | `core/world_model_3.py:505` | `sink.publish(...)` | out-of-scope non-P2-U |
| `system.ready` | `main.py:1608` | `kernel.publish(...)` | out-of-scope non-P2-U |
| `chat.requested` | `main.py:2462` | `kernel.publish(...)` | out-of-scope non-P2-U |
| `mission.planned` | `services/mission_service.py:146` | `kernel.publish(...)` | out-of-scope non-P2-U |
| `mission.authorized` | `services/mission_service.py:152` | `kernel.publish(...)` | out-of-scope non-P2-U |

**Note:** the 22 non-P2-U findings are 22 emission/finding instances, with 21 distinct literal/construction labels because `world.model.changed` appears at two source sites and `Evolution.<event_name>` appears at two dynamic-construction sites. They remain out of scope for the P2-U taxonomy artifact.

## What was not changed

- `core/schemas/event_taxonomy.json` was not modified.
- No emitter call site was modified.
- No regression test was added for the invalid “all `.emit()`/`.publish()` literals must be in EventTaxonomy” rule, because the repository intentionally has multiple event mechanisms.
- The original `UNDECLARED_EVENT` findings remain traceable through this amendment and are explicitly reclassified rather than deleted.

## Closing statement

**Zero events need to be added. Zero emitters need to be touched. The required correction is the audit record, not the J.A.R.V.I.S. event taxonomy.**

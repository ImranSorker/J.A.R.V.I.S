# J.A.R.V.I.S. V12.8.3 — P2-Y Baseline Reopened

**Phase:** P2-Y — Autonomous Recovery  
**Kernel:** 12.8.0  
**Status:** BASELINE REOPENED — P2-W EXACT ARCHIVE VERIFIED  
**Reopened:** 2026-10-05T01:29:35.161508Z

## Gate result

The previous P2-Y blocker is cleared. The exact P2-W archive was recovered from the Library root and freshly verified from materialized bytes.

- Filename: `JARVIS_V12.8.3_P2W_AGENT_ECONOMICS.zip`
- Size: **4,735,395 bytes**
- SHA-256: `0f422fdec2a4c5b28dc13f94638b6df4b2ab3919e4321ff147e3a9904cff5d49`
- `unzip -t`: **PASS**
- ZIP entries: **1,191**
- Build signature status: **UNSIGNED_BUILD_OUTPUT** (no external signing key supplied)

## P2-W interfaces now frozen for P2-Y

### Recovery priority
P2-W freezes `recovery` as a first-class `priority_class`. The accepted priority classes also include `safety_critical`, `security_critical`, `verification`, `attestation`, `diagnosis`, `evolution_candidate`, `production`, `interactive`, `background`, and `opportunistic`.

### Allocation request
`ResourceRequest` is signed and integrity-hashed. `AgentEconomics.submit_request(request, *, context)` validates the signed request, schema, budget, quota, danger authority, and tenant context. The request carries tenant identity, requester identity, resource demand, priority class/rationale, budget ceilings, risk class, optional danger surface reference, environment hash, registry state reference, and policy version.

### Allocation decision
`AgentEconomics.decide(request_id, *, context)` produces the signed `AllocationDecision`, whose frozen shape includes request reference, outcome, grants, queue position, pre-emption reference, priority class, scheduling policy identity/version, fairness/accounting references, substitutions, constraints, risk ceiling, registry state, policy version, chain hash, signature and integrity hash.

### Accounting
`AccountingRecord` is the durable signed accounting shape. `AgentEconomics.record_consumption(...)` records measured resources with tenant, subject, parent references, budget state, attribution, period, registry reference and chain linkage. P2-E harness accounting is accepted explicitly through `record_harness_accounting(...)`.

### Pre-emption
P2-W exposes `pre_empt(...)` and `resume_preempted(...)`. Pre-emption is policy-bound by allowed flag, pre-emptor/target priority classes, minimum progress, maximum pre-emption frequency, and optional verified checkpoint requirement. Checkpoints are registered explicitly through `register_checkpoint(...)`. P2-Y must therefore treat pre-emption as a coordination/allocation decision, not a direct execution primitive.

## Exact P2-W artifacts inspected

All requested recovery-relevant files were present in the recovered archive: `core/agent_economics.py`, the requested P2-W resource/allocation/accounting/policy/quota/cost/currency/fairness/reconciliation/queue/substitution/escalation schemas, `tests/test_p2_agent_economics.py`, plus P2-W's `economics_escalation_record_v1.schema.json`.

## Baseline status

**P2-Y may now proceed to its implementation turn against real P2-W interfaces.** No P2-Y design or implementation was performed during the unblock turn.

The P2-Y phase remains at V12.8.3 / kernel 12.8.0; no prior-phase artifact was modified and no signature claim was made for unsigned release outputs.

# J.A.R.V.I.S. 12.8.3

J.A.R.V.I.S. V12.8.3 is a modular autonomous cognitive platform with durable
memory, provenance-aware RAG, bounded autonomy, capability governance,
cryptographic authorization, secure execution, verification, learning,
observability, distributed runtime primitives, and a **Flutter/Dart-only desktop
Command Deck**.

## Frontier Knowledge Plane

JARVIS 12.8.3 now embeds Frontier RAG 2.1 as the application knowledge plane. The integration keeps JARVIS identity, authorization, execution, workspace, model routing, and promotion policy authoritative while Frontier provides adaptive retrieval, evidence analysis, temporal/task knowledge, code and multimodal normalization, graph planning, evaluation, and retrieval diagnostics.

The production entry point is `core.frontier_knowledge.FrontierKnowledgeService`. It is initialized before the UI launches, persists under the configured JARVIS runtime data root, scopes knowledge by tenant/user identity, and routes generation through the JARVIS model router rather than creating a second model-serving boundary.

High-risk external capabilities remain outside the Frontier subsystem and are governed by JARVIS policy. Retrieved material is explicitly treated as untrusted DATA and is never promoted to executable instructions by the integration.

See `FRONTIER_RAG_INTEGRATION.md` for the merge contract and validation evidence.

## V12.8 Frontier upgrades

V12.8.3 adds production control-plane foundations around the existing cognition and autonomy stack:

- `core/trust_engine.py` — fail-closed, capability-aware trust decisions with explicit approval/sandbox states.
- `core/agent_runtime.py` — signed agent authorization, capability leases, bounded execution, cancellation, deadlines, output budgets, and tamper-evident receipts.
- `core/evolution_gate.py` — static, signed candidate validation with source digests, regression/security evidence requirements, and rollback metadata; it never executes candidate code during admission.
- `core/gpu_manager.py` and `core/model_runtime.py` — hardware telemetry, VRAM reservations, model discovery, artifact hashing, and bounded local-model lifecycle management.
- `core/memory_event_store.py` — namespace-bound tamper-evident memory journaling and replay-safe integrity checks.
- `core/device_fabric.py` — capability-bound device abstractions without breaking the existing descriptor contract.
- `core/benchmark_lab.py`, `core/chaos_lab.py`, and `core/jarvis_doctor.py` — measurable performance, bounded fault injection, and machine-readable diagnostics.
- `core/plugin_guard.py` — bounded artifact verification for signed extensions.
- canonical pytest path isolation and deterministic dependency-graph validation.

The architecture intentionally does not claim CUDA/TensorRT, Rust, .NET, Flutter, or Android production certification when those toolchains are not present on the build host.

## Frontier awareness, safety, and bounded self-optimization

The 12.8.3 frontier layer now exposes a cohesive, provider-neutral safety and
awareness plane:

- `core/sensor_fusion.py` normalizes and fuses camera, thermal, radar, LiDAR,
  acoustic, atmospheric, satellite, and telemetry observations with uncertainty,
  trust, provenance, temporal bounds, and conflict scoring.
- `core/world_state.py` maintains a provenance-addressed world-state projection
  with contradiction detection and digest-addressed snapshots.
- `core/cognitive_assistant.py` separates observations, inferences,
  recommendations, and uncertainty; wellbeing support is non-diagnostic, and
  the evidence assistant is coercion-free.
- `core/flight_safety.py` provides deterministic geofenced route, ETA, energy,
  and return-to-home calculations. It contains no targeting or engagement path.
- `core/swarm_coordinator.py` provides human-authorized, simulation-first
  multi-robot allocation with separation checks and an emergency stop.
- `core/cyber_defense.py` provides authorized defensive SOC analytics and
  injected containment actions; offensive intrusion is not exposed by the core.
- `core/telemetry_fabric.py` and `core/hud_diagnostics.py` provide normalized
  multi-system telemetry and a UI-neutral diagnostic/HUD projection.
- `core/lab_automation.py` enforces dry-run defaults and human approval for
  hazardous instrument actions.
- `core/bounded_optimization.py` limits self-optimization to finite,
  benchmark-gated parameter search; source evolution remains subject to the
  existing signed sandbox/test/security/canary promotion pipeline.
- `core/agent_population.py` bounds specialist populations and quarantine/restore
  lifecycle operations.
- `core/distributed_cognitive.py` shares evidence/facts/results while refusing
  credentials and secrets, preserving authority isolation.
- `core/root_authority.py` provides short-lived, single-use operator grants that
  cannot disable immutable safety invariants.
- `core/operational_modes.py` defines simulation, training, emergency, rescue,
  disaster-response, and hazardous-environment modes without an offensive
  autonomous-combat mode.

This is an engineering foundation for frontier intelligence, not a claim that
J.A.R.V.I.S. possesses superintelligence or unrestricted autonomous agency.
Real sensors, vehicles, instruments, and network controls remain explicit
provider boundaries and require deployment-specific certification.

## Architecture

- `main.py` — composition root and compatibility facade
- `core/` — canonical cognition, autonomy, policy, execution, memory, recovery, and runtime fabric
- `services/` — typed service facades
- `security/` — OS sandbox and workload identity primitives
- `agents/` — capability-declared agent management
- `memory/` and `knowledge/` — persistent memory and retrieval
- `tools/` — policy-mediated tool surfaces
- `voice/` — optional voice subsystem
- `api/` — authenticated operator/API surface
- `native/bridge_host/` — native process wrapper for the local Flutter bridge
- `scripts/desktop_bridge.py` — stdio-only local bridge to the Python core
- `flutter/` — **sole product UI/UX**, including the holographic Command Deck

## UI policy

Flutter/Dart is the only first-party UI stack in V12.8.0. The release tree contains no Python-owned desktop UI.
The Flutter application launches a bounded local bridge over stdin/stdout pipes;
it does not open a product TCP/WebSocket listener and does not launch a shell.

The bridge binds the JARVIS operator identity to the owning Flutter process and
exposes only the typed command surface implemented by `core.desktop_command_gateway`.

## Assurance model

Every kernel command receives an auditable capability decision and proof record. High-risk execution remains approval-gated, generated code is sandboxed, plugin capabilities are default-deny, and security audit integrity is fail-closed. Policy replacement is propagated to all kernel security authorities so idempotency replay cannot bypass current authorization. Continual-learning artifacts are quarantined until test, benchmark, security, policy, resource, and external Ed25519 approval gates succeed.

## Security model

High-impact operations are governed by explicit capabilities, scoped policy,
bounded resource budgets, approval proofs, capability leases, execution receipts,
provenance, and post-action verification. External content is treated as
untrusted data. Generated source is staged in a non-approved area until the
acceptance gate succeeds.

Memory, task state, preferences, and knowledge artifacts are namespace-scoped
and integrity-protected. Principal/workspace erasure is explicit and testable.

## Operational certification

```text
python -m compileall -q .
python -m pytest -q -W error
python scripts/strict_quality.py
python scripts/certify_runtime.py
python scripts/run_agent_benchmark.py
python scripts/verify_zero_port.py
python scripts/dependency_graph.py
python scripts/verify_release.py <release.zip>
python scripts/build_release.py --check-reproducible
python scripts/build_wheel.py --output dist
python scripts/run_adversarial_corpus.py
python scripts/soak_test.py --duration 30 --interval 1
```

Native Flutter validation is performed on a host with the Flutter SDK:

```text
cd flutter
flutter pub get
flutter analyze
flutter test
```

Go bridge-host validation:

```text
go test ./native/bridge_host/...
```

## Promotion approval

Model, skill, policy, schema, or source promotion is externally authorized. The
operator signs the canonical candidate-bound approval payload with Ed25519 using
`scripts/sign_promotion.py`; the private key is supplied from a file and is never
placed on a command line. The runtime verifies the candidate binding and signature
before a candidate can enter the `PROMOTED` state.

## Runtime-state hygiene

The `data/` tree is operational state, not release input. Private databases,
identity state, cryptographic keys, certificates, credentials, logs, model files,
and recovery state are ignored by version control and excluded from release
staging. Only release-safe metadata such as `data/dependency_graph.json` is
packaged.

## Release identity

The public version is **12.8.3**. Release
artifacts carry deterministic manifests, SBOM data, provenance, anti-rollback
metadata, and SHA-256 checksums. Production release signing requires an
operator-owned signing key/HSM/KMS trust root and is never synthesized by the
repository.

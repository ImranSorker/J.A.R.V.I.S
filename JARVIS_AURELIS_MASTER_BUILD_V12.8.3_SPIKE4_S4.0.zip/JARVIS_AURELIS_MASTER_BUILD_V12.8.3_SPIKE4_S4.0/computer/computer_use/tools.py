"""Computer automation tools using PyAutoGUI.

Provides cross-platform GUI automation: screenshots, mouse control,
keyboard input, and cursor tracking. All coordinates are screen-relative.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("jarvis.computer")


def computer_use_tools() -> Dict[str, Callable[..., Any]]:
    """Return computer automation tool functions.

    Each function returns a dict with 'ok' and result data.
    """
    if os.name != "nt":
        display = os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")
        if not display:
            logger.info("computer_use_unavailable_no_desktop_session")
            return {}
        display_number = display.split(":", 1)[1].split("/", 1)[0] if ":" in display else display
        display_number = display_number.split(".", 1)[0]
        if display_number.isdigit() and not Path(f"/tmp/.X11-unix/X{display_number}").exists() and not os.environ.get("WAYLAND_DISPLAY"):  # nosec B108 -- read-only existence probe of the X11 socket, not a temp-file creation
            logger.info("computer_use_unavailable_display_socket_missing", extra={"display": display})
            return {}
    try:
        import pyautogui
        pyautogui.FAILSAFE = True  # Move mouse to corner to abort
    except Exception as exc:
        logger.warning("pyautogui_unavailable", extra={"error": str(exc)})
        return {}

    def screenshot() -> Dict[str, Any]:
        """Capture a screenshot."""
        try:
            img = pyautogui.screenshot()
            return {"ok": True, "size": img.size, "mode": img.mode}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def click(x: int, y: int, button: str = "left") -> Dict[str, Any]:
        """Click at screen coordinates."""
        try:
            pyautogui.click(x, y, button=button)
            return {"ok": True, "x": x, "y": y, "button": button}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def type_text(text: str, interval: float = 0.01) -> Dict[str, Any]:
        """Type text with optional delay between keystrokes."""
        try:
            pyautogui.typewrite(text, interval=interval)
            return {"ok": True, "chars": len(text)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def get_cursor_pos() -> Dict[str, Any]:
        """Get current mouse cursor position."""
        try:
            x, y = pyautogui.position()
            return {"ok": True, "x": x, "y": y}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def scroll(amount: int, x: Optional[int] = None, y: Optional[int] = None) -> Dict[str, Any]:
        """Scroll the mouse wheel."""
        try:
            if x is not None and y is not None:
                pyautogui.scroll(amount, x=x, y=y)
            else:
                pyautogui.scroll(amount)
            return {"ok": True, "amount": amount}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def press(key: str) -> Dict[str, Any]:
        """Press a keyboard key."""
        try:
            pyautogui.press(key)
            return {"ok": True, "key": key}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    return {
        "screenshot": screenshot,
        "click": click,
        "type_text": type_text,
        "get_cursor_pos": get_cursor_pos,
        "scroll": scroll,
        "press": press,
    }



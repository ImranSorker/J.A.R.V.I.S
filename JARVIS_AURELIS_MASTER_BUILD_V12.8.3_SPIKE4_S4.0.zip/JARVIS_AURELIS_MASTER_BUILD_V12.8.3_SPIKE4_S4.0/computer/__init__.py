"""Computer automation package."""

__all__: list[str] = []



# J.A.R.V.I.S. V12.8.3 — P2-R Baseline Inspection

## Gate status
BASELINE VERIFIED — all six required predecessor releases were located and SHA-256 verified before P2-R design/implementation.

## Release hashes
| Dependency | Release ZIP SHA-256 | Source-tree hash |
|---|---|---|
| P2-N Agent-to-Agent Verification | `ec228ca0c8d3f6036418f1421436cd16223450d38ee9ebc35f66c6b63d431d41` | `a19aee425adfd9714484fb23461a9a2bd72dc093cb7460a449d2b2ccdcbc126e` |
| P2-O Model Fabric | `e5aae1ef5b64f777cf3ee708b349cf4b75c06d0efc9b3e6734939a243c131ca0` | `b32153f5a01c77b406fcf089f1929881bf1e2fd5f2e1eb46ec81d106afaf6c83` |
| P2-P Tool Fabric | `10a9287e60447b840197f25270e5e12651c5ee10c9ce9f914701827f53cac2ad` | `689eca6f3a4486478449b866065fb456630f13a763dc5a9ed1a073b316acc7fe8` |
| P2-H Experience Memory | `b94f42db0de8a82d2a5663a90597fcfba5216ad108ea20ae8d7f8346986bf55e` | `1505220bd48d0a083dca7a5221350278407f3dc5ab55628c0fb83be7844983fc` |
| P2-J World Model 3.x | `7c4b1729367f64f893a250f9d32c36b577611fb041a94db90d714629d3e52366` | `f74ec4f14460fe1e012229688ac6de2c58d42f3c38f0611ab9da4f7e209a27f0` |
| P2-K Simulation Universe 2.0 | `50633b04f9d86f165d66b7c77e7e4a89ca67f445ce1d7a26905f3cfb23625358` | `06a0b4e4771492c57d7243f4341989ffe2f14fb0b839100ad3533c89c41559a0` |

P2-N predecessor wheel remains known `WHEEL_BLOCKED` from the preceding phase; P2-R does not falsify or hide that limitation.

## Interface inventory

### P2-O — Model Fabric
Canonical API consumed:
- `ModelFabric.route(request, context=...) -> RoutingDecision`
- `ModelFabric.RoutingDecision` exposes `chosen_model_ref`, `fallback_chain`, `estimated_latency_ms`, `estimated_cost`, `policy_version`, and `signature`.
- Model role routing is policy/context gated. P2-R uses roles `reasoning`, `embedding`, and `reranker` through this interface or injected role adapters.

### P2-P — Tool Fabric
Canonical API consumed:
- `ToolFabric.discover(request, context=...)`
- `ToolFabric.select(request, discovery, context=...)`
- `ToolFabric.invoke(request, context=..., plan_ref=None, skill_ref=None, ad_hoc_authorization=None)`
- Search/fetch transport is therefore tool-registry mediated; P2-R does not create a web crawler or bypass the fabric.

### P2-H — Experience Memory
Canonical API consumed:
- `ExperienceMemory.write(item, auth_context, allow_duplicate=False)`
- `ExperienceMemory.query(tenant, auth_context, ...)`
- `ExperienceMemory.recall(auth_context, ...)`
P2-R emits signed semantic-memory **proposals** only and never calls `write` during proposal emission.

### P2-J — World Model
Canonical API consumed:
- `WorldModel3.export_projection(...)`
- `WorldModel3.upsert_entity(...)`
- `WorldModel3.add_relation(...)`
- `WorldModel3.observe_state(...)`
- `WorldModel3.record_plan_projection(...)`
P2-R uses world-state reads/cross-reference and emits proposal envelopes rather than applying production updates.

### P2-N — A2A Verification
Canonical API consumed:
- `request_verification(spec)`
- `verify_identity(...)`
- `verify_authorization(...)`
- `verify_result(delegation_id, result_ref, ...)`
The predecessor P2-N `verify_result` is delegation-bound and requires an existing P2-M delegation. P2-R therefore defines a narrow `research_verifier` integration adapter so artifact verification cannot silently bypass P2-N. Without a configured verifier bridge, proposal emission fails closed.

### P2-I — Failure Intelligence
Canonical API consumed for structured failures:
- `FailureIntelligence.ingest(signal, auth_context, source=...)`
P2-R never silently drops stage failures; they are retained in the research artifact and optionally forwarded to P2-I.

### P2-K — Simulation Universe
Canonical API consumed:
- `SimulationEngine.mandate_required(...)`
- `SimulationEngine.prepare(...)`
- `SimulationEngine.run(...)`
- `SimulationEngine.replay(...)`
- `SimulationEngine.authorization_handoff(...)`
- isolation methods `isolate_memory_write`, `isolate_world_write`, `isolate_cloud_call`, `isolate_secret`
Dangerous research is simulation-gated or requires explicit authorization; P2-R never uses simulation as real-world evidence.

### P2-M — Multi-Agent Orchestration
Canonical API available from P2-N's wrapped orchestration:
- `delegate(...)`
- `send(...)`
- `replay_team(...)`
Team mode is optional and remains bounded by existing P2-M/P2-N security.

## Concrete P2-R dependency touch points
1. Search/fetch execution enters only through configured P2-P tools or explicit test adapters.
2. Model reasoning/embedding/reranking enters only through P2-O role routing or explicit test adapters.
3. High-stakes artifact verification must pass a P2-N research verifier bridge before proposals can be emitted.
4. Memory and world-state outputs are proposal documents, never direct writes.
5. P2-K simulation is an independent evidence source for safety/replay only and is excluded from factual real-world support counts.
6. P2-I receives structured failures after stage abort/refusal when an integration is configured.

## Gap inventory
P2-R must build:
- Frozen research taxonomy and schemas.
- Request lifecycle and bounded budgets.
- Eleven-stage pipeline and signed stage records.
- Source content-addressing and trust-tier rule engine.
- Claim extraction/grounding contract.
- Structural independence/cross-checking and six-kind contradiction engine.
- Evidence DAG construction and cycle detection.
- Grounded synthesis and forbidden-claim enforcement.
- Deterministic confidence calibration.
- Four research modes and frozen defaults.
- Signed proposal generation for P2-H/P2-J/P2-L.
- Refusal/danger policy records.
- Deterministic replay bundle and divergence detection.
- Research-specific P2-N verification bridge.
- Research event taxonomy.
- Research-specific test/adversarial qualification suite.

Already provided by predecessors and not reimplemented:
- A2A verification cryptography and authorization primitives (P2-N).
- Model routing/residency/role selection (P2-O).
- Search/fetch transport and tool authorization (P2-P).
- Semantic memory persistence (P2-H).
- World-state persistence/projection (P2-J).
- Hermetic simulation/replay primitives (P2-K).
- Team delegation (P2-M).
- Structured failure intelligence (P2-I).

## Design consequence
P2-R is implemented as a first-class package `core/autonomous_research/` rather than a single `core/autonomous_research.py` file because the required `core/autonomous_research/trust_tiers/<rule>/<version>/` seed tree cannot coexist with a same-named Python file on the filesystem. The public import remains `core.autonomous_research`.

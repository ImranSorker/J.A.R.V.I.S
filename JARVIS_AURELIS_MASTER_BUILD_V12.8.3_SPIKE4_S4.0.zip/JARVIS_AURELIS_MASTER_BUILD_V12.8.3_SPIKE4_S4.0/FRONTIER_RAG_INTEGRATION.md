# Frontier RAG 2.1 → JARVIS 12.8.0 Integration

The Frontier RAG subsystem is integrated as JARVIS 12.8.0’s knowledge-intelligence plane rather than a second application core.

## Authority split

- **JARVISCore:** identity, capability authorization, execution broker, workspace policy, model routing, lifecycle, promotion, system/device control.
- **Frontier RAG:** adaptive retrieval, chunk/vector/lexical fusion, evidence graph, claim verification, contradiction analysis, graph planning, temporal/task knowledge, evaluation, profiling, code intelligence, and multimodal normalization.
- **Integration adapter:** `core/frontier_knowledge.py`.

## Runtime path

Flutter/local bridge → JARVISCore → FrontierKnowledgeService → Frontier KnowledgeEngine/RAGEngine → scoped evidence/results → JARVIS model router → response → evidence verification → memory/telemetry.

Retrieved documents are wrapped as DATA and passed through JARVIS ContentTrust before entering generation context.

## Identity isolation

Document, chunk, memory, task, evidence, failure, and graph access are scoped by tenant/user. Graph entity creation, lookup, relation traversal, and weighted traversal are identity-aware. Chunk retrieval is subjected to the same hard corpus ACL boundary as parent documents.

## Release policy

Frontier optional providers remain provider-neutral. OCR/ASR/VLM/model-provider behavior is not fabricated by the integration. External services are enabled only through explicit configuration and dependency gates.

# J.A.R.V.I.S. V12.8.0 — Turn 3.1 Operational Patch

This patch keeps the public version at 12.8.0 and records fixes found during real workload validation after Turn 3.

## Root-cause fixes

- AION/AutonomyFabric now treats explicit `{ok: false}` step results as failed execution and routes them through the durable rollback state machine. Failed steps cannot silently complete the DAG.
- GPUManager reservations are device-scoped. A reservation on one GPU no longer consumes capacity on another device.
- Voice TTS reporting is fail-closed: an unavailable TTSEngine cannot produce a successful `voice_tools.speak` result.
- ComputerUseController now suppresses repeated high-impact/consequential actions across screen-state changes using a bounded semantic action guard.
- `scripts/build_wheel.py` already contains the Turn 3 stale-build cleanup; deterministic wheel rebuilds were revalidated.

## Operational evidence

- AION crash/restart workload: PASS.
- AION injected failed-step workload: PASS; sibling state preserved and mission rolled back.
- Network churn workload: PASS.
- GPU driver-shape harness: PASS; real NVIDIA hardware remains BLOCKED in this environment.
- Learned router workload: PASS.
- Continual learning workload: PASS; good checkpoint promoted, regressed checkpoint rejected, missing trainer fails closed.
- Descriptor safe-open adversarial race: PASS.
- Controlled Xvfb computer-use workload: PASS, including an explicitly approved sandbox deletion and duplicate consequential-action rejection.
- Voice file fixture harness: provider-unavailable behavior PASS; real microphone/STT/TTS remains BLOCKED.
- Cross-subsystem integration harness: PASS using explicit GPU/computer boundary harnesses.

## Environment blockers

Real GPU verification requires a supported NVIDIA GPU, current driver, `nvidia-smi`, and CUDA-compatible runtime access.

Real voice verification requires an audio capture/output device, OS permissions, `sounddevice`, a functioning STT provider/model (for example Whisper/faster-whisper plus model weights), and a functioning TTS provider.

The final artifact is released only with these limitations explicitly classified as BLOCKED; no hardware or provider success is simulated.

## Validation

The repository collected 1,020 tests and all 1,020 passed in segmented execution. Ruff was unavailable in the build environment and is not claimed as passed.

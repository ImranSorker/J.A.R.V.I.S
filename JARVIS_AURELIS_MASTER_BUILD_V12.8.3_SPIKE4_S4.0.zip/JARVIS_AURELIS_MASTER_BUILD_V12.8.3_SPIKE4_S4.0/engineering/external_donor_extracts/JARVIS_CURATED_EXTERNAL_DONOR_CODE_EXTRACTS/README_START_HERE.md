# Curated donor-code extracts for JARVIS + AURELIS

Selected source trees and corresponding tests from the supplied five-project workbench. **This is a code-review/reference pack, not a merged or directly buildable dependency.**

Included: 646 selected source/test files. Consult `SOURCE_PATH_MANIFEST.csv` for original paths and per-file SHA-256 hashes.

## Donor areas

- **DeepSeek Harness:** Python SDK, plugin-manager approval/registry lifecycle, subagent lifecycle/control, checkpoint and compaction contracts/tests.
- **Prime Agent:** session core, daemon lifecycle/recovery and relevant continuation/checkpoint/session tests.
- **Hermes Agent:** context compression, context engine, memory providers, session persistence, skill and selected provider material/tests.
- **REA:** evidence ledger, artifact inventory, evidence bundle, replay and verification contracts/tests.
- **Moli Browser:** URL policy, browser profiles/cookies, structured HTML-to-Markdown extraction, and selected CDP/WebDriver protocol layers.

## Important source limitations

The supplied aggregate source dump does not reliably preserve all original Git metadata, dependency lockfiles, non-source assets, build manifests or license files for these projects. `SOURCE_PATH_MANIFEST.csv` records the exact extracted content hashes but **does not prove an upstream commit identity or establish redistribution clearance**. Before copying code into JARVIS, restore each full upstream repository at an exact commit, verify the applicable license and third-party notices, compare file hashes, understand dependencies, then port with tests.

## Reuse rule

Use each file as a candidate to study/port. Do not duplicate JARVIS's policy, mission scheduler, memory authority, model router or tool execution path. Any executable external integration must go through JARVIS authorization and the security gates.

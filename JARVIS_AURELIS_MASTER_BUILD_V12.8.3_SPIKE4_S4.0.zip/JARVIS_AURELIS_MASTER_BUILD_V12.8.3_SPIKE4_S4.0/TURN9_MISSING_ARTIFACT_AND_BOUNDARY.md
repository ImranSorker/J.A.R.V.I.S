# Turn 9 — Missing Artifact Decision and Boundary Test

## C1 — `data/self_knowledge_graph.json`

Classification: **deferred artifact**.

References were found in:
- `main.py:1194` — runtime `AIOSFabric` knowledge-path configuration.
- `scripts/release_ceremony.py:26` — release artifact manifest.
- `scripts/generate_artifact_manifest.py:13` — required-artifact list.
- `scripts/audit_self_consistency.py:13` — self-consistency verification input.
- `scripts/rebuild_self_knowledge.py:19` — generator output path.
- historical release/implementation reports documenting the same artifact.

A generator is present: `scripts/rebuild_self_knowledge.py`. The self-consistency audit fails with an explicit `RuntimeError` when the file is absent; it does not silently pass. The runtime `SelfKnowledgeGraph` loader starts an empty graph when the file is missing, but that is separate from the release self-consistency gate.

Action: do not fabricate or commit the generated artifact. Document the build step `python scripts/rebuild_self_knowledge.py` as the release-time generation step. The missing artifact remains a declared release/build prerequisite rather than a hand-written source fix.

## C2 — Gateway boundary marker

`test_local_desktop_boundary_uses_no_internal_network_ui_imports` now carries `pytest.mark.xfail(strict=True)` with the P2Z_GATEWAY_TRANSPORT_COUPLING reason and a reference to `TURN8_GATEWAY_BOUNDARY_PLAN.md`. This makes the deferred extraction visible while forcing an unexpected-pass failure once the extraction lands.

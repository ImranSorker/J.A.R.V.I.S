# J.A.R.V.I.S. V12.8.3 — P2-W Agent Economics / Resource Scheduler

Status: COMPLETED
Public version: 12.8.3
Kernel: 12.8.0

## Baseline

Baseline is verified. The original P2-W blocker was caused by failure to surface the standalone P2-E release in the first search. A later Library-wide search found it; the actual ZIP hashes to the prescribed P2-E identity.

## Implementation

Added `core/agent_economics.py` as the canonical P2-W subsystem.

Implemented:
- frozen five-axis economics taxonomy
- signed/resource-ceiling bounded requests
- signed/chained allocation decisions
- signed measurement-linked accounting records
- scheduling policy registration/activation
- tenant/agent/team/quota enforcement
- weighted fair queue, deficit round robin, seeded lottery and hierarchical fairness
- starvation escalation
- policy-bound checkpointed pre-emption and resume
- deterministic queue ordering and decisioning
- explicit reduced allocations/substitutions
- raw/normalized/cost-unit accounting
- policy-driven financial conversion with no hardcoded runtime rates
- deterministic chargeback attribution
- estimate-vs-actual reconciliation and deviation events
- P2-E harness accounting adapter
- tenant-isolated query surfaces
- replay digest and ledger verification
- additive P2-U Economics event taxonomy
- P2-W policy/cost/currency seed artifacts

## Integration guardrails

P2-W allocates and accounts only. It does not execute, deploy, mutate agents, alter plans, bypass Security Authority, or bypass P2-E.

Dangerous resource requests require a danger reference and authorization context. Pre-emption requires a policy-approved pre-emptor, an eligible pre-emptee, minimum progress, bounded per-window frequency, and a valid checkpoint.

## Compatibility correction

P2-T/P2-M already own `core/schemas/escalation_record_v1.schema.json`. P2-W originally targeted the same filename, which would have broken a predecessor contract. The final release preserves the established schema and adds `core/schemas/economics_escalation_record_v1.schema.json`; P2-W uses the latter internally.

## Validation

- P2-W dedicated tests: 52/52 passed.
- P2-M + P2-T-adjacent / Learning / Evolution cross-phase regression: 207/207 passed for the executed suites.
- Feature evidence audit: 180/180 complete.
- Compileall: PASS.
- Polyglot protocol contract: PASS.
- Service contract: PASS.
- Source release reproducibility: PASS.
- Wheel reproducibility with `SOURCE_DATE_EPOCH=0`: PASS.
- Release manifest/CRC verification: PASS during release build.

The broader 165-file runtime certification was attempted with four workers and a 15-second per-file cap. It reached 16/165 files before the bounded command window terminated it. Existing failures observed during that scoped run were in `tests/architecture/test_replaceability.py` and `tests/architecture/test_boundaries.py`; the full certification matrix is therefore not claimed as passed.

Long-running P2 phase suites also exceeded the bounded aggregate command window during the final regression attempt. They are not reported as failed unless an assertion failure was actually observed.

Unavailable quality tools: `ruff`, `black`, `mypy`, `bandit`, `pip-audit`, `import-linter`.

Existing repository-level authority findings remain in `core/agent_factory.py` and `core/kernel_12_8_0/sandbox.py`; no new P2-W direct-process/network path was added.

## Release

P2-W remains V12.8.3. No version increment.

## Final artifact identity

The authoritative source ZIP identity is recorded in the external `.sha256` sidecar and in the in-toto/SLSA-style provenance statement. The wheel identity is likewise recorded in the release checksums sidecar. Keeping these digests external avoids a self-referential archive hash.

Final packaged-source regression for P2-W plus the executed P2-L/P2-M/P2-G/P2-V adjacent suites: 259/259 passed.

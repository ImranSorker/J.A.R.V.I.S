# Native Agent Forge integration contracts

- JARVIS remains the authority for identity, permission, model selection, tool execution, memory, audit and provenance.
- Forge produces candidate definitions; it does not independently grant capabilities.
- Validating or registering a manifest creates a draft, not permission to execute.
- Runtime activation is a separate audited, operator-approved transition and is deliberately not implemented here.
- Required later interfaces: definition export/source digest; trusted identity/policy authorization; canonical disabled-draft registry; activation broker after security gates; evidence/provenance receiver.
- Fail closed on unknown schema, unsigned or mismatched source identity, unapproved capabilities/tools, bad principal, missing artifact hashes, missing provenance, or uncertain runtime constraints.

# JARVIS/AURELIS Next-Step Integration Plan

**Audit date:** 2026-10-15  
**Target baseline:** supplied JARVIS V12.8.3 source-release bundle  
**External inputs:** aggregate source dump representing Moli Browser, Prime Agent, Hermes Agent, REA, and DeepSeek Harness; reconstructed source workbench; generated file inventory and subsystem crosswalk  
**Document status:** implementation plan based on static inventory and targeted source-path review; not a code merge, successful build, penetration test, license opinion, or production certification.

## Evidence labels used in this plan

- **Verified inventory fact:** directly counted from the supplied source inventory or JARVIS baseline inventory.
- **Source-path candidate:** a path present in the reconstructed inventory and worth reviewing; presence does not prove code correctness or successful runtime behavior.
- **Architecture recommendation:** a proposed target contract, control, test, or rollout.
- **Open / unverified:** requires an original manifest, execution, test, license/provenance evidence, or a human decision.

---

## 1. Understanding of the mission — five bullets

1. **JARVIS remains the governing runtime.** Its current security, policy, model routing, agent creation, memory/RAG, verification, telemetry, GUI, and recovery paths are the canonical integration points unless the baseline audit proves a particular interface is inadequate.
2. **The five source projects are capability donors, not five new runtimes to merge wholesale.** Reuse is earned by capability and test evidence, not by line count or project reputation.
3. **Spike 1 establishes the execution trust boundary first.** No imported shell, filesystem, browser, plugin, MCP, or subprocess code may receive direct host authority by default. The first adapter must be deny-by-default and have a kill switch.
4. **Spike 2 establishes durable and recoverable work next.** Sessions, jobs, worker leases, checkpoints, handoffs, cancellation, idempotency, and resource budgets must be explicit and observable; “exactly once” side effects must not be claimed without a transactional boundary that actually provides them.
5. **Everything remains evidence-led.** The inventory contains approximately 8.18 million physical lines, not 8.18 million lines of verified production logic. Build metadata, license provenance, original revisions, native dependencies and runtime behavior must be restored or verified before promoting an adapter to production.

## 2. Assumptions and open questions

### 2.1 Working assumptions

| ID | Assumption | Impact if false | How to resolve |
|---|---|---|---|
| A1 | The supplied JARVIS V12.8.3 archive is the correct current baseline for integration. | All module mappings and acceptance baselines may be stale. | Record repository URL, exact commit SHA, branch, archive SHA-256, and release tag from the project owner. |
| A2 | The aggregated external dump preserves source file paths and file contents for its listed entries, but not every original repository artifact. | Build systems, licenses, binary assets, generated-code sources and some dependency semantics may be absent. | Reacquire exact upstream snapshots and compare source hashes. |
| A3 | The current desktop target includes Windows; Linux support may be required later. | Sandbox implementation and packaging differ by OS. | Declare a supported-OS matrix for each adapter and sandbox backend. |
| A4 | The existing JARVIS policy broker remains the single authority for approval and tool permissions. | A second policy authority can create inconsistent authorization. | Identify and test the actual construction path for `JARVISCore` and its policy dependencies. |
| A5 | Imported external tools are untrusted until reviewed, even when a project has extensive tests. | Security posture remains fail-open. | Default imported adapters to disabled and require signed allowlisted manifests. |
| A6 | Local-first operation and optional online providers must both work. | Provider fallback, DNS, network and credentials handling change. | Define offline mode and provider-specific egress rules as testable policy. |
| A7 | JARVIS will retain its Flet Command Center as the current primary desktop UI. | External CLI/TUI/web UI code could be over-integrated unnecessarily. | Treat clients as reference implementations until a UI migration is separately approved. |
| A8 | The first two spikes are prototypes that must pass independent conformance gates before general use. | A time-boxed proof may be mistaken for a production-ready security mechanism. | Label all flags and UI states `experimental` until the release gate passes. |

### 2.2 Open questions to answer before implementation

1. What are the exact upstream repository URLs, immutable commit IDs, release dates, and branch names for all five projects?
2. Which license applies to each repository and each vendored/native dependency? Are any generated files or binaries under separate terms? Is redistribution and commercial use permitted for the intended distribution model?
3. Does the source dump omit package manifests, lockfiles, Rust workspaces, Node workspace configuration, Python project metadata, `.git` history, submodules, Git LFS files, V8/JS runtime assets, code signing information, and build scripts? Restore these before attempting builds.
4. What is the actual JARVIS V12.8.3 commit or immutable archive checksum, and which CI/test report corresponds to that exact artifact?
5. What sandbox guarantee is required on Windows today: best-effort child-process isolation, restricted token + Job Object, AppContainer, Windows Sandbox/VM, or another boundary? What is the acceptable fallback if a hardening primitive is unavailable?
6. Is network access denied by default for every imported tool, or do specific tool identities need allowlisted egress? Are private-LAN devices a supported target? If yes, they need explicit named network capabilities rather than a general “local network” bypass.
7. Which state store is canonical for durable jobs and sessions? Existing JARVIS storage should be assessed before adding another database. What crash-loss window is acceptable?
8. Which actions require user approval: shell commands, filesystem writes outside a per-job workspace, package installation, credentials, network, browser form submission, publication, deletion, or other irreversible effects?
9. What are the maximum concurrent jobs, worker depth, retry count, tokens, wall-clock time, CPU, memory, disk, artifact size, and network bytes per job on supported hardware?
10. Which existing JARVIS policy, tool, event, provenance and scheduler interfaces are stable public contracts versus internal implementation details?

### 2.3 Artifacts required for a reliable build and compatibility review

| Required artifact | Why it matters | Minimum acceptable evidence |
|---|---|---|
| Original upstream snapshots or repositories at immutable commit SHAs | Verifies tree identity and enables reproducible builds. | Commit SHA + archive/tree hash for each project. |
| `LICENSE`, `NOTICE`, copyright headers, SPDX identifiers, dependency-license data | Establishes code and redistribution obligations. | License/provenance ledger with per-project and vendored dependency disposition. |
| Package manifests and lockfiles (`Cargo.toml`/`Cargo.lock`, Node package manifests/lockfiles, Python `pyproject.toml`/requirements/lock files, workspace configs) | Determines dependency and runtime compatibility. | Exact manifests matching each source revision. |
| CI workflows, release scripts, supported toolchain matrix | Documents intended build, test, lint and packaging commands. | Reproducible local CI invocation with tool versions. |
| Binary assets, generated-code inputs, schemas, submodules and Git LFS objects | Prevents incomplete or misleading builds. | File completeness report vs. upstream tree. |
| JARVIS baseline commit, environment file examples, pinned dependencies, current doctor/test/lint outputs | Establishes a before-change regression baseline. | Saved results and checksums attached to the baseline. |
| Windows and Linux sandbox capability report | Identifies primitives actually available on target operating systems. | Automated capability probe; unsupported hardening must fail closed for high-risk tools. |
| Threat model and approval matrix signed by project owner | Converts risk appetite into enforceable policy. | Named capabilities, permitted side effects and default-deny rules. |
| SBOM and vulnerability/license scan outputs | Supports supply-chain review and repeatable updates. | CycloneDX or SPDX SBOM plus dated scan reports. |

**Important:** if any license, source revision, or security boundary remains unknown, keep the corresponding source in `reference-only` or `disabled` status. Do not infer a permissive license or assume an implementation is safe because it has many tests.

---

## 3. Capability-by-capability integration matrix

The following are the highest-value capability slices found in the inventory and the existing JARVIS baseline. External path names are relative to each reconstructed project's root. Paths are review candidates, not validated import instructions. Risk ratings are preliminary engineering judgments.

| Capability | Existing JARVIS target | Source project(s) and key source areas/files | Native interface to use | Missing invariants to verify or add | Approach | Risk | Required tests | Sequence / owner |
|---|---|---|---|---|---|---|---|---|
| Typed tool registry and call envelopes | `core/tool_fabric/impl.py`, `super_agent/tools/registry.py`, `core/schemas/tool_manifest_v1.schema.json`, `core/schemas/tool_invocation_request_v1.schema.json`, `core/schemas/tool_invocation_result_v1.schema.json` | DeepSeek: `packages/core/tools/src/index.ts`, `schema.ts`, `json-schema.ts`, `ptc.ts`; also tool contracts in `packages/*` | Versioned JARVIS `ToolManifest`, `ToolInvocationRequest`, `ToolInvocationResult` | Schema validation on both ends; strict tool/version identity; input/output size limits; stable errors; side-effect declarations; no arbitrary dynamic registration | **Adapt** contract patterns; preserve JARVIS registry | High | Valid/invalid schemas, schema evolution, unknown tool/version deny, output truncation, duplicate IDs, malicious nested JSON, deterministic error mapping | Spike 1, Security/Tool Fabric owner |
| Permission broker, approvals and capability grants | `core/permission_engine.py`, `core/policy_gateway.py`, `core/agent_policy.py`, `core/execution_policy.py`, `super_agent/safety/permissions.py` | DeepSeek: `packages/credentials/authorization/src/index.ts`, `packages/guard/*`, `packages/identity/*`, `packages/host/*` | JARVIS policy decision API returning allow/deny/approval + obligations and decision ID | Deny by default; least privilege; short-lived scoped approvals; no ambient inheritance from parent agent; revocation and audit binding | **Adapt**; JARVIS remains sole authority | Very high | Permission escalation attempts, expired/replayed approval tokens, parent-to-child privilege tests, deny overrides, policy-change race tests | Spike 1, Security owner |
| Sandboxed process lifecycle and resource controls | `security/os_sandbox.py`, `security/sandbox.py`, `security/sandbox_profiles.py`, `security/windows_job.py`, `super_agent/sandbox/runner.py` | DeepSeek: `packages/sandbox/sandbox/src/index.ts`, `sandbox-local/src/index.ts`, `sandbox-policy/src/index.ts`; `packages/subprocess/*` | JARVIS `SandboxProfile` + isolated worker runner contract | Fail-closed if required isolation is unavailable; process tree containment; CPU/RAM/time/disk/pids caps; no writable host paths; termination proof | **Adapt** policies, run external sidecar; do not import into privileged host | Very high | Escape attempts, child-process survival, resource exhaustion, read/write outside root, unsupported-backend fail-closed | Spike 1, Sandbox owner |
| Filesystem reads/writes and path confinement | `security/*`, `core/security_executor.py`, `core/tool_fabric`, `super_agent/tools` | DeepSeek: `packages/fs/fs/src/index.ts`, `fs-local/src/fsio.ts`, `fs-sandbox/src/containment.ts`, `fs-observation-policy/src/index.ts` | JARVIS workspace/capability API that resolves canonical paths inside a per-job root | Symlinks/reparse points, UNC/device paths, case folding, traversal, TOCTOU, hard links, temp paths and delete/write limits | **Adapt** containment ideas; use JARVIS workspace as authority | Very high | `../`, encoded traversal, symlink swap, junction/reparse point, UNC/device namespace, case-insensitive collision, concurrent rename, quota exhaustion | Spike 1, OS/Security owner |
| Shell and subprocess execution | `core/security_executor.py`, `security/windows_job.py`, `security/os_sandbox.py`, `core/tool_fabric` | DeepSeek: `packages/shell/bash-sandbox/src/index.ts`, `pwsh-sandbox/src/index.ts`, `bash-local/src/index.ts`, `pwsh-local/src/index.ts`, `packages/subprocess/subprocess/src/*` | Allowlisted JARVIS command adapter with argument arrays, executable identity and policy review; no free-form shell by default | Shell interpolation/injection, PATH hijacking, working-directory control, inherited env/secrets, process-tree kill, output caps, executable allowlist | **Adapt** only after contract review; default deny shell | Very high | Injection payloads, malicious PATH, Unicode/quote edge cases, environment leakage, timeout and child kill, output flooding | Spike 1, Security owner |
| Credentials and identity | `security/mtls_identity.py`, `security/worker_identity.py`, `core/policy_gateway.py` | DeepSeek: `packages/credentials/credentials/src/*`, `credentials-local/src/index.ts`, `authorization/src/*`, `identity/anonymous-user-id/src/index.ts`; Hermes provider credential paths | JARVIS credential broker; ephemeral, task-scoped secret handle | Secrets not in prompts, event logs, environment dumps, crash reports or artifacts; process-scoped audience; rotation/revocation | **Adapt**; never merge a second credential authority | Very high | Secret canary scan across logs/artifacts, worker isolation, token expiry, cross-session leakage, redaction under exceptions | Spike 1, Security owner |
| Network egress, SSRF and URL policy | `core/network_policy.py`, `core/autonomous_research` trust tiers, `core/policy_gateway.py` | Moli: `moli-url-policy/src/{route,scheme,error}.rs`, `moli-fetch/src/{client,dns,config}.rs`; DeepSeek network/sandbox policy | JARVIS network capability service; URL decision before connection and re-check at redirect/resolve/connect | DNS rebinding, private/reserved IPs, IPv4/IPv6 variants, redirects, alternate schemes, proxy bypass, websocket and browser subrequests | **Adapt** URL policy; enforce at socket/worker boundary too | Very high | SSRF corpus; IPv4/IPv6/private/mapped addresses; DNS rebinding simulation; redirect chain; IDNA and unusual schemes; egress firewall deny tests | Spike 1, Networking/Security owner |
| Browser profile and cookie isolation | `tools/browser_automation/browser.py`, `computer/computer_use/*`, `core/network_policy.py` | Moli: `moli-browser-profile/src/{profile,profile_lock,profile_manifest,profile_paths,identity}.rs`; `moli-cookie-store/src/*`; protocol storage modules | JARVIS per-identity browser-context API; isolated profile per task/user/tenant | Cookie/session boundaries; profile locking; encrypted or protected storage where required; safe teardown; no reuse across identities | **Adapt** concepts; no engine import in Spike 1 | Very high | Cross-profile cookie tests, profile lock contention, crash cleanup, path aliasing, storage deletion and identity separation | Spike 1 prototype only for URL/profile contracts; full driver later |
| Durable session and event journal | `super_agent/durability/*`, `super_agent/replay/*`, `core/replay_engine.py`, `core/provenance_graph.py` | DeepSeek: `packages/session/*`, `packages/session-query/*`, `packages/spill/*`, `packages/compaction/*`; Prime session code | JARVIS versioned job/session event envelope and canonical session ID | Monotonic per-job sequence; atomic event append; schema migration; redaction; checkpoint ownership; corruption detection | **Adapt** after store/semantics decision | High | Crash during append/checkpoint; duplicate/reordered event; replay determinism; schema migration; redaction/retention | Spike 2, Runtime/Data owner |
| Daemon/supervisor, session leases and recovery | `core/autonomous_recovery`, `core/mission_runtime.py`, `core/task_scheduler.py`, `super_agent/durability/*` | Prime: `packages/coding-agent/src/modes/daemon/daemon-supervisor.ts`, `daemon-supervisor-ownership.ts`, `daemon-worker-client.ts`, `daemon-worker-protocol.ts`, `worker-recovery-journal.ts`, `core/session-lease.ts`, `cli/owned-session-worker.ts` | JARVIS supervisor API; fenced leases; heartbeat and worker identity | Lease expiry and fencing; stale owner rejection; process supervision; worker restart bounds; unambiguous terminal states | **Adapt** lifecycle patterns; no parallel daemon | High | Kill/restart workers at each state; stale lease owner writes; lease renewal race; orphan cleanup; supervisor restart | Spike 2, Runtime owner |
| Job queue, idempotency and side-effect handling | `core/task_scheduler.py`, `agents/scheduler/nl_scheduler.py`, `core/mission_contract.py`, `super_agent/durability/atomic_transition.py` | DeepSeek: `packages/jobs/jobs-local/src/{index,pump,events}.ts`, `packages/schedule/schedule/src/{domain,runtime,storage}.ts`; Prime queues/leases | JARVIS JobRecord with idempotency key, attempt number, side-effect ledger and deadlines | At-least-once semantics explicit; idempotency keys; retries bounded; ambiguous effects become `NEEDS_REVIEW`; queue backpressure | **Adapt**; use existing scheduler or extend it | High | Duplicate enqueue, repeated tool call, lost ack, worker crash after effect-before-ack, backpressure and retry storms | Spike 2, Runtime/Data owner |
| Agent workers, subagent handoffs, recursion limits | `core/agent_factory.py`, `core/agent_fabric.py`, `core/agent_garage.py`, `core/agent_workshop.py`, `core/agent_genome.py`, `core/multi_agent_orchestration` if present in baseline | Prime coding-agent loop and worker protocols; DeepSeek `packages/subagent/subagent/src/*`, `packages/goal/goal/src/*`, `packages/plan/plan-mode/src/*` | Native JARVIS mission/agent contracts; parent/child task IDs, capability envelope, budget ledger | Recursion depth, concurrent worker cap, inherited permissions deny-by-default, handoff schema, cancellation propagation and context budget | **Adapt** selected algorithms/contracts | High | Recursive spawn bomb, cross-task leakage, cancellation propagation, worker exhaustion, malformed handoff, cost/token budget overshoot | Spike 2, Agent Runtime owner |
| Goal, plan, workflow and recovery state | `core/mission_contract.py`, `core/mission_runtime.py`, `core/agent_fabric.py`, `core/tool_composition.py`, `core/autonomous_research`, `core/autonomous_recovery` | DeepSeek: `packages/goal/goal/src/{index,domain,fold}.ts`, `packages/plan/plan-mode/src/index.ts`, `packages/workflow/workflow/src/*`, `tool-workflow/src/*` | JARVIS mission/plan/workflow contract and state transition APIs | Versioned plans; validated state transition graph; evidence for completion; compensation/rollback for reversible effects; persisted budget | **Adapt** and reconcile schemas; don't host a second planner state store | High | Invalid transition, plan version drift, interrupted workflow, compensation failure, cyclic workflow, unverified success | Spike 2, Agent Runtime owner |
| Memory, session recall and context compression | `jarvis_rag/*`, `super_agent/memory/*`, `super_agent/rag/*`, `memory/*`, `core/provenance_graph.py` | Hermes: `agent/memory_manager.py`, `agent/memory_provider.py`, `agent/context_compressor.py`, `tools/session_search_tool.py`; DeepSeek session/compaction paths | Canonical JARVIS Memory/RAG API with provenance and retention policy | User/tenant/session separation; citations/source links; deletion/forget semantics; stale/conflicting fact handling; context budgets | **Adapt** strategies only after benchmarks | High | Recall precision, no cross-session leakage, deletion guarantees, ungrounded memory, contradiction resolution, prompt injection in retrieved content | Phase 3, Memory/RAG owner |
| Skill catalog and progressive skill loading | `super_agent/skills/*` if present, `core/agent_genome.py`, `core/agent_workshop.py`, `core/agent_garage.py`, `core/tool_fabric` | Hermes `skills/*`, `optional-skills/*`; DeepSeek `packages/skill/skill/src/index.ts`, `skill-filesystem/src/index.ts`, `packages/extensions/*` | Signed/versioned JARVIS `SkillManifest` with declared capabilities and evaluation metadata | Origin/signature, permission manifest, dependency hashes, instruction-injection defense, version pinning, revocation, rollback | **Adapt** manifest/loader patterns; never auto-execute all imported skills | High | Malicious frontmatter, path escape, injected instructions, undeclared tool call, revocation and uninstall, version rollback | Phase 3, Agent/Plugin owner |
| Model-provider adapters and failover | `core/model_fabric.py`, `core/adaptive_router.py`, `super_agent/models/*`, `qwen_integration/*` | Prime `packages/ai/src/providers/*`; Hermes `agent/provider_registry.py`, `agent/provider_base.py`, `agent/fallback_cooldown.py`; DeepSeek `packages/llm/*` | JARVIS provider interface and sole router | Bounded fallback loops; privacy/policy parity per provider; secret redaction; retry/backoff; local-first mode; budget ceilings | **Adapt** missing provider adapters only | Medium-high | Offline/no-key tests; malformed responses; fallback-loop cap; timeout and rate-limit handling; credential redaction | Phase 3, Model Fabric owner |
| Channel gateways and remote control ingress | `api/server.py`, `super_agent/gateway/*`, `core/contracts/*`, observability | Hermes `gateway/*`, `plugins/platforms/*`, transports; DeepSeek `packages/api/gateway/*`, clients | One JARVIS ingress envelope carrying authenticated principal, source channel, scopes, nonce, trace ID and approval status | Strong identity mapping; replay protection; channel allowlists; rate limits; safe attachments; no channel-specific policy bypass | **Adapt** individual adapters as optional ingress | High | Forged identity, replay, rate limits, revoked token, untrusted attachment, approval and audit enforcement | Phase 3/4, API owner |
| Evidence, artifact hashing and replayability | `core/provenance_graph.py`, `super_agent/verification/*`, `super_agent/contracts/*`, `core/schemas/*` | REA `src/domain/evidence*`, `src/application/*Evidence*`, `src/artifacts/*`, `src/replay/*`, `src/application/ProcessCapture*` | JARVIS evidence/provenance record: inputs, hashes, tool identity, raw observations, derived claims, limits and replay recipe | Distinguish observation from inference; tamper detection; tool/version provenance; limitations; reproduction steps | **Adapt** evidence schemas and methods | Medium-high | Hash mutation, deterministic re-run, missing evidence refusal, observation/inference confusion, tool version mismatch | Phase 4, Evidence owner |
| Native, binary, Electron and process investigation | `native/bridge_host`, `polyglot/*`, `core/provenance_graph.py`, `super_agent/sandbox/runner.py`, `tools/code_executor.py` if present | REA `src/application/{Electron*,Native*,ProcessCapture*,ManagedNativeVerificationService*}`, `src/ghidra/*`, `src/hopper/*`, `bridge/native/*` | Isolated investigator-worker protocol with artifact hash, capability grants, resource limits and evidence bundle output | Untrusted binary isolation; external tool license checks; no host privilege; replayable results; platform boundaries | **Sidecar**; start with mock providers | Very high | Malformed binary corpus, worker timeout, sandbox escape, no-tool-installed behavior, evidence integrity, platform-specific smoke tests | Phase 4, Native/Forensics owner |
| Browser protocol and structured extraction | `tools/browser_automation/browser.py`, `computer/computer_use/*` | Moli `moli-protocol-cdp/src/*`, `moli-protocol-webdriver-classic/src/*`, `moli-protocol-webdriver-bidi/src/*`, `moli-html2md/src/*` | JARVIS browser-driver adapter with normalized navigate/extract/act/result contracts | Action-level permission checks; DOM stale references; output sanitization; site-specific policy; cancellation; navigation egress enforcement | **Adapt** protocol/extraction first | High | Mock protocol conformance; redirect/SSRF; stale handles; hostile DOM; auth boundary; action confirmation; cancellation | Phase 5, Browser owner |
| Full Moli Rust/V8 browser runtime | Existing browser automation plus an isolated process supervisor | Moli `moli-renderer-v8/src/*`, browser core, fetch, DOM/layout/paint and vendored V8 directories | Versioned sidecar RPC protocol; no direct Python/native in-process linking in initial phase | Upstream build completeness, V8 provenance, memory/process isolation, crash containment, sandbox, license/SBOM, protocol compatibility | **Sidecar candidate only**; not replace | Very high | Reproducible build; process kill; memory cap; no host profile leakage; web-platform subset; security and license gate | Phase 5, separate go/no-go |
| Telemetry, benchmarks, evals and conformance suites | `observability/*`, `evaluation/*`, `core/autonomous_system_doctor.py`, `tests/*` | All five projects' tests/fixtures/benchmarks; Moli `moli-benchmark/*`; DeepSeek benchmarks/evals; Hermes evals | JARVIS redacted telemetry and shared conformance harness | Distinguish expected fixture data from runnable tests; prevent secrets in traces; stable regression thresholds; provenance attached to results | **Adapt tests/benchmarks**; never count test LOC as runtime capability | Medium | Secret scanning; reproducible benchmark; flaky test detection; differential baseline; coverage of negative cases | Cross-cutting, QA/Security owner |
| CLI, TUI, web and desktop experiences | Flet Command Center / current JARVIS client contracts | DeepSeek `apps/*`, `packages/api/*`; Prime TUI; Hermes CLI/TUI/web/desktop | Current JARVIS API/event contracts; UI remains replaceable | No alternate client bypasses permissions; async cancellation; UI state follows durable server state | **Reference/adapt selectively**, not a wholesale UI replacement | Medium | API contract tests; permission parity; session resume; cancellation; accessibility and UI responsiveness | Last / only if a defined UX gap exists |

### Reading the matrix correctly

- A source path in the matrix is an **inspection target**, not an endorsement. We have not established that it is secure, compatible, or superior to the matching JARVIS module.
- For similarly named modules, the existing JARVIS test suite and real construction path determine the authoritative interface. Do not infer stable API guarantees from filenames alone.
- Keep imports and runtime boundaries small. It is preferable to port a validated state machine or a handful of schemas than to embed a second framework with its own plugin loader, provider router, session database and policy authority.

---

## 4. Spike 1 — JARVIS Execution Fabric and security boundaries

### 4.1 Objective and timebox

**Objective:** prove that one imported tool can be described, authorized, executed in a constrained child process, audited and disabled without granting the imported project ambient host authority.

**Recommended spike timebox:** 5 engineering days for the thin adapter and conformance proof, followed by implementation/hardening tickets. A five-day spike is **not** enough to certify a commercial-grade sandbox or authorize arbitrary shell/plugin execution.

### In scope

- Read and compare the DeepSeek typed tool, filesystem, sandbox, subprocess and shell contracts with JARVIS tool schemas and sandbox implementations.
- Compare Moli URL policy and browser-profile isolation concepts at the contract level; no live browser engine in the first adapter.
- Define manifest, invocation, policy decision, result, audit/provenance and sandbox-profile interfaces.
- Implement one local **read-only fixture tool** in a low-privilege child process, operating only on a synthetic workspace. It should return a bounded JSON result and audit reference.
- Add deny-path conformance tests, resource limits, feature-flag gating and a kill switch.

### Out of scope

- Arbitrary user shell execution as a production feature.
- Loading arbitrary plugins or skills directly into `JARVISCore`.
- Running the full Moli/V8 browser engine.
- Automatically granting network, credentials, host filesystem, computer-control, or device access.
- Claiming that the sandbox blocks every escape vector before platform-specific tests and independent review.

### 4.2 Target contracts

Use existing `core/schemas/tool_manifest_v1.schema.json`, `tool_invocation_request_v1.schema.json`, `tool_invocation_result_v1.schema.json`, `tool_side_effect_v1.schema.json`, `core/tool_fabric/impl.py`, `core/policy_gateway.py`, and `security/*` as first review targets. Add new versions only when the existing schemas cannot express a required invariant; avoid breaking schema consumers silently.

#### `ToolManifest` (versioned and validated before registration)

Required fields or equivalent existing-schema fields:

- `tool_id`, `version`, `display_name`, `description`, immutable `source_digest`, `origin`, `license_status`, `entrypoint`, `runtime_kind`.
- JSON input/output schema references and maximum serialized input/output sizes.
- Declared capabilities: read/write roots, executable IDs, network destinations, credential handles, browser profiles, and other side effects.
- Risk class, required approval class, maximum time/CPU/memory/disk/output budgets, concurrency limit, and idempotency behavior.
- Dependency/SBOM digest, signature/attestation status where signing is used, and minimum compatible JARVIS contract version.
- A manifest being syntactically valid is not a grant. The policy broker separately decides which declared capabilities to grant.

#### `ExecutionRequest`

- `request_id`, `job_id`, `session_id`, `principal`, `tool_id`, exact `tool_version`, validated arguments, `idempotency_key`, `deadline`, `trace_id`, `approval_reference`, `requested_capabilities`, and a correlation/provenance reference.
- Caller-provided paths or URLs must be revalidated by the policy/adapter layer. The tool cannot declare that its own arguments are trusted.
- The request is immutable after authorization; changed arguments require a new decision.

#### `PolicyDecision`

- `decision_id`, allow/deny/approval-required, scoped capability grants, reason code, policy version, obligations, expiry, subject, target tool digest and request hash.
- Approval is short-lived, bound to the exact request and tool version, non-replayable, and revocable. Do not accept a boolean `approved=true` from an untrusted client as proof of authorization.

#### `SandboxProfile`

- Unique job workspace, read-only runtime image/code, explicit writable temp/output paths, environment allowlist, secret-handle list, denied-by-default network, process tree limits, CPU/memory/wall-time/disk/output caps, OS identity, and mandatory isolation features.
- The runner reports which controls were **actually applied**, not just which were requested. If a mandatory isolation control cannot be activated, reject high-risk execution rather than silently downgrading.

#### `ExecutionResult`

- `execution_id`, terminal status, typed result/error code, bounded stdout/stderr if the tool contract requires it, start/end times, resource usage, termination reason, applied sandbox controls, side-effect/effect-ledger references, artifacts and hashes, audit event IDs, and provenance parents.
- Errors must not expose secrets, host paths, credential handles, internal tokens or unbounded process output.
- The result must distinguish `failed-before-start`, `failed-with-no-known-side-effect`, and `side-effect-state-unknown`. The last case cannot be blindly retried.

#### `AuditEvent` / provenance event

- Append-only sequence, actor, job/session, tool/version/digest, policy decision, capability grants, start/stop/kill reason, outcome, artifact hashes, redacted input/output digests, and parent event links.
- Do not write raw credentials or full sensitive arguments to an event store. Redaction must happen before persistence; secret canaries should be part of tests.

### 4.3 Contract and architecture shape

```text
JARVISCore / Command Center
           |
           v
  Tool Fabric (canonical registry)
           |
           v
 Policy Gateway (allow / deny / approval)
           |
           v
 Execution Broker ---- append-only audit/provenance
           |
           v
 OS sandbox supervisor / dedicated low-privilege identity
           |
           v
 Minimal adapter process (read-only fixture tool)
           |
           v
 bounded structured result + artifact hashes
```

The worker process must not receive a reference to `JARVISCore`, an unrestricted filesystem object, the parent process environment, a provider API key, or an unrestricted network client. The broker passes only a normalized request and explicit capabilities.

### 4.4 Threat model

| Threat / trust boundary | Attacker capability | Required mitigation | Evidence for acceptance |
|---|---|---|---|
| Malicious or compromised imported tool | Tool code tries to access host files, shell, secrets or arbitrary network. | Child process; least-privilege identity; allowlisted capabilities; restricted workspace; denied network by default; resource limits; killable process tree. | Adversarial tool tests, OS logs and negative controls show denied attempts. |
| Malicious request data | User, website, model output or document supplies crafted paths, shell syntax, URLs or JSON. | Strict schema; canonicalization; parameterized process launch; contextual validation; never concatenate data into shell commands. | Security corpus and property-based tests. |
| Confused deputy in JARVIS | Low-trust agent asks a privileged tool to perform a higher-privilege action. | Central policy broker; authority bound to principal + task + exact request; no ambient parent privilege; approval tokens bound to request hash. | Cross-agent permission escalation tests. |
| SSRF / network pivot | Tool controls URL, redirect or DNS result to reach loopback, private/LAN or metadata endpoints. | Resolve and validate at connection time; re-evaluate redirects and address families; enforce egress at worker/OS boundary; explicit destinations. | SSRF corpus with IPv4/IPv6, redirects, IDNA, DNS rebinding and proxy cases. |
| Credential exfiltration | Tool inspects environment, command line, logs, temp files or output. | No inherited secrets; secret broker with scoped handles; redaction before persistence; no secrets in process args; rotate/revoke. | Secret-canary scan across logs, artifacts, process metadata and errors. |
| Sandbox fallback / fail-open | Required backend unavailable, but system executes anyway with weaker controls. | Explicit capability probing; high-risk profile fails closed; UI and audit disclose downgrade; no silent fallback. | Test with required isolation deliberately unavailable. |
| Browser identity leakage | One task accesses another task's cookies, cache, local storage or profile. | Per-principal/task profile root, safe lock/creation, no shared auth state by default, teardown and retention controls. | Cross-identity profile-isolation tests before any browser action is enabled. |
| Runtime exhaustion | Infinite loop, fork bomb, output flood, large artifact, parser attack. | CPU, RAM, process count, wall-clock, storage, output and nesting limits; parent supervisor can terminate whole tree. | Deterministic timeout/quota tests under load. |

### 4.5 Isolation strategy

1. **Keep the privileged core separate from imported code.** No direct in-process plugin import for unreviewed external source.
2. **Run a minimal worker as a separate process** under a dedicated low-privilege identity, with a per-job working directory and a sanitized, allowlisted environment.
3. **Apply mandatory platform limits.** On Windows, inspect and test the supplied `security/windows_job.py`, `security/os_sandbox.py` and related sandbox profile code; verify actual Job Object limits and child-process termination. Where available, add a stronger boundary such as a restricted token/AppContainer or a disposable VM for high-risk analysis. On Linux, evaluate namespaces/seccomp and a supported sandbox backend. Do not claim either platform is hardened from source inspection alone.
4. **Fail closed for high-risk tools.** If the configured sandbox level cannot be applied, return a structured `SANDBOX_UNAVAILABLE`/policy-denied result and do not run the tool outside the boundary.
5. **Deny network by default.** Add explicit host/domain/port capabilities only after DNS/IP/redirect enforcement has been tested. Policy-only URL checking is insufficient if the actual socket path can bypass it.
6. **Constrain filesystem access.** The first adapter gets read access to a synthetic fixture root and write access only to a job-local output directory. Canonicalize paths while guarding against symlink/reparse-point and TOCTOU races.
7. **Broker secrets outside the worker.** Prefer scoped handles or one-shot secret delivery; do not put secrets in command-line arguments or general-purpose environment variables.
8. **Use structured argument arrays, not string-built shell commands.** The initial shell capability remains disabled. A later shell adapter must define executable and argument policy, working directory, environment, process tree, output caps and approval semantics.
9. **Keep policy, results and audit in JARVIS.** External code must not be able to self-approve, self-register as trusted or erase its audit record.

### 4.6 Feature flags and rollout

| Flag | Initial value | Meaning |
|---|---|---|
| `JARVIS_EXTERNAL_TOOL_ADAPTERS` | `false` | Master kill switch for imported adapters. |
| `JARVIS_EXTERNAL_TOOL_ALLOWLIST` | empty | Explicit digest-pinned tool IDs that may be loaded. Empty means none. |
| `JARVIS_EXTERNAL_TOOL_READONLY_SPIKE` | `false` | Enables only the fixture-backed read-only adapter after a developer/test opt-in. |
| `JARVIS_EXTERNAL_TOOL_NETWORK` | `false` | Network egress is denied until a separately tested capability is approved. |
| `JARVIS_EXTERNAL_TOOL_SHELL` | `false` | Shell/subprocess tools stay disabled for the initial release. |
| `JARVIS_EXTERNAL_TOOL_BROWSER` | `false` | Moli/browser tools remain disabled during Spike 1. |
| `JARVIS_EXTERNAL_TOOL_REQUIRED_SANDBOX` | platform-qualified strict profile | Expected control profile; execution denied if mandatory controls are missing. |

All flags must be read through the current JARVIS settings/config contract, validated at startup, logged without secrets, and included in diagnostics. A flag cannot override a policy denial.

### 4.7 Rollback design

- One command or configuration change disables `JARVIS_EXTERNAL_TOOL_ADAPTERS`, blocks new work and stops queued imported-tool jobs.
- Supervisor sends cooperative cancellation, waits a bounded interval, then terminates the complete worker process tree through the OS supervisor.
- Revoke scoped credential handles and network grants; delete or quarantine job temp directories according to forensic retention policy.
- Preserve append-only audit/provenance events and artifact hashes; do not roll back by deleting history.
- No irreversible JARVIS database migration during the spike. Any new schema must be additive, versioned and backward-compatible with flag-off startup.
- Re-enabling requires digest revalidation, dependency and license status check, sandbox capability probe, and the conformance suite.

### 4.8 Minimal first adapter

**Prototype:** `FixtureReadTool`—a read-only child process that reads a small synthetic JSON/Markdown fixture from a configured fixture root, returns a bounded normalized JSON object, emits no network traffic and cannot see real user data.

1. Register a signed-or-local-dev-only manifest with immutable digest and `filesystem.read:fixture_root` capability only.
2. Validate request JSON against the registered schema and compute a request hash.
3. Ask the policy gateway for authorization; policy denies all undeclared capabilities.
4. Start the isolated worker with a clean environment, no credentials, read-only fixture root and bounded output folder.
5. Enforce a short deadline, small memory/CPU/disk quotas and a hard output-size cap.
6. Hash inputs/outputs, record policy decision and applied sandbox controls, then return the typed result.
7. Test denial of `../`, symlinks/reparse points, shell launches, environment inspection, loopback network access, output flooding, timeouts and attempts to write outside the output root.

This adapter is deliberately boring. It proves the trust boundary and telemetry before adding a powerful tool.

### 4.9 Spike 1 conformance tests

**Contract tests:** valid/invalid manifest; unknown schema version; unknown tool ID/version; malformed JSON; oversized payload; invalid argument type; missing side-effect declarations; duplicate registration; stale digest; result/error schema; policy-denied result.

**OS/security tests:** path traversal; symlink and junction/reparse-point escapes; UNC/device path cases on Windows; shell injection; malicious executable/PATH substitution; child process tree termination; environment and credential leakage; DNS/IP/redirect checks; unsupported sandbox backend; process, time, memory, disk and output exhaustion; concurrent cancellation and timeout race.

**Audit/provenance tests:** each execution has an immutable correlation chain; policy decision is bound to the exact tool digest/request hash; secrets are redacted before event storage; killed/crashed workers produce a terminal or quarantined state; artifact hashes match; error paths are audited.

### 4.10 Spike 1 acceptance criteria

Spike 1 is accepted only if all are true:

- The read-only fixture tool runs only when both the feature flag and explicit allowlist/policy permit it.
- No imported code runs inside the privileged `JARVISCore` process.
- High-risk execution fails closed if mandatory sandbox controls are unavailable.
- All negative tests above pass on the declared target OS; test results are saved and repeatable.
- Every allow, deny, approval, launch, timeout, kill and result has a redacted audit record linked to a request and tool digest.
- Secret-canary tests find no credentials in logs, artifacts, stdout/stderr or errors.
- The master flag disables new work and kills active worker trees within a defined bounded time.
- Existing JARVIS startup, doctor, core tests and UI remain unchanged with flags off.
- `python -m compileall -q .` and the baseline pytest suite pass for changed Python files/modules; external Rust/TypeScript builds are validated separately with their restored toolchains.

**Non-acceptance:** a passing happy-path demo alone, policy checks without OS enforcement, an undocumented isolation downgrade, unresolved license status, or a test harness that does not prove denial paths.

---

## 5. Spike 2 — Persistent agents and recoverable tasks

### 5.1 Objective and timebox

**Objective:** prove that a bounded JARVIS task can survive supervisor/worker process failure, resume safely from a durable checkpoint, cancel predictably, hand off to a child worker, and avoid blindly duplicating an external side effect.

**Recommended spike timebox:** 5 engineering days for a state-machine prototype and crash-injection harness, followed by delivery stories. The spike should reuse the canonical JARVIS store where possible, rather than introduce a second database just to match an external project's architecture.

### In scope

- Compare Prime's daemon/session lease/supervisor/worker recovery patterns with the JARVIS mission, scheduler and recovery machinery.
- Compare DeepSeek session event, jobs/lease, goal/plan/workflow, and subagent contracts with JARVIS's existing durable transition/event and mission APIs.
- Define a canonical task state machine, versioned event envelope, heartbeat/lease with fencing token, checkpoint and idempotency/effect ledger.
- Prototype one local task with two deterministic steps, process restart, cancellation, and one child worker handoff.
- Inject crashes at each state boundary and document replay/retry semantics.

### Out of scope

- Unlimited recursive agents or autonomous daemon execution of arbitrary tools.
- Replacing JARVIS's current scheduler, mission runtime or event store before a compatibility review.
- Claiming exactly-once external effects without target-system idempotency or transaction support.
- Automatic retry of an operation whose external side-effect status is unknown.

### 5.2 Canonical task lifecycle

Proposed states; map to existing schemas rather than duplicating names blindly:

`CREATED → QUEUED → CLAIMED → RUNNING → (WAITING_APPROVAL | CHECKPOINTED | HANDOFF_PENDING) → RUNNING → SUCCEEDED`

Terminal/failure states: `FAILED`, `TIMED_OUT`, `CANCELLED`, `NEEDS_REVIEW`, and optionally `QUARANTINED` for corrupted/unsafe state. Requeue and retry must be explicit transitions with attempt count and failure classification.

| State transition | Required guard | Persisted evidence |
|---|---|---|
| `CREATED → QUEUED` | Valid request/manifest; budgets assigned; idempotency key recorded. | Request hash, actor, goal/plan version and queued timestamp. |
| `QUEUED → CLAIMED` | Atomic lease claim; concurrency budget available; worker identity generated. | Lease ID, owner, expiry, fencing token and attempt number. |
| `CLAIMED → RUNNING` | Worker confirms environment and mandatory sandbox level. | Applied sandbox controls and start event. |
| `RUNNING → CHECKPOINTED` | Checkpoint is schema-valid and atomic; no untracked secret is serialized. | Checkpoint hash, plan version, event sequence and resumable step ID. |
| `RUNNING → WAITING_APPROVAL` | Proposed side effect requires human approval. | Exact request hash, scope, approver, expiry and approval state. |
| `RUNNING → HANDOFF_PENDING` | Child work validated against depth/concurrency/budget/permissions. | Parent/child IDs, delegated capabilities and parent checkpoint. |
| `RUNNING → SUCCEEDED` | Required result checks and verification complete; no unresolved side effects. | Result hashes, evidence refs and completion check summary. |
| `RUNNING → FAILED/TIMED_OUT` | Error classified; worker stopped or quarantined. | Failure class, resource use, known side-effect state and retry eligibility. |
| Any active state → `CANCELLING` → `CANCELLED` | Cancellation authority valid; worker and descendants receive cancel. | Initiator, time, worker termination evidence, remaining effect status. |
| Expired lease → recovery decision | New worker obtains a newer fencing token; old worker is unable to commit. | Recovery reason, previous owner, checkpoint and effect-ledger reconciliation. |
| Unknown external effect → `NEEDS_REVIEW` | Effect may have happened but no authoritative acknowledgement exists. | Operation key, request/response hashes and manual/target-system reconciliation requirement. |

### 5.3 State and persistence contract

A `JobRecord` or existing equivalent should carry:

- Immutable `job_id`, `session_id`, `parent_job_id`, request hash, actor, objective, approved capabilities, plan/workflow revision, tool/skill/model digests and JARVIS contract versions.
- State, attempt count, budget counters, absolute deadline, cancellation token/version, lease owner and fencing token.
- `idempotency_key` for each side-effecting step, not merely one key for the entire job.
- Append-only event sequence and event schema version; checkpoint hash and step index; provenance/evidence references; artifact manifests.
- Last known side-effect state (`NONE`, `PENDING`, `CONFIRMED`, `COMPENSATED`, `UNKNOWN`) and references to external operation IDs where provided.
- Safe error classification and sanitized diagnostic context.

Durable writes must use the actual transaction/atomicity guarantees of the chosen JARVIS store. If the store cannot atomically update job state and event sequence, document the consistency model and design reconciliation explicitly. Avoid introducing a new datastore until the existing one is measured and shown to be insufficient.

### 5.4 Lease, queue and worker semantics

- **Atomic lease claim:** a worker must win a compare-and-set/transaction to claim a queued job. Two workers must not both become owners.
- **Fencing token:** each lease generation increments a token. Writes from an old owner are rejected after lease expiry/recovery, even if that process is still alive.
- **Heartbeat:** renew only while the worker is healthy, within its deadline, and still holds the current lease. Heartbeat silence triggers recovery after a configurable grace period, not immediate duplicate execution.
- **Queue backpressure:** cap queued and in-flight jobs; reject or defer work with a structured reason when capacity is exhausted. Per-user/principal quotas prevent one agent from starving all others.
- **At-least-once delivery:** assume a job can be delivered again after failure. Make each step idempotent where possible. For non-idempotent operations, use a provider-supported idempotency token or move ambiguous outcomes to `NEEDS_REVIEW`.
- **Cancellation:** cooperative cancellation first, bounded grace period next, supervisor termination after grace period, then OS process-tree kill. Cancellation propagates to child jobs; a child must not outlive the parent unintentionally.
- **Retry taxonomy:** retry only transient, side-effect-safe failures within configured attempts/backoff. Do not retry policy denials, invalid input, license failures, exhausted budgets, or ambiguous external actions automatically.
- **Worker isolation:** persistent sessions retain state, not permanent authority. Every resumed worker revalidates the principal, tool/skill digests, policy version and required sandbox capabilities.

### 5.5 Goal, plan and workflow semantics

- Persist the goal's identity and owner separately from its mutable plan revision.
- A plan version is immutable once execution starts; amendments create a new revision with a recorded reason and fresh validation.
- Each step has a bounded retry policy, declared inputs/outputs, capability requirements, success predicate, side-effect classification and optional compensation.
- “Completed” requires deterministic verification or explicit human acknowledgement for the relevant task type. An LLM's own assertion is not sufficient evidence for critical actions.
- Constrain recursion depth, child count, aggregate budget and total wall-clock time at the parent mission level; child budgets are carved out of the parent budget, not added on top.
- Handoff payloads contain only task-relevant context, references, constraints, authorized tools and completion contract—not the parent's unrestricted credentials or full private history by default.
- Recovery rebuilds from durable events plus a validated checkpoint; if event/checkpoint hashes conflict, stop and quarantine rather than guess.

### 5.6 Crash recovery algorithm

1. Supervisor starts and scans non-terminal jobs using the canonical JARVIS state interface.
2. For each expired lease, prevent stale-owner commits with a new fencing token and mark the former owner as lost.
3. Load the last valid checkpoint and verify its hash/schema/version; replay later durable events deterministically where supported.
4. Reconcile the side-effect ledger with the target operation's idempotency/status API if available.
5. If the effect is proven absent, requeue within budgets. If it is confirmed, advance to the verified next state. If unknown, set `NEEDS_REVIEW`; do not replay automatically.
6. Create a recovery event containing reason, old/new lease IDs, checkpoint/effect reconciliation references and recovery decision.
7. Resume only after revalidating permissions, expiration, tool code digest, secret scopes, quotas and sandbox availability.

### 5.7 Observability requirements

**Per job:** state-duration histogram, current state/step, attempts, lease age, last heartbeat, checkpoint sequence/hash, queue wait, parent/child counts, token/model cost if applicable, tool calls by capability class, resource use, cancellation duration, recovery count, effect-unknown count and terminal result.

**Global:** queue depth/backlog age, worker saturation, expired leases, recovery-loop counts, crash/restart rate, retry rate, stale owner write rejection count, budget rejections, stuck state transitions and unhandled state migrations.

Observability must be structured and redacted. Do not put raw prompt contents, credentials or sensitive files in metrics labels. Each trace/event should have a stable correlation chain that links mission, job, step, tool execution and artifact provenance.

### 5.8 Spike 2 test plan

- State machine transition tests: every allowed edge, every forbidden edge, concurrent transition race and duplicate event.
- Lease tests: two workers contend; lease expires; old worker attempts to write; fencing token rejects it; heartbeat stalls; supervisor restarts.
- Crash-injection matrix: kill before claim, after claim, after starting a step, after side effect but before acknowledgement, after checkpoint write, during checkpoint update, after child launch and during cancellation.
- Idempotency tests: duplicate queue item, repeated request, provider returns same operation ID, lost acknowledgement, safe retry and ambiguous side-effect routing.
- Cancellation tests: cooperative exit, unresponsive child, nested children, timeout-vs-cancel race, supervisor process failure, OS kill of entire tree.
- Budget tests: max concurrency, child-depth limit, token/time/memory quota, retry cap, cost cap, queue backpressure and starvation prevention.
- Recovery tests: checkpoint corrupted; schema version unknown; code digest changed; revoked approval; changed policy; unsupported sandbox; effect status cannot be reconciled. Expected result: stop, quarantine or `NEEDS_REVIEW`—not blind execution.
- Regression: baseline task scheduler, mission runtime, autonomy, GUI progress state and core doctor still behave with the experimental path disabled.

### 5.9 Spike 2 acceptance criteria

- State changes and checkpoints survive supervisor/worker restart with no silently lost acknowledged state updates.
- Competing workers cannot both commit under the same lease; a stale worker is fenced after recovery.
- Cancellation reaches descendants and ends the whole worker tree within the configured bound.
- No ambiguous side-effect case is automatically replayed; it transitions to `NEEDS_REVIEW` or a provider-verified recovery path.
- Every task has declared budgets, retry policies, idempotency behavior and a complete provenance link.
- Goal/plan/workflow revisions are versioned and state transitions are schema-validated.
- All crash-injection tests pass for the prototype's stated store/platform; known limitations are documented.
- Existing JARVIS tasks and UI remain compatible; the new runtime is opt-in and can be disabled without a destructive migration.
- The integration can resume a deterministic multi-step test after forced worker termination and yield the same verified output without repeating a side effect.

---

## 6. Security and conformance checklist for both spikes

Use these as release-gate checklist items. Each should have a named test, an expected denial/success result, logs/evidence and a linked issue for any failure.

| Control | Spike 1: execution | Spike 2: durable agents | Required evidence / stop condition |
|---|---|---|---|
| Sandbox escape | Try host filesystem, process, namespace and device escape from imported worker. | Try worker/child to escape task ownership or use parent authority after resume. | Any reproducible boundary break blocks release. |
| Shell injection | Inject shell metacharacters, quotes, Unicode, newlines, leading dashes, PATH changes and executable substitutions. | Ensure restored job inputs cannot mutate a command after approval/checkpoint. | No command-string concatenation; unsafe execution denied. |
| Path traversal | `../`, encoded traversal, symlinks, junctions/reparse points, UNC/device paths, hard links and TOCTOU. | Check persisted paths are revalidated after resume and on OS/path changes. | No access/write outside declared roots. |
| Credential leakage | Scan process env, argv, logs, stdout/stderr, exceptions, temp files and artifacts with secret canaries. | Check checkpoint, session replay, handoff and worker restart do not persist or broaden secrets. | Zero canary hits; any hit is a release blocker. |
| Network egress / SSRF | Deny by default; test private/reserved/loopback IPs, redirects, IDNA, IPv6, DNS rebinding and proxy routes. | Ensure jobs don't gain egress merely by being resumed or delegated. | Denied traffic verified at the enforcement point, not only in app-level checks. |
| URL policy bypass | Alternate schemes, user-info authority confusion, redirects, host normalization, IP literals, WebSocket and embedded resources. | Validate URL grants again on recovery and when plan arguments change. | Policy is enforced at connect time and every redirect. |
| Browser-profile leakage | Cross-user/task cookies, cache, local storage, downloads and profile lock tests. | Resumed session binds to the same authorized identity or intentionally creates a new profile. | No data crossed between identities; profile reuse is opt-in. |
| Resource exhaustion | CPU loop, memory growth, process tree, disk fill, oversized response and output flood. | Unbounded child recursion, queue flood, heartbeat storm, retry storm and long-running task. | Quotas stop/contain worker; supervisor/core remains responsive. |
| Race conditions | Concurrent registry mutation, authorization revocation during launch, cancel-vs-timeout, path replacement. | Double lease claims, stale-owner writes, duplicate event append and checkpoint/side-effect races. | Atomicity/fencing proven under stress and race injection. |
| Permission escalation | Forged approvals, stale tokens, tool claims ungranted capabilities, child worker inherits broad access. | Child inherits parent grants; resume after role/policy revocation; cross-tenant job lookup. | Every capability checked at invocation boundary and again when resuming. |
| Audit logging | Ensure allow, deny, approval, start, applied isolation, termination, outputs and artifacts are linked. | Ensure state transitions, lease claims, retries, recovery, cancellation and effect reconciliation are recorded. | No missing terminal/recovery event; logs are redacted and tamper-evident where required. |
| Provenance | Hash source tool, manifest, request, input/output artifacts and policy decision. | Link mission → job → plan revision → step → tool execution → artifact → verification result. | Verifier can detect mismatched or missing hashes/parent references. |
| Supply-chain integrity | Verify immutable source revision, license status, dependencies, SBOM, signature and build outputs. | Pin task's tool/skill/model revision so recovery does not silently execute changed code. | Unknown license or changed digest blocks activation/resume. |
| Safe failure | Missing sandbox, policy service error, invalid manifest, broken credential broker. | Corrupt checkpoint, unavailable store, unknown side-effect state, invalid plan version. | Deny or quarantine; never continue with weakened controls or guessed state. |
| Availability / kill switch | Disable adapter, stop queueing, revoke grants, terminate process tree. | Stop queue, cancel current tasks/descendants, checkpoint safe state, prevent restart loop. | Measured time-to-disable and proof no work continues without authorization. |
| Data retention / deletion | Remove per-job temp data according to policy while preserving required audit. | Session retention and user-directed deletion reconcile with audit/provenance obligations. | Written data lifecycle and tests; no accidental cross-session recall. |

**Required security sign-off:** the security owner must review failures and accepted limitations. Passing a source linter or unit test suite is not equivalent to a penetration test or a sandbox certification.

---

## 7. Roadmap for priorities 3–5

### Phase 0 — Reproducible baseline and provenance (parallel prerequisite)

1. Pin each external source revision and restore missing manifests/licenses/assets.
2. Produce an SBOM and per-file/license provenance map; distinguish authored source, vendored dependency, generated code, tests, fixtures and examples.
3. Run baseline JARVIS doctor, `python -m compileall -q .`, current pytest suite, linter/type checks and packaging checks from a clean environment. Save the exact environment and outputs.
4. Build a component-level diff: existing JARVIS contract, external behavior candidate, gap, tests, license status, decision (`port`, `adapt`, `sidecar`, `reference-only`, `reject`).
5. No production code changes before the reference baseline is reproducible.

### Priority 3 — AURELIS Memory Fabric, skills and model integrations

**Sequence:** Hermes recall/context patterns → skill catalog and progressive loading → provider adapters/fallback → optional channel ingress.

- Benchmark Hermes `agent/memory_manager.py`, `agent/context_compressor.py`, `tools/session_search_tool.py` and session/state logic against JARVIS RAG using a labeled query/answer corpus. Track recall precision, answer grounding, latency, context-token savings and deletion behavior.
- Adopt recall/ranking/compression as adapters or algorithms behind the existing JARVIS Memory/RAG API. Preserve evidence sources and provenance with each recalled item. Do not create a second authoritative memory store unless a migration/replication design is approved.
- Create a JARVIS `SkillManifest`: origin/revision/hash, description, declared tool capabilities, dependency/environment spec, permissions, test/eval results, compatibility and rollback version. Progressive loading reduces context size; it does not by itself make instructions trustworthy.
- Audit optional skills separately. Skills that touch financial accounts, crypto, shell, external networks, credentials, files or computer control need per-skill threat review and must remain disabled until allowed.
- Map provider connectors from Prime/Hermes/DeepSeek to the single JARVIS Model Fabric. Provider fallback must honor local-only mode, data classification, latency/cost ceilings and user settings. Do not let an adapter initiate its own unbounded retry loop.
- Channel integrations are remote attack surfaces. All incoming messages must become a normal JARVIS request with authenticated principal, permitted scopes, replay defense, rate limits, attachment quarantine and common audit/provenance handling.

**Gate:** memory quality is measured against baseline; no cross-session leakage; skills are digest-pinned and permissioned; provider fallback is bounded; local-only mode is tested.

### Priority 4 — AURELIS Evidence Engine

**Sequence:** schemas and artifact hashes → deterministic replay → browser/JS/Electron investigation → native/binary worker plugins.

- Map REA evidence/result DTOs (`src/domain/evidence*`, `src/application/*Evidence*`, `src/artifacts/*`, `src/replay/*`) to `core/provenance_graph.py`, `super_agent/verification/*` and `core/schemas/*`.
- Preserve the distinction between raw observation, derived analysis, model-generated hypothesis and verified claim. Record tool versions, artifact digest, invocation options, platform, limitations and reproduction steps.
- Start with inert sample artifacts and mocked native providers. Add process, Electron, JavaScript, Ghidra and Hopper paths as isolated worker adapters one by one.
- Unknown proprietary dependencies, missing debugger tools, unsupported platforms or unverified signatures must result in an explicit `UNAVAILABLE`/`UNVERIFIED` status, not a fabricated success.
- Do not execute untrusted binaries in the JARVIS core. Sidecar workers receive only the artifact and a read-only tool bundle, with no secrets and strict resource limits.

**Gate:** deterministic evidence envelope, hash integrity, replay where supported, safe refusal when tool/platform is missing, isolation verified, and licenses reviewed.

### Priority 5 — AURELIS Navigator / Moli

**Sequence:** URL policy and extraction → existing-browser protocol adapters → profile isolation → optional Moli sidecar evaluation.

- First compare `moli-url-policy`, `moli-fetch`, `moli-html2md`, and CDP/WebDriver Classic/BiDi APIs with `tools/browser_automation/browser.py`.
- Create a normalized JARVIS `BrowserSession`/`BrowserAction`/`BrowserObservation` adapter with navigation, text/DOM extraction, screenshot/artifact references, action permissions, timeout and cancellation. Treat every page and document as untrusted input.
- Apply URL policy to top-level navigation and subresources, redirects, fetches and browser-created requests where the engine permits. Do not rely exclusively on pre-navigation string validation.
- Store profiles by principal/task identity. Login/cookies, downloads, browser storage, clipboard and form submission need distinct grants and audit events. Destructive or externally visible actions require confirmation policy.
- Only after protocol/extraction success should the full Moli Rust/V8 runtime be considered. Restore Rust workspace/build manifests, V8 assets and licenses; benchmark memory, startup, compatibility, sandbox behavior and crashes. Run it as a sidecar, not an in-process replacement.

**Gate:** URL-policy adversarial suite passes; profile isolation passes; browser side effects are approval-gated; adapter failure/cancel works; the full browser runtime remains optional and killable.

---

## 8. Ticket breakdown for the first two spikes

### Estimation basis

Story-point estimates are **planning estimates**, not measured durations. Assume one engineer familiar with JARVIS, an available security reviewer, and access to a reproducible Windows development environment. External repository restoration and legal review can change estimates materially. The five-day spike timeboxes below are discovery/prototype milestones; the follow-on story estimates are implementation work.

### Epic EF — Execution Fabric security boundary

| Ticket | Story / task | Estimate | Depends on | Definition of done |
|---|---|---:|---|---|
| EF-01 | Pin JARVIS baseline and external source revisions; add audit manifest | 3 pts | None | Checksums, commit/revision fields, license status, toolchain and missing-artifact list recorded. Unknown values remain explicit. |
| EF-02 | Threat model, trust-boundary diagram and capability/approval matrix | 3 pts | EF-01 | Owner-reviewed threat model; every risky capability has default, approver, scope and negative test. |
| EF-03 | Compare existing JARVIS tool manifest/request/result schemas with DeepSeek typed-tool contracts | 5 pts | EF-01 | Field-by-field gap report; backward-compatibility plan; no duplicate registry introduced. |
| EF-04 | Define or extend versioned execution and sandbox contracts | 5 pts | EF-02, EF-03 | Schemas validated at runtime; strict IDs/digests; structured policy/result/error types and migration tests. |
| EF-05 | Implement feature-flagged fixture read-only adapter | 5 pts | EF-04 | Disabled by default; one synthetic fixture path; no live shell/network; bounded typed result. |
| EF-06 | Integrate policy decision, request-bound approval and capability checks | 5 pts | EF-04 | All calls pass through one canonical policy authority; expired/replayed approvals denied. |
| EF-07 | Isolated child-process runner and applied-controls report | 8 pts | EF-02, EF-04 | Separate process; clean environment; quota/deadline; complete process-tree termination; fails closed when mandatory isolation is unavailable. |
| EF-08 | Filesystem root confinement and adversarial path suite | 5 pts | EF-07 | Traversal, symlink/reparse point, UNC/device and race tests pass on declared OS. |
| EF-09 | Network/URL policy contract and SSRF tests (no production egress enablement) | 5 pts | EF-04 | Redirect/DNS/IP validation suite; network remains off by default; enforcement boundary documented. |
| EF-10 | Audit/provenance, secret redaction and kill switch | 5 pts | EF-05–EF-07 | All state/action events linked and redacted; master flag blocks new jobs and kills active worker trees within agreed bound. |
| EF-11 | Security conformance and baseline regression suite | 8 pts | EF-05–EF-10 | Negative tests automated; CI outputs saved; baseline tests and doctor pass. |
| EF-12 | Supply-chain/license/SBOM release gate | 5 pts | EF-01 | License and dependency status reviewed; unknowns block activation; reproducible manifest/report archived. |

**Spike 1 exit:** EF-01 through EF-07 have a thin end-to-end prototype and one fixture adapter; EF-08 through EF-12 may remain implementation tickets if the 5-day timebox ends, but the missing controls must keep the adapter disabled outside the spike environment.

### Epic DR — Durable agents and recovery

| Ticket | Story / task | Estimate | Depends on | Definition of done |
|---|---|---:|---|---|
| DR-01 | Map existing JARVIS mission, scheduler, recovery, durability and replay contracts | 3 pts | EF-01 | Existing authoritative module/store selected; duplicate scheduler/store proposal avoided. |
| DR-02 | Define job lifecycle and versioned state/event envelope | 5 pts | DR-01 | State transitions/schema validated; invalid transition and unknown version tests pass. |
| DR-03 | Implement atomic job claim, lease expiry and fencing token | 8 pts | DR-02 | Concurrent workers cannot claim/commit as same owner; stale process commits are rejected. |
| DR-04 | Add checkpoints and restart recovery for deterministic steps | 8 pts | DR-02, DR-03 | Kill/restart at every state edge resumes from last verified checkpoint; hash/schema failures quarantine. |
| DR-05 | Implement per-step idempotency/effect ledger | 8 pts | DR-02 | Duplicate request and lost acknowledgement do not duplicate known-safe effects; ambiguous effects transition to review. |
| DR-06 | Cancellation propagation and process-tree termination | 5 pts | EF-07, DR-03 | Parent/child cancellation works under timeout/race conditions; bounded termination time recorded. |
| DR-07 | Goal/plan/workflow revision and child-handoff constraints | 5 pts | DR-02 | Plan version pinned; child inherits only explicit capabilities/budgets; recursion/worker caps tested. |
| DR-08 | Retry taxonomy, queue backpressure and resource budgets | 5 pts | DR-02, DR-03 | Retryable vs non-retryable cases explicit; quotas enforced; flood tests remain bounded. |
| DR-09 | Crash-injection, recovery, metrics and regression tests | 8 pts | DR-03–DR-08 | Automated crash matrix passes; dashboards/structured logs capture recovery and state durations; baseline suite passes. |
| DR-10 | Compatibility and rollout/rollback procedure | 3 pts | DR-09 | Feature-flag off path tested; migration is additive/backward-compatible; recovery flag can be disabled without data loss. |

**Spike 2 exit:** DR-01–DR-04 have a deterministic prototype and crash-injection proof. Do not claim full reliable autonomy until DR-05–DR-10 pass on the selected store and target OS.

### Suggested order and dependency path

`EF-01 → EF-02/03 → EF-04 → EF-05/06/07 → EF-08/09/10 → EF-11/12`  
`EF-01 → DR-01 → DR-02 → DR-03/04 → DR-05/06/07/08 → DR-09/10`

Parallel work is appropriate for legal/source restoration and baseline test preparation, but policy, worker isolation and task recovery should not be implemented against invented contracts.

---

## 9. Risks, assumptions and kill criteria by spike

### Spike 1 risks

| Risk | Likelihood / impact | Mitigation | Kill / pause criterion |
|---|---|---|---|
| Existing JARVIS sandbox behavior is weaker/different than its names suggest. | Unknown / critical | Run source review plus adversarial tests against actual Windows OS behavior. | Cannot enforce the required isolation or cannot terminate all child processes; no imported code runs beyond test fixtures. |
| Source revisions or licenses cannot be established. | Medium / high | Keep source reference-only; obtain upstream metadata and counsel/owner review. | No license/provenance basis for redistribution or build; no code port. |
| Adapter can access secrets or host paths through inherited process state. | Medium / critical | Clean environment, scoped paths and credentials, secret-canary scanning. | Any reproduced credential leakage or out-of-root file access blocks activation. |
| Network controls exist only in app code and can be bypassed through direct sockets/browser requests. | Medium / critical | Add OS/sidecar egress enforcement; test actual network path. | Cannot demonstrate egress denial at enforcement point; keep network-enabled adapters disabled. |
| Scope expands into arbitrary shell, browser engine or plugin marketplace. | High / high | Strict one-adapter timebox and explicit out-of-scope list. | Spike cannot yield a minimal isolated fixture proof within the timebox; split/re-scope rather than weaken controls. |
| Kill switch disables registration but leaves active processes running. | Medium / critical | Supervisor-level kill and process-tree test. | Cannot stop active work or revoke grants within agreed bound; no deployment. |

**Spike 1 overall kill criterion:** if the team cannot prove isolation/denial of host filesystem, shell and network for the declared target platform, retain only source analysis and tests; do not port a powerful execution adapter into production.

### Spike 2 risks

| Risk | Likelihood / impact | Mitigation | Kill / pause criterion |
|---|---|---|---|
| JARVIS already has partially overlapping durable orchestration that is not yet understood. | High / high | Complete DR-01 module/store map before adding state storage. | Cannot identify a canonical job/session authority; pause implementation to resolve ownership. |
| Store cannot atomically enforce lease ownership and state transitions. | Unknown / critical | Characterize store guarantees; use transactions/CAS or redesign lease semantics. | Stale workers can commit after takeover and no feasible fencing design exists; do not enable multi-worker recovery. |
| External side effects cannot be queried or idempotently retried. | High / high | Effect ledger and `NEEDS_REVIEW` terminal path; adapter-specific idempotency contracts. | Any ambiguous effect gets blindly retried; disable that action class. |
| Checkpoint contains secrets, stale grants or prompt-injected instructions. | Medium / high | Minimize serialized context, encrypt/retain appropriately, revalidate permissions and digests. | Resume can bypass current policy or leak secrets; block resume for affected task type. |
| Retry/recovery loop creates runaway workers/cost. | Medium / high | Parent budget, depth/attempt/concurrency caps, backoff and circuit breakers. | Budget can be exceeded without a hard enforcement point; no unattended mode. |
| Crash matrix too narrow to expose race conditions. | Medium / high | Systematic injection before/after all durable writes and side effects. | Not enough evidence to establish crash consistency; keep in experimental-only mode. |

**Spike 2 overall kill criterion:** if state store consistency, lease fencing or side-effect reconciliation cannot be demonstrated, do not enable multi-worker autonomous recovery. Keep durable sessions limited to deterministic, safe-to-repeat work until those invariants are solved.

---

## 10. Recommended actions for the human team

### Restore

1. Acquire exact upstream checkouts/snapshots for all five sources at immutable commits, including license/notice files, manifests/lockfiles, scripts, submodules/LFS, generated inputs and relevant binaries.
2. Record current JARVIS commit/checksum, Python/dependency lock state, OS, runtime versions and the actual current baseline results.
3. Produce the SBOM and license/provenance ledger; mark every source component as `approved`, `review required`, `reference only`, or `prohibited` until resolved.

### Measure

1. Capture a clean baseline: `python -m compileall -q .`, complete current pytest suite, doctor, linter/type checks, packaging and startup/GUI smoke tests. Preserve outputs and environment.
2. Measure tool execution startup latency, overhead, memory, CPU and termination behavior for the isolated fixture adapter. Define maximum acceptable costs before choosing sandbox backend.
3. Measure durable-store transaction/atomicity guarantees and run a simple concurrent-claim test before creating a lease implementation.
4. Label a small evaluation corpus for memory recall/context compression and a small deterministic multi-step task set for crash/replay validation.

### Prototype

1. Implement only the read-only fixture tool under Spike 1 with network and shell disabled.
2. Implement only one deterministic two-step job under Spike 2, with checkpoint/resume, a parent/child handoff and no external irreversible side effects.
3. Build shared negative-test fixtures for paths, shell injection, SSRF, secret leakage, stale leases and ambiguous effects.

### Test and decide

1. Review any failure as either a bug, a missing invariant, an unsupported platform capability or a license/source issue; do not simply loosen the policy to make tests pass.
2. Compare external algorithms against JARVIS's baseline using measurable tests; port only the behavior that demonstrably improves correctness, security, reliability or performance.
3. Require an explicit release review before changing any experimental feature flag from disabled to enabled in a user-facing build.

---

## 11. Appendices and source review shortlist

### A. Initial source-path review shortlist

These are concrete places to begin; exact dependency and API use must be confirmed in the restored source trees.

**JARVIS execution/security:**
- `core/tool_fabric/impl.py`
- `core/tool_composition.py`
- `core/schemas/tool_manifest_v1.schema.json`
- `core/schemas/tool_invocation_request_v1.schema.json`
- `core/schemas/tool_invocation_result_v1.schema.json`
- `core/schemas/tool_side_effect_v1.schema.json`
- `core/policy_gateway.py`, `core/permission_engine.py`, `core/network_policy.py`
- `security/os_sandbox.py`, `security/sandbox.py`, `security/sandbox_profiles.py`, `security/windows_job.py`, `security/worker_identity.py`
- `super_agent/sandbox/runner.py`, `super_agent/tools/registry.py`

**DeepSeek Harness:**
- `packages/core/tools/src/index.ts`, `schema.ts`, `json-schema.ts`
- `packages/sandbox/sandbox/src/index.ts`, `sandbox-local/src/index.ts`, `sandbox-policy/src/index.ts`
- `packages/fs/fs-local/src/fsio.ts`, `packages/fs/fs-sandbox/src/containment.ts`
- `packages/shell/bash-sandbox/src/index.ts`, `packages/shell/pwsh-sandbox/src/index.ts`
- `packages/subprocess/subprocess/src/index.ts`
- `packages/credentials/authorization/src/index.ts`, `packages/credentials/credentials-local/src/index.ts`
- `packages/session/*`, `packages/jobs/jobs-local/src/*`, `packages/subagent/subagent/src/*`
- `packages/goal/goal/src/*`, `packages/plan/plan-mode/src/index.ts`, `packages/workflow/workflow/src/*`

**Prime Agent:**
- `packages/coding-agent/src/modes/daemon/daemon-supervisor.ts`
- `packages/coding-agent/src/modes/daemon/daemon-supervisor-ownership.ts`
- `packages/coding-agent/src/modes/daemon/daemon-worker-client.ts`
- `packages/coding-agent/src/modes/daemon/daemon-worker-protocol.ts`
- `packages/coding-agent/src/modes/daemon/worker-recovery-journal.ts`
- `packages/coding-agent/src/core/session-lease.ts`
- `packages/coding-agent/src/cli/owned-session-worker.ts`

**Hermes Agent:**
- `agent/memory_manager.py`, `agent/memory_provider.py`
- `agent/context_compressor.py`, `agent/context_compressor_prellm.py`
- `tools/session_search_tool.py`
- `agent/provider_registry.py`, `agent/provider_base.py`, `agent/fallback_cooldown.py`
- Skill catalog/loader and gateway/platform adapters, reviewed as distinct features.

**REA:**
- `src/application/ElectronActiveEvidence.ts`
- `src/application/ElectronActiveObservationService.ts`
- `src/application/ProcessCaptureJournal.ts`, `ProcessCaptureLifecycle.ts`
- `src/application/BrowserEvidence.ts`, `EvidenceBundleCommands.ts`
- `src/artifacts/*`, `src/replay/*`, `src/ghidra/*`, `src/hopper/*`

**Moli Browser:**
- `moli-url-policy/src/route.rs`, `scheme.rs`
- `moli-fetch/src/client.rs`, `dns.rs`, `config.rs`
- `moli-browser-profile/src/profile.rs`, `profile_lock.rs`, `profile_manifest.rs`, `identity.rs`
- `moli-cookie-store/src/cookie.rs`
- `moli-protocol-cdp/src/wire.rs`
- `moli-protocol-webdriver-classic/src/actions.rs`
- `moli-protocol-webdriver-bidi/src/commands.rs`, `network.rs`
- `moli-html2md/src/machine.rs`
- `moli-renderer-v8/src/*` only for later sidecar evaluation.

### B. What this plan does not claim

- It does not certify that any external project is secure, superior or buildable from the reconstructed dump.
- It does not claim all 8,180,283 physical lines are production code. Test/fixture shares are path-based estimates.
- It does not prove all original files or repository metadata are present.
- It does not provide legal clearance for redistribution.
- It does not indicate that an external project has been merged or that the JARVIS runtime has been modified.
- It does not claim a sandbox can be absolutely escape-proof; the plan requires named platform controls, explicit limitations, adversarial validation and a fail-closed release policy.

## 12. One-page executive summary

### Decision
Proceed with two narrow, security-first prototypes. **Do not merge repositories wholesale.** Use existing JARVIS module contracts as the primary architecture and import only selected, tested capabilities through adapters. The first workbench reconstructed all entries represented in the aggregate source dump, but the correct next unit of work is a verified behavior and invariant—not another bulk extraction.

### Why these two first
Execution controls define what an agent is allowed to do; durable task semantics define what happens when it crashes, is cancelled, or retries. Without those controls, adding more research, memory, browser and skill capabilities compounds risk. Therefore:

1. **Spike 1 — Execution Fabric:** prove a single read-only adapter runs outside the privileged JARVIS core, behind a canonical policy decision, in a constrained and killable child process, with complete redacted audit/provenance.
2. **Spike 2 — Persistent agents:** prove a bounded job can be claimed once per lease generation, checkpointed, resumed after process failure, cancelled with its descendants and routed to review rather than duplicating unknown side effects.

### Architecture decision
Keep `JARVISCore`, `core/tool_fabric`, policy/permission services, `security/*`, mission/recovery/scheduler modules, memory/RAG, and `core/provenance_graph.py` authoritative. Compare existing implementations before creating new interfaces. Potential source donors include DeepSeek's typed tools/sandbox/session/job packages; Prime's daemon/supervisor/lease/worker lifecycle; Hermes' memory/context/skills/providers; REA's evidence/replay/application-analysis services; and Moli's URL policy, browser profile, protocols and extraction. The Moli Rust/V8 engine is a later sidecar candidate only.

### Hard gates
- No imported runtime in the privileged core by default.
- No shell, credential, host filesystem or network capability by default.
- Fail closed when required isolation is unavailable.
- License/source revision unknown means reference-only, not redistribution or activation.
- Ambiguous external side effect means `NEEDS_REVIEW`, never blind retry.
- Existing JARVIS compilation/tests/doctor/UI must pass with experimental flags off.

### Planning estimates
Use five engineering days each for the first two spikes, not as release deadlines. Follow-on implementation is roughly **55–65 points for the initial execution boundary** and **58 points for durable-agent hardening** under the assumptions in Section 8; team capacity, source restoration and OS-specific sandbox constraints may materially change that estimate. Start implementation tickets only after the upstream artifacts and JARVIS baseline are pinned.

### Immediate next move
Restore revisions/manifests/licenses; establish the clean baseline; review JARVIS's actual sandbox/tool/policy and mission/durability code; then prototype a fixture-only tool and one crash-recoverable deterministic job. This is the smallest proof that will reveal whether the architecture and target OS can satisfy the security and durability promises before more capabilities are activated.

---

## 13. Next 7-day action plan — 15–21 October 2026

| Day | Goal | Concrete outputs | Gate / decision |
|---|---|---|---|
| **Thu 15 Oct** | Freeze the baseline and source identity. | JARVIS commit/checksum; five upstream revision requests; missing-artifact register; baseline test command list. | If the baseline cannot be identified, no implementation branch is opened. |
| **Fri 16 Oct** | Restore manifests and license/provenance data. | Repository/commit map; licenses/notices; package manifests/lockfiles; first SBOM and unresolved-license list. | Unknown or incompatible license keeps component reference-only. |
| **Sat 17 Oct** | Map JARVIS security execution path. | Call graph from `JARVISCore` to tool registry, policy gateway, sandbox, OS process runner, audit and UI; Windows isolation capability probe. | Confirm whether mandatory isolation can be enforced or identify the backend gap. |
| **Sun 18 Oct** | Map JARVIS durable runtime and design contracts. | Mission/task scheduler/store map; allowed state transitions; proposed execution/job schemas and threat model reviewed. | No second registry/store/scheduler unless a documented gap is proven. |
| **Mon 19 Oct** | Prototype Spike 1 fixture adapter. | Flag-disabled-by-default adapter; child-process protocol; policy decision; bounded output; kill switch; first negative tests. | Any out-of-root access, secret exposure or fail-open behavior stops the spike. |
| **Tue 20 Oct** | Prototype Spike 2 lifecycle. | Deterministic two-step task; durable state/checkpoint; lease/fencing prototype; restart/cancel/handoff test harness. | No multi-worker mode if stale owner writes or ambiguous effects are not controlled. |
| **Wed 21 Oct** | Run review and choose next increments. | Spike reports; failing-test list; security review; estimates revised from measured evidence; go/no-go and rollback record. | Only verified and licensed slices move from experimental to implementation-ready. |

### End-of-week review package

The team should leave 21 October with a reproducible baseline, source/license provenance status, two small runnable prototypes, adversarial test output, a revised capability crosswalk, and explicit go/no-go decisions. It should **not** expect every external capability to be integrated in seven days; the objective is to prove the safest integration path and expose the blocking unknowns early.

---


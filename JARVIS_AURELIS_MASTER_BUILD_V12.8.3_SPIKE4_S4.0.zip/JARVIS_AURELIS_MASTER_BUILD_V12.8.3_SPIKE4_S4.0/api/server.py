"""FastAPI server for JARVIS with authentication, rate limiting, and MCP.

Endpoints:
  GET  /health          — Health check
  POST /chat            — Chat completion
  GET  /models          — List available models
  GET  /tools           — List registered tools
  POST /tools/execute   — Execute a tool
  POST /ingest          — Ingest a document
  GET  /sessions        — List sessions
  POST /sessions/clear  — Clear a session
  GET  /mcp             — MCP tool listing
  POST /mcp/call        — MCP tool execution
"""
from __future__ import annotations

import asyncio
import base64
from concurrent.futures import Future
from collections import OrderedDict, deque
import hashlib
import hmac
import json
import logging
import os
import pathlib
import threading
import time
import uuid
from typing import Any, ClassVar, Optional

from fastapi import FastAPI, HTTPException, Depends, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, field_validator

from core.tracing import set_request_id, set_session_id

# Global reference to JARVISCore — set by configure_core()
_core: Optional[Any] = None
logger = logging.getLogger("jarvis.api")
_rate_limit_lock = threading.Lock()

_DOCS_ENABLED = os.environ.get("JARVIS_API_DOCS", "").strip().lower() in {"1", "true", "yes", "on"}
app = FastAPI(
    title="JARVIS API",
    version="12.8.3",
    docs_url="/docs" if _DOCS_ENABLED else None,
    redoc_url="/redoc" if _DOCS_ENABLED else None,
)

# CORS — restrictive defaults, credentials only for known origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID", "X-Session-ID"],
)

# Security
security = HTTPBearer(auto_error=False)

# Bounded in-memory rate limiter (per-IP + per-token).
_rate_limit_store: OrderedDict[str, deque[float]] = OrderedDict()
_token_rate_limit_store: OrderedDict[str, deque[float]] = OrderedDict()
RATE_LIMIT_IP = 60       # requests per minute per IP
RATE_LIMIT_TOKEN = 120   # requests per minute per token
RATE_LIMIT_WINDOW_SECONDS = 60.0
RATE_LIMIT_MAX_KEYS = 10_000
RATE_LIMIT_SWEEP_INTERVAL = 256
_rate_limit_operations = 0
CHAT_TIMEOUT_SECONDS = 60.0


# =================================================================
# Safe path validation
# =================================================================
class SafePathValidator:
    """Validate paths and, when a root is supplied, enforce root containment."""

    MAX_PATH_LENGTH = 4096
    FORBIDDEN_CHARS: ClassVar[set[str]] = {"\x00", "\n", "\r"}

    @classmethod
    def _validate_syntax(cls, v: str) -> str:
        if not v or len(v) > cls.MAX_PATH_LENGTH:
            raise ValueError("path empty or too long")
        if any(c in v for c in cls.FORBIDDEN_CHARS):
            raise ValueError("path contains forbidden characters")
        return v

    @classmethod
    def validate(cls, v: str, *, allowed_root: str | pathlib.Path) -> str:
        """Resolve a path and require it to remain inside the configured root."""
        value = cls._validate_syntax(v)
        try:
            root = pathlib.Path(allowed_root).expanduser().resolve(strict=False)
            candidate = pathlib.Path(value)
            if not candidate.is_absolute():
                candidate = root / candidate
            resolved = candidate.resolve(strict=False)
        except OSError as exc:
            raise ValueError(f"path resolution failed: {exc}") from exc
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise ValueError("path escapes configured workspace") from exc
        return str(resolved)


# =================================================================
# Dependency injection
# =================================================================
def get_core() -> Any:
    if _core is None:
        raise HTTPException(status_code=503, detail="JARVIS core not initialized")
    return _core


def verify_token(request: Request, credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Verify bearer token; development may use loopback without a token."""
    expected = os.environ.get("JARVIS_API_TOKEN", "")
    environment = os.environ.get("JARVIS_ENV", "development").strip().lower()
    client_ip = request.client.host if request.client else "unknown"
    if not expected:
        if environment in {"production", "prod"}:
            raise HTTPException(status_code=503, detail="JARVIS_API_TOKEN must be configured in production")
        trusted_loopback = {"127.0.0.1", "::1", "localhost"}
        if client_ip == "testclient":
            trusted_loopback.add("testclient")
        if client_ip not in trusted_loopback:
            raise HTTPException(status_code=401, detail="API token required for non-loopback access")
        return "dev"
    if not credentials:
        raise HTTPException(status_code=401, detail="Missing authorization header")
    if not hmac.compare_digest(credentials.credentials, expected):
        raise HTTPException(status_code=403, detail="Invalid token")
    return credentials.credentials


def _rate_window(store: OrderedDict[str, deque[float]], key: str, now: float) -> deque[float]:
    """Return a bounded, recently-used request window for one limiter key."""
    global _rate_limit_operations
    _rate_limit_operations += 1
    if key in store:
        window = store.pop(key)
        store[key] = window
    else:
        window = deque()
        if len(store) >= RATE_LIMIT_MAX_KEYS:
            store.popitem(last=False)
        store[key] = window
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    while window and window[0] <= cutoff:
        window.popleft()
    if _rate_limit_operations % RATE_LIMIT_SWEEP_INTERVAL == 0:
        stale = [k for k, values in store.items() if not values or values[-1] <= now - RATE_LIMIT_WINDOW_SECONDS - 3600.0]
        for stale_key in stale:
            store.pop(stale_key, None)
    return window


def rate_limit(request: Request, token: str = Depends(verify_token)) -> None:
    """Dual bounded rate limiter: per-IP and per-token buckets."""
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    with _rate_limit_lock:
        ip_window = _rate_window(_rate_limit_store, client_ip, now)
        if len(ip_window) >= RATE_LIMIT_IP:
            raise HTTPException(status_code=429, detail="Rate limit exceeded (IP)")
        ip_window.append(now)

        token_key = hashlib.sha256(token.encode("utf-8")).hexdigest()
        token_window = _rate_window(_token_rate_limit_store, token_key, now)
        if len(token_window) >= RATE_LIMIT_TOKEN:
            raise HTTPException(status_code=429, detail="Rate limit exceeded (token)")
        token_window.append(now)


@app.middleware("http")
async def request_context_middleware(request: Request, call_next):
    """Attach a request correlation ID and propagate via ContextVar."""
    request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex
    request.state.request_id = request_id
    set_request_id(request_id)
    set_session_id(request.headers.get("X-Session-ID", "default"))
    try:
        response = await call_next(request)
    except Exception:
        logger.exception("api_request_failed", extra={"request_id": request_id, "path": request.url.path})
        raise
    response.headers["X-Request-ID"] = request_id
    return response


# =================================================================
# Pydantic models
# =================================================================
class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=50000)
    session_id: str = Field(default="default", max_length=256)
    stream: bool = False
    task_type: str = Field(default="default", max_length=64)


class ChatResponse(BaseModel):
    response: str
    session_id: str
    model: Optional[str] = None


class ToolExecuteRequest(BaseModel):
    tool: str = Field(..., min_length=1)
    arguments: dict = Field(default_factory=dict)
    approval_token: Optional[str] = None


class ToolExecuteResponse(BaseModel):
    ok: bool
    result: Any = None
    error: Optional[str] = None


class IngestRequest(BaseModel):
    file_path: str = Field(..., min_length=1)

    @field_validator("file_path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        return SafePathValidator._validate_syntax(v)


class IngestResponse(BaseModel):
    file: str
    chunks: int
    embedded: int
    vector_search: bool


class WebAuthnBeginRequest(BaseModel):
    operator_id: str = Field(..., min_length=1, max_length=128)
    purpose: str = Field(default="control", min_length=1, max_length=64)


class WebAuthnVerifyRequest(BaseModel):
    challenge_id: str = Field(..., min_length=1, max_length=128)
    credential_id: str = Field(..., min_length=1, max_length=256)
    signature_der_b64: str = Field(..., min_length=1, max_length=8192)
    client_data_json_b64: str = Field(..., min_length=1, max_length=16384)
    authenticator_data_b64: str = Field(..., min_length=37, max_length=8192)
    operator_id: str = Field(..., min_length=1, max_length=128)
    origin: str | None = Field(default=None, max_length=512)


class SessionListResponse(BaseModel):
    sessions: list[str]


class MCPRequest(BaseModel):
    jsonrpc: str = "2.0"
    id: Any = None
    method: str
    params: dict = Field(default_factory=dict)


class MCPResponse(BaseModel):
    jsonrpc: str = "2.0"
    id: Any = None
    result: Any = None
    error: Optional[dict] = None


class WorkerRegistration(BaseModel):
    worker_id: str = Field(..., min_length=1, max_length=128)
    capabilities: list[str] = Field(..., min_length=1, max_length=64)
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkerHeartbeat(BaseModel):
    worker_id: str = Field(..., min_length=1, max_length=128)
    active_tasks: int = Field(default=0, ge=0, le=1024)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SettingUpdateRequest(BaseModel):
    key: str = Field(..., min_length=1, max_length=512)
    value: Any
    persist: bool = True


class AutopilotAuthorizeRequest(BaseModel):
    approval_token: str = Field(..., min_length=1, max_length=4096)
    reason: str = Field(default="authorized autonomous operation", max_length=1000)
    capabilities: list[str] = Field(default_factory=list, max_length=128)
    webauthn_challenge_id: str | None = Field(default=None, min_length=1, max_length=128)
    operator_id: str | None = Field(default=None, min_length=1, max_length=128)


class LongTermWorkerRequest(BaseModel):
    role: str = Field(..., min_length=1, max_length=128)
    objective: str = Field(..., min_length=1, max_length=5000)
    interval_seconds: float = Field(default=30.0, ge=0.1, le=3600.0)



class DistributedTaskRequest(BaseModel):
    task_id: str = Field(..., min_length=1, max_length=128)
    mission_id: str = Field(..., min_length=1, max_length=128)
    capability: str = Field(..., min_length=1, max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)
    issued_at: float
    expires_at: float
    nonce: str = Field(..., min_length=16, max_length=128)
    signature: str = Field(..., min_length=64, max_length=128)


# =================================================================
# Health
# =================================================================
@app.get("/health", tags=["system"])
def health() -> dict:
    """Liveness endpoint that does not require a fully initialized core."""
    return {
        "status": "ok",
        "version": "12.8.3",
        "core_ready": _core is not None,
    }


@app.get("/ready", tags=["system"])
def ready(token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    """Readiness endpoint using HealthProbeRegistry."""
    registry = getattr(core, "health_registry", None)
    if registry is not None and registry.has_probes():
        result = registry.readiness()
        if not result["healthy"]:
            raise HTTPException(status_code=503, detail=result)
        return {"status": result["status"], "version": getattr(core, "version", "unknown"), "probes": result["probes"]}

    snapshot = core.health() if hasattr(core, "health") else {"overall": "healthy"}
    ready_state = snapshot.get("overall") in {"healthy", "degraded"}
    if not ready_state:
        raise HTTPException(status_code=503, detail="JARVIS core is not ready")
    return {"status": "ready", "version": getattr(core, "version", "unknown"), "health": snapshot}


@app.get("/health/supreme", tags=["system"])
def health_supreme(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return the autonomous, temporal, memory, cluster, and supply-chain fabric snapshot."""
    return {
        "version": getattr(core, "version", "unknown"),
        "autonomy": core.autonomy_engine.snapshot(),
        "world": core.temporal_world.snapshot(),
        "memory_governance": core.memory_governance.stats(),
        "cluster": core.distributed_fabric.snapshot(),
        "evaluation": core.evaluation_lab.snapshot(),
        "supply_chain": core.supply_chain_auditor.sbom(),
        "computer_use": bool(getattr(core, "computer_use", None)),
        "distributed_queue": core.distributed_queue.stats(),
        "sandbox_profiles": [p.name for p in core.sandbox_profiles.list()],
        "world_reasoning": {"current_facts": len(core.world_reasoner.resolve("host"))},
        "planner": {"max_steps": core.long_horizon_planner.max_steps},
        "model_server": core.model_server.snapshot(),
        "memory_migration": {"snapshot_root": str(core.memory_migration.root)},
        "multimodal_stream": {"cancelled": False},
        "slo": core.slo.snapshot(),
        "target_machine": core.target_machine_certification.run(),
        "distributed_transport": core.distributed_transport.snapshot(),
        "mtls": core.mtls_identity.snapshot(),
        "agent_reputation": core.agent_reputation.snapshot(),
        "skill_manifests": core.skill_manifests.snapshot(),
        "digital_twin": core.system_digital_twin.snapshot(),
        "cognitive_loop": {"available": hasattr(core, "cognitive_loop")},
    }


@app.post("/security/webauthn/begin", tags=["security"])
def webauthn_begin(req: WebAuthnBeginRequest, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Start an explicit WebAuthn step-up ceremony."""
    fabric = getattr(core, "nextgen", None)
    control = getattr(fabric, "webauthn", None)
    if control is None:
        raise HTTPException(status_code=503, detail="WebAuthn control plane unavailable")
    authenticated_operator = _owner_id(token)
    if req.operator_id != authenticated_operator:
        raise HTTPException(status_code=403, detail="operator does not match authenticated API identity")
    challenge = control.begin(authenticated_operator, purpose=req.purpose)
    return {"challenge_id": challenge.challenge_id, "challenge": challenge.challenge, "expires_at": challenge.expires_at, "purpose": challenge.purpose}


@app.post("/security/webauthn/verify", tags=["security"])
def webauthn_verify(req: WebAuthnVerifyRequest, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Verify a WebAuthn assertion and atomically consume the ceremony."""
    fabric = getattr(core, "nextgen", None)
    control = getattr(fabric, "webauthn", None)
    if control is None:
        raise HTTPException(status_code=503, detail="WebAuthn control plane unavailable")
    authenticated_operator = _owner_id(token)
    if req.operator_id != authenticated_operator:
        raise HTTPException(status_code=403, detail="operator does not match authenticated API identity")
    try:
        ok = control.verify_assertion(
            req.challenge_id, req.credential_id, base64.b64decode(req.signature_der_b64, validate=True),
            client_data_json=base64.b64decode(req.client_data_json_b64, validate=True),
            authenticator_data=base64.b64decode(req.authenticator_data_b64, validate=True),
            operator_id=authenticated_operator, origin=req.origin,
        )
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail="invalid WebAuthn encoding") from exc
    if not ok:
        raise HTTPException(status_code=403, detail="WebAuthn verification failed")
    return {"ok": True, "challenge_id": req.challenge_id, "operator_id": req.operator_id}


@app.get("/frontier", tags=["system"])
def frontier(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return the integrated frontier identity, mission, task, cache, and privacy state."""
    fabric = getattr(core, "frontier", None)
    if fabric is None:
        raise HTTPException(status_code=503, detail="Frontier fabric not initialized")
    return {"version": getattr(core, "version", "unknown"), "frontier": fabric.health()}


@app.get("/health/deep", tags=["system"])
def health_deep(token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    """Comprehensive health check of all subsystems."""
    registry = getattr(core, "health_registry", None)
    if registry is None:
        raise HTTPException(status_code=503, detail="Health registry not initialized")
    return registry.deep_check()


@app.get("/metrics", tags=["system"])
def metrics(token: str = Depends(verify_token)) -> PlainTextResponse:
    """Prometheus-compatible metrics including application and health metrics."""
    lines: list[str] = []
    registry = getattr(_core, "health_registry", None)
    if registry is not None:
        lines.append(registry.prometheus_metrics())
    collector = getattr(_core, "metrics", None)
    if collector is not None:
        lines.append(collector.prometheus_metrics())
    ledger = getattr(_core, "token_ledger", None)
    if ledger is not None:
        stats = ledger.global_stats()
        lines.append(
            "# HELP jarvis_tokens_total Total tokens consumed across all sessions.\n"
            "# TYPE jarvis_tokens_total counter\n"
            f"jarvis_tokens_total {stats['total_tokens']}\n"
            "# HELP jarvis_token_cost_usd_total Estimated cost in USD across all sessions.\n"
            "# TYPE jarvis_token_cost_usd_total counter\n"
            f"jarvis_token_cost_usd_total {stats['cost_usd']}\n"
            "# HELP jarvis_inference_calls_total Total inference calls recorded.\n"
            "# TYPE jarvis_inference_calls_total counter\n"
            f"jarvis_inference_calls_total {stats['total_calls']}"
        )
    if not lines:
        raise HTTPException(status_code=503, detail="Metrics not initialized")
    return PlainTextResponse(content="\n".join(lines), media_type="text/plain")


@app.get("/accounting", tags=["system"])
def accounting(
    session_id: str | None = None,
    token: str = Depends(verify_token),
) -> dict[str, Any]:
    """Return global accounting, optionally scoped to one authenticated session."""
    ledger = getattr(_core, "token_ledger", None)
    if ledger is None:
        raise HTTPException(status_code=503, detail="Token ledger not initialized")
    snapshot = ledger.health()
    if session_id is not None:
        if not session_id or len(session_id) > 256:
            raise HTTPException(status_code=422, detail="invalid session_id")
        owner_session = f"{_owner_id(token)}:{session_id}"
        scoped = ledger.session_stats(owner_session)
        if scoped is None:
            raise HTTPException(status_code=404, detail="Session accounting not found")
        snapshot["session"] = scoped
    return snapshot


# =================================================================
# Distributed worker fabric
# =================================================================
@app.post("/cluster/workers/register", tags=["cluster"])
def register_worker(req: WorkerRegistration, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Register a worker lease with the authenticated JARVIS coordinator."""
    lease = core.distributed_fabric.register_worker(req.worker_id, tuple(req.capabilities), req.metadata)
    return {"ok": True, "worker_id": lease.worker_id, "capabilities": list(lease.capabilities)}


@app.post("/cluster/workers/heartbeat", tags=["cluster"])
def heartbeat_worker(req: WorkerHeartbeat, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Refresh a worker lease."""
    return {"ok": core.distributed_fabric.heartbeat(req.worker_id, active_tasks=req.active_tasks, metadata=req.metadata)}


@app.post("/cluster/tasks", tags=["cluster"])
def execute_distributed_task(req: DistributedTaskRequest, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Verify a signed remote task and execute only through the local tool gateway."""
    from core.distributed_fabric import TaskEnvelope
    envelope = TaskEnvelope(**req.model_dump())
    if not core.distributed_fabric.verify_task(envelope):
        raise HTTPException(status_code=401, detail="invalid or expired task envelope")
    if envelope.capability.startswith(("code.", "process.", "system.")):
        raise HTTPException(status_code=403, detail="remote direct execution capability denied")
    tool = str(envelope.payload.get("tool", "")).strip()
    arguments = envelope.payload.get("arguments", {})
    if not tool or not isinstance(arguments, dict):
        raise HTTPException(status_code=422, detail="remote task requires tool and object arguments")
    try:
        result = core.registry.execute(tool, arguments, None)
        return result if isinstance(result, dict) else {"ok": True, "result": result}
    except Exception:
        logger.exception("distributed_task_failed", extra={"task_id": envelope.task_id})
        raise HTTPException(status_code=500, detail="distributed task failed")


# =================================================================
# Chat
# =================================================================
async def _stream_core_chat(core: Any, message: str, *, task_type: str, session_id: str, owner: str = "jarvis"):
    """Iterate a synchronous JARVIS stream without blocking the asyncio event loop."""
    iterator = await asyncio.to_thread(core.chat, message, stream=True, task_type=task_type, session_id=session_id)
    if isinstance(iterator, str):
        yield iterator
        return
    next_item = getattr(__builtins__, "next", next)
    while True:
        item = await asyncio.to_thread(lambda: next_item(iterator, None))
        if item is None:
            break
        text = getattr(item, "text", item)
        if text is not None:
            yield str(text)


@app.post("/chat", response_model=None, tags=["chat"])
async def chat(
    request: Request,
    req: ChatRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> ChatResponse:
    """Send a chat message to JARVIS with bounded execution time."""
    request_id = getattr(request.state, "request_id", None)
    owner = _owner_id(token)
    owner_session = f"{owner}:{req.session_id}"
    if req.stream:
        async def event_stream():
            started = time.perf_counter()
            try:
                async with asyncio.timeout(CHAT_TIMEOUT_SECONDS):
                    async for chunk in _stream_core_chat(core, req.message, task_type=req.task_type, session_id=owner_session):
                        payload = json.dumps({"text": chunk}, ensure_ascii=False)
                        yield f"event: delta\ndata: {payload}\n\n"
                yield "event: done\ndata: {}\n\n"
            except TimeoutError:
                yield 'event: error\ndata: {"error":"Chat request timed out"}\n\n'
            except Exception:
                logger.exception("chat_stream_failed", extra={"request_id": request_id})
                yield 'event: error\ndata: {"error":"Internal server error"}\n\n'
            finally:
                logger.debug("chat_stream_finished", extra={"request_id": request_id, "latency_ms": round((time.perf_counter() - started) * 1000, 2)})
        return StreamingResponse(event_stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
    work = asyncio.to_thread(
        core.chat, req.message, stream=False, task_type=req.task_type, session_id=owner_session, owner=owner
    )
    try:
        result = await asyncio.wait_for(work, timeout=CHAT_TIMEOUT_SECONDS)
        text = result if isinstance(result, str) else str(result)
        model = core.router.primary.name if core.router.primary else None
        return ChatResponse(response=text, session_id=req.session_id, model=model)
    except asyncio.TimeoutError:
        if hasattr(work, "close"):
            work.close()
        logger.warning("chat_request_timeout", extra={"request_id": request_id, "session": req.session_id})
        raise HTTPException(status_code=504, detail="Chat request timed out")
    except Exception:
        if hasattr(work, "close"):
            work.close()
        logger.exception("chat_request_failed", extra={"request_id": request_id})
        raise HTTPException(status_code=500, detail="Internal server error")


# =================================================================
# Models
# =================================================================
@app.get("/cognitive/control-plane", tags=["intelligence"])
def cognitive_control_plane(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return the integrated cognitive control-plane snapshot."""
    if core is None or not hasattr(core, "cognitive_control_plane"):
        raise HTTPException(status_code=503, detail="cognitive control plane unavailable")
    return core.cognitive_control_plane.snapshot()


@app.get("/platform/frontier", tags=["system"])
def platform_frontier(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return target-independent platform frontier capabilities and hardware evidence."""
    fabric = getattr(core, "platform_frontier", None)
    if fabric is None:
        raise HTTPException(status_code=503, detail="platform frontier unavailable")
    attestation = fabric["attestor"].collect()
    health = fabric["hardware"].snapshot()
    supervisor = fabric["native_supervisor"].probe()
    return {
        "attestation": {"platform": attestation.platform, "provider": attestation.provider, "available": attestation.available, "trusted": attestation.trusted, "evidence": dict(attestation.evidence), "reason": attestation.reason},
        "hardware": {"platform": health.platform, "architecture": health.architecture, "cpu_count": health.cpu_count, "memory_total_mb": health.memory_total_mb, "memory_available_mb": health.memory_available_mb, "load_percent": health.load_percent, "gpu_hint": health.gpu_hint},
        "native_runtime": {"name": supervisor.name, "state": supervisor.state, "consecutive_failures": supervisor.consecutive_failures, "latency_ms": supervisor.last_latency_ms, "detail": supervisor.detail},
        "prefix_cache": fabric["prefix_cache"].snapshot(),
    }


@app.get("/runtimes", tags=["system"])
def list_runtimes(
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> dict[str, object]:
    """Return the authoritative polyglot runtime manifest and health state."""
    registry = getattr(core, "polyglot_runtimes", None)
    if registry is None:
        raise HTTPException(status_code=503, detail="polyglot runtime registry not initialized")
    return {"manifest": registry.manifest(), "health": [item.to_dict() for item in registry.health()]}


@app.get("/platform/nextgen", tags=["system"])
def platform_nextgen(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return the integrated next-generation trust, protocol, inference and device fabric."""
    fabric = getattr(core, "nextgen", None)
    if fabric is None:
        raise HTTPException(status_code=503, detail="nextgen platform unavailable")
    return fabric.health()


@app.get("/settings", tags=["system"])
def get_settings(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return editable configuration metadata without exposing process secrets."""
    service = getattr(core, "settings_service", None)
    if service is None:
        raise HTTPException(status_code=503, detail="settings service unavailable")
    return service.metadata()


@app.put("/settings", tags=["system"])
def put_setting(req: SettingUpdateRequest, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Apply and optionally persist one runtime setting through the canonical settings service."""
    service = getattr(core, "settings_service", None)
    if service is None:
        raise HTTPException(status_code=503, detail="settings service unavailable")
    try:
        change = service.set(req.key, req.value)
        if req.persist and not service.save():
            raise RuntimeError("settings persistence failed")
        return {"ok": True, **change, "persisted": bool(req.persist)}
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/autopilot", tags=["autonomy"])
def autopilot_status(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return bounded autopilot status."""
    autopilot = getattr(core, "autopilot", None)
    if autopilot is None:
        raise HTTPException(status_code=503, detail="autopilot unavailable")
    return autopilot.status()


@app.post("/autopilot/authorize", tags=["autonomy"])
def autopilot_authorize(req: AutopilotAuthorizeRequest, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Authorize a bounded human-approval override using an explicit capability grant."""
    autopilot = getattr(core, "autopilot", None)
    if autopilot is None:
        raise HTTPException(status_code=503, detail="autopilot unavailable")
    try:
        step_up_verified = False
        if req.webauthn_challenge_id:
            fabric = getattr(core, "nextgen", None)
            control = getattr(fabric, "webauthn", None)
            authenticated_operator = _owner_id(token)
            if req.operator_id != authenticated_operator:
                raise PermissionError("WebAuthn operator does not match authenticated API identity")
            if control is None or not control.consume_authorization(req.webauthn_challenge_id, operator_id=authenticated_operator, purpose="autopilot"):
                raise PermissionError("invalid or expired WebAuthn step-up authorization")
            step_up_verified = True
        session = autopilot.authorize(req.approval_token, reason=req.reason, capabilities=tuple(req.capabilities), step_up_verified=step_up_verified)
        return {"ok": True, "session": {"session_id": session.session_id, "expires_at": session.expires_at, "capabilities": list(session.capabilities)}}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


@app.post("/autopilot/stop", tags=["autonomy"])
def autopilot_stop(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Stop and revoke the active autopilot session."""
    autopilot = getattr(core, "autopilot", None)
    if autopilot is None:
        raise HTTPException(status_code=503, detail="autopilot unavailable")
    autopilot.stop()
    return {"ok": True, "status": autopilot.status()}


@app.get("/workers/long-term", tags=["autonomy"])
def long_term_workers(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Return persistent agent worker state."""
    manager = getattr(core, "long_term_workers", None)
    if manager is None:
        raise HTTPException(status_code=503, detail="long-term workers unavailable")
    return manager.snapshot()


@app.post("/workers/long-term", tags=["autonomy"])
def create_long_term_worker(req: LongTermWorkerRequest, authorization: str | None = None, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Register and start a bounded persistent agent worker after autopilot authorization."""
    manager = getattr(core, "long_term_workers", None)
    autopilot = getattr(core, "autopilot", None)
    if manager is None or autopilot is None:
        raise HTTPException(status_code=503, detail="long-term worker system unavailable")
    if not autopilot.authorize_action("autonomy.worker.start"):
        raise HTTPException(status_code=403, detail="authorized autopilot session required for long-term workers")
    try:
        spec = manager.register(req.role, req.objective, lambda worker, cycle: core.autonomous_executive.trigger(worker.objective, priority=70, source=f"long-term:{worker.worker_id}"), interval_seconds=req.interval_seconds)
        state = manager.start(spec.worker_id)
        return {"ok": True, "worker": {"worker_id": spec.worker_id, "role": spec.role, "objective": spec.objective, "status": state.status}}
    except (KeyError, ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/workers/long-term/{worker_id}/stop", tags=["autonomy"])
def stop_long_term_worker(worker_id: str, token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Stop one persistent worker through the canonical lifecycle manager."""
    manager = getattr(core, "long_term_workers", None)
    if manager is None:
        raise HTTPException(status_code=503, detail="long-term workers unavailable")
    try:
        state = manager.stop(worker_id)
        return {"ok": True, "worker": state.__dict__ if hasattr(state, "__dict__") else {
            "worker_id": state.worker_id,
            "role": state.role,
            "status": state.status,
            "cycles": state.cycles,
            "started_at": state.started_at,
            "last_heartbeat": state.last_heartbeat,
            "last_error": state.last_error,
        }}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="worker not found") from exc


@app.post("/workers/long-term/stop-all", tags=["autonomy"])
def stop_all_long_term_workers(token: str = Depends(verify_token), core=Depends(get_core)) -> dict[str, Any]:
    """Stop all persistent workers; the action is safe and idempotent."""
    manager = getattr(core, "long_term_workers", None)
    if manager is None:
        raise HTTPException(status_code=503, detail="long-term workers unavailable")
    manager.stop_all()
    return {"ok": True, "workers": manager.snapshot()}


@app.get("/models", tags=["models"])
def list_models(
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> list[dict]:
    """List available model backends."""
    backends = core.router.list_backends()
    primary = core.router.primary
    primary_name = primary.get("name") if isinstance(primary, dict) else getattr(primary, "name", None)
    return [
        {**item, "primary": item.get("name") == primary_name}
        for item in backends
    ]


# =================================================================
# Tools
# =================================================================
@app.get("/tools", tags=["tools"])
def list_tools(
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> list[dict]:
    """List registered tools."""
    return [
        {
            "name": t.name,
            "description": t.description,
            "risk": t.risk.name,
            "capabilities": t.capabilities,
        }
        for t in core.registry.list_tools()
    ]


@app.post("/tools/execute", response_model=ToolExecuteResponse, tags=["tools"])
def execute_tool(
    req: ToolExecuteRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> ToolExecuteResponse:
    """Execute a registered tool."""
    result = core.registry.execute(req.tool, req.arguments, req.approval_token)
    if isinstance(result, dict) and "ok" in result:
        return ToolExecuteResponse(**result)
    return ToolExecuteResponse(ok=True, result=result)


# =================================================================
# Document ingestion
# =================================================================
@app.post("/ingest", response_model=IngestResponse, tags=["memory"])
def ingest(
    req: IngestRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> IngestResponse:
    """Ingest a document into memory."""
    try:
        configured_workspace = getattr(core, "cfg", {}).get("workspace", "workspace")
        workspace = pathlib.Path(configured_workspace).expanduser().resolve()
        try:
            requested = pathlib.Path(SafePathValidator.validate(req.file_path, allowed_root=workspace))
        except ValueError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        if not requested.is_file():
            raise HTTPException(status_code=404, detail="document not found")
        max_bytes = int(getattr(core, "cfg", {}).get("ingestion", {}).get("max_file_bytes", 25_000_000))
        if requested.stat().st_size > max_bytes:
            raise HTTPException(status_code=413, detail="document exceeds configured size limit")
        result = core.ingest_document(str(requested), owner=_owner_id(token))
        return IngestResponse(**result)
    except HTTPException:
        raise
    except OSError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("document_ingest_failed")
        raise HTTPException(status_code=400, detail="document ingestion failed") from exc


# =================================================================
# Sessions
# =================================================================
@app.get("/sessions", response_model=SessionListResponse, tags=["memory"])
def list_sessions(
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> SessionListResponse:
    """List active sessions."""
    sessions = core.memory.list_sessions() if core.memory else []
    prefix = f"{_owner_id(token)}:"
    owned = [s[len(prefix):] for s in sessions if s.startswith(prefix)]
    return SessionListResponse(sessions=owned)


@app.post("/sessions/{session_id}/clear", tags=["memory"])
def clear_session(
    session_id: str,
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> dict:
    """Clear a session's history."""
    if core.memory:
        core.memory.clear_session(f"{_owner_id(token)}:{session_id}")
    return {"ok": True, "session_id": session_id}


# =================================================================
# MCP (Model Context Protocol) adapter
# =================================================================
@app.get("/mcp", tags=["mcp"])
def mcp_list(
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> dict:
    """List available tools in MCP format."""
    tools = core.registry.list_tools()
    return {
        "tools": [
            {
                "name": t.name,
                "description": t.description,
                "inputSchema": t.parameters,
            }
            for t in tools
        ]
    }


@app.post("/mcp/call", tags=["mcp"])
def mcp_call(
    req: MCPRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> MCPResponse:
    """Execute a tool via MCP JSON-RPC."""
    if req.method == "tools/list":
        tools = core.registry.list_tools()
        return MCPResponse(
            id=req.id,
            result={
                "tools": [
                    {
                        "name": t.name,
                        "description": t.description,
                        "inputSchema": t.parameters,
                    }
                    for t in tools
                ]
            },
        )
    elif req.method == "tools/call":
        tool_name = req.params.get("name")
        arguments = req.params.get("arguments", {})
        if not tool_name:
            return MCPResponse(
                id=req.id,
                error={"code": -32602, "message": "Missing tool name"},
            )
        result = core.registry.execute(tool_name, arguments, req.params.get("approval_token"))
        return MCPResponse(id=req.id, result={"content": [{"type": "text", "text": str(result)}]})
    else:
        return MCPResponse(
            id=req.id,
            error={"code": -32601, "message": f"Method not found: {req.method}"},
        )



# =================================================================
# Flutter Holo Command Deck WebSocket
# =================================================================
_HOLO_PROTOCOL_VERSION = 1
_HOLO_MAX_MESSAGE_BYTES = 256_000
_HOLO_CLIENT_LIMIT = 8
_HOLO_CLIENTS: set[WebSocket] = set()
_HOLO_CLIENT_LOCK = threading.Lock()
_HOLO_RATE_LIMIT = 120
_HOLO_RATE_WINDOW_SECONDS = 60.0
_HOLO_RATE_STATE: dict[str, list[float]] = {}
_HOLO_SENSITIVE_KEYS = {"token", "authorization", "api_key", "apikey", "secret", "password", "private_key", "approval_token", "execution_grant"}
_HOLO_PUBLIC_EVENT_PREFIXES = ("chat.", "mission.", "workflow.", "model.", "runtime.", "health.", "log.")


def _holo_client_allowed(host: str, token: str | None) -> bool:
    expected = os.environ.get("JARVIS_HOLO_TOKEN", os.environ.get("JARVIS_API_TOKEN", ""))
    if not expected and host in {"127.0.0.1", "::1", "localhost"}:
        return True
    return bool(expected and token and hmac.compare_digest(token, expected))


def _holo_rate_allowed(key: str) -> bool:
    """Apply a bounded per-client sliding-window rate limit."""
    now = time.monotonic()
    with _HOLO_CLIENT_LOCK:
        window = _HOLO_RATE_STATE.setdefault(key, [])
        cutoff = now - _HOLO_RATE_WINDOW_SECONDS
        window[:] = [value for value in window if value >= cutoff]
        if len(window) >= _HOLO_RATE_LIMIT:
            return False
        window.append(now)
        if len(_HOLO_RATE_STATE) > _HOLO_CLIENT_LIMIT * 4:
            stale = [name for name, values in _HOLO_RATE_STATE.items() if not values or values[-1] < cutoff]
            for name in stale:
                _HOLO_RATE_STATE.pop(name, None)
        return True


def _holo_redact(value: Any) -> Any:
    """Recursively redact credential-like keys before presentation transport."""
    if isinstance(value, dict):
        return {str(key): ("[REDACTED]" if str(key).lower() in _HOLO_SENSITIVE_KEYS else _holo_redact(item)) for key, item in value.items()}
    if isinstance(value, list):
        return [_holo_redact(item) for item in value]
    if isinstance(value, tuple):
        return [_holo_redact(item) for item in value]
    return value


def _holo_snapshot(core: Any) -> dict[str, Any]:
    """Build a non-sensitive state snapshot for the presentation layer."""
    profiler = getattr(core, "hardware", None) or getattr(core, "hardware_profiler", None)
    cpu = 0.0
    ram = 0.0
    gpu = 0.0
    vram = 0.0
    if profiler is not None:
        try:
            import psutil
            cpu = float(psutil.cpu_percent(interval=None))
            total = float(getattr(profiler, "ram_total_gb", 0.0) or 0.0)
            free = float(getattr(profiler, "ram_free_gb", total) or total)
            ram = ((total - free) / total * 100.0) if total > 0 else 0.0
            gpus = getattr(profiler, "gpus", []) or []
            if gpus:
                total_vram = float(gpus[0].get("total_gb", 0.0) or 0.0)
                free_vram = float(gpus[0].get("free_gb", total_vram) or total_vram)
                vram = ((total_vram - free_vram) / total_vram * 100.0) if total_vram > 0 else 0.0
        except Exception:
            logger.debug("holo_hardware_snapshot_failed", exc_info=True)
    router = getattr(core, "router", None)
    primary = getattr(router, "primary", None) if router is not None else None
    model = str(getattr(primary, "name", "unknown"))
    gateway = getattr(core, "intelligence_gateway", None)
    gateway_snapshot = gateway.snapshot().to_dict() if gateway is not None and hasattr(gateway, "snapshot") else {}
    memory = getattr(core, "cognitive_memory", None)
    memory_items = int((memory.snapshot().get("total", 0) if memory is not None else 0))
    autonomy = getattr(core, "autonomy_fabric", None)
    autonomy_snapshot = autonomy.snapshot() if autonomy is not None and hasattr(autonomy, "snapshot") else {}
    security_mode = str(getattr(core, "cfg", {}).get("security", {}).get("mode", "guarded"))
    return {
        "cpu_percent": max(0.0, min(100.0, cpu)),
        "ram_percent": max(0.0, min(100.0, ram)),
        "gpu_percent": max(0.0, min(100.0, gpu)),
        "vram_percent": max(0.0, min(100.0, vram)),
        "tokens_per_second": float(gateway_snapshot.get("tokens_per_second", 0.0) or 0.0),
        "latency_ms": float(gateway_snapshot.get("mean_latency_ms", 0.0) or 0.0),
        "active_jobs": int((core.job_engine.get_stats().get("running", 0) if callable(getattr(core.job_engine, "get_stats", None)) else 0)) if getattr(core, "job_engine", None) else 0,
        "active_agents": int(autonomy_snapshot.get("status_counts", {}).get("running", 0)) if isinstance(autonomy_snapshot, dict) else 0,
        "memory_items": memory_items,
        "model": model,
        "backend": model,
        "security_mode": security_mode,
    }


async def _holo_send(ws: WebSocket, msg_type: str, data: dict[str, Any], request_id: str | None = None, correlation_id: str | None = None) -> None:
    await ws.send_json({
        "t": msg_type,
        "id": request_id,
        "v": _HOLO_PROTOCOL_VERSION,
        "ts": time.time(),
        "correlation_id": correlation_id,
        "data": _holo_redact(data),
    })


async def _holo_client(ws: WebSocket) -> None:
    host = ws.client.host if ws.client else "unknown"
    with _HOLO_CLIENT_LOCK:
        if len(_HOLO_CLIENTS) >= _HOLO_CLIENT_LIMIT:
            await ws.close(code=1013, reason="too many holo clients")
            return
        _HOLO_CLIENTS.add(ws)
    loop = asyncio.get_running_loop()
    event_bus = None
    session_id = "unknown"
    operator_id = ""
    event_tasks: set[Future[Any]] = set()

    def publish_event(event: Any) -> None:
        """Forward only presentation-safe events with bounded in-flight tasks."""
        event_type = str(getattr(event, "event_type", "event"))
        if not event_type.startswith(_HOLO_PUBLIC_EVENT_PREFIXES):
            return
        if len(event_tasks) >= 16:
            logger.warning("holo_event_backpressure", extra={"host": host})
            return
        try:
            async def forward() -> None:
                payload = dict(getattr(event, "payload", {}))
                outgoing_type = "log" if event_type == "log" or event_type.startswith("log.") else event_type
                await _holo_send(ws, outgoing_type, payload, correlation_id=getattr(event, "correlation_id", None))
            task = asyncio.run_coroutine_threadsafe(forward(), loop)
            event_tasks.add(task)
            def _finished(future: Future[Any]) -> None:
                event_tasks.discard(future)
                if not future.cancelled():
                    try:
                        future.result()
                    except Exception:
                        logger.debug("holo_event_forward_failed", exc_info=True)
            task.add_done_callback(_finished)
        except Exception:
            logger.debug("holo_event_forward_failed", exc_info=True)

    try:
        await ws.accept()
        raw_hello = await ws.receive_text()
        if len(raw_hello.encode("utf-8")) > _HOLO_MAX_MESSAGE_BYTES:
            await ws.close(code=1009, reason="message too large")
            return
        hello = json.loads(raw_hello)
        data = hello.get("data", {}) if isinstance(hello, dict) else {}
        if not isinstance(data, dict) or int(hello.get("v", 0)) != _HOLO_PROTOCOL_VERSION or data.get("protocol") != "jarvis-holo":
            await _holo_send(ws, "error", {"error": "unsupported holo protocol"}, request_id=hello.get("id") if isinstance(hello, dict) else None)
            await ws.close(code=1002, reason="unsupported protocol")
            return
        if not _holo_client_allowed(host, data.get("token")):
            await _holo_send(ws, "error", {"error": "holo authentication failed"}, request_id=hello.get("id"))
            await ws.close(code=1008, reason="authentication failed")
            return
        raw_token = str(data.get("token") or "")
        operator_id = _owner_id(raw_token) if raw_token else "holo:" + hashlib.sha256(host.encode("utf-8")).hexdigest()[:24]
        core = _core
        if core is None:
            await _holo_send(ws, "error", {"error": "JARVIS core not initialized"}, request_id=hello.get("id"))
            return
        event_bus = getattr(core, "event_bus", None)
        if event_bus is not None and hasattr(event_bus, "subscribe_event"):
            event_bus.subscribe_event("*", publish_event)
        await _holo_send(ws, "hello.ok", {"protocol": "jarvis-holo", "version": _HOLO_PROTOCOL_VERSION, "server_version": getattr(core, "version", "12.8.3"), "operator_id": operator_id}, request_id=hello.get("id"))
        try:
            models = core.router.list_backends()
            model_names = [str(row.get("name")) for row in models if isinstance(row, dict) and row.get("name")]
            await _holo_send(ws, "model.list", {"models": model_names})
        except Exception:
            logger.debug("holo_model_list_failed", exc_info=True)
        while True:
            raw = await ws.receive_text()
            if len(raw.encode("utf-8")) > _HOLO_MAX_MESSAGE_BYTES:
                await _holo_send(ws, "error", {"error": "message too large"})
                continue
            if not _holo_rate_allowed(f"{host}:{session_id}"):
                await _holo_send(ws, "error", {"error": "holo rate limit exceeded"})
                continue
            message = json.loads(raw)
            if not isinstance(message, dict) or int(message.get("v", 0)) != _HOLO_PROTOCOL_VERSION:
                await _holo_send(ws, "error", {"error": "invalid protocol envelope"}, request_id=message.get("id") if isinstance(message, dict) else None)
                continue
            request_id = str(message.get("id", "")) or None
            msg_type = str(message.get("t", ""))
            payload = message.get("data", {})
            if not isinstance(payload, dict):
                await _holo_send(ws, "error", {"error": "data must be an object"}, request_id=request_id)
                continue
            if msg_type == "heartbeat":
                await _holo_send(ws, "heartbeat.ok", {"server_time": time.time()}, request_id=request_id)
            elif msg_type == "state.request":
                await _holo_send(ws, "telemetry", _holo_snapshot(core), request_id=request_id)
            elif msg_type == "models.request":
                models = core.router.list_backends()
                await _holo_send(ws, "model.list", {"models": [str(row.get("name")) for row in models if isinstance(row, dict) and row.get("name")]}, request_id=request_id)
            elif msg_type == "chat.request":
                text = str(payload.get("text", "")).strip()
                if not text or len(text) > 50_000:
                    await _holo_send(ws, "error", {"error": "invalid chat text"}, request_id=request_id)
                    continue
                session_id = str(payload.get("session_id", "default"))[:256]
                try:
                    full_text: list[str] = []
                    async with asyncio.timeout(60.0):
                        async for chunk in _stream_core_chat(core, text, task_type=str(payload.get("task_type", "default"))[:64], session_id=f"holo:{host}:{session_id}"):
                            full_text.append(chunk)
                            await _holo_send(ws, "chat.delta", {"text": chunk}, request_id=request_id, correlation_id=request_id)
                    await _holo_send(ws, "chat.result", {"text": "".join(full_text)}, request_id=request_id, correlation_id=request_id)
                except TimeoutError:
                    await _holo_send(ws, "error", {"error": "Chat request timed out"}, request_id=request_id, correlation_id=request_id)
                except Exception:
                    logger.exception("holo_chat_failed", extra={"request_id": request_id})
                    await _holo_send(ws, "error", {"error": "Chat request failed"}, request_id=request_id, correlation_id=request_id)
            elif msg_type == "mission.create":
                goal = str(payload.get("goal", "")).strip()
                if not goal or len(goal) > 20_000:
                    await _holo_send(ws, "error", {"error": "invalid mission goal"}, request_id=request_id)
                    continue
                owner = f"holo:{host}"
                mission_service = getattr(core, "mission_service", None)
                if mission_service is None:
                    await _holo_send(ws, "error", {"error": "mission service unavailable"}, request_id=request_id)
                    continue
                result = await asyncio.wait_for(asyncio.to_thread(lambda: asyncio.run(mission_service.execute_mission(goal, owner=owner))), timeout=300.0)
                mission_id = str(result.get("mission_id", ""))
                await _holo_send(ws, "mission.update", {"mission_id": mission_id, "goal": goal, "status": "completed" if result.get("ok") else "failed", "steps": result.get("steps", []), "error": result.get("error")}, request_id=request_id, correlation_id=request_id)
            elif msg_type == "mission.status":
                mission_id = str(payload.get("mission_id", "")).strip()
                mission_service = getattr(core, "mission_service", None)
                result = await mission_service.get_mission_status(mission_id) if mission_service is not None else {"ok": False, "error": "mission service unavailable"}
                await _holo_send(ws, "mission.update", result.get("status", result), request_id=request_id, correlation_id=request_id)
            elif msg_type == "mission.cancel":
                mission_id = str(payload.get("mission_id", "")).strip()
                mission_service = getattr(core, "mission_service", None)
                active = getattr(mission_service, "_active_missions", {}) if mission_service is not None else {}
                record = active.get(mission_id) if isinstance(active, dict) else None
                job_id = record.get("job_id") if isinstance(record, dict) else None
                job_engine = getattr(core, "job_engine", None)
                cancelled = bool(job_id and job_engine is not None and job_engine.cancel(job_id))
                await _holo_send(ws, "mission.update", {"mission_id": mission_id, "status": "cancelled" if cancelled else "failed", "error": None if cancelled else "mission could not be cancelled"}, request_id=request_id, correlation_id=request_id)
            elif msg_type == "workflow.create":
                workflow_service = getattr(core, "workflow_service", None)
                if workflow_service is None:
                    await _holo_send(ws, "error", {"error": "workflow service unavailable"}, request_id=request_id)
                    continue
                try:
                    workflow_id = workflow_service.create_visual(
                        str(payload.get("name", "Holo Workflow"))[:256],
                        list(payload.get("nodes", [])),
                        list(payload.get("edges", [])),
                    )
                    await _holo_send(ws, "workflow.saved", {"workflow_id": workflow_id}, request_id=request_id, correlation_id=request_id)
                except (TypeError, ValueError) as exc:
                    await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "workflow.get":
                workflow_service = getattr(core, "workflow_service", None)
                workflow_id = str(payload.get("workflow_id", "")).strip()
                definition = workflow_service.get_visual(workflow_id) if workflow_service is not None else None
                if definition is None:
                    await _holo_send(ws, "error", {"error": "workflow not found"}, request_id=request_id)
                else:
                    await _holo_send(ws, "workflow.definition", definition, request_id=request_id, correlation_id=request_id)
            elif msg_type == "workflow.compile":
                workflow_service = getattr(core, "workflow_service", None)
                workflow_id = str(payload.get("workflow_id", "")).strip()
                if workflow_service is None:
                    await _holo_send(ws, "error", {"error": "workflow service unavailable"}, request_id=request_id)
                else:
                    try:
                        report = workflow_service.visual_compile_report(workflow_id)
                        await _holo_send(ws, "workflow.compiled", report, request_id=request_id, correlation_id=request_id)
                    except Exception as exc:
                        await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "workflow.run":
                workflow_service = getattr(core, "workflow_service", None)
                authority = getattr(core, "mission_authority", None)
                workflow_id = str(payload.get("workflow_id", "")).strip()
                workflow_input = str(payload.get("input", ""))[:20_000]
                if workflow_service is None or authority is None:
                    await _holo_send(ws, "error", {"error": "workflow runtime unavailable"}, request_id=request_id)
                else:
                    try:
                        compiled = workflow_service.compile_visual(workflow_id)
                        capabilities = tuple(sorted({step.capability for step in compiled.steps}))
                        mission = authority.create(compiled.name, compiled.steps, owner=f"holo:{host}:{session_id}", capabilities=capabilities)
                        results: dict[str, Any] = {}

                        def execute_visual(step: Any) -> Any:
                            meta = dict(step.metadata)
                            node_type = str(meta.get("node_type", ""))
                            dep_values = [results.get(dep) for dep in step.dependencies]
                            value = next((item for item in reversed(dep_values) if item is not None), workflow_input)
                            if node_type in {"input.text", "user_input"}:
                                output: Any = workflow_input
                            elif node_type in {"ai.router", "ai_router"}:
                                output = core.chat(str(value), session_id=f"workflow:{mission.mission_id}")
                            elif node_type in {"agent.researcher", "research_agent"}:
                                output = core.agent_service.run_task("research", {"task": str(value)}, mission_id=mission.mission_id)
                            elif node_type in {"tool.web_search", "web_search"}:
                                output = core.tool_service.execute("web_search", {"query": str(value)}, mission_id=mission.mission_id)
                            elif node_type in {"memory.write", "memory_write"}:
                                if core.memory is None:
                                    raise RuntimeError("memory subsystem unavailable")
                                core.memory.add(f"workflow:{mission.mission_id}", "workflow", str(value))
                                output = {"ok": True, "stored": True}
                            elif node_type in {"policy.check", "policy_check"}:
                                decision = core.policy_gateway.evaluate(capability=step.capability, risk=getattr(__import__("core.policy_gateway", fromlist=["RiskLevel"]), "RiskLevel").L0, mission_id=mission.mission_id)
                                output = {"ok": decision.allowed, "reason": decision.reason, "decision_id": decision.decision_id}
                                if not decision.allowed:
                                    raise PermissionError(decision.reason)
                            elif node_type in {"control.approval", "human_approval"}:
                                autopilot = getattr(core, "autopilot", None)
                                if autopilot is None or not autopilot.authorize_action("workflow.approval.override"):
                                    raise PermissionError("human approval is required before this workflow step")
                                output = {"ok": True, "overridden": True, "mode": "authorized_autopilot"}
                            elif node_type in {"output.text", "output"}:
                                output = value
                            else:
                                raise ValueError(f"unsupported executable workflow node: {node_type}")
                            results[step.step_id] = output
                            return output

                        result = await asyncio.to_thread(authority.execute, mission.mission_id, compiled.steps, execute_visual)
                        await _holo_send(ws, "workflow.result", {"workflow_id": workflow_id, "mission_id": mission.mission_id, **result}, request_id=request_id, correlation_id=request_id)
                    except Exception as exc:
                        await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "security.webauthn.begin":
                try:
                    purpose = str(payload.get("purpose", "control")).strip()[:64] or "control"
                    control = getattr(getattr(core, "nextgen", None), "webauthn", None)
                    if control is None:
                        raise RuntimeError("WebAuthn control plane unavailable")
                    challenge = control.begin(operator_id, purpose=purpose)
                    await _holo_send(ws, "webauthn.challenge", {"challenge_id": challenge.challenge_id, "challenge": challenge.challenge, "expires_at": challenge.expires_at, "purpose": challenge.purpose, "operator_id": operator_id}, request_id=request_id, correlation_id=request_id)
                except (ValueError, RuntimeError) as exc:
                    await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "security.webauthn.verify":
                try:
                    control = getattr(getattr(core, "nextgen", None), "webauthn", None)
                    if control is None:
                        raise RuntimeError("WebAuthn control plane unavailable")
                    ok = control.verify_assertion(
                        str(payload.get("challenge_id", "")),
                        str(payload.get("credential_id", "")),
                        base64.b64decode(str(payload.get("signature_der_b64", "")), validate=True),
                        client_data_json=base64.b64decode(str(payload.get("client_data_json_b64", "")), validate=True),
                        authenticator_data=base64.b64decode(str(payload.get("authenticator_data_b64", "")), validate=True),
                        operator_id=operator_id,
                        origin=str(payload.get("origin") or "") or None,
                    )
                    if not ok:
                        raise PermissionError("WebAuthn verification failed")
                    await _holo_send(ws, "webauthn.verified", {"ok": True, "operator_id": operator_id}, request_id=request_id, correlation_id=request_id)
                except (ValueError, TypeError, PermissionError, RuntimeError) as exc:
                    await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "nextgen.status":
                fabric = getattr(core, "nextgen", None)
                if fabric is None:
                    await _holo_send(ws, "error", {"error": "nextgen platform unavailable"}, request_id=request_id)
                else:
                    await _holo_send(ws, "nextgen.status", fabric.health(), request_id=request_id, correlation_id=request_id)
            elif msg_type == "settings.get":
                service = getattr(core, "settings_service", None)
                if service is None:
                    await _holo_send(ws, "error", {"error": "settings service unavailable"}, request_id=request_id)
                else:
                    await _holo_send(ws, "settings.result", service.metadata(), request_id=request_id, correlation_id=request_id)
            elif msg_type == "settings.set":
                service = getattr(core, "settings_service", None)
                try:
                    if service is None:
                        raise RuntimeError("settings service unavailable")
                    key = str(payload.get("key", ""))
                    change = service.set(key, payload.get("value"))
                    if bool(payload.get("persist", True)) and not service.save():
                        raise RuntimeError("settings persistence failed")
                    await _holo_send(ws, "settings.result", {"ok": True, **change}, request_id=request_id, correlation_id=request_id)
                except Exception as exc:
                    await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "autopilot.status":
                autopilot = getattr(core, "autopilot", None)
                if autopilot is None:
                    await _holo_send(ws, "error", {"error": "autopilot unavailable"}, request_id=request_id)
                else:
                    await _holo_send(ws, "autopilot.status", autopilot.status(), request_id=request_id, correlation_id=request_id)
            elif msg_type == "autopilot.authorize":
                try:
                    autopilot = getattr(core, "autopilot", None)
                    if autopilot is None:
                        raise RuntimeError("autopilot unavailable")
                    requested_capabilities = tuple(str(item).strip() for item in (payload.get("capabilities") or []) if str(item).strip())
                    step_up_verified = False
                    challenge_id = str(payload.get("webauthn_challenge_id", "")).strip()
                    operator_id = str(payload.get("operator_id", "")).strip()
                    high_impact = any(cap in {"process.spawn", "code.execute", "device.write", "filesystem.write"} for cap in requested_capabilities)
                    if high_impact:
                        if challenge_id:
                            control = getattr(getattr(core, "nextgen", None), "webauthn", None)
                            if control is None or not control.consume_authorization(challenge_id, operator_id=operator_id, purpose="autopilot"):
                                raise PermissionError("invalid or expired WebAuthn step-up authorization")
                            step_up_verified = True
                        else:
                            raise PermissionError("high-impact Holo autopilot capabilities require WebAuthn step-up verification")
                    autopilot.authorize(str(payload.get("approval_token", "")), reason=str(payload.get("reason", "authorized autopilot")), capabilities=requested_capabilities, step_up_verified=step_up_verified)
                    await _holo_send(ws, "autopilot.status", {"ok": True, **autopilot.status()}, request_id=request_id, correlation_id=request_id)
                except Exception as exc:
                    await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "autopilot.stop":
                autopilot = getattr(core, "autopilot", None)
                if autopilot is None:
                    await _holo_send(ws, "error", {"error": "autopilot unavailable"}, request_id=request_id)
                else:
                    autopilot.stop()
                    await _holo_send(ws, "autopilot.status", autopilot.status(), request_id=request_id, correlation_id=request_id)
            elif msg_type == "workers.list":
                manager = getattr(core, "long_term_workers", None)
                if manager is None:
                    await _holo_send(ws, "error", {"error": "long-term workers unavailable"}, request_id=request_id)
                else:
                    await _holo_send(ws, "workers.result", manager.snapshot(), request_id=request_id, correlation_id=request_id)
            elif msg_type == "worker.create":
                manager = getattr(core, "long_term_workers", None)
                autopilot = getattr(core, "autopilot", None)
                if manager is None or autopilot is None:
                    await _holo_send(ws, "error", {"error": "long-term worker system unavailable"}, request_id=request_id)
                elif not autopilot.authorize_action("autonomy.worker.start"):
                    await _holo_send(ws, "error", {"error": "authorized autopilot session required"}, request_id=request_id)
                else:
                    try:
                        role = str(payload.get("role", "")).strip()
                        objective = str(payload.get("objective", "")).strip()
                        interval_seconds = float(payload.get("interval_seconds", 30.0))
                        spec = manager.register(role, objective, lambda worker, cycle: core.autonomous_executive.trigger(worker.objective, priority=70, source=f"long-term:{worker.worker_id}"), interval_seconds=interval_seconds)
                        state = manager.start(spec.worker_id)
                        await _holo_send(ws, "worker.result", {"ok": True, "worker": {"worker_id": spec.worker_id, "role": spec.role, "objective": spec.objective, "status": state.status}}, request_id=request_id, correlation_id=request_id)
                    except (ValueError, RuntimeError) as exc:
                        await _holo_send(ws, "error", {"error": str(exc)}, request_id=request_id)
            elif msg_type == "worker.stop":
                manager = getattr(core, "long_term_workers", None)
                worker_id = str(payload.get("worker_id", "")).strip()
                if manager is None:
                    await _holo_send(ws, "error", {"error": "long-term workers unavailable"}, request_id=request_id)
                elif not worker_id:
                    await _holo_send(ws, "error", {"error": "worker_id is required"}, request_id=request_id)
                else:
                    try:
                        state = manager.stop(worker_id)
                        await _holo_send(ws, "worker.result", {"ok": True, "worker": {"worker_id": state.worker_id, "role": state.role, "status": state.status, "cycles": state.cycles, "last_error": state.last_error}}, request_id=request_id, correlation_id=request_id)
                    except KeyError:
                        await _holo_send(ws, "error", {"error": "worker not found"}, request_id=request_id)
            elif msg_type == "workers.stop_all":
                manager = getattr(core, "long_term_workers", None)
                if manager is None:
                    await _holo_send(ws, "error", {"error": "long-term workers unavailable"}, request_id=request_id)
                else:
                    manager.stop_all()
                    await _holo_send(ws, "workers.result", {"ok": True, **manager.snapshot()}, request_id=request_id, correlation_id=request_id)
            elif msg_type == "action.request":
                capability = str(payload.get("capability", "")).strip()
                if capability == "system.observe":
                    await _holo_send(ws, "action.result", {"ok": True, "state": _holo_snapshot(core)}, request_id=request_id, correlation_id=request_id)
                else:
                    # The Holo client does not receive direct host execution authority.
                    await _holo_send(ws, "action.result", {"ok": False, "state": "denied", "error": "action requires an authorized core-side capability flow"}, request_id=request_id, correlation_id=request_id)
            else:
                await _holo_send(ws, "error", {"error": f"unknown holo message: {msg_type}"}, request_id=request_id)

            if msg_type != "heartbeat":
                try:
                    await _holo_send(ws, "telemetry", _holo_snapshot(core))
                except Exception:
                    logger.debug("holo_telemetry_push_failed", exc_info=True)
    except (WebSocketDisconnect, RuntimeError):
        logger.debug("holo_client_disconnected", extra={"host": host})
    except Exception:
        logger.exception("holo_client_failed", extra={"host": host})
    finally:
        if event_bus is not None and hasattr(event_bus, "unsubscribe_event"):
            try:
                event_bus.unsubscribe_event("*", publish_event)
            except Exception:
                logger.debug("holo_event_unsubscribe_failed", exc_info=True)
        with _HOLO_CLIENT_LOCK:
            _HOLO_CLIENTS.discard(ws)
            _HOLO_RATE_STATE.pop(f"{host}:{session_id}", None)


@app.websocket("/holo")
async def holo_websocket(websocket: WebSocket) -> None:
    """Authenticated WebSocket endpoint for the V12.8.0 Flutter Command Deck."""
    await _holo_client(websocket)

# =================================================================
# Core configuration
# =================================================================
def configure_core(core: Any) -> None:
    """Wire the JARVISCore instance into the FastAPI app."""
    global _core
    _core = core


# =================================================================
# Autonomous Executive
# =================================================================
class GoalRequest(BaseModel):
    goal: str = Field(..., min_length=1, max_length=20000)
    priority: int = Field(default=5, ge=0, le=100)
    metadata: dict[str, Any] = Field(default_factory=dict)


@app.get("/autonomy", tags=["autonomy"])
def autonomy_snapshot(token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    """Return the autonomous executive state."""
    executive = getattr(core, "executive", None)
    if executive is None:
        raise HTTPException(status_code=503, detail="Autonomous executive unavailable")
    return executive.snapshot()


@app.get("/autonomy/goals", tags=["autonomy"])
def autonomy_goals(token: str = Depends(verify_token), core=Depends(get_core)) -> list[dict]:
    """List autonomous goals."""
    executive = getattr(core, "executive", None)
    if executive is None:
        raise HTTPException(status_code=503, detail="Autonomous executive unavailable")
    return executive.list_goals(owner=_owner_id(token))


@app.post("/autonomy/goals", tags=["autonomy"])
def autonomy_submit(req: GoalRequest, token: str = Depends(verify_token), core=Depends(get_core), _: None = Depends(rate_limit)) -> dict:
    """Submit a bounded autonomous goal."""
    executive = getattr(core, "executive", None)
    if executive is None:
        raise HTTPException(status_code=503, detail="Autonomous executive unavailable")
    owner = _owner_id(token)
    try:
        goal_id = executive.submit_goal(req.goal, priority=req.priority, owner=owner, metadata=req.metadata)
        return {"ok": True, "goal_id": goal_id}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/world", tags=["autonomy"])
def world_snapshot(token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    """Return a compact world-model snapshot."""
    model = getattr(core, "world_model", None)
    if model is None:
        raise HTTPException(status_code=503, detail="World model unavailable")
    return model.snapshot()


@app.get("/devices", tags=["autonomy"])
def devices(token: str = Depends(verify_token), core=Depends(get_core)) -> list[dict]:
    """List registered physical/digital devices."""
    gateway = getattr(core, "device_gateway", None)
    if gateway is None:
        raise HTTPException(status_code=503, detail="Device gateway unavailable")
    return gateway.list_devices()


class ScheduleRequest(BaseModel):
    goal: str = Field(..., min_length=1, max_length=20000)
    delay_seconds: float = Field(default=0.0, ge=0.0, le=7 * 24 * 3600)
    priority: int = Field(default=5, ge=0, le=100)


@app.post("/autonomy/schedules", tags=["autonomy"])
def autonomy_schedule(req: ScheduleRequest, token: str = Depends(verify_token), core=Depends(get_core), _: None = Depends(rate_limit)) -> dict:
    """Schedule a bounded autonomous goal."""
    scheduler = getattr(core, "task_scheduler", None)
    if scheduler is None:
        raise HTTPException(status_code=503, detail="Autonomous scheduler unavailable")
    try:
        schedule_id = scheduler.schedule(req.goal, delay_seconds=req.delay_seconds, priority=req.priority, metadata={"owner": _owner_id(token)})
        return {"ok": True, "schedule_id": schedule_id}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/autonomy/schedules", tags=["autonomy"])
def autonomy_schedules(token: str = Depends(verify_token), core=Depends(get_core)) -> list[dict]:
    """List autonomous schedules belonging to the authenticated owner."""
    scheduler = getattr(core, "task_scheduler", None)
    if scheduler is None:
        raise HTTPException(status_code=503, detail="Autonomous scheduler unavailable")
    owner = _owner_id(token)
    return [item for item in scheduler.pending() if item.get("metadata", {}).get("owner") == owner]


# =================================================================
# Durable Jobs
# =================================================================
class JobSubmitRequest(BaseModel):
    goal: str = Field(..., min_length=1, max_length=20000)
    steps: list[dict[str, Any]] = Field(default_factory=list, max_length=100)
    priority: int = Field(default=5, ge=1, le=10)
    idempotency_key: Optional[str] = Field(default=None, min_length=1, max_length=256)


class JobAuthRequest(BaseModel):
    job_id: str = Field(..., min_length=1, max_length=128)
    step_id: str = Field(..., min_length=1, max_length=128)
    token: str = Field(..., min_length=1, max_length=4096)


def _require_job_service(core: Any) -> Any:
    svc = getattr(core, "job_service", None)
    if svc is None or not svc.available():
        raise HTTPException(status_code=503, detail="Job engine unavailable")
    return svc


def _owner_id(token: str) -> str:
    return "api:" + hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


def _owned_job_or_404(svc: Any, job_id: str, owner: str) -> dict[str, Any]:
    result = svc.get(job_id)
    if not result.get("ok"):
        raise HTTPException(status_code=404, detail="Job not found")
    job = result.get("job") or {}
    if job.get("owner") != owner:
        raise HTTPException(status_code=404, detail="Job not found")
    return result


@app.post("/jobs", tags=["jobs"])
def submit_job(
    req: JobSubmitRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> dict:
    """Submit and asynchronously start one durable job."""
    svc = _require_job_service(core)
    engine = getattr(core, "job_engine", None)
    if engine is not None:
        stats = engine.get_stats()
        if int(stats.get("queue_depth", 0)) >= 500:
            raise HTTPException(status_code=429, detail="Job queue depth exceeded")
    result = svc.submit(
        req.goal,
        req.steps,
        owner=_owner_id(token),
        priority=req.priority,
        idempotency_key=req.idempotency_key,
    )
    if not result.get("ok"):
        error = str(result.get("error", "job submission failed"))
        error_code = str(result.get("error_code", "INTERNAL_ERROR"))
        http_code = {"IDEMPOTENCY_CONFLICT": 409, "IDEMPOTENCY_IN_PROGRESS": 409, "VALIDATION_ERROR": 400, "SERVICE_UNAVAILABLE": 503}.get(error_code, 500)
        raise HTTPException(status_code=http_code, detail={"code": error_code, "message": error})
    return result


@app.get("/jobs", tags=["jobs"])
def list_jobs(
    status: str | None = None,
    limit: int = 100,
    token: str = Depends(verify_token),
    core=Depends(get_core),
) -> dict:
    return _require_job_service(core).list(status=status, owner=_owner_id(token), limit=max(1, min(limit, 1000)))


@app.get("/jobs/dlq", tags=["jobs"])
def job_dlq(limit: int = 100, token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    return _require_job_service(core).dlq(limit=max(1, min(limit, 1000)), owner=_owner_id(token))


@app.get("/jobs/stats", tags=["jobs"])
def job_stats(token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    return _require_job_service(core).stats(owner=_owner_id(token))


@app.get("/jobs/{job_id}", tags=["jobs"])
def get_job(job_id: str, token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    return _owned_job_or_404(_require_job_service(core), job_id, _owner_id(token))


@app.post("/jobs/{job_id}/cancel", tags=["jobs"])
def cancel_job(
    job_id: str,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> dict:
    svc = _require_job_service(core)
    _owned_job_or_404(svc, job_id, _owner_id(token))
    result = svc.cancel(job_id)
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("error"))
    return result


@app.post("/jobs/{job_id}/pause", tags=["jobs"])
def pause_job(
    job_id: str,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> dict:
    svc = _require_job_service(core)
    _owned_job_or_404(svc, job_id, _owner_id(token))
    result = svc.pause(job_id)
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("error"))
    return result


@app.post("/jobs/{job_id}/resume", tags=["jobs"])
def resume_job(
    job_id: str,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> dict:
    svc = _require_job_service(core)
    _owned_job_or_404(svc, job_id, _owner_id(token))
    result = svc.resume(job_id)
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("error"))
    return result


@app.get("/jobs/{job_id}/history", tags=["jobs"])
def job_history(job_id: str, token: str = Depends(verify_token), core=Depends(get_core)) -> dict:
    svc = _require_job_service(core)
    _owned_job_or_404(svc, job_id, _owner_id(token))
    return svc.history(job_id)


@app.post("/jobs/authorize", tags=["jobs"])
def authorize_step(
    req: JobAuthRequest,
    token: str = Depends(verify_token),
    core=Depends(get_core),
    _: None = Depends(rate_limit),
) -> dict:
    svc = _require_job_service(core)
    _owned_job_or_404(svc, req.job_id, _owner_id(token))
    result = svc.authorize_step(req.job_id, req.step_id, req.token, approver=_owner_id(token))
    if not result.get("ok"):
        raise HTTPException(status_code=403, detail="Step authorization failed")
    return result



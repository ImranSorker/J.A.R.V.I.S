"""Target-machine capability and certification report for the polyglot platform."""
from __future__ import annotations

import importlib.util
import platform
import shutil


class TargetMachineCertification:
    """Inspect backend, GUI, hardware and polyglot toolchain readiness without mutation."""

    def run(self) -> dict[str, object]:
        """Return required/optional target capabilities with explicit toolchain status."""
        checks = {
            "python_312_313": platform.python_version_tuple()[:2] in {("3", "12"), ("3", "13")},
            "flutter_cli": shutil.which("flutter") is not None,
            "pynvml": importlib.util.find_spec("pynvml") is not None,
            "whisper": importlib.util.find_spec("whisper") is not None,
            "playwright": importlib.util.find_spec("playwright") is not None,
            "lancedb": importlib.util.find_spec("lancedb") is not None,
            "llama_cpp": importlib.util.find_spec("llama_cpp") is not None,
            "rustc": shutil.which("rustc") is not None,
            "cargo": shutil.which("cargo") is not None,
            "dotnet": shutil.which("dotnet") is not None,
            "go": shutil.which("go") is not None,
            "node": shutil.which("node") is not None,
            "git": shutil.which("git") is not None,
            "platform": platform.system(),
        }
        required = {"python_312_313", "git"}
        return {"ok": all(bool(checks[name]) for name in required), "checks": checks, "required": sorted(required), "optional_toolchains": [name for name in checks if name not in required and name != "platform"]}



# Turn 9 — Approval Token Triage

## Classification

**Marker, not credential.** `SecurityExecutor` constructs `ExecutionBroker` without a permission engine. `ExecutionBroker._verify_authorization()` returns success when `_permissions is None`, so `approval_token` is not consulted as proof of authorization on this compatibility path. The literal therefore cannot function as a bearer credential through this broker configuration; it was still a misleading fixed marker.

## Fix

The literal `compat-approved` was replaced with a fresh `secrets.token_urlsafe(32)` value for every authorized `run()` call. The broker interface and `SecurityExecutor.run()` signature are unchanged. A regression test captures two broker requests and verifies that both markers are non-empty, neither equals the old literal, and the two values differ.

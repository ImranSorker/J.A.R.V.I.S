"""AION bridge for external cognitive services."""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger("jarvis.aion_bridge")


class AIONBridge:
    """Bridge to external AION cognitive services."""

    def __init__(self, journal_path: str = "data/aion_journal.jsonl",
                 poll_interval: int = 2):
        self.journal_path = Path(journal_path)
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.poll_interval = poll_interval
        self._entries: List[Dict[str, Any]] = []

    def write_journal(self, entry: Dict[str, Any]) -> None:
        """Write an entry to the AION journal."""
        entry["timestamp"] = time.time()
        with open(self.journal_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, default=str) + "\n")
        self._entries.append(entry)

    def read_journal(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Read recent journal entries."""
        if not self.journal_path.exists():
            return []
        entries = []
        with open(self.journal_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        logger.warning("aion_journal_invalid_json")
        return entries[-limit:]

    def sync(self) -> Dict[str, Any]:
        """Record a deterministic local synchronization checkpoint."""
        return {"ok": True, "synced": 0}

    def get_stats(self) -> Dict[str, Any]:
        return {
            "journal_path": str(self.journal_path),
            "entries_in_memory": len(self._entries),
            "poll_interval": self.poll_interval,
        }



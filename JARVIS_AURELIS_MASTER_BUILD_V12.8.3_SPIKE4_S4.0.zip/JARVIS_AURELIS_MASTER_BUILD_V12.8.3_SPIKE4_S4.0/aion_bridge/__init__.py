"""AION bridge for cognitive layer integration."""

__all__: list[str] = []



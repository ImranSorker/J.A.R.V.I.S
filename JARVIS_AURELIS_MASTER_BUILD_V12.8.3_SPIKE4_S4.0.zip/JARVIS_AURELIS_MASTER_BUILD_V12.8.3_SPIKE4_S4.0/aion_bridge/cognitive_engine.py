"""AION cognitive engine.

Records experiences, maintains goals, and provides strategic guidance
to the main JARVIS runtime.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jarvis.aion")


class AION:
    """Adaptive Intelligence Orchestration Network."""

    def __init__(self, store=None):
        self.store = store
        self._experiences: List[Dict[str, Any]] = []
        self._goals: List[Dict[str, Any]] = []
        self._strategies: Dict[str, Any] = {}

    def record_experience(self, experience: Dict[str, Any]) -> None:
        """Record an experience for future learning."""
        entry = {
            "timestamp": time.time(),
            **experience,
        }
        self._experiences.append(entry)
        logger.info("experience_recorded", extra={"type": experience.get("type", "unknown")})

    def add_goal(self, description: str, priority: int = 5,
                 deadline: Optional[float] = None) -> str:
        """Add a strategic goal."""
        goal_id = f"goal_{int(time.time())}_{len(self._goals)}"
        self._goals.append({
            "id": goal_id,
            "description": description,
            "priority": priority,
            "deadline": deadline,
            "created": time.time(),
            "status": "active",
        })
        return goal_id

    def list_goals(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """List goals, optionally filtered by status."""
        goals = self._goals
        if status:
            goals = [g for g in goals if g["status"] == status]
        return sorted(goals, key=lambda g: g["priority"])

    def complete_goal(self, goal_id: str) -> bool:
        """Mark a goal as completed."""
        for g in self._goals:
            if g["id"] == goal_id:
                g["status"] = "completed"
                g["completed_at"] = time.time()
                return True
        return False

    def suggest_strategy(self, context: str) -> Optional[str]:
        """Suggest a strategy based on past experiences."""
        relevant = [e for e in self._experiences if context.lower() in str(e).lower()]
        if not relevant:
            return None
        actions: Dict[str, int] = {}
        for e in relevant:
            action = e.get("action", "unknown")
            actions[action] = actions.get(action, 0) + 1
        if actions:
            return max(actions, key=actions.get)
        return None

    def get_stats(self) -> Dict[str, Any]:
        return {
            "experiences": len(self._experiences),
            "goals": len(self._goals),
            "active_goals": sum(1 for g in self._goals if g["status"] == "active"),
        }



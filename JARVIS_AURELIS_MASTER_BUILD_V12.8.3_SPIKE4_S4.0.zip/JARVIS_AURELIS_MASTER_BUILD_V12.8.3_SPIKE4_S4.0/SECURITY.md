# J.A.R.V.I.S. Security Model

J.A.R.V.I.S. V12.8.0 defaults to guarded local execution.

## Trust boundaries

User/Flutter UI → stdio bridge → composition root → cognitive/planning layer →
capability policy → authorization → secure executor/sandbox → external effect.

No production UI module owns policy or persistence. No model output is treated
as executable authority. External retrievals and tool results are untrusted data.

## High-risk actions

High-risk operations require explicit authorization, capability scope, bounded
resources, replay protection, and post-execution verification. Destructive or
externally visible actions remain approval-gated.

## Data protection

Persistent memory is namespace scoped. Secrets are never stored in the source
tree, logs, or model prompts. Runtime data remains under deployment-controlled
storage and is excluded from source release archives.

## Local transport

The Flutter Command Deck communicates with the Python runtime through a local
stdin/stdout process boundary. The default desktop transport does not expose a
listening socket or WebSocket endpoint. Network-facing APIs are separate and
must be explicitly configured and authenticated.

## Release signing

Source certification and deterministic provenance are separate from deployment
signing. A deployment-owned Ed25519 signing key/HSM/KMS trust root must be used
for production artifact signatures; private keys must never be committed here.

## Frontier safety fabric

The runtime now treats heterogeneous sensing, world state, mobility, swarm
coordination, and cybersecurity as separate policy domains with explicit
contracts. Sensor observations carry quality/trust/uncertainty metadata.
Conflicting high-confidence sources are surfaced rather than silently merged.

Vehicle and multi-robot functions are simulation-first and human-authorized.
Navigation calculations include geofencing, battery reserve, and return-to-home
checks. The core has no autonomous targeting or engagement capability.

Cybersecurity functions are restricted to assets declared inside an authorized
scope. Detection and containment are defensive analytics; operational actions
are delegated to injected adapters and cannot be triggered against an
undeclared asset.

Shared cognitive state contains evidence/facts/results only; credential fields
are rejected. Root-operator grants are short-lived and single-use and cannot
bypass immutable authorization, anti-exfiltration, or safety invariants.

Self-optimization is finite and benchmark-gated. Source evolution remains
quarantined until build, test, security, performance, and canary gates pass.

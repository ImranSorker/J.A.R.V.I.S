"""State-of-the-art bounded evolution fabrics for J.A.R.V.I.S. 12.8.0.

This module provides explicit contracts for sensor ingestion, context compilation,
adaptive routing, learning proposals, agent genomes, simulation, verification,
recovery and GPU governance. It is deliberately deterministic at the control
plane: model execution and hardware I/O are injected behind protocols.
"""
from __future__ import annotations

import hashlib
import json
import math
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Callable, Mapping, Protocol, Sequence


class Evolution2Error(RuntimeError):
    """Base error for frontier evolution control-plane failures."""


@dataclass(frozen=True, slots=True)
class SensorFrame:
    sensor_id: str
    sensor_type: str
    timestamp: float
    frame_id: str
    coordinate_frame: str
    payload: Mapping[str, float]
    uncertainty: Mapping[str, float] = field(default_factory=dict)
    quality: float = 1.0
    sequence: int = 0

    def validate(self, *, now: float | None = None, max_age: float = 30.0) -> None:
        if not self.sensor_id.strip() or not self.sensor_type.strip() or not self.frame_id.strip():
            raise ValueError("sensor identity is required")
        if not self.coordinate_frame.strip() or not math.isfinite(self.timestamp):
            raise ValueError("sensor frame metadata is invalid")
        if abs((time.time() if now is None else now) - self.timestamp) > max_age:
            raise ValueError("sensor frame is outside freshness window")
        if not self.payload or len(self.payload) > 512:
            raise ValueError("sensor payload must contain 1..512 fields")
        if not 0.0 <= self.quality <= 1.0:
            raise ValueError("sensor quality must be in [0,1]")
        for value in self.payload.values():
            if not math.isfinite(float(value)):
                raise ValueError("sensor payload contains non-finite data")


class SensorAdapter(Protocol):
    """Explicit adapter boundary for physical or simulated sensors."""

    def poll(self) -> SensorFrame:
        ...


class SensorFabric2:
    """Canonical sensor registry with sequence, calibration and health gates."""

    def __init__(self, *, max_sensors: int = 4096) -> None:
        self._max = max(1, min(int(max_sensors), 100_000))
        self._adapters: dict[str, SensorAdapter] = {}
        self._frames: dict[str, SensorFrame] = {}
        self._calibration: dict[str, tuple[float, float]] = {}
        self._lock = threading.RLock()

    def register(self, sensor_id: str, adapter: SensorAdapter, *, scale: float = 1.0, offset: float = 0.0) -> None:
        sensor_id = str(sensor_id).strip()
        if not sensor_id or not callable(getattr(adapter, "poll", None)):
            raise ValueError("valid sensor_id and adapter.poll are required")
        if not math.isfinite(float(scale)) or not math.isfinite(float(offset)) or scale == 0.0:
            raise ValueError("calibration must be finite and scale must be non-zero")
        with self._lock:
            if sensor_id not in self._adapters and len(self._adapters) >= self._max:
                raise Evolution2Error("sensor registry capacity exhausted")
            self._adapters[sensor_id] = adapter
            self._calibration[sensor_id] = (float(scale), float(offset))

    def poll(self, sensor_id: str) -> SensorFrame:
        with self._lock:
            adapter = self._adapters.get(sensor_id)
            calibration = self._calibration.get(sensor_id)
        if adapter is None or calibration is None:
            raise KeyError(sensor_id)
        frame = adapter.poll()
        frame.validate()
        scale, offset = calibration
        payload = {key: float(value) * scale + offset for key, value in frame.payload.items()}
        normalized = SensorFrame(frame.sensor_id, frame.sensor_type, frame.timestamp, frame.frame_id, frame.coordinate_frame, payload, frame.uncertainty, frame.quality, frame.sequence)
        with self._lock:
            previous = self._frames.get(sensor_id)
            if previous is not None and normalized.sequence <= previous.sequence:
                raise Evolution2Error("sensor sequence is not monotonic")
            self._frames[sensor_id] = normalized
        return normalized

    def health(self) -> dict[str, Any]:
        with self._lock:
            now = time.time()
            return {"sensors": len(self._adapters), "fresh": sum(1 for f in self._frames.values() if now - f.timestamp <= 5.0), "frames": len(self._frames)}


@dataclass(frozen=True, slots=True)
class WorldSnapshot:
    snapshot_id: str
    created_at: float
    entities: tuple[Mapping[str, Any], ...]
    conflicts: tuple[str, ...]
    digest: str


class WorldModel2:
    """Immutable snapshot projection with persistent entity identity and contradictions."""

    def __init__(self) -> None:
        self._entities: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()

    def ingest(self, entity_id: str, entity_type: str, properties: Mapping[str, Any], *, confidence: float = 1.0, source: str = "internal", observed_at: float | None = None) -> None:
        if not entity_id.strip() or not entity_type.strip() or not source.strip():
            raise ValueError("world entity identity is required")
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("confidence must be in [0,1]")
        clean = dict(properties)
        with self._lock:
            previous = self._entities.get(entity_id)
            version = int(previous["version"]) + 1 if previous else 1
            self._entities[entity_id] = {"entity_id": entity_id, "entity_type": entity_type, "properties": clean, "confidence": float(confidence), "source": source, "observed_at": time.time() if observed_at is None else float(observed_at), "version": version}

    def snapshot(self) -> WorldSnapshot:
        with self._lock:
            entities = tuple(dict(value) for value in sorted(self._entities.values(), key=lambda item: item["entity_id"]))
        conflicts: list[str] = []
        for entity in entities:
            props = entity["properties"]
            if isinstance(props, Mapping) and props.get("conflict") is True:
                conflicts.append(str(entity["entity_id"]))
        canonical = json.dumps({"entities": entities, "conflicts": conflicts}, sort_keys=True, separators=(",", ":"), default=str).encode()
        return WorldSnapshot(uuid.uuid4().hex, time.time(), entities, tuple(conflicts), hashlib.sha256(canonical).hexdigest())


@dataclass(frozen=True, slots=True)
class ContextPacket:
    request_id: str
    objective: str
    evidence: tuple[Mapping[str, Any], ...]
    constraints: tuple[str, ...]
    uncertainty: float
    token_budget: int
    provenance_digest: str


class ContextCompiler:
    """Builds bounded, provenance-addressed model context from trusted evidence."""

    def compile(self, objective: str, evidence: Sequence[Mapping[str, Any]], *, constraints: Sequence[str] = (), token_budget: int = 4096) -> ContextPacket:
        objective = str(objective).strip()
        budget = max(256, min(int(token_budget), 131_072))
        if not objective or len(objective) > 16_384:
            raise ValueError("objective is empty or oversized")
        bounded = tuple(dict(item) for item in evidence[:256])
        canonical = json.dumps(bounded, sort_keys=True, separators=(",", ":"), default=str).encode()
        uncertainty = 0.0 if not bounded else min(1.0, sum(1.0 - float(item.get("confidence", 1.0)) for item in bounded) / len(bounded))
        return ContextPacket(uuid.uuid4().hex, objective, bounded, tuple(str(item) for item in constraints[:64]), uncertainty, budget, hashlib.sha256(canonical).hexdigest())


@dataclass(frozen=True, slots=True)
class RouteDecision:
    model_id: str
    reason: str
    estimated_cost: float
    confidence: float


@dataclass(frozen=True, slots=True)
class RouteCandidate:
    model_id: str
    capabilities: frozenset[str]
    memory_mb: int
    quality: float
    latency_ms: float
    cost: float


class AdaptiveModelRouter2:
    """Constraint-first model router with deterministic scoring and explainability."""

    def choose(self, task: str, candidates: Sequence[RouteCandidate], *, required: Sequence[str] = (), memory_available_mb: int = 16_384, latency_budget_ms: float = 2_000.0) -> RouteDecision:
        if not str(task).strip() or not candidates:
            raise ValueError("task and candidates are required")
        required_set = set(required)
        eligible = [c for c in candidates if required_set.issubset(c.capabilities) and c.memory_mb <= memory_available_mb and c.latency_ms <= latency_budget_ms]
        if not eligible:
            raise Evolution2Error("no model satisfies routing constraints")
        ranked = sorted(eligible, key=lambda c: (-(c.quality - 0.001 * c.latency_ms - 0.01 * c.cost), c.model_id))
        winner = ranked[0]
        confidence = max(0.0, min(1.0, winner.quality * (1.0 - min(1.0, winner.latency_ms / max(latency_budget_ms, 1.0)) * 0.25)))
        return RouteDecision(winner.model_id, f"quality={winner.quality:.3f};latency={winner.latency_ms:.1f}ms;cost={winner.cost:.3f}", winner.cost, confidence)


@dataclass(frozen=True, slots=True)
class LearningProposal:
    proposal_id: str
    dataset_digest: str
    baseline_score: float
    candidate_score: float
    improvement: float
    status: str
    reason: str


class PersonalLearningGate:
    """Promotion gate for continual-learning candidates; no direct model mutation."""

    def propose(self, dataset: Sequence[Mapping[str, Any]], *, baseline_score: float, candidate_score: float, minimum_improvement: float = 0.01) -> LearningProposal:
        if not dataset:
            raise ValueError("training/evaluation dataset cannot be empty")
        if not all(math.isfinite(float(x)) for x in (baseline_score, candidate_score, minimum_improvement)):
            raise ValueError("scores must be finite")
        canonical = json.dumps(list(dataset), sort_keys=True, separators=(",", ":"), default=str).encode()
        improvement = float(candidate_score) - float(baseline_score)
        status = "eligible" if improvement >= minimum_improvement else "rejected"
        reason = "candidate clears improvement gate" if status == "eligible" else "candidate does not clear improvement gate"
        return LearningProposal(uuid.uuid4().hex, hashlib.sha256(canonical).hexdigest(), float(baseline_score), float(candidate_score), improvement, status, reason)


@dataclass(frozen=True, slots=True)
class AgentGenome:
    genome_id: str
    role: str
    capabilities: frozenset[str]
    max_concurrency: int = 1
    max_runtime_seconds: float = 60.0
    generation: int = 0

    def validate(self) -> None:
        if not self.genome_id.strip() or not self.role.strip() or not self.capabilities:
            raise ValueError("agent genome identity/capabilities are required")
        if not 1 <= self.max_concurrency <= 32 or not 0.1 <= self.max_runtime_seconds <= 86_400:
            raise ValueError("agent genome resource limits are invalid")


class AgentGenomeLab:
    """Deterministic bounded specialization and mutation registry."""

    def __init__(self) -> None:
        self._genomes: dict[str, AgentGenome] = {}
        self._lock = threading.RLock()

    def register(self, genome: AgentGenome) -> None:
        genome.validate()
        with self._lock:
            self._genomes[genome.genome_id] = genome

    def specialize(self, parent_id: str, role: str, capability: str) -> AgentGenome:
        with self._lock:
            parent = self._genomes.get(parent_id)
        if parent is None:
            raise KeyError(parent_id)
        child = AgentGenome(uuid.uuid4().hex, str(role).strip(), frozenset(set(parent.capabilities) | {str(capability).strip()}), parent.max_concurrency, parent.max_runtime_seconds, parent.generation + 1)
        child.validate()
        self.register(child)
        return child

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"genomes": len(self._genomes), "generations": max((g.generation for g in self._genomes.values()), default=0)}


@dataclass(frozen=True, slots=True)
class SimulationResult:
    scenario_id: str
    safe: bool
    steps: int
    violations: tuple[str, ...]
    digest: str


class SimulationUniverse:
    """Deterministic bounded digital-twin scenario runner."""

    def run(self, scenario_id: str, initial: Mapping[str, float], actions: Sequence[Mapping[str, float]], *, max_steps: int = 256, min_separation: float = 2.0) -> SimulationResult:
        if not scenario_id.strip() or not actions:
            raise ValueError("scenario and actions are required")
        state = {str(k): float(v) for k, v in initial.items()}
        violations: list[str] = []
        for index, action in enumerate(actions[:max(1, min(int(max_steps), 10_000))]):
            for key, delta in action.items():
                if not math.isfinite(float(delta)):
                    raise ValueError("simulation action contains non-finite value")
                state[str(key)] = state.get(str(key), 0.0) + float(delta)
            if "separation" in state and state["separation"] < min_separation:
                violations.append(f"step:{index}:minimum separation")
                break
        canonical = json.dumps({"scenario": scenario_id, "state": state, "violations": violations}, sort_keys=True, separators=(",", ":")).encode()
        return SimulationResult(scenario_id, not violations, index + 1, tuple(violations), hashlib.sha256(canonical).hexdigest())


class VerificationEngine:
    """Composes invariant checks before an externally visible action is admitted."""

    def verify(self, *, authorization: bool, simulation_safe: bool, policy_safe: bool, provenance_digest: str) -> tuple[bool, tuple[str, ...]]:
        failures = []
        if not authorization:
            failures.append("authorization")
        if not simulation_safe:
            failures.append("simulation")
        if not policy_safe:
            failures.append("policy")
        if len(provenance_digest) != 64:
            failures.append("provenance")
        return not failures, tuple(failures)


@dataclass(frozen=True, slots=True)
class GpuBudget:
    memory_mb: int
    utilization_percent: float
    temperature_c: float
    power_w: float


class GpuIntelligenceFabric:
    """Hardware-agnostic GPU governance with RTX-class safe operating envelopes."""

    def admit(self, budget: GpuBudget, *, memory_required_mb: int, temperature_limit_c: float = 83.0, max_utilization: float = 98.0) -> bool:
        if budget.memory_mb < 0 or memory_required_mb < 0 or not 0.0 <= budget.utilization_percent <= 100.0 or budget.temperature_c < -50.0 or budget.temperature_c > 150.0:
            raise ValueError("invalid GPU telemetry")
        return budget.memory_mb >= memory_required_mb and budget.temperature_c < temperature_limit_c and budget.utilization_percent <= max_utilization


@dataclass(frozen=True, slots=True)
class RecoveryRecord:
    operation_id: str
    checkpoint_digest: str
    restored: bool
    attempts: int


class RecoveryCoordinator:
    """Bounded checkpoint/restore coordinator with correct success-only idempotency.

    A failed operation is intentionally *not* recorded as completed: callers may
    retry the same idempotency key after repairing the underlying failure.
    Successful records remain replayable and are bound to their checkpoint digest.
    Per-operation locks prevent concurrent duplicate execution without serializing
    unrelated recovery operations.
    """

    def __init__(self, *, max_attempts: int = 3) -> None:
        self._max_attempts = max(1, min(int(max_attempts), 10))
        self._completed: dict[str, RecoveryRecord] = {}
        self._inflight: dict[str, threading.Lock] = {}
        self._lock = threading.RLock()

    def execute(self, operation_id: str, checkpoint: Mapping[str, Any], action: Callable[[], Any]) -> RecoveryRecord:
        """Execute an operation with bounded retries and success-only replay.

        Reusing a completed operation ID with a different checkpoint is rejected
        because it would silently alias two distinct recovery transactions.
        """
        operation_id = str(operation_id).strip()
        if not operation_id:
            raise ValueError("operation_id is required")
        if not callable(action):
            raise TypeError("action must be callable")
        canonical = json.dumps(dict(checkpoint), sort_keys=True, separators=(",", ":"), default=str).encode()
        digest = hashlib.sha256(canonical).hexdigest()

        with self._lock:
            completed = self._completed.get(operation_id)
            if completed is not None:
                if completed.checkpoint_digest != digest:
                    raise ValueError("operation_id was already completed with a different checkpoint")
                return completed
            operation_lock = self._inflight.get(operation_id)
            if operation_lock is None:
                operation_lock = threading.Lock()
                self._inflight[operation_id] = operation_lock

        with operation_lock:
            with self._lock:
                completed = self._completed.get(operation_id)
                if completed is not None:
                    if completed.checkpoint_digest != digest:
                        raise ValueError("operation_id was already completed with a different checkpoint")
                    return completed

            attempts = 0
            try:
                while attempts < self._max_attempts:
                    attempts += 1
                    try:
                        action()
                        record = RecoveryRecord(operation_id, digest, True, attempts)
                        with self._lock:
                            self._completed[operation_id] = record
                        return record
                    except Exception:
                        if attempts >= self._max_attempts:
                            return RecoveryRecord(operation_id, digest, False, attempts)
                raise AssertionError("unreachable")
            finally:
                with self._lock:
                    self._inflight.pop(operation_id, None)

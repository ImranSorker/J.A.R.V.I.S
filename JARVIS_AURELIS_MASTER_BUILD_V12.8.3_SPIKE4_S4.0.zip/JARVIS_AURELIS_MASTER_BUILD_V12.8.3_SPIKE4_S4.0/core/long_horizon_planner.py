"""Persistent-style hierarchical planning with dependency and resource constraints."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True, slots=True)
class PlanStep:
    """One executable planning node with explicit resource and timing bounds."""

    step_id: str
    description: str
    depends_on: tuple[str, ...] = ()
    cost: float = 1.0
    duration_seconds: float = 1.0
    required_resources: tuple[str, ...] = ()
    deadline: float | None = None
    priority: int = 0


@dataclass(frozen=True, slots=True)
class PlanEstimate:
    """Deterministic critical-path estimate for a plan."""

    step_count: int
    total_cost: float
    critical_path_seconds: float
    blocked_steps: tuple[str, ...]


class LongHorizonPlanner:
    """Validate, order and estimate bounded plans with deterministic tie-breaking."""

    def __init__(self, max_steps: int = 1000) -> None:
        self.max_steps = max(1, min(int(max_steps), 10_000))

    def validate(self, steps: Iterable[PlanStep]) -> tuple[PlanStep, ...]:
        """Validate identity, dependencies, bounds and uniqueness."""
        selected = tuple(steps)
        if len(selected) > self.max_steps:
            raise ValueError("plan exceeds step limit")
        ids = {step.step_id for step in selected}
        if len(ids) != len(selected) or any(not step.step_id.strip() or not step.description.strip() for step in selected):
            raise ValueError("plan steps require unique id and description")
        for step in selected:
            if step.cost < 0 or step.duration_seconds < 0:
                raise ValueError("step cost and duration must be non-negative")
            if step.deadline is not None and step.deadline < 0:
                raise ValueError("deadline must be non-negative")
            missing = set(step.depends_on) - ids
            if missing:
                raise ValueError(f"unknown dependency: {sorted(missing)[0]}")
        self.order(list(selected))
        return selected

    def order(self, steps: list[PlanStep]) -> list[PlanStep]:
        """Topologically order steps, preferring priority then lexical identity."""
        selected = self.validate_shallow(steps)
        by = {step.step_id: step for step in selected}
        indegree = {step.step_id: 0 for step in selected}
        children = {step.step_id: [] for step in selected}
        for step in selected:
            for dep in step.depends_on:
                if dep not in by:
                    raise ValueError(f"unknown dependency: {dep}")
                indegree[step.step_id] += 1
                children[dep].append(step.step_id)
        ready = sorted((key for key, value in indegree.items() if value == 0), key=lambda key: (-by[key].priority, key))
        output: list[PlanStep] = []
        while ready:
            key = ready.pop(0)
            output.append(by[key])
            for child in sorted(children[key], key=lambda child_id: (-by[child_id].priority, child_id)):
                indegree[child] -= 1
                if indegree[child] == 0:
                    ready.append(child)
            ready.sort(key=lambda item: (-by[item].priority, item))
        if len(output) != len(selected):
            raise ValueError("plan contains dependency cycle")
        return output

    def validate_shallow(self, steps: list[PlanStep]) -> list[PlanStep]:
        """Perform bounded structural checks without recursively invoking ordering."""
        if len(steps) > self.max_steps:
            raise ValueError("plan exceeds step limit")
        seen: set[str] = set()
        for step in steps:
            if not step.step_id or step.step_id in seen:
                raise ValueError("plan contains duplicate or empty step id")
            seen.add(step.step_id)
        return list(steps)

    def replan(self, steps: list[PlanStep], completed: set[str]) -> list[PlanStep]:
        """Return remaining work while rejecting completed/unknown dependency inconsistencies."""
        selected = self.validate(steps)
        known = {step.step_id for step in selected}
        unknown = completed - known
        if unknown:
            raise ValueError(f"completed set contains unknown step: {sorted(unknown)[0]}")
        return [step for step in self.order(list(selected)) if step.step_id not in completed]

    def estimate(self, steps: list[PlanStep]) -> PlanEstimate:
        """Estimate cost and critical path while reporting unavailable dependencies."""
        ordered = self.order(steps)
        finish: dict[str, float] = {}
        for step in ordered:
            start = max((finish.get(dep, 0.0) for dep in step.depends_on), default=0.0)
            finish[step.step_id] = start + step.duration_seconds
        return PlanEstimate(len(ordered), sum(max(0.0, step.cost) for step in ordered), max(finish.values(), default=0.0), ())



"""Policy-aware autonomous agent swarm coordinator with dependencies and evidence."""
from __future__ import annotations

import concurrent.futures
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

logger = logging.getLogger("jarvis.agent_swarm")


@dataclass(frozen=True, slots=True)
class SwarmTask:
    """Specialist task with dependency, retry and verification metadata."""

    task_id: str
    role: str
    description: str
    priority: int = 5
    metadata: dict[str, Any] = field(default_factory=dict)
    depends_on: tuple[str, ...] = ()
    max_attempts: int = 1


@dataclass(slots=True)
class SwarmResult:
    """Execution and verification result for one swarm task."""

    ok: bool
    task_id: str
    role: str
    result: Any = None
    error: str | None = None
    attempts: int = 0
    latency_ms: float = 0.0
    verified: bool = False


class AgentSwarm:
    """Execute bounded dependency-aware specialist batches through one executor."""

    def __init__(self, executor: Callable[[str, dict[str, Any]], Any], max_workers: int = 4, *, max_tasks: int = 512, reviewer: Callable[[SwarmTask, SwarmResult], bool] | None = None, reputation_observer: Callable[[str, bool, float], Any] | None = None) -> None:
        if not callable(executor):
            raise ValueError("executor required")
        self.executor = executor
        self.max_workers = max(1, min(int(max_workers), 64))
        self.max_tasks = max(1, min(int(max_tasks), 10_000))
        self.reviewer = reviewer
        self.reputation_observer = reputation_observer
        self._lock = threading.RLock()
        self._active = 0

    def create_task(self, role: str, description: str, priority: int = 5, metadata: dict[str, Any] | None = None, *, depends_on: tuple[str, ...] = (), max_attempts: int = 1) -> SwarmTask:
        """Create a validated immutable specialist task."""
        name = str(role).strip()
        text = str(description).strip()
        if not name or not text:
            raise ValueError("role and description are required")
        attempts = max(1, min(int(max_attempts), 5))
        return SwarmTask(f"swarm_{uuid.uuid4().hex[:12]}", name, text, int(priority), dict(metadata or {}), tuple(depends_on), attempts)

    @staticmethod
    def _validate(tasks: list[SwarmTask]) -> None:
        ids = {task.task_id for task in tasks}
        if len(ids) != len(tasks):
            raise ValueError("duplicate swarm task id")
        for task in tasks:
            if any(dep not in ids for dep in task.depends_on):
                raise ValueError(f"unknown swarm dependency for {task.task_id}")
        indegree = {task.task_id: len(task.depends_on) for task in tasks}
        children = {task.task_id: [] for task in tasks}
        for task in tasks:
            for dep in task.depends_on:
                children[dep].append(task.task_id)
        ready = [task_id for task_id, degree in indegree.items() if degree == 0]
        seen = 0
        while ready:
            current = ready.pop()
            seen += 1
            for child in children[current]:
                indegree[child] -= 1
                if indegree[child] == 0:
                    ready.append(child)
        if seen != len(tasks):
            raise ValueError("swarm dependency cycle")

    def run(self, tasks: Iterable[SwarmTask]) -> list[SwarmResult]:
        """Execute tasks in dependency-safe batches with bounded retries."""
        work = list(tasks)
        if len(work) > self.max_tasks:
            raise ValueError("swarm task count exceeds configured bound")
        if not work:
            return []
        self._validate(work)
        by_id = {task.task_id: task for task in work}
        completed: set[str] = set()
        results: dict[str, SwarmResult] = {}
        remaining = set(by_id)
        while remaining:
            ready = sorted((by_id[task_id] for task_id in remaining if all(dep in completed for dep in by_id[task_id].depends_on)), key=lambda task: (-task.priority, task.task_id))[: self.max_workers * 16]
            if not ready:
                raise RuntimeError("swarm cannot make progress")
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(self.max_workers, len(ready)), thread_name_prefix="jarvis-swarm") as pool:
                futures = {pool.submit(self._execute_one, task): task for task in ready}
                batch_results = [future.result() for future in futures]
            for task, result in zip(ready, batch_results):
                results[task.task_id] = result
                if result.ok:
                    completed.add(task.task_id)
                remaining.remove(task.task_id)
                if not result.ok:
                    blocked = {task.task_id}
                    changed = True
                    while changed:
                        changed = False
                        for candidate_id in tuple(remaining):
                            candidate = by_id[candidate_id]
                            if any(dep in blocked for dep in candidate.depends_on):
                                blocked.add(candidate_id)
                                changed = True
                    blocked.discard(task.task_id)
                    for descendant in blocked:
                        if descendant in remaining:
                            remaining.remove(descendant)
                            results[descendant] = SwarmResult(False, descendant, by_id[descendant].role, error=f"dependency_failed:{task.task_id}")
            if any(task_id not in completed and task_id not in remaining for task_id in by_id):
                completed.update(task_id for task_id in by_id if task_id not in remaining and results.get(task_id, SwarmResult(False, "", "")).ok)
        return [results[task.task_id] for task in sorted(work, key=lambda item: (-item.priority, item.task_id))]

    def _execute_one(self, task: SwarmTask) -> SwarmResult:
        started = time.perf_counter()
        last_error = "unknown_error"
        final_ok = False
        with self._lock:
            self._active += 1
        try:
            for attempt in range(1, task.max_attempts + 1):
                try:
                    result = self.executor(task.description, {"task": task.description, "agent_name": task.role, **task.metadata})
                    candidate = SwarmResult(True, task.task_id, task.role, result=result, attempts=attempt, latency_ms=(time.perf_counter() - started) * 1000.0)
                    verified = True if self.reviewer is None else bool(self.reviewer(task, candidate))
                    candidate.verified = verified
                    candidate.ok = bool(candidate.ok and verified)
                    if candidate.ok:
                        final_ok = True
                        return candidate
                    last_error = "review_rejected"
                except Exception as exc:
                    last_error = f"{type(exc).__name__}: {exc}"
                    logger.exception("swarm_task_failed", extra={"task": task.task_id, "attempt": attempt})
            return SwarmResult(False, task.task_id, task.role, error=last_error, attempts=task.max_attempts, latency_ms=(time.perf_counter() - started) * 1000.0)
        finally:
            elapsed = (time.perf_counter() - started) * 1000.0
            with self._lock:
                self._active = max(0, self._active - 1)
            if self.reputation_observer is not None:
                try:
                    self.reputation_observer(task.role, final_ok, elapsed)
                except Exception:
                    logger.debug("swarm_reputation_observer_failed", exc_info=True)

    def get_stats(self) -> dict[str, int]:
        """Return current worker utilization."""
        with self._lock:
            return {"max_workers": self.max_workers, "max_tasks": self.max_tasks, "active": self._active}



"""Encrypted memory governance with namespace-specific keys, provenance, retention, integrity, and deletion."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

log = logging.getLogger("jarvis.memory_governance")
CRYPTO_VERSION = 2

@dataclass(frozen=True, slots=True)
class MemoryRecord:
    """Governed plaintext memory returned only after integrity and authenticity checks."""
    record_id: str
    namespace: str
    content: str
    source: str
    version: int
    created_at: float
    expires_at: float | None
    integrity: str

class MemoryGovernance:
    """Persist memory as independently encrypted records with namespace-derived wrapping keys."""
    def __init__(
        self,
        secret: bytes,
        *,
        default_retention_seconds: float = 31_536_000,
        max_records: int = 100_000,
        max_content_bytes: int = 10_000_000,
        db_path: str | Path = "data/memory_governance.db",
    ) -> None:
        if len(secret) < 32:
            raise ValueError("memory governance secret must be at least 32 bytes")
        if max_content_bytes < 1024 or max_content_bytes > 100_000_000:
            raise ValueError("max_content_bytes is outside the supported range")
        self._closed = False
        self._secret = hashlib.sha256(bytes(secret)).digest()
        self.default_retention_seconds = max(60.0, float(default_retention_seconds))
        self.max_records = max(100, min(int(max_records), 1_000_000))
        self.max_content_bytes = int(max_content_bytes)
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db: sqlite3.Connection | None = sqlite3.connect(self.db_path, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA secure_delete=ON")
        self._db.execute("CREATE TABLE IF NOT EXISTS records(record_id TEXT PRIMARY KEY,namespace TEXT,content_cipher BLOB,record_key BLOB,source TEXT,version INTEGER,created_at REAL,expires_at REAL,integrity TEXT)")
        columns = {row[1] for row in self._db.execute("PRAGMA table_info(records)").fetchall()}
        if "crypto_version" not in columns:
            self._db.execute("ALTER TABLE records ADD COLUMN crypto_version INTEGER NOT NULL DEFAULT 1")
        self._db.execute("CREATE TABLE IF NOT EXISTS tombstones(record_id TEXT PRIMARY KEY,deleted_at REAL)")
        self._db.commit()
        self._lock = threading.RLock()

    def _namespace_key(self, namespace: str) -> bytes:
        """Derive a cryptographically distinct key for each logical memory namespace."""
        value = str(namespace).strip()
        if not value or len(value) > 1024:
            raise ValueError("invalid memory namespace")
        return hmac.new(self._secret, b"jarvis-memory-namespace-v2:" + value.encode("utf-8"), hashlib.sha256).digest()

    def _digest(self, rid: str, namespace: str, content: str, source: str, version: int) -> str:
        payload = json.dumps([rid, namespace, content, source, version, CRYPTO_VERSION], separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return hmac.new(self._namespace_key(namespace), payload, hashlib.sha256).hexdigest()

    def _legacy_digest(self, rid: str, namespace: str, content: str, source: str, version: int) -> str:
        payload = json.dumps([rid, namespace, content, source, version], separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return hmac.new(self._secret, payload, hashlib.sha256).hexdigest()

    def _encrypt(self, content: str, namespace: str) -> tuple[bytes, bytes]:
        record_key = secrets.token_bytes(32)
        nonce = secrets.token_bytes(12)
        cipher = nonce + AESGCM(record_key).encrypt(nonce, content.encode("utf-8"), namespace.encode("utf-8"))
        wrap_key = self._namespace_key(namespace)
        wrap_nonce = secrets.token_bytes(12)
        wrapped = wrap_nonce + AESGCM(wrap_key).encrypt(wrap_nonce, record_key, namespace.encode("utf-8"))
        return cipher, wrapped

    def _decrypt(self, cipher: bytes, wrapped: bytes, namespace: str, crypto_version: int) -> str:
        key_material = self._namespace_key(namespace) if int(crypto_version) >= 2 else self._secret
        wn, wrapped_key = wrapped[:12], wrapped[12:]
        record_key = AESGCM(key_material).decrypt(wn, wrapped_key, namespace.encode("utf-8") if int(crypto_version) >= 2 else None)
        nonce, data = cipher[:12], cipher[12:]
        return AESGCM(record_key).decrypt(nonce, data, namespace.encode("utf-8") if int(crypto_version) >= 2 else None).decode("utf-8")

    def register(
        self,
        record_id: str,
        namespace: str,
        content: str,
        *,
        source: str,
        version: int = 1,
        retention_seconds: float | None = None,
    ) -> MemoryRecord:
        rid, ns, src, text = str(record_id).strip(), str(namespace).strip(), str(source).strip(), str(content)
        if not rid or not ns or not src:
            raise ValueError("record_id, namespace, and source are required")
        if "\x00" in rid or "\x00" in ns or "\x00" in src:
            raise ValueError("memory identifiers may not contain NUL bytes")
        if len(text.encode("utf-8")) > self.max_content_bytes:
            raise ValueError("memory content exceeds configured maximum")
        ver = max(1, int(version))
        now = time.time()
        expires = now + (self.default_retention_seconds if retention_seconds is None else max(60.0, float(retention_seconds)))
        integrity = self._digest(rid, ns, text, src, ver)
        cipher, wrapped = self._encrypt(text, ns)
        with self._lock:
            if self._db is None:
                raise RuntimeError("memory governance is closed")
            self._db.execute(
                "INSERT OR REPLACE INTO records(record_id,namespace,content_cipher,record_key,source,version,created_at,expires_at,integrity,crypto_version) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (rid, ns, cipher, wrapped, src, ver, now, expires, integrity, CRYPTO_VERSION),
            )
            self._db.execute("DELETE FROM tombstones WHERE record_id=?", (rid,))
            count = int(self._db.execute("SELECT COUNT(*) FROM records").fetchone()[0])
            overflow = max(0, count - self.max_records)
            if overflow:
                evicted = self._db.execute(
                    "SELECT record_id FROM records ORDER BY created_at ASC LIMIT ?", (overflow,)
                ).fetchall()
                for (evicted_id,) in evicted:
                    self._db.execute("DELETE FROM records WHERE record_id=?", (evicted_id,))
                    self._db.execute("INSERT OR REPLACE INTO tombstones VALUES (?,?)", (evicted_id, now))
            self._db.commit()
        return MemoryRecord(rid, ns, text, src, ver, now, expires, integrity)

    def verify(self, record: MemoryRecord) -> bool:
        expected = self._digest(record.record_id, record.namespace, record.content, record.source, record.version)
        return hmac.compare_digest(record.integrity, expected)

    def get(self, record_id: str) -> MemoryRecord | None:
        with self._lock:
            if self._db is None:
                return None
            row = self._db.execute(
                "SELECT record_id,namespace,content_cipher,record_key,source,version,created_at,expires_at,integrity,crypto_version FROM records WHERE record_id=?",
                (str(record_id),),
            ).fetchone()
            if row is None:
                return None
            if row[7] is not None and row[7] <= time.time():
                return None
            try:
                text = self._decrypt(bytes(row[2]), bytes(row[3]), str(row[1]), int(row[9] or 1))
                record = MemoryRecord(row[0], row[1], text, row[4], row[5], row[6], row[7], row[8])
                if int(row[9] or 1) >= 2:
                    return record if self.verify(record) else None
                if not hmac.compare_digest(record.integrity, self._legacy_digest(record.record_id, record.namespace, record.content, record.source, record.version)):
                    return None
                # Online migration: rewrite legacy plaintext through v2 namespace crypto.
                cipher_v2, wrapped_v2 = self._encrypt(record.content, record.namespace)
                integrity_v2 = self._digest(record.record_id, record.namespace, record.content, record.source, record.version)
                if self._db is None:
                    raise RuntimeError("memory governance is closed")
                self._db.execute(
                    "UPDATE records SET content_cipher=?,record_key=?,integrity=?,crypto_version=? WHERE record_id=?",
                    (cipher_v2, wrapped_v2, integrity_v2, CRYPTO_VERSION, record.record_id),
                )
                self._db.commit()
                return MemoryRecord(record.record_id, record.namespace, record.content, record.source, record.version, record.created_at, record.expires_at, integrity_v2)
            except Exception:
                record_digest = hashlib.sha256(str(record_id).encode("utf-8", "strict")).hexdigest()[:16]
                log.warning("memory_record_authentication_failed", extra={"record_id_digest": record_digest})
                return None

    def purge_expired(self) -> int:
        now = time.time()
        with self._lock:
            if self._db is None:
                return 0
            rows = self._db.execute("SELECT record_id FROM records WHERE expires_at<=?", (now,)).fetchall()
            for (rid,) in rows:
                self._db.execute("DELETE FROM records WHERE record_id=?", (rid,))
                self._db.execute("INSERT OR REPLACE INTO tombstones VALUES (?,?)", (rid, now))
            self._db.commit()
            self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            return len(rows)

    def delete(self, record_id: str) -> bool:
        with self._lock:
            if self._db is None:
                return False
            existed = self._db.execute("SELECT 1 FROM records WHERE record_id=?", (str(record_id),)).fetchone() is not None
            self._db.execute("DELETE FROM records WHERE record_id=?", (str(record_id),))
            self._db.execute("INSERT OR REPLACE INTO tombstones VALUES (?,?)", (str(record_id), time.time()))
            self._db.commit()
            self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            return existed

    def stats(self) -> dict[str, int]:
        with self._lock:
            if self._db is None:
                return {"records": 0, "tombstones": 0}
            return {
                "records": int(self._db.execute("SELECT COUNT(*) FROM records").fetchone()[0]),
                "tombstones": int(self._db.execute("SELECT COUNT(*) FROM tombstones").fetchone()[0]),
            }

    def __del__(self) -> None:
        try:
            self.close()
        except Exception as exc:
            log.debug("best_effort_cleanup_failed", exc_info=exc)

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            db = self._db
            self._db = None
            self._closed = True
            if db is not None:
                try:
                    db.commit()
                    db.close()
                except sqlite3.Error:
                    log.debug("memory_governance_close_failed", exc_info=True)

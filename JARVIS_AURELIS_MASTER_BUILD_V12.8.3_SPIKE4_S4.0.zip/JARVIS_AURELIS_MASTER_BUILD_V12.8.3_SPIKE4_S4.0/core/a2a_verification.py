"""P2-N Agent-to-Agent Verification security fabric.

P2-N is an enforcement layer around P2-M. It never grants authority; it verifies
identity, capability, policy and authorization before a wrapped P2-M operation
is admitted. Decisions and evidence are immutable, signed artifacts.
"""
from __future__ import annotations

import copy
import hashlib
import sqlite3
import json
import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

VERSION = "12.8.3"
KERNEL_ID = "kernel-12.8.0"
VERIFICATION_VERSION = 1
logger = logging.getLogger(__name__)
VERIFICATION_METHOD_VERSION = "1.0.0"
SKEW_SECONDS = 120.0
REPLAY_TTL_SECONDS = 900.0

TARGETS = frozenset({
    "agent_identity", "agent_capability", "agent_authorization", "message_integrity",
    "delegation_legitimacy", "delegation_narrowing", "result_integrity", "result_correctness",
    "result_consistency", "trust_boundary", "collusion_signal",
})
METHODS = frozenset({
    "signature_check", "registry_lookup", "policy_evaluation", "schema_validation",
    "provenance_chain", "cross_reference", "independent_recompute", "independent_model",
    "simulation_replay", "statistical_analysis", "human_escalation",
})
OUTCOMES = frozenset({"verified", "denied", "inconclusive", "contradicted", "escalated", "insufficient_evidence", "replayed", "expired"})
SEVERITIES = frozenset({"critical", "high", "medium", "low"})
DECISIONS = frozenset({"allow", "block", "escalate", "quarantine_recommend"})

EVENTS = {
    "requested": "Agent.Verification.Requested",
    "identity_verified": "Agent.Verification.IdentityVerified",
    "identity_denied": "Agent.Verification.IdentityDenied",
    "capability_verified": "Agent.Verification.CapabilityVerified",
    "capability_denied": "Agent.Verification.CapabilityDenied",
    "authorization_granted": "Agent.Verification.AuthorizationGranted",
    "authorization_denied": "Agent.Verification.AuthorizationDenied",
    "message_verified": "Agent.Verification.MessageVerified",
    "message_denied": "Agent.Verification.MessageDenied",
    "message_replayed": "Agent.Verification.MessageReplayed",
    "delegation_verified": "Agent.Verification.DelegationVerified",
    "delegation_denied": "Agent.Verification.DelegationDenied",
    "delegation_widened": "Agent.Verification.DelegationWidened",
    "result_verified": "Agent.Verification.ResultVerified",
    "result_denied": "Agent.Verification.ResultDenied",
    "result_contradicted": "Agent.Verification.ResultContradicted",
    "compromised": "Agent.Verification.Compromised",
    "peer_unavailable": "Agent.Verification.PeerUnavailable",
    "malformed_result": "Agent.Verification.MalformedResult",
    "capability_exceeded": "Agent.Verification.CapabilityExceeded",
    "privilege_escalation": "Agent.Verification.PrivilegeEscalationAttempt",
    "unauthorized_tool": "Agent.Verification.UnauthorizedToolUse",
    "disagreement": "Agent.Verification.Disagreement",
    "escalated": "Agent.Verification.Escalated",
    "replay_divergence": "Agent.Verification.ReplayDivergence",
    "collusion_signal": "Agent.Verification.CollusionSignalRaised",
}

class A2AVerificationError(RuntimeError):
    """Base P2-N enforcement failure."""

class VerificationDenied(A2AVerificationError, PermissionError):
    """Verification failed closed."""

class ReplayRejected(VerificationDenied):
    """Interaction was replayed."""

class DelegationExpansionRejected(VerificationDenied):
    """Delegation widened authority."""


def _now() -> float:
    return time.time()


def _rfc3339(value: float | None = None) -> str:
    return datetime.fromtimestamp(_now() if value is None else float(value), tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_time(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str) or not value.strip():
        raise ValueError("timestamp is required")
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def _uuid(value: Any) -> str:
    return str(uuid.UUID(str(value)))


def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def _sign(value: Mapping[str, Any], key: Ed25519PrivateKey) -> tuple[str, str]:
    body = dict(value)
    body.pop("signature", None)
    body.pop("integrity_hash", None)
    digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
    signed = dict(body)
    signed["integrity_hash"] = digest
    signature = key.sign(canonical_json(signed))
    import base64
    return base64.b64encode(signature).decode("ascii"), digest


def _verify(value: Mapping[str, Any], signature: str, public_key: Ed25519PublicKey) -> bool:
    import base64
    try:
        body = dict(value)
        body.pop("signature", None)
        body.pop("integrity_hash", None)
        digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
        expected = str(value.get("integrity_hash", ""))
        if digest != expected:
            return False
        signed = dict(body)
        signed["integrity_hash"] = digest
        public_key.verify(base64.b64decode(signature, validate=True), canonical_json(signed))
        return True
    except (ValueError, TypeError, InvalidSignature):
        return False


def _subset(child: Iterable[str], parent: Iterable[str]) -> bool:
    return set(map(str, child)).issubset(set(map(str, parent)))


def _budget_leq(child: Mapping[str, Any], parent: Mapping[str, Any]) -> bool:
    for key in ("wall_seconds", "cpu_seconds", "ram_mb", "vram_mb", "network_bytes", "tool_calls", "api_calls", "tokens_in", "tokens_out"):
        if float(child.get(key, 0)) > float(parent.get(key, 0)):
            return False
    return True


@dataclass(frozen=True, slots=True)
class VerificationRecord:
    document: dict[str, Any]
    signature: str
    integrity_hash: str

    def to_dict(self) -> dict[str, Any]:
        return copy.deepcopy(self.document) | {"signature": self.signature, "integrity_hash": self.integrity_hash}


class A2AVerificationFabric:
    """Independent verification fabric bound to one real P2-M orchestration instance."""

    DETECTORS = (
        "mutual_elevation", "paired_challenges", "closed_loop", "same_model_family",
        "knowledge_overshare", "delegation_ping_pong", "synchronized_timing", "evidence_recycling", "anomalous_consensus",
    )

    def __init__(
        self,
        orchestration: Any,
        *,
        root: str | Path | None = None,
        authorization_verifier: Callable[[Mapping[str, Any], str, str], bool] | None = None,
        security_authority: Any | None = None,
        policy_evaluator: Callable[[Mapping[str, Any]], bool] | None = None,
        world_state_resolver: Callable[[str], Mapping[str, Any] | None] | None = None,
        memory_resolver: Callable[[str], Mapping[str, Any] | None] | None = None,
        independent_recompute: Callable[[Mapping[str, Any]], Any] | None = None,
        simulation_replay: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
        independent_model_verify: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
        time_provider: Callable[[], float] | None = None,
    ) -> None:
        self.orchestration = orchestration
        self.root = Path(root or "./data/a2a_verification").resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.authorization_verifier = authorization_verifier or getattr(orchestration, "authorization_verifier", None)
        self.security_authority = security_authority
        self.policy_evaluator = policy_evaluator
        self.world_state_resolver = world_state_resolver
        self.memory_resolver = memory_resolver
        self.independent_recompute = independent_recompute
        self.simulation_replay = simulation_replay
        self.independent_model_verify = independent_model_verify
        self._time = time_provider or _now
        self._signer = Ed25519PrivateKey.generate()
        self._public = self._signer.public_key()
        raw = self._public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.key_id = hashlib.sha256(raw).hexdigest()[:16]
        self._lock = threading.RLock()
        self._requests: dict[str, dict[str, Any]] = {}
        self._records: dict[str, VerificationRecord] = {}
        self._request_by_hash: dict[str, str] = {}
        self._replay: dict[str, dict[str, float]] = defaultdict(dict)
        self._replay_db = sqlite3.connect(str(self.root / "verification_replay.db"), check_same_thread=False, isolation_level=None)
        self._replay_db.execute("CREATE TABLE IF NOT EXISTS replay_ledger (tenant_id TEXT NOT NULL, kind TEXT NOT NULL, identifier TEXT NOT NULL, expires_at REAL NOT NULL, used_at REAL NOT NULL, PRIMARY KEY(tenant_id, kind, identifier))")
        self._events: list[dict[str, Any]] = []
        self._detector_config = {d: {"version": "1.0.0", "window": 64, "threshold": 3} for d in self.DETECTORS}
        self._detector_window: deque[dict[str, Any]] = deque(maxlen=512)
        self._verification_edges: dict[str, set[str]] = defaultdict(set)
        self._genome_registry: dict[str, Any] = {}
        self._authority_cache: dict[str, tuple[float, dict[str, Any]]] = {}

    def close(self) -> None:
        with self._lock:
            if self._replay_db is not None:
                self._replay_db.close()
                self._replay_db = None

    @property
    def public_key(self) -> Ed25519PublicKey:
        return self._public

    @property
    def verification_events(self) -> tuple[dict[str, Any], ...]:
        return tuple(copy.deepcopy(self._events))

    def register_genome(self, genome: Any, tenant_id: str) -> None:
        ref = f"{genome.agent_uuid}@{genome.genome_version}"
        if not genome.verify():
            raise VerificationDenied("cannot register an unsigned or invalid genome")
        self._genome_registry[(str(tenant_id), ref)] = genome

    def _emit(self, key: str, tenant_id: str, correlation_id: str | None, causation_id: str | None, payload: Mapping[str, Any]) -> None:
        event = {"event_id": str(uuid.uuid4()), "event_type_name": EVENTS[key], "tenant_id": str(tenant_id), "correlation_id": correlation_id, "causation_id": causation_id, "timestamp": _rfc3339(self._time()), "payload": copy.deepcopy(dict(payload)), "producer": "a2a-verification", "key_id": self.key_id}
        body = dict(event); event["integrity_hash"] = _sha(body); body["integrity_hash"] = event["integrity_hash"]
        import base64
        event["signature"] = base64.b64encode(self._signer.sign(canonical_json(body))).decode("ascii")
        self._events.append(event)
        fabric = getattr(self.orchestration, "event_fabric", None)
        if fabric is None:
            return
        # Event Fabric remains transport only; P2-N's local signed event is the authoritative audit artifact.
        try:
            from core.event_fabric import EventEnvelope, AuthContext, EventLineage, ProducedBy
            et, en = EVENTS[key].split(".", 1)
            payload_schema = f"urn:jarvis:p2n:{key}:1.0.0"
            event_envelope = EventEnvelope.create(
                event_type=et, event_name=en, payload=dict(payload),
                produced_by=ProducedBy("system", "a2a-verification", self._sha(self.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)), "system"),
                auth_context=AuthContext("a2a-verification", ("events.publish.agent.verification",), None, None),
                tenant_id=str(tenant_id), partition_key=str(correlation_id or tenant_id), correlation_id=correlation_id or str(uuid.uuid4()),
                causation_id=causation_id, signing_key=self._signer,
            )
            # The released Event Fabric may reject taxonomy not present in its frozen JSON; local P2-N ledger is still durable.
            if hasattr(fabric, "publish_envelope"):
                try:
                    fabric.publish_envelope(event_envelope)
                except Exception:
                    logger.debug("P2-N Event Fabric publish failed; local signed event remains authoritative", exc_info=True)
        except Exception:
            logger.debug("P2-N Event Fabric envelope construction failed; local signed event remains authoritative", exc_info=True)

    def _tenant(self, team_id: str) -> str:
        team = self.orchestration.inspect_team(str(team_id))
        return str(team.tenant_id)

    def _profile(self, agent_ref: str, tenant_id: str) -> Any:
        p = getattr(self.orchestration, "_agents", {}).get(str(agent_ref))
        if p is None or str(p.tenant_id) != str(tenant_id):
            raise VerificationDenied("agent is unknown or cross-tenant")
        if not bool(getattr(p, "certified", False)) or str(getattr(p, "garage_state", "")) != "MONITORED":
            raise VerificationDenied("agent is not certified and monitored")
        return p

    def _replay_key(self, tenant: str, kind: str, identifier: str) -> str:
        self._prune_replay(tenant)
        return f"{kind}:{identifier}"

    def _prune_replay(self, tenant: str) -> None:
        now = self._time()
        rows = self._replay[str(tenant)]
        for key, expiry in list(rows.items()):
            if expiry <= now:
                rows.pop(key, None)
        if self._replay_db is not None:
            self._replay_db.execute("DELETE FROM replay_ledger WHERE expires_at <= ?", (now,))

    def _consume_replay(self, tenant: str, kind: str, identifier: str, ttl: float = REPLAY_TTL_SECONDS) -> None:
        key = self._replay_key(tenant, kind, identifier)
        now = self._time(); expiry = now + ttl
        if key in self._replay[str(tenant)]:
            raise ReplayRejected(f"replayed {kind}: {identifier}")
        if self._replay_db is None:
            raise ReplayRejected("verification replay ledger unavailable")
        try:
            self._replay_db.execute(
                "INSERT INTO replay_ledger(tenant_id,kind,identifier,expires_at,used_at) VALUES(?,?,?,?,?)",
                (str(tenant), str(kind), str(identifier), expiry, now),
            )
        except sqlite3.IntegrityError as exc:
            raise ReplayRejected(f"replayed {kind}: {identifier}") from exc
        self._replay[str(tenant)][key] = expiry

    def request_verification(self, spec: Mapping[str, Any]) -> str:
        target, method = str(spec.get("target")), str(spec.get("method"))
        if target not in TARGETS or method not in METHODS:
            raise VerificationDenied("unknown frozen verification taxonomy value")
        tenant = str(spec.get("tenant_id") or "")
        if not tenant:
            raise VerificationDenied("tenant_id required")
        verification_id = str(spec.get("verification_id") or uuid.uuid4())
        _uuid(verification_id)
        correlation_id = str(spec.get("correlation_id") or uuid.uuid4())
        _uuid(correlation_id)
        subject = str(spec.get("subject_agent_ref") or "")
        profile = getattr(self.orchestration, "_agents", {}).get(subject)
        genome_hash = str(spec.get("subject_genome_hash") or getattr(profile, "genome_hash", "0" * 64))
        body = copy.deepcopy(dict(spec))
        body.update({"verification_id": verification_id, "verification_version": VERIFICATION_VERSION, "tenant_id": tenant, "target": target, "method": method, "subject_agent_ref": subject, "subject_genome_hash": genome_hash, "subject_team_id": body.get("subject_team_id"), "subject_delegation_id": body.get("subject_delegation_id"), "subject_message_id": body.get("subject_message_id"), "subject_result_ref": body.get("subject_result_ref"), "claim": body.get("claim") or {"claim_kind": target, "claim_body_ref": f"{target}:{verification_id}", "claim_evidence_refs": list(body.get("claim_evidence_refs", ()))}, "execution_context_ref": body.get("execution_context_ref") or correlation_id, "policy_ref": str(body.get("policy_ref") or "policy:live"), "policy_version": str(body.get("policy_version") or "1.0.0"), "registry_state_ref": str(body.get("registry_state_ref") or "registry:live"), "correlation_id": correlation_id, "causation_id": body.get("causation_id"), "in_reply_to": body.get("in_reply_to"), "required_outcome": str(body.get("required_outcome") or "verified"), "fail_closed": bool(body.get("fail_closed", True)), "escalation_on": list(body.get("escalation_on", ())), "deadline": body.get("deadline") or _rfc3339(self._time() + REPLAY_TTL_SECONDS), "requested_by": body.get("requested_by") or {"principal": "a2a-verification", "key_id": self.key_id}, "requested_at": body.get("requested_at") or _rfc3339(self._time())})
        body.pop("signature", None); body.pop("integrity_hash", None)
        content_key = _sha({k: v for k, v in body.items() if k not in {"verification_id", "requested_at", "deadline"}})
        with self._lock:
            prior = self._request_by_hash.get(content_key)
            if prior:
                return prior
            self._consume_replay(tenant, "verification", verification_id)
            signature, digest = _sign(body, self._signer)
            body["signature"], body["integrity_hash"] = signature, digest
            self._requests[verification_id] = body
            self._request_by_hash[content_key] = verification_id
        self._emit("requested", tenant, body.get("correlation_id"), body.get("causation_id"), body)
        return verification_id

    def _record(self, request: Mapping[str, Any], *, target: str, method: str, outcome: str, severity: str,
                decision: str, checks: Sequence[Mapping[str, Any]], reason: Mapping[str, Any], evidence: Mapping[str, Any] | None = None,
                verifier_kind: str = "fabric", subject_agent_ref: str = "", subject_genome_hash: str = "", tenant_id: str = "") -> dict[str, Any]:
        if outcome not in OUTCOMES or severity not in SEVERITIES or decision not in DECISIONS:
            raise ValueError("invalid verification record enum")
        started = _rfc3339(self._time())
        document = {
            "record_id": str(uuid.uuid4()), "request_ref": str(request["verification_id"]),
            "subject_agent_ref": subject_agent_ref, "subject_genome_hash": subject_genome_hash,
            "tenant_id": tenant_id, "target": target, "method": method, "outcome": outcome,
            "severity_on_failure": severity,
            "evidence": {"checks": [dict(c) for c in checks], "contradictions": list((evidence or {}).get("contradictions", [])), "cross_references": list((evidence or {}).get("cross_references", [])), "independent_path_ref": (evidence or {}).get("independent_path_ref")},
            "confidence": float((evidence or {}).get("confidence", 1.0 if outcome == "verified" else 0.0)),
            "calibrated": bool((evidence or {}).get("calibrated", False)), "calibration_ref": (evidence or {}).get("calibration_ref"),
            "decision": decision, "reason": dict(reason), "escalation_ref": (evidence or {}).get("escalation_ref"),
            "verifier_identity": {"principal": "a2a-verification", "key_id": self.key_id}, "verifier_kind": verifier_kind,
            "verifier_model_family": (evidence or {}).get("verifier_model_family"), "registry_state_ref": str(request.get("registry_state_ref", "registry:live")),
            "policy_version": str(request.get("policy_version", "1.0.0")), "verification_method_version": VERIFICATION_METHOD_VERSION,
            "started_at": started, "finished_at": _rfc3339(self._time()), "correlation_id": request.get("correlation_id"), "causation_id": request.get("causation_id"),
        }
        signature, digest = _sign(document, self._signer)
        record = VerificationRecord(document, signature, digest)
        with self._lock:
            self._records[record.document["record_id"]] = record
            self._detector_window.append(record.to_dict())
        event_key = "identity_verified" if target == "agent_identity" and decision == "allow" else "identity_denied" if target == "agent_identity" else "delegation_verified" if target.startswith("delegation") and decision == "allow" else "delegation_denied" if target.startswith("delegation") else "result_verified" if target.startswith("result") and decision == "allow" else "result_denied" if target.startswith("result") else "message_verified" if target == "message_integrity" and decision == "allow" else "message_denied" if target == "message_integrity" else "collusion_signal" if target == "collusion_signal" else "requested"
        if outcome == "replayed": event_key = "message_replayed"
        if outcome == "contradicted": event_key = "result_contradicted"
        self._emit(event_key, tenant_id, str(request.get("correlation_id")), str(request.get("causation_id")) if request.get("causation_id") else None, record.to_dict())
        return record.to_dict()

    def verify_identity(self, subject_agent_ref: str, registry_state_ref: str = "registry:live", *, tenant_id: str | None = None, correlation_id: str | None = None) -> dict[str, Any]:
        tenant = str(tenant_id or "")
        if not tenant:
            profile = getattr(self.orchestration, "_agents", {}).get(str(subject_agent_ref))
            tenant = str(getattr(profile, "tenant_id", ""))
        request_id = self.request_verification({"tenant_id": tenant, "target": "agent_identity", "method": "registry_lookup", "subject_agent_ref": subject_agent_ref, "registry_state_ref": registry_state_ref, "correlation_id": correlation_id or str(uuid.uuid4())})
        req = self._requests[request_id]
        try:
            profile = self._profile(subject_agent_ref, tenant)
            genome = self._genome_registry.get((tenant, str(subject_agent_ref)))
            checks = [{"check": "registry_lookup", "passed": True}, {"check": "tenant_binding", "passed": True}, {"check": "certification", "passed": bool(profile.certified)}]
            if genome is not None:
                passed = bool(genome.verify()) and str(genome.hash()) == str(profile.genome_hash)
                checks.append({"check": "genome_signature", "passed": passed})
                if not passed:
                    raise VerificationDenied("registered genome signature or hash mismatch")
            else:
                checks.append({"check": "genome_registry", "passed": False, "reason": "raw genome unavailable"})
                raise VerificationDenied("independent genome verification unavailable")
            return self._record(req, target="agent_identity", method="registry_lookup", outcome="verified", severity="critical", decision="allow", checks=checks, reason={"code": "IDENTITY_VERIFIED"}, subject_agent_ref=str(subject_agent_ref), subject_genome_hash=str(profile.genome_hash), tenant_id=tenant)
        except VerificationDenied as exc:
            return self._record(req, target="agent_identity", method="registry_lookup", outcome="denied", severity="critical", decision="block", checks=[{"check": "identity", "passed": False}], reason={"code": "IDENTITY_DENIED", "detail": str(exc)}, tenant_id=tenant, subject_agent_ref=str(subject_agent_ref))

    def verify_capability(self, subject_agent_ref: str, capability: str, registry_state_ref: str = "registry:live", *, tenant_id: str | None = None, correlation_id: str | None = None) -> dict[str, Any]:
        tenant = str(tenant_id or getattr(getattr(self.orchestration, "_agents", {}).get(str(subject_agent_ref)), "tenant_id", ""))
        req_id = self.request_verification({"tenant_id": tenant, "target": "agent_capability", "method": "registry_lookup", "subject_agent_ref": subject_agent_ref, "registry_state_ref": registry_state_ref, "claim": {"claim_kind": "capability", "claim_body_ref": f"capability:{capability}"}, "correlation_id": correlation_id or str(uuid.uuid4())})
        req = self._requests[req_id]; profile = self._profile(subject_agent_ref, tenant)
        passed = str(capability) in profile.capabilities
        return self._record(req, target="agent_capability", method="registry_lookup", outcome="verified" if passed else "denied", severity="critical" if not passed else "medium", decision="allow" if passed else "block", checks=[{"check": "declared_capability", "passed": passed, "capability": capability}], reason={"code": "CAPABILITY_VERIFIED" if passed else "CAPABILITY_DENIED"}, subject_agent_ref=subject_agent_ref, subject_genome_hash=profile.genome_hash, tenant_id=tenant)

    def _verify_authority_token(self, token: Mapping[str, Any], tenant: str, capability: str, subject_agent_ref: str, target_agent_ref: str) -> bool:
        if self.authorization_verifier is not None:
            return bool(self.authorization_verifier(token, tenant, capability))
        authority = self.security_authority
        if authority is None:
            return False
        try:
            from core.zero_trust import CapabilityLease
            lease_data = token.get("lease") if isinstance(token.get("lease"), Mapping) else token
            lease = CapabilityLease(
                lease_id=str(lease_data["lease_id"]), subject=str(lease_data["subject"]), audience=str(lease_data["audience"]),
                capabilities=tuple(lease_data["capabilities"]), issued_at=float(lease_data["issued_at"]), expires_at=float(lease_data["expires_at"]),
                nonce=str(lease_data["nonce"]), policy_digest=str(lease_data["policy_digest"]), key_id=str(lease_data["key_id"]), signature_b64=str(lease_data["signature_b64"]),
            )
            return bool(authority.verify_lease(lease, subject=subject_agent_ref, audience=target_agent_ref, capability=capability, policy_digest=str(token.get("policy_digest", lease.policy_digest)), now=self._time(), consume_nonce=False))
        except Exception:
            return False

    def verify_authorization(self, subject_agent_ref: str, invocation_spec: Mapping[str, Any], policy_ref: str = "policy:live", *, tenant_id: str | None = None, correlation_id: str | None = None) -> dict[str, Any]:
        tenant = str(tenant_id or getattr(getattr(self.orchestration, "_agents", {}).get(str(subject_agent_ref)), "tenant_id", ""))
        target = str(invocation_spec.get("target_agent_ref") or invocation_spec.get("target") or "")
        capability = str(invocation_spec.get("capability") or "")
        token = dict(invocation_spec.get("authorization_token") or {})
        req_id = self.request_verification({"tenant_id": tenant, "target": "agent_authorization", "method": "policy_evaluation", "subject_agent_ref": subject_agent_ref, "policy_ref": policy_ref, "policy_version": invocation_spec.get("policy_version", "1.0.0"), "correlation_id": correlation_id or str(uuid.uuid4())})
        req = self._requests[req_id]
        checks: list[dict[str, Any]] = []
        try:
            self.verify_identity(subject_agent_ref, tenant_id=tenant, correlation_id=req.get("correlation_id"))
            cap = self.verify_capability(subject_agent_ref, capability, tenant_id=tenant, correlation_id=req.get("correlation_id"))
            if cap.get("decision") != "allow": raise VerificationDenied("capability step failed")
            required = ("authorization_ref", "expires_at", "subject_agent_ref", "target_agent_ref", "capability", "scope", "nonce", "signature", "key_id")
            missing = [key for key in required if not str(token.get(key, "")).strip()]
            if missing: raise VerificationDenied("authorization token missing: " + ",".join(missing))
            if str(token.get("tenant_id", tenant)) != tenant or str(token["subject_agent_ref"]) != subject_agent_ref or str(token["target_agent_ref"]) != target or str(token["capability"]) != capability:
                raise VerificationDenied("authorization token subject/target/capability binding failed")
            exp = _parse_time(token["expires_at"])
            if exp <= self._time(): raise VerificationDenied("authorization token expired")
            scope_hash = _sha(token.get("scope"))
            if str(token.get("scope_hash", scope_hash)) != scope_hash: raise VerificationDenied("authorization scope hash mismatch")
            self._consume_replay(tenant, "authorization", str(token["nonce"]))
            if not self._verify_authority_token(token, tenant, capability, subject_agent_ref, target):
                raise VerificationDenied("Security Authority did not positively verify the authorization token")
            if self.policy_evaluator is not None and not self.policy_evaluator(invocation_spec):
                raise VerificationDenied("policy evaluation denied invocation")
            checks.extend([{"check": "identity", "passed": True}, {"check": "capability", "passed": True}, {"check": "policy", "passed": True}, {"check": "authorization", "passed": True}, {"check": "single_use_nonce", "passed": True}])
            return self._record(req, target="agent_authorization", method="policy_evaluation", outcome="verified", severity="critical", decision="allow", checks=checks, reason={"code": "AUTHORIZATION_GRANTED"}, subject_agent_ref=subject_agent_ref, subject_genome_hash=getattr(self.orchestration._agents.get(subject_agent_ref), "genome_hash", ""), tenant_id=tenant)
        except VerificationDenied as exc:
            checks.append({"check": "authorization_chain", "passed": False, "reason": str(exc)})
            return self._record(req, target="agent_authorization", method="policy_evaluation", outcome="denied", severity="critical", decision="block", checks=checks, reason={"code": "AUTHORIZATION_DENIED", "detail": str(exc)}, subject_agent_ref=subject_agent_ref, tenant_id=tenant)

    def _message_record(self, message: Mapping[str, Any], tenant: str) -> dict[str, Any]:
        required = ("message_id", "team_id", "from_member", "to_member", "kind", "correlation_id", "payload", "evidence_refs", "claim_refs", "sent_at", "signature", "sender_key_id", "integrity_hash")
        checks = [{"check": key, "passed": key in message} for key in required]
        if any(not c["passed"] for c in checks):
            raise VerificationDenied("message missing required field(s)")
        _uuid(message["message_id"]); _uuid(message["team_id"]); _uuid(message["correlation_id"])
        sent = _parse_time(message["sent_at"])
        if abs(self._time() - sent) > SKEW_SECONDS: raise VerificationDenied("message timestamp outside skew window")
        self._consume_replay(tenant, "message", str(message["message_id"]))
        team = self.orchestration.inspect_team(str(message["team_id"]))
        member = team.member_index.get(str(message["from_member"]))
        if member is None: raise VerificationDenied("sender is not in team")
        profile = self._profile(member.agent_ref, tenant)
        if str(message.get("sender_key_id")) != hashlib.sha256(f"{getattr(self.orchestration, 'key_id', '')}:{member.member_id}:{member.agent_genome_hash}".encode()).hexdigest()[:16]:
            raise VerificationDenied("sender identity binding failed")
        signed = dict(message)
        expected_hash = _sha({k: v for k, v in signed.items() if k not in {"signature", "integrity_hash"}})
        if expected_hash != str(message.get("integrity_hash")): raise VerificationDenied("message integrity hash mismatch")
        body = {k: v for k, v in dict(message).items() if k != "signature"}; body["integrity_hash"] = expected_hash
        import base64
        try:
            pub = getattr(self.orchestration, "public_key")
            pub.verify(base64.b64decode(str(message["signature"]), validate=True), canonical_json(body))
        except Exception as exc:
            raise VerificationDenied("message signature verification failed") from exc
        recipients = message.get("to_member")
        targets = tuple(recipients) if isinstance(recipients, (list, tuple)) else (str(recipients),)
        if any(t not in team.member_index for t in targets): raise VerificationDenied("recipient outside team")
        if str(message.get("correlation_id")) not in {str(message.get("correlation_id"))}: raise VerificationDenied("invalid correlation")
        return self._record(self._requests[self.request_verification({"tenant_id": tenant, "target": "message_integrity", "method": "signature_check", "subject_agent_ref": member.agent_ref, "subject_message_id": message["message_id"], "correlation_id": message["correlation_id"]})], target="message_integrity", method="signature_check", outcome="verified", severity="high", decision="allow", checks=checks + [{"check": "signature", "passed": True}, {"check": "replay", "passed": True}, {"check": "tenant", "passed": True}], reason={"code": "MESSAGE_VERIFIED"}, subject_agent_ref=member.agent_ref, subject_genome_hash=profile.genome_hash, tenant_id=tenant)

    def verify_message(self, message_ref: Mapping[str, Any], registry_state_ref: str = "registry:live", *, tenant_id: str | None = None) -> dict[str, Any]:
        tenant = str(tenant_id or self._tenant(str(message_ref["team_id"])))
        try:
            return self._message_record(message_ref, tenant)
        except ReplayRejected as exc:
            req = {"verification_id": str(uuid.uuid4()), "tenant_id": tenant, "correlation_id": message_ref.get("correlation_id")}
            return self._record(req, target="message_integrity", method="signature_check", outcome="replayed", severity="high", decision="block", checks=[{"check": "replay", "passed": False}], reason={"code": "MESSAGE_REPLAYED", "detail": str(exc)}, tenant_id=tenant)
        except Exception as exc:
            req_id = self.request_verification({"tenant_id": tenant, "target": "message_integrity", "method": "signature_check", "subject_message_id": str(message_ref.get("message_id") or uuid.uuid4()), "correlation_id": str(message_ref.get("correlation_id") or uuid.uuid4())})
            req = self._requests[req_id]
            return self._record(req, target="message_integrity", method="signature_check", outcome="denied", severity="high", decision="block", checks=[{"check": "message", "passed": False, "detail": str(exc)}], reason={"code": "MESSAGE_DENIED", "detail": str(exc)}, tenant_id=tenant)

    def check_narrowing(self, delegation_contract: Any) -> dict[str, Any]:
        team = self.orchestration.inspect_team(str(delegation_contract.team_id))
        from_member = team.member_index[str(delegation_contract.from_member)]
        to_member = team.member_index[str(delegation_contract.to_member)]
        parent_profile = self._profile(from_member.agent_ref, team.tenant_id)
        delegate_profile = self._profile(to_member.agent_ref, team.tenant_id)
        authority = {"capabilities": sorted(parent_profile.capabilities), "scopes": sorted(parent_profile.scopes), "budget": parent_profile.budget.as_dict(), "tools": sorted(parent_profile.tools), "max_depth": int(parent_profile.delegation_depth_max)}
        delegated = {"capabilities": sorted(delegation_contract.delegated_capabilities), "scopes": sorted(delegation_contract.delegated_scopes), "budget": delegation_contract.delegated_budget.as_dict(), "tools": sorted(delegation_contract.delegated_tools or ()), "max_depth": int(delegation_contract.delegated_max_depth)}
        checks = {"capabilities_subset": _subset(delegated["capabilities"], authority["capabilities"]), "scopes_subset": _subset(delegated["scopes"], authority["scopes"]), "budget_bounded": _budget_leq(delegated["budget"], authority["budget"]), "tools_subset": _subset(delegated["tools"], authority["tools"]), "depth_narrowed": delegated["max_depth"] <= max(0, authority["max_depth"] - (1 if delegation_contract.parent_delegation_id else 0)), "delegatee_trust": getattr(delegate_profile, "trust_level", "untrusted") != "untrusted"}
        effective = {"capabilities": sorted(set(authority["capabilities"]).intersection(delegated["capabilities"]).intersection(delegate_profile.capabilities)), "scopes": sorted(set(authority["scopes"]).intersection(delegated["scopes"]).intersection(delegate_profile.scopes)), "tools": sorted(set(authority["tools"]).intersection(delegated["tools"]).intersection(delegate_profile.tools)), "budget": {k: min(float(authority["budget"][k]), float(delegated["budget"][k])) for k in authority["budget"]}, "max_depth": min(authority["max_depth"], delegated["max_depth"], delegate_profile.delegation_depth_max)}
        return {"delegation_id": delegation_contract.delegation_id, "checks": checks, "effective_authority": effective, "allowed": all(checks.values())}

    def verify_delegation(self, delegation_id: str, registry_state_ref: str = "registry:live") -> dict[str, Any]:
        d = getattr(self.orchestration, "_delegations", {}).get(str(delegation_id))
        if d is None: raise VerificationDenied("unknown delegation")
        tenant = self._tenant(d.team_id)
        try:
            self._consume_replay(tenant, "delegation", d.delegation_id)
        except ReplayRejected as exc:
            return self._record({"verification_id": str(uuid.uuid4()), "tenant_id": tenant, "correlation_id": d.correlation_id}, target="delegation_legitimacy", method="registry_lookup", outcome="replayed", severity="high", decision="block", checks=[{"check": "replay", "passed": False}], reason={"code": "DELEGATION_REPLAYED", "detail": str(exc)}, tenant_id=tenant)
        team = self.orchestration.inspect_team(d.team_id)
        fm = team.member_index.get(d.from_member); tm = team.member_index.get(d.to_member)
        if fm is None or tm is None: allowed = False; reason = "delegation member missing"; narrowing = {"allowed": False}
        else:
            parent_identity = self.verify_identity(fm.agent_ref, tenant_id=tenant, correlation_id=d.correlation_id)
            delegate_identity = self.verify_identity(tm.agent_ref, tenant_id=tenant, correlation_id=d.correlation_id)
            narrowing = self.check_narrowing(d)
            allowed = parent_identity.get("decision") == "allow" and delegate_identity.get("decision") == "allow" and bool(narrowing["allowed"])
            reason = "ok" if allowed else "delegation widening or identity failure"
        req_id = self.request_verification({"tenant_id": tenant, "target": "delegation_narrowing", "method": "registry_lookup", "subject_agent_ref": fm.agent_ref if fm else "", "subject_delegation_id": d.delegation_id, "registry_state_ref": registry_state_ref, "correlation_id": d.correlation_id})
        req = self._requests[req_id]
        if not allowed:
            self._emit("delegation_widened", tenant, d.correlation_id, None, {"delegation_id": d.delegation_id, "reason": reason})
        return self._record(req, target="delegation_narrowing", method="registry_lookup", outcome="verified" if allowed else "denied", severity="critical" if not allowed else "high", decision="allow" if allowed else "block", checks=[{"check": k, "passed": v} for k,v in (narrowing.get("checks", {"members": bool(fm and tm)})).items()], reason={"code": "DELEGATION_VERIFIED" if allowed else "DELEGATION_DENIED", "detail": reason}, subject_agent_ref=fm.agent_ref if fm else "", subject_genome_hash=getattr(getattr(self.orchestration, "_agents", {}).get(fm.agent_ref if fm else ""), "genome_hash", ""), tenant_id=tenant)

    def _result_stage(self, stage: str, passed: bool, detail: str = "") -> dict[str, Any]:
        return {"stage": stage, "passed": bool(passed), "detail": str(detail)}

    def verify_result(self, delegation_id: str, result_ref: Mapping[str, Any], registry_state_ref: str = "registry:live") -> dict[str, Any]:
        d = getattr(self.orchestration, "_delegations", {}).get(str(delegation_id))
        if d is None: raise VerificationDenied("unknown delegation")
        team = self.orchestration.inspect_team(d.team_id); tenant = str(team.tenant_id); delegate_member = team.member_index[d.to_member]; profile = self._profile(delegate_member.agent_ref, tenant)
        high_stakes = bool(d.task.get("high_stakes", False))
        checks: list[dict[str, Any]] = []
        outcome = "verified"; decision = "allow"; severity = "high"; reason = {"code": "RESULT_VERIFIED"}
        schema_ok = bool(result_ref.get("schema_valid", False) or result_ref.get("expected_schema_valid", False))
        provenance_ok = all(str(x).strip() for x in result_ref.get("evidence_refs", ())) and bool(result_ref.get("provenance_complete", False))
        integrity_ok = bool(result_ref.get("signature_valid", False) and result_ref.get("body_hash_valid", False))
        post_ok = bool(result_ref.get("postconditions_hold", False))
        contradiction_ok = not bool(result_ref.get("contradicts_world_state", False) or result_ref.get("contradicts_memory", False))
        auth_ok = str(result_ref.get("authorization_ref", "")) == str(d.task.get("authorization_ref", result_ref.get("authorization_ref", "")))
        if high_stakes:
            independent = bool(result_ref.get("independent_path_ref")) and str(result_ref.get("verifier_model_family", "")) not in {"", profile.model_family}
            if result_ref.get("independent_recompute") is not None and self.independent_recompute is not None:
                independent = independent or self.independent_recompute(result_ref) == result_ref.get("expected_recompute")
            if result_ref.get("simulation_replay") is not None and self.simulation_replay is not None:
                independent = independent or bool(self.simulation_replay(result_ref).get("converged"))
        else:
            independent = True
        checks.extend([
            self._result_stage("schema_validation", schema_ok), self._result_stage("provenance_validation", provenance_ok), self._result_stage("integrity_check", integrity_ok),
            self._result_stage("postcondition_check", post_ok), self._result_stage("contradiction_check", contradiction_ok), self._result_stage("authorization_check", auth_ok), self._result_stage("independence_check", independent),
        ])
        if not all(bool(c["passed"]) for c in checks):
            outcome, decision, severity, reason = "contradicted" if not contradiction_ok else "denied", "block", "high", {"code": "RESULT_DENIED", "failed_stages": [c["stage"] for c in checks if not c["passed"]]}
        req_id = self.request_verification({"tenant_id": tenant, "target": "result_correctness", "method": "schema_validation", "subject_agent_ref": profile.agent_ref, "subject_delegation_id": d.delegation_id, "subject_result_ref": str(result_ref.get("result_id", _sha(result_ref))), "registry_state_ref": registry_state_ref, "correlation_id": d.correlation_id})
        return self._record(self._requests[req_id], target="result_correctness", method="schema_validation", outcome=outcome, severity=severity, decision=decision, checks=checks, reason=reason, evidence={"independent_path_ref": result_ref.get("independent_path_ref"), "verifier_model_family": result_ref.get("verifier_model_family")}, subject_agent_ref=profile.agent_ref, subject_genome_hash=profile.genome_hash, tenant_id=tenant)

    def compute_effective_authority(self, delegation_id: str) -> dict[str, Any]:
        now = self._time()
        cached = self._authority_cache.get(str(delegation_id))
        if cached and cached[0] > now:
            return copy.deepcopy(cached[1])
        d = getattr(self.orchestration, "_delegations", {}).get(str(delegation_id))
        if d is None: raise VerificationDenied("unknown delegation")
        report = self.check_narrowing(d)
        if not report["allowed"]: raise DelegationExpansionRejected("delegation is not within structural bounds")
        self._authority_cache[str(delegation_id)] = (now + 1.0, copy.deepcopy(report["effective_authority"]))
        return copy.deepcopy(report["effective_authority"])

    def get_verification_record(self, record_id: str) -> dict[str, Any]:
        record = self._records.get(str(record_id))
        if record is None: raise KeyError(record_id)
        if not _verify(record.document | {"signature": record.signature, "integrity_hash": record.integrity_hash}, record.signature, self.public_key):
            raise VerificationDenied("verification record integrity failure")
        return record.to_dict()

    def query_verifications(self, filter: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        f = dict(filter or {})
        out = []
        for record in self._records.values():
            row = record.to_dict()
            if f and any(row.get(k) != v for k, v in f.items() if k in row): continue
            out.append(row)
        return out

    def history(self, subject_agent_ref: str) -> list[dict[str, Any]]:
        return [r for r in self.query_verifications({"subject_agent_ref": str(subject_agent_ref)})]

    def explain(self, record_id: str) -> dict[str, Any]:
        row = self.get_verification_record(record_id)
        return {"record_id": record_id, "decision": row["decision"], "outcome": row["outcome"], "reason": row["reason"], "checks": row["evidence"]["checks"], "replayable": True}

    def _detector(self, detector: str, rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
        if detector == "mutual_elevation":
            ids = [(r.get("subject_agent_ref"), r.get("verifier_identity", {}).get("principal")) for r in rows]
            if len(rows) >= 3 and len(set(x[0] for x in ids)) == 1: return [{"detector": detector, "signal": "repeated_self_verification", "confidence": 0.8}]
        if detector == "same_model_family":
            if len(rows) >= 3 and len({r.get("verifier_model_family") for r in rows if r.get("verifier_model_family")}) <= 1: return [{"detector": detector, "signal": "non_independent_model_family", "confidence": 0.9}]
        if detector == "evidence_recycling":
            refs = [tuple(r.get("evidence", {}).get("cross_references", ())) for r in rows]
            if rows and sum(bool(x) for x in refs) >= 3 and len(set(refs)) == 1: return [{"detector": detector, "signal": "evidence_recycling", "confidence": 0.9}]
        return []

    def query_collusion_signals(self, filter: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
        rows = list(self._detector_window)
        signals = []
        for detector in self.DETECTORS:
            signals.extend(self._detector(detector, rows))
        return [s for s in signals if not filter or all(s.get(k) == v for k,v in filter.items())]

    def explain_collusion_signal(self, signal_id: str) -> dict[str, Any]:
        for event in reversed(self._events):
            if event.get("event_id") == str(signal_id): return copy.deepcopy(event)
        raise KeyError(signal_id)

    def analyze_collusion(self, team_id: str, correlation_id: str | None = None) -> tuple[dict[str, Any], ...]:
        tenant = self._tenant(team_id); signals = self.query_collusion_signals()
        out = []
        for signal in signals:
            artifact = {"signal_id": str(uuid.uuid4()), "team_id": team_id, "tenant_id": tenant, "detector": signal["detector"], "signal": signal["signal"], "confidence": signal["confidence"], "auto_accusation": False, "blocked": bool(signal["confidence"] >= 0.85)}
            self._emit("collusion_signal", tenant, correlation_id, None, artifact); out.append(artifact)
        return tuple(out)

    def handle_compromised(self, subject_agent_ref: str, evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "compromised", tenant_id, evidence_refs, "critical", "quarantine_recommend")

    def handle_unavailable(self, subject_agent_ref: str, evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "peer_unavailable", tenant_id, evidence_refs, "high", "block")

    def handle_malformed(self, subject_agent_ref: str, result_ref: str, evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "malformed_result", tenant_id, list(evidence_refs) + [result_ref], "high", "block")

    def handle_capability_exceeded(self, subject_agent_ref: str, attempted_capability: str, evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "capability_exceeded", tenant_id, list(evidence_refs) + [attempted_capability], "critical", "block")

    def handle_privilege_escalation(self, subject_agent_ref: str, attempted_escalation: Mapping[str, Any], evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "privilege_escalation", tenant_id, list(evidence_refs) + [f"attempt:{_sha(attempted_escalation)}"], "critical", "block")

    def handle_unauthorized_tool_use(self, subject_agent_ref: str, tool_ref: str, evidence_refs: Sequence[str], *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref, "unauthorized_tool", tenant_id, list(evidence_refs) + [tool_ref], "critical", "block")

    def handle_disagreement(self, subject_agent_ref_a: str, subject_agent_ref_b: str, claim_ref: str, *, tenant_id: str) -> dict[str, Any]:
        return self._boundary(subject_agent_ref_a, "disagreement", tenant_id, [subject_agent_ref_b, claim_ref], "medium", "escalate")

    def _boundary(self, subject_agent_ref: str, scenario: str, tenant: str, evidence: Sequence[str], severity: str, decision: str) -> dict[str, Any]:
        mapping = {"compromised": "compromised", "peer_unavailable": "peer_unavailable", "malformed_result": "malformed_result", "capability_exceeded": "capability_exceeded", "privilege_escalation": "privilege_escalation", "unauthorized_tool": "unauthorized_tool", "disagreement": "disagreement"}
        event_key = mapping[scenario]
        req_id = self.request_verification({"tenant_id": tenant, "target": "trust_boundary", "method": "statistical_analysis", "subject_agent_ref": subject_agent_ref, "correlation_id": str(uuid.uuid4())})
        record = self._record(self._requests[req_id], target="trust_boundary", method="statistical_analysis", outcome="escalated" if decision == "escalate" else "denied", severity=severity, decision=decision, checks=[{"check": scenario, "passed": False, "evidence_refs": list(evidence)}], reason={"code": f"AGENT_{scenario.upper()}"}, tenant_id=tenant, subject_agent_ref=subject_agent_ref)
        self._emit(event_key, tenant, record.get("correlation_id"), None, {"subject_agent_ref": subject_agent_ref, "evidence_refs": list(evidence)})
        return record


class VerifiedMultiAgentOrchestration:
    """Boundary wrapper that preserves P2-M APIs and refuses bypass."""

    INTERCEPTS = frozenset({"send", "delegate", "accept_delegation", "review", "challenge", "verify", "escalate", "share_knowledge", "request_resources", "consensus", "record_outcome", "authorization_handoff"})

    def __init__(self, orchestration: Any, verifier: A2AVerificationFabric | None = None) -> None:
        object.__setattr__(self, "_orchestration", orchestration)
        object.__setattr__(self, "verifier", verifier or A2AVerificationFabric(orchestration))

    def __getattr__(self, name: str) -> Any:
        return getattr(self._orchestration, name)

    def register_genome(self, genome: Any, *, tenant_id: str, garage_state: str = "MONITORED", skills: Sequence[str] = ()) -> Any:
        profile = self._orchestration.register_genome(genome, tenant_id=tenant_id, garage_state=garage_state, skills=skills)
        self.verifier.register_genome(genome, tenant_id)
        return profile

    def _member_actor(self, team_id: str, member_id: str) -> tuple[str, str]:
        team = self._orchestration.inspect_team(team_id)
        member = team.member_index.get(member_id)
        if member is None: raise VerificationDenied("A2A actor is not a team member")
        return str(member.agent_ref), str(team.tenant_id)

    def _context_token(self, context: Any) -> Mapping[str, Any]:
        token = getattr(context, "auth_context", None)
        if isinstance(token, Mapping): return token
        token = getattr(context, "authorization", None)
        return token if isinstance(token, Mapping) else {}

    def _gate(self, *, team_id: str, member_id: str, capability: str, target_member: str | None = None, context: Any, scope: Any = None) -> None:
        agent_ref, tenant = self._member_actor(team_id, member_id)
        identity = self.verifier.verify_identity(agent_ref, tenant_id=tenant, correlation_id=getattr(context, "correlation_id", None))
        if identity.get("decision") != "allow": raise VerificationDenied("identity verification failed")
        cap = self.verifier.verify_capability(agent_ref, capability, tenant_id=tenant, correlation_id=identity.get("correlation_id"))
        if cap.get("decision") != "allow": raise VerificationDenied(f"capability denied: {cap['reason']}")
        raw = self._context_token(context)
        target_ref = ""
        if target_member:
            target_ref, _ = self._member_actor(team_id, target_member)
        token = dict(raw)
        if not token:
            raise VerificationDenied("P2-N requires an invocation-specific Security Authority token")
        invocation = {"target_agent_ref": target_ref or agent_ref, "capability": capability, "scope": scope if scope is not None else {"team_id": team_id}, "authorization_token": token, "policy_version": "1.0.0"}
        auth = self.verifier.verify_authorization(agent_ref, invocation, policy_ref="policy:live", tenant_id=tenant)
        if auth.get("decision") != "allow": raise VerificationDenied("authorization chain failed closed")

    def send(self, message: Mapping[str, Any], *, context: Any) -> Any:
        msg = dict(message); self._gate(team_id=str(msg["team_id"]), member_id=str(msg["from_member"]), capability="task.run", target_member=str(msg["to_member"]) if isinstance(msg.get("to_member"), str) else None, context=context)
        result = self._orchestration.send(msg, context=context)
        verification = self.verifier.verify_message(result.to_dict(), tenant_id=self._tenant(str(msg["team_id"])))
        if verification.get("decision") != "allow": raise VerificationDenied("post-admission message verification failed")
        return result

    def delegate(self, team_id: str, from_member: str, to_member: str, task: Mapping[str, Any], obligations: Mapping[str, Any] | None, *, context: Any, parent_delegation_id: str | None = None) -> Any:
        self._gate(team_id=team_id, member_id=from_member, capability=str(next(iter(task.get("delegated_capabilities", ["task.run"])), "task.run")), target_member=to_member, context=context, scope=task.get("delegated_scopes", ()))
        d = self._orchestration.delegate(team_id, from_member, to_member, task, obligations, context=context, parent_delegation_id=parent_delegation_id)
        v = self.verifier.verify_delegation(d.delegation_id)
        if v.get("decision") != "allow":
            try:
                self._orchestration.cancel_delegation(d.delegation_id, "P2-N verification denied", context=context)
            except Exception as exc:
                logger.error("P2-N delegation cancellation failed after verification denial", exc_info=True)
                raise DelegationExpansionRejected(
                    f"{v['reason']}; cancellation of denied delegation failed"
                ) from exc
            raise DelegationExpansionRejected(v["reason"])
        return d

    def accept_delegation(self, delegation_id: str, *, context: Any) -> Any:
        d = self._orchestration._delegations[str(delegation_id)]
        team = self._orchestration.inspect_team(d.team_id); to_member = team.member_index[d.to_member]
        self._gate(team_id=d.team_id, member_id=d.to_member, capability=str(next(iter(d.delegated_capabilities), "task.run")), target_member=d.from_member, context=context, scope=d.delegated_scopes)
        pre = self.verifier.verify_delegation(delegation_id)
        if pre.get("decision") != "allow": raise VerificationDenied("delegation cannot be accepted before verification")
        return self._orchestration.accept_delegation(delegation_id, context=context)

    def review(self, team_id: str, reviewer: str, target_ref: str, criteria: Sequence[str], findings: Sequence[Mapping[str, Any]], *, context: Any, author_member: str | None = None, confidence: float = 0.0) -> Any:
        self._gate(team_id=team_id, member_id=reviewer, capability="task.run", target_member=author_member, context=context, scope={"review": target_ref})
        if author_member == reviewer: raise VerificationDenied("self-review is forbidden")
        return self._orchestration.review(team_id, reviewer, target_ref, criteria, findings, context=context, author_member=author_member, confidence=confidence)

    def challenge(self, team_id: str, challenger: str, claim_ref: str, evidence_refs: Sequence[str], *, context: Any, ground: str = "evidence", severity: str = "medium") -> Any:
        self._gate(team_id=team_id, member_id=challenger, capability="task.run", context=context, scope={"challenge": claim_ref})
        if not evidence_refs: raise VerificationDenied("challenge requires evidence")
        return self._orchestration.challenge(team_id, challenger, claim_ref, evidence_refs, context=context, ground=ground, severity=severity)

    def verify(self, team_id: str, verifier: str, claim_ref: str, evidence_refs: Sequence[str], *, context: Any, proposer_member: str, high_stakes: bool = True, verification_kind: str = "independent_check", result: str = "verified", confidence: float = 0.0) -> Any:
        self._gate(team_id=team_id, member_id=verifier, capability="task.run", target_member=proposer_member, context=context, scope={"verify": claim_ref})
        if verifier == proposer_member: raise VerificationDenied("closed-loop self-verification is forbidden")
        if high_stakes:
            team = self._orchestration.inspect_team(team_id); vp = self._orchestration._profile(team.member_index[verifier].agent_ref, team.tenant_id); pp = self._orchestration._profile(team.member_index[proposer_member].agent_ref, team.tenant_id)
            if vp.model_family == pp.model_family: raise VerificationDenied("high-stakes verification requires independent model family")
        return self._orchestration.verify(team_id, verifier, claim_ref, evidence_refs, context=context, proposer_member=proposer_member, high_stakes=high_stakes, verification_kind=verification_kind, result=result, confidence=confidence)

    def escalate(self, team_id: str, from_member: str, to_member_or_human: str, reason: str, evidence_refs: Sequence[str], *, context: Any, depth: int = 0, deadline: Any = None, to_human: bool = False) -> Any:
        self._gate(team_id=team_id, member_id=from_member, capability="task.run", target_member=to_member_or_human if not to_human else None, context=context, scope={"escalate": reason})
        return self._orchestration.escalate(team_id, from_member, to_member_or_human, reason, evidence_refs, context=context, depth=depth, deadline=deadline, to_human=to_human)

    def share_knowledge(self, team_id: str, from_member: str, knowledge_ref: str, scope: str, ttl: int, *, context: Any, recipients: Sequence[str] | None = None) -> Any:
        self._gate(team_id=team_id, member_id=from_member, capability="task.run", context=context, scope={"knowledge": knowledge_ref, "scope": scope})
        return self._orchestration.share_knowledge(team_id, from_member, knowledge_ref, scope, ttl, context=context, recipients=recipients)

    def request_resources(self, team_id: str, member_id: str, request: Mapping[str, Any], *, context: Any) -> Any:
        self._gate(team_id=team_id, member_id=member_id, capability="task.run", context=context, scope={"resources": request})
        return self._orchestration.request_resources(team_id, member_id, request, context=context)

    def consensus(self, team_id: str, proposal: Mapping[str, Any], rule: Mapping[str, Any] | None = None, *, context: Any, votes: Mapping[str, Any]) -> Any:
        team = self._orchestration.inspect_team(team_id)
        for member_id in votes:
            self._gate(team_id=team_id, member_id=str(member_id), capability="task.run", context=context, scope={"consensus": proposal})
        self.verifier.analyze_collusion(team_id, correlation_id=getattr(context, "correlation_id", None))
        return self._orchestration.consensus(team_id, proposal, rule, context=context, votes=votes)

    def record_outcome(self, team_id: str, outcome: Mapping[str, Any], *, context: Any) -> Any:
        owner = str(outcome.get("from_member") or outcome.get("member_id") or (self._orchestration.inspect_team(team_id).coordinator_ref or ""))
        self._gate(team_id=team_id, member_id=owner, capability="task.run", context=context, scope={"outcome": outcome})
        delegation_id = outcome.get("delegation_id")
        if delegation_id:
            verification = self.verifier.verify_result(str(delegation_id), outcome)
            if verification.get("decision") != "allow": raise VerificationDenied("result verification denied")
        return self._orchestration.record_outcome(team_id, outcome, context=context)

    def authorization_handoff(self, team_id: str, action: Mapping[str, Any], *, context: Any, simulation: Mapping[str, Any] | None = None) -> Any:
        owner = str(action.get("from_member") or action.get("member_id") or (self._orchestration.inspect_team(team_id).coordinator_ref or ""))
        self._gate(team_id=team_id, member_id=owner, capability="task.run", context=context, scope=action)
        return self._orchestration.authorization_handoff(team_id, action, context=context, simulation=simulation)

    def verify_bypass(self, operation_name: str) -> None:
        if operation_name in self.INTERCEPTS:
            raise VerificationDenied(f"direct P2-M bypass refused: {operation_name}")

    def health(self) -> dict[str, Any]:
        base = dict(self._orchestration.health())
        base["p2n_verification"] = True
        base["p2n_records"] = len(self.verifier._records)
        base["p2n_intercepts"] = sorted(self.INTERCEPTS)
        return base

"""Authorized autopilot with explicit human override controls and fail-safe bounds."""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class AutopilotPolicy:
    """Bounded autopilot policy; authority is time-limited and capability-scoped."""

    enabled: bool = False
    max_runtime_seconds: float = 3600.0
    max_actions: int = 100
    allowed_capabilities: tuple[str, ...] = ()
    emergency_kill: bool = False


@dataclass(frozen=True, slots=True)
class AutopilotSession:
    """Immutable record describing one authorized autonomous session."""

    session_id: str
    started_at: float
    expires_at: float
    actions: int
    active: bool
    reason: str
    capabilities: tuple[str, ...]


class AuthorizedAutopilot:
    """Enable bounded human-approval override only after explicit authorization."""

    def __init__(
        self,
        permission_engine: Any,
        *,
        policy: AutopilotPolicy | None = None,
        audit: Any | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.permission_engine = permission_engine
        self.policy = policy or AutopilotPolicy()
        self.audit = audit
        self.clock = clock
        self._lock = threading.RLock()
        self._session: AutopilotSession | None = None

    def authorize(self, approval_token: str, *, reason: str, capabilities: tuple[str, ...] | list[str] = (), step_up_verified: bool = False) -> AutopilotSession:
        """Consume an explicit override grant and create a bounded session."""
        if not self.policy.enabled:
            raise PermissionError("autopilot is disabled by policy")
        if self.policy.emergency_kill:
            raise PermissionError("autopilot emergency kill switch is active")
        requested = tuple(sorted(set(str(item).strip() for item in capabilities if str(item).strip())))
        if not requested:
            requested = self.policy.allowed_capabilities
        if not requested:
            raise PermissionError("autopilot requires an explicit capability allowlist")
        allowed = set(self.policy.allowed_capabilities)
        if not all(cap in allowed or "*" in allowed for cap in requested):
            raise PermissionError("autopilot capability exceeds configured allowlist")
        if any(cap in {"process.spawn", "code.execute", "device.write", "filesystem.write"} for cap in requested) and not step_up_verified:
            raise PermissionError("high-impact autopilot capabilities require WebAuthn step-up verification")
        if not self.permission_engine.verify(approval_token, capability="autopilot.override"):
            raise PermissionError("invalid or already-used autopilot authorization")
        now = self.clock()
        session = AutopilotSession(
            session_id=f"ap_{uuid.uuid4().hex[:16]}",
            started_at=now,
            expires_at=now + max(1.0, min(float(self.policy.max_runtime_seconds), 86_400.0)),
            actions=0,
            active=True,
            reason=str(reason).strip() or "authorized autopilot",
            capabilities=requested,
        )
        with self._lock:
            self._session = session
        self._record("autopilot.authorized", session)
        return session

    def authorize_action(self, capability: str) -> bool:
        """Check and consume one bounded autonomous action slot."""
        cap = str(capability).strip()
        with self._lock:
            session = self._session
            if session is None or not session.active:
                return False
            if self.clock() >= session.expires_at or session.actions >= max(1, int(self.policy.max_actions)):
                self._session = AutopilotSession(session.session_id, session.started_at, session.expires_at, session.actions, False, session.reason, session.capabilities)
                self._record("autopilot.expired", self._session)
                return False
            if cap not in session.capabilities and "*" not in session.capabilities:
                return False
            updated = AutopilotSession(
                session.session_id,
                session.started_at,
                session.expires_at,
                session.actions + 1,
                True,
                session.reason,
                session.capabilities,
            )
            self._session = updated
            return True

    def stop(self, reason: str = "stopped by operator") -> None:
        """Immediately revoke the active autonomous session."""
        with self._lock:
            if self._session is None:
                return
            session = self._session
            self._session = AutopilotSession(session.session_id, session.started_at, session.expires_at, session.actions, False, str(reason), session.capabilities)
            self._record("autopilot.stopped", self._session)

    def status(self) -> dict[str, Any]:
        """Return safe operational state without exposing authorization material."""
        with self._lock:
            session = self._session
            return {
                "enabled": self.policy.enabled,
                "kill_switch": self.policy.emergency_kill,
                "active": bool(session and session.active),
                "session": None if session is None else {
                    "session_id": session.session_id,
                    "started_at": session.started_at,
                    "expires_at": session.expires_at,
                    "actions": session.actions,
                    "reason": session.reason,
                    "capabilities": list(session.capabilities),
                },
            }

    def _record(self, event: str, session: AutopilotSession) -> None:
        if self.audit is None:
            return
        try:
            self.audit.write(event, {"session_id": session.session_id, "actions": session.actions, "reason": session.reason})
        except Exception:
            return



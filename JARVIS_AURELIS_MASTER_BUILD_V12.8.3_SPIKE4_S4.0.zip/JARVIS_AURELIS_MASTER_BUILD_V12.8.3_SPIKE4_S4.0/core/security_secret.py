"""Stable local secret derivation for restart-survivable 12.8.0 identities and memory."""
from __future__ import annotations

import hashlib
import os
from pathlib import Path


_DEFAULT_KEY_PATH = Path("data/kernel_12_8_0_master.key")


def _load_or_create_local_key(path: Path = _DEFAULT_KEY_PATH) -> bytes:
    """Load or atomically create a local 32-byte secret with owner-only permissions."""
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        data = path.read_bytes()
        if len(data) != 32:
            raise RuntimeError("persistent J.A.R.V.I.S. master key has invalid length")
        if hasattr(os, "chmod"):
            os.chmod(path, 0o600)
        return data
    data = os.urandom(32)
    temp = path.with_name(path.name + ".tmp")
    if temp.exists():
        try:
            if temp.is_symlink() or not temp.is_file():
                raise RuntimeError("persistent J.A.R.V.I.S. secret temp path is unsafe")
            if temp.stat().st_mode & 0o077:
                raise RuntimeError("persistent J.A.R.V.I.S. secret temp path permissions are too broad")
            temp.unlink()
        except OSError as exc:
            raise RuntimeError("unable to recover stale J.A.R.V.I.S. secret temp file") from exc
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    fd = os.open(temp, flags, 0o600)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        if hasattr(os, "chmod"):
            os.chmod(path, 0o600)
    finally:
        temp.unlink(missing_ok=True)
    return data


def derive_secret(name: str, configured: str | None, master: str | None) -> bytes:
    """Return a stable 32-byte secret from explicit material or a local root key."""
    if configured:
        raw = configured.encode("utf-8")
    elif master:
        raw = f"jarvis:{name}:{master}".encode("utf-8")
    else:
        raw = f"jarvis:{name}:".encode("utf-8") + _load_or_create_local_key()
    return hashlib.sha256(raw).digest()



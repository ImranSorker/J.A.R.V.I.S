"""Canonical mission authority for planning, execution, cancellation and recovery."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from core.autonomy_fabric import AutonomyFabric, MissionRecord
from core.contracts.autonomy import MissionStepSpec, MissionStatus
from core.planning_v2 import HierarchicalPlanner, PlanBudget, PlanNode


@dataclass(frozen=True, slots=True)
class MissionExecutionPolicy:
    """Bounded execution controls applied above the durable mission fabric."""

    max_steps: int = 100
    max_duration_seconds: float = 3600.0


class MissionAuthority:
    """Single mission facade; lower-level services never own mission lifecycle state."""

    def __init__(self, fabric: AutonomyFabric, planner: HierarchicalPlanner | None = None, *, policy: MissionExecutionPolicy | None = None) -> None:
        self.fabric = fabric
        self.planner = planner or HierarchicalPlanner()
        self.policy = policy or MissionExecutionPolicy()
        self._cancelled: set[str] = set()
        self._lock = threading.RLock()

    def plan(self, nodes: Sequence[PlanNode], budget: PlanBudget | None = None) -> list[PlanNode]:
        """Validate and deterministically order a hierarchical plan."""
        effective = budget or PlanBudget(max_steps=self.policy.max_steps, max_duration_seconds=self.policy.max_duration_seconds)
        return self.planner.order(nodes, effective)

    def create(self, objective: str, steps: Sequence[MissionStepSpec], *, owner: str = "jarvis", capabilities: tuple[str, ...] = (), priority: int = 5, deadline: float | None = None) -> MissionRecord:
        """Create a goal and durable mission under one authority boundary."""
        goal = self.fabric.create_goal(objective, owner=owner, capabilities=capabilities, priority=priority, deadline=deadline)
        return self.fabric.create_mission(goal, steps)

    def cancel(self, mission_id: str) -> MissionRecord:
        """Request cancellation and persist the terminal state."""
        with self._lock:
            self._cancelled.add(mission_id)
        row = self.fabric.missions.get(mission_id)
        if row is None:
            raise KeyError(mission_id)
        if row.status in {MissionStatus.CREATED, MissionStatus.RUNNING, MissionStatus.PAUSED}:
            return self.fabric.transition(mission_id, MissionStatus.CANCELLED, error="cancelled by authority")
        return row

    def is_cancelled(self, mission_id: str) -> bool:
        """Return whether cancellation was requested."""
        with self._lock:
            return mission_id in self._cancelled

    def execute(self, mission_id: str, steps: Sequence[MissionStepSpec], executor: Callable[[MissionStepSpec], Any], compensations: Mapping[str, Callable[[], Any]] | None = None) -> dict[str, Any]:
        """Execute through the durable fabric while enforcing deadline and cancellation."""
        started = time.monotonic()
        bounded = tuple(steps)
        if len(bounded) > self.policy.max_steps:
            raise ValueError("mission exceeds authority step budget")
        original = executor

        def guarded(step: MissionStepSpec) -> Any:
            if self.is_cancelled(mission_id):
                raise RuntimeError("mission cancellation requested")
            if time.monotonic() - started > self.policy.max_duration_seconds:
                raise TimeoutError("mission execution budget exceeded")
            return original(step)

        return self.fabric.execute_mission(mission_id, bounded, guarded, compensations)

    def status(self, mission_id: str) -> MissionRecord | None:
        """Return the durable mission snapshot."""
        return self.fabric.missions.get(mission_id)



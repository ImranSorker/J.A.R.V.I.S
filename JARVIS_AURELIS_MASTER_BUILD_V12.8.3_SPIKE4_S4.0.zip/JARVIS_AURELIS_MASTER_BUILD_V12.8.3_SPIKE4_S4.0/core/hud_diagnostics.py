"""UI-neutral HUD/command-deck diagnostics projection."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Mapping, Sequence

from core.telemetry_fabric import TelemetrySample


@dataclass(frozen=True, slots=True)
class HUDAlert:
    code: str
    severity: str
    message: str
    source: str


@dataclass(frozen=True, slots=True)
class HUDSnapshot:
    timestamp: float
    system_status: str
    telemetry: Mapping[str, float]
    alerts: tuple[HUDAlert, ...]
    uncertainty: float
    task: str


class HUDDiagnostics:
    """Build a bounded operator-facing projection without binding to Flet/Flutter."""

    def build(self, samples: Sequence[TelemetrySample], *, task: str = "idle", uncertainty: float = 0.0) -> HUDSnapshot:
        latest: dict[str, float] = {}
        alerts: list[HUDAlert] = []
        for sample in samples[-256:]:
            latest[f"{sample.subsystem}.{sample.metric}"] = sample.value
            if sample.quality < 0.4:
                alerts.append(HUDAlert("LOW_TELEMETRY_QUALITY", "warning", f"Telemetry quality is low for {sample.subsystem}.{sample.metric}.", sample.source))
            if "temperature" in sample.metric.lower() and sample.value > 90.0:
                alerts.append(HUDAlert("HIGH_TEMPERATURE", "critical", f"High temperature reported by {sample.subsystem}.", sample.source))
            if "battery" in sample.metric.lower() and sample.value < 0.2:
                alerts.append(HUDAlert("LOW_BATTERY", "critical", f"Battery reserve is low for {sample.subsystem}.", sample.source))
        status = "critical" if any(alert.severity == "critical" for alert in alerts) else ("warning" if alerts else "nominal")
        return HUDSnapshot(time.time(), status, latest, tuple(alerts[-64:]), max(0.0, min(1.0, float(uncertainty))), str(task).strip()[:256] or "idle")

"""P2-G Learning Pipeline — controlled learning and evolution loop.

The legacy dataset/example API is retained for compatibility, while P2-G adds a
proposal-only, signed, evidence-bound evolution pipeline.  P2-G never rewrites
live agents and never owns deployment or rollback.  Those authorities remain in
P2-D Agent Garage and the Security Authority.
"""
from __future__ import annotations

import copy
import hashlib
import hmac
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, List, Mapping, Optional, Protocol, Sequence, Set

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes

logger = logging.getLogger("jarvis.learning_pipeline")

VERSION = "2.0.0"
PUBLIC_VERSION = "12.8.3"
KERNEL_VERSION = "12.8.0"

TRIGGERS = (
    "experience_review", "failure_pattern", "diagnosis_remediation", "performance_regression",
    "adversarial_finding", "security_advisory", "research_finding", "operator_initiated",
    "cross_agent_learning", "capability_gap",
)
CANDIDATE_CLASSES = (
    "agent_genome_change", "skill_update", "skill_composition", "tool_manifest_update",
    "tool_composition_update", "prompt_program_update", "workflow_update", "plan_template_update",
    "policy_update", "model_adapter_update", "memory_consolidation_rule", "failure_pattern_rule",
    "detector_update",
)
ORIGIN_METHODS = (
    "direct_proposal", "differential_learning", "imitation_learning", "reinforcement_signal", "search",
    "composition", "pruning", "refactor", "template_instantiation", "operator_authored",
)
GATE_STAGES = (
    "proposed", "evidence_bound", "simulated", "benchmarked", "security_validated", "verified",
    "certified", "staged", "deployed", "monitored", "attributed", "rolled_back", "invalidated", "rejected",
)
OUTCOME_STATES = (
    "blocked", "rejected", "invalidated", "withdrawn", "expired", "pending", "passed", "failed", "skipped",
    "superseded", "deployed_and_stable", "deployed_and_regressed", "deployed_and_rolled_back", "invalidated_during_monitoring",
)
MANDATORY_GATES = ("benchmarked", "security_validated", "verified", "certified", "staged")
DANGEROUS_EFFECTS = ("destructive", "financial", "identity", "device", "communication")

# P2-S artifact-class mapping.  P2-G does not duplicate P2-S attestation logic.
SECURITY_CLASS_MAP = {
    "agent_genome_change": "agent", "skill_update": "skill", "skill_composition": "skill",
    "tool_manifest_update": "tool", "tool_composition_update": "composite_tool",
    "prompt_program_update": "prompt_program", "workflow_update": "workflow",
    "plan_template_update": "workflow", "policy_update": "policy", "model_adapter_update": "model_adapter",
    "memory_consolidation_rule": "policy", "failure_pattern_rule": "policy", "detector_update": "policy",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _sign_document(document: Mapping[str, Any], key: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    body = copy.deepcopy(dict(document))
    body["writer_key_id"] = str(key_id)
    body["integrity_hash"] = ""
    body["signature"] = ""
    body["integrity_hash"] = _sha(body)
    body["signature"] = key.sign(canonical_bytes(body)).hex()
    return body


def verify_signed_document(document: Mapping[str, Any], public_key: bytes | Ed25519PublicKey) -> bool:
    try:
        body = copy.deepcopy(dict(document))
        signature = bytes.fromhex(str(body.pop("signature")))
        integrity = str(body.get("integrity_hash", ""))
        body["integrity_hash"] = ""
        body["signature"] = ""
        if not hmac.compare_digest(_sha(body), integrity):
            return False
        body["integrity_hash"] = integrity
        key = public_key if isinstance(public_key, Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(public_key))
        key.verify(signature, canonical_bytes(body))
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError):
        return False


class LearningPipelineError(RuntimeError):
    """Base P2-G error."""


class CandidateValidationError(LearningPipelineError, ValueError):
    """Candidate input or contract validation failed."""


class CandidateImmutable(LearningPipelineError):
    """A signed candidate cannot be mutated in place."""


class TenantIsolationError(LearningPipelineError, PermissionError):
    """A candidate or artifact crossed its tenant boundary."""


class GateViolation(LearningPipelineError):
    """A mandatory lifecycle gate or transition was violated."""


class SecurityGateDenied(GateViolation, PermissionError):
    """Security Authority denied a required evolution operation."""


class SimulationRequired(GateViolation):
    """A dangerous candidate requires a simulation before benchmarking."""


class DeploymentHandoffDenied(GateViolation):
    """P2-D deployment or rollback handoff was not admissible."""


class AttributionError(LearningPipelineError, ValueError):
    """Attribution evidence or lifecycle state was invalid."""


class AuthorityProtocol(Protocol):
    def authorize(self, operation: str, subject: Mapping[str, Any]) -> Any: ...


class SimulationAdapter(Protocol):
    def run(self, candidate: Mapping[str, Any], *, tenant_id: str, seed: int) -> Mapping[str, Any]: ...


class BenchmarkAdapter(Protocol):
    def run(self, candidate: Mapping[str, Any], *, tenant_id: str, seed: int) -> Mapping[str, Any]: ...


class SecurityAdapter(Protocol):
    def validate(self, candidate: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...


class VerificationAdapter(Protocol):
    def verify(self, candidate: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...


class CertificationAdapter(Protocol):
    def certify(self, candidate: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...


class StagingAdapter(Protocol):
    def stage(self, candidate: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...


class DeploymentAdapter(Protocol):
    def deploy(self, candidate: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...
    def rollback(self, candidate: Mapping[str, Any], *, tenant_id: str, reason: str) -> Mapping[str, Any]: ...


class MemoryAdapter(Protocol):
    def read(self, *, tenant_id: str, kind: str, limit: int) -> Sequence[Mapping[str, Any]]: ...
    def write(self, *, tenant_id: str, kind: str, body: Mapping[str, Any]) -> str: ...


class FailureAdapter(Protocol):
    def read(self, *, tenant_id: str, limit: int) -> Sequence[Mapping[str, Any]]: ...


@dataclass(frozen=True, slots=True)
class CandidateConfig:
    store_path: str = ":memory:"
    storage_secret: bytes = b"jarvis-p2g-learning-pipeline-secret-32bytes"
    signer_key_id: str = "p2g-learning-pipeline"
    low_improvement_delta: float = 0.0
    attribution_window_seconds: float = 7 * 24 * 3600.0
    max_batch_candidates: int = 128


@dataclass(frozen=True, slots=True)
class CandidateRecord:
    candidate_id: str
    candidate_version: int
    tenant_id: str
    trigger: str
    candidate_class: str
    origin_method: str
    gate_stage: str
    outcome: str
    parent_ref: str | None
    root_ref: str
    artifact_hash: str
    evidence_refs: tuple[str, ...]
    lineage: Mapping[str, Any]
    requires_simulation: bool
    widening: bool
    created_at: str
    signature: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id, "candidate_version": self.candidate_version,
            "tenant_id": self.tenant_id, "trigger": self.trigger, "candidate_class": self.candidate_class,
            "origin_method": self.origin_method, "gate_stage": self.gate_stage, "outcome": self.outcome,
            "parent_ref": self.parent_ref, "root_ref": self.root_ref, "artifact_hash": self.artifact_hash,
            "evidence_refs": list(self.evidence_refs), "lineage": dict(self.lineage),
            "requires_simulation": self.requires_simulation, "widening": self.widening,
            "created_at": self.created_at, "signature": self.signature,
        }


@dataclass(frozen=True, slots=True)
class GateRecord:
    candidate_id: str
    stage: str
    outcome: str
    evidence_refs: tuple[str, ...]
    details: Mapping[str, Any]
    recorded_at: str
    sequence: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id, "stage": self.stage, "outcome": self.outcome,
            "evidence_refs": list(self.evidence_refs), "details": dict(self.details),
            "recorded_at": self.recorded_at, "sequence": self.sequence,
        }


@dataclass(frozen=True, slots=True)
class LearningBatch:
    batch_id: str
    tenant_id: str
    seed: int
    trigger_refs: tuple[str, ...]
    candidate_ids: tuple[str, ...]
    created_at: str
    signature: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "batch_id": self.batch_id, "tenant_id": self.tenant_id, "seed": self.seed,
            "trigger_refs": list(self.trigger_refs), "candidate_ids": list(self.candidate_ids),
            "created_at": self.created_at, "signature": self.signature,
        }


class _CandidateStore:
    def __init__(self, path: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("P2-G storage secret must be at least 32 bytes")
        self.path = Path(path)
        self._memory = str(path) == ":memory:"
        if not self._memory:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(":memory:" if self._memory else str(self.path), check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.secret = bytes(secret)
        self.lock = threading.RLock()
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS candidates(id TEXT NOT NULL, version INTEGER NOT NULL, tenant TEXT NOT NULL, document TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(tenant,id,version));
        CREATE TABLE IF NOT EXISTS gates(seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, candidate_id TEXT NOT NULL, stage TEXT NOT NULL, outcome TEXT NOT NULL, evidence TEXT NOT NULL, details TEXT NOT NULL, recorded_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS batches(id TEXT NOT NULL, tenant TEXT NOT NULL, document TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(tenant,id));
        CREATE TABLE IF NOT EXISTS outcomes(id TEXT NOT NULL, tenant TEXT NOT NULL, candidate_id TEXT NOT NULL, document TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(tenant,id));
        CREATE TABLE IF NOT EXISTS baselines(id TEXT NOT NULL, tenant TEXT NOT NULL, document TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(tenant,id));
        """)
        self.db.commit()

    def _tag(self, document: Mapping[str, Any]) -> str:
        return hmac.new(self.secret, canonical_bytes(document), hashlib.sha256).hexdigest()

    def put_candidate(self, document: Mapping[str, Any]) -> None:
        body = json.dumps(dict(document), sort_keys=True, separators=(",", ":"))
        with self.lock:
            self.db.execute("INSERT INTO candidates VALUES(?,?,?,?,?)", (document["candidate_id"], int(document["candidate_version"]), document["tenant_id"], body, self._tag(document)))
            self.db.commit()

    def get_candidate(self, tenant: str, candidate_id: str, version: int | None = None) -> dict[str, Any] | None:
        q = "SELECT document,tag FROM candidates WHERE tenant=? AND id=?" + (" AND version=?" if version is not None else " ORDER BY version DESC LIMIT 1")
        args = (tenant, candidate_id, int(version)) if version is not None else (tenant, candidate_id)
        row = self.db.execute(q, args).fetchone()
        if not row: return None
        doc = json.loads(row[0])
        if not hmac.compare_digest(str(row[1]), self._tag(doc)): raise LearningPipelineError("candidate store integrity failure")
        return doc

    def gates(self, tenant: str, candidate_id: str) -> list[dict[str, Any]]:
        rows = self.db.execute("SELECT seq,stage,outcome,evidence,details,recorded_at FROM gates WHERE tenant=? AND candidate_id=? ORDER BY seq", (tenant,candidate_id)).fetchall()
        return [{"sequence":r[0],"stage":r[1],"outcome":r[2],"evidence_refs":json.loads(r[3]),"details":json.loads(r[4]),"recorded_at":r[5]} for r in rows]

    def put_gate(self, tenant: str, record: GateRecord) -> None:
        with self.lock:
            self.db.execute("INSERT INTO gates(tenant,candidate_id,stage,outcome,evidence,details,recorded_at) VALUES(?,?,?,?,?,?,?)", (tenant,record.candidate_id,record.stage,record.outcome,json.dumps(list(record.evidence_refs)),json.dumps(dict(record.details),sort_keys=True),record.recorded_at))
            self.db.commit()

    def put_batch(self, batch: Mapping[str, Any]) -> None:
        with self.lock:
            self.db.execute("INSERT INTO batches VALUES(?,?,?,?)", (batch["batch_id"],batch["tenant_id"],json.dumps(dict(batch),sort_keys=True),self._tag(batch)))
            self.db.commit()

    def put_outcome(self, outcome: Mapping[str, Any]) -> None:
        with self.lock:
            self.db.execute("INSERT INTO outcomes VALUES(?,?,?,?,?)", (outcome["outcome_id"],outcome["tenant_id"],outcome["candidate_id"],json.dumps(dict(outcome),sort_keys=True),self._tag(outcome)))
            self.db.commit()

    def put_baseline(self, baseline: Mapping[str, Any]) -> None:
        with self.lock:
            self.db.execute("INSERT INTO baselines VALUES(?,?,?,?)", (baseline["baseline_id"],baseline["tenant_id"],json.dumps(dict(baseline),sort_keys=True),self._tag(baseline)))
            self.db.commit()

    def verify(self) -> bool:
        with self.lock:
            for table, cols in (("candidates",("document","tag")),("batches",("document","tag")),("outcomes",("document","tag")),("baselines",("document","tag"))):
                for raw, tag in self.db.execute(f"SELECT {cols[0]},{cols[1]} FROM {table}").fetchall():
                    if not hmac.compare_digest(tag,self._tag(json.loads(raw))): return False
        return True

    def close(self) -> None:
        self.db.close()


class _Generator:
    def __init__(self, name: str) -> None: self.name = name
    def generate(self, trigger: Mapping[str, Any], *, seed: int) -> Mapping[str, Any]:
        return {"proposal": f"{self.name}:{trigger.get('trigger','unknown')}", "seed": int(seed), "generator": self.name}


class LearningPipeline:
    """Compatibility dataset manager plus the canonical P2-G evolution controller."""

    def __init__(self, output_dir: str = "data/datasets", *, config: CandidateConfig | None = None,
                 signer: Ed25519PrivateKey | None = None, authority: AuthorityProtocol | None = None,
                 simulation: SimulationAdapter | None = None, benchmark: BenchmarkAdapter | None = None,
                 security: SecurityAdapter | None = None, verification: VerificationAdapter | None = None,
                 certification: CertificationAdapter | None = None, staging: StagingAdapter | None = None,
                 deployment: DeploymentAdapter | None = None, memory: MemoryAdapter | None = None,
                 failures: FailureAdapter | None = None, event_fabric: Any | None = None,
                 tenant_id: str = "default") -> None:
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._dataset: List[TrainingExample] = []
        self._seen_hashes: Set[str] = set()
        self._load_existing()
        self.config = config or CandidateConfig(store_path=str(self._output_dir / "p2g.db"))
        self.signer = signer or Ed25519PrivateKey.generate()
        self.public_key = self.signer.public_key()
        self.authority = authority
        self.simulation = simulation
        self.benchmark = benchmark
        self.security = security
        self.verification = verification
        self.certification = certification
        self.staging = staging
        self.deployment = deployment
        self.memory = memory
        self.failures = failures
        self.event_fabric = event_fabric
        self.tenant_id = str(tenant_id)
        self._store = _CandidateStore(self.config.store_path, self.config.storage_secret)
        self._generators = {name: _Generator(name) for name in ORIGIN_METHODS}
        self._lock = threading.RLock()

    # ----- legacy dataset API -----
    def _load_existing(self) -> None:
        dataset_file = self._output_dir / "dataset.jsonl"
        if not dataset_file.exists(): return
        try:
            for line in dataset_file.read_text(encoding="utf-8").splitlines():
                item=json.loads(line)
                example=TrainingExample(input_text=item["input"],output_text=item["output"],score=item.get("score",1.0),source=item.get("source","unknown"),tags=item.get("tags",[]),created_at=item.get("created_at",time.time()),id=item.get("id",hashlib.sha256(line.encode()).hexdigest()[:16]))
                self._dataset.append(example); self._seen_hashes.add(self._hash_example(example))
        except (OSError,ValueError,KeyError,json.JSONDecodeError) as exc: logger.warning("failed_to_load_dataset: %s",exc)

    @staticmethod
    def _hash_example(example: "TrainingExample") -> str:
        return hashlib.sha256((example.input_text+"\x00"+example.output_text).encode()).hexdigest()

    def _save(self) -> None:
        path=self._output_dir/"dataset.jsonl"; tmp=path.with_suffix(".tmp")
        tmp.write_text("".join(json.dumps(e.to_dict(),sort_keys=True)+"\n" for e in self._dataset),encoding="utf-8"); tmp.replace(path)

    def add_example(self,input_text:str,output_text:str,score:float=1.0,source:str="manual",tags:Optional[List[str]]=None)->dict[str,Any]:
        if not input_text or not output_text: return {"ok":False,"error":"Input and output text required"}
        if len(input_text)>100_000 or len(output_text)>100_000: return {"ok":False,"error":"Text exceeds 100KB limit"}
        example=TrainingExample(input_text,output_text,max(0.0,min(1.0,float(score))),source,list(tags or []))
        h=self._hash_example(example)
        if h in self._seen_hashes: return {"ok":False,"error":"Duplicate example","id":example.id}
        self._dataset.append(example); self._seen_hashes.add(h); self._save(); return {"ok":True,"id":example.id,"dataset_size":len(self._dataset)}

    def add_examples(self,examples:List[Dict[str,Any]])->dict[str,Any]:
        a=d=e=0
        for x in examples:
            r=self.add_example(x.get("input",""),x.get("output",""),x.get("score",1.0),x.get("source","batch"),x.get("tags"))
            if r["ok"]: a+=1
            elif "Duplicate" in r.get("error",""): d+=1
            else: e+=1
        return {"ok":True,"added":a,"duplicates":d,"errors":e,"dataset_size":len(self._dataset)}

    def get_examples(self,min_score:float=0.0,limit:int=1000)->List[Dict[str,Any]]:
        return [x.to_dict() for x in self._dataset if x.score>=min_score][:limit]

    def export_dataset(self,format:str="jsonl")->dict[str,Any]:
        if format!="jsonl": return {"ok":False,"error":f"Format {format} not supported"}
        path=self._output_dir/"export.jsonl"; path.write_text("".join(json.dumps(e.to_dict(),sort_keys=True)+"\n" for e in self._dataset),encoding="utf-8"); return {"ok":True,"path":str(path),"count":len(self._dataset)}

    def get_stats(self)->dict[str,Any]:
        if not self._dataset:return {"examples":0,"avg_score":0.0,"sources":{}}
        scores=[x.score for x in self._dataset]; sources={}
        for x in self._dataset:sources[x.source]=sources.get(x.source,0)+1
        return {"examples":len(self._dataset),"avg_score":sum(scores)/len(scores),"min_score":min(scores),"max_score":max(scores),"sources":sources,"unique":len(self._seen_hashes)}

    # ----- P2-G lifecycle -----
    @property
    def generator_names(self) -> tuple[str, ...]: return ORIGIN_METHODS

    def _tenant(self, tenant_id: str | None) -> str:
        tenant=str(tenant_id or self.tenant_id)
        if tenant != self.tenant_id: raise TenantIsolationError("cross-tenant learning access denied")
        return tenant

    def _emit(self,event_name:str,payload:Mapping[str,Any],*,tenant_id:str,correlation_id:str) -> None:
        if self.event_fabric is None: return
        result=None
        if hasattr(self.event_fabric,"publish"):
            result=self.event_fabric.publish("Evolution."+event_name,dict(payload),source="p2g.learning_pipeline",correlation_id=correlation_id)
        elif hasattr(self.event_fabric,"emit"):
            result=self.event_fabric.emit("Evolution."+event_name,dict(payload),correlation_id=correlation_id)
        if result is False: raise LearningPipelineError("event admission failed; lifecycle transition refused")

    @staticmethod
    def danger_matrix(candidate: Mapping[str,Any]) -> dict[str,Any]:
        effects={str(x) for x in candidate.get("effects",[]) if isinstance(x,str)}
        irreversible=bool(candidate.get("reversibility_changed",False)) or bool(candidate.get("irreversible",False))
        widening=bool(candidate.get("capability_widening",False) or candidate.get("permission_widening",False) or candidate.get("scope_widening",False))
        dangerous=bool(effects & set(DANGEROUS_EFFECTS)) or irreversible
        return {"effects":sorted(effects),"dangerous":dangerous,"requires_simulation":dangerous,"widening":widening,"security_authority_required":widening}

    def _validate_candidate_input(self, candidate: Mapping[str,Any], *, tenant_id:str) -> None:
        required=("candidate_id","candidate_class","origin_method","trigger","artifact")
        for k in required:
            if not candidate.get(k): raise CandidateValidationError(f"missing candidate field: {k}")
        if str(candidate["candidate_class"]) not in CANDIDATE_CLASSES: raise CandidateValidationError("unknown candidate class")
        if str(candidate["origin_method"]) not in ORIGIN_METHODS: raise CandidateValidationError("unknown origin method")
        if str(candidate["trigger"]) not in TRIGGERS: raise CandidateValidationError("unknown trigger")
        if str(candidate.get("tenant_id",tenant_id)) != tenant_id: raise TenantIsolationError("candidate tenant mismatch")
        artifact=candidate["artifact"]
        if not isinstance(artifact,Mapping): raise CandidateValidationError("artifact must be a mapping")
        if not candidate.get("evidence_refs"): raise CandidateValidationError("candidate requires evidence_refs")
        matrix=self.danger_matrix(candidate)
        if matrix["widening"]:
            if self.authority is None: raise SecurityGateDenied("capability/permission/scope widening requires Security Authority")
            decision=self.authority.authorize("p2g.capability_widening",{"tenant_id":tenant_id,"candidate":dict(candidate)})
            if decision is False or decision is None: raise SecurityGateDenied("Security Authority denied widening")

    def _make_candidate_document(self, candidate: Mapping[str,Any], *, tenant_id:str, seed:int) -> dict[str,Any]:
        self._validate_candidate_input(candidate,tenant_id=tenant_id)
        matrix=self.danger_matrix(candidate)
        cid=str(candidate["candidate_id"])
        parent=candidate.get("parent_ref")
        prior=self._store.get_candidate(tenant_id,cid)
        version=int(prior["candidate_version"])+1 if prior else int(candidate.get("candidate_version",1))
        artifact_hash=_sha(candidate["artifact"])
        root=str(candidate.get("root_ref") or parent or cid)
        lineage={"root_ref":root,"parent_ref":parent,"supersedes":candidate.get("supersedes"),"seed":int(seed),"generator":str(candidate["origin_method"]),"evidence_refs":sorted(set(map(str,candidate.get("evidence_refs",[]))))}
        body={
            "schema_version":"p2g-candidate-1.0.0","candidate_id":cid,"candidate_version":version,"tenant_id":tenant_id,
            "trigger":str(candidate["trigger"]),"candidate_class":str(candidate["candidate_class"]),"origin_method":str(candidate["origin_method"]),
            "artifact":copy.deepcopy(dict(candidate["artifact"])),"artifact_hash":artifact_hash,"evidence_refs":lineage["evidence_refs"],
            "lineage":lineage,"parent_ref":parent,"root_ref":root,"effects":sorted(set(map(str,candidate.get("effects",[])))),
            "requires_simulation":matrix["requires_simulation"],"widening":matrix["widening"],"gate_stage":"proposed","outcome":"pending",
            "seed":int(seed),"created_at":_now(),"provenance":copy.deepcopy(dict(candidate.get("provenance",{}))),
        }
        return _sign_document(body,self.signer,self.config.signer_key_id)

    def propose_candidate(self,candidate:Mapping[str,Any],*,tenant_id:str|None=None,seed:int=0)->dict[str,Any]:
        tenant=self._tenant(tenant_id)
        doc=self._make_candidate_document(candidate,tenant_id=tenant,seed=seed)
        if not verify_signed_document(doc,self.public_key): raise LearningPipelineError("candidate signing self-check failed")
        self._store.put_candidate(doc); self._record_gate(doc,"proposed","pending",doc["evidence_refs"],{"seed":seed},tenant)
        self._emit("CandidateCreated",{"candidate_id":doc["candidate_id"],"candidate_version":doc["candidate_version"],"candidate_class":doc["candidate_class"],"trigger":doc["trigger"]},tenant_id=tenant,correlation_id=doc["candidate_id"])
        return copy.deepcopy(doc)

    def bind_evidence(self,candidate_id:str,evidence_refs:Sequence[str],*,tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id); self._require_stage(doc,"proposed")
        refs=sorted(set(map(str,evidence_refs)))
        if not refs: raise CandidateValidationError("evidence binding requires at least one reference")
        updated=copy.deepcopy(doc); updated["evidence_refs"]=refs; updated["lineage"]={**updated["lineage"],"evidence_refs":refs}; updated["gate_stage"]="evidence_bound"; updated["outcome"]="pending"; updated["candidate_version"]=int(doc.get("candidate_version",1))+1; updated=_sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id)
        self._store.put_candidate(updated); self._record_gate(updated,"evidence_bound","passed",refs,{"count":len(refs)},tenant); return updated

    def verify_candidate(self, document: Mapping[str, Any]) -> bool:
        """Verify a candidate document without mutating pipeline state."""
        return verify_signed_document(document, self.public_key)

    def _require(self,tenant:str,candidate_id:str)->dict[str,Any]:
        doc=self._store.get_candidate(tenant,candidate_id)
        if doc is None: raise CandidateValidationError("candidate not found")
        if not verify_signed_document(doc,self.public_key): raise LearningPipelineError("candidate signature/integrity verification failed")
        return doc

    @staticmethod
    def _require_stage(doc:Mapping[str,Any],expected:str)->None:
        if str(doc.get("gate_stage"))!=expected: raise GateViolation(f"candidate must be at {expected}, found {doc.get('gate_stage')}")

    def _replace_stage(self,doc:Mapping[str,Any],stage:str,outcome:str)->dict[str,Any]:
        if stage not in GATE_STAGES or outcome not in OUTCOME_STATES: raise GateViolation("invalid gate state")
        current=str(doc.get("gate_stage"))
        legal={
            "proposed":{"evidence_bound","rejected","invalidated"},
            "evidence_bound":{"simulated","rejected","invalidated"},
            "simulated":{"benchmarked","rejected","invalidated"},
            "benchmarked":{"security_validated","rejected","invalidated"},
            "security_validated":{"verified","rejected","invalidated"},
            "verified":{"certified","rejected","invalidated"},
            "certified":{"staged","rejected","invalidated"},
            "staged":{"deployed","rejected","invalidated"},
            "deployed":{"monitored","rolled_back","invalidated"},
            "monitored":{"attributed","rolled_back","invalidated"},
            "attributed":{"rolled_back","invalidated"},
            "rolled_back":set(), "invalidated":set(), "rejected":set(),
        }
        if stage != current and stage not in legal.get(current,set()):
            raise GateViolation(f"illegal gate transition: {current} -> {stage}")
        updated=copy.deepcopy(dict(doc)); updated["gate_stage"]=stage; updated["outcome"]=outcome
        updated["candidate_version"]=int(doc.get("candidate_version",1))+1
        return _sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id)

    def _record_gate(self,doc:Mapping[str,Any],stage:str,outcome:str,evidence:Sequence[str],details:Mapping[str,Any],tenant:str)->None:
        self._store.put_gate(tenant,GateRecord(str(doc["candidate_id"]),stage,outcome,tuple(map(str,evidence)),dict(details),_now(),0))

    def _adapter(self,obj:Any,name:str)->Any:
        if obj is None: raise GateViolation(f"mandatory P2-G gate adapter unavailable: {name}")
        return obj

    def advance(self,candidate_id:str,*,tenant_id:str|None=None,seed:int|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id); stage=str(doc["gate_stage"]); seed=int(doc.get("seed",0) if seed is None else seed)
        if stage in {"rejected","invalidated","rolled_back"}: return doc
        if stage=="proposed":
            if not doc.get("evidence_refs"): raise GateViolation("evidence_bound gate required")
            doc=self._replace_stage(doc,"evidence_bound","passed"); self._store.put_candidate(doc); self._record_gate(doc,"evidence_bound","passed",doc["evidence_refs"],{},tenant); stage="evidence_bound"
        if stage=="evidence_bound":
            if bool(doc["requires_simulation"]):
                adapter=self._adapter(self.simulation,"simulation")
                result=dict(adapter.run(doc,tenant_id=tenant,seed=seed)); ok=bool(result.get("passed",result.get("ok",False)))
                if not ok: return self._fail_gate(doc,"simulated",result,tenant)
                doc=self._replace_stage(doc,"simulated","passed"); self._store.put_candidate(doc); self._record_gate(doc,"simulated","passed",result.get("evidence_refs",()),result,tenant); stage="simulated"
            else:
                self._record_gate(doc,"simulated","skipped",(),{"reason":"danger_matrix_not_triggered"},tenant)
                doc=self._replace_stage(doc,"simulated","skipped"); self._store.put_candidate(doc); doc=self._replace_stage(doc,"benchmarked","pending")
                self._store.put_candidate(doc); self._record_gate(doc,"benchmarked","pending",(),{},tenant); return self._run_from_benchmark(doc,tenant,seed)
        if stage=="simulated": return self._run_from_benchmark(self._replace_stage(doc,"benchmarked","pending"),tenant,seed)
        if stage=="benchmarked": return self._run_from_benchmark(doc,tenant,seed)
        if stage in {"security_validated","verified","certified","staged"}: return doc
        raise GateViolation(f"unsupported candidate gate stage: {stage}")

    def _run_from_benchmark(self,doc:Mapping[str,Any],tenant:str,seed:int)->dict[str,Any]:
        if doc["gate_stage"]!="benchmarked": self._require_stage(doc,"benchmarked")
        adapter=self._adapter(self.benchmark,"benchmark"); result=dict(adapter.run(doc,tenant_id=tenant,seed=seed)); ok=bool(result.get("passed",result.get("ok",False)))
        if not ok:return self._fail_gate(doc,"benchmarked",result,tenant)
        doc=self._replace_stage(doc,"benchmarked","passed"); self._store.put_candidate(doc); self._record_gate(doc,"benchmarked","passed",result.get("evidence_refs",()),result,tenant)
        adapter=self._adapter(self.security,"security")
        sec=dict(adapter.validate(doc,tenant_id=tenant)); ok=bool(sec.get("passed",sec.get("ok",False)))
        if not ok:return self._fail_gate(doc,"security_validated",sec,tenant)
        doc=self._replace_stage(doc,"security_validated","passed"); self._store.put_candidate(doc); self._record_gate(doc,"security_validated","passed",sec.get("evidence_refs",()),sec,tenant)
        adapter=self._adapter(self.verification,"verification")
        ver=dict(adapter.verify(doc,tenant_id=tenant)); ok=bool(ver.get("passed",ver.get("ok",False)))
        if not ok:return self._fail_gate(doc,"verified",ver,tenant)
        doc=self._replace_stage(doc,"verified","passed"); self._store.put_candidate(doc); self._record_gate(doc,"verified","passed",ver.get("evidence_refs",()),ver,tenant)
        adapter=self._adapter(self.certification,"certification")
        cert=dict(adapter.certify(doc,tenant_id=tenant)); ok=bool(cert.get("passed",cert.get("ok",False)))
        if not ok:return self._fail_gate(doc,"certified",cert,tenant)
        doc=self._replace_stage(doc,"certified","passed"); self._store.put_candidate(doc); self._record_gate(doc,"certified","passed",cert.get("evidence_refs",()),cert,tenant)
        adapter=self._adapter(self.staging,"staging")
        staged=dict(adapter.stage(doc,tenant_id=tenant)); ok=bool(staged.get("passed",staged.get("ok",True)))
        if not ok:return self._fail_gate(doc,"staged",staged,tenant)
        doc=self._replace_stage(doc,"staged","passed"); self._store.put_candidate(doc); self._record_gate(doc,"staged","passed",staged.get("evidence_refs",()),staged,tenant)
        self._emit("Certified",{"candidate_id":doc["candidate_id"],"artifact_hash":doc["artifact_hash"]},tenant_id=tenant,correlation_id=doc["candidate_id"])
        return doc

    def _fail_gate(self,doc:Mapping[str,Any],stage:str,result:Mapping[str,Any],tenant:str)->dict[str,Any]:
        updated=self._replace_stage(doc,"rejected","failed"); self._store.put_candidate(updated); self._record_gate(updated,stage,"failed",result.get("evidence_refs",()),result,tenant); self._emit("Rejected",{"candidate_id":doc["candidate_id"],"failed_stage":stage},tenant_id=tenant,correlation_id=doc["candidate_id"]); return updated

    def process(self,candidate_id:str,*,tenant_id:str|None=None,seed:int|None=None)->dict[str,Any]:
        """Run the complete controlled proposal→stage pipeline; never deploys."""
        return self.advance(candidate_id,tenant_id=tenant_id,seed=seed)

    def stage_handoff(self,candidate_id:str,*,tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id)
        if doc["gate_stage"]!="staged": raise DeploymentHandoffDenied("candidate must be staged before deployment handoff")
        if self.deployment is None: raise DeploymentHandoffDenied("P2-D deployment adapter unavailable")
        result=dict(self.deployment.deploy(doc,tenant_id=tenant)); updated=self._replace_stage(doc,"deployed","passed"); updated["deployment"] = result; updated=_sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id); self._store.put_candidate(updated); self._record_gate(updated,"deployed","passed",result.get("evidence_refs",()),result,tenant); return updated

    def monitor(self,candidate_id:str,metrics:Mapping[str,Any],*,tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id)
        if doc["gate_stage"] not in {"deployed","monitored"}: raise GateViolation("candidate must be deployed before monitoring")
        regression=bool(metrics.get("regression",False)); stage="monitored"; outcome="deployed_and_regressed" if regression else "passed"
        updated=self._replace_stage(doc,stage,outcome); updated["monitoring"] = {"metrics":dict(metrics),"recorded_at":_now()}; updated=_sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id); self._store.put_candidate(updated); self._record_gate(updated,stage,outcome,metrics.get("evidence_refs",()),dict(metrics),tenant); return updated

    def attribute(self,candidate_id:str,*,baseline:Mapping[str,Any],post:Mapping[str,Any],tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id)
        if doc["gate_stage"] not in {"monitored","deployed"}: raise AttributionError("candidate must be monitored before attribution")
        base_hash=_sha(baseline); post_hash=_sha(post); keys=sorted(set(baseline)|set(post)); lower_is_better={"latency","latency_ms","cost","cost_units","error_rate","failure_rate","tokens","resource_use"}; deltas={}
        for k in keys:
            bv,pv=baseline.get(k,0),post.get(k,0)
            if isinstance(bv,(int,float)) and isinstance(pv,(int,float)):
                raw=float(pv)-float(bv); deltas[k]=(-raw if k in lower_is_better else raw)
        improvement=sum(deltas.values())/max(1,len(deltas)); stable=improvement>self.config.low_improvement_delta and not bool(post.get("regression",False))
        outcome="deployed_and_stable" if stable else "deployed_and_regressed"; updated=self._replace_stage(doc,"attributed",outcome); updated["attribution"]={"baseline_hash":base_hash,"post_hash":post_hash,"deltas":deltas,"improvement":improvement,"attributed_at":_now()}; updated=_sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id); self._store.put_candidate(updated); self._record_gate(updated,"attributed",outcome,(base_hash,post_hash),updated["attribution"],tenant)
        if self.memory is not None: self.memory.write(tenant_id=tenant,kind="task",body={"candidate_id":candidate_id,"outcome":outcome,"attribution":updated["attribution"]})
        return updated

    def rollback_handoff(self,candidate_id:str,reason:str,*,tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); doc=self._require(tenant,candidate_id)
        if doc["gate_stage"] not in {"deployed","monitored","attributed"}: raise DeploymentHandoffDenied("rollback requires a deployed candidate")
        if self.deployment is None: raise DeploymentHandoffDenied("P2-D rollback adapter unavailable")
        result=dict(self.deployment.rollback(doc,tenant_id=tenant,reason=str(reason))); updated=self._replace_stage(doc,"rolled_back","deployed_and_rolled_back"); updated["rollback"]={"reason":str(reason),"result":result,"recorded_at":_now()}; updated=_sign_document({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer,self.config.signer_key_id); self._store.put_candidate(updated); self._record_gate(updated,"rolled_back","deployed_and_rolled_back",result.get("evidence_refs",()),result,tenant); return updated

    def gates(self,candidate_id:str,*,tenant_id:str|None=None)->list[dict[str,Any]]:
        return self._store.gates(self._tenant(tenant_id),candidate_id)

    def create_batch(self,*,trigger_refs:Sequence[str],tenant_id:str|None=None,seed:int=0)->dict[str,Any]:
        tenant=self._tenant(tenant_id); refs=tuple(sorted(set(map(str,trigger_refs))))
        if not refs: raise CandidateValidationError("learning batch requires trigger refs")
        bid=hashlib.sha256(canonical_bytes({"tenant_id":tenant,"seed":int(seed),"trigger_refs":list(refs)})).hexdigest()
        body={"schema_version":"p2g-batch-1.0.0","batch_id":bid,"tenant_id":tenant,"seed":int(seed),"trigger_refs":list(refs),"candidate_ids":[],"created_at":_now()}; body=_sign_document(body,self.signer,self.config.signer_key_id); self._store.put_batch(body); return body

    def generate(self,trigger:Mapping[str,Any],*,origin_method:str,tenant_id:str|None=None,seed:int=0,candidate_class:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); method=str(origin_method)
        if method not in self._generators: raise CandidateValidationError("unknown generator")
        if str(trigger.get("trigger")) not in TRIGGERS: raise CandidateValidationError("unknown trigger")
        cls=candidate_class or "policy_update"; if_cls=cls
        generated=dict(self._generators[method].generate(trigger,seed=seed)); cid=hashlib.sha256(canonical_bytes({"tenant":tenant,"trigger":dict(trigger),"method":method,"seed":seed,"class":if_cls})).hexdigest()
        generated.update({"candidate_id":cid,"tenant_id":tenant,"trigger":str(trigger["trigger"]),"candidate_class":if_cls,"origin_method":method,"artifact":{"proposal":generated.pop("proposal"),"trigger":dict(trigger)},"evidence_refs":list(trigger.get("evidence_refs",[])),"effects":list(trigger.get("effects",[]))})
        return self.propose_candidate(generated,tenant_id=tenant,seed=seed)

    def record_outcome(self,candidate_id:str,result:str,*,tenant_id:str|None=None,metrics:Mapping[str,Any]|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id)
        if result not in OUTCOME_STATES: raise CandidateValidationError("invalid outcome state")
        self._require(tenant,candidate_id)
        outcome={"outcome_id":hashlib.sha256(canonical_bytes({"candidate":candidate_id,"result":result,"tenant":tenant,"metrics":metrics or {}})).hexdigest(),"tenant_id":tenant,"candidate_id":candidate_id,"result":result,"metrics":dict(metrics or {}),"recorded_at":_now()}
        outcome=_sign_document(outcome,self.signer,self.config.signer_key_id)
        self._store.put_outcome(outcome)
        return outcome

    def capture_baseline(self,artifact_ref:str,metrics:Mapping[str,Any],*,tenant_id:str|None=None)->dict[str,Any]:
        tenant=self._tenant(tenant_id); body={"baseline_id":hashlib.sha256(canonical_bytes({"tenant":tenant,"artifact_ref":artifact_ref,"metrics":metrics})).hexdigest(),"tenant_id":tenant,"artifact_ref":str(artifact_ref),"metrics":dict(metrics),"captured_at":_now()}; body=_sign_document(body,self.signer,self.config.signer_key_id); self._store.put_baseline(body); return body

    def health(self)->dict[str,Any]:
        return {"version":PUBLIC_VERSION,"kernel":KERNEL_VERSION,"pipeline_version":VERSION,"tenant_id":self.tenant_id,"store_integrity":self._store.verify(),"generators":list(ORIGIN_METHODS),"candidate_classes":list(CANDIDATE_CLASSES),"triggers":list(TRIGGERS),"mandatory_gates":list(MANDATORY_GATES)}

    def observe(self, *, tenant_id: str | None = None, limit: int = 100) -> dict[str, Any]:
        tenant = self._tenant(tenant_id)
        memory_rows = list(self.memory.read(tenant_id=tenant, kind="episodic", limit=limit)) if self.memory is not None else []
        failure_rows = list(self.failures.read(tenant_id=tenant, limit=limit)) if self.failures is not None else []
        return {"tenant_id": tenant, "experience_count": len(memory_rows), "failure_count": len(failure_rows), "experiences": memory_rows, "failures": failure_rows}

    def run_batch(self, candidates: Sequence[Mapping[str, Any]], *, tenant_id: str | None = None, seed: int = 0) -> dict[str, Any]:
        tenant = self._tenant(tenant_id)
        if len(candidates) > self.config.max_batch_candidates:
            raise CandidateValidationError("learning batch exceeds configured candidate limit")
        batch = self.create_batch(trigger_refs=[str(c.get("trigger_ref") or c.get("candidate_id") or "unknown") for c in candidates], tenant_id=tenant, seed=seed)
        results = []
        for index, candidate in enumerate(candidates):
            local_seed = int(seed) + index
            if not candidate.get("candidate_id"):
                raise CandidateValidationError("batch candidate_id is required")
            doc = self.propose_candidate(candidate, tenant_id=tenant, seed=local_seed)
            result = self.process(doc["candidate_id"], tenant_id=tenant, seed=local_seed)
            results.append(result)
        return {"batch": batch, "results": results, "passed": sum(1 for x in results if x.get("gate_stage") == "staged"), "rejected": sum(1 for x in results if x.get("gate_stage") == "rejected")}

    def list_generator_manifests(self) -> list[dict[str, Any]]:
        return [{"generator_id": f"p2g.{name}", "method": name, "version": VERSION, "deterministic": True, "allowed_candidate_classes": list(CANDIDATE_CLASSES)} for name in ORIGIN_METHODS]

    def close(self)->None: self._store.close()


@dataclass
class TrainingExample:
    """Legacy training example retained for compatibility."""
    input_text: str
    output_text: str
    score: float = 1.0
    source: str = "unknown"
    tags: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: hashlib.sha256(uuid.uuid4().bytes).hexdigest()[:16])

    def to_dict(self)->Dict[str,Any]:
        return {"id":self.id,"input":self.input_text,"output":self.output_text,"score":self.score,"source":self.source,"tags":self.tags,"created_at":self.created_at}

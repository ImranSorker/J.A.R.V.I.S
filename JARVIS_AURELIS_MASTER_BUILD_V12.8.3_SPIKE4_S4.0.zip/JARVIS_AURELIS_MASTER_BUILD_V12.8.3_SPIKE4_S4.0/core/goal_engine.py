"""Typed goal/objective graph used by mission planning."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal

GoalStatus = Literal["pending", "active", "blocked", "completed", "cancelled"]

@dataclass(slots=True)
class Objective:
    """A bounded objective belonging to a goal."""
    objective_id: str
    title: str
    depends_on: tuple[str, ...] = ()
    status: GoalStatus = "pending"

@dataclass(slots=True)
class Goal:
    """A user-visible goal with explicit constraints and objectives."""
    goal_id: str
    title: str
    constraints: tuple[str, ...] = ()
    objectives: dict[str, Objective] = field(default_factory=dict)
    status: GoalStatus = "pending"

class GoalEngine:
    """Validate and advance goal graphs without performing side effects."""
    def __init__(self) -> None:
        self._goals: dict[str, Goal] = {}

    def create(self, goal_id: str, title: str, constraints: tuple[str, ...] = ()) -> Goal:
        """Create a unique goal."""
        if goal_id in self._goals:
            raise ValueError("goal already exists")
        if not title.strip():
            raise ValueError("goal title is required")
        goal = Goal(goal_id, title.strip(), constraints)
        self._goals[goal_id] = goal
        return goal

    def add_objective(self, goal_id: str, objective: Objective) -> None:
        """Add an objective and reject unknown dependencies/cycles."""
        goal = self._goals[goal_id]
        if objective.objective_id in goal.objectives:
            raise ValueError("objective already exists")
        goal.objectives[objective.objective_id] = objective
        self._validate(goal)

    def ready(self, goal_id: str) -> list[Objective]:
        """Return objectives whose dependencies are complete."""
        goal = self._goals[goal_id]
        return [o for o in goal.objectives.values() if o.status == "pending" and all(goal.objectives[d].status == "completed" for d in o.depends_on)]

    def _validate(self, goal: Goal) -> None:
        for objective in goal.objectives.values():
            if any(dep not in goal.objectives for dep in objective.depends_on):
                raise ValueError("objective dependency does not exist")
        visiting: set[str] = set()
        visited: set[str] = set()
        def visit(node: str) -> None:
            if node in visiting:
                raise ValueError("objective dependency cycle")
            if node in visited:
                return
            visiting.add(node)
            for dep in goal.objectives[node].depends_on:
                visit(dep)
            visiting.remove(node)
            visited.add(node)
        for node in goal.objectives:
            visit(node)



"""Bounded, interruptible health watchdog."""
from __future__ import annotations

import logging
import threading
from typing import Callable

logger = logging.getLogger("jarvis.watchdog")


class Watchdog:
    """Run health checks periodically and stop deterministically."""

    def __init__(self, check_interval: int = 5, max_restarts: int = 3):
        self.check_interval = max(1, int(check_interval))
        self.max_restarts = max(0, int(max_restarts))
        self._checks: list[Callable[[], bool]] = []
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._running = False
        self._restart_count = 0
        self._lock = threading.RLock()

    def add_check(self, check: Callable[[], bool]) -> None:
        """Register one bounded health check."""
        if not callable(check):
            raise TypeError("watchdog check must be callable")
        with self._lock:
            self._checks.append(check)

    def start(self) -> None:
        """Start the watchdog exactly once until stopped."""
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._stop.clear()
            self._running = True
            self._thread = threading.Thread(target=self._loop, daemon=True, name="watchdog")
            self._thread.start()

    def _loop(self) -> None:
        while self._running and not self._stop.wait(self.check_interval):
            with self._lock:
                checks = tuple(self._checks)
            for check in checks:
                if not self._running or self._stop.is_set():
                    break
                try:
                    healthy = bool(check())
                except Exception as exc:
                    logger.error("watchdog_check_error", extra={"error": str(exc)})
                    continue
                if not healthy:
                    with self._lock:
                        self._restart_count += 1
                        count = self._restart_count
                    logger.warning("watchdog_check_failed", extra={"restart_count": count})

    def stop(self, timeout: float = 2.0) -> None:
        """Stop the watchdog promptly and wait for its worker to exit."""
        with self._lock:
            self._running = False
            self._stop.set()
            thread = self._thread
        if thread is not None and thread.is_alive() and threading.current_thread() is not thread:
            thread.join(max(0.1, float(timeout)))
        with self._lock:
            if thread is self._thread and (thread is None or not thread.is_alive()):
                self._thread = None

    @property
    def restart_count(self) -> int:
        """Return the number of failed health checks observed."""
        with self._lock:
            return self._restart_count



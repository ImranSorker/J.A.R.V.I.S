"""Bounded interruption-aware multimodal event stream with channel sequencing."""
from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class MediaEvent:
    """Timestamped multimodal event."""

    kind: str
    payload: bytes
    timestamp: float
    sequence: int
    channel: str = "default"
    correlation_id: str | None = None
    interrupt: bool = False


class MultimodalStream:
    """Thread-safe bounded FIFO with per-channel ordering and interruption semantics."""

    def __init__(self, max_events: int = 256) -> None:
        self._q: queue.Queue[MediaEvent] = queue.Queue(maxsize=max(1, min(int(max_events), 10_000)))
        self._seq = 0
        self._channel_seq: dict[str, int] = {}
        self._lock = threading.Lock()
        self._cancel = threading.Event()
        self._interrupt = threading.Event()

    def publish(self, kind: str, payload: bytes, *, channel: str = "default", correlation_id: str | None = None, interrupt: bool = False) -> MediaEvent:
        """Publish one event while retaining global and channel sequence order."""
        if self._cancel.is_set():
            raise RuntimeError("stream cancelled")
        label = str(channel).strip() or "default"
        with self._lock:
            self._seq += 1
            self._channel_seq[label] = self._channel_seq.get(label, 0) + 1
            event = MediaEvent(str(kind), bytes(payload), time.time(), self._seq, label, correlation_id, bool(interrupt))
            if interrupt:
                self._interrupt.set()
        try:
            self._q.put_nowait(event)
        except queue.Full as exc:
            raise RuntimeError("multimodal stream backpressure") from exc
        return event

    def next(self, timeout: float = 1.0) -> MediaEvent | None:
        """Read the next media event."""
        try:
            return self._q.get(timeout=max(0.01, min(float(timeout), 60.0)))
        except queue.Empty:
            return None

    def drain_interrupts(self) -> list[MediaEvent]:
        """Drain queued interruption events without blocking."""
        retained: list[MediaEvent] = []
        interrupts: list[MediaEvent] = []
        while True:
            try:
                event = self._q.get_nowait()
            except queue.Empty:
                break
            (interrupts if event.interrupt else retained).append(event)
        for event in retained:
            try:
                self._q.put_nowait(event)
            except queue.Full:
                break
        self._interrupt.clear()
        return interrupts

    @property
    def interrupted(self) -> bool:
        """Return whether a pending interruption has been observed."""
        return self._interrupt.is_set()

    def cancel(self) -> None:
        """Permanently cancel the stream."""
        self._cancel.set()

    def snapshot(self) -> dict[str, object]:
        """Return non-payload stream metrics."""
        with self._lock:
            return {"sequence": self._seq, "channels": dict(self._channel_seq), "queued": self._q.qsize(), "cancelled": self._cancel.is_set(), "interrupted": self._interrupt.is_set()}



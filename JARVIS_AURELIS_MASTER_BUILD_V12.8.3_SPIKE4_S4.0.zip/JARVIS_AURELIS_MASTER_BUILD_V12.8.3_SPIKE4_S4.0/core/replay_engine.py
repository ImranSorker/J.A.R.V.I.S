"""Deterministic cognitive replay and counterfactual execution boundary."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Sequence

from core.cognitive_episode import CognitiveEpisode, EpisodeStore


@dataclass(frozen=True, slots=True)
class ReplayResult:
    """Replay outcome."""
    episode_id: str
    ok: bool
    output: Any = None
    error: str | None = None


class CognitiveReplayEngine:
    """Replay persisted episodes through an injected model/planner function."""

    def __init__(self, store: EpisodeStore) -> None:
        self.store = store

    def replay(self, episode_id: str, executor: Callable[[CognitiveEpisode], Any]) -> ReplayResult:
        """Replay exactly one episode without mutating its source record."""
        episode = self.store.get(episode_id)
        if episode is None:
            return ReplayResult(episode_id, False, error="episode not found")
        try:
            return ReplayResult(episode_id, True, output=executor(episode))
        except Exception as exc:
            return ReplayResult(episode_id, False, error=str(exc))

    def list(self, session_id: str | None = None) -> Sequence[CognitiveEpisode]:
        """Return replay candidates."""
        return self.store.list(session_id)



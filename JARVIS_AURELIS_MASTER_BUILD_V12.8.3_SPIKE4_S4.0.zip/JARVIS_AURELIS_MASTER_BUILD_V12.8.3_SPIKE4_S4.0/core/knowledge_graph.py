"""Simple knowledge graph."""
from __future__ import annotations
from typing import Any, Dict, List, Tuple


class KnowledgeGraph:
    def __init__(self):
        self._nodes: Dict[str, Dict[str, Any]] = {}
        self._edges: List[Tuple[str, str, str]] = []

    def add_node(self, node_id: str, properties: Dict[str, Any] = None) -> None:
        self._nodes[node_id] = properties or {}

    def add_edge(self, src: str, rel: str, dst: str) -> None:
        self._edges.append((src, rel, dst))

    def query(self, node_id: str) -> Dict[str, Any]:
        return {"node": self._nodes.get(node_id), "relations": [e for e in self._edges if e[0] == node_id or e[2] == node_id]}



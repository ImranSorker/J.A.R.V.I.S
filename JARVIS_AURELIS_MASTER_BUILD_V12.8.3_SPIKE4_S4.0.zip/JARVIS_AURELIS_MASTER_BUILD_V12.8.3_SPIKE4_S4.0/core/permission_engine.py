"""Capability-based HMAC permission engine with replay protection."""
from __future__ import annotations
import base64
import binascii
import hashlib
import hmac
import secrets
import threading
import time
from typing import Optional


class PermissionEngine:
    """Issue short-lived, capability-bound, single-use authorization tokens."""

    MIN_TTL = 1
    MAX_TTL = 3600

    def __init__(self, secret: str = ""):
        self._secret = secret.encode("utf-8") if secret else secrets.token_bytes(32)
        # nonce -> expiry timestamp (ms). Keeping expiry lets the replay cache
        # self-prune instead of growing for the lifetime of the process.
        self._used_nonces: dict[str, int] = {}
        self._max_used_nonces = 100_000
        self._lock = threading.Lock()

    def _sign(self, capability: str, expires_at: int, nonce: str) -> str:
        raw = f"{capability}:{expires_at}:{nonce}".encode("utf-8")
        return hmac.new(self._secret, raw, hashlib.sha256).hexdigest()

    def issue_grant(self, capability: str, expiry: int = 300) -> str:
        if not capability or ":" in capability:
            raise ValueError("capability must be non-empty and contain no ':'")
        if not self.MIN_TTL <= expiry <= self.MAX_TTL:
            raise ValueError(f"expiry must be between {self.MIN_TTL} and {self.MAX_TTL} seconds")
        expires_at = int(time.time() * 1000) + expiry * 1000
        nonce = secrets.token_urlsafe(16)
        sig = self._sign(capability, expires_at, nonce)
        raw = f"{capability}:{expires_at}:{nonce}:{sig}".encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii")

    def verify(self, token_b64: str, capability: Optional[str] = None) -> bool:
        if not token_b64 or token_b64.startswith("APPROVE-"):
            return False
        try:
            raw = base64.b64decode(token_b64.encode("ascii"), altchars=b"-_", validate=True).decode("utf-8")
            cap, ts_str, nonce, sig = raw.split(":", 3)
            expires_at = int(ts_str)
        except (ValueError, UnicodeError, TypeError, binascii.Error):
            return False
        if not cap or ":" in cap or not nonce or not sig:
            return False
        if capability is not None and cap != capability:
            return False
        if expires_at < int(time.time() * 1000):
            return False
        expected = self._sign(cap, expires_at, nonce)
        if not hmac.compare_digest(sig, expected):
            return False
        now_ms = int(time.time() * 1000)
        with self._lock:
            # Expired replay entries are no longer useful. Prune them before
            # accepting a new nonce so long-running processes stay bounded.
            if self._used_nonces:
                expired = [n for n, expiry in self._used_nonces.items() if expiry < now_ms]
                for n in expired:
                    self._used_nonces.pop(n, None)
            if nonce in self._used_nonces:
                return False
            if len(self._used_nonces) >= self._max_used_nonces:
                # The cache is intentionally fail-closed rather than evicting
                # live nonces, which would re-open replay attacks.
                return False
            self._used_nonces[nonce] = expires_at
            return True



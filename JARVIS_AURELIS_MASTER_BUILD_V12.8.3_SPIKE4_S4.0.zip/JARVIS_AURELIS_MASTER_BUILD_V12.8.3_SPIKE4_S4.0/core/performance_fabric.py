"""Precision and latency fabric for high-speed J.A.R.V.I.S. execution.

The fabric provides deterministic fast-path dispatch, explicit accuracy/latency
budgets and privacy-scoped context caching. It optimizes routing without
silently lowering a task's required correctness threshold.
"""
from __future__ import annotations

import hashlib
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Callable, Mapping


class PerformanceError(RuntimeError):
    """Base performance-fabric error."""


class ExecutionMode(StrEnum):
    """Execution policy tier."""

    TURBO = "turbo"
    BALANCED = "balanced"
    SUPREME = "supreme"


@dataclass(frozen=True, slots=True)
class PrecisionBudget:
    """Immutable accuracy/latency/verification requirements."""

    mode: ExecutionMode
    minimum_accuracy: float
    latency_target_ms: int
    max_parallel_branches: int
    verification_required: bool

    def validate(self) -> None:
        if not 0.0 <= float(self.minimum_accuracy) <= 1.0:
            raise ValueError("minimum_accuracy must be within 0..1")
        if not 1 <= int(self.latency_target_ms) <= 3_600_000:
            raise ValueError("latency_target_ms outside policy")
        if not 1 <= int(self.max_parallel_branches) <= 256:
            raise ValueError("max_parallel_branches outside policy")


class PrecisionGovernor:
    """Map task requirements to an explicit execution budget."""

    def plan(self, *, risk: str = "normal", accuracy_required: float = 0.90, latency_target_ms: int = 2000) -> PrecisionBudget:
        accuracy = max(0.0, min(1.0, float(accuracy_required)))
        latency = max(1, min(int(latency_target_ms), 3_600_000))
        risk_name = str(risk).strip().lower()
        if risk_name in {"critical", "high"} or accuracy >= 0.995:
            mode = ExecutionMode.SUPREME
            budget = PrecisionBudget(mode, max(accuracy, 0.995), latency, 8, True)
        elif accuracy >= 0.95 or risk_name == "important":
            mode = ExecutionMode.BALANCED
            budget = PrecisionBudget(mode, max(accuracy, 0.95), latency, 4, True)
        else:
            mode = ExecutionMode.TURBO
            budget = PrecisionBudget(mode, accuracy, latency, 1 if latency < 250 else 2, False)
        budget.validate()
        return budget


@dataclass(frozen=True, slots=True)
class FastPathRule:
    """Deterministic rule for bypassing expensive model inference."""

    name: str
    predicate: Callable[[str], bool]
    handler: Callable[[str], Any]


@dataclass(frozen=True, slots=True)
class FastPathResult:
    """Result of deterministic dispatch."""

    matched: bool
    rule: str | None
    result: Any = None
    latency_ms: float = 0.0


class ExecutionFastPath:
    """Ordered deterministic pre-inference dispatch."""

    def __init__(self) -> None:
        self._rules: list[FastPathRule] = []
        self._lock = threading.RLock()

    def register(self, rule: FastPathRule) -> None:
        if not str(rule.name).strip() or not callable(rule.predicate) or not callable(rule.handler):
            raise ValueError("invalid fast-path rule")
        with self._lock:
            if any(existing.name == rule.name for existing in self._rules):
                raise ValueError("fast-path rule already exists")
            self._rules.append(rule)

    def dispatch(self, request: str) -> FastPathResult:
        text = str(request).strip()
        started = time.perf_counter()
        with self._lock:
            rules = tuple(self._rules)
        for rule in rules:
            try:
                if rule.predicate(text):
                    return FastPathResult(True, rule.name, rule.handler(text), (time.perf_counter() - started) * 1000.0)
            except Exception:
                continue
        return FastPathResult(False, None, None, (time.perf_counter() - started) * 1000.0)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"rules": [rule.name for rule in self._rules], "count": len(self._rules)}


@dataclass(frozen=True, slots=True)
class ContextCacheScope:
    """Privacy and model generation boundary for cached context."""

    owner: str
    workspace: str
    privacy_domain: str
    policy_digest: str
    model_generation: str


@dataclass(frozen=True, slots=True)
class ContextCacheEntry:
    """Bounded cache item."""

    key: str
    scope: ContextCacheScope
    value: Any
    created_at: float
    last_used: float
    ttl_seconds: float


class ContextCache:
    """LRU cache with cryptographically scoped keys."""

    def __init__(self, *, max_entries: int = 4096) -> None:
        self.max_entries = max(16, min(int(max_entries), 1_000_000))
        self._entries: OrderedDict[str, ContextCacheEntry] = OrderedDict()
        self._lock = threading.RLock()

    @staticmethod
    def key(context_digest: str, scope: ContextCacheScope) -> str:
        canonical = f"{context_digest}|{scope.owner}|{scope.workspace}|{scope.privacy_domain}|{scope.policy_digest}|{scope.model_generation}".encode("utf-8")
        return hashlib.sha256(canonical).hexdigest()

    def put(self, context_digest: str, scope: ContextCacheScope, value: Any, *, ttl_seconds: float = 300.0) -> str:
        ttl = max(1.0, min(float(ttl_seconds), 86_400.0))
        key = self.key(context_digest, scope)
        now = time.time()
        with self._lock:
            self._entries.pop(key, None)
            while len(self._entries) >= self.max_entries:
                self._entries.popitem(last=False)
            self._entries[key] = ContextCacheEntry(key, scope, value, now, now, ttl)
        return key

    def get(self, key: str, scope: ContextCacheScope) -> Any | None:
        with self._lock:
            entry = self._entries.get(str(key))
            if entry is None or entry.scope != scope:
                return None
            if time.time() - entry.created_at >= entry.ttl_seconds:
                self._entries.pop(entry.key, None)
                return None
            refreshed = ContextCacheEntry(entry.key, entry.scope, entry.value, entry.created_at, time.time(), entry.ttl_seconds)
            self._entries[entry.key] = refreshed
            self._entries.move_to_end(entry.key)
            return entry.value

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"entries": len(self._entries), "max_entries": self.max_entries}

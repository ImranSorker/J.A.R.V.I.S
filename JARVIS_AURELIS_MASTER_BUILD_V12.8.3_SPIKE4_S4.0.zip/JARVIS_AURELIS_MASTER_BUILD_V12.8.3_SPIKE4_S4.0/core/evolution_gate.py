"""Safe self-evolution promotion gate; validation only, never arbitrary execution."""
from __future__ import annotations

import ast
import hashlib
import hmac
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True, slots=True)
class CandidateManifest:
    """Immutable candidate manifest used for promotion decisions."""

    candidate_id: str
    parent_version: str
    changed_files: tuple[str, ...]
    source_sha256: str
    tests_passed: bool
    security_passed: bool
    regression_passed: bool
    rollback_artifact: str
    signature: str


@dataclass(frozen=True, slots=True)
class PromotionDecision:
    """Result of candidate validation."""

    allowed: bool
    reason: str
    candidate_id: str


class EvolutionGate:
    """Validate candidate source without importing or executing it."""

    def __init__(self, repository_root: str | Path, signing_key: bytes, *, max_files: int = 512, max_bytes: int = 50_000_000) -> None:
        self.root = Path(repository_root).resolve()
        self.key = bytes(signing_key)
        if not self.key:
            raise ValueError("signing_key required")
        self.max_files = max(1, min(int(max_files), 10_000))
        self.max_bytes = max(1024, min(int(max_bytes), 500_000_000))

    def inspect_tree(self, candidate_root: str | Path) -> tuple[tuple[str, ...], str]:
        """Parse source files and produce deterministic candidate digest."""
        root = Path(candidate_root).resolve()
        if not root.is_dir():
            raise ValueError("candidate root must be a directory")
        files: list[Path] = []
        total = 0
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in {".git", "__pycache__", ".pytest_cache", ".venv"} for part in path.relative_to(root).parts):
                continue
            rel = path.relative_to(root).as_posix()
            total += path.stat().st_size
            if total > self.max_bytes:
                raise ValueError("candidate exceeds size limit")
            files.append(path)
            if len(files) > self.max_files:
                raise ValueError("candidate exceeds file-count limit")
            if path.suffix == ".py":
                ast.parse(path.read_text(encoding="utf-8"), filename=rel)
        files.sort(key=lambda p: p.relative_to(root).as_posix())
        material = []
        for path in files:
            rel = path.relative_to(root).as_posix()
            material.append({"path": rel, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        digest = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        return tuple(item["path"] for item in material), digest

    def sign_manifest(self, *, candidate_id: str, parent_version: str, changed_files: Iterable[str], source_sha256: str, tests_passed: bool, security_passed: bool, regression_passed: bool, rollback_artifact: str) -> CandidateManifest:
        files = tuple(sorted(str(v) for v in changed_files))
        canonical = self._canonical(candidate_id, parent_version, files, source_sha256, tests_passed, security_passed, regression_passed, rollback_artifact)
        sig = hmac.new(self.key, canonical, hashlib.sha256).hexdigest()
        return CandidateManifest(str(candidate_id), str(parent_version), files, str(source_sha256), bool(tests_passed), bool(security_passed), bool(regression_passed), str(rollback_artifact), sig)

    def verify_manifest(self, manifest: CandidateManifest) -> bool:
        expected = hmac.new(self.key, self._canonical(manifest.candidate_id, manifest.parent_version, manifest.changed_files, manifest.source_sha256, manifest.tests_passed, manifest.security_passed, manifest.regression_passed, manifest.rollback_artifact), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, manifest.signature)

    def decide(self, manifest: CandidateManifest, *, candidate_root: str | Path) -> PromotionDecision:
        """Allow promotion only when every required evidence gate is present."""
        if not self.verify_manifest(manifest):
            return PromotionDecision(False, "invalid candidate signature", manifest.candidate_id)
        if manifest.parent_version.strip() == "":
            return PromotionDecision(False, "missing parent version", manifest.candidate_id)
        if not manifest.changed_files:
            return PromotionDecision(False, "candidate has no changed files", manifest.candidate_id)
        root = Path(candidate_root).resolve()
        if not root.is_relative_to(self.root.parent) and root != self.root:
            return PromotionDecision(False, "candidate root outside trusted repository area", manifest.candidate_id)
        try:
            files, digest = self.inspect_tree(root)
        except Exception as exc:
            return PromotionDecision(False, f"static validation failed: {type(exc).__name__}: {exc}", manifest.candidate_id)
        if digest != manifest.source_sha256:
            return PromotionDecision(False, "candidate digest mismatch", manifest.candidate_id)
        if not set(manifest.changed_files).issubset(set(files)):
            return PromotionDecision(False, "manifest references missing files", manifest.candidate_id)
        if not manifest.tests_passed or not manifest.security_passed or not manifest.regression_passed:
            return PromotionDecision(False, "required evidence gate failed", manifest.candidate_id)
        if not manifest.rollback_artifact or len(manifest.rollback_artifact) > 4096:
            return PromotionDecision(False, "rollback artifact metadata missing", manifest.candidate_id)
        return PromotionDecision(True, "candidate is statically validated and evidence-complete", manifest.candidate_id)

    @staticmethod
    def _canonical(candidate_id: str, parent_version: str, changed_files: tuple[str, ...], source_sha256: str, tests_passed: bool, security_passed: bool, regression_passed: bool, rollback_artifact: str) -> bytes:
        return json.dumps({"candidate_id": candidate_id, "parent_version": parent_version, "changed_files": list(changed_files), "source_sha256": source_sha256, "tests_passed": tests_passed, "security_passed": security_passed, "regression_passed": regression_passed, "rollback_artifact": rollback_artifact}, sort_keys=True, separators=(",", ":")).encode("utf-8")

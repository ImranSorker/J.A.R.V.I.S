"""Long-lived, supervised agent workers with durable heartbeats and safe lifecycles."""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


@dataclass(frozen=True, slots=True)
class WorkerSpec:
    """Bounded persistent worker configuration."""

    worker_id: str
    role: str
    objective: str
    interval_seconds: float = 15.0
    max_lifetime_seconds: float = 86_400.0
    max_cycles: int = 10_000


@dataclass(frozen=True, slots=True)
class WorkerState:
    """Current supervised-worker state."""

    worker_id: str
    role: str
    status: str
    cycles: int
    started_at: float | None
    last_heartbeat: float | None
    last_error: str | None


class LongTermAgentWorker:
    """A persistent, restartable worker loop with bounded resources and no privilege bypass."""

    def __init__(self, spec: WorkerSpec, run_once: Callable[[WorkerSpec, int], Mapping[str, Any] | None], *, checkpoint: Callable[[WorkerState], None] | None = None) -> None:
        self.spec = spec
        self.run_once = run_once
        self.checkpoint = checkpoint
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._state = WorkerState(spec.worker_id, spec.role, "stopped", 0, None, None, None)

    def start(self) -> WorkerState:
        """Start the worker exactly once; repeated starts are idempotent."""
        with self._lock:
            if self._thread and self._thread.is_alive():
                return self._state
            self._stop.clear()
            self._state = WorkerState(self.spec.worker_id, self.spec.role, "running", 0, time.time(), None, None)
            self._thread = threading.Thread(target=self._run, name=f"jarvis-worker-{self.spec.worker_id}", daemon=True)
            self._thread.start()
            return self._state

    def stop(self, timeout_seconds: float = 5.0) -> WorkerState:
        """Request stop and wait only for the bounded worker shutdown window."""
        self._stop.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(max(0.1, min(float(timeout_seconds), 30.0)))
        return self.state()

    def state(self) -> WorkerState:
        """Return an immutable worker state snapshot."""
        with self._lock:
            return self._state

    def _run(self) -> None:
        started = self._state.started_at or time.time()
        try:
            while not self._stop.is_set():
                with self._lock:
                    current = self._state
                if current.cycles >= max(1, int(self.spec.max_cycles)):
                    break
                if time.time() - started >= max(1.0, float(self.spec.max_lifetime_seconds)):
                    break
                try:
                    self.run_once(self.spec, current.cycles)
                    updated = WorkerState(self.spec.worker_id, self.spec.role, "running", current.cycles + 1, started, time.time(), None)
                except Exception as exc:
                    updated = WorkerState(self.spec.worker_id, self.spec.role, "degraded", current.cycles + 1, started, time.time(), f"{type(exc).__name__}: {exc}")
                with self._lock:
                    self._state = updated
                if self.checkpoint is not None:
                    try:
                        self.checkpoint(updated)
                    except Exception:
                        continue
                self._stop.wait(max(0.1, min(float(self.spec.interval_seconds), 3600.0)))
        finally:
            with self._lock:
                current = self._state
                final_status = "stopped" if self._stop.is_set() else ("completed" if current.last_error is None else "degraded")
                self._state = WorkerState(current.worker_id, current.role, final_status, current.cycles, current.started_at, current.last_heartbeat, current.last_error)


class LongTermWorkerManager:
    """Registry and supervisor for persistent JARVIS agent workers."""

    def __init__(self, checkpoint_path: str | Path = "data/workers.jsonl", *, max_workers: int = 64) -> None:
        self.max_workers = max(1, min(int(max_workers), 256))
        self.path = Path(checkpoint_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._workers: dict[str, LongTermAgentWorker] = {}
        self._lock = threading.RLock()

    def register(self, role: str, objective: str, run_once: Callable[[WorkerSpec, int], Mapping[str, Any] | None], *, interval_seconds: float = 15.0) -> WorkerSpec:
        """Register a new bounded worker definition without starting it."""
        with self._lock:
            if len(self._workers) >= self.max_workers:
                raise ValueError("worker capacity exceeded")
            worker_id = f"worker_{uuid.uuid4().hex[:12]}"
            spec = WorkerSpec(worker_id, str(role).strip(), str(objective).strip(), interval_seconds=max(0.1, float(interval_seconds)))
            if not spec.role or not spec.objective:
                raise ValueError("role and objective are required")
            worker = LongTermAgentWorker(spec, run_once, checkpoint=self._checkpoint)
            self._workers[worker_id] = worker
            return spec

    def start(self, worker_id: str) -> WorkerState:
        """Start one registered worker."""
        return self._workers[str(worker_id)].start()

    def stop(self, worker_id: str) -> WorkerState:
        """Stop one registered worker."""
        return self._workers[str(worker_id)].stop()

    def stop_all(self) -> None:
        """Stop every worker safely."""
        for worker in tuple(self._workers.values()):
            worker.stop()

    def snapshot(self) -> dict[str, Any]:
        """Return worker lifecycle state for diagnostics/UI."""
        with self._lock:
            items = [worker.state() for worker in self._workers.values()]
        return {"count": len(items), "workers": [asdict(state) for state in items]}

    def _checkpoint(self, state: WorkerState) -> None:
        """Append a bounded JSON-line heartbeat checkpoint."""
        import json
        payload = json.dumps(asdict(state), sort_keys=True, separators=(",", ":"), default=str)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(payload + "\n")



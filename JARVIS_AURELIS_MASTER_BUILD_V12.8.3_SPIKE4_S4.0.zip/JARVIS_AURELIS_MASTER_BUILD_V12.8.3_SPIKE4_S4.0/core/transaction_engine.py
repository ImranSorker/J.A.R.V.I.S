"""Preview/commit/rollback transaction state machine."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

TransactionStatus = Literal["planned", "approved", "committed", "rolled_back", "failed"]

@dataclass(slots=True)
class Transaction:
    """A side-effect transaction with explicit state transitions."""
    transaction_id: str
    description: str
    status: TransactionStatus = "planned"

class TransactionEngine:
    """Enforce safe transaction ordering."""
    def approve(self, transaction: Transaction) -> None:
        """Move a planned transaction to approved."""
        if transaction.status != "planned":
            raise ValueError("only planned transactions can be approved")
        transaction.status = "approved"

    def commit(self, transaction: Transaction) -> None:
        """Commit an approved transaction."""
        if transaction.status != "approved":
            raise ValueError("transaction requires approval")
        transaction.status = "committed"

    def rollback(self, transaction: Transaction) -> None:
        """Rollback any non-committed transaction."""
        if transaction.status == "committed":
            raise ValueError("committed transaction requires compensating action")
        transaction.status = "rolled_back"



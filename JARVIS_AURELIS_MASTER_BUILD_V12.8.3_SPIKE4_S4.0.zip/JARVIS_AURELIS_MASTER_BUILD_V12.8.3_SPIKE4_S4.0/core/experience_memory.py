"""P2-H Experience Memory 2.0.

Typed, tenant-isolated, signed, provenance-aware memory fabric. Memory is an
explicit substrate: it does not grant authority, mutate genomes, or execute
code. Durable state is append-only and every control-plane operation is
observable on the P2-U Memory event family.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import math
import re
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_harness import ExecutionContext
from core.event_fabric import AuthContext, EventEnvelope, EventLineage, EventBus, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

BASE_DIR = Path(__file__).resolve().parent
SCHEMA_DIR = BASE_DIR / "schemas"
ITEM_SCHEMA = SCHEMA_DIR / "memory_item_v1.schema.json"
TYPE_SCHEMAS = {
    "episodic": SCHEMA_DIR / "memory_episodic_v1.schema.json",
    "semantic": SCHEMA_DIR / "memory_semantic_v1.schema.json",
    "procedural": SCHEMA_DIR / "memory_procedural_v1.schema.json",
    "working": SCHEMA_DIR / "memory_working_v1.schema.json",
    "task": SCHEMA_DIR / "memory_task_v1.schema.json",
    "agent": SCHEMA_DIR / "memory_agent_v1.schema.json",
    "system": SCHEMA_DIR / "memory_system_v1.schema.json",
    "world_state": SCHEMA_DIR / "memory_world_state_v1.schema.json",
    "failure": SCHEMA_DIR / "memory_failure_v1.schema.json",
}

MEMORY_TYPES = tuple(TYPE_SCHEMAS)

def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _b64d(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"), validate=True)
_DEFAULT_DECAY = {
    "episodic": 0.001,
    "semantic": 0.00003,
    "procedural": 0.00002,
    "working": 0.2,
    "task": 0.01,
    "agent": 0.0001,
    "system": 0.00001,
    "world_state": 0.001,
    "failure": 0.00002,
}
_DEFAULT_IMPORTANCE = {
    "episodic": 0.45,
    "semantic": 0.65,
    "procedural": 0.75,
    "working": 0.2,
    "task": 0.5,
    "agent": 0.55,
    "system": 0.7,
    "world_state": 0.6,
    "failure": 0.8,
}
_DEFAULT_WEIGHTS = {"confidence": 0.30, "importance": 0.25, "reliability": 0.25, "recency": 0.20}
_SCOPE_BY_TYPE = {
    "episodic": "memory.read.episodic",
    "semantic": "memory.read.semantic",
    "procedural": "memory.read.procedural",
    "working": "memory.read.working",
    "task": "memory.read.task",
    "agent": "memory.read.agent",
    "system": "memory.read.system",
    "world_state": "memory.read.world_state",
    "failure": "memory.read.failure",
}
_WRITE_SCOPE_BY_TYPE = {k: v.replace("memory.read", "memory.write") for k, v in _SCOPE_BY_TYPE.items()}
_MEMORY_EVENTS = {
    "Written", "Read", "Superseded", "Linked", "Consolidated", "ConsolidationBlocked",
    "ContradictionDetected", "ContradictionResolved", "Archived", "Forgotten", "Restored",
    "Promoted", "AccessDenied", "DependencyForgotten", "Scored", "Decayed", "Quarantined",
}


class MemoryError(RuntimeError):
    """Base memory-fabric error."""


class MemorySchemaError(MemoryError, ValueError):
    """Schema validation failure."""


class MemorySignatureError(MemoryError, ValueError):
    """Signature/integrity verification failure."""


class MemoryAccessDenied(MemoryError, PermissionError):
    """Scope or tenant authorization failure."""


class DuplicateMemory(MemoryError):
    """Exact duplicate write rejected."""


class ContradictionError(MemoryError):
    """Contradictory items block an operation."""


class MemoryNotFound(MemoryError):
    """Memory item not found."""


class MemoryPolicyError(MemoryError):
    """Lifecycle/policy constraint was violated."""


class SnapshotEnvironmentMismatch(MemoryError):
    """Memory snapshot is bound to another environment."""


class MemoryKind(StrEnum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    WORKING = "working"
    TASK = "task"
    AGENT = "agent"
    SYSTEM = "system"
    WORLD_STATE = "world_state"
    FAILURE = "failure"


@dataclass(frozen=True, slots=True)
class MemoryConfig:
    weights: Mapping[str, float]
    default_decay: Mapping[str, float]
    default_importance: Mapping[str, float]
    stale_after_seconds: float = 300.0
    near_duplicate_threshold: float = 0.985
    archive_score_threshold: float = 0.15
    archive_age_seconds: float = 30 * 24 * 3600.0

    def __post_init__(self) -> None:
        if set(self.weights) != set(_DEFAULT_WEIGHTS):
            raise ValuePolicyError("weights must contain confidence, importance, reliability, recency")
        total = sum(float(v) for v in self.weights.values())
        if not math.isclose(total, 1.0, rel_tol=0.0, abs_tol=1e-9):
            raise MemoryPolicyError("memory scoring weights must sum to 1.0")
        for key, value in self.weights.items():
            if not 0.0 <= float(value) <= 1.0:
                raise MemoryPolicyError(f"invalid weight for {key}")
        for table in (self.default_decay, self.default_importance):
            if set(table) != set(MEMORY_TYPES):
                raise MemoryPolicyError("per-type memory configuration is incomplete")


class ValuePolicyError(MemoryPolicyError):
    """Compatibility alias for malformed scoring configuration."""


DEFAULT_CONFIG = MemoryConfig(_DEFAULT_WEIGHTS, _DEFAULT_DECAY, _DEFAULT_IMPORTANCE)


class VectorIndex(Protocol):
    """Optional vector index contract; vector search is intentionally external."""

    def neighbors(self, tenant_id: str, query: Sequence[float], threshold: float) -> Sequence[tuple[str, float]]: ...

    def put(self, tenant_id: str, memory_id: str, vector: Sequence[float]) -> None: ...


class SecretBroker(Protocol):
    """Minimal secret-broker verification contract; secret values never enter memory."""

    def verify_handle(self, handle: str, *, tenant_id: str, principal: str) -> bool: ...


class NullVectorIndex:
    """No-op vector index used until a real vector store is injected."""

    def neighbors(self, tenant_id: str, query: Sequence[float], threshold: float) -> Sequence[tuple[str, float]]:
        return ()

    def put(self, tenant_id: str, memory_id: str, vector: Sequence[float]) -> None:
        return None


class MemoryStoreDurable:
    """SQLite append-only storage with HMAC-protected records and blob tiering."""

    def __init__(self, path: str | Path, secret: bytes, *, blob_threshold: int = 64 * 1024) -> None:
        if len(secret) < 32:
            raise ValueError("durable memory storage secret must be at least 32 bytes")
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = bytes(secret)
        self.blob_threshold = int(blob_threshold)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("""CREATE TABLE IF NOT EXISTS memory_current(
            tenant_id TEXT NOT NULL, memory_id TEXT NOT NULL, version INTEGER NOT NULL,
            document TEXT NOT NULL, integrity_tag TEXT NOT NULL, content_hash TEXT NOT NULL,
            recorded_at REAL NOT NULL, PRIMARY KEY(tenant_id,memory_id))""")
        self._db.execute("""CREATE TABLE IF NOT EXISTS memory_versions(
            tenant_id TEXT NOT NULL, memory_id TEXT NOT NULL, version INTEGER NOT NULL,
            document TEXT NOT NULL, integrity_tag TEXT NOT NULL, content_hash TEXT NOT NULL,
            recorded_at REAL NOT NULL, PRIMARY KEY(tenant_id,memory_id,version))""")
        self._db.execute("""CREATE TABLE IF NOT EXISTS memory_relations(
            tenant_id TEXT NOT NULL, memory_id TEXT NOT NULL, target_id TEXT NOT NULL,
            relation_kind TEXT NOT NULL, confidence REAL NOT NULL, version INTEGER NOT NULL,
            PRIMARY KEY(tenant_id,memory_id,target_id,relation_kind))""")
        self._db.execute("""CREATE TABLE IF NOT EXISTS memory_blobs(
            tenant_id TEXT NOT NULL, body_hash TEXT NOT NULL, body_json TEXT NOT NULL,
            integrity_tag TEXT NOT NULL, PRIMARY KEY(tenant_id,body_hash))""")
        self._db.execute("""CREATE TABLE IF NOT EXISTS memory_chain(
            tenant_id TEXT NOT NULL, sequence INTEGER NOT NULL, memory_id TEXT NOT NULL,
            memory_version INTEGER NOT NULL, record_hash TEXT NOT NULL, previous_hash TEXT,
            integrity_tag TEXT NOT NULL, document TEXT NOT NULL, recorded_at REAL NOT NULL,
            PRIMARY KEY(tenant_id,sequence))""")
        self._db.commit()

    def _tag(self, kind: str, material: str) -> str:
        return hmac.new(self.secret, f"{kind}|{material}".encode("utf-8"), hashlib.sha256).hexdigest()

    def _append_chain_row(self, tenant_id: str, document: Mapping[str, Any], payload: str, recorded_at: float) -> None:
        previous_row = self._db.execute(
            "SELECT sequence,record_hash FROM memory_chain WHERE tenant_id=? ORDER BY sequence DESC LIMIT 1",
            (tenant_id,),
        ).fetchone()
        sequence = 1 if previous_row is None else int(previous_row[0]) + 1
        previous_hash = None if previous_row is None else str(previous_row[1])
        material = {
            "tenant_id": tenant_id,
            "sequence": sequence,
            "memory_id": str(document["memory_id"]),
            "memory_version": int(document["memory_version"]),
            "document": json.loads(payload),
            "previous_hash": previous_hash,
        }
        record_hash = hashlib.sha256(canonical_bytes(material)).hexdigest()
        tag = self._tag("chain", f"{tenant_id}|{sequence}|{record_hash}|{payload}|{previous_hash or ''}")
        self._db.execute(
            "INSERT INTO memory_chain VALUES(?,?,?,?,?,?,?,?,?)",
            (tenant_id, sequence, str(document["memory_id"]), int(document["memory_version"]), record_hash, previous_hash, tag, payload, recorded_at),
        )

    def put(self, tenant_id: str, document: Mapping[str, Any]) -> None:
        payload = json.dumps(document, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        content_hash = _memory_content_hash(document)
        tag = self._tag("record", f"{tenant_id}|{document['memory_id']}|{document['memory_version']}|{content_hash}|{payload}")
        now = _timestamp(document.get("recorded_at"))
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO memory_versions VALUES(?,?,?,?,?,?,?)",
                (tenant_id, document["memory_id"], int(document["memory_version"]), payload, tag, content_hash, now),
            )
            self._db.execute(
                "INSERT OR REPLACE INTO memory_current VALUES(?,?,?,?,?,?,?)",
                (tenant_id, document["memory_id"], int(document["memory_version"]), payload, tag, content_hash, now),
            )
            self._append_chain_row(tenant_id, document, payload, now)

    def put_many(self, tenant_id: str, documents: Sequence[Mapping[str, Any]]) -> None:
        with self._lock, self._db:
            for document in documents:
                payload = json.dumps(document, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                content_hash = _memory_content_hash(document)
                tag = self._tag("record", f"{tenant_id}|{document['memory_id']}|{document['memory_version']}|{content_hash}|{payload}")
                now = _timestamp(document.get("recorded_at"))
                self._db.execute(
                    "INSERT INTO memory_versions VALUES(?,?,?,?,?,?,?)",
                    (tenant_id, document["memory_id"], int(document["memory_version"]), payload, tag, content_hash, now),
                )
                self._db.execute(
                    "INSERT OR REPLACE INTO memory_current VALUES(?,?,?,?,?,?,?)",
                    (tenant_id, document["memory_id"], int(document["memory_version"]), payload, tag, content_hash, now),
                )
                self._append_chain_row(tenant_id, document, payload, now)

    def verify_chain(self, tenant_id: str) -> bool:
        rows = self._db.execute(
            "SELECT sequence,memory_id,memory_version,record_hash,previous_hash,integrity_tag,document FROM memory_chain WHERE tenant_id=? ORDER BY sequence",
            (tenant_id,),
        ).fetchall()
        previous = None
        expected_sequence = 1
        for sequence, memory_id, memory_version, record_hash, previous_hash, integrity_tag, payload in rows:
            if int(sequence) != expected_sequence or previous_hash != previous:
                return False
            material = {
                "tenant_id": tenant_id,
                "sequence": int(sequence),
                "memory_id": str(memory_id),
                "memory_version": int(memory_version),
                "document": json.loads(payload),
                "previous_hash": previous_hash,
            }
            expected_hash = hashlib.sha256(canonical_bytes(material)).hexdigest()
            if expected_hash != str(record_hash):
                return False
            expected_tag = self._tag("chain", f"{tenant_id}|{int(sequence)}|{record_hash}|{payload}|{previous_hash or ''}")
            if not hmac.compare_digest(expected_tag, str(integrity_tag)):
                return False
            previous = str(record_hash)
            expected_sequence += 1
        return True

    def get(self, tenant_id: str, memory_id: str, version: int | None = None) -> dict[str, Any] | None:
        sql = "SELECT document,integrity_tag,content_hash FROM memory_current WHERE tenant_id=? AND memory_id=?"
        args: tuple[Any, ...] = (tenant_id, memory_id)
        if version is not None:
            sql = "SELECT document,integrity_tag,content_hash FROM memory_versions WHERE tenant_id=? AND memory_id=? AND version=?"
            args = (tenant_id, memory_id, int(version))
        row = self._db.execute(sql, args).fetchone()
        if not row:
            return None
        doc = json.loads(row[0])
        expected = self._tag("record", f"{tenant_id}|{doc['memory_id']}|{doc['memory_version']}|{row[2]}|{row[0]}")
        if not hmac.compare_digest(expected, str(row[1])):
            raise MemorySignatureError("durable memory record HMAC mismatch")
        if _memory_content_hash(doc) != str(row[2]):
            raise MemorySignatureError("durable memory content hash mismatch")
        return doc

    def list_current(self, tenant_id: str, memory_type: str | None = None) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT document FROM memory_current WHERE tenant_id=? ORDER BY memory_id", (tenant_id,)).fetchall()
        docs = [self.get(tenant_id, str(json.loads(r[0])["memory_id"])) for r in rows]
        return [d for d in docs if d is not None and (memory_type is None or d["memory_type"] == memory_type)]

    def history(self, tenant_id: str, memory_id: str) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT version FROM memory_versions WHERE tenant_id=? AND memory_id=? ORDER BY version", (tenant_id, memory_id)).fetchall()
        result: list[dict[str, Any]] = []
        for (version,) in rows:
            doc = self.get(tenant_id, memory_id, int(version))
            if doc is not None:
                result.append(doc)
        return result

    def put_blob(self, tenant_id: str, body_hash: str, body: Mapping[str, Any]) -> str:
        raw = json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        tag = self._tag("blob", f"{tenant_id}|{body_hash}|{raw}")
        with self._lock, self._db:
            self._db.execute("INSERT OR IGNORE INTO memory_blobs VALUES(?,?,?,?)", (tenant_id, body_hash, raw, tag))
        return f"memoryblob://{tenant_id}/{body_hash}"

    def get_blob(self, tenant_id: str, body_hash: str) -> dict[str, Any] | None:
        row = self._db.execute("SELECT body_json,integrity_tag FROM memory_blobs WHERE tenant_id=? AND body_hash=?", (tenant_id, body_hash)).fetchone()
        if not row:
            return None
        expected = self._tag("blob", f"{tenant_id}|{body_hash}|{row[0]}")
        if not hmac.compare_digest(expected, str(row[1])):
            raise MemorySignatureError("memory blob HMAC mismatch")
        return json.loads(row[0])

    def snapshot(self, tenant_id: str) -> dict[str, Any]:
        docs = self.list_current(tenant_id)
        blobs: dict[str, Any] = {}
        for doc in docs:
            ref = doc.get("content", {}).get("body_ref")
            if ref:
                body_hash = str(ref).rsplit("/", 1)[-1]
                blob = self.get_blob(tenant_id, body_hash)
                if blob is not None:
                    blobs[body_hash] = blob
        base = {"schema_version": "1.0.0", "tenant_id": tenant_id, "items": docs, "blobs": blobs}
        base["snapshot_hash"] = hashlib.sha256(canonical_bytes(base)).hexdigest()
        return base

    def restore(self, tenant_id: str, snapshot: Mapping[str, Any], *, environment_hash: str | None = None) -> int:
        if str(snapshot.get("tenant_id")) != tenant_id:
            raise MemoryAccessDenied("memory snapshot tenant mismatch")
        expected = str(snapshot.get("snapshot_hash", ""))
        base = {k: v for k, v in snapshot.items() if k != "snapshot_hash"}
        if not expected or not hmac.compare_digest(expected, hashlib.sha256(canonical_bytes(base)).hexdigest()):
            raise MemorySignatureError("memory snapshot integrity mismatch")
        blobs = dict(snapshot.get("blobs", {}))
        with self._lock, self._db:
            for body_hash, body in blobs.items():
                self.put_blob(tenant_id, str(body_hash), body)
            for doc in list(snapshot.get("items", [])):
                payload = json.dumps(doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                content_hash = _memory_content_hash(doc)
                tag = self._tag("record", f"{tenant_id}|{doc['memory_id']}|{doc['memory_version']}|{content_hash}|{payload}")
                now = _timestamp(doc.get("recorded_at"))
                self._db.execute("INSERT OR IGNORE INTO memory_versions VALUES(?,?,?,?,?,?,?)", (tenant_id, doc["memory_id"], int(doc["memory_version"]), payload, tag, content_hash, now))
                self._db.execute("INSERT OR REPLACE INTO memory_current VALUES(?,?,?,?,?,?,?)", (tenant_id, doc["memory_id"], int(doc["memory_version"]), payload, tag, content_hash, now))
        return len(list(snapshot.get("items", [])))

    def close(self) -> None:
        self._db.close()


class MemoryStoreEphemeral:
    """Session-scoped working-memory storage with TTL semantics."""

    def __init__(self, clock: callable = time.time) -> None:
        self.clock = clock
        self._items: dict[tuple[str, str], dict[str, Any]] = {}
        self._lock = threading.RLock()

    def put(self, tenant_id: str, document: Mapping[str, Any]) -> None:
        with self._lock:
            self._items[(tenant_id, document["memory_id"])] = copy.deepcopy(dict(document))

    def get(self, tenant_id: str, memory_id: str) -> dict[str, Any] | None:
        with self._lock:
            doc = self._items.get((tenant_id, memory_id))
            if doc is None:
                return None
            ttl = doc["content"]["body"].get("ttl_seconds") if isinstance(doc["content"].get("body"), dict) else None
            if ttl is not None and _iso_to_epoch(doc["recorded_at"]) + float(ttl) <= float(self.clock()):
                self._items.pop((tenant_id, memory_id), None)
                return None
            return copy.deepcopy(doc)

    def list_current(self, tenant_id: str, memory_type: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            self._purge(tenant_id)
            docs = [copy.deepcopy(v) for (t, _), v in self._items.items() if t == tenant_id and (memory_type is None or v["memory_type"] == memory_type)]
        docs.sort(key=lambda d: d["memory_id"])
        return docs

    def history(self, tenant_id: str, memory_id: str) -> list[dict[str, Any]]:
        doc = self.get(tenant_id, memory_id)
        return [] if doc is None else [doc]

    def _purge(self, tenant_id: str) -> None:
        now = float(self.clock())
        for key, doc in list(self._items.items()):
            if key[0] != tenant_id:
                continue
            body = doc.get("content", {}).get("body")
            ttl = body.get("ttl_seconds") if isinstance(body, dict) else None
            if ttl is not None and _iso_to_epoch(doc["recorded_at"]) + float(ttl) <= now:
                self._items.pop(key, None)


class MemoryProjector:
    """Deterministic event-log projector used for replay/time-travel."""

    def __init__(self, tenant_id: str) -> None:
        self.tenant_id = tenant_id
        self.items: dict[str, dict[str, Any]] = {}

    def apply(self, event: Mapping[str, Any] | Any) -> None:
        payload = dict(event.payload) if hasattr(event, "payload") else dict(event.get("payload", {}))
        tenant = event.tenant_id if hasattr(event, "tenant_id") else event.get("tenant_id")
        if tenant != self.tenant_id:
            raise MemoryAccessDenied("replay tenant mismatch")
        name = event.event_name if hasattr(event, "event_name") else str(event.get("event_name"))
        doc = payload.get("item")
        if name in {"Written", "Restored", "Promoted", "Superseded", "Consolidated"} and isinstance(doc, Mapping):
            self.items[str(doc["memory_id"])] = copy.deepcopy(dict(doc))
        elif name in {"Forgotten"}:
            mid = str(payload.get("memory_id"))
            current = self.items.get(mid)
            if current is not None:
                current = copy.deepcopy(current)
                current["state"] = "forgotten"
                current["forgotten_at"] = payload.get("forgotten_at")
                current["content"]["body"] = {"tombstone": payload.get("tombstone_hash")}
                current["content"]["body_ref"] = None
                self.items[mid] = current
        elif name in {"Archived", "Decayed", "Scored", "ContradictionResolved", "ContradictionDetected", "Linked", "Quarantined"}:
            mid = str(payload.get("memory_id"))
            if mid in self.items and isinstance(payload.get("item"), Mapping):
                self.items[mid] = copy.deepcopy(dict(payload["item"]))
        elif name == "DependencyForgotten":
            return None
        return None


@dataclass(frozen=True, slots=True)
class ForgetRecord:
    memory_id: str
    reason: str
    actor: Mapping[str, str]
    correlation_id: str
    timestamp: str
    policy_ref: str
    signature: str
    integrity_hash: str

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__) if hasattr(self, "__dict__") else {
            "memory_id": self.memory_id, "reason": self.reason, "actor": dict(self.actor),
            "correlation_id": self.correlation_id, "timestamp": self.timestamp, "policy_ref": self.policy_ref,
            "signature": self.signature, "integrity_hash": self.integrity_hash,
        }


class ExperienceMemory:
    """Tenant-scoped typed memory facade and lifecycle engine."""

    def __init__(
        self,
        *,
        tenant_id: str,
        durable_store: MemoryStoreDurable,
        ephemeral_store: MemoryStoreEphemeral | None = None,
        signer: Ed25519PrivateKey | None = None,
        event_bus: EventBus | Any | None = None,
        vector_index: VectorIndex | None = None,
        secret_broker: SecretBroker | None = None,
        config: MemoryConfig = DEFAULT_CONFIG,
        clock: callable = time.time,
        blob_threshold: int = 64 * 1024,
    ) -> None:
        if not str(tenant_id).strip():
            raise ValueError("tenant_id is required")
        self.tenant_id = str(tenant_id)
        self.durable = durable_store
        self.ephemeral = ephemeral_store or MemoryStoreEphemeral(clock=clock)
        self.signer = signer or Ed25519PrivateKey.generate()
        self.event_bus = event_bus
        self.vector_index = vector_index or NullVectorIndex()
        self.secret_broker = secret_broker
        self.config = config
        self.clock = clock
        self.blob_threshold = int(blob_threshold)
        self._lock = threading.RLock()
        self._deny_count = 0

    @property
    def public_key_b64(self) -> str:
        raw = self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return _b64(raw)

    def _auth(self, auth_context: Any, *, memory_type: str, write: bool = False, sensitivity: str = "internal") -> Mapping[str, Any]:
        if isinstance(auth_context, ExecutionContext):
            auth = auth_context.auth_context
            tenant = auth_context.tenant_id
            scopes = tuple(auth.scopes)
            principal = auth.principal
            policy_ref = auth.policy_ref
            verified = bool(auth.authorization_token)
        elif isinstance(auth_context, Mapping):
            tenant = auth_context.get("tenant_id", self.tenant_id)
            scopes = tuple(auth_context.get("scopes", ()))
            principal = str(auth_context.get("principal", "unknown"))
            policy_ref = str(auth_context.get("policy_ref", "memory"))
            verified = bool(auth_context.get("authorization_verified", auth_context.get("authorization_token", True)))
        else:
            raise MemoryAccessDenied("ExecutionContext.auth_context is required")
        if tenant != self.tenant_id:
            self._deny("tenant_mismatch", memory_type, principal)
            raise MemoryAccessDenied("cross-tenant memory access denied")
        needed = _WRITE_SCOPE_BY_TYPE[memory_type] if write else _SCOPE_BY_TYPE[memory_type]
        if needed not in scopes and "memory.admin" not in scopes:
            self._deny("scope_denied", memory_type, principal)
            raise MemoryAccessDenied(f"missing memory scope: {needed}")
        if not verified:
            self._deny("unverified_authorization", memory_type, principal)
            raise MemoryAccessDenied("authorization context is not verified")
        if sensitivity == "secret":
            if "secrets.read" not in scopes and "secret" not in scopes and "memory.admin" not in scopes:
                self._deny("secret_scope_denied", memory_type, principal)
                raise MemoryAccessDenied("secret memory requires secret scope")
            handle = auth_context.get("secret_handle") if isinstance(auth_context, Mapping) else getattr(auth_context, "secret_handle", None)
            if self.secret_broker is None or not handle or not self.secret_broker.verify_handle(str(handle), tenant_id=self.tenant_id, principal=principal):
                self._deny("secret_broker_denied", memory_type, principal)
                raise MemoryAccessDenied("secret memory requires a valid secret-broker handle")
        return {"tenant_id": tenant, "scopes": scopes, "principal": principal, "policy_ref": policy_ref}

    def _deny(self, reason: str, memory_type: str, principal: str) -> None:
        self._deny_count += 1
        self._emit("AccessDenied", {"reason": reason, "memory_type": memory_type, "principal": principal}, priority="high")

    def _emit(self, name: str, payload: Mapping[str, Any], *, correlation_id: str | None = None, causation_id: str | None = None, partition_key: str | None = None, priority: str | None = None) -> None:
        if self.event_bus is None:
            return
        try:
            producer = ProducedBy("system", "experience-memory", hashlib.sha256(base64.b64decode(self.public_key_b64)).hexdigest(), "system")
            event = EventEnvelope.create(
                event_type="Memory", event_name=name, payload=dict(payload), produced_by=producer,
                auth_context=AuthContext("experience-memory", ("events.publish.memory",), "memory", None),
                tenant_id=self.tenant_id, partition_key=partition_key or str(payload.get("memory_id", self.tenant_id)),
                correlation_id=correlation_id or str(uuid.uuid4()), causation_id=causation_id,
                signing_key=self.signer, priority=priority,
            )
            self.event_bus.publish(event)
        except Exception as exc:
            raise MemoryError(f"memory event publication failed: {type(exc).__name__}: {exc}") from exc

    def _validate_item(self, item: Mapping[str, Any], *, allow_unsigned: bool = False) -> dict[str, Any]:
        doc = copy.deepcopy(dict(item))
        try:
            SchemaValidator(max_errors=128).validate_or_raise(doc, json.loads(ITEM_SCHEMA.read_text(encoding="utf-8")))
            kind = str(doc["memory_type"])
            if kind not in MEMORY_TYPES:
                raise MemorySchemaError(f"unsupported memory type: {kind}")
            body = doc["content"]["body"]
            cold_body = bool(doc["content"].get("body_ref")) and body == {}
            tombstoned = doc["state"] == "forgotten" and isinstance(body, Mapping) and set(body) == {"tombstone"}
            if not (cold_body or tombstoned):
                SchemaValidator(max_errors=64).validate_or_raise(body, json.loads(TYPE_SCHEMAS[kind].read_text(encoding="utf-8")))
        except Exception as exc:
            if isinstance(exc, MemorySchemaError):
                raise
            raise MemorySchemaError(str(exc)) from exc
        if not allow_unsigned and not _verify_memory_signature(doc):
            raise MemorySignatureError("memory item signature invalid")
        if _memory_content_hash(doc) != _memory_content_hash(doc):
            raise MemorySignatureError("unreachable content integrity failure")
        return doc

    def write(self, item: Mapping[str, Any], auth_context: Any, *, allow_duplicate: bool = False) -> str:
        doc = self._validate_item(item)
        kind = str(doc["memory_type"])
        self._auth(auth_context, memory_type=kind, write=True, sensitivity=str(doc["sensitivity"]))
        if doc["tenant_id"] != self.tenant_id:
            raise MemoryAccessDenied("cross-tenant write denied")
        self._ensure_provenance_acyclic(doc)
        if kind == "working":
            target_store: Any = self.ephemeral
        else:
            target_store = self.durable
        content_hash = _memory_content_hash(doc)
        if not allow_duplicate:
            for candidate in target_store.list_current(self.tenant_id, kind):
                if _memory_content_hash(candidate) == content_hash and candidate["memory_id"] != doc["memory_id"]:
                    raise DuplicateMemory(f"exact duplicate content already exists as {candidate['memory_id']}")
        body = doc["content"].get("body", {})
        if len(canonical_bytes(body)) > self.blob_threshold and kind != "working":
            body_hash = hashlib.sha256(canonical_bytes(body)).hexdigest()
            ref = self.durable.put_blob(self.tenant_id, body_hash, body)
            doc["content"]["body_ref"] = ref
            doc = _resign_memory(doc, self.signer)
            self._validate_item(doc)
        target_store.put(self.tenant_id, doc)
        self._emit("Written", {"memory_id": doc["memory_id"], "memory_type": kind, "item": doc}, correlation_id=str(doc["provenance"]["source_ref"] or uuid.uuid4()))
        return str(doc["memory_id"])

    def write_batch(self, items: Sequence[Mapping[str, Any]], auth_context: Any) -> list[str]:
        docs = [self._validate_item(item) for item in items]
        for doc in docs:
            self._auth(auth_context, memory_type=doc["memory_type"], write=True, sensitivity=doc["sensitivity"])
            if doc["tenant_id"] != self.tenant_id:
                raise MemoryAccessDenied("cross-tenant batch denied")
        with self._lock:
            durable_docs = [doc for doc in docs if doc["memory_type"] != "working"]
            working_docs = [doc for doc in docs if doc["memory_type"] == "working"]
            if durable_docs:
                self.durable.put_many(self.tenant_id, durable_docs)
            for doc in working_docs:
                self.ephemeral.put(self.tenant_id, doc)
        for doc in docs:
            self._emit("Written", {"memory_id": doc["memory_id"], "memory_type": doc["memory_type"], "item": doc})
        return [str(doc["memory_id"]) for doc in docs]

    def get(self, memory_id: str, auth_context: Any, *, include_forgotten: bool = False, as_of: float | str | None = None) -> dict[str, Any]:
        candidate = self.durable.get(self.tenant_id, memory_id) or self.ephemeral.get(self.tenant_id, memory_id)
        if candidate is None:
            raise MemoryNotFound(memory_id)
        self._auth(auth_context, memory_type=candidate["memory_type"], write=False, sensitivity=candidate["sensitivity"])
        visible = _is_temporally_valid(candidate, as_of, self.clock)
        if candidate["state"] == "forgotten" and not include_forgotten:
            raise MemoryNotFound(memory_id)
        if not visible and as_of is None:
            raise MemoryNotFound(memory_id)
        hydrated = copy.deepcopy(candidate)
        body_ref = hydrated.get("content", {}).get("body_ref")
        if body_ref and hydrated["memory_type"] != "working":
            body_hash = str(body_ref).rsplit("/", 1)[-1]
            blob = self.durable.get_blob(self.tenant_id, body_hash)
            if blob is not None:
                hydrated["content"] = {**hydrated["content"], "body": blob}
        self._emit("Read", {"memory_id": memory_id, "memory_type": candidate["memory_type"]})
        return hydrated

    def query(self, tenant: str, auth_context: Any, *, memory_type: str | None = None, scope: Sequence[str] = (), limit: int = 50, order: str = "score", as_of: float | str | None = None, include_archived: bool = False) -> list[dict[str, Any]]:
        if tenant != self.tenant_id:
            raise MemoryAccessDenied("cross-tenant query denied")
        if memory_type is not None and memory_type not in MEMORY_TYPES:
            raise MemorySchemaError("invalid memory_type")
        if memory_type is None:
            needed_types = MEMORY_TYPES
        else:
            needed_types = (memory_type,)
        if not any(_has_scope(auth_context, _SCOPE_BY_TYPE[k]) or "memory.admin" in set(_scopes(auth_context)) for k in needed_types):
            self._deny("query_scope_denied", memory_type or "multiple", str((auth_context.get("principal") if isinstance(auth_context, Mapping) else "unknown")))
            raise MemoryAccessDenied("no authorized memory read scope for query")
        caller_scopes = set(_scopes(auth_context))
        if as_of is not None and "memory.read.historical" not in caller_scopes and "memory.admin" not in caller_scopes:
            self._deny("historical_scope_denied", memory_type or "multiple", str((auth_context.get("principal") if isinstance(auth_context, Mapping) else "unknown")))
            raise MemoryAccessDenied("historical read requires memory.read.historical")
        docs: list[dict[str, Any]] = []
        for kind in needed_types:
            try:
                self._auth(auth_context, memory_type=kind, write=False)
            except MemoryAccessDenied:
                continue
            docs.extend(self.durable.list_current(self.tenant_id, kind))
            if kind == "working":
                docs.extend(self.ephemeral.list_current(self.tenant_id, kind))
        caller_scopes = set(_scopes(auth_context))
        result = []
        now = self.clock()
        for doc in docs:
            if doc["state"] == "forgotten":
                continue
            if not include_archived and doc["state"] == "archived":
                continue
            if as_of is None and not _is_temporally_valid(doc, None, self.clock):
                continue
            if scope and not set(scope).issubset(caller_scopes):
                continue
            hydrated = copy.deepcopy(doc)
            body_ref = hydrated.get("content", {}).get("body_ref")
            if body_ref and hydrated["memory_type"] != "working":
                body_hash = str(body_ref).rsplit("/", 1)[-1]
                blob = self.durable.get_blob(self.tenant_id, body_hash)
                if blob is not None:
                    hydrated["content"] = {**hydrated["content"], "body": blob}
            result.append(self._rescore_if_stale(hydrated, now))
        if order == "score":
            result.sort(key=lambda d: (-float(d["score"]["base"]), str(d["memory_id"])))
        elif order == "recorded_at":
            result.sort(key=lambda d: (str(d["recorded_at"]), str(d["memory_id"])))
        elif order == "memory_id":
            result.sort(key=lambda d: str(d["memory_id"]))
        return result[: max(1, min(int(limit), 5000))]

    def recall(self, auth_context: Any, *, query_text_or_vec: str | Sequence[float], memory_types: Sequence[str] = MEMORY_TYPES, top_k: int = 10, min_score: float = 0.0, now: float | None = None) -> list[dict[str, Any]]:
        candidates = self.query(self.tenant_id, auth_context, memory_type=None, limit=5000, order="score")
        allowed_types = set(memory_types)
        candidates = [d for d in candidates if d["memory_type"] in allowed_types and float(d["score"]["base"]) >= float(min_score)]
        if isinstance(query_text_or_vec, str):
            q = _token_set(query_text_or_vec)
            def similarity(doc: Mapping[str, Any]) -> float:
                text = _body_text(doc["content"]["body"])
                return _jaccard(q, _token_set(text))
        else:
            query_vec = list(float(x) for x in query_text_or_vec)
            def similarity(doc: Mapping[str, Any]) -> float:
                embedded = doc["content"]["body"].get("embedding") if isinstance(doc["content"]["body"], dict) else None
                return _cosine(query_vec, embedded or ())
        ranked = sorted(candidates, key=lambda d: (-similarity(d), -float(d["score"]["base"]), d["memory_id"]))
        return ranked[: max(1, min(int(top_k), 1000))]

    def history(self, memory_id: str, auth_context: Any) -> list[dict[str, Any]]:
        current = self.get(memory_id, auth_context)
        if current["memory_type"] == "working":
            return self.ephemeral.history(self.tenant_id, memory_id)
        return self.durable.history(self.tenant_id, memory_id)

    def _mutate(self, memory_id: str, auth_context: Any, mutator: callable, *, event_name: str = "Written") -> dict[str, Any]:
        current = self.get(memory_id, auth_context, include_forgotten=True)
        self._auth(auth_context, memory_type=current["memory_type"], write=True, sensitivity=current["sensitivity"])
        next_doc = mutator(copy.deepcopy(current))
        next_doc["memory_version"] = int(current["memory_version"]) + 1
        next_doc["recorded_at"] = _now()
        next_doc = _resign_memory(next_doc, self.signer)
        self._validate_item(next_doc)
        if next_doc["memory_type"] == "working":
            self.ephemeral.put(self.tenant_id, next_doc)
        else:
            self.durable.put(self.tenant_id, next_doc)
        self._emit(event_name, {"memory_id": memory_id, "item": next_doc}, correlation_id=memory_id)
        return next_doc

    def supersede(self, memory_id: str, replacement: Mapping[str, Any], auth_context: Any) -> str:
        current = self.get(memory_id, auth_context)
        replacement_doc = copy.deepcopy(dict(replacement))
        if replacement_doc.get("tenant_id") != self.tenant_id:
            raise MemoryAccessDenied("cross-tenant supersede denied")
        replacement_doc["memory_version"] = 1
        self.write(replacement_doc, auth_context)
        self._mutate(memory_id, auth_context, lambda d: {**d, "state": "superseded", "superseded_by": replacement_doc["memory_id"]}, event_name="Superseded")
        return str(replacement_doc["memory_id"])

    def link(self, memory_id: str, target_memory_id: str, relation_kind: str, confidence: float, auth_context: Any) -> Mapping[str, Any]:
        src = self.get(memory_id, auth_context, include_forgotten=True)
        target = self.get(target_memory_id, auth_context, include_forgotten=True)
        if src["tenant_id"] != target["tenant_id"]:
            raise MemoryAccessDenied("cross-tenant relation denied")
        relation = {"kind": relation_kind, "target_memory_id": target_memory_id, "confidence": max(0.0, min(1.0, float(confidence)))}
        updated = self._mutate(memory_id, auth_context, lambda d: {**d, "relations": sorted([*d.get("relations", []), relation], key=lambda x: (x["target_memory_id"], x["kind"]))}, event_name="Linked")
        return updated

    def unlink(self, memory_id: str, target_memory_id: str, relation_kind: str, auth_context: Any) -> Mapping[str, Any]:
        return self._mutate(memory_id, auth_context, lambda d: {**d, "relations": [r for r in d.get("relations", []) if not (r["target_memory_id"] == target_memory_id and r["kind"] == relation_kind)]}, event_name="Linked")

    def update_confidence(self, memory_id: str, new_confidence: float, evidence_ref: str, auth_context: Any) -> dict[str, Any]:
        if not 0.0 <= float(new_confidence) <= 1.0 or not str(evidence_ref).strip():
            raise MemoryPolicyError("confidence update requires bounded value and evidence")
        return self._mutate(memory_id, auth_context, lambda d: {**d, "confidence": float(new_confidence), "provenance": {**d["provenance"], "evidence_refs": sorted(set(d["provenance"].get("evidence_refs", [])) | {str(evidence_ref)})}}, event_name="Scored")

    def update_validity(self, memory_id: str, valid_from: str, valid_until: str | None, auth_context: Any) -> dict[str, Any]:
        if valid_until is not None and _iso_to_epoch(valid_until) < _iso_to_epoch(valid_from):
            raise MemoryPolicyError("valid_until precedes valid_from")
        return self._mutate(memory_id, auth_context, lambda d: {**d, "valid_from": valid_from, "valid_until": valid_until}, event_name="Written")

    def quarantine(self, memory_id: str, reason: str, auth_context: Any) -> dict[str, Any]:
        return self._mutate(memory_id, auth_context, lambda d: {**d, "state": "quarantined"}, event_name="Quarantined")

    def consolidate(self, source_ids: Sequence[str], target_type: str, derivation: Mapping[str, Any], auth_context: Any, *, body: Mapping[str, Any], memory_id: str | None = None) -> str:
        if target_type not in MEMORY_TYPES:
            raise MemorySchemaError("invalid target memory type")
        sources = [self.get(mid, auth_context) for mid in source_ids]
        contradictions = self._find_internal_contradictions(sources)
        unresolved = []
        source_ids_set = {str(x) for x in source_ids}
        for source in sources:
            for entry in source.get("contradictions", []):
                if str(entry.get("target_memory_id")) in source_ids_set and entry.get("resolution") in (None, "unresolved"):
                    unresolved.append({"a": source["memory_id"], "b": entry["target_memory_id"], "reason": "recorded_unresolved_contradiction"})
        contradictions.extend(x for x in unresolved if x not in contradictions)
        if contradictions:
            self._emit("ConsolidationBlocked", {"source_ids": list(source_ids), "target_type": target_type, "contradictions": contradictions}, correlation_id=str(uuid.uuid4()))
            raise ContradictionError("consolidation blocked by contradictory sources")
        derivation_doc = dict(derivation)
        derivation_doc.setdefault("algorithm", "jarvis.memory.consolidation")
        derivation_doc.setdefault("version", "1.0.0")
        derivation_doc["source_ids"] = list(source_ids)
        source_scopes = [str(s["memory_type"]) for s in sources]
        item = self._new_item(memory_type=target_type, body=dict(body), auth_context=auth_context, memory_id=memory_id, source_kind="derived", source_ref=str(uuid.uuid4()), derivation=derivation_doc)
        self.write(item, auth_context)
        self._emit("Consolidated", {"memory_id": item["memory_id"], "source_ids": list(source_ids), "source_types": source_scopes, "item": item}, correlation_id=str(item["memory_id"]))
        return str(item["memory_id"])

    def dedupe(self, auth_context: Any, *, memory_type: str | None = None) -> Mapping[str, Any]:
        docs = self.query(self.tenant_id, auth_context, memory_type=memory_type, limit=5000, order="memory_id")
        exact: dict[str, list[str]] = {}
        structural: dict[str, list[str]] = {}
        for doc in docs:
            exact.setdefault(_memory_content_hash(doc), []).append(doc["memory_id"])
            key = _structural_key(doc)
            if key:
                structural.setdefault(key, []).append(doc["memory_id"])
        clusters = []
        for groups in list(exact.values()) + [v for v in structural.values() if len(v) > 1]:
            if len(groups) > 1:
                canonical = sorted(groups, key=lambda mid: (-float(next(d for d in docs if d["memory_id"] == mid)["score"]["base"]), next(d for d in docs if d["memory_id"] == mid)["recorded_at"], mid))[0]
                clusters.append({"members": sorted(set(groups)), "canonical": canonical, "reason": "exact_or_structural"})
        return {"duplicate_clusters": clusters, "near_duplicate_candidates": self._near_duplicate_candidates(docs)}

    def _near_duplicate_candidates(self, docs: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for doc in docs:
            vector = doc["content"]["body"].get("embedding") if isinstance(doc["content"]["body"], dict) else None
            if vector:
                for other, score in self.vector_index.neighbors(self.tenant_id, vector, self.config.near_duplicate_threshold):
                    if other != doc["memory_id"] and score >= self.config.near_duplicate_threshold:
                        result.append({"memory_id": doc["memory_id"], "candidate": other, "similarity": float(score)})
        return result

    def detect_contradictions(self, auth_context: Any, *, memory_type: str | None = None) -> Mapping[str, Any]:
        docs = self.query(self.tenant_id, auth_context, memory_type=memory_type, limit=5000, order="memory_id")
        pairs: list[dict[str, Any]] = []
        for i, left in enumerate(docs):
            for right in docs[i + 1:]:
                reason = _contradiction_reason(left, right)
                if not reason:
                    continue
                entry_a = next((x for x in left.get("contradictions", []) if x.get("target_memory_id") == right["memory_id"]), None)
                entry_b = next((x for x in right.get("contradictions", []) if x.get("target_memory_id") == left["memory_id"]), None)
                detected_at = _now()
                if entry_a is None:
                    self._mutate(
                        left["memory_id"], auth_context,
                        lambda d, target=right["memory_id"], detected_at=detected_at: {
                            **d,
                            "contradictions": sorted([*d.get("contradictions", []), {
                                "target_memory_id": target, "detected_at": detected_at, "resolution": "unresolved",
                                "resolved_by": None, "resolved_at": None,
                            }], key=lambda x: str(x["target_memory_id"])),
                        },
                        event_name="ContradictionDetected",
                    )
                if entry_b is None:
                    self._mutate(
                        right["memory_id"], auth_context,
                        lambda d, target=left["memory_id"], detected_at=detected_at: {
                            **d,
                            "contradictions": sorted([*d.get("contradictions", []), {
                                "target_memory_id": target, "detected_at": detected_at, "resolution": "unresolved",
                                "resolved_by": None, "resolved_at": None,
                            }], key=lambda x: str(x["target_memory_id"])),
                        },
                        event_name="ContradictionDetected",
                    )
                pairs.append({"a": left["memory_id"], "b": right["memory_id"], "reason": reason})
        return {"contradictions": pairs, "count": len(pairs)}

    def resolve_contradiction(self, memory_id: str, target_memory_id: str, resolution: str, actor: Mapping[str, str], auth_context: Any) -> Mapping[str, Any]:
        self.get(memory_id, auth_context, include_forgotten=True); self.get(target_memory_id, auth_context, include_forgotten=True)
        if resolution not in {"unresolved", "accepted_a", "accepted_b", "both_invalid", "merged"}:
            raise MemoryPolicyError("invalid contradiction resolution")
        record = {"memory_id": memory_id, "target_memory_id": target_memory_id, "resolution": resolution, "resolved_by": dict(actor), "resolved_at": _now(), "signature": "", "integrity_hash": ""}
        signed = _resign_generic(record, self.signer)
        def mark(d: Mapping[str, Any]) -> dict[str, Any]:
            entries = []
            for current in d.get("contradictions", []):
                if current.get("target_memory_id") in {target_memory_id, memory_id}:
                    entries.append({**current, "resolution": resolution, "resolved_by": dict(actor), "resolved_at": signed["resolved_at"]})
                else:
                    entries.append(current)
            return {**d, "contradictions": entries}
        self._mutate(memory_id, auth_context, mark, event_name="ContradictionResolved")
        self._mutate(target_memory_id, auth_context, lambda d: mark(d), event_name="ContradictionResolved")
        self._emit("ContradictionResolved", {"memory_id": memory_id, "target_memory_id": target_memory_id, "resolution": resolution, "resolution_record": signed}, correlation_id=memory_id)
        return signed

    def score(self, memory_id: str, auth_context: Any, *, now: float | None = None) -> Mapping[str, Any]:
        doc = self.get(memory_id, auth_context, include_forgotten=True)
        return self._score_document(doc, now if now is not None else float(self.clock()))

    def rescore(self, auth_context: Any, *, memory_type: str | None = None, now: float | None = None) -> Mapping[str, Any]:
        now_value = float(self.clock() if now is None else now)
        docs = self.query(self.tenant_id, auth_context, memory_type=memory_type, limit=5000, order="memory_id", include_archived=True)
        changed = 0
        scores = []
        for doc in docs:
            result = self._score_document(doc, now_value)
            score_doc = self._mutate(doc["memory_id"], auth_context, lambda d, result=result: {**d, "score": result}, event_name="Scored")
            changed += 1
            scores.append((score_doc["memory_id"], score_doc["score"]["base"]))
        return {"changed": changed, "scores": scores}

    def decay(self, auth_context: Any, *, memory_type: str | None = None, now: float | None = None) -> Mapping[str, Any]:
        now_value = float(self.clock() if now is None else now)
        docs = self.query(self.tenant_id, auth_context, memory_type=memory_type, limit=5000, order="memory_id", include_archived=True)
        changed: list[str] = []
        for doc in docs:
            score = self._score_document(doc, now_value)
            updated = self._mutate(doc["memory_id"], auth_context, lambda d, score=score: {**d, "score": score}, event_name="Decayed")
            changed.append(updated["memory_id"])
        return {"changed": changed, "now": now_value}

    def archive(self, memory_id: str, reason: str, auth_context: Any, *, now: float | None = None) -> dict[str, Any]:
        doc = self.get(memory_id, auth_context, include_forgotten=True)
        score = self._score_document(doc, float(self.clock() if now is None else now))["base"]
        age = float(self.clock() if now is None else now) - _iso_to_epoch(doc["recorded_at"])
        if score > self.config.archive_score_threshold or age < self.config.archive_age_seconds:
            raise MemoryPolicyError("memory does not satisfy archival threshold")
        original_body = copy.deepcopy(doc["content"]["body"])
        body_hash = hashlib.sha256(canonical_bytes(original_body)).hexdigest()
        ref = self.durable.put_blob(self.tenant_id, body_hash, original_body)
        return self._mutate(memory_id, auth_context, lambda d: {**d, "state": "archived", "archived_at": _now(), "content": {**d["content"], "body": {}, "body_ref": ref}}, event_name="Archived")

    def forget(self, memory_id: str, reason: str, actor: Mapping[str, str], auth_context: Any, *, policy_ref: str = "memory.default") -> Mapping[str, Any]:
        doc = self.get(memory_id, auth_context, include_forgotten=True)
        self._auth(auth_context, memory_type=doc["memory_type"], write=True, sensitivity=doc["sensitivity"])
        tombstone = hashlib.sha256(canonical_bytes(doc["content"]["body"])).hexdigest()
        updated = self._mutate(memory_id, auth_context, lambda d: {**d, "state": "forgotten", "forgotten_at": _now(), "forgotten_reason": reason, "content": {**d["content"], "body": {"tombstone": tombstone}, "body_ref": None}}, event_name="Forgotten")
        record = {"memory_id": memory_id, "reason": reason, "actor": dict(actor), "correlation_id": str(uuid.uuid4()), "timestamp": _now(), "policy_ref": policy_ref, "tombstone_hash": tombstone}
        signed = _resign_generic(record, self.signer)
        for candidate in self.durable.list_current(self.tenant_id):
            if candidate["memory_id"] == memory_id:
                continue
            relations = candidate.get("relations", [])
            if any(r.get("target_memory_id") == memory_id for r in relations):
                self._emit("DependencyForgotten", {"memory_id": candidate["memory_id"], "forgotten_target": memory_id}, correlation_id=candidate["memory_id"])
        return signed

    def restore(self, memory_id: str, reason: str, actor: Mapping[str, str], auth_context: Any) -> dict[str, Any]:
        doc = self.get(memory_id, auth_context, include_forgotten=True)
        if doc["state"] == "forgotten":
            raise MemoryPolicyError("forgotten memory cannot be restored without forensic authorization")
        return self._mutate(memory_id, auth_context, lambda d: {**d, "state": "active", "archived_at": None}, event_name="Restored")

    def promote_working(self, session_id: str, memory_id: str, target_type: str, auth_context: Any) -> str:
        if target_type == "working" or target_type not in MEMORY_TYPES:
            raise MemoryPolicyError("working promotion requires another durable memory type")
        source = self.get(memory_id, auth_context)
        if source["memory_type"] != "working" or str(source["content"]["body"].get("session_id")) != str(session_id):
            raise MemoryPolicyError("working memory is session scoped")
        if not bool(source["content"]["body"].get("promotable", False)):
            raise MemoryPolicyError("working memory is not promotable")
        promoted_body = copy.deepcopy(source["content"]["body"].get("context_slice", {}))
        if target_type == "task" and not {"task_id", "parent_task_id", "objective", "plan_ref", "progress", "blockers", "state"}.issubset(promoted_body):
            promoted_body = {"task_id": str(source["content"]["body"].get("execution_id", memory_id)), "parent_task_id": None, "objective": str(promoted_body.get("objective", promoted_body.get("note", "promoted working context"))), "plan_ref": str(promoted_body.get("plan_ref", memory_id)), "progress": list(promoted_body.get("progress", [])), "blockers": list(promoted_body.get("blockers", [])), "state": "done"}
        item = self._new_item(memory_type=target_type, body=promoted_body, auth_context=auth_context, source_kind="derived", source_ref=memory_id, derivation={"algorithm": "jarvis.memory.promote_working", "version": "1.0.0", "source_ids": [memory_id]})
        self.write(item, auth_context)
        self._emit("Promoted", {"memory_id": item["memory_id"], "source_memory_id": memory_id, "item": item}, correlation_id=memory_id)
        return str(item["memory_id"])

    def stats(self, tenant: str, memory_type: str | None, auth_context: Any) -> Mapping[str, Any]:
        if tenant != self.tenant_id:
            raise MemoryAccessDenied("cross-tenant stats denied")
        docs = self.query(tenant, auth_context, memory_type=memory_type, limit=5000, order="memory_id", include_archived=True)
        return {"tenant_id": tenant, "memory_type": memory_type, "count": len(docs), "state_counts": {state: sum(1 for d in docs if d["state"] == state) for state in ("active", "superseded", "archived", "forgotten", "quarantined")}, "mean_score": (sum(float(d["score"]["base"]) for d in docs) / len(docs)) if docs else 0.0, "access_denials": self._deny_count}

    def explain(self, memory_id: str, auth_context: Any) -> Mapping[str, Any]:
        root = self.get(memory_id, auth_context, include_forgotten=True)
        visited: set[str] = set()
        tree = self._explain(root, visited, auth_context)
        return tree

    def _explain(self, doc: Mapping[str, Any], visited: set[str], auth_context: Any) -> Mapping[str, Any]:
        mid = str(doc["memory_id"])
        if mid in visited:
            raise MemoryPolicyError("provenance cycle detected")
        visited.add(mid)
        derivation = doc.get("provenance", {}).get("derivation")
        sources = []
        if derivation:
            for sid in derivation.get("source_ids", []):
                try:
                    src = self.get(str(sid), auth_context, include_forgotten=True)
                    sources.append(self._explain(src, visited, auth_context))
                except MemoryNotFound:
                    sources.append({"memory_id": str(sid), "missing": True})
        return {"memory_id": mid, "memory_type": doc["memory_type"], "signature_valid": _verify_memory_signature(doc), "integrity_hash": doc["integrity_hash"], "provenance": doc["provenance"], "sources": sources}

    def snapshot(self, auth_context: Any, *, environment_hash: str | None = None) -> Mapping[str, Any]:
        if "memory.admin" not in _scopes(auth_context):
            raise MemoryAccessDenied("memory snapshots require memory.admin")
        docs = [d for d in self.query(self.tenant_id, auth_context, limit=5000, order="memory_id", include_archived=True) if d["memory_type"] != "working"]
        blobs: dict[str, Any] = {}
        for doc in docs:
            ref = doc.get("content", {}).get("body_ref")
            if ref:
                body_hash = str(ref).rsplit("/", 1)[-1]
                blob = self.durable.get_blob(self.tenant_id, body_hash)
                if blob is not None:
                    blobs[body_hash] = blob
        snap = {"schema_version": "1.0.0", "tenant_id": self.tenant_id, "environment_hash": environment_hash, "items": docs, "blobs": blobs, "created_at": _now()}
        snap["snapshot_hash"] = hashlib.sha256(canonical_bytes(snap)).hexdigest()
        return _resign_generic(snap, self.signer)

    def restore_snapshot(self, snapshot: Mapping[str, Any], auth_context: Any, *, environment_hash: str | None = None) -> int:
        if snapshot.get("tenant_id") != self.tenant_id or not _verify_generic_signature(snapshot):
            raise MemorySignatureError("invalid memory snapshot signature")
        if snapshot.get("environment_hash") not in {None, environment_hash}:
            raise SnapshotEnvironmentMismatch("memory snapshot environment hash mismatch")
        expected_snapshot_hash = str(snapshot.get("snapshot_hash", ""))
        snapshot_base = {k: copy.deepcopy(v) for k, v in snapshot.items() if k not in {"signature", "signer_public_key", "integrity_hash", "snapshot_hash"}}
        if not expected_snapshot_hash or not hmac.compare_digest(expected_snapshot_hash, hashlib.sha256(canonical_bytes(snapshot_base)).hexdigest()):
            raise MemorySignatureError("memory snapshot hash mismatch")
        if "memory.admin" not in _scopes(auth_context):
            raise MemoryAccessDenied("memory snapshot restore requires memory.admin")
        for body_hash, body in dict(snapshot.get("blobs", {})).items():
            self.durable.put_blob(self.tenant_id, str(body_hash), body)
        items = list(snapshot.get("items", []))
        count = 0
        for item in items:
            existing = self.durable.get(self.tenant_id, str(item["memory_id"])) or self.ephemeral.get(self.tenant_id, str(item["memory_id"]))
            if existing is not None:
                if _memory_content_hash(existing) != _memory_content_hash(item) or int(existing["memory_version"]) != int(item["memory_version"]):
                    raise MemoryPolicyError(f"snapshot conflicts with current memory {item['memory_id']}")
                continue
            self.write(item, auth_context, allow_duplicate=True)
            count += 1
        return count

    def replay_events(self, events: Iterable[Any], *, as_of: float | None = None) -> Mapping[str, Any]:
        projector = MemoryProjector(self.tenant_id)
        for event in events:
            timestamp = _event_time(event)
            if as_of is not None and timestamp > float(as_of):
                continue
            if getattr(event, "event_type", None) != "Memory":
                continue
            projector.apply(event)
        return projector.items

    def verify_durable_chain(self) -> bool:
        return self.durable.verify_chain(self.tenant_id)

    def signed_score_config(self) -> dict[str, Any]:
        document = {
            "schema_version": "1.0.0",
            "weights": dict(self.config.weights),
            "default_decay": dict(self.config.default_decay),
            "default_importance": dict(self.config.default_importance),
        }
        return _resign_generic(document, self.signer)

    @staticmethod
    def verify_score_config(document: Mapping[str, Any]) -> bool:
        return _verify_generic_signature(document)

    @staticmethod
    def verify_signed_record(document: Mapping[str, Any]) -> bool:
        return _verify_generic_signature(document)

    def _resign_for_test(self, document: Mapping[str, Any]) -> dict[str, Any]:
        return _resign_memory(document, self.signer)

    def _score_document(self, doc: Mapping[str, Any], now: float) -> Mapping[str, Any]:
        observed = _iso_to_epoch(doc.get("observed_at") or doc["recorded_at"])
        age = max(0.0, now - observed)
        decay = float(doc["score"]["decay_rate"])
        recency = math.exp(-decay * age)
        weights = self.config.weights
        base = weights["confidence"] * float(doc["confidence"]) + weights["importance"] * float(doc["importance"]) + weights["reliability"] * float(doc["reliability"]) + weights["recency"] * recency
        return {"base": round(float(base), 12), "decay_rate": decay, "last_scored_at": _epoch_to_iso(now), "recency": round(recency, 12), "weights": dict(weights)}

    def _rescore_if_stale(self, doc: Mapping[str, Any], now: float) -> dict[str, Any]:
        last = _iso_to_epoch(doc["score"]["last_scored_at"])
        if now - last <= self.config.stale_after_seconds:
            return doc
        result = self._score_document(doc, now)
        fresh = copy.deepcopy(doc); fresh["score"] = result
        return fresh

    def _find_internal_contradictions(self, docs: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
        pairs = []
        for i, left in enumerate(docs):
            for right in docs[i + 1:]:
                reason = _contradiction_reason(left, right)
                if reason:
                    pairs.append({"a": left["memory_id"], "b": right["memory_id"], "reason": reason})
        return pairs

    def _ensure_provenance_acyclic(self, document: Mapping[str, Any]) -> None:
        root = str(document["memory_id"])
        derivation = document.get("provenance", {}).get("derivation")
        roots = [] if not derivation else [str(x) for x in derivation.get("source_ids", [])]
        seen: set[str] = set()
        stack = list(roots)
        while stack:
            current = stack.pop()
            if current == root:
                raise MemoryPolicyError("provenance cycle rejected")
            if current in seen:
                continue
            seen.add(current)
            existing = self.durable.get(self.tenant_id, current) or self.ephemeral.get(self.tenant_id, current)
            if existing:
                child = existing.get("provenance", {}).get("derivation")
                if child:
                    stack.extend(str(x) for x in child.get("source_ids", []))

    def _new_item(self, *, memory_type: str, body: Mapping[str, Any], auth_context: Any, memory_id: str | None = None, owner_agent_id: str | None = None, owner_genome_hash: str | None = None, source_kind: str = "system", source_ref: str | None = None, derivation: Mapping[str, Any] | None = None, sensitivity: str = "internal", valid_from: str | None = None, valid_until: str | None = None, confidence: float = 0.8, reliability: float = 0.8) -> dict[str, Any]:
        auth = self._auth(auth_context, memory_type=memory_type, write=True, sensitivity=sensitivity)
        now = _now()
        mid = memory_id or str(uuid.uuid4())
        schema_ref = f"urn:jarvis:memory-body:{memory_type}:1.0.0"
        doc = {
            "memory_id": mid, "memory_type": memory_type, "memory_version": 1,
            "tenant_id": self.tenant_id, "owner_agent_id": owner_agent_id, "owner_genome_hash": owner_genome_hash,
            "content": {"schema_ref": schema_ref, "body": copy.deepcopy(dict(body)), "language": None, "embedding_ref": None, "body_ref": None},
            "scope": sorted(set(auth["scopes"]) & {"memory.admin"} | {_SCOPE_BY_TYPE[memory_type]}),
            "sensitivity": sensitivity,
            "valid_from": valid_from or now, "valid_until": valid_until, "recorded_at": now, "observed_at": now,
            "confidence": max(0.0, min(1.0, float(confidence))), "importance": float(self.config.default_importance[memory_type]), "reliability": max(0.0, min(1.0, float(reliability))),
            "score": {"base": 0.0, "decay_rate": float(self.config.default_decay[memory_type]), "last_scored_at": now},
            "provenance": {"source_kind": source_kind, "source_ref": str(source_ref or auth["principal"]), "source_signature": None, "derivation": copy.deepcopy(dict(derivation)) if derivation else None, "evidence_refs": []},
            "relations": [], "contradictions": [], "state": "active", "superseded_by": None, "archived_at": None, "forgotten_at": None, "forgotten_reason": None,
            "signature": "", "writer_key_id": self.public_key_b64, "writer_public_key": self.public_key_b64, "integrity_hash": "",
        }
        doc["score"] = self._score_document(doc, self.clock())
        return _resign_memory(doc, self.signer)


def memory_config_from_genome(genome: Mapping[str, Any] | Any) -> dict[str, Mapping[str, Any]]:
    """Consume P2-A memory_config without changing the genome or granting access."""
    document = genome.document if hasattr(genome, "document") else dict(genome)
    config = document.get("memory_config", {})
    return {str(kind): dict(value) for kind, value in config.items() if str(kind) in MEMORY_TYPES}


def validate_skill_memory_requirements(skill: Mapping[str, Any], genome: Mapping[str, Any] | Any) -> Mapping[str, Any]:
    """Ensure a skill's declared memory needs are covered by the agent genome."""
    memory_config = memory_config_from_genome(genome)
    required = dict(skill.get("memory_requirements", {}))
    missing = [kind for kind in MEMORY_TYPES if bool(required.get(kind, {}).get("enabled", required.get(kind, False))) and not bool(memory_config.get(kind, {}).get("enabled", False))]
    if missing:
        raise MemoryAccessDenied(f"agent genome does not declare required memory types: {', '.join(missing)}")
    return {"ok": True, "missing": []}


def build_memory_item(**kwargs: Any) -> dict[str, Any]:
    """Convenience builder for tests and downstream integration adapters."""
    owner = kwargs.pop("owner_agent_id", None); genome = kwargs.pop("owner_genome_hash", None)
    service = kwargs.pop("service") if "service" in kwargs else None
    if service is None:
        raise ValueError("build_memory_item requires service=ExperienceMemory")
    return service._new_item(owner_agent_id=owner, owner_genome_hash=genome, **kwargs)


def _memory_content_hash(doc: Mapping[str, Any]) -> str:
    content = copy.deepcopy(dict(doc["content"]))
    content.pop("body_ref", None)
    return hashlib.sha256(canonical_bytes({"memory_type": doc["memory_type"], "content": content})).hexdigest()


def _resign_memory(doc: Mapping[str, Any], key: Ed25519PrivateKey) -> dict[str, Any]:
    body = copy.deepcopy(dict(doc)); body.pop("signature", None); body.pop("integrity_hash", None)
    pub = _b64(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    body["writer_key_id"] = pub; body["writer_public_key"] = pub
    digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
    signed_document = copy.deepcopy(body)
    body["integrity_hash"] = digest
    body["signature"] = _b64(key.sign(canonical_bytes({"integrity_hash": digest, "document": signed_document})))
    return body


def _verify_memory_signature(doc: Mapping[str, Any]) -> bool:
    try:
        body = copy.deepcopy(dict(doc)); signature = _b64d(str(body.pop("signature"))); digest = str(body.pop("integrity_hash")); public = _b64d(str(body["writer_public_key"]))
        if digest != hashlib.sha256(canonical_bytes(body)).hexdigest():
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(signature, canonical_bytes({"integrity_hash": digest, "document": body}))
        return True
    except (KeyError, ValueError, TypeError, InvalidSignature):
        return False


def _resign_generic(doc: Mapping[str, Any], key: Ed25519PrivateKey) -> dict[str, Any]:
    body = copy.deepcopy(dict(doc)); body.pop("signature", None); body.pop("integrity_hash", None)
    body["signer_public_key"] = _b64(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
    signed_document = copy.deepcopy(body)
    body["integrity_hash"] = digest
    body["signature"] = _b64(key.sign(canonical_bytes({"integrity_hash": digest, "document": signed_document})))
    return body


def _verify_generic_signature(doc: Mapping[str, Any]) -> bool:
    try:
        body = copy.deepcopy(dict(doc)); sig = _b64d(str(body.pop("signature"))); integ = str(body.pop("integrity_hash")); public = _b64d(str(body["signer_public_key"]))
        if integ != hashlib.sha256(canonical_bytes(body)).hexdigest():
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(sig, canonical_bytes({"integrity_hash": integ, "document": body}))
        return True
    except (KeyError, ValueError, TypeError, InvalidSignature):
        return False


def _has_scope(auth_context: Any, scope: str) -> bool:
    return scope in set(_scopes(auth_context))


def _scopes(auth_context: Any) -> tuple[str, ...]:
    if isinstance(auth_context, ExecutionContext):
        return tuple(auth_context.auth_context.scopes)
    if isinstance(auth_context, Mapping):
        return tuple(auth_context.get("scopes", ()))
    return ()


def _timestamp(value: Any) -> float:
    if value is None:
        return time.time()
    if isinstance(value, (int, float)):
        return float(value)
    return _iso_to_epoch(str(value))


def _iso_to_epoch(value: str | float | int) -> float:
    if isinstance(value, (float, int)):
        return float(value)
    text = str(value).replace("Z", "+00:00")
    return datetime.fromisoformat(text).timestamp()


def _epoch_to_iso(value: float) -> str:
    return datetime.fromtimestamp(float(value), timezone.utc).isoformat().replace("+00:00", "Z")


def _is_temporally_valid(doc: Mapping[str, Any], as_of: float | str | None, clock: callable) -> bool:
    point = float(clock()) if as_of is None else _iso_to_epoch(as_of)
    start = _iso_to_epoch(doc["valid_from"]); end = None if doc.get("valid_until") is None else _iso_to_epoch(doc["valid_until"])
    return start <= point and (end is None or point <= end)


def _body_text(body: Any) -> str:
    if isinstance(body, str):
        return body
    if isinstance(body, Mapping):
        return json.dumps(body, sort_keys=True, ensure_ascii=False)
    return str(body)


def _token_set(text: str) -> set[str]:
    return {x for x in re.findall(r"[A-Za-z0-9_]+", text.lower()) if len(x) > 1}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    union = a | b
    return 0.0 if not union else len(a & b) / len(union)


def _cosine(a: Sequence[float], b: Sequence[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    aa = sum(float(x) * float(x) for x in a); bb = sum(float(x) * float(x) for x in b)
    if aa <= 0 or bb <= 0:
        return 0.0
    return sum(float(x) * float(y) for x, y in zip(a, b)) / math.sqrt(aa * bb)


def _structural_key(doc: Mapping[str, Any]) -> str | None:
    body = doc["content"]["body"]
    if doc["memory_type"] == "semantic" and all(k in body for k in ("subject", "predicate", "object")):
        return f"semantic|{body['subject']}|{body['predicate']}"
    return None


def _contradiction_reason(a: Mapping[str, Any], b: Mapping[str, Any]) -> str | None:
    if a["memory_type"] == "semantic" and b["memory_type"] == "semantic":
        aa, bb = a["content"]["body"], b["content"]["body"]
        if aa.get("subject") == bb.get("subject") and aa.get("predicate") == bb.get("predicate") and aa.get("object") != bb.get("object"):
            if aa.get("disputed") or bb.get("disputed") or _overlap_temporal(a, b):
                return "semantic_subject_predicate_conflict"
    if a["memory_type"] == "world_state" and b["memory_type"] == "world_state":
        aa, bb = a["content"]["body"], b["content"]["body"]
        if aa.get("entity_ref") == bb.get("entity_ref") and aa.get("state_body") != bb.get("state_body") and _overlap_temporal(a, b):
            return "world_state_overlap_conflict"
    if a["memory_type"] == "procedural" and b["memory_type"] == "procedural":
        aa, bb = a["content"]["body"], b["content"]["body"]
        if aa.get("skill_ref") == bb.get("skill_ref") and aa.get("preconditions") == bb.get("preconditions") and aa.get("steps") != bb.get("steps"):
            return "procedural_precondition_conflict"
    if {a["memory_type"], b["memory_type"]} == {"failure", "procedural"}:
        failure = a["content"]["body"] if a["memory_type"] == "failure" else b["content"]["body"]
        procedure = a["content"]["body"] if a["memory_type"] == "procedural" else b["content"]["body"]
        if failure.get("failure_signature") and (failure.get("remediation_ref") == procedure.get("skill_ref") or failure.get("regression_test_ref") in procedure.get("known_failure_modes", [])):
            return "failure_procedure_postcondition_conflict"
    return None


def _overlap_temporal(a: Mapping[str, Any], b: Mapping[str, Any]) -> bool:
    a0, a1 = _iso_to_epoch(a["valid_from"]), float("inf") if a.get("valid_until") is None else _iso_to_epoch(a["valid_until"])
    b0, b1 = _iso_to_epoch(b["valid_from"]), float("inf") if b.get("valid_until") is None else _iso_to_epoch(b["valid_until"])
    return max(a0, b0) <= min(a1, b1)


def _event_time(event: Any) -> float:
    return _iso_to_epoch(event.emitted_at) if hasattr(event, "emitted_at") else _iso_to_epoch(event.get("emitted_at", _now()))

"""Cancellation Token — cooperative cancellation contract for JARVIS.

Provides a thread-safe, asyncio-compatible cancellation mechanism
that flows through: API -> Core -> Model -> Tool -> Job.

Architecture:
    User/Timeout/Shutdown
      -> CancellationTokenSource
      -> CancellationToken (propagated)
      -> Model backend (checks token, yields)
      -> Tool execution (checks token, aborts)
      -> Job step (checks token, stops)

This is NOT a thread-kill mechanism. It is a cooperative signal
that every layer must check and respect.
"""
from __future__ import annotations

import logging
import math
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, TypeVar

logger = logging.getLogger("jarvis.cancellation")

T = TypeVar("T")


class OperationCancelledError(Exception):
    """Raised when an operation is cancelled via token."""


@dataclass
class CancellationToken:
    """Immutable-ish cancellation token. Check .is_cancelled before work."""
    _source: "CancellationTokenSource"
    _id: str

    @property
    def is_cancelled(self) -> bool:
        return self._source.is_cancelled

    @property
    def cancellation_reason(self) -> Optional[str]:
        return self._source.cancellation_reason

    def throw_if_cancelled(self) -> None:
        """Raise OperationCancelledError if cancelled."""
        if self.is_cancelled:
            raise OperationCancelledError(
                f"Operation cancelled: {self.cancellation_reason or 'unknown'}"
            )

    def register_callback(self, callback: Callable[[], None]) -> "CancellationRegistration":
        """Register a callback to fire on cancellation."""
        return self._source.register_callback(callback)

    def link_to(self, other: "CancellationToken") -> "CancellationRegistration":
        """Link this token to another — cancelling other cancels this."""
        def on_cancel() -> None:
            if not self.is_cancelled:
                self._source.cancel(f"linked to {other._id}")
        return other.register_callback(on_cancel)


@dataclass
class CancellationRegistration:
    """Handle for unregistering a cancellation callback."""
    _source: "CancellationTokenSource"
    _callback: Callable[[], None]
    _active: bool = True

    def unregister(self) -> None:
        if self._active:
            self._source.unregister_callback(self._callback)
            self._active = False

    def __enter__(self) -> "CancellationRegistration":
        return self

    def __exit__(self, *args: Any) -> None:
        self.unregister()


class CancellationTokenSource:
    """Source of cancellation tokens. One source, many tokens."""

    _counter = 0
    _counter_lock = threading.Lock()

    def __init__(self, timeout: Optional[float] = None, *, max_callbacks: int = 4096) -> None:
        if isinstance(max_callbacks, bool) or int(max_callbacks) < 1:
            raise ValueError("max_callbacks must be a positive integer")
        if timeout is not None and (not math.isfinite(float(timeout)) or float(timeout) < 0):
            raise ValueError("timeout must be finite and >= 0")
        self.max_callbacks = int(max_callbacks)
        with CancellationTokenSource._counter_lock:
            CancellationTokenSource._counter += 1
            self._id = f"cts_{CancellationTokenSource._counter}_{int(time.time()*1000)}"
        self._cancelled = False
        self._reason: Optional[str] = None
        self._callbacks: List[Callable[[], None]] = []
        self._lock = threading.RLock()
        self._timeout_handle: Optional[threading.Timer] = None
        if timeout == 0:
            self.cancel(reason="timeout")
        elif timeout is not None:
            self._timeout_handle = threading.Timer(float(timeout), self._on_timeout)
            self._timeout_handle.daemon = True
            self._timeout_handle.start()

    @property
    def is_cancelled(self) -> bool:
        with self._lock:
            return self._cancelled

    @property
    def cancellation_reason(self) -> Optional[str]:
        with self._lock:
            return self._reason

    def token(self) -> CancellationToken:
        return CancellationToken(_source=self, _id=self._id)

    def cancel(self, reason: str = "cancelled") -> bool:
        """Cancel all linked tokens. Returns True if this call initiated cancellation."""
        with self._lock:
            if self._cancelled:
                return False
            self._cancelled = True
            self._reason = str(reason)
            callbacks = list(self._callbacks)
            self._callbacks.clear()

        for cb in callbacks:
            try:
                cb()
            except Exception:
                logger.debug("cancellation_callback_failed", exc_info=True)

        if self._timeout_handle and self._timeout_handle.is_alive():
            self._timeout_handle.cancel()
        return True

    def register_callback(self, callback: Callable[[], None]) -> CancellationRegistration:
        with self._lock:
            if self._cancelled:
                # Already cancelled, fire immediately
                try:
                    callback()
                except Exception:
                    logger.debug("cancellation_immediate_callback_failed", exc_info=True)
                return CancellationRegistration(_source=self, _callback=callback, _active=False)
            if len(self._callbacks) >= self.max_callbacks:
                raise RuntimeError("cancellation callback capacity reached")
            self._callbacks.append(callback)
            return CancellationRegistration(_source=self, _callback=callback, _active=True)

    def unregister_callback(self, callback: Callable[[], None]) -> None:
        with self._lock:
            if callback in self._callbacks:
                self._callbacks.remove(callback)

    def _on_timeout(self) -> None:
        self.cancel(reason="timeout")

    def __enter__(self) -> "CancellationTokenSource":
        return self

    def __exit__(self, *args: Any) -> None:
        self.cancel(reason="source_disposed")


class CancellationTokenRegistry:
    """Registry of active cancellation sources for global management."""

    def __init__(self, *, max_sources: int = 10000) -> None:
        if isinstance(max_sources, bool) or int(max_sources) < 1:
            raise ValueError("max_sources must be a positive integer")
        self.max_sources = int(max_sources)
        self._sources: Dict[str, CancellationTokenSource] = {}
        self._lock = threading.RLock()

    def create(self, timeout: Optional[float] = None) -> CancellationTokenSource:
        with self._lock:
            self.cleanup()
            if len(self._sources) >= self.max_sources:
                raise RuntimeError("cancellation source capacity reached")
            source = CancellationTokenSource(timeout=timeout)
            self._sources[source._id] = source
            return source

    def get(self, source_id: str) -> Optional[CancellationTokenSource]:
        with self._lock:
            return self._sources.get(source_id)

    def cancel(self, source_id: str, reason: str = "cancelled") -> bool:
        source = self.get(source_id)
        if source:
            return source.cancel(reason)
        return False

    def cancel_all(self, reason: str = "shutdown") -> int:
        with self._lock:
            sources = list(self._sources.values())
        count = 0
        for source in sources:
            if source.cancel(reason):
                count += 1
        return count

    def cleanup(self) -> int:
        """Remove cancelled sources."""
        with self._lock:
            to_remove = [sid for sid, src in self._sources.items() if src.is_cancelled]
            for sid in to_remove:
                self._sources.pop(sid, None)
            return len(to_remove)



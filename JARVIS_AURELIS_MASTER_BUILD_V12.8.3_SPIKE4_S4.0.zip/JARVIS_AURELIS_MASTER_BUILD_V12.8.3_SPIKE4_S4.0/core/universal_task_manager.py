"""Durable unified task authority for missions, jobs, workflows and agents.

The task center is intentionally a facade, not a second execution engine. It
records lifecycle state, ownership, progress, bounded metadata, idempotency and
cancellation hooks for tasks executed by the existing authoritative engines.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping


class TaskKind(StrEnum):
    """Canonical task classes exposed to the operator control plane."""

    MISSION = "mission"
    JOB = "job"
    WORKFLOW = "workflow"
    AGENT = "agent"
    SCHEDULED = "scheduled"
    SYSTEM = "system"


class TaskState(StrEnum):
    """Durable task lifecycle states."""

    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCEL_REQUESTED = "cancel_requested"
    CANCELLED = "cancelled"
    RECOVERED = "recovered"


@dataclass(frozen=True, slots=True)
class TaskRecord:
    """Immutable operator-facing task record."""

    task_id: str
    idempotency_key: str
    kind: str
    title: str
    owner: str
    state: str
    progress: float
    created_at: float
    updated_at: float
    external_id: str | None
    result_summary: str | None
    error: str | None
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Serialize without internal integrity fields."""
        return {
            "task_id": self.task_id,
            "idempotency_key": self.idempotency_key,
            "kind": self.kind,
            "title": self.title,
            "owner": self.owner,
            "state": self.state,
            "progress": self.progress,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "external_id": self.external_id,
            "result_summary": self.result_summary,
            "error": self.error,
            "metadata": dict(self.metadata),
        }


class UniversalTaskManager:
    """Persistent lifecycle authority that delegates actual execution elsewhere."""

    _TERMINAL = frozenset({TaskState.SUCCEEDED, TaskState.FAILED, TaskState.CANCELLED})
    _VALID_TRANSITIONS = {
        TaskState.QUEUED: frozenset({TaskState.RUNNING, TaskState.CANCEL_REQUESTED, TaskState.CANCELLED, TaskState.RECOVERED}),
        TaskState.RUNNING: frozenset({TaskState.SUCCEEDED, TaskState.FAILED, TaskState.CANCEL_REQUESTED, TaskState.CANCELLED, TaskState.RECOVERED}),
        TaskState.CANCEL_REQUESTED: frozenset({TaskState.CANCELLED, TaskState.FAILED, TaskState.RECOVERED}),
        TaskState.RECOVERED: frozenset({TaskState.QUEUED, TaskState.RUNNING, TaskState.CANCELLED, TaskState.FAILED}),
        TaskState.SUCCEEDED: frozenset(),
        TaskState.FAILED: frozenset(),
        TaskState.CANCELLED: frozenset(),
    }

    def __init__(self, db_path: str | Path = "data/task_center.db", *, max_metadata_bytes: int = 32_768) -> None:
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_metadata_bytes = max(1024, int(max_metadata_bytes))
        self._lock = threading.RLock()
        self._cancel_handlers: dict[str, Callable[[], Any]] = {}
        self._db = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.execute("PRAGMA busy_timeout=10000")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY,
                idempotency_key TEXT NOT NULL UNIQUE,
                kind TEXT NOT NULL,
                title TEXT NOT NULL,
                owner TEXT NOT NULL,
                state TEXT NOT NULL,
                progress REAL NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                external_id TEXT,
                result_summary TEXT,
                error TEXT,
                metadata_json TEXT NOT NULL,
                record_hash TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_tasks_updated ON tasks(updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_tasks_state ON tasks(state, updated_at DESC);
            """
        )
        self._db.commit()

    def close(self) -> None:
        """Flush and close the persistent database."""
        with self._lock:
            self._db.commit()
            self._db.close()
            self._cancel_handlers.clear()

    def _validate_text(self, value: Any, field: str, max_len: int = 512) -> str:
        text = str(value).strip()
        if not text or len(text) > max_len:
            raise ValueError(f"invalid {field}")
        return text

    def _safe_metadata(self, metadata: Mapping[str, Any] | None) -> dict[str, Any]:
        data = dict(metadata or {})
        encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        if len(encoded.encode("utf-8")) > self.max_metadata_bytes:
            raise ValueError("task metadata exceeds configured limit")
        return data

    @staticmethod
    def _hash(task_id: str, state: str, updated_at: float, payload: Mapping[str, Any]) -> str:
        canonical = json.dumps(
            {"task_id": task_id, "state": state, "updated_at": round(updated_at, 6), "payload": dict(payload)},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        return hashlib.sha256(canonical).hexdigest()

    def create(
        self,
        *,
        kind: TaskKind | str,
        title: str,
        owner: str = "local",
        idempotency_key: str | None = None,
        external_id: str | None = None,
        metadata: Mapping[str, Any] | None = None,
        state: TaskState | str = TaskState.QUEUED,
    ) -> TaskRecord:
        """Create or return an idempotent durable task record."""
        normalized_kind = self._validate_text(kind, "kind", 64)
        normalized_title = self._validate_text(title, "title", 2_000)
        normalized_owner = self._validate_text(owner, "owner", 256)
        idem = self._validate_text(idempotency_key or f"{normalized_kind}:{uuid.uuid4().hex}", "idempotency_key", 512)
        external = None if external_id is None else self._validate_text(external_id, "external_id", 512)
        task_state = TaskState(str(state))
        metadata_safe = self._safe_metadata(metadata)
        now = time.time()
        payload = {"kind": normalized_kind, "title": normalized_title, "owner": normalized_owner, "external_id": external, "metadata": metadata_safe, "progress": 0.0, "result": None, "error": None}
        task_id = f"task_{uuid.uuid4().hex[:16]}"
        digest = self._hash(task_id, task_state.value, now, payload)
        with self._lock:
            row = self._db.execute("SELECT * FROM tasks WHERE idempotency_key=?", (idem,)).fetchone()
            if row is not None:
                return self._row(row)
            self._db.execute(
                "INSERT INTO tasks(task_id,idempotency_key,kind,title,owner,state,progress,created_at,updated_at,external_id,result_summary,error,metadata_json,record_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (task_id, idem, normalized_kind, normalized_title, normalized_owner, task_state.value, 0.0, now, now, external, None, None, json.dumps(metadata_safe, sort_keys=True, separators=(",", ":")), digest),
            )
            self._db.commit()
            return self.get(task_id)  # type: ignore[return-value]

    def get(self, task_id: str) -> TaskRecord | None:
        """Return one task, or ``None`` when it does not exist."""
        with self._lock:
            row = self._db.execute("SELECT * FROM tasks WHERE task_id=?", (str(task_id),)).fetchone()
            return self._row(row) if row is not None else None

    def update(
        self,
        task_id: str,
        *,
        state: TaskState | str | None = None,
        progress: float | None = None,
        result_summary: str | None = None,
        error: str | None = None,
    ) -> TaskRecord:
        """Apply one bounded lifecycle transition and persist its integrity digest."""
        with self._lock:
            current = self.get(task_id)
            if current is None:
                raise KeyError(task_id)
            next_state = current.state if state is None else TaskState(str(state)).value
            if next_state != current.state and next_state not in self._VALID_TRANSITIONS[TaskState(current.state)]:
                raise ValueError(f"invalid task transition: {current.state} -> {next_state}")
            next_progress = current.progress if progress is None else max(0.0, min(1.0, float(progress)))
            if next_state == TaskState.SUCCEEDED.value:
                next_progress = 1.0
            now = time.time()
            next_result = current.result_summary if result_summary is None else str(result_summary)[:4_000]
            next_error = current.error if error is None else str(error)[:4_000]
            payload = {"kind": current.kind, "title": current.title, "owner": current.owner, "external_id": current.external_id, "metadata": current.metadata}
            digest = self._hash(current.task_id, next_state, now, payload | {"progress": next_progress, "result": next_result, "error": next_error})
            self._db.execute(
                "UPDATE tasks SET state=?,progress=?,updated_at=?,result_summary=?,error=?,record_hash=? WHERE task_id=?",
                (next_state, next_progress, now, next_result, next_error, digest, current.task_id),
            )
            self._db.commit()
            return self.get(task_id)  # type: ignore[return-value]

    def bind_cancel_handler(self, task_id: str, handler: Callable[[], Any]) -> None:
        """Bind a process-local cancellation callback for a live execution engine."""
        if not callable(handler):
            raise TypeError("handler must be callable")
        with self._lock:
            if self.get(task_id) is None:
                raise KeyError(task_id)
            self._cancel_handlers[str(task_id)] = handler

    def request_cancel(self, task_id: str) -> TaskRecord:
        """Request cancellation and invoke the registered engine callback when present."""
        current = self.get(task_id)
        if current is None:
            raise KeyError(task_id)
        if current.state in self._TERMINAL:
            return current
        updated = self.update(task_id, state=TaskState.CANCEL_REQUESTED)
        handler = self._cancel_handlers.get(str(task_id))
        if handler is not None:
            try:
                handler()
            except Exception as exc:
                return self.update(task_id, state=TaskState.FAILED, error=f"cancellation handler failed: {exc}")
        return updated

    def list(self, *, states: Iterable[TaskState | str] = (), limit: int = 100) -> list[TaskRecord]:
        """Return recent tasks filtered by optional lifecycle states."""
        bounded = max(1, min(int(limit), 500))
        normalized = tuple(TaskState(str(item)).value for item in states)
        with self._lock:
            if normalized:
                placeholders = ",".join("?" for _ in normalized)
                rows = self._db.execute(f"SELECT * FROM tasks WHERE state IN ({placeholders}) ORDER BY updated_at DESC LIMIT ?", (*normalized, bounded)).fetchall()
            else:
                rows = self._db.execute("SELECT * FROM tasks ORDER BY updated_at DESC LIMIT ?", (bounded,)).fetchall()
            return [self._row(row) for row in rows]

    def recover_incomplete(self) -> int:
        """Mark orphaned running/cancel-requested work as recoverable after a crash."""
        with self._lock:
            now = time.time()
            states = (TaskState.RUNNING.value, TaskState.CANCEL_REQUESTED.value)
            rows = self._db.execute("SELECT task_id FROM tasks WHERE state IN (?,?)", states).fetchall()
            for row in rows:
                task_id = str(row["task_id"])
                current = self.get(task_id)
                if current is None:
                    continue
                payload = {"kind": current.kind, "title": current.title, "owner": current.owner, "external_id": current.external_id, "metadata": current.metadata, "progress": current.progress, "result": current.result_summary, "error": "recovered after restart"}
                digest = self._hash(task_id, TaskState.RECOVERED.value, now, payload)
                self._db.execute("UPDATE tasks SET state=?,updated_at=?,error=?,record_hash=? WHERE task_id=?", (TaskState.RECOVERED.value, now, "recovered after restart", digest, task_id))
            self._db.commit()
            self._cancel_handlers.clear()
            return len(rows)

    def verify_integrity(self) -> bool:
        """Verify all task record hashes without exposing internal data."""
        with self._lock:
            rows = self._db.execute("SELECT * FROM tasks ORDER BY created_at ASC, task_id ASC").fetchall()
            for row in rows:
                metadata = json.loads(str(row["metadata_json"]))
                payload = {
                    "kind": str(row["kind"]),
                    "title": str(row["title"]),
                    "owner": str(row["owner"]),
                    "external_id": row["external_id"],
                    "metadata": metadata,
                    "progress": float(row["progress"]),
                    "result": row["result_summary"],
                    "error": row["error"],
                }
                expected = self._hash(str(row["task_id"]), str(row["state"]), float(row["updated_at"]), payload)
                if expected != str(row["record_hash"]):
                    return False
            return True

    def stats(self) -> dict[str, Any]:
        """Return non-sensitive task-center statistics."""
        with self._lock:
            total = int(self._db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0])
            rows = self._db.execute("SELECT state,COUNT(*) AS count FROM tasks GROUP BY state").fetchall()
            states = {str(row["state"]): int(row["count"]) for row in rows}
            return {"total": total, "states": states, "integrity_ok": self.verify_integrity()}

    @staticmethod
    def _row(row: sqlite3.Row) -> TaskRecord:
        return TaskRecord(
            task_id=str(row["task_id"]),
            idempotency_key=str(row["idempotency_key"]),
            kind=str(row["kind"]),
            title=str(row["title"]),
            owner=str(row["owner"]),
            state=str(row["state"]),
            progress=float(row["progress"]),
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            external_id=None if row["external_id"] is None else str(row["external_id"]),
            result_summary=None if row["result_summary"] is None else str(row["result_summary"]),
            error=None if row["error"] is None else str(row["error"]),
            metadata=dict(json.loads(str(row["metadata_json"]))),
        )



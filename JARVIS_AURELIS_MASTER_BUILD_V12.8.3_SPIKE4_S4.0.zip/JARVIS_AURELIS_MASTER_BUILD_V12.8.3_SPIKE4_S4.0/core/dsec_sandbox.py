"""DSec Sandbox: unified, fail-closed autonomous sandbox infrastructure.

The Python layer owns sandbox identity, immutable manifests, overlay composition,
incremental snapshot/diff storage, admission control and lifecycle. Execution is
provided by explicit backends: trusted function calls, OCI containers,
Firecracker microVMs, and QEMU full VMs. Privileged runtimes are never inferred;
if an external runtime is absent, the corresponding backend reports unavailable.
"""
from __future__ import annotations

import hashlib
import json
import os
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from pathlib import Path
import shutil
import subprocess
import tarfile
import threading
import time
import uuid
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from core.execution_broker import ExecutionBroker


class DSecError(RuntimeError):
    """Base DSec error."""


class BackendUnavailable(DSecError):
    """Raised when a requested sandbox runtime is not available."""


class SnapshotIntegrityError(DSecError):
    """Raised when a snapshot or diff fails integrity validation."""


class SandboxBackend(StrEnum):
    """Supported DSec execution backends."""

    FNCALL = "fncall"
    CONTAINER = "container"
    MICROVM = "microvm"
    FULLVM = "fullvm"


class SandboxState(StrEnum):
    """Sandbox lifecycle state."""

    CREATED = "created"
    RUNNING = "running"
    STOPPED = "stopped"
    SNAPSHOTTED = "snapshotted"
    DESTROYED = "destroyed"


@dataclass(frozen=True, slots=True)
class SandboxLimits:
    """Hard execution and output budgets."""

    timeout_seconds: float = 60.0
    memory_mb: int = 1024
    pids: int = 64
    output_bytes: int = 4 * 1024 * 1024
    cpu_seconds: int = 60
    max_disk_bytes: int = 10 * 1024 * 1024 * 1024

    def validate(self) -> None:
        if not 0.1 <= float(self.timeout_seconds) <= 86_400:
            raise ValueError("timeout_seconds outside policy")
        if not 16 <= int(self.memory_mb) <= 1_048_576:
            raise ValueError("memory_mb outside policy")
        if not 1 <= int(self.pids) <= 1_000_000:
            raise ValueError("pids outside policy")
        if not 1_024 <= int(self.output_bytes) <= 1_073_741_824:
            raise ValueError("output_bytes outside policy")
        if not 1 <= int(self.cpu_seconds) <= 86_400:
            raise ValueError("cpu_seconds outside policy")
        if not 1_024 <= int(self.max_disk_bytes) <= 10 * 1024**4:
            raise ValueError("max_disk_bytes outside policy")


@dataclass(frozen=True, slots=True)
class OverlayLayer:
    """One immutable overlay layer."""

    name: str
    path: str
    read_only: bool = True

    def resolved(self) -> Path:
        value = Path(self.path).resolve()
        if not value.exists() or not value.is_dir():
            raise ValueError(f"overlay layer does not exist: {value}")
        return value


@dataclass(frozen=True, slots=True)
class OverlayPlan:
    """Composable base/workspace/toolkit overlay description."""

    base: OverlayLayer
    workspace: OverlayLayer | None = None
    toolkit: OverlayLayer | None = None

    def layers(self) -> tuple[OverlayLayer, ...]:
        return tuple(layer for layer in (self.base, self.toolkit, self.workspace) if layer is not None)

    def digest(self) -> str:
        raw = json.dumps([asdict(item) for item in self.layers()], sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True, slots=True)
class SandboxSpec:
    """Immutable sandbox request."""

    sandbox_id: str
    backend: SandboxBackend
    overlay: OverlayPlan
    argv: tuple[str, ...] = ()
    environment: Mapping[str, str] = field(default_factory=dict)
    limits: SandboxLimits = field(default_factory=SandboxLimits)
    network: str = "none"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        sid = str(self.sandbox_id).strip()
        if not sid or any(ch in sid for ch in "/\\"):
            raise ValueError("invalid sandbox_id")
        self.limits.validate()
        if self.network not in {"none", "host", "restricted"}:
            raise ValueError("unsupported network policy")
        if any(not str(item).strip() for item in self.argv):
            raise ValueError("argv cannot contain empty values")
        for key in self.environment:
            if not str(key).replace("_", "").isalnum():
                raise ValueError("environment key contains unsafe characters")


@dataclass(frozen=True, slots=True)
class SandboxResult:
    """Execution result from one sandbox."""

    sandbox_id: str
    backend: SandboxBackend
    ok: bool
    returncode: int | None
    stdout: str
    stderr: str
    timed_out: bool
    latency_ms: float


@dataclass(frozen=True, slots=True)
class SnapshotRef:
    """Content-addressed reusable snapshot."""

    snapshot_id: str
    archive_path: str
    manifest_sha256: str
    file_count: int
    total_bytes: int
    created_at: float


@dataclass(frozen=True, slots=True)
class DiffPack:
    """Content-addressed incremental snapshot."""

    diff_id: str
    archive_path: str
    base_manifest_sha256: str
    target_manifest_sha256: str
    changed_files: tuple[str, ...]
    deleted_files: tuple[str, ...]
    total_bytes: int


@dataclass(frozen=True, slots=True)
class SandboxRecord:
    """Persistent logical sandbox metadata."""

    sandbox_id: str
    backend: SandboxBackend
    state: SandboxState
    workspace: str
    overlay_digest: str
    created_at: float
    updated_at: float
    snapshot_id: str | None = None


class SandboxBackendProtocol(Protocol):
    """Execution backend contract."""

    backend: SandboxBackend

    def available(self) -> bool:
        """Return whether the runtime dependency is installed and usable."""

    def run(self, spec: SandboxSpec, workspace: Path) -> SandboxResult:
        """Execute the sandbox request."""


class _ProcessRunner:
    """Common trusted-process runner using argv only; no shell execution."""

    @staticmethod
    def run(argv: Sequence[str], *, cwd: Path, env: Mapping[str, str], limits: SandboxLimits, sandbox_id: str, backend: SandboxBackend) -> SandboxResult:
        if not argv:
            raise ValueError("execution argv is empty")
        started = time.perf_counter()
        merged_env = {"PATH": os.environ.get("PATH", ""), **{str(k): str(v) for k, v in env.items()}}
        broker = ExecutionBroker()
        executable = str(argv[0])
        allowed = (Path(executable).name,)
        result = broker.execute_trusted_argv(list(argv), principal=f"dsec:{sandbox_id}", capability=f"dsec.{backend.value}", cwd=cwd, timeout_seconds=limits.timeout_seconds, allowed_executables=allowed, env=merged_env)
        output_limit = int(limits.output_bytes)
        stdout = result.stdout.encode("utf-8")[:output_limit].decode("utf-8", errors="replace")
        stderr = result.stderr.encode("utf-8")[:output_limit].decode("utf-8", errors="replace")
        return SandboxResult(sandbox_id, backend, result.ok, result.returncode, stdout, stderr, result.killed, result.execution_time_ms)


class FnCallBackend:
    """Trusted in-process backend for deterministic harness functions."""

    backend = SandboxBackend.FNCALL

    def available(self) -> bool:
        return True

    def run(self, spec: SandboxSpec, workspace: Path) -> SandboxResult:
        raise BackendUnavailable("FNCALL requires DsecSandbox.run_callable; arbitrary code is not executed in-process")

    def run_callable(self, sandbox_id: str, limits: SandboxLimits, callable_: Callable[[], Any]) -> SandboxResult:
        started = time.perf_counter()
        executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="dsec-fncall")
        future: Future[Any] = executor.submit(callable_)
        try:
            result = future.result(timeout=limits.timeout_seconds)
            payload = str(result)
            bounded = payload.encode("utf-8")[: limits.output_bytes].decode("utf-8", errors="replace")
            return SandboxResult(sandbox_id, self.backend, True, 0, bounded, "", False, (time.perf_counter() - started) * 1000.0)
        except TimeoutError:
            future.cancel()
            return SandboxResult(sandbox_id, self.backend, False, None, "", "function call timed out", True, (time.perf_counter() - started) * 1000.0)
        except Exception as exc:
            return SandboxResult(sandbox_id, self.backend, False, 1, "", f"{type(exc).__name__}: {exc}", False, (time.perf_counter() - started) * 1000.0)
        finally:
            executor.shutdown(wait=False, cancel_futures=True)


class ContainerBackend:
    """OCI-compatible backend with a hardened default container profile."""

    backend = SandboxBackend.CONTAINER

    def __init__(self, engine: str | None = None) -> None:
        self.engine = engine or self._detect_engine()

    @staticmethod
    def _detect_engine() -> str | None:
        for candidate in ("docker", "podman"):
            found = shutil.which(candidate)
            if found:
                return found
        return None

    def available(self) -> bool:
        return self.engine is not None

    def run(self, spec: SandboxSpec, workspace: Path) -> SandboxResult:
        if not self.engine:
            raise BackendUnavailable("no OCI runtime detected")
        image = str(spec.metadata.get("image", "")).strip()
        if not image or any(ch.isspace() for ch in image):
            raise ValueError("container image is required and must not contain whitespace")
        argv = [self.engine, "run", "--rm", "--read-only", "--network", "none", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--pids-limit", str(spec.limits.pids), "--memory", f"{spec.limits.memory_mb}m", "--cpus", str(max(0.1, min(64.0, spec.limits.cpu_seconds / max(spec.limits.timeout_seconds, 0.1))))]
        if spec.network == "host":
            argv[argv.index("none")] = "host"
        elif spec.network == "restricted":
            argv[argv.index("none")] = "none"
        argv += ["-v", f"{workspace}:/workspace:rw"]
        for layer in spec.overlay.layers():
            path = layer.resolved()
            if path != workspace:
                mount_mode = "ro" if layer.read_only else "rw"
                argv += ["-v", f"{path}:/opt/dsec/{layer.name}:{mount_mode}"]
        for key, value in sorted(spec.environment.items()):
            argv += ["-e", f"{key}={value}"]
        argv.append(image)
        argv.extend(spec.argv)
        return _ProcessRunner.run(argv, cwd=workspace, env={}, limits=spec.limits, sandbox_id=spec.sandbox_id, backend=self.backend)


class FirecrackerBackend:
    """Firecracker availability adapter with a validated launch contract."""

    backend = SandboxBackend.MICROVM

    def __init__(self, binary: str | None = None) -> None:
        self.binary = binary or shutil.which("firecracker")

    def available(self) -> bool:
        return self.binary is not None

    def run(self, spec: SandboxSpec, workspace: Path) -> SandboxResult:
        if not self.binary:
            raise BackendUnavailable("firecracker runtime is unavailable")
        kernel = Path(str(spec.metadata.get("kernel", ""))).resolve()
        rootfs = Path(str(spec.metadata.get("rootfs", ""))).resolve()
        if not kernel.is_file() or not rootfs.is_file():
            raise ValueError("microVM requires existing kernel and rootfs paths")
        api_socket = workspace / "firecracker.sock"
        cmdline = str(spec.metadata.get("kernel_args", "console=ttyS0 reboot=k panic=1 pci=off"))
        started = time.perf_counter()
        broker = ExecutionBroker()
        process = broker.start_trusted_argv(
            [self.binary, "--api-sock", str(api_socket)],
            principal=f"dsec:{spec.sandbox_id}",
            capability="dsec.microvm",
            cwd=workspace,
            allowed_executables=(Path(self.binary).name,),
            env={},
        )
        try:
            deadline = time.monotonic() + min(spec.limits.timeout_seconds, 15.0)
            while not api_socket.exists() and time.monotonic() < deadline:
                if process.poll() is not None:
                    break
                time.sleep(0.02)
            if not api_socket.exists():
                process.kill()
                stdout, stderr = process.communicate()
                return SandboxResult(spec.sandbox_id, self.backend, False, process.returncode, stdout[-spec.limits.output_bytes :], stderr[-spec.limits.output_bytes :], False, (time.perf_counter() - started) * 1000.0)
            for request in self._firecracker_config_requests(spec, kernel, rootfs, cmdline):
                self._post_unix_http(api_socket, request)
            self._post_unix_http(api_socket, {"method": "PUT", "path": "/actions", "body": {"action_type": "InstanceStart"}})
            remaining = max(0.1, spec.limits.timeout_seconds - (time.perf_counter() - started))
            try:
                stdout, stderr = process.communicate(timeout=remaining)
                timed_out = False
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                timed_out = True
            return SandboxResult(spec.sandbox_id, self.backend, process.returncode == 0 and not timed_out, process.returncode, stdout, stderr, timed_out, (time.perf_counter() - started) * 1000.0)
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()
            api_socket.unlink(missing_ok=True)
            broker.forget_process(process)

    @staticmethod
    def _firecracker_config_requests(spec: SandboxSpec, kernel: Path, rootfs: Path, cmdline: str) -> tuple[dict[str, Any], ...]:
        return (
            {"method": "PUT", "path": "/machine-config", "body": {"vcpu_count": 1, "mem_size_mib": spec.limits.memory_mb, "ht_enabled": False, "track_dirty_pages": False}},
            {"method": "PUT", "path": "/boot-source", "body": {"kernel_image_path": str(kernel), "boot_args": cmdline}},
            {"method": "PUT", "path": "/drives/rootfs", "body": {"drive_id": "rootfs", "path_on_host": str(rootfs), "is_root_device": True, "is_read_only": False}},
        )

    @staticmethod
    def _post_unix_http(socket_path: Path, request: Mapping[str, Any]) -> None:
        import socket

        payload = json.dumps(request["body"], separators=(",", ":")).encode("utf-8")
        message = f"{request['method']} {request['path']} HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii") + payload
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            sock.settimeout(3.0)
            sock.connect(str(socket_path))
            sock.sendall(message)
            response = sock.recv(4096)
            if b" 2" not in response.split(b"\r\n", 1)[0] and b" 3" not in response.split(b"\r\n", 1)[0]:
                raise DSecError(f"firecracker control-plane rejected request: {response[:200]!r}")
        finally:
            sock.close()


class FullVMBackend:
    """QEMU full-VM backend with immutable snapshot boot semantics."""

    backend = SandboxBackend.FULLVM

    def __init__(self, binary: str | None = None) -> None:
        self.binary = binary or shutil.which("qemu-system-x86_64")

    def available(self) -> bool:
        return self.binary is not None

    def run(self, spec: SandboxSpec, workspace: Path) -> SandboxResult:
        if not self.binary:
            raise BackendUnavailable("qemu-system-x86_64 is unavailable")
        disk = Path(str(spec.metadata.get("disk_image", ""))).resolve()
        if not disk.is_file():
            raise ValueError("full VM requires disk_image")
        argv = [self.binary, "-nodefaults", "-machine", "accel=kvm:tcg", "-m", str(spec.limits.memory_mb), "-smp", "1", "-snapshot", "-display", "none", "-serial", "stdio", "-drive", f"file={disk},if=virtio,format=qcow2,readonly=on"]
        return _ProcessRunner.run(argv, cwd=workspace, env={}, limits=spec.limits, sandbox_id=spec.sandbox_id, backend=self.backend)


class OverlayComposer:
    """Compose layers deterministically, using native overlayfs when requested."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def materialize(self, plan: OverlayPlan, destination: str | Path) -> Path:
        """Materialize a deterministic merged tree without requiring mount privileges."""
        destination_path = Path(destination).resolve()
        if destination_path.exists():
            shutil.rmtree(destination_path)
        destination_path.mkdir(parents=True, exist_ok=True)
        for layer in plan.layers():
            source = layer.resolved()
            self._copy_layer(source, destination_path)
        return destination_path

    @staticmethod
    def _copy_layer(source: Path, destination: Path) -> None:
        for entry in source.rglob("*"):
            rel = entry.relative_to(source)
            target = destination / rel
            if entry.is_symlink():
                resolved_target = entry.resolve()
                if not str(resolved_target).startswith(str(source) + os.sep):
                    raise DSecError(f"overlay symlink escapes layer: {entry}")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.unlink(missing_ok=True)
                target.symlink_to(os.readlink(entry))
            elif entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            elif entry.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(entry, target)
            else:
                raise DSecError(f"unsupported overlay entry: {entry}")

    @staticmethod
    def native_overlay_available() -> bool:
        return bool(shutil.which("fuse-overlayfs") or shutil.which("mount.fuse-overlayfs") or shutil.which("mount"))


class SnapshotStore:
    """Content-addressed snapshot and incremental-diff store."""

    MANIFEST = ".dsec_manifest.json"
    DELETED = ".dsec_deleted.json"

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    @staticmethod
    def _file_manifest(root: Path) -> dict[str, dict[str, Any]]:
        manifest: dict[str, dict[str, Any]] = {}
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.name in {SnapshotStore.MANIFEST, SnapshotStore.DELETED}:
                continue
            rel = path.relative_to(root).as_posix()
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            manifest[rel] = {"sha256": digest, "size": path.stat().st_size}
        return manifest

    @staticmethod
    def _manifest_digest(manifest: Mapping[str, Any]) -> str:
        raw = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def snapshot(self, source: str | Path) -> SnapshotRef:
        src = Path(source).resolve()
        if not src.is_dir():
            raise ValueError("snapshot source must be a directory")
        manifest = self._file_manifest(src)
        digest = self._manifest_digest(manifest)
        snapshot_id = f"snap_{digest[:24]}"
        archive = self.root / f"{snapshot_id}.tar.gz"
        if not archive.exists():
            tmp = self.root / f".{snapshot_id}.{uuid.uuid4().hex}.tmp"
            try:
                with tarfile.open(tmp, "w:gz") as tar:
                    tar.add(src, arcname=".", recursive=True, filter=lambda info: self._tar_filter(info))
                    payload = json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
                    info = tarfile.TarInfo(self.MANIFEST)
                    info.size = len(payload)
                    info.mtime = int(time.time())
                    tar.addfile(info, fileobj=_BytesReader(payload))
                os.replace(tmp, archive)
            finally:
                tmp.unlink(missing_ok=True)
        return SnapshotRef(snapshot_id, str(archive), digest, len(manifest), sum(int(v["size"]) for v in manifest.values()), time.time())

    @staticmethod
    def _tar_filter(info: tarfile.TarInfo) -> tarfile.TarInfo:
        info.uid = 0
        info.gid = 0
        info.uname = ""
        info.gname = ""
        info.mtime = 0
        return info

    def load(self, snapshot: SnapshotRef | str, destination: str | Path) -> Path:
        archive = Path(snapshot.archive_path if isinstance(snapshot, SnapshotRef) else snapshot).resolve()
        if not archive.is_file():
            raise FileNotFoundError(archive)
        target = Path(destination).resolve()
        if target.exists():
            shutil.rmtree(target)
        target.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive, "r:gz") as tar:
            self._safe_extract(tar, target)
        loaded = self._file_manifest(target)
        expected = None
        if isinstance(snapshot, SnapshotRef):
            expected = snapshot.manifest_sha256
        else:
            manifest_path = target / self.MANIFEST
            if manifest_path.exists():
                expected = self._manifest_digest(json.loads(manifest_path.read_text(encoding="utf-8")))
        (target / self.MANIFEST).unlink(missing_ok=True)
        if expected and self._manifest_digest(loaded) != expected:
            raise SnapshotIntegrityError("snapshot manifest digest mismatch")
        return target

    @staticmethod
    def _safe_extract(tar: tarfile.TarFile, destination: Path) -> None:
        root = destination.resolve()
        for member in tar.getmembers():
            if member.issym() or member.islnk() or not (member.isdir() or member.isreg()):
                raise SnapshotIntegrityError("snapshot archives may contain only regular files and directories")
            target = (destination / member.name).resolve()
            if target != root and not str(target).startswith(str(root) + os.sep):
                raise SnapshotIntegrityError(f"snapshot path escape: {member.name}")
            if member.size > 10 * 1024**4:
                raise SnapshotIntegrityError("snapshot member exceeds maximum supported size")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            source = tar.extractfile(member)
            if source is None:
                raise SnapshotIntegrityError(f"snapshot member unreadable: {member.name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with source, target.open("wb") as handle:
                shutil.copyfileobj(source, handle, length=1024 * 1024)
            os.chmod(target, member.mode & 0o777)

    def pack_diff(self, base: str | Path, target: str | Path) -> DiffPack:
        base_root = Path(base).resolve()
        target_root = Path(target).resolve()
        if not base_root.is_dir() or not target_root.is_dir():
            raise ValueError("base and target must be directories")
        base_manifest = self._file_manifest(base_root)
        target_manifest = self._file_manifest(target_root)
        changed = sorted(path for path, meta in target_manifest.items() if base_manifest.get(path) != meta)
        deleted = sorted(path for path in base_manifest if path not in target_manifest)
        base_digest = self._manifest_digest(base_manifest)
        target_digest = self._manifest_digest(target_manifest)
        diff_id = f"diff_{hashlib.sha256((base_digest + target_digest).encode()).hexdigest()[:24]}"
        archive = self.root / f"{diff_id}.tar.gz"
        if not archive.exists():
            tmp = self.root / f".{diff_id}.{uuid.uuid4().hex}.tmp"
            try:
                with tarfile.open(tmp, "w:gz") as tar:
                    for rel in changed:
                        tar.add(target_root / rel, arcname=rel, recursive=False, filter=lambda info: self._tar_filter(info))
                    deleted_payload = json.dumps(deleted, sort_keys=True, separators=(",", ":")).encode("utf-8")
                    deleted_info = tarfile.TarInfo(self.DELETED)
                    deleted_info.size = len(deleted_payload)
                    deleted_info.mtime = 0
                    tar.addfile(deleted_info, fileobj=_BytesReader(deleted_payload))
                    manifest_payload = json.dumps(target_manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
                    manifest_info = tarfile.TarInfo(self.MANIFEST)
                    manifest_info.size = len(manifest_payload)
                    manifest_info.mtime = 0
                    tar.addfile(manifest_info, fileobj=_BytesReader(manifest_payload))
                os.replace(tmp, archive)
            finally:
                tmp.unlink(missing_ok=True)
        total_bytes = sum(int(target_manifest[item]["size"]) for item in changed)
        return DiffPack(diff_id, str(archive), base_digest, target_digest, tuple(changed), tuple(deleted), total_bytes)

    def apply_diff(self, base: str | Path, diff: DiffPack | str, destination: str | Path) -> Path:
        base_root = Path(base).resolve()
        archive = Path(diff.archive_path if isinstance(diff, DiffPack) else diff).resolve()
        target = Path(destination).resolve()
        if not base_root.is_dir() or not archive.is_file():
            raise ValueError("invalid base or diff archive")
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(base_root, target, symlinks=False)
        with tarfile.open(archive, "r:gz") as tar:
            members = tar.getmembers()
            deleted: list[str] = []
            target_manifest: dict[str, Any] | None = None
            for member in members:
                if member.issym() or member.islnk():
                    raise SnapshotIntegrityError("diff archives may not contain links")
                safe = (target / member.name).resolve()
                if safe != target and not str(safe).startswith(str(target) + os.sep):
                    raise SnapshotIntegrityError(f"diff path escape: {member.name}")
                if member.name == self.DELETED:
                    data = tar.extractfile(member)
                    deleted = json.loads(data.read().decode("utf-8")) if data else []
                elif member.name == self.MANIFEST:
                    data = tar.extractfile(member)
                    target_manifest = json.loads(data.read().decode("utf-8")) if data else None
                else:
                    output = (target / member.name).resolve()
                    if member.isdir():
                        output.mkdir(parents=True, exist_ok=True)
                    elif member.isfile():
                        if output.exists() and output.is_dir():
                            shutil.rmtree(output)
                        output.parent.mkdir(parents=True, exist_ok=True)
                        source = tar.extractfile(member)
                        if source is None:
                            raise SnapshotIntegrityError(f"diff member unreadable: {member.name}")
                        with source, output.open("wb") as handle:
                            shutil.copyfileobj(source, handle, length=1024 * 1024)
                        os.chmod(output, member.mode & 0o777)
                    else:
                        raise SnapshotIntegrityError("diff archives may contain only regular files and directories")
            for rel in deleted:
                victim = (target / rel).resolve()
                if victim != target and not str(victim).startswith(str(target) + os.sep):
                    raise SnapshotIntegrityError("delete path escape")
                if victim.is_file() or victim.is_symlink():
                    victim.unlink()
                elif victim.is_dir():
                    shutil.rmtree(victim)
        actual = self._file_manifest(target)
        if target_manifest is not None and actual != target_manifest:
            raise SnapshotIntegrityError("applied diff manifest mismatch")
        return target


class DsecSandboxManager:
    """High-level libdsec-style sandbox SDK."""

    def __init__(self, root: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("DsecSandboxManager secret must contain at least 32 bytes")
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._workspaces = self.root / "workspaces"
        self._workspaces.mkdir(exist_ok=True)
        self.overlay = OverlayComposer(self.root / "overlay")
        self.snapshots = SnapshotStore(self.root / "snapshots")
        self.backends: dict[SandboxBackend, SandboxBackendProtocol] = {
            SandboxBackend.FNCALL: FnCallBackend(),
            SandboxBackend.CONTAINER: ContainerBackend(),
            SandboxBackend.MICROVM: FirecrackerBackend(),
            SandboxBackend.FULLVM: FullVMBackend(),
        }
        self._records: dict[str, SandboxRecord] = {}
        self._lock = threading.RLock()
        self._max_live = 1_000_000
        self._secret_fingerprint = hashlib.sha256(secret).hexdigest()

    def create(self, spec: SandboxSpec) -> SandboxRecord:
        """Create a logical sandbox and deterministically materialize its workspace."""
        spec.validate()
        with self._lock:
            if len(self._records) >= self._max_live:
                raise DSecError("sandbox logical-cap reached")
            if spec.sandbox_id in self._records:
                raise ValueError("sandbox_id already exists")
            workspace = self._workspaces / spec.sandbox_id
            self.overlay.materialize(spec.overlay, workspace)
            record = SandboxRecord(spec.sandbox_id, spec.backend, SandboxState.CREATED, str(workspace), spec.overlay.digest(), time.time(), time.time())
            self._records[spec.sandbox_id] = record
            return record

    def run(self, spec: SandboxSpec) -> SandboxResult:
        """Create-on-demand and execute through the selected backend."""
        record = self._records.get(spec.sandbox_id) or self.create(spec)
        backend = self.backends[spec.backend]
        if not backend.available():
            raise BackendUnavailable(f"backend unavailable: {spec.backend.value}")
        with self._lock:
            self._records[spec.sandbox_id] = SandboxRecord(spec.sandbox_id, spec.backend, SandboxState.RUNNING, record.workspace, record.overlay_digest, record.created_at, time.time(), record.snapshot_id)
        try:
            return backend.run(spec, Path(record.workspace))
        finally:
            with self._lock:
                current = self._records.get(spec.sandbox_id)
                if current is not None:
                    self._records[spec.sandbox_id] = SandboxRecord(spec.sandbox_id, spec.backend, SandboxState.STOPPED, current.workspace, current.overlay_digest, current.created_at, time.time(), current.snapshot_id)

    def run_callable(self, sandbox_id: str, callable_: Callable[[], Any], *, limits: SandboxLimits | None = None) -> SandboxResult:
        """Run a trusted harness function inside the bounded FNCALL backend."""
        with self._lock:
            record = self._records.get(sandbox_id)
        if record is None:
            raise KeyError(sandbox_id)
        backend = self.backends[SandboxBackend.FNCALL]
        if not isinstance(backend, FnCallBackend):
            raise DSecError("FNCALL backend contract violation")
        return backend.run_callable(sandbox_id, limits or SandboxLimits(), callable_)

    def snapshot(self, sandbox_id: str) -> SnapshotRef:
        """Persist the current logical sandbox workspace as a reusable snapshot."""
        with self._lock:
            record = self._records.get(sandbox_id)
        if record is None:
            raise KeyError(sandbox_id)
        ref = self.snapshots.snapshot(record.workspace)
        with self._lock:
            self._records[sandbox_id] = SandboxRecord(record.sandbox_id, record.backend, SandboxState.SNAPSHOTTED, record.workspace, record.overlay_digest, record.created_at, time.time(), ref.snapshot_id)
        return ref

    def pack_diff(self, base: str | Path, target: str | Path) -> DiffPack:
        """Create a reusable incremental diff."""
        return self.snapshots.pack_diff(base, target)

    def load_snapshot(self, snapshot: SnapshotRef | str, destination: str | Path) -> Path:
        """On-demand materialization of a reusable snapshot."""
        return self.snapshots.load(snapshot, destination)

    def apply_diff(self, base: str | Path, diff: DiffPack | str, destination: str | Path) -> Path:
        """On-demand reconstruction from a base and incremental diff."""
        return self.snapshots.apply_diff(base, diff, destination)

    def destroy(self, sandbox_id: str) -> None:
        """Destroy a logical sandbox and its local workspace."""
        with self._lock:
            record = self._records.pop(sandbox_id, None)
        if record is None:
            return
        shutil.rmtree(record.workspace, ignore_errors=True)

    def health(self) -> dict[str, Any]:
        """Return non-secret runtime capability and lifecycle state."""
        with self._lock:
            states = {state.value: 0 for state in SandboxState}
            for record in self._records.values():
                states[record.state.value] += 1
            return {
                "logical_sandboxes": len(self._records),
                "states": states,
                "backends": {name.value: backend.available() for name, backend in self.backends.items()},
                "overlay_native_available": self.overlay.native_overlay_available(),
                "snapshot_root": str(self.snapshots.root),
                "policy_fingerprint": self._secret_fingerprint[:16],
            }

    def close(self) -> None:
        """Destroy all live logical sandboxes."""
        with self._lock:
            ids = tuple(self._records)
        for sandbox_id in ids:
            self.destroy(sandbox_id)


class _BytesReader:
    """Tiny file-like adapter for tarfile.addfile."""

    def __init__(self, data: bytes) -> None:
        self._data = data
        self._position = 0

    def read(self, size: int = -1) -> bytes:
        if size < 0:
            size = len(self._data) - self._position
        start = self._position
        self._position = min(len(self._data), self._position + size)
        return self._data[start:self._position]

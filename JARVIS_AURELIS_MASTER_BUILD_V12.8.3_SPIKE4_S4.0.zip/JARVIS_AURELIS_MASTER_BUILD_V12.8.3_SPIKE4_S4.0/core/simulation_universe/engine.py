from __future__ import annotations

import base64
import copy
import hashlib
import json
import logging
import math
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from core.kernel_12_8_0.canonical import canonical_json

logger = logging.getLogger(__name__)


class SimulationError(RuntimeError): pass
class SimulationAuthorizationError(SimulationError, PermissionError): pass
class SimulationIsolationError(SimulationError): pass
class SimulationValidationError(SimulationError, ValueError): pass
class SimulationDivergenceError(SimulationError): pass
class SimulationReplayError(SimulationError): pass

class FidelityTier(StrEnum):
    ABSTRACT='abstract'; BEHAVIORAL='behavioral'; ADVERSARIAL='adversarial'; REPLAY='replay'; DIGITAL_TWIN='digital_twin'; HARDWARE_IN_LOOP='hardware_in_loop'; PARTIAL_REAL='partial_real'
class TargetClass(StrEnum):
    PLAN='plan'; TOOL='tool'; COMPOSITE_TOOL='composite_tool'; AGENT='agent'; WORKFLOW='workflow'; SKILL='skill'; MODEL_ROUTE='model_route'; SECURITY_ACTION='security_action'; DEVICE_ACTION='device_action'; SYSTEM_CHANGE='system_change'
class EnvironmentScope(StrEnum): ISOLATED='isolated'; MIRRORED='mirrored'; FORKED='forked'; HYBRID='hybrid'
class Determinism(StrEnum): DETERMINISTIC='deterministic'; SEEDED='seeded'; NONDETERMINISTIC='nondeterministic'
class UniverseState(StrEnum): PREPARED='prepared'; RUNNING='running'; PAUSED='paused'; COMPLETED='completed'; DIVERGED='diverged'; FAILED='failed'; CANCELLED='cancelled'; TIMED_OUT='timed_out'
class OutcomeClass(StrEnum): SUCCESS='success'; PARTIAL='partial'; DIVERGED='diverged'; FAILED='failed'; CANCELLED='cancelled'; TIMEOUT='timeout'; VIOLATION='violation'; COMPENSATED='compensated'
class DivergenceKind(StrEnum):
    OUTCOME='outcome_divergence'; POSTCONDITION='postcondition_violation'; METRIC='metric_divergence'; SIDE_EFFECT='side_effect_divergence'; MISSING_SIDE_EFFECT='missing_side_effect'; TIMING='timing_divergence'; RESOURCE='resource_divergence'; POLICY='policy_violation'; ISOLATION='isolation_breach'; NONDETERMINISM='nondeterminism_breach'

FROZEN_FIDELITY=tuple(x.value for x in FidelityTier); FROZEN_TARGETS=tuple(x.value for x in TargetClass); FROZEN_SCOPES=tuple(x.value for x in EnvironmentScope); FROZEN_OUTCOMES=tuple(x.value for x in OutcomeClass)

MANDATORY_SIMULATION_EFFECTS=frozenset({'destructive','financial','identity','device','communication','irreversible'})


def _now(): return time.time()
def _uuid(): return str(uuid.uuid4())
def _canon(v): return canonical_json(v)
def _sha(v): return hashlib.sha256(_canon(v)).hexdigest()
def _b64(v): return base64.b64encode(v).decode('ascii')
def _unb64(v): return base64.b64decode(v.encode('ascii'))


def _unsigned(doc: Mapping[str,Any]) -> dict[str,Any]:
    # Universe signatures cover the sealed contract, not mutable lifecycle telemetry.
    mutable={'signature','event_log','actual','checkpoint_data','state','outcome_class','started_at','finished_at','step_index'}
    return {k:v for k,v in doc.items() if k not in mutable}

def sign_document(doc: Mapping[str,Any], signer: Ed25519PrivateKey) -> str:
    return _b64(signer.sign(_canon(_unsigned(doc))))

def verify_document(doc: Mapping[str,Any], public_key: bytes|Ed25519PublicKey) -> bool:
    try:
        key=public_key if isinstance(public_key,Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(public_key))
        key.verify(_unb64(str(doc['signature'])), _canon(_unsigned(doc))); return True
    except Exception: return False

@dataclass(frozen=True, slots=True)
class Budget:
    cpu_seconds: float=60.0; wall_seconds: float=60.0; ram_mb:int=1024; vram_mb:int=0; network_bytes:int=0; tool_calls:int=100; api_calls:int=100; tokens_in:int=100000; tokens_out:int=100000
    def validate(self):
        for k,v in asdict(self).items():
            if float(v)<0: raise SimulationValidationError(f'budget {k} must be non-negative')
        if self.wall_seconds<=0: raise SimulationValidationError('wall_seconds must be positive')
    def tighten(self, other: Any) -> 'Budget':
        vals=other.as_dict() if hasattr(other,'as_dict') else dict(other)
        return Budget(**{k:min(getattr(self,k), float(vals[k])) for k in asdict(self)})
    def as_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class IsolationGuarantees:
    network_egress_denied:bool=True; real_fs_writes_denied:bool=True; real_device_access_denied:bool=True; real_cloud_calls_denied:bool=True; real_secret_use_denied:bool=True; real_event_bus_write_denied:bool=True; real_memory_write_denied:bool=True; real_world_model_write_denied:bool=True
    def validate(self):
        if not all(asdict(self).values()): raise SimulationIsolationError('hermetic isolation guarantee missing')

@dataclass(frozen=True, slots=True)
class Tolerance:
    timing_ms:float=0.0; metric_fraction:float=0.0; false_positive_rate:float=0.0; false_negative_rate:float=0.0
    def validate(self):
        if any(float(v)<0 for v in asdict(self).values()): raise SimulationValidationError('negative tolerance')

@dataclass(frozen=True, slots=True)
class ExpectedBehavior:
    expected_outcome:str='success'; expected_postconditions:tuple[Mapping[str,Any],...]=(); expected_metrics:Mapping[str,Any]=field(default_factory=dict); expected_failure_modes:tuple[str,...]=(); tolerance:Tolerance=field(default_factory=Tolerance)
    def to_dict(self):
        return {'expected_outcome':self.expected_outcome,'expected_postconditions':[dict(x) for x in self.expected_postconditions],'expected_metrics':dict(self.expected_metrics),'expected_failure_modes':list(self.expected_failure_modes),'tolerance':asdict(self.tolerance)}

@dataclass(slots=True)
class SimulatedComponent:
    entity_kind:str; simulated_id:str; real_ref:str|None=None; behavior:Mapping[str,Any]=field(default_factory=dict); state:Mapping[str,Any]=field(default_factory=dict); provenance:Mapping[str,Any]=field(default_factory=dict); io_contract_hash:str|None=None; signature:str=''; integrity_hash:str=''
    def document(self):
        return {'entity_kind':self.entity_kind,'simulated_id':self.simulated_id,'real_ref':self.real_ref,'behavior':dict(self.behavior),'state':dict(self.state),'provenance':dict(self.provenance),'io_contract_hash':self.io_contract_hash,'signature':self.signature,'integrity_hash':self.integrity_hash}

@dataclass(frozen=True, slots=True)
class Fault:
    fault_id:str; kind:str; target_ref:str; trigger:str|None=None; probability:float=1.0; seed_offset:int=0
    def validate(self):
        allowed={'latency_injection','packet_loss','network_partition','tool_error_injection','tool_timeout_injection','model_hallucination_injection','model_degradation_injection','filesystem_corruption','device_fault_injection','auth_bypass_attempt','prompt_injection','data_poisoning','race_condition_injection','resource_exhaustion','dependency_unavailable'}
        if self.kind not in allowed: raise SimulationValidationError(f'unknown fault kind: {self.kind}')
        if not 0<=self.probability<=1: raise SimulationValidationError('fault probability outside [0,1]')

@dataclass(frozen=True, slots=True)
class AdversarialConfig:
    adversaries:tuple[Mapping[str,Any],...]=(); fault_schedule:tuple[Fault,...]=(); tolerance:Tolerance=field(default_factory=Tolerance); signature:str=''
    def validate(self):
        if not self.signature: raise SimulationAuthorizationError('adversarial configuration must be signed')
        for f in self.fault_schedule: f.validate()

@dataclass(slots=True)
class SimulationUniverse:
    universe_id:str; universe_version:int; tenant_id:str; fidelity_tier:str; target_class:str; environment_scope:str; environment_ref:dict[str,Any]; target_ref:dict[str,Any]; simulated_entities:list[dict[str,Any]]; simulated_tools:list[dict[str,Any]]; simulated_models:list[dict[str,Any]]; simulated_networks:list[dict[str,Any]]; simulated_filesystems:list[dict[str,Any]]; simulated_devices:list[dict[str,Any]]; simulated_users:list[dict[str,Any]]; simulated_apis:list[dict[str,Any]]; simulated_iot:list[dict[str,Any]]; simulated_robots:list[dict[str,Any]]; simulated_tool_responses:list[dict[str,Any]]; adversarial_config:dict[str,Any]|None; budget:dict[str,Any]; isolation:dict[str,Any]; expected:dict[str,Any]; provenance:dict[str,Any]; state:str; outcome_class:str|None; started_at:float|None; finished_at:float|None; signature:str; integrity_hash:str; sealed:bool=True; step_index:int=0; event_log:list[dict[str,Any]]=field(default_factory=list); actual:dict[str,Any]=field(default_factory=dict); checkpoint_data:dict[str,Any]|None=None
    def unsigned(self):
        d=asdict(self); d.pop('signature',None); return d
    def to_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class SimulationOutcome:
    outcome_id:str; universe_id:str; outcome_class:str; state:str; steps:int; actual:Mapping[str,Any]; divergence_ids:tuple[str,...]; environment_hash:str; outcome_hash:str; signature:str
    def to_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class DivergenceReport:
    report_id:str; universe_id:str; simulation_outcome_ref:str; expected_ref:str; divergence_kind:str; detail:Mapping[str,Any]; severity:str; reproducible:str; evidence_refs:tuple[str,...]; recommended_action:str; produced_at:float; signature:str
    def to_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class Checkpoint:
    checkpoint_id:str; universe_id:str; universe_version:int; step:int; state_hash:str; state:Mapping[str,Any]

class BaseSimulationAdapter:
    target_class='generic'
    def __init__(self, engine:'SimulationEngine'): self.engine=engine
    def prepare(self, universe): return universe
    def run(self, universe): return self.engine._execute(universe)
    def pause(self, universe): universe.state=UniverseState.PAUSED.value
    def resume(self, universe): universe.state=UniverseState.RUNNING.value
    def checkpoint(self, universe): return self.engine.checkpoint(universe.universe_id)
    def restore(self, checkpoint): return self.engine.restore(checkpoint)
    def cancel(self, universe, reason):
        universe.state=UniverseState.CANCELLED.value; universe.actual={'reason':reason}
    def wait(self, universe, timeout):
        if timeout is not None and timeout<=0: raise TimeoutError('simulation wait timeout')
        return self.engine.wait(universe.universe_id, timeout)

class PlanSimulationAdapter(BaseSimulationAdapter): target_class='plan'
class ToolSimulationAdapter(BaseSimulationAdapter): target_class='tool'
class CompositeToolSimulationAdapter(BaseSimulationAdapter): target_class='composite_tool'
class AgentSimulationAdapter(BaseSimulationAdapter): target_class='agent'
class WorkflowSimulationAdapter(BaseSimulationAdapter): target_class='workflow'
class SkillSimulationAdapter(BaseSimulationAdapter): target_class='skill'
class ModelRouteSimulationAdapter(BaseSimulationAdapter): target_class='model_route'
class DeviceSimulationAdapter(BaseSimulationAdapter): target_class='device_action'
class SystemChangeSimulationAdapter(BaseSimulationAdapter): target_class='system_change'

ADAPTERS={c.target_class:c for c in (PlanSimulationAdapter,ToolSimulationAdapter,CompositeToolSimulationAdapter,AgentSimulationAdapter,WorkflowSimulationAdapter,SkillSimulationAdapter,ModelRouteSimulationAdapter,DeviceSimulationAdapter,SystemChangeSimulationAdapter)}

class SimulationEngine:
    """Canonical P2-K simulation control plane."""
    SCHEMA_VERSION='2.0.0'; MANDATE_VERSION='2.0.0'
    def __init__(self, *, root:str|Path|None=None, signer:Ed25519PrivateKey|None=None, event_fabric:Any=None, world_model:Any=None, memory:Any=None, failure_intelligence:Any=None):
        self.root=Path(root or '.jarvis_simulation').resolve(); self.root.mkdir(parents=True,exist_ok=True)
        self.signer=signer or Ed25519PrivateKey.generate(); self.public_key=self.signer.public_key(); self.key_id='simulation-universe'
        self.event_fabric=event_fabric; self.world_model=world_model; self.memory=memory; self.failure_intelligence=failure_intelligence
        self._universes={}; self._universe_versions={}; self._checkpoints={}; self._reports={}; self._lock=threading.RLock(); self._event_seq=0
    @property
    def adapters(self): return {k:v(self) for k,v in ADAPTERS.items()}
    def _emit(self,name,u,payload=None,*,severity='normal'):
        self._event_seq+=1; event={'event_id':_uuid(),'event_name':name,'sequence':self._event_seq,'timestamp':_now(),'correlation_id':u.universe_id,'causation_id':u.event_log[-1]['event_id'] if u.event_log else None,'tenant_id':u.tenant_id,'severity':severity,'payload':payload or {}}
        u.event_log.append(event)
        if self.event_fabric is not None:
            try:
                self.event_fabric.publish(name,payload or {},source='p2k.simulation',correlation_id=u.universe_id,causation_id=event['causation_id'])
            except Exception:
                logger.debug("P2-K Event Fabric publish failed; local simulation event log remains authoritative", exc_info=True)
        return event
    def _environment(self, tenant, scope, seed, snapshot=None):
        if scope not in FROZEN_SCOPES: raise SimulationValidationError('invalid environment scope')
        if scope=='hybrid' and not snapshot: raise SimulationAuthorizationError('hybrid environment requires explicit entity declaration')
        if scope in {'mirrored','forked'} and snapshot is None: raise SimulationValidationError(f'{scope} environment requires World Model snapshot')
        env={'scope':scope,'tenant_id':tenant,'seed':int(seed),'snapshot':copy.deepcopy(snapshot) if snapshot is not None else {'entities':{},'relations':{},'state':{}},'overlay':{}}
        env['hash']=_sha(env); return env
    def prepare(self, target_ref:Mapping[str,Any], fidelity_tier:str, environment_scope:str, expectations:Mapping[str,Any], config:Mapping[str,Any]|None=None, *, execution_context:Any=None, tenant_id:str='default', seed:int=0, budget:Mapping[str,Any]|None=None, world_snapshot:Mapping[str,Any]|None=None, requested_by:str='system') -> SimulationUniverse:
        config=dict(config or {}); fidelity=str(fidelity_tier); scope=str(environment_scope); target=dict(target_ref)
        if execution_context is None: raise SimulationAuthorizationError('P2-E ExecutionContext is required')
        mode=getattr(getattr(execution_context,'mode',None),'value',getattr(execution_context,'mode',None));
        if str(mode)!='simulation': raise SimulationAuthorizationError('ExecutionContext must use simulation mode')
        if fidelity not in FROZEN_FIDELITY or scope not in FROZEN_SCOPES: raise SimulationValidationError('invalid simulation taxonomy')
        target_kind=str(target.get('kind',''))
        if target_kind not in FROZEN_TARGETS: raise SimulationValidationError('invalid target class')
        determinism=str(config.get('determinism','deterministic'))
        if determinism not in {x.value for x in Determinism}: raise SimulationValidationError('invalid determinism')
        if determinism=='nondeterministic' and fidelity!='abstract': raise SimulationValidationError('nondeterministic simulation is only allowed for abstract fidelity')
        if fidelity=='adversarial' and scope not in {'isolated','forked'}: raise SimulationValidationError('adversarial simulation requires isolated or forked scope')
        iso=IsolationGuarantees(**config.get('isolation',{})); iso.validate()
        exp=ExpectedBehavior(expected_outcome=str(expectations.get('expected_outcome','success')),expected_postconditions=tuple(expectations.get('expected_postconditions',())),expected_metrics=dict(expectations.get('expected_metrics',{})),expected_failure_modes=tuple(expectations.get('expected_failure_modes',())),tolerance=Tolerance(**expectations.get('tolerance',{})))
        exp.tolerance.validate()
        env=self._environment(tenant_id,scope,seed,world_snapshot)
        b=Budget(**{**Budget().as_dict(),**dict(budget or {})}); b.validate()
        u=SimulationUniverse(
            universe_id=_uuid(), universe_version=1, tenant_id=tenant_id, fidelity_tier=fidelity, target_class=target_kind, environment_scope=scope,
            environment_ref={'world_partition_id':None,'environment_hash':env['hash'],'seed':int(seed),'determinism':determinism,'environment':env}, target_ref=target,
            simulated_entities=[], simulated_tools=[], simulated_models=[], simulated_networks=[], simulated_filesystems=[], simulated_devices=[], simulated_users=[],
            simulated_apis=[], simulated_iot=[], simulated_robots=[], simulated_tool_responses=[], adversarial_config=None, budget=b.as_dict(), isolation=asdict(iso),
            expected=exp.to_dict(), provenance={'requested_by':{'principal':requested_by,'key_id':self.key_id},'requested_at':_now(),'parent_simulation_id':config.get('parent_simulation_id'),'derived_from_plan':config.get('derived_from_plan'),'derivation':config.get('derivation')},
            state=UniverseState.PREPARED.value, outcome_class=None, started_at=None, finished_at=None, signature='', integrity_hash='', sealed=True
        )
        if fidelity=='adversarial':
            adv=AdversarialConfig(**(config.get('adversarial_config') or {})); adv.validate(); u.adversarial_config=asdict(adv)
        u.integrity_hash=_sha(u.unsigned()); u.signature=sign_document(u.to_dict(),self.signer); self._universes[u.universe_id]=u; self._emit('Simulation.Prepared',u,{'integrity_hash':u.integrity_hash})
        return copy.deepcopy(u)
    def add_component(self, universe_id:str, component:Mapping[str,Any], component_kind:str, *, real_contract_hash:str|None=None):
        with self._lock:
            old=self._universes[universe_id]
            if old.state!=UniverseState.PREPARED.value: raise SimulationValidationError('universe is no longer mutable')
            c=dict(component); c['entity_kind']=component_kind; c.setdefault('simulated_id',_uuid())
            if real_contract_hash and c.get('io_contract_hash') not in {None,real_contract_hash}: raise SimulationValidationError('simulation I/O contract mismatch')
            effects=set(c.get('behavior',{}).get('side_effects',()))
            if effects & {'real_network','real_fs','real_device','real_cloud','real_secret','production_memory','production_world_model'}: raise SimulationIsolationError('simulated component declares a real side effect')
            bucket={'tool':'simulated_tools','model':'simulated_models','network':'simulated_networks','filesystem':'simulated_filesystems','device':'simulated_devices','user':'simulated_users','api':'simulated_apis','iot':'simulated_iot','robot':'simulated_robots','tool_response':'simulated_tool_responses'}.get(component_kind,'simulated_entities')
            new=copy.deepcopy(old); new.universe_version=old.universe_version+1; getattr(new,bucket).append(c); new.integrity_hash=_sha(new.unsigned()); new.signature=sign_document(new.to_dict(),self.signer)
            self._universe_versions[(universe_id,old.universe_version)]=copy.deepcopy(old); self._universes[universe_id]=new
            return copy.deepcopy(c)
    def _assert_isolation(self,u):
        if not all(u.isolation.values()): raise SimulationIsolationError('declared isolation is incomplete')
        env=u.environment_ref.get('environment',{}); scope=env.get('scope')
        if scope not in FROZEN_SCOPES: raise SimulationIsolationError('invalid environment')
    def _execute(self,u):
        self._assert_isolation(u); u.state=UniverseState.RUNNING.value; u.started_at=_now(); self._emit('Simulation.Started',u,{'target':u.target_ref})
        max_steps=min(int(u.budget['tool_calls'] or 1),10000)
        target=u.target_ref; actions=target.get('actions') or target.get('steps') or []
        actual={'target':target.get('ref'),'steps':0,'effects':[],'metrics':{},'postconditions':[],'seed':u.environment_ref['seed']}
        adv=u.adversarial_config or {}
        faults={f['target_ref']:f for f in adv.get('fault_schedule',[]) if isinstance(f,dict)}
        for idx,action in enumerate(actions[:max_steps]):
            if u.state!=UniverseState.RUNNING.value: break
            actual['steps']=idx+1
            if isinstance(action,Mapping):
                ref=str(action.get('tool_ref',action.get('ref','')))
                if ref in faults: actual.setdefault('faults',[]).append(faults[ref].get('kind'))
                actual['effects'].append({'ref':ref,'status':'simulated','input':copy.deepcopy(action.get('input',{}))})
            self._emit('Simulation.StepExecuted',u,{'step':idx+1,'action':action})
        if u.state==UniverseState.RUNNING.value: u.state=UniverseState.COMPLETED.value; u.finished_at=_now()
        # expected outcome + explicit postcondition checks
        divergences=[]
        if u.expected['expected_outcome']!='success' and u.state==UniverseState.COMPLETED.value: divergences.append(self._make_divergence(u,DivergenceKind.OUTCOME.value,{'expected':u.expected['expected_outcome'],'actual':'success'}))
        if actual['steps']<len(actions): divergences.append(self._make_divergence(u,DivergenceKind.RESOURCE.value,{'reason':'step budget exhausted'}))
        u.actual=actual; u.outcome_class=(OutcomeClass.DIVERGED.value if divergences else OutcomeClass.SUCCESS.value); u.state=UniverseState.DIVERGED.value if divergences else UniverseState.COMPLETED.value
        self._emit('Simulation.Diverged' if divergences else 'Simulation.Completed',u,{'outcome_class':u.outcome_class},severity='high' if divergences else 'normal')
        outcome_body={'outcome_id':_uuid(),'universe_id':u.universe_id,'outcome_class':u.outcome_class,'state':u.state,'steps':actual['steps'],'actual':actual,'divergence_ids':tuple(d['report_id'] for d in divergences),'environment_hash':u.environment_ref['environment_hash']}
        outcome_body['outcome_hash']=_sha({k:v for k,v in outcome_body.items() if k not in {'outcome_id','universe_id'}}); outcome_body['signature']=sign_document(outcome_body,self.signer)
        return SimulationOutcome(**outcome_body)
    def run(self, universe_id:str):
        with self._lock: u=self._universes.get(universe_id)
        if u is None: raise KeyError(universe_id)
        return self.adapters[u.target_class].run(u)
    def step(self, universe_id:str,n:int=1):
        if n<1: raise ValueError('n must be positive')
        u=self._universes[universe_id]; u.target_ref=dict(u.target_ref); u.target_ref['actions']=list(u.target_ref.get('actions',()))[:n]; return self._execute(u)
    def pause(self, universe_id): self._universes[universe_id].state=UniverseState.PAUSED.value; self._emit('Simulation.Paused',self._universes[universe_id])
    def resume(self, universe_id): self._universes[universe_id].state=UniverseState.RUNNING.value; self._emit('Simulation.Resumed',self._universes[universe_id])
    def checkpoint(self, universe_id):
        u=self._universes[universe_id]; cp=Checkpoint(_uuid(),u.universe_id,u.universe_version,u.step_index,_sha({'actual':u.actual,'step':u.step_index}),copy.deepcopy(u.actual)); self._checkpoints[cp.checkpoint_id]=cp; return cp
    def restore(self, checkpoint:Checkpoint):
        if checkpoint.checkpoint_id not in self._checkpoints: raise SimulationReplayError('unknown checkpoint')
        u=self._universes[checkpoint.universe_id]; u.actual=copy.deepcopy(dict(checkpoint.state)); u.step_index=checkpoint.step; u.state=UniverseState.PAUSED.value; return copy.deepcopy(u)
    def cancel(self, universe_id, reason):
        u=self._universes[universe_id]; u.state=UniverseState.CANCELLED.value; u.outcome_class=OutcomeClass.CANCELLED.value; u.finished_at=_now(); self._emit('Simulation.Cancelled',u,{'reason':reason})
    def wait(self, universe_id, timeout=None):
        u=self._universes[universe_id]
        if timeout is not None and timeout<0: raise TimeoutError('invalid timeout')
        if u.state in {UniverseState.PREPARED.value,UniverseState.RUNNING.value,UniverseState.PAUSED.value}: return self.run(universe_id)
        return self.outcome(universe_id)
    def outcome(self, universe_id):
        u=self._universes[universe_id]; actual=u.actual or {}; body={'outcome_id':_uuid(),'universe_id':u.universe_id,'outcome_class':u.outcome_class or OutcomeClass.FAILED.value,'state':u.state,'steps':actual.get('steps',0),'actual':actual,'divergence_ids':tuple(), 'environment_hash':u.environment_ref['environment_hash']}; body['outcome_hash']=_sha({k:v for k,v in body.items() if k not in {'outcome_id','universe_id'}}); body['signature']=sign_document(body,self.signer); return SimulationOutcome(**body)
    def _make_divergence(self,u,kind,detail,severity='high'):
        report={'report_id':_uuid(),'universe_id':u.universe_id,'simulation_outcome_ref':u.universe_id,'expected_ref':u.integrity_hash,'divergence_kind':kind,'detail':detail,'severity':severity,'reproducible':'always','evidence_refs':(), 'recommended_action':'block' if severity=='critical' else 're_simulate','produced_at':_now()}; report['signature']=sign_document(report,self.signer); self._reports[report['report_id']]=DivergenceReport(**report); return report
    def compare(self, simulation_outcome_ref, expected_ref=None):
        u=self._universes.get(simulation_outcome_ref); out=self.outcome(simulation_outcome_ref) if u else None
        if not out: raise KeyError(simulation_outcome_ref)
        expected=u.expected if expected_ref is None else expected_ref; divergences=[]
        if out.outcome_class!=expected.get('expected_outcome','success'): divergences.append(self._make_divergence(u,DivergenceKind.OUTCOME.value,{'expected':expected.get('expected_outcome'),'actual':out.outcome_class}))
        return tuple(self._reports[d['report_id']] for d in divergences)
    def diff_universes(self,a,b):
        da=self._universes[a].to_dict(); db=self._universes[b].to_dict(); return {'changed':{k:(da[k],db[k]) for k in da if da.get(k)!=db.get(k)}}
    def replay(self, universe_id, from_checkpoint_ref=None):
        u=self._universes[universe_id]
        if u.environment_ref['determinism']=='nondeterministic': raise SimulationReplayError('nondeterministic universe is not replayable')
        cp=self._checkpoints[from_checkpoint_ref] if from_checkpoint_ref else None
        if cp: self.restore(cp)
        clone=copy.deepcopy(u); clone.universe_id=_uuid(); clone.signature=''; clone.integrity_hash=''; clone.event_log=[]; clone.actual={}; clone.state=UniverseState.PREPARED.value; clone.outcome_class=None; clone.started_at=None; clone.finished_at=None; clone.step_index=0; self._universes[clone.universe_id]=clone; out=self.run(clone.universe_id)
        original=self.outcome(universe_id); 
        if original.outcome_hash!=out.outcome_hash and u.state in {UniverseState.COMPLETED.value,UniverseState.DIVERGED.value}: self._make_divergence(u,DivergenceKind.NONDETERMINISM.value,{'original':original.outcome_hash,'replay':out.outcome_hash},'critical'); raise SimulationReplayError('deterministic replay divergence')
        return out
    def inject_fault(self, universe_id, fault:Fault):
        fault.validate(); u=self._universes[universe_id]
        if u.fidelity_tier!='adversarial': raise SimulationAuthorizationError('fault injection requires adversarial fidelity')
        cfg=dict(u.adversarial_config or {}); schedule=list(cfg.get('fault_schedule',[])); schedule.append(asdict(fault)); cfg['fault_schedule']=schedule; u.adversarial_config=cfg; u.universe_version+=1; u.integrity_hash=_sha(u.unsigned()); u.signature=sign_document(u.to_dict(),self.signer); return copy.deepcopy(u)
    def set_adversary(self, universe_id, config:AdversarialConfig):
        config.validate(); u=self._universes[universe_id]
        if u.fidelity_tier!='adversarial': raise SimulationAuthorizationError('adversary requires adversarial fidelity')
        u.adversarial_config=asdict(config); u.universe_version+=1; u.integrity_hash=_sha(u.unsigned()); u.signature=sign_document(u.to_dict(),self.signer); return copy.deepcopy(u)
    def emit_verification_evidence(self, universe_id):
        u=self._universes[universe_id]; out=self.outcome(universe_id); evidence={'evidence_id':_uuid(),'universe_id':universe_id,'outcome_hash':out.outcome_hash,'outcome_class':out.outcome_class,'environment_hash':u.environment_ref['environment_hash'],'signed_by':self.key_id}; evidence['integrity_hash']=_sha(evidence); evidence['signature']=sign_document(evidence,self.signer); self._emit('Simulation.VerificationEvidenceEmitted',u,{'evidence_id':evidence['evidence_id']}); return evidence
    def authorization_handoff(self, universe_id):
        u=self._universes[universe_id]; out=self.outcome(universe_id); mandatory=self.mandate_required(u.target_class,u.target_ref.get('effect_class',u.target_ref.get('effects',())))
        return {'simulation_required':mandatory,'authorization_permitted':out.outcome_class==OutcomeClass.SUCCESS.value,'outcome_hash':out.outcome_hash,'waiver_required':out.outcome_class!=OutcomeClass.SUCCESS.value,'universe_id':universe_id}
    def mandate_required(self,target_class,effects=()): return target_class in {'plan','agent','workflow','skill','device_action','system_change'} or bool(set(effects)&MANDATORY_SIMULATION_EFFECTS)
    def isolate_memory_write(self): raise SimulationIsolationError('production memory writes are denied in P2-K')
    def isolate_world_write(self): raise SimulationIsolationError('production World Model writes are denied in P2-K')
    def isolate_cloud_call(self): raise SimulationIsolationError('cloud calls are denied in P2-K')
    def isolate_secret(self): raise SimulationIsolationError('real secret use is denied in P2-K')
    def deprecate_universe(self,universe_id,reason): self._universes[universe_id].actual['deprecated_reason']=reason; self._universes[universe_id].state=UniverseState.CANCELLED.value
    def archive_universe(self,universe_id,storage_ref):
        p=Path(storage_ref); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(self._universes[universe_id].to_dict(),sort_keys=True,default=str),encoding='utf-8'); return str(p)
    def health(self): return {'status':'ready','universes':len(self._universes),'checkpoints':len(self._checkpoints),'reports':len(self._reports),'schema_version':self.SCHEMA_VERSION}

# Public alias chosen to avoid conflict with the historical frontier class.
SimulationUniverseEngine=SimulationEngine

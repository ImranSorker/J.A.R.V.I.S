"""LoRA adapter manager."""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Any, List

logger = logging.getLogger("jarvis.lora")


class LoRAManager:
    def __init__(self, adapter_dir: str = "data/adapters"):
        self.adapter_dir = Path(adapter_dir)
        self.adapter_dir.mkdir(parents=True, exist_ok=True)

    def list_adapters(self) -> List[str]:
        return [p.name for p in self.adapter_dir.glob("*.bin")]

    def load_adapter(self, name: str) -> dict[str, Any]:
        path = self.adapter_dir / name
        if not path.exists():
            return {"ok": False, "error": f"Adapter {name} not found"}
        return {"ok": True, "adapter": str(path)}



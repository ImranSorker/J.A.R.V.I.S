"""Persistent, provenance-aware world model for autonomous JARVIS reasoning."""
from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass(frozen=True)
class WorldEntity:
    """A typed entity observed by JARVIS."""

    entity_id: str
    entity_type: str
    name: str
    properties: dict[str, Any] = field(default_factory=dict)
    source: str = "internal"
    confidence: float = 1.0
    version: int = 1
    observed_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class WorldRelation:
    """A provenance-aware relationship between two entities."""

    source_id: str
    relation: str
    target_id: str
    source: str = "internal"
    confidence: float = 1.0
    observed_at: float = field(default_factory=time.time)


class WorldModel:
    """Thread-safe SQLite-backed world-state store with bounded queries."""

    def __init__(self, db_path: str = "data/world_model.db", max_entities: int = 100_000) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_entities = max(1000, int(max_entities))
        self._lock = threading.RLock()
        self._closed = False
        self._sqlite = sqlite3.connect(self.db_path, check_same_thread=False)
        self._sqlite.execute("PRAGMA journal_mode=WAL")
        self._sqlite.execute(
            "CREATE TABLE IF NOT EXISTS entities ("
            "entity_id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, name TEXT NOT NULL, "
            "properties TEXT NOT NULL, source TEXT NOT NULL, confidence REAL NOT NULL, "
            "version INTEGER NOT NULL, observed_at REAL NOT NULL)"
        )
        self._sqlite.execute(
            "CREATE TABLE IF NOT EXISTS relations ("
            "source_id TEXT NOT NULL, relation TEXT NOT NULL, target_id TEXT NOT NULL, "
            "source TEXT NOT NULL, confidence REAL NOT NULL, observed_at REAL NOT NULL, "
            "PRIMARY KEY(source_id, relation, target_id))"
        )
        self._sqlite.execute(
            "CREATE TABLE IF NOT EXISTS world_events ("
            "event_id TEXT PRIMARY KEY, event_type TEXT NOT NULL, payload TEXT NOT NULL, "
            "source TEXT NOT NULL, created_at REAL NOT NULL)"
        )
        self._sqlite.commit()

    def upsert_entity(self, entity: WorldEntity) -> WorldEntity:
        """Insert or version an entity and evict oldest stale entities when necessary."""
        if not entity.entity_id or not entity.entity_type or not entity.name:
            raise ValueError("entity identity is required")
        if not 0.0 <= float(entity.confidence) <= 1.0:
            raise ValueError("confidence must be between 0 and 1")
        with self._lock:
            row = self._sqlite.execute(
                "SELECT version FROM entities WHERE entity_id=?", (entity.entity_id,)
            ).fetchone()
            version = int(row[0]) + 1 if row else max(1, int(entity.version))
            current = WorldEntity(
                entity.entity_id,
                entity.entity_type,
                entity.name,
                dict(entity.properties),
                entity.source,
                float(entity.confidence),
                version,
                time.time(),
            )
            self._sqlite.execute(
                "INSERT OR REPLACE INTO entities VALUES (?,?,?,?,?,?,?,?)",
                (
                    current.entity_id,
                    current.entity_type,
                    current.name,
                    json.dumps(current.properties, ensure_ascii=False, default=str),
                    current.source,
                    current.confidence,
                    current.version,
                    current.observed_at,
                ),
            )
            count = self._sqlite.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
            excess = max(0, int(count) - self.max_entities)
            if excess:
                self._sqlite.execute(
                    "DELETE FROM entities WHERE entity_id IN "
                    "(SELECT entity_id FROM entities ORDER BY observed_at ASC LIMIT ?)",
                    (excess,),
                )
            self._sqlite.commit()
            return current

    def add_relation(self, relation: WorldRelation) -> None:
        """Store or update a relationship."""
        if not relation.source_id or not relation.relation or not relation.target_id:
            raise ValueError("relation endpoints and name are required")
        with self._lock:
            self._sqlite.execute(
                "INSERT OR REPLACE INTO relations VALUES (?,?,?,?,?,?)",
                (
                    relation.source_id,
                    relation.relation,
                    relation.target_id,
                    relation.source,
                    float(relation.confidence),
                    time.time(),
                ),
            )
            self._sqlite.commit()

    def record_event(self, event_type: str, payload: dict[str, Any], source: str = "internal") -> str:
        """Persist an event that can later explain a world-state change."""
        if not event_type:
            raise ValueError("event_type is required")
        event_id = f"evt_{uuid.uuid4().hex[:16]}"
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        with self._lock:
            self._sqlite.execute(
                "INSERT INTO world_events VALUES (?,?,?,?,?)",
                (event_id, event_type, raw, source, time.time()),
            )
            self._sqlite.commit()
        return event_id

    def get_entity(self, entity_id: str) -> Optional[WorldEntity]:
        """Return one entity."""
        with self._lock:
            row = self._sqlite.execute(
                "SELECT entity_id,entity_type,name,properties,source,confidence,version,observed_at "
                "FROM entities WHERE entity_id=?", (entity_id,)
            ).fetchone()
        if row is None:
            return None
        return WorldEntity(
            row[0], row[1], row[2], json.loads(row[3]), row[4], float(row[5]), int(row[6]), float(row[7])
        )

    def query(self, *, entity_type: Optional[str] = None, name: Optional[str] = None, limit: int = 100) -> list[WorldEntity]:
        """Query entities with a hard result bound."""
        limit = max(1, min(int(limit), 1000))
        clauses: list[str] = []
        params: list[Any] = []
        if entity_type:
            clauses.append("entity_type=?")
            params.append(entity_type)
        if name:
            clauses.append("name LIKE ?")
            params.append(f"%{name}%")
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with self._lock:
            rows = self._sqlite.execute(
                f"SELECT entity_id,entity_type,name,properties,source,confidence,version,observed_at "
                f"FROM entities {where} ORDER BY observed_at DESC LIMIT ?", (*params, limit)
            ).fetchall()
        return [WorldEntity(r[0], r[1], r[2], json.loads(r[3]), r[4], float(r[5]), int(r[6]), float(r[7])) for r in rows]

    def relations_for(self, entity_id: str, limit: int = 100) -> list[WorldRelation]:
        """Return relations touching an entity."""
        limit = max(1, min(int(limit), 1000))
        with self._lock:
            rows = self._sqlite.execute(
                "SELECT source_id,relation,target_id,source,confidence,observed_at FROM relations "
                "WHERE source_id=? OR target_id=? ORDER BY observed_at DESC LIMIT ?",
                (entity_id, entity_id, limit),
            ).fetchall()
        return [WorldRelation(*r) for r in rows]

    def snapshot(self) -> dict[str, Any]:
        """Return a compact integrity-verifiable snapshot."""
        with self._lock:
            entity_count = self._sqlite.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
            relation_count = self._sqlite.execute("SELECT COUNT(*) FROM relations").fetchone()[0]
            event_count = self._sqlite.execute("SELECT COUNT(*) FROM world_events").fetchone()[0]
            rows = self._sqlite.execute(
                "SELECT entity_id,entity_type,name,version,observed_at FROM entities ORDER BY observed_at DESC LIMIT 100"
            ).fetchall()
        payload = {"entities": rows, "relations": relation_count, "events": event_count}
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()
        return {
            "entity_count": int(entity_count),
            "relation_count": int(relation_count),
            "event_count": int(event_count),
            "digest": digest,
        }

    def export_entities(self, limit: int = 10_000) -> list[dict[str, Any]]:
        """Export bounded entity state for diagnostics or backup."""
        return [entity.to_dict() for entity in self.query(limit=limit)]

    def __del__(self) -> None:
        """Best-effort emergency cleanup for garbage-collected instances."""
        try:
            self.close()
        except Exception as exc:
            logging.getLogger("jarvis.lifecycle").debug("best_effort_cleanup_failed", exc_info=exc)

    def close(self) -> None:
        """Close durable resources."""
        with self._lock:
            if self._closed:
                return
            conn = self._sqlite
            self._sqlite = None
            conn.close()
            self._closed = True



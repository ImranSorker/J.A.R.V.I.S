"""Deterministic, capability-aware AION planner.

The planner is deliberately model-independent: it converts a natural-language
objective into an executable mission skeleton without claiming that execution
has already happened.  Richer planners can be adapted behind the same contract.
"""
from __future__ import annotations

import re
import threading
from dataclasses import dataclass, asdict
from typing import Any, Mapping

from core.contracts.autonomy import MissionStepSpec


@dataclass(frozen=True, slots=True)
class PlanStep:
    step_id: str
    name: str
    action: str
    arguments: Mapping[str, Any]
    capability: str
    dependencies: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "arguments": dict(self.arguments), "dependencies": list(self.dependencies)}

    def to_spec(self) -> MissionStepSpec:
        return MissionStepSpec(
            step_id=self.step_id,
            name=self.name,
            dependencies=self.dependencies,
            capability=self.capability,
            metadata={"action": self.action, "arguments": dict(self.arguments)},
        )


@dataclass(frozen=True, slots=True)
class AIONPlan:
    objective: str
    steps: tuple[PlanStep, ...]
    strategy: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "objective": self.objective,
            "strategy": self.strategy,
            "steps": [step.to_dict() for step in self.steps],
        }


class AIONPlanner:
    """Build an executable plan with explicit capabilities and dependencies."""

    def __init__(self, *, max_steps: int = 32) -> None:
        self.max_steps = max(1, min(int(max_steps), 128))
        self._plans: list[AIONPlan] = []
        self._lock = threading.RLock()

    def build(self, goal: str, *, context: Mapping[str, Any] | None = None) -> AIONPlan:
        objective = str(goal or "").strip()
        if not objective:
            raise ValueError("goal is required")
        low = objective.lower()
        steps: list[PlanStep] = []

        if re.search(r"\b(search|find|research|look up)\b", low):
            query = re.sub(r"^.*?\b(?:search|find|research|look up)(?:\s+for)?\s*", "", objective, flags=re.I).strip() or objective
            steps.append(PlanStep("plan.search", "web_search", "tool", {"query": query}, "tool.invoke"))
        elif re.search(r"\bread\b.*\bfile\b|\bfile\b.*\bread\b", low):
            match = re.search(r"\bfile\s+(.+)$", objective, re.I)
            path = match.group(1).strip().strip('\"\'') if match else objective
            steps.append(PlanStep("plan.read_file", "file_read", "tool", {"path": path}, "tool.invoke"))
        elif re.search(r"\b(calculate|compute|math)\b", low):
            expression = re.sub(r"^\s*(?:calculate|compute|math)\s*", "", objective, flags=re.I).strip() or objective
            steps.append(PlanStep("plan.calculate", "calculator", "tool", {"expression": expression}, "tool.invoke"))
        elif re.search(r"\b(list|show)\b.*\b(files|directory|folder)\b", low):
            path = re.sub(r"^.*?\b(?:files|directory|folder)\b", "", objective, flags=re.I).strip() or "."
            steps.append(PlanStep("plan.list_files", "file_list", "tool", {"path": path}, "tool.invoke"))
        else:
            steps.append(PlanStep("plan.agent", "general_agent", "agent", {"task": objective}, "agent.invoke"))

        if not steps:
            raise RuntimeError("planner produced no executable steps")
        if len(steps) > self.max_steps:
            raise RuntimeError("planner exceeded configured step limit")
        plan = AIONPlan(objective=objective, steps=tuple(steps), strategy="deterministic-capability-planning")
        with self._lock:
            self._plans.append(plan)
            if len(self._plans) > 10_000:
                del self._plans[:-10_000]
        return plan

    def plan(self, goal: str) -> list[str]:
        """Compatibility view used by existing AION planner adapters."""
        return [step.name for step in self.build(goal).steps]

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            return {"plans_created": len(self._plans), "max_steps": self.max_steps}

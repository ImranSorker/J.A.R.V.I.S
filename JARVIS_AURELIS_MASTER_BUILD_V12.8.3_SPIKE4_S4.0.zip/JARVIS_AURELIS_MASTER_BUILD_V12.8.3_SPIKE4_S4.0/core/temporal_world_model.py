"""Temporal and causal extension over the shared JARVIS world model."""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class TemporalFact:
    """Fact with an explicit validity interval and provenance."""
    subject: str
    predicate: str
    value: Any
    valid_from: float
    valid_until: float | None = None
    source: str = "unknown"
    confidence: float = 1.0


class TemporalWorldModel:
    """Maintain bounded temporal facts, causal links, and event history."""

    def __init__(self, max_facts: int = 100_000, db_path: str | Path = "data/temporal_world.db") -> None:
        self.max_facts = max(100, min(int(max_facts), 1_000_000))
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._closed = False
        self._sqlite = sqlite3.connect(self.db_path, check_same_thread=False)
        self._sqlite.execute("PRAGMA journal_mode=WAL")
        self._sqlite.execute("CREATE TABLE IF NOT EXISTS facts(subject TEXT NOT NULL,predicate TEXT NOT NULL,value_json TEXT NOT NULL,valid_from REAL NOT NULL,valid_until REAL,source TEXT NOT NULL,confidence REAL NOT NULL)")
        self._sqlite.execute("CREATE TABLE IF NOT EXISTS causes(cause TEXT NOT NULL,effect TEXT NOT NULL,confidence REAL NOT NULL)")
        self._sqlite.execute("CREATE TABLE IF NOT EXISTS events(timestamp REAL NOT NULL,event TEXT NOT NULL,payload_json TEXT NOT NULL)")
        self._sqlite.commit()
        self._lock = threading.RLock()

    def observe(self, subject: str, predicate: str, value: Any, *, source: str = "unknown", confidence: float = 1.0, at: float | None = None) -> TemporalFact:
        """Record a fact, closing the previous fact interval for the same key."""
        now = time.time() if at is None else float(at)
        fact = TemporalFact(str(subject), str(predicate), value, now, None, str(source), max(0.0, min(1.0, float(confidence))))
        with self._lock:
            self._sqlite.execute("UPDATE facts SET valid_until=? WHERE subject=? AND predicate=? AND valid_until IS NULL", (now, fact.subject, fact.predicate))
            self._sqlite.execute("INSERT INTO facts VALUES (?,?,?,?,?,?,?)", (fact.subject, fact.predicate, json.dumps(fact.value, default=str, separators=(",", ":")), fact.valid_from, fact.valid_until, fact.source, fact.confidence))
            self._sqlite.execute("DELETE FROM facts WHERE rowid NOT IN (SELECT rowid FROM facts ORDER BY rowid DESC LIMIT ?)", (self.max_facts,))
            self._sqlite.commit()
        return fact

    def add_cause(self, cause: str, effect: str, *, confidence: float = 1.0) -> None:
        """Record a bounded causal relationship."""
        with self._lock:
            self._sqlite.execute("INSERT INTO causes VALUES (?,?,?)", (str(cause), str(effect), max(0.0, min(1.0, float(confidence)))))
            self._sqlite.execute("DELETE FROM causes WHERE rowid NOT IN (SELECT rowid FROM causes ORDER BY rowid DESC LIMIT ?)", (self.max_facts,))
            self._sqlite.commit()

    def current(self, subject: str | None = None) -> list[TemporalFact]:
        """Return currently valid facts, optionally filtered by subject."""
        now = time.time()
        with self._lock:
            query = "SELECT subject,predicate,value_json,valid_from,valid_until,source,confidence FROM facts WHERE valid_from<=? AND (valid_until IS NULL OR valid_until>?)"
            params: tuple[Any, ...] = (now, now)
            if subject is not None:
                query += " AND subject=?"
                params += (subject,)
            rows = self._sqlite.execute(query, params).fetchall()
            return [TemporalFact(r[0], r[1], json.loads(r[2]), r[3], r[4], r[5], r[6]) for r in rows]

    def history(self, subject: str, predicate: str | None = None) -> list[TemporalFact]:
        """Return historical facts for a subject."""
        with self._lock:
            query = "SELECT subject,predicate,value_json,valid_from,valid_until,source,confidence FROM facts WHERE subject=?"
            params: tuple[Any, ...] = (subject,)
            if predicate is not None:
                query += " AND predicate=?"
                params += (predicate,)
            rows = self._sqlite.execute(query, params).fetchall()
            return [TemporalFact(r[0], r[1], json.loads(r[2]), r[3], r[4], r[5], r[6]) for r in rows]

    def causes_of(self, effect: str) -> list[tuple[str, float]]:
        """Return candidate causes of an effect."""
        with self._lock:
            return [(str(cause), float(confidence)) for cause, _target, confidence in self._sqlite.execute("SELECT cause,effect,confidence FROM causes WHERE effect=?", (effect,)).fetchall()]

    def record_event(self, event: str, payload: dict[str, Any]) -> None:
        """Append a bounded event suitable for replay/diagnostics."""
        with self._lock:
            self._sqlite.execute("INSERT INTO events VALUES (?,?,?)", (time.time(), str(event), json.dumps(payload, default=str, separators=(",", ":"))))
            self._sqlite.execute("DELETE FROM events WHERE rowid NOT IN (SELECT rowid FROM events ORDER BY rowid DESC LIMIT ?)", (self.max_facts,))
            self._sqlite.commit()

    def events(self) -> list[dict[str, Any]]:
        """Return bounded event history for deterministic replay."""
        with self._lock:
            rows = self._sqlite.execute("SELECT timestamp,event,payload_json FROM events ORDER BY timestamp,rowid").fetchall()
            return [{"timestamp": float(r[0]), "event": str(r[1]), "payload": json.loads(r[2])} for r in rows]

    def snapshot(self) -> dict[str, int]:
        """Return temporal-model cardinalities."""
        with self._lock:
            return {"facts": int(self._sqlite.execute("SELECT COUNT(*) FROM facts").fetchone()[0]), "causes": int(self._sqlite.execute("SELECT COUNT(*) FROM causes").fetchone()[0]), "events": int(self._sqlite.execute("SELECT COUNT(*) FROM events").fetchone()[0])}

    def __del__(self) -> None:
        """Best-effort emergency cleanup for garbage-collected instances."""
        try:
            self.close()
        except Exception as exc:
            logging.getLogger("jarvis.lifecycle").debug("best_effort_cleanup_failed", exc_info=exc)

    def close(self) -> None:
        """Close the durable temporal store."""
        with self._lock:
            if self._closed:
                return
            conn = self._sqlite
            self._sqlite = None
            conn.close()
            self._closed = True



"""Virtual Agent + Tool Fabric for J.A.R.V.I.S. 12.8.0.

Agents are logical, persistent objects rather than permanent processes.  The
fabric provides factory, studio, workshop, garage, harness and garbage
collection semantics while enforcing finite physical execution budgets.  This
supports very large dormant agent populations without creating one OS process
per logical agent.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import sqlite3
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from core.schema_validator import SchemaValidationError, SchemaValidator


class AgentFabricError(RuntimeError):
    """Base agent-fabric error."""


class AgentAdmissionDenied(AgentFabricError):
    """Raised when an agent is outside its declared authority or lifecycle."""


class AgentKind(StrEnum):
    """Logical agent sizing tier."""

    NANO = "nano"
    MINI = "mini"
    STANDARD = "standard"
    EXPERT = "expert"
    SOVEREIGN = "sovereign"


class AgentTrustClass(StrEnum):
    """Execution trust classification for agent implementations."""

    TRUSTED_IN_PROCESS = "trusted_in_process"
    UNTRUSTED_SANDBOXED = "untrusted_sandboxed"


class AgentState(StrEnum):
    """Agent lifecycle state."""

    READY = "ready"
    RUNNING = "running"
    HIBERNATED = "hibernated"
    QUARANTINED = "quarantined"
    RETIRED = "retired"


@dataclass(frozen=True, slots=True)
class AgentBudget:
    """Bounded physical execution budget."""

    timeout_seconds: float = 60.0
    max_output_bytes: int = 4 * 1024 * 1024
    max_concurrency: int = 1
    max_children: int = 64

    def validate(self) -> None:
        if not 0.1 <= float(self.timeout_seconds) <= 86_400:
            raise ValueError("timeout_seconds outside policy")
        if not 1_024 <= int(self.max_output_bytes) <= 1_073_741_824:
            raise ValueError("max_output_bytes outside policy")
        if not 1 <= int(self.max_concurrency) <= 256:
            raise ValueError("max_concurrency outside policy")
        if not 0 <= int(self.max_children) <= 10_000:
            raise ValueError("max_children outside policy")


@dataclass(frozen=True, slots=True)
class AgentBlueprint:
    """Declarative logical-agent specification."""

    name: str
    kind: AgentKind
    capabilities: tuple[str, ...]
    tools: tuple[str, ...] = ()
    model_policy: tuple[str, ...] = ()
    budget: AgentBudget = field(default_factory=AgentBudget)
    parent_id: str | None = None
    tags: tuple[str, ...] = ()
    trust_class: AgentTrustClass = AgentTrustClass.TRUSTED_IN_PROCESS

    def normalized(self) -> "AgentBlueprint":
        self.budget.validate()
        name = str(self.name).strip()
        capabilities = tuple(sorted({str(item).strip() for item in self.capabilities if str(item).strip()}))
        tools = tuple(sorted({str(item).strip() for item in self.tools if str(item).strip()}))
        policies = tuple(sorted({str(item).strip() for item in self.model_policy if str(item).strip()}))
        tags = tuple(sorted({str(item).strip() for item in self.tags if str(item).strip()}))
        if not name or not capabilities:
            raise ValueError("agent name and capabilities are required")
        return AgentBlueprint(name, AgentKind(self.kind), capabilities, tools, policies, self.budget, self.parent_id, tags, AgentTrustClass(self.trust_class))


@dataclass(frozen=True, slots=True)
class LogicalAgent:
    """Persisted logical-agent identity and lifecycle state."""

    agent_id: str
    blueprint: AgentBlueprint
    state: AgentState
    created_at: float
    updated_at: float
    generation: int


@dataclass(frozen=True, slots=True)
class AgentExecutionReceipt:
    """Cryptographically verifiable execution outcome."""

    request_id: str
    agent_id: str
    capability: str
    ok: bool
    output_sha256: str
    output_bytes: int
    latency_ms: float
    generation: int
    signature: str


class AgentCallable(Protocol):
    """Callable agent implementation contract."""

    def __call__(self, request: str, context: Mapping[str, Any]) -> Any:
        """Execute one bounded request."""


class AgentFactory:
    """Factory and durable registry for very large logical-agent populations."""

    def __init__(self, registry: str | Path, secret: bytes, *, max_logical_agents: int = 5_000_000) -> None:
        if len(secret) < 32:
            raise ValueError("agent factory secret must contain at least 32 bytes")
        self.registry = Path(registry)
        self.registry.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self._max_logical_agents = max(1, min(int(max_logical_agents), 20_000_000))
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.registry), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS agents(
                agent_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                capabilities TEXT NOT NULL,
                tools TEXT NOT NULL,
                model_policy TEXT NOT NULL,
                budget TEXT NOT NULL,
                parent_id TEXT,
                tags TEXT NOT NULL,
                trust_class TEXT NOT NULL DEFAULT 'trusted_in_process',
                state TEXT NOT NULL,
                generation INTEGER NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_agents_state ON agents(state);
            CREATE INDEX IF NOT EXISTS idx_agents_parent ON agents(parent_id);
            """
        )
        columns = {row[1] for row in self._db.execute("PRAGMA table_info(agents)").fetchall()}
        if "trust_class" not in columns:
            self._db.execute("ALTER TABLE agents ADD COLUMN trust_class TEXT NOT NULL DEFAULT 'trusted_in_process'")
        self._db.commit()

    def create(self, blueprint: AgentBlueprint, *, agent_id: str | None = None) -> LogicalAgent:
        """Create one dormant logical agent without allocating a worker."""
        normalized = blueprint.normalized()
        identifier = str(agent_id or f"agent_{uuid.uuid4().hex}").strip()
        if not identifier or any(ch in identifier for ch in "/\\"):
            raise ValueError("invalid agent_id")
        now = time.time()
        with self._lock:
            count = int(self._db.execute("SELECT COUNT(*) FROM agents").fetchone()[0])
            if count >= self._max_logical_agents:
                raise AgentFabricError("logical agent registry capacity reached")
            if self._db.execute("SELECT 1 FROM agents WHERE agent_id=?", (identifier,)).fetchone() is not None:
                raise ValueError("agent_id already exists")
            self._insert(identifier, normalized, AgentState.READY, 0, now)
        return self.get(identifier)

    def spawn_child(self, parent_id: str, blueprint: AgentBlueprint) -> LogicalAgent:
        """Spawn a child agent with capability attenuation only."""
        parent = self.get(parent_id)
        if parent is None:
            raise KeyError(parent_id)
        normalized = blueprint.normalized()
        if normalized.parent_id not in {None, parent.agent_id}:
            raise AgentAdmissionDenied("child parent mismatch")
        if not set(normalized.capabilities).issubset(set(parent.blueprint.capabilities)):
            raise AgentAdmissionDenied("child capabilities exceed parent authority")
        if not set(normalized.tools).issubset(set(parent.blueprint.tools)):
            raise AgentAdmissionDenied("child tools exceed parent authority")
        with self._lock:
            child_count = int(self._db.execute("SELECT COUNT(*) FROM agents WHERE parent_id=?", (parent_id,)).fetchone()[0])
        if child_count >= parent.blueprint.budget.max_children:
            raise AgentAdmissionDenied("parent child budget exhausted")
        return self.create(AgentBlueprint(normalized.name, normalized.kind, normalized.capabilities, normalized.tools, normalized.model_policy, normalized.budget, parent.agent_id, normalized.tags, normalized.trust_class))

    def _insert(self, agent_id: str, blueprint: AgentBlueprint, state: AgentState, generation: int, timestamp: float) -> None:
        self._db.execute(
            "INSERT INTO agents(agent_id,name,kind,capabilities,tools,model_policy,budget,parent_id,tags,trust_class,state,generation,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                agent_id,
                blueprint.name,
                blueprint.kind.value,
                json.dumps(list(blueprint.capabilities), sort_keys=True),
                json.dumps(list(blueprint.tools), sort_keys=True),
                json.dumps(list(blueprint.model_policy), sort_keys=True),
                json.dumps(asdict(blueprint.budget), sort_keys=True),
                blueprint.parent_id,
                json.dumps(list(blueprint.tags), sort_keys=True),
                blueprint.trust_class.value,
                state.value,
                generation,
                timestamp,
                timestamp,
            ),
        )
        self._db.commit()

    def get(self, agent_id: str) -> LogicalAgent | None:
        with self._lock:
            row = self._db.execute("SELECT agent_id,name,kind,capabilities,tools,model_policy,budget,parent_id,tags,trust_class,state,generation,created_at,updated_at FROM agents WHERE agent_id=?", (str(agent_id),)).fetchone()
        if row is None:
            return None
        blueprint = AgentBlueprint(str(row[1]), AgentKind(str(row[2])), tuple(json.loads(row[3])), tuple(json.loads(row[4])), tuple(json.loads(row[5])), AgentBudget(**json.loads(row[6])), row[7], tuple(json.loads(row[8])), AgentTrustClass(str(row[9])))
        return LogicalAgent(str(row[0]), blueprint, AgentState(str(row[10])), float(row[12]), float(row[13]), int(row[11]))

    def transition(self, agent_id: str, state: AgentState) -> LogicalAgent:
        """Perform an explicit lifecycle transition."""
        allowed: dict[AgentState, set[AgentState]] = {
            AgentState.READY: {AgentState.RUNNING, AgentState.HIBERNATED, AgentState.QUARANTINED, AgentState.RETIRED},
            AgentState.RUNNING: {AgentState.READY, AgentState.HIBERNATED, AgentState.QUARANTINED, AgentState.RETIRED},
            AgentState.HIBERNATED: {AgentState.READY, AgentState.RETIRED},
            AgentState.QUARANTINED: {AgentState.READY, AgentState.RETIRED},
            AgentState.RETIRED: set(),
        }
        current = self.get(agent_id)
        if current is None:
            raise KeyError(agent_id)
        if state not in allowed[current.state]:
            raise AgentAdmissionDenied(f"invalid transition {current.state.value}->{state.value}")
        now = time.time()
        with self._lock:
            self._db.execute("UPDATE agents SET state=?,updated_at=? WHERE agent_id=?", (state.value, now, agent_id))
            self._db.commit()
        return self.get(agent_id)  # type: ignore[return-value]

    def restore_snapshot(self, agent_id: str, blueprint: Mapping[str, Any], state: AgentState, generation: int) -> LogicalAgent:
        """Restore a durable agent record from a validated garage snapshot."""
        payload = dict(blueprint)
        normalized = AgentBlueprint(
            str(payload["name"]),
            AgentKind(str(payload["kind"])),
            tuple(payload.get("capabilities", ())),
            tuple(payload.get("tools", ())),
            tuple(payload.get("model_policy", ())),
            AgentBudget(**dict(payload.get("budget", {}))),
            payload.get("parent_id"),
            tuple(payload.get("tags", ())),
            AgentTrustClass(str(payload.get("trust_class", AgentTrustClass.TRUSTED_IN_PROCESS.value))),
        ).normalized()
        with self._lock:
            current = self.get(agent_id)
            if current is None:
                raise KeyError(agent_id)
            now = time.time()
            self._db.execute(
                "UPDATE agents SET name=?,kind=?,capabilities=?,tools=?,model_policy=?,budget=?,parent_id=?,tags=?,trust_class=?,state=?,generation=?,updated_at=? WHERE agent_id=?",
                (
                    normalized.name, normalized.kind.value, json.dumps(normalized.capabilities), json.dumps(normalized.tools),
                    json.dumps(normalized.model_policy), json.dumps(asdict(normalized.budget)), normalized.parent_id,
                    json.dumps(normalized.tags), normalized.trust_class.value, AgentState(state).value, max(1, int(generation)), now, str(agent_id),
                ),
            )
            self._db.commit()
        restored = self.get(agent_id)
        if restored is None:  # pragma: no cover - row was updated above
            raise KeyError(agent_id)
        return restored

    def list(self, *, state: AgentState | None = None, limit: int = 1000) -> tuple[LogicalAgent, ...]:
        """Return a bounded registry page."""
        bounded = max(1, min(int(limit), 10_000))
        if state is None:
            query, params = "SELECT agent_id FROM agents ORDER BY created_at LIMIT ?", (bounded,)
        else:
            query, params = "SELECT agent_id FROM agents WHERE state=? ORDER BY created_at LIMIT ?", (state.value, bounded)
        with self._lock:
            ids = [str(row[0]) for row in self._db.execute(query, params).fetchall()]
        return tuple(item for item in (self.get(item_id) for item_id in ids) if item is not None)

    def garbage_collect(self, *, older_than_seconds: float = 86_400.0, limit: int = 10_000) -> int:
        """Retire stale hibernated agents while preserving audit identity."""
        cutoff = time.time() - max(60.0, float(older_than_seconds))
        with self._lock:
            rows = self._db.execute("SELECT agent_id FROM agents WHERE state=? AND updated_at<? ORDER BY updated_at LIMIT ?", (AgentState.HIBERNATED.value, cutoff, max(1, min(int(limit), 100_000)))).fetchall()
            ids = [str(row[0]) for row in rows]
            if ids:
                self._db.executemany("UPDATE agents SET state=?,updated_at=? WHERE agent_id=?", [(AgentState.RETIRED.value, time.time(), item) for item in ids])
                self._db.commit()
        return len(ids)

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret logical-agent population statistics."""
        with self._lock:
            total = int(self._db.execute("SELECT COUNT(*) FROM agents").fetchone()[0])
            states = {row[0]: int(row[1]) for row in self._db.execute("SELECT state,COUNT(*) FROM agents GROUP BY state").fetchall()}
        return {"total": total, "max_logical_agents": self._max_logical_agents, "states": states, "registry": str(self.registry)}

    def close(self) -> None:
        """Close the durable registry."""
        with self._lock:
            self._db.commit()
            self._db.close()


class AgentHarness:
    """Uniform execution harness for every logical agent tier."""

    def __init__(self, factory: AgentFactory, secret: bytes, *, max_workers: int = 64) -> None:
        if len(secret) < 32:
            raise ValueError("agent harness secret must contain at least 32 bytes")
        self.factory = factory
        self._secret = bytes(secret)
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(int(max_workers), 256)), thread_name_prefix="jarvis-agent")
        self._semaphores: dict[str, threading.BoundedSemaphore] = {}
        self._lock = threading.RLock()
        self._closed = False

    def execute(self, agent_id: str, capability: str, request: str, implementation: AgentCallable, *, metadata: Mapping[str, Any] | None = None) -> AgentExecutionReceipt:
        """Execute a logical agent through one common bounded harness."""
        agent = self.factory.get(agent_id)
        if agent is None:
            raise KeyError(agent_id)
        if agent.state in {AgentState.HIBERNATED, AgentState.QUARANTINED, AgentState.RETIRED}:
            raise AgentAdmissionDenied(f"agent is not runnable: {agent.state.value}")
        if agent.blueprint.trust_class is AgentTrustClass.UNTRUSTED_SANDBOXED:
            raise AgentAdmissionDenied("untrusted agent implementations must use the isolated execution boundary")
        if capability not in agent.blueprint.capabilities and "*" not in agent.blueprint.capabilities:
            raise AgentAdmissionDenied(f"capability denied: {capability}")
        text = str(request).strip()
        if not text:
            raise ValueError("request is required")
        with self._lock:
            semaphore = self._semaphores.setdefault(agent_id, threading.BoundedSemaphore(agent.blueprint.budget.max_concurrency))
        if not semaphore.acquire(timeout=min(agent.blueprint.budget.timeout_seconds, 60.0)):
            raise TimeoutError("agent concurrency budget exhausted")
        self.factory.transition(agent_id, AgentState.RUNNING)
        request_id = f"req_{uuid.uuid4().hex}"
        started = time.perf_counter()
        cancel_event = threading.Event()
        future: Future[Any] = self._executor.submit(implementation, text, {"request_id": request_id, "agent_id": agent_id, "capability": capability, "generation": agent.generation, "metadata": dict(metadata or {}), "cancel_event": cancel_event, "deadline_monotonic": time.monotonic() + agent.blueprint.budget.timeout_seconds})
        ok = False
        output = ""
        timed_out = False
        try:
            raw = future.result(timeout=agent.blueprint.budget.timeout_seconds)
            output = str(raw)
            if len(output.encode("utf-8")) > agent.blueprint.budget.max_output_bytes:
                raise AgentFabricError("agent output budget exceeded")
            supplied = raw if isinstance(raw, Mapping) else {}
            verified = bool(dict(metadata or {}).get("verified", False)) or bool(supplied.get("verified", False))
            evidence = dict(metadata or {}).get("evidence") or (supplied.get("evidence") if isinstance(supplied, Mapping) else None)
            if not verified or not evidence:
                raise AgentFabricError("agent execution requires verified outcome evidence")
            ok = True
        except TimeoutError:
            timed_out = True
            cancel_event.set()
        except Exception:
            cancel_event.set()
        if timed_out:
            def finalize(_completed: Future[Any]) -> None:
                semaphore.release()
                current = self.factory.get(agent_id)
                if current is not None and current.state == AgentState.RUNNING:
                    self.factory.transition(agent_id, AgentState.READY)
            future.add_done_callback(finalize)
        else:
            semaphore.release()
            current = self.factory.get(agent_id)
            if current is not None and current.state == AgentState.RUNNING:
                self.factory.transition(agent_id, AgentState.READY)
        output_bytes = len(output.encode("utf-8"))
        digest = hashlib.sha256(output.encode("utf-8")).hexdigest()
        canonical = json.dumps({"request_id": request_id, "agent_id": agent_id, "capability": capability, "ok": ok, "output_sha256": digest, "output_bytes": output_bytes, "generation": agent.generation}, sort_keys=True, separators=(",", ":")).encode("utf-8")
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        return AgentExecutionReceipt(request_id, agent_id, capability, ok, digest, output_bytes, (time.perf_counter() - started) * 1000.0, agent.generation, signature)

    def verify(self, receipt: AgentExecutionReceipt) -> bool:
        """Verify a receipt without requiring access to execution state."""
        canonical = json.dumps({"request_id": receipt.request_id, "agent_id": receipt.agent_id, "capability": receipt.capability, "ok": receipt.ok, "output_sha256": receipt.output_sha256, "output_bytes": receipt.output_bytes, "generation": receipt.generation}, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hmac.compare_digest(receipt.signature, hmac.new(self._secret, canonical, hashlib.sha256).hexdigest())

    def close(self) -> None:
        """Close execution workers."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
        self._executor.shutdown(wait=True, cancel_futures=True)


@dataclass(frozen=True, slots=True)
class AgentTeamPlan:
    """Validated fan-out/fan-in agent composition."""

    root_id: str
    child_ids: tuple[str, ...]
    synthesis_agent_id: str | None
    digest: str


class AgentStudio:
    """Composition and architecture authoring surface for agent teams."""

    def __init__(self, factory: AgentFactory) -> None:
        self.factory = factory

    def compose_team(self, root_id: str, child_blueprints: Sequence[AgentBlueprint], synthesis: AgentBlueprint | None = None) -> AgentTeamPlan:
        """Create an attenuated fan-out/fan-in team from one parent."""
        root = self.factory.get(root_id)
        if root is None:
            raise KeyError(root_id)
        child_ids = [self.factory.spawn_child(root_id, blueprint).agent_id for blueprint in child_blueprints]
        synthesis_id = None
        if synthesis is not None:
            synthesis_id = self.factory.spawn_child(root_id, synthesis).agent_id
        digest = hashlib.sha256(json.dumps({"root": root_id, "children": child_ids, "synthesis": synthesis_id}, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return AgentTeamPlan(root_id, tuple(child_ids), synthesis_id, digest)


@dataclass(frozen=True, slots=True)
class WorkshopResult:
    """Agent workshop admission result with auditable gate evidence."""

    agent_id: str
    passed: bool
    stages: tuple[str, ...]
    failures: tuple[str, ...]
    duration_ms: float
    evidence_sha256: str = ""


class AgentWorkshop:
    """Pre-production gate that records every mandatory lifecycle stage."""

    DEFAULT_GATES = (
        "capability-contract", "tool-boundary", "adversarial", "timeout",
        "resource-limit", "crash-recovery", "state-integrity", "permission",
        "deterministic-replay", "evidence-validation",
    )

    def run(self, agent_id: str, *, tests: Mapping[str, Callable[[], bool]], minimum_required: Iterable[str] = ()) -> WorkshopResult:
        """Run named gates and fail closed when any required gate is absent or fails."""
        started = time.perf_counter()
        required = tuple(sorted(set(self.DEFAULT_GATES) | {str(item) for item in minimum_required}))
        passed: list[str] = []
        failures: list[str] = []
        evidence: list[dict[str, Any]] = []
        for name in sorted(tests):
            callback = tests[name]
            try:
                result = bool(callback())
                error = None
            except Exception as exc:
                result = False
                error = f"{type(exc).__name__}: {exc}"
            evidence.append({"gate": str(name), "passed": result, "error": error})
            if result:
                passed.append(str(name))
            else:
                failures.append(str(name))
        missing = [name for name in required if name not in passed]
        failures.extend(missing)
        evidence.extend({"gate": name, "passed": False, "error": "required gate not supplied"} for name in missing)
        digest = hashlib.sha256(json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return WorkshopResult(agent_id, not failures, tuple(sorted(set(passed))), tuple(sorted(set(failures))), (time.perf_counter() - started) * 1000.0, digest)


class AgentGarage:
    """Lifecycle, snapshot, quarantine, promotion and rollback manager."""

    def __init__(self, factory: AgentFactory) -> None:
        self.factory = factory
        self._path = factory.registry.with_suffix(factory.registry.suffix + ".garage.json")
        self._lock = threading.RLock()
        self._mac_key = hmac.new(factory._secret, b"jarvis-garage-state-v1", hashlib.sha256).digest()
        self._state: dict[str, Any] = {}
        if self._path.exists():
            try:
                envelope = json.loads(self._path.read_text(encoding="utf-8"))
                state = envelope.get("state") if isinstance(envelope, dict) else None
                supplied = str(envelope.get("mac", "")) if isinstance(envelope, dict) else ""
                if not isinstance(state, dict) or not supplied:
                    raise AgentAdmissionDenied("garage state is unsigned")
                expected = self._mac(state)
                if not hmac.compare_digest(expected, supplied):
                    raise AgentAdmissionDenied("garage state integrity verification failed")
                self._state = state
            except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
                raise AgentAdmissionDenied("garage state is unreadable or corrupt") from exc

    def _mac(self, state: Mapping[str, Any]) -> str:
        canonical = json.dumps(dict(state), sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return hmac.new(self._mac_key, canonical, hashlib.sha256).hexdigest()

    def _save(self) -> None:
        envelope = {"version": 1, "state": self._state, "mac": self._mac(self._state)}
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(envelope, sort_keys=True, indent=2), encoding="utf-8")
        tmp.replace(self._path)

    def hibernate(self, agent_id: str) -> LogicalAgent:
        return self.factory.transition(agent_id, AgentState.HIBERNATED)

    def wake(self, agent_id: str) -> LogicalAgent:
        return self.factory.transition(agent_id, AgentState.READY)

    def quarantine(self, agent_id: str) -> LogicalAgent:
        return self.factory.transition(agent_id, AgentState.QUARANTINED)

    def retire(self, agent_id: str) -> LogicalAgent:
        return self.factory.transition(agent_id, AgentState.RETIRED)

    def record_workshop(self, result: WorkshopResult) -> None:
        with self._lock:
            self._state.setdefault("certifications", {})[result.agent_id] = {
                "passed": result.passed, "stages": list(result.stages), "failures": list(result.failures),
                "evidence_sha256": result.evidence_sha256, "recorded_at": time.time(),
            }
            self._save()

    def snapshot(self, agent_id: str, label: str = "manual") -> str:
        agent = self.factory.get(agent_id)
        if agent is None:
            raise KeyError(agent_id)
        snapshot_id = f"snap_{uuid.uuid4().hex}"
        with self._lock:
            self._state.setdefault("snapshots", {})[snapshot_id] = {
                "agent_id": agent.agent_id, "label": str(label), "blueprint": asdict(agent.blueprint),
                "state": agent.state.value, "generation": agent.generation, "created_at": time.time(),
            }
            self._save()
        return snapshot_id

    def promote(self, agent_id: str, workshop: WorkshopResult | None = None) -> LogicalAgent:
        with self._lock:
            record = self._state.setdefault("certifications", {}).get(str(agent_id))
        if not record:
            raise AgentAdmissionDenied("promotion requires a recorded workshop certification")
        if workshop is not None:
            if workshop.agent_id != str(agent_id):
                raise AgentAdmissionDenied("workshop certification belongs to a different agent")
            if workshop.evidence_sha256 != str(record.get("evidence_sha256", "")) or workshop.passed != bool(record.get("passed")) or tuple(workshop.failures) != tuple(record.get("failures", ())):
                raise AgentAdmissionDenied("supplied workshop certification does not match the recorded evidence")
        passed = bool(record.get("passed"))
        failures = tuple(record.get("failures", ()))
        if not passed or failures:
            raise AgentAdmissionDenied("promotion gate failed: " + ",".join(str(item) for item in failures))
        self._state.setdefault("promoted", {})[str(agent_id)] = {"evidence_sha256": record.get("evidence_sha256"), "promoted_at": time.time()}
        self._save()
        current = self.factory.get(agent_id)
        if current is None or current.state is not AgentState.READY:
            raise AgentAdmissionDenied("only READY agents may be promoted")
        return current

    def rollback(self, snapshot_id: str) -> LogicalAgent:
        with self._lock:
            record = self._state.get("snapshots", {}).get(str(snapshot_id))
        if not record:
            raise KeyError(snapshot_id)
        agent_id = str(record["agent_id"])
        current = self.factory.get(agent_id)
        if current is None:
            raise KeyError(agent_id)
        snapshot_blueprint = AgentBlueprint(
            str(record["blueprint"]["name"]),
            AgentKind(str(record["blueprint"]["kind"])),
            tuple(record["blueprint"].get("capabilities", ())),
            tuple(record["blueprint"].get("tools", ())),
            tuple(record["blueprint"].get("model_policy", ())),
            AgentBudget(**dict(record["blueprint"].get("budget", {}))),
            record["blueprint"].get("parent_id"),
            tuple(record["blueprint"].get("tags", ())),
            AgentTrustClass(str(record["blueprint"].get("trust_class", AgentTrustClass.TRUSTED_IN_PROCESS.value))),
        ).normalized()
        if not set(snapshot_blueprint.capabilities).issubset(set(current.blueprint.capabilities)):
            raise AgentAdmissionDenied("rollback would broaden agent capabilities")
        if not set(snapshot_blueprint.tools).issubset(set(current.blueprint.tools)):
            raise AgentAdmissionDenied("rollback would broaden agent tools")
        restored = self.factory.restore_snapshot(
            agent_id,
            record["blueprint"],
            AgentState(str(record["state"])),
            int(record["generation"]),
        )
        with self._lock:
            history = self._state.setdefault("rollback_history", [])
            history.append({"snapshot_id": str(snapshot_id), "agent_id": agent_id, "restored_generation": restored.generation, "restored_state": restored.state.value, "rolled_back_at": time.time()})
            self._state["rollback_history"] = history[-4096:]
            self._save()
        return restored


@dataclass(frozen=True, slots=True)
class ToolBlueprint:
    """Dynamic tool specification with optional JSON-Schema boundaries."""

    name: str
    capabilities: tuple[str, ...]
    timeout_seconds: float = 30.0
    max_output_bytes: int = 4 * 1024 * 1024
    input_schema: Mapping[str, Any] | None = None
    output_schema: Mapping[str, Any] | None = None

    def normalized(self) -> "ToolBlueprint":
        timeout = max(0.1, min(float(self.timeout_seconds), 86_400.0))
        output = max(1_024, min(int(self.max_output_bytes), 1_073_741_824))
        name = str(self.name).strip()
        caps = tuple(sorted({str(item).strip() for item in self.capabilities if str(item).strip()}))
        if not name or not caps:
            raise ValueError("tool name and capabilities are required")
        schemas: list[Mapping[str, Any] | None] = []
        for schema in (self.input_schema, self.output_schema):
            if schema is not None:
                candidate = dict(schema)
                SchemaValidator().validate(candidate, {"type": "object"})
            schemas.append(schema)
        return ToolBlueprint(name, caps, timeout, output, schemas[0], schemas[1])


class ToolFabric:
    """Dynamically composed tool-call fabric with bounded execution."""

    def __init__(self, secret: bytes, *, max_workers: int = 64) -> None:
        if len(secret) < 32:
            raise ValueError("tool fabric secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self._tools: dict[str, tuple[ToolBlueprint, Callable[[Mapping[str, Any]], Any], float]] = {}
        self._lock = threading.RLock()
        self._schema_validator = SchemaValidator()
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(int(max_workers), 256)), thread_name_prefix="jarvis-tool")

    def register(self, blueprint: ToolBlueprint, handler: Callable[[Mapping[str, Any]], Any]) -> None:
        """Register a callable tool; generated tools are regular tools after validation."""
        normalized = blueprint.normalized()
        if not callable(handler):
            raise ValueError("tool handler must be callable")
        with self._lock:
            self._tools[normalized.name] = (normalized, handler, time.time())

    def compose(self, name: str, sequence: Sequence[str], *, capabilities: Iterable[str]) -> ToolBlueprint:
        """Compose existing tools into a deterministic sequential composite."""
        steps = tuple(str(item).strip() for item in sequence if str(item).strip())
        if not steps:
            raise ValueError("tool composition requires at least one step")
        with self._lock:
            missing = [item for item in steps if item not in self._tools]
        if missing:
            raise AgentFabricError(f"unknown tools: {', '.join(missing)}")
        blueprint = ToolBlueprint(str(name), tuple(capabilities)).normalized()
        def composite(payload: Mapping[str, Any]) -> Any:
            current: Any = dict(payload)
            for step in steps:
                result = self.execute(step, current, granted_capabilities=blueprint.capabilities)
                if not result["ok"]:
                    return result
                current = result["result"]
            return current
        self.register(blueprint, composite)
        return blueprint

    def execute(self, name: str, payload: Mapping[str, Any], *, granted_capabilities: Iterable[str]) -> dict[str, Any]:
        """Call one registered tool through capability and timeout controls."""
        with self._lock:
            entry = self._tools.get(str(name))
        if entry is None:
            return {"ok": False, "error": "tool_not_found"}
        blueprint, handler, _ = entry
        granted = set(str(item) for item in granted_capabilities)
        if not set(blueprint.capabilities).issubset(granted) and "*" not in granted:
            return {"ok": False, "error": "tool_capability_denied"}
        try:
            if blueprint.input_schema is not None:
                self._schema_validator.validate_or_raise(dict(payload), dict(blueprint.input_schema))
        except SchemaValidationError as exc:
            return {**exc.to_dict(), "ok": False}
        except (TypeError, ValueError) as exc:
            return {"ok": False, "error": f"invalid_tool_input_schema: {exc}"}
        future = self._executor.submit(handler, dict(payload))
        try:
            result = future.result(timeout=blueprint.timeout_seconds)
            text = str(result)
            if len(text.encode("utf-8")) > blueprint.max_output_bytes:
                return {"ok": False, "error": "tool_output_budget_exceeded"}
            try:
                if blueprint.output_schema is not None:
                    self._schema_validator.validate_or_raise(result, dict(blueprint.output_schema))
            except SchemaValidationError as exc:
                return {**exc.to_dict(), "ok": False}
            except (TypeError, ValueError) as exc:
                return {"ok": False, "error": f"invalid_tool_output_schema: {exc}"}
            return {"ok": True, "result": result}
        except TimeoutError:
            future.cancel()
            return {"ok": False, "error": "tool_timeout"}
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        finally:
            with self._lock:
                if name in self._tools:
                    blueprint_now, handler_now, _last = self._tools[name]
                    self._tools[name] = (blueprint_now, handler_now, time.time())

    def garbage_collect(self, *, older_than_seconds: float = 86_400.0) -> tuple[str, ...]:
        """Remove unused dynamically generated tools."""
        cutoff = time.time() - max(60.0, float(older_than_seconds))
        with self._lock:
            retired = tuple(sorted(name for name, (_blueprint, _handler, last_used) in self._tools.items() if last_used < cutoff))
            for name in retired:
                self._tools.pop(name, None)
            return retired

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret tool population state."""
        with self._lock:
            return {"tools": sorted(self._tools), "count": len(self._tools)}

    def close(self) -> None:
        """Close tool workers."""
        self._executor.shutdown(wait=True, cancel_futures=True)

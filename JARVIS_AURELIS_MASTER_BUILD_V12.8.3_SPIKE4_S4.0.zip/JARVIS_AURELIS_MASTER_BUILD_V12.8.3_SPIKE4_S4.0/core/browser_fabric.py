"""Canonical browser destination policy shared by all browser clients."""
from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse

from core.network_policy import NetworkPolicy, SSRFValidator


@dataclass(frozen=True, slots=True)
class BrowserRequest:
    """A browser operation before network policy authorization."""

    action: str
    url: str


class BrowserFabric:
    """Single browser destination authority backed by the SSRF policy."""

    def __init__(self, policy: NetworkPolicy | tuple[str, ...] = NetworkPolicy()) -> None:
        self._policy = policy if isinstance(policy, NetworkPolicy) else NetworkPolicy(allowed_hosts=tuple(policy))
        self._ssrf = SSRFValidator()

    @property
    def policy(self) -> NetworkPolicy:
        """Return the immutable network policy used for browser requests."""
        return self._policy

    def validate(self, request: BrowserRequest) -> bool:
        """Return whether the URL passes scheme, host and SSRF checks."""
        parsed = urlparse(request.url)
        if parsed.scheme.lower() not in {"https", "http"} or not parsed.hostname:
            return False
        return bool(self._ssrf.validate_url(request.url, self._policy).get("ok"))



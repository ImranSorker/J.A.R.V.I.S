"""Observe-act-verify computer-use contract with duplicate-action protection."""
from __future__ import annotations

import hashlib
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ScreenState:
    """Observed screen state with a deterministic fingerprint."""
    width: int
    height: int
    fingerprint: str
    metadata: dict[str, Any]


class ComputerAdapter(Protocol):
    """Concrete desktop adapter contract."""
    def observe(self) -> ScreenState: raise RuntimeError("abstract contract method invoked")
    def act(self, action: str, parameters: dict[str, Any]) -> dict[str, Any]: raise RuntimeError("abstract contract method invoked")
class ComputerUseController:
    """Controller that verifies state before and after every desktop action."""

    def __init__(self, adapter: ComputerAdapter, authority: Any | None = None) -> None:
        self.adapter = adapter
        self.authority = authority
        self._lock = threading.RLock()
        self._last_action_key: str | None = None
        self._consequential_action_keys: set[str] = set()
        self._idempotency_keys: set[str] = set()
        self._max_consequential_keys = 4096

    def authority_context(self, state: ScreenState) -> Any:
        from core.kernel_12_8_0.computer_use import ObservedContext
        return ObservedContext(str(state.metadata.get("application_id", "desktop")), state.metadata.get("origin"), bool(state.metadata.get("verified", True)), state.metadata.get("identity"))

    def observe(self) -> ScreenState:
        """Capture current desktop state."""
        return self.adapter.observe()

    def act_and_verify(self, action: str, parameters: dict[str, Any], *, expected_fingerprint: str | None = None, idempotency_key: str | None = None) -> dict[str, Any]:
        """Perform an action only once per identical state/action tuple and verify result."""
        before = self.adapter.observe()
        decision = None
        if self.authority is not None:
            context = self.authority_context(before)
            decision = self.authority.evaluate(context, str(action), target_url=parameters.get("target_url"), approval=bool(parameters.get("approval", False)))
            if not decision.allowed:
                return {"ok": False, "error": decision.reason, "risk": int(decision.risk), "requires_approval": decision.requires_approval}
        if expected_fingerprint and before.fingerprint != expected_fingerprint:
            return {"ok": False, "error": "screen state changed"}
        key_material = tuple(sorted((str(k), repr(v)) for k, v in parameters.items() if str(k) != "approval"))
        key = hashlib.sha256(f"{before.fingerprint}|{action}|{key_material}".encode()).hexdigest()
        consequential_key = hashlib.sha256(f"{action}|{key_material}".encode()).hexdigest()
        with self._lock:
            if idempotency_key and idempotency_key in self._idempotency_keys:
                return {"ok": False, "error": "duplicate idempotency key suppressed", "idempotency_key": str(idempotency_key)}
            if key == self._last_action_key:
                return {"ok": False, "error": "duplicate action suppressed"}
            if decision is not None and int(decision.risk) >= 3 and consequential_key in self._consequential_action_keys:
                return {"ok": False, "error": "duplicate consequential action suppressed", "risk": int(decision.risk), "requires_approval": decision.requires_approval}
            self._last_action_key = key
        result = self.adapter.act(str(action), dict(parameters))
        after = self.adapter.observe()
        if after.fingerprint == before.fingerprint and not bool(result.get("verified", False)):
            deadline = time.monotonic() + 0.5
            while time.monotonic() < deadline:
                time.sleep(0.02)
                after = self.adapter.observe()
                if after.fingerprint != before.fingerprint:
                    break
        verified = bool(result.get("verified", False))
        verifier = getattr(self.adapter, "verify_action", None)
        if callable(verifier):
            verified = bool(verifier(str(action), dict(parameters), before, after, dict(result)))
        elif after.fingerprint != before.fingerprint:
            verified = True
        if result.get("ok") and idempotency_key:
            with self._lock:
                if len(self._idempotency_keys) >= self._max_consequential_keys:
                    self._idempotency_keys.clear()
                self._idempotency_keys.add(str(idempotency_key))
        if result.get("ok") and decision is not None and int(decision.risk) >= 3:
            with self._lock:
                if len(self._consequential_action_keys) >= self._max_consequential_keys:
                    self._consequential_action_keys.clear()
                self._consequential_action_keys.add(consequential_key)
        if result.get("ok") and not verified:
            return {**result, "ok": False, "error": "action effect could not be verified", "before": before.fingerprint, "after": after.fingerprint, "verified": False}
        return {**result, "before": before.fingerprint, "after": after.fingerprint, "verified": bool(result.get("ok")) and verified}


class PyAutoGUIAdapter:
    """Optional real desktop adapter using pyautogui when explicitly enabled."""

    def __init__(self, pause: float = 0.05) -> None:
        if os.environ.get("JARVIS_COMPUTER_USE_ISOLATED") != "1":
            raise RuntimeError("computer-use requires an explicitly isolated desktop session")
        try:
            import pyautogui  # type: ignore
        except ImportError as exc:
            raise RuntimeError("pyautogui is not installed") from exc
        self._pyautogui = pyautogui
        self._pyautogui.PAUSE = max(0.0, min(float(pause), 1.0))

    def observe(self) -> ScreenState:
        """Capture a deterministic screenshot fingerprint."""
        image = self._pyautogui.screenshot()
        raw = image.tobytes()
        return ScreenState(
            image.width,
            image.height,
            hashlib.sha256(raw).hexdigest(),
            {
                "mode": "desktop",
                "identity": os.environ.get("JARVIS_COMPUTER_USE_IDENTITY"),
                "verified": True,
            },
        )

    def act(self, action: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Execute a narrow allowlist of desktop actions."""
        if action == "click":
            self._pyautogui.click(x=int(parameters["x"]), y=int(parameters["y"]))
        elif action == "type":
            self._pyautogui.write(str(parameters["text"]), interval=float(parameters.get("interval", 0.0)))
        elif action == "press":
            self._pyautogui.press(str(parameters["key"]))
        elif action == "hotkey":
            keys = parameters.get("keys")
            if not isinstance(keys, (list, tuple)) or not keys:
                raise ValueError("hotkey requires a non-empty keys sequence")
            self._pyautogui.hotkey(*(str(k) for k in keys))
        elif action == "scroll":
            self._pyautogui.scroll(int(parameters.get("clicks", 1)))
        else:
            raise ValueError("unsupported computer action")
        return {"ok": True, "action": action}



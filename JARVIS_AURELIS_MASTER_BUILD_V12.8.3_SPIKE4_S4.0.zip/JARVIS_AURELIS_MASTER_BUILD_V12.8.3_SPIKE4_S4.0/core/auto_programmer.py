"""Production-path auto-programming with bounded generation, tests and sandbox execution."""
from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from core.kernel_12_8_0.sandbox import SandboxPolicy, SandboxResult, SecurePythonSandbox
from core.kernel_12_8_0.contracts import CapabilityRequest
from core.kernel_12_8_0.runtime import JarvisKernelRuntime
from core.sandbox_validator import SandboxValidator

logger = logging.getLogger("jarvis.autocoder")


@dataclass(frozen=True, slots=True)
class AutoProgramResult:
    ok: bool
    name: str
    code: str
    validation: Mapping[str, Any]
    tests: tuple[Mapping[str, Any], ...]
    attempts: int
    sandbox: SandboxResult | None
    error: str | None = None


class AutoProgrammer:
    """Generate code through an injected model generator and validate every iteration.

    The model is never granted execution authority. Generated source is first parsed
    and statically filtered, then tested, and only then may run inside the secure
    subprocess sandbox after explicit approval.
    """

    def __init__(self, sandbox_validator: SandboxValidator | None = None, *, model_generator: Callable[[str], str] | None = None, sandbox: SecurePythonSandbox | None = None, max_repair_iterations: int = 3, kernel: JarvisKernelRuntime | None = None) -> None:
        self._validator = sandbox_validator or SandboxValidator()
        self._generator = model_generator
        self._kernel = kernel
        self._sandbox = sandbox or SecurePythonSandbox(SandboxPolicy())
        self._max_repair_iterations = max(1, min(int(max_repair_iterations), 3))
        self._generated_count = 0

    def set_model_generator(self, generator: Callable[[str], str]) -> None:
        if not callable(generator): raise TypeError("model generator must be callable")
        self._generator = generator

    @staticmethod
    def _safe_name(name: str) -> str:
        normalized = re.sub(r"[^a-zA-Z0-9_]", "_", name).strip("_")
        return normalized if normalized and normalized[0].isalpha() else f"generated_tool_{normalized or 'tool'}"

    def _generate(self, prompt: str, name: str) -> str:
        if self._generator is None:
            raise RuntimeError("AutoProgrammer requires an injected model generator")
        code = str(self._generator(prompt))
        if len(code.encode("utf-8")) > 1_000_000: raise ValueError("generated code exceeds input budget")
        return code

    def _validate(self, code: str) -> dict[str, Any]:
        validation = self._validator.validate(code)
        if not validation.get("ok"): return validation
        tree = ast.parse(code, mode="exec")
        forbidden = {"subprocess", "socket", "ctypes", "cffi", "os.system", "os.popen"}
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split(".", 1)[0] in forbidden or alias.name in forbidden:
                        return {"ok": False, "error": f"forbidden import: {alias.name}"}
            if isinstance(node, ast.ImportFrom) and node.module and node.module.split(".", 1)[0] in forbidden:
                return {"ok": False, "error": f"forbidden import: {node.module}"}
        return {**validation, "ast_nodes": len(list(ast.walk(tree)))}

    def _test_generated(self, code: str, name: str) -> tuple[Mapping[str, Any], ...]:
        harness = (
            code
            + "\n"
            + f"_jarvis_result = {name}(sample='regression')\n"
            + "assert isinstance(_jarvis_result, dict)\n"
            + "assert _jarvis_result.get('ok') is True\n"
            + "assert _jarvis_result.get('arguments', {}).get('sample') == 'regression'\n"
            + "print('JARVIS_GENERATED_TEST_PASS')\n"
        )
        if self._kernel is None:
            result = self._sandbox.execute(harness)
        else:
            result = self._kernel.execution.run_python(harness, request=CapabilityRequest("code.sandbox", reason="generated-code validation", risk="low", ttl_seconds=int(self._sandbox.policy.timeout_seconds), principal="autoprogrammer"), approved=False, policy=self._sandbox.policy)
        passed = result.return_code == 0 and not result.timed_out and not result.blocked and "JARVIS_GENERATED_TEST_PASS" in result.stdout
        return ({"passed": passed, "case": "basic_contract", "return_code": result.return_code, "stderr": result.stderr[-500:]},)

    def generate_tool(self, description: str, name: str | None = None) -> dict[str, Any]:
        if not description or len(description) > 10_000: return {"ok": False, "error": "Description empty or too long"}
        tool_name = self._safe_name(name or f"generated_tool_{self._generated_count}"); self._generated_count += 1
        code = ""; validation: dict[str, Any] = {}; tests: tuple[Mapping[str, Any], ...] = (); errors: list[str] = []
        for attempt in range(1, self._max_repair_iterations + 1):
            try:
                code = self._generate(description if attempt == 1 else f"Repair iteration {attempt}: {errors[-1] if errors else 'previous validation failed'}\nOriginal task: {description}", tool_name)
                validation = self._validate(code)
                if not validation.get("ok"): raise ValueError(str(validation.get("error", "validation failed")))
                tests = self._test_generated(code, tool_name)
                if not all(bool(t.get("passed")) for t in tests): raise ValueError("generated regression test failed")
                logger.info("tool_generated", extra={"tool": tool_name, "attempt": attempt})
                return {"ok": True, "name": tool_name, "code": code, "validation": validation, "tests": list(tests), "attempts": attempt, "sandbox_available": True}
            except Exception as exc:
                errors.append(type(exc).__name__ + ": " + str(exc))
                logger.warning("generated_code_iteration_failed", extra={"tool": tool_name, "attempt": attempt, "error": str(exc)})
        return {"ok": False, "name": tool_name, "code": code, "validation": validation, "tests": list(tests), "attempts": self._max_repair_iterations, "error": errors[-1] if errors else "generation_failed"}

    def execute_generated(self, result: Mapping[str, Any], *, approved: bool = False) -> dict[str, Any]:
        if not approved: return {"ok": False, "error": "explicit approval is required before generated code execution"}
        if not result.get("ok") or not isinstance(result.get("code"), str): return {"ok": False, "error": "invalid generated result"}
        if self._kernel is None:
            raise RuntimeError("generated code execution requires the canonical kernel")
        sandbox_result = self._kernel.execution.run_python(str(result["code"]), request=CapabilityRequest("code.execute", reason="approved generated-code execution", risk="high", ttl_seconds=int(self._sandbox.policy.timeout_seconds), principal="autoprogrammer"), approved=True, policy=self._sandbox.policy)
        return {"ok": sandbox_result.return_code == 0 and not sandbox_result.blocked and not sandbox_result.timed_out, "sandbox": sandbox_result}

    def get_stats(self) -> dict[str, Any]:
        return {"generated_count": self._generated_count, "max_repair_iterations": self._max_repair_iterations, "model_generator_configured": self._generator is not None}



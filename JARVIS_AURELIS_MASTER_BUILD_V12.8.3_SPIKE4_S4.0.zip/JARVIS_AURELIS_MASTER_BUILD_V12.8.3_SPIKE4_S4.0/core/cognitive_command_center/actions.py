from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from .models import *


class ActionError(RuntimeError):
    """Raised when a UI action cannot be safely dispatched."""


def _parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class ActionDispatcher:
    """Validate UI actions and forward only through explicit phase bindings."""

    def __init__(self, gateway):
        self.gateway = gateway

    def validate(self, session, action: Mapping[str, Any]):
        for key in (
            "action_id", "action_version", "surface", "action_kind",
            "authorization_level", "tenant_id", "parameters",
            "correlation_id", "requested_at",
        ):
            if key not in action:
                raise ActionError(f"missing action field: {key}")

        if action["tenant_id"] != session.tenant_id:
            raise PermissionError("cross-tenant action refused")
        if action["surface"] not in session.granted_surfaces:
            raise PermissionError("surface not granted to session")

        # Public authority is deliberately confined to HOME read-only.
        if action["authorization_level"] == "public":
            if not (action["surface"] == "HOME" and action["action_kind"] == "read"):
                raise PermissionError("public authorization is restricted to HOME read")

        required = str(action["authorization_level"])
        session_level = str(session.surface_authorizations.get(action["surface"], "public"))
        if AUTH_RANK.get(session_level, -1) < AUTH_RANK.get(required, 99):
            raise PermissionError("session authorization level is insufficient")
        if not set(action.get("scopes_required", [])).issubset(set(session.granted_scopes)):
            raise PermissionError("required scope is missing")

        if required in ("security_authority", "dual_control", "system_wide"):
            token_ref = session.security_authority_token_ref
            if not token_ref or not self.gateway.security_authority.validate_token(
                token_ref,
                operator_ref=session.operator_ref,
                tenant_id=session.tenant_id,
                scope=required,
            ):
                raise PermissionError("Security Authority token invalid")
            if required == "system_wide" and not session.justification_ref:
                raise PermissionError("system-wide justification missing")
            if required in ("dual_control", "system_wide") and not session.dual_control_satisfied:
                raise PermissionError("elevated session prerequisite missing")
            if required in ("security_authority", "dual_control", "system_wide") and self.gateway.security_authority.authorizer:
                if not self.gateway.security_authority.authorize(
                    operator_ref=session.operator_ref,
                    tenant_id=session.tenant_id,
                    operation=f"{action['surface']}:{action['action_kind']}",
                    scopes=tuple(action.get("scopes_required", [])),
                    token_ref=token_ref,
                    justification_ref=session.justification_ref,
                ):
                    raise PermissionError("Security Authority refused action")

        danger = action.get("danger_surface")
        if danger:
            if action.get("confirmation_ref") is None:
                return "confirmation_required"
            rec = self.gateway.confirmations.get(str(action["confirmation_ref"]))
            if not rec or rec.get("action_id") != action["action_id"] or rec.get("tenant_id") != session.tenant_id:
                raise PermissionError("invalid confirmation")
            try:
                expired = _parse_time(str(rec["expires_at"])) <= datetime.now(_parse_time(str(rec["expires_at"])).tzinfo)
            except Exception as exc:
                raise PermissionError("invalid confirmation expiry") from exc
            if expired:
                raise PermissionError("confirmation expired")
            body = {k: v for k, v in rec.items() if k not in ("primary_signature", "second_signature", "integrity_hash")}
            provider = self.gateway.operator_provider
            if not provider or not hasattr(provider, "verify") or not rec.get("primary_signature"):
                raise PermissionError("confirmation signer unavailable")
            if not provider.verify(session.operator_ref["operator_id"], body, str(rec["primary_signature"])):
                raise PermissionError("confirmation signature invalid")
            if required in ("dual_control", "system_wide"):
                second_ref = rec.get("second_operator_ref")
                if not second_ref or not rec.get("second_signature"):
                    raise PermissionError("dual-control confirmation missing")
                second_id = str(second_ref.get("operator_id"))
                if second_id == str(session.operator_ref.get("operator_id")):
                    raise PermissionError("dual-control requires a distinct second operator")
                allowed_tenants = set(second_ref.get("tenant_ids", []))
                if allowed_tenants and session.tenant_id not in allowed_tenants:
                    raise PermissionError("second operator is not authorized for tenant")
                if not provider.verify(second_id, body, str(rec["second_signature"])):
                    raise PermissionError("second operator confirmation signature invalid")
                if self.gateway.security_authority.authorizer and not self.gateway.security_authority.authorize(
                    operator_ref=session.operator_ref, tenant_id=session.tenant_id,
                    operation=f"{action['surface']}:{action['action_kind']}",
                    scopes=tuple(action.get("scopes_required", [])),
                    token_ref=session.security_authority_token_ref,
                    justification_ref=session.justification_ref, second_operator_ref=second_ref):
                    raise PermissionError("Security Authority refused second operator")
            if required == "system_wide" and not rec.get("justification_ref"):
                raise PermissionError("system-wide justification missing")

        return "authorized"

    def forward(self, session, action: Mapping[str, Any]) -> tuple[str, Any]:
        binding = self.gateway.action_bindings.get((action["surface"], action["action_kind"]))
        if not binding:
            raise ActionError("no declared downstream API binding")
        phase, method = binding
        obj = self.gateway.phase_objects.get(phase)
        fn = getattr(obj, method, None) if obj else None
        if fn is None or not callable(fn):
            raise ActionError(f"declared downstream API unavailable: {phase}.{method}")
        params = dict(action.get("parameters", {}))
        params["tenant_id"] = session.tenant_id
        params["operator_ref"] = session.operator_ref
        if action.get("confirmation_ref") is not None:
            params["confirmation_ref"] = str(action["confirmation_ref"])
        if action.get("danger_surface") is not None:
            params["danger_surface"] = str(action["danger_surface"])
        result = fn(**params)
        return f"{phase}.{method}", result

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

from .models import *


class ViewError(RuntimeError):
    """Raised when a declared view cannot be safely sourced or rendered."""


def _redact(value: Any, path: str = "") -> tuple[Any, list[dict[str, str]]]:
    sensitive_tokens = ("password", "token", "secret", "private_key", "api_key", "credential", "authorization")
    redactions: list[dict[str, str]] = []
    if isinstance(value, Mapping):
        out = {}
        for key, item in value.items():
            key_s = str(key)
            child = f"{path}.{key_s}" if path else key_s
            lower = key_s.lower()
            if any(token in lower for token in sensitive_tokens) and not lower.endswith("_ref"):
                out[key_s] = "<redacted>"
                redactions.append({"path": child, "reason": "sensitive_value"})
            else:
                clean, child_redactions = _redact(item, child)
                out[key_s] = clean
                redactions.extend(child_redactions)
        return out, redactions
    if isinstance(value, list):
        out = []
        for index, item in enumerate(value):
            clean, child_redactions = _redact(item, f"{path}[{index}]")
            out.append(clean)
            redactions.extend(child_redactions)
        return out, redactions
    return value, redactions


def _timestamp_from_data(data: Mapping[str, Any], default: str) -> str:
    for key in ("source_timestamp", "updated_at", "computed_at", "timestamp"):
        value = data.get(key)
        if isinstance(value, str):
            return value
    return default


class PhaseReadAdapter:
    """Explicit allow-list binding from surface descriptor to a real phase object and method."""

    def __init__(self, phase_objects: Mapping[str, Any]):
        self.phase_objects = dict(phase_objects)

    def call(self, phase: str, method: str, params: Mapping[str, Any]) -> tuple[Any, str]:
        obj = self.phase_objects.get(phase)
        if obj is None:
            raise ViewError(f"phase unavailable: {phase}")
        fn = getattr(obj, method, None)
        if fn is None or not callable(fn):
            raise ViewError(f"backing API unavailable: {phase}.{method}")
        return fn(**dict(params)), f"{phase}.{method}"


class ViewRenderer:
    def __init__(self, surface_specs: Mapping[str, Mapping[str, Any]], phase_adapter: PhaseReadAdapter, signer, public_key_id: str):
        self.specs = dict(surface_specs)
        self.phase = phase_adapter
        self.signer = signer
        self.public_key_id = public_key_id

    def render(
        self,
        *,
        session,
        surface: str,
        spec: Mapping[str, Any] | None = None,
        view_kind: str = "detail",
        params: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if surface not in self.specs:
            raise ViewError("unknown surface")
        desc = self.specs[surface]
        source = desc["data_sources"][0]
        params = dict(params or {})
        params["tenant_id"] = session.tenant_id
        params["operator_ref"] = session.operator_ref
        data, source_ref = self.phase.call(source["phase"], source["method"], params)
        if not isinstance(data, dict):
            data = {"value": data}
        redacted, redactions = _redact(data)
        now = now_iso()
        source_timestamp = _timestamp_from_data(data, now)
        stale = False
        try:
            dt = datetime.fromisoformat(source_timestamp.replace("Z", "+00:00"))
            stale_after = int((spec or {}).get("stale_after_seconds", 30))
            stale = (datetime.now(timezone.utc) - dt).total_seconds() > max(0, stale_after)
        except Exception:
            stale = True
        model = {
            "view_id": uid(),
            "view_version": 1,
            "surface": surface,
            "tenant_id": session.tenant_id,
            "operator_ref": session.operator_ref,
            "view_kind": view_kind,
            "data": redacted,
            "pagination": None,
            "filters_applied": list((spec or {}).get("filters_applied", [])),
            "computed_at": now,
            "data_freshness": {"source_phase": source["phase"], "source_ref": source_ref, "source_timestamp": source_timestamp},
            "stale": stale,
            "available_actions": [],
            "disabled_actions": [],
            "stream_ref": None,
            "redactions_applied": redactions,
            "produced_by": {"principal": "p2z-gateway", "key_id": self.public_key_id},
            "gateway_version": "12.8.3",
            "registry_state_ref": "jarvis://p2z/registry",
            "policy_version": "1.0.0",
        }
        model["integrity_hash"] = sha(model)
        model["signature"] = sign(model, self.signer)
        return model

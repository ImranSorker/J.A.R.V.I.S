from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import time
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .actions import ActionDispatcher, ActionError
from .audit import AuditLedger
from .client_verification import ClientBundleVerifier, SurfaceVerifier
from .models import *
from .sessions import SessionManager
from .streams import StreamManager
from .views import PhaseReadAdapter, ViewError, ViewRenderer

COMMAND_EVENTS = {
    "SessionOpened", "SessionRefreshed", "SessionClosed", "SessionExpired",
    "ActionReceived", "ActionAuthorized", "ActionDenied", "ActionForwarded", "ActionCompleted", "ActionFailed", "ActionCancelled",
    "ConfirmationRequested", "ConfirmationSupplied", "ConfirmationRejected",
    "ViewRendered", "ViewStale", "ViewRedacted",
    "StreamOpened", "StreamThrottled", "StreamDisconnected", "StreamClosed",
    "ClientBundleVerified", "ClientBundleRefused", "ClientUnsignedRefused",
    "CrossTenantRefused", "ExportRequested", "ExportCompleted", "ReplayDivergence",
}
STREAM_EVENT_TYPES = {
    "event_stream": None,
    "telemetry_stream": "Telemetry",
    "health_stream": "System",
    "security_stream": "Security",
    "recovery_stream": "Recovery",
    "evolution_stream": "Evolution",
    "log_stream": None,
}
SENSITIVE_KEYS = {"password", "token", "secret", "private_key", "api_key", "credential", "authorization", "key"}
logger = logging.getLogger(__name__)


class GatewayError(RuntimeError):
    """Gateway operation error."""


class FailClosed(GatewayError, PermissionError):
    """A gateway operation refused because a required precondition is unverified."""


class ContentStore:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, data: bytes, media_type: str) -> str:
        digest = hashlib.sha256(data).hexdigest()
        p = self.root / digest
        if not p.exists():
            p.write_bytes(data)
        meta = self.root / (digest + ".json")
        meta.write_text(json.dumps({"sha256": digest, "media_type": media_type, "size": len(data)}, sort_keys=True))
        return f"cas://{digest}"


class CognitiveCommandCenterGateway:
    VERSION = "12.8.3"
    KERNEL = "12.8.0"

    def __init__(
        self,
        *,
        root: str | Path = "data/cognitive_command_center",
        phase_objects: Mapping[str, Any] | None = None,
        operator_provider=None,
        security_authority=None,
        provenance=None,
        event_fabric=None,
        storage_secret: bytes | None = None,
        signer: Ed25519PrivateKey | None = None,
        client_verifier: ClientBundleVerifier | None = None,
        trusted_client_attestation_verifier=None,
        surface_attestation_verifier=None,
        surface_verifier: SurfaceVerifier | None = None,
        allowed_origins: tuple[str, ...] = (),
        max_rate_buckets: int = 10000,
        max_records: int = 10000,
        pending_action_ttl_seconds: int = 300,
        max_pending_actions: int = 10000,
    ):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.phase_objects = dict(phase_objects or {})
        self.operator_provider = operator_provider
        self.security_authority = security_authority or SecurityAuthorityAdapter()
        self.provenance = provenance
        self.event_fabric = event_fabric
        self.signer = signer or Ed25519PrivateKey.generate()
        self.key_id = "p2z-gateway-runtime-1"
        if storage_secret is None:
            raise ValueError("storage_secret is required; refusing to derive from a default")
        if len(storage_secret) < 32:
            raise ValueError("storage_secret must be at least 32 bytes")
        self.storage_secret = bytes(storage_secret)
        self.audit = AuditLedger(self.root / "audit.db", self.storage_secret)
        self.content = ContentStore(self.root / "cas")
        self.client_verifier = client_verifier or ClientBundleVerifier(attestation_verifier=trusted_client_attestation_verifier)
        surface_key = Path(__file__).resolve().parent / "keys" / "surface_signing_public.hex"
        self.surface_verifier = surface_verifier or SurfaceVerifier(surface_attestation_verifier, public_key_path=surface_key)
        self.confirmations = ConfirmationStore(key=self.storage_secret, db_path=str(self.root / "confirmations.sqlite3"))
        self._confirmation_lock = threading.RLock()
        self.sessions = SessionManager(self)
        self.streams = StreamManager()
        self.dispatcher = ActionDispatcher(self)
        self.phase_adapter = PhaseReadAdapter(self.phase_objects)
        self.surface_specs = self._load_surfaces()
        self.view_renderer = ViewRenderer(self.surface_specs, self.phase_adapter, self.signer, self.key_id)
        self.action_bindings: dict[tuple[str, str], tuple[str, str] | None] = {}
        if max_rate_buckets <= 0 or max_records <= 0 or pending_action_ttl_seconds <= 0 or max_pending_actions <= 0:
            raise ValueError("gateway state limits must be positive")
        self.max_rate_buckets = int(max_rate_buckets)
        self.max_records = int(max_records)
        self.pending_action_ttl_seconds = int(pending_action_ttl_seconds)
        self.max_pending_actions = int(max_pending_actions)
        self.rate: dict[tuple[str, str, str], list[float | int]] = {}
        self.records: dict[str, dict[str, Any]] = {}
        self.pending_actions: dict[str, dict[str, Any]] = {}
        self.stream_bus_handles: dict[str, Any] = {}
        self.mtls_required = True
        self.allowed_origins = tuple(str(x) for x in allowed_origins)
        self._bind_safe_actions()

    def _load_surfaces(self):
        out = {}
        base = Path(__file__).resolve().parent / "surfaces"
        for name in SURFACES:
            p = base / name / "1.0.0" / "surface.json"
            if p.exists():
                out[name] = json.loads(p.read_text())
        return out

    def _bind_safe_actions(self):
        # These are real downstream API names recovered from the predecessor source inventory.
        self.action_bindings = {
            ("AGENT_GARAGE", "request"): ("P2-D", "deploy"),
            ("AGENT_WORKSHOP", "request"): ("P2-C", "evaluate"),
            ("TASKS", "request"): ("P2-L", "plan"),
            ("SIMULATION", "request"): ("P2-K", "prepare"),
            ("EVOLUTION_LAB", "request"): ("P2-V", "start_experiment"),
            ("SECURITY_SOC", "request"): ("P2-S", "attest"),
            ("SYSTEMS", "request"): ("P2-T", "propose_remediation"),
            ("AGENTS", "request"): ("P2-D", "register_staged"),
            ("SKILLS", "request"): ("P2-F", "register"),
            ("MEMORY_RAG", "request"): ("P2-H", "write"),
            ("MODELS", "request"): ("P2-O", "route"),
            ("ROBOTICS", "request"): ("P2-M", "send"),
            ("DIAGNOSTICS", "request"): ("P2-I", "ingest"),
            ("SETTINGS", "configure"): None,  # handled by gateway-owned operator preferences only
        }

    def _verify_surface(self, surface: str, tenant_id: str) -> None:
        desc = self.surface_specs.get(surface)
        if desc is None:
            raise FailClosed("unknown surface")
        try:
            result = self.surface_verifier.verify(desc, tenant_id=tenant_id)
        except Exception as exc:
            self.emit("CommandCenter.ClientBundleRefused", {"surface": surface, "error": str(exc)}, tenant_id=tenant_id, correlation_id=uid())
            raise FailClosed(f"surface not attested: {surface}") from exc
        self.emit("CommandCenter.ClientBundleVerified", {"surface": surface, "attestation_ref": result["attestation_ref"]}, tenant_id=tenant_id, correlation_id=uid())

    def emit(self, event_name: str, payload: Mapping[str, Any], *, tenant_id: str, correlation_id: str | None = None, causation_id: str | None = None):
        short_name = event_name.split(".", 1)[1] if event_name.startswith("CommandCenter.") else event_name
        if event_name.startswith("CommandCenter.") and short_name not in COMMAND_EVENTS:
            raise GatewayError("unregistered command-center event")
        corr = correlation_id or uid()
        self.audit.append({
            "tenant_id": tenant_id,
            "operator_ref": payload.get("operator_ref", {"operator_id": "system", "tenant_ids": [tenant_id]}),
            "session_id": str(payload.get("session_id", corr)),
            "surface": str(payload.get("surface", "HOME")),
            "action_kind": str(payload.get("action_kind", "read")),
            "action_id": str(payload.get("action_id", corr)),
            "target_ref": payload.get("target_ref"),
            "parameters_hash": sha(payload.get("parameters", {})),
            "authorization_evidence": {"event": event_name},
            "result": {"event": event_name},
            "duration_ms": 0,
            "correlation_id": corr,
            "causation_id": causation_id,
        })
        env = None
        if self.event_fabric is not None:
            try:
                from core.event_fabric import AuthContext, EventEnvelope, ProducedBy
                env = EventEnvelope.create(
                    event_type="CommandCenter",
                    event_name=short_name,
                    payload=dict(payload),
                    produced_by=ProducedBy("system", "p2z-gateway", hashlib.sha256(self.signer.public_key().public_bytes_raw()).hexdigest(), "elevated"),
                    auth_context=AuthContext(str(payload.get("operator_ref", {}).get("operator_id", "system")), tuple(sorted(set(tuple(payload.get("scopes_presented", [])) + ("events.publish.commandcenter",))))),
                    tenant_id=tenant_id,
                    partition_key=tenant_id,
                    correlation_id=corr,
                    causation_id=causation_id,
                    signing_key=self.signer,
                    replayable=True,
                    sensitivity="internal",
                )
                publisher = getattr(self.event_fabric, "publish_envelope", None)
                if not callable(publisher):
                    raise FailClosed("P2-U publish_envelope API unavailable")
                publisher(env)
            except Exception as exc:
                raise FailClosed(f"P2-U event emission failed: {exc}") from exc
        if self.provenance is not None:
            try:
                if env is None:
                    raise FailClosed("P2-X provenance requires signed P2-U event")
                indexer = getattr(self.provenance, "index_event", None)
                if not callable(indexer):
                    raise FailClosed("P2-X index_event API unavailable")
                indexer(env.to_dict())
            except Exception as exc:
                raise FailClosed(f"P2-X provenance recording failed: {exc}") from exc

    @staticmethod
    def _redact_error(exc: BaseException) -> dict[str, str]:
        safe_messages = {
            FailClosed: "request refused",
            PermissionError: "permission denied",
            ValueError: "invalid request",
            KeyError: "resource not found",
        }
        message = "internal error"
        for exc_type, safe_message in safe_messages.items():
            if isinstance(exc, exc_type):
                message = safe_message
                break
        return {"error_class": type(exc).__name__, "message": message}

    @classmethod
    def _redact_audit_value(cls, value: Any, *, key: str | None = None) -> Any:
        if key is not None and key.lower() in SENSITIVE_KEYS:
            return "<redacted>"
        if isinstance(value, Mapping):
            return {str(k): cls._redact_audit_value(v, key=str(k)) for k, v in value.items()}
        if isinstance(value, list):
            return [cls._redact_audit_value(v) for v in value]
        if isinstance(value, tuple):
            return [cls._redact_audit_value(v) for v in value]
        if isinstance(value, str) and len(value) > 2048:
            return value[:2048] + "…"
        return value

    def _prune_rate_buckets(self, now: float) -> None:
        expired = [key for key, bucket in self.rate.items() if now - float(bucket[0]) >= 60]
        for key in expired:
            self.rate.pop(key, None)
        if len(self.rate) >= self.max_rate_buckets:
            oldest_key = min(self.rate, key=lambda key: float(self.rate[key][0]))
            self.rate.pop(oldest_key, None)

    def _rate_limit(self, operator_id: str, surface: str, action_kind: str):
        key = (operator_id, surface, action_kind)
        now = time.monotonic()
        self._prune_rate_buckets(now)
        bucket = self.rate.setdefault(key, [now, 0])
        if now - float(bucket[0]) >= 60:
            bucket[:] = [now, 0]
        bucket[1] = int(bucket[1]) + 1
        if int(bucket[1]) > 120:
            raise FailClosed("gateway rate limit exceeded")

    def _tenant_ok(self, session: Mapping[str, Any], tenant_id: str):
        if str(tenant_id) != str(session["tenant_id"]):
            self.emit("CommandCenter.CrossTenantRefused", {"session_id": session["session_id"], "operator_ref": session["operator_ref"], "surface": "HOME"}, tenant_id=session["tenant_id"], correlation_id=session["session_id"])
            raise FailClosed("cross-tenant access refused")

    def _prune_pending_actions(self) -> None:
        now = datetime.now(timezone.utc)
        expired = []
        for key, item in self.pending_actions.items():
            try:
                created = datetime.fromisoformat(str(item.get("created_at", "")).replace("Z", "+00:00"))
            except (TypeError, ValueError):
                expired.append(key)
                continue
            if (now - created).total_seconds() >= self.pending_action_ttl_seconds:
                expired.append(key)
        for key in expired:
            self.pending_actions.pop(key, None)
        while len(self.pending_actions) > self.max_pending_actions:
            oldest_key = min(self.pending_actions, key=lambda key: str(self.pending_actions[key].get("created_at", "")))
            self.pending_actions.pop(oldest_key, None)

    def _prune_records(self) -> None:
        if len(self.records) <= self.max_records:
            return
        protected = set(self.pending_actions)
        candidates = [
            (str(record.get("created_at", "")), key)
            for key, record in self.records.items()
            if key not in protected
        ]
        candidates.sort()
        for _, key in candidates:
            if len(self.records) <= self.max_records:
                break
            self.records.pop(key, None)

    def _record_action(self, *, session: Mapping[str, Any], action: Mapping[str, Any], outcome: str, result: Mapping[str, Any], forwarded_api: str | None = None, forwarded_at: str | None = None) -> dict[str, Any]:
        self._prune_pending_actions()
        body = {
            "action_id": str(action["action_id"]),
            "session_id": str(session["session_id"]),
            "tenant_id": str(session["tenant_id"]),
            "operator_ref": dict(session["operator_ref"]),
            "surface": str(action["surface"]),
            "action_kind": str(action["action_kind"]),
            "target_ref": action.get("target_ref"),
            "parameters_hash": sha(action.get("parameters", {})),
            "authorization_level": str(action["authorization_level"]),
            "forwarded_api": forwarded_api,
            "forwarded_at": forwarded_at,
            "outcome": outcome,
            "result": self._redact_audit_value(dict(result)),
            "correlation_id": str(action["correlation_id"]),
            "causation_id": action.get("causation_id"),
            "created_at": now_iso(),
        }
        body["integrity_hash"] = sha(body)
        body["signature"] = sign(body, self.signer)
        self.records[str(action["action_id"])] = body
        self._prune_records()
        return body

    def _public_result(self, record: Mapping[str, Any]) -> dict[str, Any]:
        return {"action_id": record["action_id"], "outcome": record["outcome"], "result": record["result"], "forwarded_api": record.get("forwarded_api"), "correlation_id": record["correlation_id"]}

    def open_session(self, *args, **kwargs):
        return self.sessions.open(*args, **kwargs)

    def refresh_session(self, sid):
        return self.sessions.refresh(sid)

    def close_session(self, sid, reason):
        return self.sessions.close(sid, reason)

    def get_session(self, sid):
        return self.sessions.get(sid)

    def _session(self, sid):
        return self.sessions.get(sid)

    def view(self, sid: str, surface: str, view_spec: Mapping[str, Any] | None = None) -> dict[str, Any]:
        s = self._session(sid)
        self._tenant_ok(s, str((view_spec or {}).get("tenant_id", s["tenant_id"])))
        if surface not in s["granted_surfaces"]:
            raise FailClosed("surface not granted to session")
        self._verify_surface(surface, s["tenant_id"])
        v = self.view_renderer.render(session=type("S", (), s)(), surface=surface, spec=view_spec, view_kind=str((view_spec or {}).get("view_kind", "detail")), params=dict((view_spec or {}).get("parameters", {})))
        desc = self.surface_specs[surface]
        available = []
        disabled = []
        session_level = str(s.get("surface_authorizations", {}).get(surface, "public"))
        has_p2x = self.phase_objects.get("P2-X") is not None
        sa_issuer = self.security_authority.issuer is not None
        for kind in desc.get("supported_actions", []):
            enabled = False
            needed = "operator"
            reason = "downstream authorization required"
            if kind == "read":
                enabled, needed, reason = surface == "HOME", "public", ""
                if surface != "HOME":
                    enabled, needed, reason = AUTH_RANK.get(session_level, -1) >= AUTH_RANK["operator_with_scope"], "operator_with_scope", "surface scope required"
            elif kind == "stream":
                enabled, needed, reason = bool(desc.get("supported_streams")) and AUTH_RANK.get(session_level, -1) >= AUTH_RANK["operator_with_scope"], "operator_with_scope", "surface scope required"
            elif kind == "query":
                enabled, needed, reason = bool(has_p2x) and AUTH_RANK.get(session_level, -1) >= AUTH_RANK["operator_with_scope"], "operator_with_scope", "P2-X scope/API required"
            elif kind == "request":
                enabled, needed, reason = (surface, kind) in self.action_bindings and self.action_bindings[(surface, kind)] is not None, "operator", "no declared downstream binding"
                if enabled and AUTH_RANK.get(session_level, -1) < AUTH_RANK[needed]:
                    enabled, reason = False, "session authorization insufficient"
            elif kind == "authorize":
                enabled, needed, reason = sa_issuer, "security_authority", "Security Authority issuer unavailable"
            elif kind == "configure":
                enabled, needed, reason = surface == "SETTINGS", "operator", "configuration is operator-scoped only"
            if enabled:
                available.append({"action_kind": kind, "authorization_level": needed, "enabled": True})
            else:
                disabled.append({"action_kind": kind, "authorization_level": needed, "enabled": False, "reason": reason})
        v["available_actions"] = available
        v["disabled_actions"] = disabled
        v["integrity_hash"] = sha({k: v[k] for k in v if k not in ("signature", "integrity_hash")})
        v["signature"] = sign({k: v[k] for k in v if k != "signature"}, self.signer)
        self.audit.append({
            "tenant_id": s["tenant_id"], "operator_ref": s["operator_ref"], "session_id": sid,
            "surface": surface, "action_kind": "read", "action_id": v["view_id"], "target_ref": None,
            "parameters_hash": sha(view_spec or {}), "authorization_evidence": {"session": sid},
            "result": {"view_hash": v["integrity_hash"]}, "duration_ms": 0, "correlation_id": sid, "causation_id": None,
        })
        self.emit("CommandCenter.ViewRendered", {"session_id": sid, "operator_ref": s["operator_ref"], "surface": surface, "view_id": v["view_id"]}, tenant_id=s["tenant_id"], correlation_id=sid)
        if v["stale"]:
            self.emit("CommandCenter.ViewStale", {"session_id": sid, "surface": surface, "view_id": v["view_id"]}, tenant_id=s["tenant_id"], correlation_id=sid)
        if v["redactions_applied"]:
            self.emit("CommandCenter.ViewRedacted", {"session_id": sid, "surface": surface, "view_id": v["view_id"], "redactions": v["redactions_applied"]}, tenant_id=s["tenant_id"], correlation_id=sid)
        return v

    def _prepare_action(self, sid: str, action: Mapping[str, Any]) -> tuple[Any, dict[str, Any]]:
        sraw = self._session(sid)
        s = type("S", (), sraw)()
        action = dict(action)
        action.setdefault("session_ref", sid)
        action.setdefault("operator_ref", s.operator_ref)
        action.setdefault("scopes_presented", list(s.granted_scopes))
        action.setdefault("tenant_id", s.tenant_id)
        return s, action

    def act(self, sid: str, action: Mapping[str, Any]) -> dict[str, Any]:
        if str(action.get("action_id")) in self.records:
            return self._public_result(self.records[str(action["action_id"])])
        s, action = self._prepare_action(sid, action)
        sraw = {"session_id": s.session_id, "tenant_id": s.tenant_id, "operator_ref": s.operator_ref, "justification_ref": getattr(s, "justification_ref", None), "security_authority_token_ref": getattr(s, "security_authority_token_ref", None)}
        corr = str(action.get("correlation_id", uid()))
        action.setdefault("correlation_id", corr)
        action.setdefault("action_version", 1)
        try:
            self._rate_limit(s.operator_ref["operator_id"], str(action.get("surface")), str(action.get("action_kind")))
            self.emit("CommandCenter.ActionReceived", dict(action), tenant_id=s.tenant_id, correlation_id=corr)
            decision = self.dispatcher.validate(s, action)
            if decision == "confirmation_required":
                rec = {
                    "confirmation_id": uid(), "action_id": str(action["action_id"]), "session_id": sid, "tenant_id": s.tenant_id,
                    "danger_surface": action.get("danger_surface"), "expected_effects": list(action.get("parameters", {}).get("expected_effects", [])),
                    "gates": list(action.get("parameters", {}).get("gates", [])), "simulation_required": bool(action.get("parameters", {}).get("simulation_required", False)),
                    "primary_operator_ref": s.operator_ref, "second_operator_ref": action.get("parameters", {}).get("second_operator_ref"),
                    "justification_ref": sraw.get("justification_ref"), "issued_at": now_iso(),
                    "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat().replace("+00:00", "Z"),
                    "primary_signature": None, "second_signature": None,
                }
                self.confirmations.put(rec)
                self._prune_pending_actions()
                pending = dict(action)
                pending["created_at"] = now_iso()
                self.pending_actions[str(action["action_id"])] = pending
                self._prune_pending_actions()
                self.emit("CommandCenter.ConfirmationRequested", rec, tenant_id=s.tenant_id, correlation_id=corr)
                result = {"action_id": action["action_id"], "outcome": "pending", "confirmation_ref": rec["confirmation_id"]}
                self._record_action(session=sraw, action=action, outcome="pending", result=result)
                return result
            return self._execute_authorized(s, action)
        except Exception as exc:
            logger.exception("command center action denied", extra={"action_id": action.get("action_id"), "correlation_id": corr})
            error = self._redact_error(exc)
            result = {"action_id": action.get("action_id"), "outcome": "denied", "error": error, "correlation_id": corr}
            self._record_action(session=sraw, action=action, outcome="denied", result=result)
            try:
                self.emit("CommandCenter.ActionDenied", {"action_id": action.get("action_id"), "error": error, "operator_ref": s.operator_ref}, tenant_id=s.tenant_id, correlation_id=corr)
            except Exception as emit_error:
                logger.exception("command center action denial audit emission failed", extra={"action_id": action.get("action_id"), "correlation_id": corr})
                result["audit_emit_error"] = self._redact_error(emit_error)
            return result

    def _execute_authorized(self, session, action: Mapping[str, Any]) -> dict[str, Any]:
        sraw = {"session_id": session.session_id, "tenant_id": session.tenant_id, "operator_ref": session.operator_ref}
        self.emit("CommandCenter.ActionAuthorized", action, tenant_id=session.tenant_id, correlation_id=action["correlation_id"])
        if action["action_kind"] == "configure" and action["surface"] == "SETTINGS":
            result = self.set_preference(session.session_id, str(action["parameters"]["key"]), action["parameters"].get("value"))
            api = "P2-Z.operator_preferences"
        else:
            api, result_value = self.dispatcher.forward(session, action)
            result = result_value if isinstance(result_value, dict) else {"value": result_value}
        self.emit("CommandCenter.ActionForwarded", {"action_id": action["action_id"], "forwarded_api": api, "operator_ref": session.operator_ref}, tenant_id=session.tenant_id, correlation_id=action["correlation_id"])
        out = {"action_id": action["action_id"], "outcome": "completed", "result": result, "forwarded_api": api, "correlation_id": action["correlation_id"]}
        self._record_action(session={k: getattr(session, k) for k in ("session_id", "tenant_id", "operator_ref")}, action=action, outcome="completed", result=out, forwarded_api=api, forwarded_at=now_iso())
        self.emit("CommandCenter.ActionCompleted", out, tenant_id=session.tenant_id, correlation_id=action["correlation_id"])
        return out

    def confirm(self, sid: str, action_id: str, confirmation_ref: str) -> dict[str, Any]:
        with self._confirmation_lock:
                    self._prune_pending_actions()
                    sraw = self._session(sid)
                    rec = self.confirmations.get(confirmation_ref)
                    if not rec or rec.get("action_id") != action_id or rec.get("session_id") != sid:
                        self.emit("CommandCenter.ConfirmationRejected", {"action_id": action_id, "confirmation_ref": confirmation_ref}, tenant_id=sraw["tenant_id"], correlation_id=action_id)
                        raise FailClosed("confirmation mismatch")
                    action = self.pending_actions.get(str(action_id))
                    if action is None:
                        raise FailClosed("confirmation has no pending action")
                    if self.operator_provider is None or not hasattr(self.operator_provider, "sign"):
                        raise FailClosed("operator signature adapter unavailable")
                    body = {k: v for k, v in rec.items() if k not in ("primary_signature", "second_signature", "integrity_hash")}
                    rec = dict(rec)
                    rec["primary_signature"] = str(self.operator_provider.sign(sraw["operator_ref"]["operator_id"], body))
                    if rec.get("second_operator_ref") and hasattr(self.operator_provider, "sign"):
                        second_id = str(rec["second_operator_ref"]["operator_id"])
                        try:
                            rec["second_signature"] = str(self.operator_provider.sign(second_id, body))
                        except Exception:
                            rec["second_signature"] = None
                    self.confirmations.put(rec)
                    action = dict(action)
                    action["confirmation_ref"] = confirmation_ref
                    self.emit("CommandCenter.ConfirmationSupplied", rec, tenant_id=sraw["tenant_id"], correlation_id=action_id)
                    self.pending_actions.pop(str(action_id), None)
                    # Do not route through act(): its action-id idempotency would return the pending record.
                    session = type("S", (), sraw)()
                    try:
                        self.dispatcher.validate(session, action)
                        self.confirmations.consume(confirmation_ref)
                        result = self._execute_authorized(session, action)
                        return {"action_id": action_id, "confirmation_ref": confirmation_ref, "outcome": result["outcome"], "action_handle": action_id, "result": result}
                    except Exception as exc:
                        self._record_action(session=sraw, action=action, outcome="denied", result={"error": str(exc)})
                        self.emit("CommandCenter.ConfirmationRejected", {"action_id": action_id, "confirmation_ref": confirmation_ref, "error": str(exc)}, tenant_id=sraw["tenant_id"], correlation_id=action_id)
                        return {"action_id": action_id, "confirmation_ref": confirmation_ref, "outcome": "denied", "error": str(exc)}
    def cancel(self, sid, handle):
        self._prune_pending_actions()
        sraw = self._session(sid)
        key = str(handle)
        pending = self.pending_actions.get(key)
        record = self.records.get(key)
        owner = pending or record
        if owner is not None and (str(owner.get("session_id")) != str(sid) or str(owner.get("tenant_id")) != str(sraw["tenant_id"])):
            self.emit("CommandCenter.CrossTenantRefused", {"session_id": sid, "operator_ref": sraw["operator_ref"], "surface": "HOME", "handle": key}, tenant_id=sraw["tenant_id"], correlation_id=sid)
            return {"action_id": handle, "outcome": "denied", "error": "action is not cancellable"}
        pending = self.pending_actions.pop(key, None)
        if pending is None:
            record = self.records.get(key)
            if not record or record.get("outcome") in ("cancelled", "denied", "completed", "failed"):
                return {"action_id": handle, "outcome": "denied", "error": "action is not cancellable"}
        action = pending or {"action_id": handle, "surface": "HOME", "action_kind": "cancel", "authorization_level": "operator", "parameters": {}, "correlation_id": handle, "target_ref": None}
        out = {"action_id": handle, "outcome": "cancelled", "correlation_id": str(action.get("correlation_id", handle))}
        self._record_action(session=sraw, action=action, outcome="cancelled", result=out)
        self.emit("CommandCenter.ActionCancelled", out, tenant_id=sraw["tenant_id"], correlation_id=out["correlation_id"])
        return out

    def status(self, sid, handle):
        self._prune_pending_actions()
        sraw = self._session(sid)
        key = str(handle)
        record = self.records.get(key)
        pending = self.pending_actions.get(key)
        owner = pending or record
        if owner is not None and (str(owner.get("session_id")) != str(sid) or str(owner.get("tenant_id")) != str(sraw["tenant_id"])):
            self.emit("CommandCenter.CrossTenantRefused", {"session_id": sid, "operator_ref": sraw["operator_ref"], "surface": "HOME", "handle": key}, tenant_id=sraw["tenant_id"], correlation_id=sid)
            return {"action_id": handle, "outcome": "pending"}
        return self._public_result(record) if record is not None else {"action_id": handle, "outcome": "pending"}

    def _stream_allowed(self, session: Mapping[str, Any], kind: str, flt: Mapping[str, Any]) -> None:
        if kind not in STREAM_KINDS:
            raise FailClosed("unsupported stream")
        requested_tenant = str(flt.get("tenant_id", session["tenant_id"]))
        self._tenant_ok(session, requested_tenant)
        if str(flt.get("sensitivity_max", "internal")) == "secret":
            raise FailClosed("secret stream boundary is not exposed through the Command Center")
        surface = str(flt.get("surface", "HOME"))
        if surface not in session["granted_surfaces"]:
            raise FailClosed("stream surface not granted")
        required_scope = f"commandcenter.stream.{kind}"
        if not ("commandcenter.*" in session["granted_scopes"] or required_scope in session["granted_scopes"]):
            raise FailClosed("stream scope missing")

    def stream(self, sid: str, kind: str, flt: Mapping[str, Any]) -> dict[str, Any]:
        s = self._session(sid)
        self._stream_allowed(s, kind, flt)
        bus = getattr(self.event_fabric, "bus", None) if self.event_fabric is not None else None
        if bus is None or not callable(getattr(bus, "subscribe", None)):
            raise FailClosed("P2-U durable stream subscription API unavailable")
        from core.event_fabric import EventFilter, SubscriberContext
        event_type = STREAM_EVENT_TYPES.get(kind)
        topic_prefix = flt.get("topic_prefix")
        correlation_id = flt.get("correlation_id")
        partition_key = flt.get("partition_key")
        event_name = None
        event_names = list(flt.get("event_names", []))
        if kind == "event_stream" and event_names and all(str(name) in COMMAND_EVENTS for name in event_names):
            event_type = "CommandCenter"
        if kind == "event_stream" and topic_prefix and str(topic_prefix).startswith("CommandCenter"):
            event_type = "CommandCenter"
        if len(event_names) > 1:
            raise FailClosed("stream filter supports one exact event_name per subscription")
        if event_names:
            event_name = str(event_names[0])
        subscriber = SubscriberContext(
            principal=s["operator_ref"]["operator_id"], scopes=tuple(s["granted_scopes"]), tenant_id=s["tenant_id"],
            trust_level="elevated" if AUTH_RANK.get(s["surface_authorizations"].get("HOME", "public"), 0) >= AUTH_RANK["security_authority"] else "standard",
            allow_restricted=kind in ("security_stream", "recovery_stream") and ("commandcenter.*" in s["granted_scopes"]),
        )
        event_filter = EventFilter(
            tenant_id=s["tenant_id"], event_type=event_type, event_name=event_name, topic_prefix=topic_prefix,
            partition_key=partition_key, correlation_id=correlation_id, sensitivity=flt.get("sensitivity_max"), subscriber=subscriber,
        )
        stream_ref = None
        def handler(event):
            payload = event.to_dict() if hasattr(event, "to_dict") else dict(event)
            payload = self._redact_stream_payload(payload)
            pushed = self.streams.push(stream_ref, payload)
            if not pushed:
                self.emit("CommandCenter.StreamThrottled", {"stream_id": stream_ref, "tenant_id": s["tenant_id"]}, tenant_id=s["tenant_id"], correlation_id=stream_ref)

        handle = bus.subscribe(event_filter, handler, delivery_mode="exactly_once_ordered", subscriber=subscriber)
        st = self.streams.open(sid, s["tenant_id"], kind, dict(flt), bus_handle=handle)
        stream_ref = st.stream_id
        self.stream_bus_handles[stream_ref] = handle
        self.emit("CommandCenter.StreamOpened", {"session_id": sid, "stream_id": st.stream_id, "stream_kind": kind}, tenant_id=s["tenant_id"], correlation_id=st.stream_id)
        return {"stream_id": st.stream_id, "outcome": "streaming"}

    @staticmethod
    def _redact_stream_payload(value: Any):
        if isinstance(value, dict):
            out = {}
            for k, v in value.items():
                if any(x in str(k).lower() for x in SENSITIVE_KEYS) and not str(k).lower().endswith("_ref"):
                    out[k] = "<redacted>"
                else:
                    out[k] = CognitiveCommandCenterGateway._redact_stream_payload(v)
            return out
        if isinstance(value, list):
            return [CognitiveCommandCenterGateway._redact_stream_payload(v) for v in value]
        return value

    def pause_stream(self, stream_id):
        return {"stream_id": stream_id, "paused": True}

    def resume_stream(self, stream_id):
        return {"stream_id": stream_id, "paused": False}

    def close_stream(self, stream_id):
        s = self.streams.items.get(stream_id)
        if not s:
            raise FailClosed("stream not found")
        self.streams.close(stream_id, unsubscribe=getattr(getattr(self.event_fabric, "bus", None), "unsubscribe", None))
        self.emit("CommandCenter.StreamClosed", {"stream_id": stream_id, "session_id": s.session_id}, tenant_id=s.tenant_id, correlation_id=stream_id)
        self.stream_bus_handles.pop(stream_id, None)
        return {"stream_id": stream_id, "closed": True}

    def poll_stream(self, sid: str, stream_id: str, limit: int = 20):
        s = self._session(sid)
        st = self.streams.items.get(stream_id)
        if not st or st.session_id != sid or st.tenant_id != s["tenant_id"]:
            raise FailClosed("stream session mismatch")
        return {"stream_id": stream_id, "messages": self.streams.poll(stream_id, limit)}

    def query(self, sid, query_spec):
        s = self._session(sid)
        obj = self.phase_objects.get("P2-X")
        if obj is None:
            raise FailClosed("P2-X query API unavailable")
        from core.provenance_graph import GraphQuery
        qd = dict(query_spec or {})
        qd.setdefault("query_id", uid())
        qd.setdefault("tenant_id", s["tenant_id"])
        qd.setdefault("requested_by", {"principal": s["operator_ref"]["operator_id"], "key_id": self.key_id})
        qd.setdefault("requested_at", now_iso())
        if not qd.get("signature") and hasattr(obj, "sign_query"):
            q = obj.sign_query(GraphQuery(**qd), self.signer)
        else:
            q = GraphQuery(**qd)
        return obj.query(q)

    def export(self, sid, target_ref, fmt):
        s = self._session(sid)
        if str(target_ref).startswith("cas://"):
            uri = str(target_ref)
        else:
            raise FailClosed("export requires an existing content-addressed target_ref; gateway will not invent state")
        self.emit("CommandCenter.ExportRequested", {"session_id": sid, "target_ref": target_ref}, tenant_id=s["tenant_id"], correlation_id=sid)
        self.emit("CommandCenter.ExportCompleted", {"session_id": sid, "target_ref": target_ref, "content_uri": uri, "format": fmt}, tenant_id=s["tenant_id"], correlation_id=sid)
        return uri

    def history(self, sid, filter=None):
        s = self._session(sid)
        return self.audit.query(s["tenant_id"], int((filter or {}).get("limit", 100)))

    def request_authorization(self, sid, action_id, justification):
        s = self._session(sid)
        ref = self.security_authority.request(operator_ref=s["operator_ref"], tenant_id=s["tenant_id"], action_id=action_id, justification=justification)
        return {"action_id": action_id, "authorization_request": ref, "outcome": "pending"}

    def attach_authorization(self, sid, action_id, token_ref):
        s = self._session(sid)
        token = token_ref
        if isinstance(token_ref, Mapping):
            value = str(token_ref.get("token_ref", ""))
            justification = token_ref.get("justification_ref")
            if justification:
                s["justification_ref"] = str(justification)
            if token_ref.get("dual_control_satisfied"):
                s["dual_control_satisfied"] = True
            token = value
        if not token:
            raise FailClosed("authorization token reference missing")
        s["security_authority_token_ref"] = str(token)
        self.sessions.sessions[sid] = s
        return {"action_id": action_id, "token_ref": str(token), "justification_ref": s.get("justification_ref")}

    def explain_action(self, action_id):
        return self.records.get(action_id, {"action_id": action_id, "outcome": "unknown"})

    def provenance_of_action(self, action_id):
        obj = self.phase_objects.get("P2-X")
        if obj is None:
            raise FailClosed("P2-X provenance API unavailable")
        fn = getattr(obj, "provenance_of", None)
        if not callable(fn):
            raise FailClosed("P2-X provenance query API unavailable")
        return fn(action_id)

    def set_preference(self, sid, key, value):
        s = self._session(sid)
        if not isinstance(key, str) or not key or len(key) > 100:
            raise FailClosed("invalid preference key")
        p = self.root / "preferences.json"
        data = json.loads(p.read_text()) if p.exists() else {}
        data.setdefault(s["tenant_id"], {}).setdefault(s["operator_ref"]["operator_id"], {})[key] = value
        p.write_text(json.dumps(data, sort_keys=True, indent=2))
        return {"key": key, "value": value}

    def get_preference(self, sid, key):
        s = self._session(sid)
        p = self.root / "preferences.json"
        data = json.loads(p.read_text()) if p.exists() else {}
        return data.get(s["tenant_id"], {}).get(s["operator_ref"]["operator_id"], {}).get(key)

    def health(self):
        return {"status": "ok", "version": self.VERSION, "kernel": self.KERNEL, "mtls_required": self.mtls_required, "surfaces": len(self.surface_specs), "flutter_tooling": "blocked"}

    def ready(self):
        bus_ready = getattr(self.event_fabric, "bus", None) is not None if self.event_fabric is not None else False
        return {
            "ready": bool(self.surface_specs) and self.mtls_required and bus_ready,
            "authority_configured": self.security_authority.authorizer is not None or self.security_authority.validator is not None,
            "p2u_stream_source": bool(bus_ready),
            "phase_bindings": len(self.phase_objects),
        }

    def close(self):
        for stream_id in list(self.streams.items):
            try:
                self.close_stream(stream_id)
            except Exception as close_error:
                _ = close_error
        self.confirmations.close()
        self.audit.close()


def create_app(gateway: CognitiveCommandCenterGateway):
    from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
    from starlette.responses import JSONResponse
    from starlette.middleware.cors import CORSMiddleware

    app = FastAPI(title="J.A.R.V.I.S. Cognitive Command Center Gateway", version="12.8.3", docs_url=None, redoc_url=None)
    if gateway.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(gateway.allowed_origins),
            allow_credentials=False,
            allow_methods=["GET", "POST", "OPTIONS"],
            allow_headers=["content-type", "x-jarvis-session", "x-jarvis-mtls-verified"],
        )

    @app.middleware("http")
    async def harden(request: Request, call_next):
        if request.url.path not in ("/health", "/ready") and gateway.mtls_required and request.headers.get("x-jarvis-mtls-verified") != "true":
            return JSONResponse({"detail": "mTLS client verification required"}, status_code=421)
        response = await call_next(request)
        response.headers["Content-Security-Policy"] = "default-src 'none'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'"
        if hasattr(response, "body") and response.body is not None:
            digest = hashlib.sha256(response.body).hexdigest()
            response.headers["X-JARVIS-Gateway-Integrity"] = digest
            response.headers["X-JARVIS-Gateway-Signature"] = base64.b64encode(gateway.signer.sign(response.body)).decode("ascii")
            response.headers["X-JARVIS-Gateway-Key-Id"] = gateway.key_id
        return response

    @app.get("/health")
    async def health(): return gateway.health()
    @app.get("/ready")
    async def ready(): return gateway.ready()
    @app.post("/v1/session")
    async def open_session(body: dict[str, Any]):
        try:
            return gateway.open_session(body.get("auth_credentials", {}), body["tenant_id"], body["client_bundle"], user_agent=body.get("user_agent", ""), device_fingerprint=body.get("device_fingerprint", ""))
        except Exception as exc:
            logger.exception("command center session open failed")
            raise HTTPException(403, "session opening failed")
    @app.post("/v1/session/refresh")
    async def refresh_session(body: dict[str, Any]): return gateway.refresh_session(body["session_id"])
    @app.post("/v1/session/close")
    async def close_session(body: dict[str, Any]): return gateway.close_session(body["session_id"], body.get("reason", "operator"))
    @app.get("/v1/session/{sid}")
    async def get_session(sid: str): return gateway.get_session(sid)
    @app.post("/v1/view")
    async def view(body: dict[str, Any]): return gateway.view(body["session_id"], body["surface"], body.get("view_spec"))
    @app.post("/v1/action")
    async def act(body: dict[str, Any]): return gateway.act(body["session_id"], body["action"])
    @app.post("/v1/action/confirm")
    async def confirm(body: dict[str, Any]): return gateway.confirm(body["session_id"], body["action_id"], body["confirmation_ref"])
    @app.post("/v1/action/cancel")
    async def cancel(body: dict[str, Any]): return gateway.cancel(body["session_id"], body["action_handle"])
    @app.get("/v1/action/{sid}/{handle}")
    async def status(sid: str, handle: str): return gateway.status(sid, handle)
    @app.post("/v1/stream")
    async def stream(body: dict[str, Any]): return gateway.stream(body["session_id"], body["stream_kind"], body.get("filter", {}))
    @app.get("/v1/stream/{sid}/{stream_id}")
    async def poll_stream(sid: str, stream_id: str, limit: int = 20): return gateway.poll_stream(sid, stream_id, limit)
    @app.post("/v1/stream/close")
    async def close_stream(body: dict[str, Any]): return gateway.close_stream(body["stream_id"])
    @app.websocket("/v1/stream/ws/{sid}/{stream_id}")
    async def websocket_stream(ws: WebSocket, sid: str, stream_id: str):
        if gateway.mtls_required and ws.headers.get("x-jarvis-mtls-verified") != "true":
            await ws.close(code=4403)
            return
        await ws.accept()
        try:
            while True:
                gateway._session(sid)
                st = gateway.streams.items.get(stream_id)
                if not st or not st.active or st.session_id != sid:
                    await ws.close(code=1000)
                    return
                messages = gateway.streams.poll(stream_id, 20)
                for message in messages:
                    await ws.send_json(message)
                await asyncio.sleep(0.2)
        except WebSocketDisconnect:
            s = gateway.streams.items.get(stream_id)
            if s:
                gateway.emit("CommandCenter.StreamDisconnected", {"stream_id": stream_id, "session_id": sid}, tenant_id=s.tenant_id, correlation_id=stream_id)
        except Exception:
            try:
                await ws.close(code=1011)
            finally:
                s = gateway.streams.items.get(stream_id)
                if s:
                    gateway.emit("CommandCenter.StreamDisconnected", {"stream_id": stream_id, "session_id": sid}, tenant_id=s.tenant_id, correlation_id=stream_id)
    @app.post("/v1/query")
    async def query(body: dict[str, Any]): return gateway.query(body["session_id"], body["query_spec"])
    @app.post("/v1/export")
    async def export(body: dict[str, Any]): return gateway.export(body["session_id"], body["target_ref"], body.get("format", "json"))
    @app.get("/v1/history/{sid}")
    async def history(sid: str, limit: int = 100): return gateway.history(sid, {"limit": limit})
    @app.post("/v1/authorization/request")
    async def request_authorization(body: dict[str, Any]): return gateway.request_authorization(body["session_id"], body["action_id"], body["justification"])
    @app.post("/v1/authorization/attach")
    async def attach_authorization(body: dict[str, Any]): return gateway.attach_authorization(body["session_id"], body["action_id"], body["token_ref"])
    return app

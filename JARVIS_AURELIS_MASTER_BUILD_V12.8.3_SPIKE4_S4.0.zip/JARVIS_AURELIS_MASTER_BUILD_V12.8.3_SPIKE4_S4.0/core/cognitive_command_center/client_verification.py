from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from typing import Any, Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from core.kernel_12_8_0.canonical import canonical_json
from .models import sha


class ClientVerificationError(PermissionError):
    """Raised when an unsigned, unverifiable, or unattested client is presented."""


class SurfaceVerificationError(PermissionError):
    """Raised when a Command Center surface artifact is not verifiably attested."""


class ClientBundleVerifier:
    def __init__(self, *, attestation_verifier=None):
        self.attestation_verifier = attestation_verifier

    def bundle_hash(self, bundle: bytes) -> str:
        return hashlib.sha256(bundle).hexdigest()

    def verify(self, manifest: Mapping[str, Any], *, bundle_hash: str | None = None, bundle_bytes: bytes | None = None, tenant_id: str) -> dict[str, Any]:
        if bundle_bytes is not None:
            bundle_hash = self.bundle_hash(bundle_bytes)
        if not bundle_hash:
            raise ClientVerificationError("client bundle bytes/hash unavailable")
        if str(manifest.get("bundle_hash")) != bundle_hash:
            raise ClientVerificationError("client bundle integrity mismatch")
        if str(manifest.get("signature_status")) != "SIGNED":
            raise ClientVerificationError("unsigned client bundle refused")
        pub = manifest.get("public_key")
        sig = manifest.get("signature")
        if not pub or not sig:
            raise ClientVerificationError("client bundle signature missing")
        body = dict(manifest)
        body.pop("signature", None)
        try:
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(str(pub))).verify(
                base64.b64decode(str(sig)), canonical_json(body)
            )
        except Exception as exc:
            raise ClientVerificationError("client bundle signature verification failed") from exc
        att = str(manifest.get("client_attestation_ref", ""))
        if not att or self.attestation_verifier is None or not self.attestation_verifier(manifest, tenant_id):
            raise ClientVerificationError("client bundle attestation unavailable or invalid")
        return {"verified": True, "client_bundle_hash": bundle_hash, "client_attestation_ref": att}


class SurfaceVerifier:
    def __init__(self, attestation_verifier=None, public_key_path: str | Path | None = None):
        self.attestation_verifier = attestation_verifier
        self.public_key_path = Path(public_key_path) if public_key_path else None
        self._public_key = None
        if self.public_key_path and self.public_key_path.exists():
            self._public_key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(self.public_key_path.read_text().strip()))

    def verify(self, artifact: Mapping[str, Any], *, tenant_id: str) -> dict[str, Any]:
        signature = str(artifact.get("signature", ""))
        if not signature or self._public_key is None:
            raise SurfaceVerificationError("surface signature unavailable")
        body = dict(artifact)
        body.pop("signature", None)
        expected_hash = sha({k: v for k, v in body.items() if k != "integrity_hash"})
        if str(body.get("integrity_hash")) != expected_hash:
            raise SurfaceVerificationError("surface integrity hash mismatch")
        try:
            self._public_key.verify(base64.b64decode(signature), canonical_json(body))
        except Exception as exc:
            raise SurfaceVerificationError("surface signature verification failed") from exc
        attestation_ref = str(artifact.get("attested_by", ""))
        if not attestation_ref:
            raise SurfaceVerificationError("surface P2-S attestation missing")
        if self.attestation_verifier is None or not self.attestation_verifier(artifact, tenant_id):
            raise SurfaceVerificationError("surface P2-S attestation unavailable or invalid")
        return {"verified": True, "attestation_ref": attestation_ref, "surface_id": artifact.get("surface_id")}

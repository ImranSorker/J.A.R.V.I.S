from __future__ import annotations

import base64, hashlib, hmac, json, sqlite3, threading, time, uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Mapping
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from core.kernel_12_8_0.canonical import canonical_json

SURFACES = ("HOME","COGNITIVE_ASSISTANT","WORLD_MODEL","TASKS","AGENTS","AGENT_WORKSHOP","AGENT_GARAGE","SKILLS","MEMORY_RAG","MODELS","SIMULATION","EVOLUTION_LAB","SECURITY_SOC","SYSTEMS","ROBOTICS","TELEMETRY","DIAGNOSTICS","SETTINGS")
ACTION_KINDS = ("read","stream","query","request","authorize","confirm","cancel","escalate","export","configure")
AUTH_LEVELS = ("public","operator","operator_with_scope","security_authority","dual_control","system_wide")
STREAM_KINDS = ("event_stream","telemetry_stream","log_stream","health_stream","security_stream","recovery_stream","evolution_stream")
OUTCOMES = ("accepted","pending","completed","denied","failed","cancelled","expired","escalated","diverged","streaming")
DANGERS = ("destructive","financial","identity","device","communication","irreversible")
AUTH_RANK = {x:i for i,x in enumerate(AUTH_LEVELS)}
SENSITIVITY_RANK = {"public":0,"internal":1,"restricted":2,"secret":3}

def now_iso() -> str: return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")
def uid() -> str: return str(uuid.uuid4())
def sha(value: Any) -> str: return hashlib.sha256(canonical_json(value)).hexdigest()
def sign(value: Mapping[str, Any], key: Ed25519PrivateKey) -> str: return base64.b64encode(key.sign(canonical_json(value))).decode("ascii")
def verify(value: Mapping[str, Any], signature: str, key: Ed25519PublicKey) -> bool:
    try: key.verify(base64.b64decode(signature.encode("ascii")), canonical_json(value)); return True
    except Exception: return False

def identity_ref(op: Mapping[str,Any]) -> dict[str,Any]:
    return {"operator_id":str(op["operator_id"]),"tenant_ids":list(op.get("tenant_ids",[]))}

@dataclass(frozen=True, slots=True)
class OperatorIdentity:
    operator_id: str
    tenant_ids: tuple[str,...]
    scopes: tuple[str,...]
    display_name: str
    authn_methods: tuple[str,...]
    security_authority_ref: str
    status: str = "active"
    identity_version: str = "1.0.0"
    signature: str = ""
    integrity_hash: str = ""
    def document(self) -> dict[str,Any]: return asdict(self)

@dataclass(frozen=True, slots=True)
class OperatorSession:
    session_id: str
    session_version: int
    operator_ref: dict[str,Any]
    tenant_id: str
    authentication_method: str
    authentication_ref: str
    authenticated_at: str
    expires_at: str
    granted_scopes: tuple[str,...]
    granted_surfaces: tuple[str,...]
    surface_authorizations: dict[str,str]
    client_bundle_ref: str
    client_bundle_hash: str
    client_attestation_ref: str
    user_agent: str
    device_fingerprint: str
    dual_control_satisfied: bool
    security_authority_token_ref: str|None
    justification_ref: str|None
    created_at: str
    created_by: dict[str,str]
    signature: str = ""
    integrity_hash: str = ""
    def document(self):
        d=asdict(self); d["granted_scopes"]=list(self.granted_scopes); d["granted_surfaces"]=list(self.granted_surfaces); return d

@dataclass(frozen=True, slots=True)
class ActionRecord:
    action_id: str
    session_id: str
    tenant_id: str
    operator_ref: dict[str,Any]
    surface: str
    action_kind: str
    target_ref: str|None
    parameters_hash: str
    authorization_level: str
    forwarded_api: str|None
    forwarded_at: str|None
    outcome: str
    result: dict[str,Any]
    correlation_id: str
    causation_id: str|None
    created_at: str
    signature: str
    integrity_hash: str
    def document(self): return asdict(self)

class ConfirmationStore:
    """Durable confirmation records with integrity protection and single-consume semantics."""
    def __init__(self, *, key: bytes, db_path: str | None = None):
        self._key=bytes(key); self._items: dict[str,dict[str,Any]]={}; self._lock=threading.RLock()
        self._db = None
        if db_path:
            path = str(db_path)
            import os
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
            self._db.execute("CREATE TABLE IF NOT EXISTS confirmations (confirmation_id TEXT PRIMARY KEY, payload TEXT NOT NULL, consumed_at REAL)")

    def _seal(self, rec: Mapping[str,Any]) -> dict[str,Any]:
        body=dict(rec); body.pop("integrity_hash",None)
        body["integrity_hash"]=hmac.new(self._key,canonical_json(body),hashlib.sha256).hexdigest()
        return body

    def put(self, rec: Mapping[str,Any]) -> None:
        rid=str(rec["confirmation_id"]); body=self._seal(rec); payload=json.dumps(body, sort_keys=True, separators=(",",":"))
        with self._lock:
            if self._db is not None:
                row=self._db.execute("SELECT payload FROM confirmations WHERE confirmation_id=?",(rid,)).fetchone()
                if row is not None:
                    existing=json.loads(str(row[0]))
                    # Allow a signature-bearing update only when the immutable confirmation body is unchanged.
                    lhs={k:v for k,v in existing.items() if k not in ("primary_signature","second_signature","integrity_hash")}
                    rhs={k:v for k,v in body.items() if k not in ("primary_signature","second_signature","integrity_hash")}
                    if lhs != rhs:
                        raise ValueError("confirmation identifier collision")
                self._db.execute("INSERT OR REPLACE INTO confirmations(confirmation_id,payload,consumed_at) VALUES(?,?,COALESCE((SELECT consumed_at FROM confirmations WHERE confirmation_id=?),NULL))",(rid,payload,rid))
            self._items[rid]=body

    def get(self, ref: str) -> dict[str,Any]|None:
        key=str(ref)
        with self._lock:
            row=self._db.execute("SELECT payload, consumed_at FROM confirmations WHERE confirmation_id=?",(key,)).fetchone() if self._db is not None else None
            if row is not None:
                if row[1] is not None:
                    return None
                body=json.loads(str(row[0]))
            else:
                body=self._items.get(key)
            if not body: return None
            expires_at=body.get("expires_at")
            if expires_at:
                try:
                    if datetime.fromisoformat(str(expires_at).replace("Z","+00:00")) <= datetime.now(timezone.utc):
                        self._items.pop(key, None)
                        if self._db is not None:
                            self._db.execute("DELETE FROM confirmations WHERE confirmation_id=?", (key,))
                        return None
                except (TypeError,ValueError):
                    return None
            check=dict(body); tag=check.pop("integrity_hash","")
            if not hmac.compare_digest(tag,hmac.new(self._key,canonical_json(check),hashlib.sha256).hexdigest()):
                return None
            return body

    def consume(self, ref: str) -> dict[str,Any]:
        key=str(ref)
        with self._lock:
            body=self.get(key)
            if body is None: raise PermissionError("confirmation unavailable or expired")
            if self._db is not None:
                now=time.time()
                cur=self._db.execute("UPDATE confirmations SET consumed_at=? WHERE confirmation_id=? AND consumed_at IS NULL",(now,key))
                if cur.rowcount != 1:
                    raise PermissionError("confirmation already consumed")
            self._items.pop(key,None)
            return body

    def close(self) -> None:
        with self._lock:
            if self._db is not None:
                self._db.close(); self._db=None

class InMemoryOperatorIdentityProvider:
    """Test/deployment adapter; production must replace it with Security Authority backed storage."""
    def __init__(self, records: Mapping[str,OperatorIdentity], signing_keys: Mapping[str,Ed25519PrivateKey]|None=None): self.records=dict(records); self.signing_keys=dict(signing_keys or {})
    def authenticate(self, credentials: Mapping[str,Any], tenant_id: str) -> OperatorIdentity:
        op_id=str(credentials.get("operator_id", "")); rec=self.records.get(op_id)
        if rec is None or rec.status!="active" or tenant_id not in rec.tenant_ids: raise PermissionError("operator authentication or tenant authorization failed")
        return rec
    def sign(self, operator_id: str, document: Mapping[str, Any]) -> str:
        key = self.signing_keys.get(operator_id)
        if key is None:
            raise PermissionError("operator signing key unavailable")
        return sign(document, key)

    def verify(self, operator_id: str, document: Mapping[str, Any], signature: str) -> bool:
        key = self.signing_keys.get(operator_id)
        if key is None:
            return False
        return verify(document, signature, key.public_key())

class SecurityAuthorityAdapter:
    """Narrow adapter: the gateway requests/validates evidence; it never grants on its own."""
    def __init__(self, validator=None, issuer=None, authorizer=None): self.validator=validator; self.issuer=issuer; self.authorizer=authorizer
    def validate_token(self, token_ref: str, *, operator_ref: Mapping[str,Any], tenant_id: str, scope: str) -> bool:
        return bool(self.validator and self.validator(token_ref,operator_ref=operator_ref,tenant_id=tenant_id,scope=scope))
    def authorize(self, *, operator_ref: Mapping[str,Any], tenant_id: str, operation: str, scopes: tuple[str,...], token_ref: str|None=None, justification_ref: str|None=None, second_operator_ref: Mapping[str,Any]|None=None) -> bool:
        if self.authorizer is None: return False
        return bool(self.authorizer(operator_ref=operator_ref,tenant_id=tenant_id,operation=operation,scopes=scopes,token_ref=token_ref,justification_ref=justification_ref,second_operator_ref=second_operator_ref))
    def request(self, *, operator_ref: Mapping[str,Any], tenant_id: str, action_id: str, justification: str) -> str:
        if self.issuer is None: raise PermissionError("Security Authority issuer unavailable")
        return str(self.issuer(operator_ref=operator_ref,tenant_id=tenant_id,action_id=action_id,justification=justification))

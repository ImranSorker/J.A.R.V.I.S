from __future__ import annotations

import collections
from dataclasses import dataclass
from typing import Any, Mapping

from .models import STREAM_KINDS, now_iso, uid


@dataclass
class StreamSession:
    stream_id: str
    session_id: str
    tenant_id: str
    stream_kind: str
    filter: dict[str, Any]
    opened_at: str
    active: bool = True
    queued: int = 0
    dropped: int = 0
    last_event_id: str | None = None
    bus_handle: Any | None = None


class StreamManager:
    """Bounded gateway-side stream queues; source subscription is owned by the gateway."""

    def __init__(self, max_streams: int = 32, per_stream_queue: int = 128, max_streams_per_tenant: int | None = None, max_total_streams: int | None = None):
        self.max_streams = max_streams
        self.max_streams_per_tenant = max_streams if max_streams_per_tenant is None else max_streams_per_tenant
        self.max_total_streams = max_streams * 16 if max_total_streams is None else max_total_streams
        self.per_stream_queue = per_stream_queue
        self.items: dict[str, StreamSession] = {}
        self.queues: dict[str, collections.deque] = {}

    def open(self, session_id: str, tenant_id: str, kind: str, flt: Mapping[str, Any], *, bus_handle: Any | None = None) -> StreamSession:
        if kind not in STREAM_KINDS:
            raise ValueError("unsupported stream kind")
        if len(self.items) >= self.max_total_streams:
            raise RuntimeError("max concurrent streams exceeded")
        tenant_count = sum(1 for x in self.items.values() if x.tenant_id == tenant_id and x.active)
        if tenant_count >= self.max_streams_per_tenant:
            raise RuntimeError("max concurrent streams per tenant exceeded")
        s = StreamSession(uid(), session_id, tenant_id, kind, dict(flt), now_iso(), bus_handle=bus_handle)
        self.items[s.stream_id] = s
        self.queues[s.stream_id] = collections.deque(maxlen=self.per_stream_queue)
        return s

    def push(self, stream_id: str, event: Mapping[str, Any]) -> bool:
        s = self.items.get(stream_id)
        if not s or not s.active:
            return False
        q = self.queues[stream_id]
        if len(q) >= q.maxlen:
            s.dropped += 1
            return False
        q.append(dict(event))
        s.queued = len(q)
        s.last_event_id = str(event.get("event_id") or "")
        return True

    def poll(self, stream_id: str, limit: int = 20) -> list[dict[str, Any]]:
        s = self.items.get(stream_id)
        if not s:
            raise KeyError(stream_id)
        q = self.queues[stream_id]
        out = []
        for _ in range(min(limit, len(q))):
            out.append(q.popleft())
        s.queued = len(q)
        return out

    def close(self, stream_id: str, unsubscribe=None) -> None:
        s = self.items.get(stream_id)
        if not s:
            return
        s.active = False
        if unsubscribe and s.bus_handle is not None:
            try:
                unsubscribe(s.bus_handle)
            except Exception as unsubscribe_error:
                s.last_event_id = f"unsubscribe-error:{unsubscribe_error}"
        self.queues.pop(stream_id, None)
        self.items.pop(stream_id, None)

    def count_for_session(self, session_id: str) -> int:
        return sum(1 for x in self.items.values() if x.session_id == session_id and x.active)

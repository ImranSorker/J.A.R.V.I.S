from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Mapping

from .models import *


class SessionManager:
    def __init__(self, gateway, ttl_seconds: int = 900):
        self.gateway = gateway
        self.ttl_seconds = max(60, min(ttl_seconds, 86400))
        self.sessions: dict[str, dict[str, Any]] = {}

    def _sign(self, doc):
        body = dict(doc)
        body.pop("signature", None)
        body.pop("integrity_hash", None)
        body["integrity_hash"] = sha(body)
        body["signature"] = sign(body, self.gateway.signer)
        return body

    def open(self, auth_credentials: Mapping[str, Any], tenant_id: str, client_bundle: Mapping[str, Any], *, user_agent: str = "", device_fingerprint: str = "") -> dict[str, Any]:
        bundle_b64 = str(client_bundle.get("bundle_bytes_b64", ""))
        if not bundle_b64:
            raise PermissionError("client bundle bytes are required")
        try:
            bundle_bytes = __import__("base64").b64decode(bundle_b64, validate=True)
        except Exception as exc:
            raise PermissionError("invalid client bundle encoding") from exc
        self.gateway.client_verifier.verify(client_bundle, bundle_bytes=bundle_bytes, tenant_id=tenant_id)
        if self.gateway.operator_provider is None:
            raise PermissionError("operator identity provider unavailable")
        op = self.gateway.operator_provider.authenticate(auth_credentials, tenant_id)
        granted_surfaces = []
        surface_auth = {}
        wildcard = any(str(s) in ("commandcenter.*", "*") for s in op.scopes)
        for surface in SURFACES:
            desc = self.gateway.surface_specs.get(surface, {})
            required = set(desc.get("required_scopes", []))
            scope_ok = wildcard or required.intersection(set(op.scopes))
            if surface == "HOME" or scope_ok:
                granted_surfaces.append(surface)
                surface_auth[surface] = "public" if surface == "HOME" else "operator_with_scope"
        if "HOME" not in granted_surfaces:
            granted_surfaces.insert(0, "HOME")
            surface_auth["HOME"] = "public"
        sid = uid()
        now = datetime.now(timezone.utc)
        exp = now + timedelta(seconds=self.ttl_seconds)
        sess = OperatorSession(
            sid, 1, identity_ref(op.document()), tenant_id,
            str(auth_credentials.get("authentication_method", "webauthn")), uid(),
            now.isoformat().replace("+00:00", "Z"), exp.isoformat().replace("+00:00", "Z"),
            op.scopes, tuple(granted_surfaces), surface_auth,
            str(client_bundle["client_bundle_ref"]), str(client_bundle["bundle_hash"]), str(client_bundle["client_attestation_ref"]),
            user_agent, device_fingerprint or sha({"operator": op.operator_id}),
            False, None, None,
            now.isoformat().replace("+00:00", "Z"), {"principal": "p2z-gateway", "key_id": self.gateway.key_id},
        )
        doc = self._sign(sess.document())
        self.sessions[sid] = doc
        self.gateway.emit("CommandCenter.SessionOpened", doc, tenant_id=tenant_id, correlation_id=sid)
        return doc

    def get(self, sid: str) -> dict[str, Any]:
        s = self.sessions.get(sid)
        if not s:
            raise PermissionError("invalid session")
        if s.get("closed_at"):
            raise PermissionError("session closed")
        if s["expires_at"] <= now_iso():
            self.expire(sid)
            raise PermissionError("session expired")
        return s

    def expire(self, sid: str):
        s = self.sessions.get(sid)
        if s and s.get("expires_at", "") <= now_iso():
            for stream_id, stream in list(self.gateway.streams.items.items()):
                if stream.session_id == sid:
                    self.gateway.close_stream(stream_id)
            self.sessions.pop(sid, None)
            self.gateway.emit("CommandCenter.SessionExpired", {"session_id": sid, "tenant_id": s["tenant_id"]}, tenant_id=s["tenant_id"], correlation_id=sid)

    def refresh(self, sid: str) -> dict[str, Any]:
        s = self.get(sid)
        now = datetime.now(timezone.utc)
        s = dict(s)
        s["session_version"] += 1
        s["expires_at"] = (now + timedelta(seconds=self.ttl_seconds)).isoformat().replace("+00:00", "Z")
        s = {**s, "signature": "", "integrity_hash": ""}
        s = self._sign(s)
        self.sessions[sid] = s
        self.gateway.emit("CommandCenter.SessionRefreshed", s, tenant_id=s["tenant_id"], correlation_id=sid)
        return s

    def close(self, sid: str, reason: str):
        s = self.get(sid)
        s = dict(s)
        s["closed_reason"] = str(reason)
        s["closed_at"] = now_iso()
        for stream_id, stream in list(self.gateway.streams.items.items()):
            if stream.session_id == sid:
                self.gateway.close_stream(stream_id)
        self.sessions[sid] = s
        self.gateway.emit("CommandCenter.SessionClosed", s, tenant_id=s["tenant_id"], correlation_id=sid)

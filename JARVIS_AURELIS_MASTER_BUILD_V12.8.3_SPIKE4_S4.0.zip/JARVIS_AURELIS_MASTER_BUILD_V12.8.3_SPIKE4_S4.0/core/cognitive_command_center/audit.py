from __future__ import annotations
import hashlib,hmac,json,sqlite3,threading
from pathlib import Path
from typing import Any,Mapping
from core.kernel_12_8_0.canonical import canonical_json
from .models import now_iso,sha,uid
class AuditLedger:
    """Tenant-scoped append-only HMAC ledger independent of operator sessions."""
    def __init__(self,path:str|Path,secret:bytes):
        if len(secret)<32: raise ValueError("audit secret must be at least 32 bytes")
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.secret=bytes(secret); self.lock=threading.RLock()
        self.db=sqlite3.connect(str(self.path),check_same_thread=False); self.db.execute("PRAGMA journal_mode=WAL"); self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT, audit_id TEXT UNIQUE, tenant_id TEXT NOT NULL, body TEXT NOT NULL, prev_hash TEXT NOT NULL, hmac TEXT NOT NULL, created REAL NOT NULL)"); self.db.commit()
    def append(self, body:Mapping[str,Any])->dict[str,Any]:
        row=dict(body); row.setdefault("audit_id",uid()); row.setdefault("created_at",now_iso()); row.setdefault("parameters_hash",sha(row.get("parameters",{}))); row.pop("parameters",None)
        with self.lock:
            prev=self.db.execute("SELECT hmac FROM audit ORDER BY seq DESC LIMIT 1").fetchone(); prev_hash=str(prev[0]) if prev else "0"*64
            material={"body":row,"prev_hash":prev_hash}; tag=hmac.new(self.secret,canonical_json(material),hashlib.sha256).hexdigest(); integrity=hashlib.sha256(canonical_json(material)).hexdigest()
            c=dict(row); c["hmac"]=tag; c["integrity_hash"]=integrity; self.db.execute("INSERT INTO audit(audit_id,tenant_id,body,prev_hash,hmac,created) VALUES(?,?,?,?,?,strftime('%s','now'))",(row["audit_id"],row["tenant_id"],json.dumps(c,sort_keys=True,separators=(",",":")),prev_hash,tag)); self.db.commit(); return c
    def query(self,tenant_id:str,limit:int=100)->list[dict[str,Any]]:
        rows=self.db.execute("SELECT body FROM audit WHERE tenant_id=? ORDER BY seq DESC LIMIT ?",(tenant_id,max(1,min(limit,1000)))).fetchall(); return [json.loads(r[0]) for r in rows]
    def close(self): self.db.close()

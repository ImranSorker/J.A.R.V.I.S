"""Correlated real-time event stream with bounded backpressure."""
from __future__ import annotations
import logging
import queue
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)

@dataclass(frozen=True, slots=True)
class FrontierEvent:
    event_id: str
    event_type: str
    created_at: float
    correlation_id: str
    source: str
    payload: dict[str, Any]

class FrontierEventStream:
    """Bounded event stream that never blocks producers indefinitely."""
    def __init__(self, *, max_queue: int = 10_000) -> None:
        self._q: queue.Queue[FrontierEvent] = queue.Queue(maxsize=max(1, min(int(max_queue), 100_000)))
        self._subs: dict[str, list[Callable[[FrontierEvent], None]]] = {}
        self._lock = threading.RLock()
        self._dropped = 0
    def subscribe(self, event_type: str, callback: Callable[[FrontierEvent], None]) -> None:
        if not str(event_type).strip() or not callable(callback): raise ValueError("event_type and callback are required")
        with self._lock: self._subs.setdefault(event_type, []).append(callback)
    def publish(self, event_type: str, payload: dict[str, Any], *, source: str = "jarvis", correlation_id: str | None = None) -> FrontierEvent:
        event = FrontierEvent(uuid.uuid4().hex, str(event_type).strip(), time.time(), correlation_id or uuid.uuid4().hex, str(source).strip(), dict(payload))
        try: self._q.put_nowait(event)
        except queue.Full:
            with self._lock: self._dropped += 1
            raise RuntimeError("frontier event queue is full")
        self.dispatch_once()
        return event
    def dispatch_once(self) -> None:
        try: event = self._q.get_nowait()
        except queue.Empty: return
        try:
            with self._lock: callbacks = tuple(self._subs.get(event.event_type, ())) + tuple(self._subs.get("*", ()))
            for callback in callbacks:
                try:
                    callback(event)
                except Exception:
                    logger.debug("frontier subscriber callback failed; dispatch continues", exc_info=True)
        finally: self._q.task_done()
    def snapshot(self) -> dict[str, int]:
        with self._lock: return {"queued": self._q.qsize(), "dropped": self._dropped, "subscriptions": sum(len(v) for v in self._subs.values())}

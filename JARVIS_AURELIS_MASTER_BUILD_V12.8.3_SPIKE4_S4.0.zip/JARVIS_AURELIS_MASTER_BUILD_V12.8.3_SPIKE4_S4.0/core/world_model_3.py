"""J.A.R.V.I.S. P2-J World Model 3.x canonical state fabric.

The World Model 3.x layer provides a single durable, tenant-scoped substrate for
entities, relationships, temporal state, provenance, causal links, predictions,
constraints, and auditable state transitions.  Legacy WorldModel/WorldModel2 and
TemporalWorldModel APIs remain intact; this module is the canonical P2-J surface
for new Simulation, Multi-Agent, Research, Doctor, Recovery, and Command Center
integrations.
"""
from __future__ import annotations

import hashlib
import logging
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence


SCHEMA_VERSION = "3.0.0"
MAX_QUERY_LIMIT = 1000
MAX_PATH_DEPTH = 12
logger = logging.getLogger(__name__)


class WorldModelError(RuntimeError):
    """Base World Model 3.x error."""


class WorldModelClosedError(WorldModelError):
    """Raised when an operation targets a closed model."""


class WorldConflictError(WorldModelError):
    """Raised for optimistic-concurrency or temporal-state conflicts."""


class WorldAuthorizationError(WorldModelError, PermissionError):
    """Raised when the configured world-model authorization boundary denies access."""


@dataclass(frozen=True, slots=True)
class Provenance:
    """Origin and trust metadata attached to a world datum."""

    source: str
    source_type: str = "system"
    producer: str = "jarvis"
    observed_at: float = field(default_factory=time.time)
    event_id: str | None = None
    evidence_refs: tuple[str, ...] = ()
    trust: float = 1.0
    content_hash: str | None = None
    chain_hash: str | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)

    def normalized(self, content: Any) -> "Provenance":
        trust = max(0.0, min(1.0, float(self.trust)))
        raw = _canonical_bytes(content)
        content_hash = hashlib.sha256(raw).hexdigest()
        chain_payload = {
            "source": self.source,
            "source_type": self.source_type,
            "producer": self.producer,
            "observed_at": float(self.observed_at),
            "event_id": self.event_id,
            "evidence_refs": list(self.evidence_refs),
            "trust": trust,
            "content_hash": content_hash,
            "metadata": dict(sorted((str(k), str(v)) for k, v in self.metadata.items())),
        }
        chain_hash = hashlib.sha256(_canonical_bytes(chain_payload)).hexdigest()
        return Provenance(
            source=str(self.source),
            source_type=str(self.source_type),
            producer=str(self.producer),
            observed_at=float(self.observed_at),
            event_id=str(self.event_id) if self.event_id else None,
            evidence_refs=tuple(str(item) for item in self.evidence_refs),
            trust=trust,
            content_hash=content_hash,
            chain_hash=chain_hash,
            metadata=dict(sorted((str(k), str(v)) for k, v in self.metadata.items())),
        )


@dataclass(frozen=True, slots=True)
class WorldEntity3:
    """Durable typed entity in the canonical world graph."""

    entity_id: str
    entity_type: str
    name: str
    properties: Mapping[str, Any] = field(default_factory=dict)
    tenant_id: str = "default"
    status: str = "active"
    version: int = 1
    confidence: float = 1.0
    uncertainty: Mapping[str, Any] = field(default_factory=dict)
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    deleted_at: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class WorldRelation3:
    """Typed relationship between two world entities."""

    relation_id: str
    source_id: str
    relation: str
    target_id: str
    tenant_id: str = "default"
    properties: Mapping[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))
    valid_from: float = field(default_factory=time.time)
    valid_until: float | None = None
    version: int = 1
    status: str = "active"

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class WorldObservation:
    """Temporal state observation for one entity and state key."""

    observation_id: str
    entity_id: str
    state_key: str
    value: Any
    tenant_id: str = "default"
    valid_from: float = field(default_factory=time.time)
    valid_until: float | None = None
    confidence: float = 1.0
    uncertainty: Mapping[str, Any] = field(default_factory=dict)
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))
    transition_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class StateTransition:
    """Auditable state transition emitted by an observation or action."""

    transition_id: str
    entity_id: str
    state_key: str
    previous_value: Any
    new_value: Any
    actor: str
    timestamp: float
    confidence: float
    cause_refs: tuple[str, ...] = ()
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))
    correlation_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class CausalLink:
    """Bounded causal relationship between world facts/events."""

    cause_id: str
    cause_ref: str
    effect_ref: str
    confidence: float = 1.0
    mechanism: str | None = None
    tenant_id: str = "default"
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))
    valid_from: float = field(default_factory=time.time)
    valid_until: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class PredictionRecord:
    """Prediction made against a world state with explicit resolution tracking."""

    prediction_id: str
    target_ref: str
    predicted_value: Any
    predicted_at: float
    horizon_seconds: float
    confidence: float
    model_ref: str
    tenant_id: str = "default"
    source_snapshot: str | None = None
    resolved_at: float | None = None
    actual_value: Any = None
    outcome: str = "open"
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class WorldConstraint:
    """Named constraint over one or more world entities."""

    constraint_id: str
    name: str
    constraint_type: str
    expression: Mapping[str, Any]
    severity: str = "warning"
    tenant_id: str = "default"
    enabled: bool = True
    provenance: Provenance = field(default_factory=lambda: Provenance("internal"))

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["provenance"] = asdict(self.provenance)
        return payload


@dataclass(frozen=True, slots=True)
class WorldSnapshot3:
    """Integrity-addressed point-in-time world projection."""

    snapshot_id: str
    tenant_id: str
    created_at: float
    schema_version: str
    entity_count: int
    relation_count: int
    observation_count: int
    transition_count: int
    causal_count: int
    prediction_count: int
    constraint_count: int
    digest: str
    sequence: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ConstraintResult:
    """Result of evaluating one constraint."""

    constraint_id: str
    satisfied: bool
    severity: str
    message: str
    details: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class WorldChange:
    """Common change envelope for downstream Simulation/Research/Doctor consumers."""

    change_id: str
    kind: str
    ref: str
    tenant_id: str
    timestamp: float
    payload: Mapping[str, Any]
    provenance: Provenance



def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _check_confidence(value: float) -> float:
    value = float(value)
    if not 0.0 <= value <= 1.0:
        raise ValueError("confidence must be between 0 and 1")
    return value


def _limit(value: int, ceiling: int = MAX_QUERY_LIMIT) -> int:
    return max(1, min(int(value), ceiling))


class WorldModel3:
    """Canonical durable world state for J.A.R.V.I.S. P2-J."""

    def __init__(
        self,
        db_path: str | Path = "data/world_model_v3.db",
        *,
        tenant_id: str = "default",
        max_entities: int = 250_000,
        max_history: int = 1_000_000,
        event_sink: Any | None = None,
        authorizer: Callable[[str, str, str], bool] | None = None,
    ) -> None:
        if not str(tenant_id).strip():
            raise ValueError("tenant_id is required")
        self.tenant_id = str(tenant_id)
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_entities = max(1000, min(int(max_entities), 2_000_000))
        self.max_history = max(1000, min(int(max_history), 5_000_000))
        self.event_sink = event_sink
        self.authorizer = authorizer
        self._lock = threading.RLock()
        self._closed = False
        self._sequence = 0
        self._sqlite = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30.0)
        self._sqlite.row_factory = sqlite3.Row
        self._sqlite.execute("PRAGMA journal_mode=WAL")
        self._sqlite.execute("PRAGMA foreign_keys=ON")
        self._sqlite.execute("PRAGMA synchronous=NORMAL")
        self._init_schema()
        row = self._sqlite.execute("SELECT COALESCE(MAX(sequence), 0) FROM change_log WHERE tenant_id=?", (self.tenant_id,)).fetchone()
        self._sequence = int(row[0] if row else 0)

    def _init_schema(self) -> None:
        self._sqlite.executescript(
            """
            CREATE TABLE IF NOT EXISTS entities (
                entity_id TEXT NOT NULL,
                tenant_id TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                name TEXT NOT NULL,
                properties_json TEXT NOT NULL,
                status TEXT NOT NULL,
                version INTEGER NOT NULL,
                confidence REAL NOT NULL,
                uncertainty_json TEXT NOT NULL,
                provenance_json TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                deleted_at REAL,
                PRIMARY KEY (tenant_id, entity_id)
            );
            CREATE INDEX IF NOT EXISTS idx_entities_type ON entities(tenant_id, entity_type, status, updated_at);
            CREATE TABLE IF NOT EXISTS relations (
                relation_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                source_id TEXT NOT NULL,
                relation TEXT NOT NULL,
                target_id TEXT NOT NULL,
                properties_json TEXT NOT NULL,
                confidence REAL NOT NULL,
                provenance_json TEXT NOT NULL,
                valid_from REAL NOT NULL,
                valid_until REAL,
                version INTEGER NOT NULL,
                status TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_rel_source ON relations(tenant_id, source_id, relation, status);
            CREATE INDEX IF NOT EXISTS idx_rel_target ON relations(tenant_id, target_id, relation, status);
            CREATE TABLE IF NOT EXISTS observations (
                observation_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                state_key TEXT NOT NULL,
                value_json TEXT NOT NULL,
                valid_from REAL NOT NULL,
                valid_until REAL,
                confidence REAL NOT NULL,
                uncertainty_json TEXT NOT NULL,
                provenance_json TEXT NOT NULL,
                transition_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_obs_current ON observations(tenant_id, entity_id, state_key, valid_until, valid_from);
            CREATE TABLE IF NOT EXISTS transitions (
                transition_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                state_key TEXT NOT NULL,
                previous_json TEXT,
                new_json TEXT NOT NULL,
                actor TEXT NOT NULL,
                timestamp REAL NOT NULL,
                confidence REAL NOT NULL,
                cause_refs_json TEXT NOT NULL,
                provenance_json TEXT NOT NULL,
                correlation_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_transitions_entity ON transitions(tenant_id, entity_id, state_key, timestamp);
            CREATE TABLE IF NOT EXISTS causal_links (
                cause_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                cause_ref TEXT NOT NULL,
                effect_ref TEXT NOT NULL,
                confidence REAL NOT NULL,
                mechanism TEXT,
                provenance_json TEXT NOT NULL,
                valid_from REAL NOT NULL,
                valid_until REAL
            );
            CREATE INDEX IF NOT EXISTS idx_cause_effect ON causal_links(tenant_id, effect_ref, confidence);
            CREATE TABLE IF NOT EXISTS predictions (
                prediction_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                target_ref TEXT NOT NULL,
                predicted_json TEXT NOT NULL,
                predicted_at REAL NOT NULL,
                horizon_seconds REAL NOT NULL,
                confidence REAL NOT NULL,
                model_ref TEXT NOT NULL,
                source_snapshot TEXT,
                resolved_at REAL,
                actual_json TEXT,
                outcome TEXT NOT NULL,
                provenance_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_predictions_target ON predictions(tenant_id, target_ref, outcome, predicted_at);
            CREATE TABLE IF NOT EXISTS constraints_v3 (
                constraint_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                name TEXT NOT NULL,
                constraint_type TEXT NOT NULL,
                expression_json TEXT NOT NULL,
                severity TEXT NOT NULL,
                enabled INTEGER NOT NULL,
                provenance_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_constraints ON constraints_v3(tenant_id, enabled, severity);
            CREATE TABLE IF NOT EXISTS change_log (
                change_id TEXT PRIMARY KEY,
                tenant_id TEXT NOT NULL,
                sequence INTEGER NOT NULL,
                kind TEXT NOT NULL,
                ref TEXT NOT NULL,
                timestamp REAL NOT NULL,
                payload_json TEXT NOT NULL,
                provenance_json TEXT NOT NULL,
                idempotency_key TEXT
            );
            CREATE UNIQUE INDEX IF NOT EXISTS idx_change_idempotency ON change_log(tenant_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
            CREATE INDEX IF NOT EXISTS idx_change_sequence ON change_log(tenant_id, sequence);
            """
        )
        self._sqlite.commit()

    def _ensure_open(self) -> None:
        if self._closed or self._sqlite is None:
            raise WorldModelClosedError("world model is closed")

    def _authorize(self, action: str, principal: str = "system") -> None:
        if self.authorizer is not None and not bool(self.authorizer(principal, action, self.tenant_id)):
            raise WorldAuthorizationError(f"world-model authorization denied: {action}")

    def _record_change(self, kind: str, ref: str, payload: Mapping[str, Any], provenance: Provenance, *, idempotency_key: str | None = None) -> WorldChange:
        now = time.time()
        normalized = provenance.normalized(payload)
        with self._lock:
            self._sequence += 1
            change_id = f"chg_{uuid.uuid4().hex[:20]}"
            try:
                self._sqlite.execute(
                    "INSERT INTO change_log VALUES (?,?,?,?,?,?,?,?,?)",
                    (change_id, self.tenant_id, self._sequence, kind, ref, now, _json(dict(payload)), _json(asdict(normalized)), idempotency_key),
                )
            except sqlite3.IntegrityError:
                if idempotency_key:
                    row = self._sqlite.execute("SELECT * FROM change_log WHERE tenant_id=? AND idempotency_key=?", (self.tenant_id, idempotency_key)).fetchone()
                    if row is not None:
                        existing_prov = _provenance_from_json(row["provenance_json"])
                        return WorldChange(row["change_id"], row["kind"], row["ref"], row["tenant_id"], float(row["timestamp"]), json.loads(row["payload_json"]), existing_prov)
                raise
            self._sqlite.commit()
        change = WorldChange(change_id, kind, ref, self.tenant_id, now, dict(payload), normalized)
        self._emit(change)
        return change

    def _emit(self, change: WorldChange) -> None:
        sink = self.event_sink
        if sink is None:
            return
        event_payload = {"change": asdict(change), "schema_version": SCHEMA_VERSION}
        try:
            if hasattr(sink, "publish"):
                sink.publish("world.model.changed", event_payload, source="world-model-3")
        except TypeError:
            try:
                sink.publish("world.model.changed", event_payload)
            except Exception:
                return
        except Exception:
            return

    def _begin(self) -> None:
        self._sqlite.execute("BEGIN IMMEDIATE")

    def upsert_entity(self, entity: WorldEntity3, *, expected_version: int | None = None, idempotency_key: str | None = None, principal: str = "system") -> WorldEntity3:
        self._authorize("world.entity.write", principal)
        self._ensure_open()
        if not entity.entity_id or not entity.entity_type or not entity.name:
            raise ValueError("entity_id, entity_type and name are required")
        confidence = _check_confidence(entity.confidence)
        now = time.time()
        provenance = entity.provenance.normalized(entity.to_dict())
        with self._lock:
            if idempotency_key:
                prior = self._sqlite.execute("SELECT * FROM change_log WHERE tenant_id=? AND idempotency_key=?", (self.tenant_id, idempotency_key)).fetchone()
                if prior is not None and prior["kind"] == "entity.upserted":
                    existing = self.get_entity(entity.entity_id, principal=principal)
                    if existing is not None:
                        return existing
            self._begin()
            try:
                row = self._sqlite.execute("SELECT * FROM entities WHERE tenant_id=? AND entity_id=?", (self.tenant_id, entity.entity_id)).fetchone()
                if row is not None and expected_version is not None and int(row["version"]) != int(expected_version):
                    raise WorldConflictError(f"entity version mismatch: expected {expected_version}, found {row['version']}")
                if row is None:
                    version = 1
                    created_at = float(entity.created_at or now)
                else:
                    version = int(row["version"]) + 1
                    created_at = float(row["created_at"])
                current = WorldEntity3(
                    entity_id=str(entity.entity_id), entity_type=str(entity.entity_type), name=str(entity.name),
                    properties=dict(entity.properties), tenant_id=self.tenant_id, status=str(entity.status), version=version,
                    confidence=confidence, uncertainty=dict(entity.uncertainty), provenance=provenance,
                    created_at=created_at, updated_at=now, deleted_at=entity.deleted_at,
                )
                self._sqlite.execute(
                    "INSERT INTO entities VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,entity_id) DO UPDATE SET entity_type=excluded.entity_type,name=excluded.name,properties_json=excluded.properties_json,status=excluded.status,version=excluded.version,confidence=excluded.confidence,uncertainty_json=excluded.uncertainty_json,provenance_json=excluded.provenance_json,updated_at=excluded.updated_at,deleted_at=excluded.deleted_at",
                    (current.entity_id, self.tenant_id, current.entity_type, current.name, _json(current.properties), current.status, current.version, current.confidence, _json(current.uncertainty), _json(asdict(current.provenance)), current.created_at, current.updated_at, current.deleted_at),
                )
                excess = self._sqlite.execute("SELECT COUNT(*) FROM entities WHERE tenant_id=? AND status != 'deleted'", (self.tenant_id,)).fetchone()[0] - self.max_entities
                if excess > 0:
                    ids = [row[0] for row in self._sqlite.execute("SELECT entity_id FROM entities WHERE tenant_id=? AND status != 'deleted' ORDER BY updated_at ASC LIMIT ?", (self.tenant_id, excess)).fetchall()]
                    for entity_id in ids:
                        self._sqlite.execute("UPDATE entities SET status='evicted', updated_at=? WHERE tenant_id=? AND entity_id=?", (now, self.tenant_id, entity_id))
                self._sqlite.execute("COMMIT")
            except Exception:
                self._sqlite.execute("ROLLBACK")
                raise
        self._record_change("entity.upserted", current.entity_id, current.to_dict(), provenance, idempotency_key=idempotency_key)
        return current

    def get_entity(self, entity_id: str, *, include_deleted: bool = False, principal: str = "system") -> WorldEntity3 | None:
        self._authorize("world.entity.read", principal)
        self._ensure_open()
        with self._lock:
            row = self._sqlite.execute("SELECT * FROM entities WHERE tenant_id=? AND entity_id=?", (self.tenant_id, str(entity_id))).fetchone()
        if row is None or (not include_deleted and row["status"] == "deleted"):
            return None
        return _entity_from_row(row)

    def query_entities(self, *, entity_type: str | None = None, status: str = "active", name: str | None = None, limit: int = 100, principal: str = "system") -> list[WorldEntity3]:
        self._authorize("world.entity.read", principal)
        self._ensure_open()
        limit = _limit(limit)
        clauses = ["tenant_id=?"]
        params: list[Any] = [self.tenant_id]
        if status:
            clauses.append("status=?"); params.append(status)
        if entity_type:
            clauses.append("entity_type=?"); params.append(str(entity_type))
        if name:
            clauses.append("name LIKE ?"); params.append(f"%{name}%")
        where = " AND ".join(clauses)
        with self._lock:
            rows = self._sqlite.execute(f"SELECT * FROM entities WHERE {where} ORDER BY updated_at DESC LIMIT ?", (*params, limit)).fetchall()
        return [_entity_from_row(row) for row in rows]

    def delete_entity(self, entity_id: str, *, expected_version: int | None = None, principal: str = "system") -> bool:
        self._authorize("world.entity.write", principal)
        self._ensure_open()
        current = self.get_entity(entity_id, principal=principal)
        if current is None:
            return False
        tombstone = WorldEntity3(**{**current.to_dict(), "properties": {}, "status": "deleted", "deleted_at": time.time(), "updated_at": time.time(), "provenance": Provenance("world-model-3", source_type="system", producer="world-model-3").normalized({"entity_id": entity_id, "deleted": True})})
        self.upsert_entity(tombstone, expected_version=expected_version or current.version, principal=principal)
        return True

    def add_relation(self, relation: WorldRelation3, *, principal: str = "system") -> WorldRelation3:
        self._authorize("world.relation.write", principal)
        self._ensure_open()
        if not relation.source_id or not relation.target_id or not relation.relation:
            raise ValueError("relation endpoints and type are required")
        confidence = _check_confidence(relation.confidence)
        provenance = relation.provenance.normalized(relation.to_dict())
        relation_id = relation.relation_id or f"rel_{uuid.uuid4().hex[:20]}"
        now = time.time()
        with self._lock:
            row = self._sqlite.execute("SELECT version FROM relations WHERE relation_id=?", (relation_id,)).fetchone()
            version = int(row[0]) + 1 if row else 1
            current = WorldRelation3(relation_id, relation.source_id, relation.relation, relation.target_id, self.tenant_id, dict(relation.properties), confidence, provenance, float(relation.valid_from), relation.valid_until, version, relation.status)
            self._sqlite.execute("INSERT OR REPLACE INTO relations VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (current.relation_id,self.tenant_id,current.source_id,current.relation,current.target_id,_json(current.properties),current.confidence,_json(asdict(current.provenance)),current.valid_from,current.valid_until,current.version,current.status))
            self._sqlite.commit()
        self._record_change("relation.upserted", relation_id, current.to_dict(), provenance)
        return current

    def relations_for(self, entity_id: str, *, direction: str = "both", relation: str | None = None, limit: int = 100, principal: str = "system") -> list[WorldRelation3]:
        self._authorize("world.relation.read", principal)
        self._ensure_open()
        limit = _limit(limit)
        clauses = ["tenant_id=?"]
        params: list[Any] = [self.tenant_id]
        if direction == "out": clauses.append("source_id=?"); params.append(entity_id)
        elif direction == "in": clauses.append("target_id=?"); params.append(entity_id)
        elif direction == "both": clauses.append("(source_id=? OR target_id=?)"); params.extend([entity_id, entity_id])
        else: raise ValueError("direction must be out, in or both")
        if relation:
            clauses.append("relation=?"); params.append(relation)
        with self._lock:
            rows = self._sqlite.execute(f"SELECT * FROM relations WHERE {' AND '.join(clauses)} ORDER BY valid_from DESC LIMIT ?", (*params, limit)).fetchall()
        return [_relation_from_row(row) for row in rows]

    def neighbors(self, entity_id: str, *, max_depth: int = 2, relation: str | None = None, limit: int = 256, principal: str = "system") -> list[str]:
        self._authorize("world.relation.read", principal)
        max_depth = max(1, min(int(max_depth), MAX_PATH_DEPTH))
        limit = _limit(limit, 10_000)
        seen = {str(entity_id)}
        frontier = [str(entity_id)]
        for _ in range(max_depth):
            if not frontier or len(seen) >= limit:
                break
            next_frontier: list[str] = []
            for node in frontier:
                for rel in self.relations_for(node, relation=relation, limit=min(100, limit), principal=principal):
                    candidate = rel.target_id if rel.source_id == node else rel.source_id
                    if candidate not in seen:
                        seen.add(candidate); next_frontier.append(candidate)
                        if len(seen) >= limit:
                            break
                if len(seen) >= limit:
                    break
            frontier = next_frontier
        return sorted(seen - {str(entity_id)})[:limit]

    def observe_state(
        self,
        entity_id: str,
        state_key: str,
        value: Any,
        *,
        valid_from: float | None = None,
        valid_until: float | None = None,
        confidence: float = 1.0,
        uncertainty: Mapping[str, Any] | None = None,
        provenance: Provenance | None = None,
        transition_id: str | None = None,
        idempotency_key: str | None = None,
        principal: str = "system",
    ) -> WorldObservation:
        self._authorize("world.state.write", principal)
        self._ensure_open()
        if self.get_entity(entity_id, principal=principal) is None:
            raise KeyError(f"unknown world entity: {entity_id}")
        confidence = _check_confidence(confidence)
        start = time.time() if valid_from is None else float(valid_from)
        if valid_until is not None and float(valid_until) <= start:
            raise ValueError("valid_until must be after valid_from")
        base_prov = provenance or Provenance("internal", producer="world-model-3")
        normalized_prov = base_prov.normalized({"entity_id": entity_id, "state_key": state_key, "value": value})
        observation = WorldObservation(
            observation_id=f"obs_{uuid.uuid4().hex[:20]}", entity_id=str(entity_id), state_key=str(state_key), value=value,
            tenant_id=self.tenant_id, valid_from=start, valid_until=valid_until, confidence=confidence,
            uncertainty=dict(uncertainty or {}), provenance=normalized_prov, transition_id=transition_id,
        )
        with self._lock:
            self._sqlite.execute("UPDATE observations SET valid_until=? WHERE tenant_id=? AND entity_id=? AND state_key=? AND valid_until IS NULL AND valid_from < ?", (start, self.tenant_id, entity_id, state_key, start))
            self._sqlite.execute("INSERT INTO observations VALUES (?,?,?,?,?,?,?,?,?,?,?)", (observation.observation_id,self.tenant_id,observation.entity_id,observation.state_key,_json(observation.value),observation.valid_from,observation.valid_until,observation.confidence,_json(observation.uncertainty),_json(asdict(observation.provenance)),observation.transition_id))
            self._sqlite.commit()
        self._record_change("state.observed", f"{entity_id}:{state_key}", observation.to_dict(), normalized_prov, idempotency_key=idempotency_key)
        return observation

    def current_state(self, entity_id: str, *, principal: str = "system") -> dict[str, WorldObservation]:
        self._authorize("world.state.read", principal)
        self._ensure_open()
        now = time.time()
        with self._lock:
            rows = self._sqlite.execute("SELECT * FROM observations WHERE tenant_id=? AND entity_id=? AND valid_from<=? AND (valid_until IS NULL OR valid_until>?) ORDER BY valid_from DESC", (self.tenant_id, entity_id, now, now)).fetchall()
        result: dict[str, WorldObservation] = {}
        for row in rows:
            item = _observation_from_row(row)
            if item.state_key not in result:
                result[item.state_key] = item
        return result

    def state_at(self, entity_id: str, at: float, *, principal: str = "system") -> dict[str, WorldObservation]:
        self._authorize("world.state.read", principal)
        self._ensure_open()
        when = float(at)
        with self._lock:
            rows = self._sqlite.execute("SELECT * FROM observations WHERE tenant_id=? AND entity_id=? AND valid_from<=? AND (valid_until IS NULL OR valid_until>?) ORDER BY valid_from DESC", (self.tenant_id, entity_id, when, when)).fetchall()
        result: dict[str, WorldObservation] = {}
        for row in rows:
            item = _observation_from_row(row)
            result.setdefault(item.state_key, item)
        return result

    def history(self, entity_id: str, state_key: str | None = None, *, limit: int = 500, principal: str = "system") -> list[WorldObservation]:
        self._authorize("world.state.read", principal)
        self._ensure_open()
        limit = _limit(limit)
        if state_key:
            query = "SELECT * FROM observations WHERE tenant_id=? AND entity_id=? AND state_key=? ORDER BY valid_from DESC LIMIT ?"
            params = (self.tenant_id, entity_id, state_key, limit)
        else:
            query = "SELECT * FROM observations WHERE tenant_id=? AND entity_id=? ORDER BY valid_from DESC LIMIT ?"
            params = (self.tenant_id, entity_id, limit)
        with self._lock:
            rows = self._sqlite.execute(query, params).fetchall()
        return [_observation_from_row(row) for row in rows]

    def transition_state(
        self,
        entity_id: str,
        state_key: str,
        new_value: Any,
        *,
        actor: str = "system",
        expected_previous: Any = ...,
        confidence: float = 1.0,
        cause_refs: Iterable[str] = (),
        provenance: Provenance | None = None,
        correlation_id: str | None = None,
        principal: str = "system",
    ) -> StateTransition:
        self._authorize("world.state.transition", principal)
        self._ensure_open()
        current = self.current_state(entity_id, principal=principal).get(state_key)
        previous = current.value if current else None
        if expected_previous is not ... and previous != expected_previous:
            raise WorldConflictError(f"state transition precondition failed for {entity_id}:{state_key}")
        transition_id = f"trn_{uuid.uuid4().hex[:20]}"
        prov = (provenance or Provenance("internal", producer="world-model-3")).normalized({"entity_id":entity_id,"state_key":state_key,"new_value":new_value,"previous":previous})
        transition = StateTransition(transition_id, entity_id, state_key, previous, new_value, str(actor), time.time(), _check_confidence(confidence), tuple(str(x) for x in cause_refs), prov, correlation_id)
        self.observe_state(entity_id, state_key, new_value, confidence=confidence, provenance=prov, transition_id=transition_id, principal=principal)
        with self._lock:
            self._sqlite.execute("INSERT INTO transitions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (transition.transition_id,self.tenant_id,transition.entity_id,transition.state_key,_json(transition.previous_value),_json(transition.new_value),transition.actor,transition.timestamp,transition.confidence,_json(list(transition.cause_refs)),_json(asdict(transition.provenance)),transition.correlation_id))
            self._sqlite.commit()
        self._record_change("state.transitioned", transition.transition_id, transition.to_dict(), prov)
        return transition

    def add_causal_link(self, link: CausalLink, *, principal: str = "system") -> CausalLink:
        self._authorize("world.causality.write", principal)
        self._ensure_open()
        normalized = link.provenance.normalized(link.to_dict())
        current = CausalLink(link.cause_id or f"cause_{uuid.uuid4().hex[:20]}",link.cause_ref,link.effect_ref,_check_confidence(link.confidence),link.mechanism,self.tenant_id,normalized,float(link.valid_from),link.valid_until)
        with self._lock:
            self._sqlite.execute("INSERT OR REPLACE INTO causal_links VALUES (?,?,?,?,?,?,?,?,?)", (current.cause_id,self.tenant_id,current.cause_ref,current.effect_ref,current.confidence,current.mechanism,_json(asdict(current.provenance)),current.valid_from,current.valid_until))
            self._sqlite.commit()
        self._record_change("causal.linked", current.cause_id, current.to_dict(), normalized)
        return current

    def causes_of(self, effect_ref: str, *, threshold: float = 0.0, limit: int = 100, principal: str = "system") -> list[CausalLink]:
        self._authorize("world.causality.read", principal)
        self._ensure_open()
        threshold = max(0.0, min(1.0, float(threshold)))
        with self._lock:
            rows = self._sqlite.execute("SELECT * FROM causal_links WHERE tenant_id=? AND effect_ref=? AND confidence>=? ORDER BY confidence DESC, valid_from DESC LIMIT ?", (self.tenant_id,effect_ref,threshold,_limit(limit))).fetchall()
        return [_causal_from_row(row) for row in rows]

    def causal_paths(self, effect_ref: str, *, max_depth: int = 6, threshold: float = 0.5, limit: int = 256, principal: str = "system") -> list[tuple[str, ...]]:
        max_depth = max(1, min(int(max_depth), MAX_PATH_DEPTH))
        frontier: list[tuple[str, tuple[str, ...]]] = [(str(effect_ref), (str(effect_ref),))]
        paths: list[tuple[str, ...]] = []
        while frontier and len(paths) < limit:
            node, path = frontier.pop(0)
            causes = self.causes_of(node, threshold=threshold, limit=64, principal=principal)
            if not causes or len(path) >= max_depth:
                paths.append(tuple(reversed(path)))
                continue
            for cause in causes:
                if cause.cause_ref in path:
                    paths.append(tuple(reversed(path + (cause.cause_ref,))))
                else:
                    frontier.append((cause.cause_ref, path + (cause.cause_ref,)))
        return paths[:limit]

    def add_prediction(self, prediction: PredictionRecord, *, principal: str = "system") -> PredictionRecord:
        self._authorize("world.prediction.write", principal)
        self._ensure_open()
        horizon = float(prediction.horizon_seconds)
        if not 0.0 <= horizon <= 31_536_000:
            raise ValueError("prediction horizon outside one-year safety bound")
        normalized = prediction.provenance.normalized(prediction.to_dict())
        current = PredictionRecord(prediction.prediction_id or f"pred_{uuid.uuid4().hex[:20]}",prediction.target_ref,prediction.predicted_value,float(prediction.predicted_at),horizon,_check_confidence(prediction.confidence),prediction.model_ref,self.tenant_id,prediction.source_snapshot,prediction.resolved_at,prediction.actual_value,prediction.outcome,normalized)
        with self._lock:
            self._sqlite.execute("INSERT OR REPLACE INTO predictions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", (current.prediction_id,self.tenant_id,current.target_ref,_json(current.predicted_value),current.predicted_at,current.horizon_seconds,current.confidence,current.model_ref,current.source_snapshot,current.resolved_at,_json(current.actual_value) if current.actual_value is not None else None,current.outcome,_json(asdict(current.provenance))))
            self._sqlite.commit()
        self._record_change("prediction.recorded", current.prediction_id, current.to_dict(), normalized)
        return current

    def resolve_prediction(self, prediction_id: str, actual_value: Any, *, outcome: str | None = None, principal: str = "system") -> PredictionRecord:
        self._authorize("world.prediction.write", principal)
        self._ensure_open()
        with self._lock:
            row = self._sqlite.execute("SELECT * FROM predictions WHERE tenant_id=? AND prediction_id=?", (self.tenant_id,prediction_id)).fetchone()
            if row is None:
                raise KeyError(prediction_id)
            predicted = json.loads(row["predicted_json"])
            status = outcome or ("correct" if predicted == actual_value else "incorrect")
            self._sqlite.execute("UPDATE predictions SET resolved_at=?,actual_json=?,outcome=? WHERE tenant_id=? AND prediction_id=?", (time.time(),_json(actual_value),status,self.tenant_id,prediction_id))
            self._sqlite.commit()
        return self.get_prediction(prediction_id, principal=principal)

    def get_prediction(self, prediction_id: str, *, principal: str = "system") -> PredictionRecord:
        self._authorize("world.prediction.read", principal)
        with self._lock:
            row = self._sqlite.execute("SELECT * FROM predictions WHERE tenant_id=? AND prediction_id=?", (self.tenant_id,prediction_id)).fetchone()
        if row is None:
            raise KeyError(prediction_id)
        return _prediction_from_row(row)

    def add_constraint(self, constraint: WorldConstraint, *, principal: str = "system") -> WorldConstraint:
        self._authorize("world.constraint.write", principal)
        self._ensure_open()
        normalized = constraint.provenance.normalized(constraint.to_dict())
        current = WorldConstraint(constraint.constraint_id or f"cst_{uuid.uuid4().hex[:20]}",constraint.name,constraint.constraint_type,dict(constraint.expression),str(constraint.severity),self.tenant_id,bool(constraint.enabled),normalized)
        with self._lock:
            self._sqlite.execute("INSERT OR REPLACE INTO constraints_v3 VALUES (?,?,?,?,?,?,?,?)", (current.constraint_id,self.tenant_id,current.name,current.constraint_type,_json(current.expression),current.severity,1 if current.enabled else 0,_json(asdict(current.provenance))))
            self._sqlite.commit()
        self._record_change("constraint.upserted", current.constraint_id, current.to_dict(), normalized)
        return current

    def list_constraints(self, *, enabled_only: bool = True, principal: str = "system") -> list[WorldConstraint]:
        self._authorize("world.constraint.read", principal)
        query = "SELECT * FROM constraints_v3 WHERE tenant_id=?" + (" AND enabled=1" if enabled_only else "") + " ORDER BY severity DESC,name ASC"
        with self._lock:
            rows = self._sqlite.execute(query, (self.tenant_id,)).fetchall()
        return [_constraint_from_row(row) for row in rows]

    def evaluate_constraint(self, constraint: WorldConstraint, *, principal: str = "system") -> ConstraintResult:
        expression = dict(constraint.expression)
        ctype = constraint.constraint_type
        if ctype == "entity_exists":
            ref = str(expression.get("entity_id", ""))
            ok = self.get_entity(ref, principal=principal) is not None
            return ConstraintResult(constraint.constraint_id, ok, constraint.severity, "entity exists" if ok else f"entity missing: {ref}")
        if ctype == "state_equals":
            ref = str(expression.get("entity_id", "")); key = str(expression.get("state_key", "")); expected = expression.get("value")
            current = self.current_state(ref, principal=principal).get(key)
            ok = current is not None and current.value == expected
            return ConstraintResult(constraint.constraint_id, ok, constraint.severity, "state matches" if ok else f"state mismatch: {ref}:{key}", {"actual": current.value if current else None, "expected": expected})
        if ctype == "relation_exists":
            source = str(expression.get("source_id", "")); target = str(expression.get("target_id", "")); rel = expression.get("relation")
            matches = [item for item in self.relations_for(source, direction="out", relation=str(rel) if rel else None, principal=principal) if item.target_id == target]
            return ConstraintResult(constraint.constraint_id, bool(matches), constraint.severity, "relation exists" if matches else "relation missing")
        if ctype == "confidence_min":
            entity = self.get_entity(str(expression.get("entity_id", "")), principal=principal)
            minimum = float(expression.get("minimum", 0.0)); actual = entity.confidence if entity else 0.0; ok = entity is not None and actual >= minimum
            return ConstraintResult(constraint.constraint_id, ok, constraint.severity, "confidence threshold satisfied" if ok else "confidence threshold violated", {"actual": actual, "minimum": minimum})
        raise ValueError(f"unsupported constraint type: {ctype}")

    def evaluate_constraints(self, *, principal: str = "system") -> tuple[ConstraintResult, ...]:
        return tuple(self.evaluate_constraint(item, principal=principal) for item in self.list_constraints(principal=principal))

    def record_tool_effect(self, tool_ref: str, result: Mapping[str, Any], *, entity_refs: Sequence[str] = (), provenance: Provenance | None = None, correlation_id: str | None = None, principal: str = "system") -> tuple[WorldChange, ...]:
        """Record structured P2-P/P2-Q side effects without guessing arbitrary state."""
        self._authorize("world.effect.write", principal)
        prov = provenance or Provenance(f"tool:{tool_ref}", producer="tool-fabric")
        changes = [self._record_change("tool.effect", str(ref), {"tool_ref": tool_ref, "result": dict(result), "correlation_id": correlation_id}, prov) for ref in entity_refs]
        if not changes:
            changes.append(self._record_change("tool.effect", str(tool_ref), {"tool_ref": tool_ref, "result": dict(result), "correlation_id": correlation_id}, prov))
        return tuple(changes)

    def record_plan_projection(self, plan_id: str, *, preconditions: Sequence[Mapping[str, Any]] = (), postconditions: Sequence[Mapping[str, Any]] = (), provenance: Provenance | None = None, principal: str = "system") -> WorldChange:
        self._authorize("world.plan.write", principal)
        prov = provenance or Provenance(f"plan:{plan_id}", producer="planning-engine")
        payload = {"plan_id": str(plan_id), "preconditions": [dict(item) for item in preconditions], "postconditions": [dict(item) for item in postconditions]}
        return self._record_change("plan.projected", str(plan_id), payload, prov)

    def ingest_memory_world_state(self, memory_item: Mapping[str, Any], *, principal: str = "system") -> WorldChange:
        """Promote P2-H world_state memory into the canonical world graph."""
        self._authorize("world.memory.ingest", principal)
        tenant = str(memory_item.get("tenant_id", self.tenant_id))
        if tenant != self.tenant_id:
            raise WorldAuthorizationError("cross-tenant memory ingestion denied")
        body = dict((memory_item.get("content") or {}).get("body") or {})
        entity_ref = str(body.get("entity_ref") or memory_item.get("memory_id") or "unknown")
        state_body = body.get("state_body")
        if isinstance(state_body, Mapping):
            for key, value in state_body.items():
                if self.get_entity(entity_ref, principal=principal) is not None:
                    self.observe_state(entity_ref, str(key), value, confidence=float(body.get("confidence", 1.0)), provenance=Provenance(f"memory:{memory_item.get('memory_id','unknown')}", source_type="memory", producer="experience-memory"), principal=principal)
        return self._record_change("memory.world_state.ingested", entity_ref, {"memory_id": memory_item.get("memory_id"), "entity_ref": entity_ref, "state_body": state_body}, Provenance(f"memory:{memory_item.get('memory_id','unknown')}", source_type="memory", producer="experience-memory"))

    def export_projection(self, *, include_history: bool = False, limit: int = 1000, principal: str = "system") -> dict[str, Any]:
        self._authorize("world.snapshot.read", principal)
        entities = [item.to_dict() for item in self.query_entities(limit=limit, principal=principal)]
        entity_ids = {str(item["entity_id"]) for item in entities}
        relations: list[dict[str, Any]] = []
        for entity_id in list(entity_ids)[:limit]:
            relations.extend(item.to_dict() for item in self.relations_for(entity_id, limit=min(100, limit), principal=principal))
        projection: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "tenant_id": self.tenant_id,
            "entities": entities,
            "relations": _dedupe_dicts(relations, "relation_id"),
            "constraints": [item.to_dict() for item in self.list_constraints(principal=principal)],
            "snapshot": self.snapshot(principal=principal).to_dict(),
        }
        if include_history:
            history: list[dict[str, Any]] = []
            for entity_id in list(entity_ids)[:limit]:
                history.extend(item.to_dict() for item in self.history(entity_id, limit=min(200, limit), principal=principal))
            projection["observations"] = history
        projection["digest"] = hashlib.sha256(_canonical_bytes(projection)).hexdigest()
        return projection

    def snapshot(self, *, principal: str = "system") -> WorldSnapshot3:
        self._authorize("world.snapshot.read", principal)
        self._ensure_open()
        with self._lock:
            counts = {}
            for key, table in (("entity_count","entities"),("relation_count","relations"),("observation_count","observations"),("transition_count","transitions"),("causal_count","causal_links"),("prediction_count","predictions"),("constraint_count","constraints_v3")):
                counts[key] = int(self._sqlite.execute(f"SELECT COUNT(*) FROM {table} WHERE tenant_id=?", (self.tenant_id,)).fetchone()[0])
            rows = self._sqlite.execute("SELECT entity_id,entity_type,name,version,status,confidence,updated_at,provenance_json FROM entities WHERE tenant_id=? ORDER BY entity_id LIMIT 512", (self.tenant_id,)).fetchall()
            relation_rows = self._sqlite.execute("SELECT relation_id,source_id,relation,target_id,version,status,confidence FROM relations WHERE tenant_id=? ORDER BY relation_id LIMIT 1024", (self.tenant_id,)).fetchall()
            current_rows = self._sqlite.execute("SELECT entity_id,state_key,value_json,valid_from,valid_until,confidence FROM observations WHERE tenant_id=? ORDER BY entity_id,state_key,valid_from DESC LIMIT 2048", (self.tenant_id,)).fetchall()
        payload = {
            "schema_version": SCHEMA_VERSION,
            "tenant_id": self.tenant_id,
            "entities": [dict(row) for row in rows],
            "relations": [dict(row) for row in relation_rows],
            "observations": [dict(row) for row in current_rows],
            "counts": counts,
            "sequence": self._sequence,
        }
        digest = hashlib.sha256(_canonical_bytes(payload)).hexdigest()
        return WorldSnapshot3(f"wms_{uuid.uuid4().hex[:20]}", self.tenant_id, time.time(), SCHEMA_VERSION, digest=digest, sequence=self._sequence, **counts)

    def changes_since(self, sequence: int = 0, *, limit: int = 500, principal: str = "system") -> list[WorldChange]:
        self._authorize("world.changes.read", principal)
        self._ensure_open()
        with self._lock:
            rows = self._sqlite.execute("SELECT * FROM change_log WHERE tenant_id=? AND sequence>? ORDER BY sequence ASC LIMIT ?", (self.tenant_id,int(sequence),_limit(limit))).fetchall()
        return [WorldChange(row["change_id"],row["kind"],row["ref"],row["tenant_id"],float(row["timestamp"]),json.loads(row["payload_json"]),_provenance_from_json(row["provenance_json"])) for row in rows]

    def health(self) -> dict[str, Any]:
        snap = self.snapshot()
        return {"status": "operational" if not self._closed else "closed", "schema_version": SCHEMA_VERSION, "tenant_id": self.tenant_id, "db_path": str(self.db_path), "snapshot": snap.to_dict()}

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            conn = self._sqlite
            self._sqlite = None
            self._closed = True
            conn.commit()
            conn.close()

    def __enter__(self) -> "WorldModel3":
        self._ensure_open()
        return self

    def __exit__(self, _exc_type: Any, _exc: Any, _tb: Any) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            if getattr(self, "_closed", True) is False:
                self.close()
        except Exception:
            logger.debug("WorldModel3 finalizer could not complete cleanup", exc_info=True)


def _provenance_from_json(raw: str) -> Provenance:
    data = json.loads(raw)
    data["evidence_refs"] = tuple(data.get("evidence_refs") or ())
    return Provenance(**data)


def _entity_from_row(row: sqlite3.Row) -> WorldEntity3:
    return WorldEntity3(str(row["entity_id"]),str(row["entity_type"]),str(row["name"]),json.loads(row["properties_json"]),str(row["tenant_id"]),str(row["status"]),int(row["version"]),float(row["confidence"]),json.loads(row["uncertainty_json"]),_provenance_from_json(row["provenance_json"]),float(row["created_at"]),float(row["updated_at"]),float(row["deleted_at"]) if row["deleted_at"] is not None else None)


def _relation_from_row(row: sqlite3.Row) -> WorldRelation3:
    return WorldRelation3(str(row["relation_id"]),str(row["source_id"]),str(row["relation"]),str(row["target_id"]),str(row["tenant_id"]),json.loads(row["properties_json"]),float(row["confidence"]),_provenance_from_json(row["provenance_json"]),float(row["valid_from"]),float(row["valid_until"]) if row["valid_until"] is not None else None,int(row["version"]),str(row["status"]))


def _observation_from_row(row: sqlite3.Row) -> WorldObservation:
    return WorldObservation(str(row["observation_id"]),str(row["entity_id"]),str(row["state_key"]),json.loads(row["value_json"]),str(row["tenant_id"]),float(row["valid_from"]),float(row["valid_until"]) if row["valid_until"] is not None else None,float(row["confidence"]),json.loads(row["uncertainty_json"]),_provenance_from_json(row["provenance_json"]),str(row["transition_id"]) if row["transition_id"] else None)


def _causal_from_row(row: sqlite3.Row) -> CausalLink:
    return CausalLink(str(row["cause_id"]),str(row["cause_ref"]),str(row["effect_ref"]),float(row["confidence"]),row["mechanism"],str(row["tenant_id"]),_provenance_from_json(row["provenance_json"]),float(row["valid_from"]),float(row["valid_until"]) if row["valid_until"] is not None else None)


def _prediction_from_row(row: sqlite3.Row) -> PredictionRecord:
    return PredictionRecord(str(row["prediction_id"]),str(row["target_ref"]),json.loads(row["predicted_json"]),float(row["predicted_at"]),float(row["horizon_seconds"]),float(row["confidence"]),str(row["model_ref"]),str(row["tenant_id"]),row["source_snapshot"],float(row["resolved_at"]) if row["resolved_at"] is not None else None,json.loads(row["actual_json"]) if row["actual_json"] is not None else None,str(row["outcome"]),_provenance_from_json(row["provenance_json"]))


def _constraint_from_row(row: sqlite3.Row) -> WorldConstraint:
    return WorldConstraint(str(row["constraint_id"]),str(row["name"]),str(row["constraint_type"]),json.loads(row["expression_json"]),str(row["severity"]),str(row["tenant_id"]),bool(row["enabled"]),_provenance_from_json(row["provenance_json"]))


def _dedupe_dicts(rows: Iterable[Mapping[str, Any]], key: str) -> list[dict[str, Any]]:
    seen: set[str] = set(); result: list[dict[str, Any]] = []
    for row in rows:
        value = str(row[key])
        if value in seen:
            continue
        seen.add(value); result.append(dict(row))
    return result


__all__ = [
    "SCHEMA_VERSION", "WorldModelError", "WorldModelClosedError", "WorldConflictError", "WorldAuthorizationError",
    "Provenance", "WorldEntity3", "WorldRelation3", "WorldObservation", "StateTransition", "CausalLink",
    "PredictionRecord", "WorldConstraint", "WorldSnapshot3", "ConstraintResult", "WorldChange", "WorldModel3",
]

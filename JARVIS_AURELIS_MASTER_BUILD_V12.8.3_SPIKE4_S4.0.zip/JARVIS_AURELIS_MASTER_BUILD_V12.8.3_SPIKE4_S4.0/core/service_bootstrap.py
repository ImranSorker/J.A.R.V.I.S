"""Dependency-injected service composition for the J.A.R.V.I.S. core."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping

logger = logging.getLogger("jarvis.service_bootstrap")


def initialize_services(core: Any, *, project_root: Path, reliability_cfg: Mapping[str, Any]) -> None:
    """Construct the service graph in dependency order and attach it to ``core``.

    The composition root remains explicit: foundational services are created first,
    durable job execution is built from those dependencies, then higher-level facades
    are attached. Initialization failures degrade only the affected optional service.
    """
    core._services = {}
    core.tool_service = None
    core.agent_service = None
    core.memory_service = None
    core.rag_service = None
    core.project_service = None
    core.settings_service = None
    core.system_service = None
    core.chat_service = None
    core.voice_service = None
    core.workflow_service = None
    core.mission_service = None
    core.job_engine = None
    core.job_service = None
    core.plugin_manager = None
    core.operator_service = None

    try:
        from services.tool_service import ToolService
        from services.agent_service import AgentService
        from services.memory_service import MemoryService
        from services.rag_service import RAGService
        from services.voice_service import VoiceService
        from services.workflow_service import WorkflowService
        from services.project_service import ProjectService
        from services.settings_service import SettingsService
        from services.system_service import SystemService
        from services.chat_service import ChatService
        from services.mission_service import MissionService
        from core.plugin_manager import PluginManager
        from services.operator_service import OperatorService

        factories = [
            ("tools", "tool_service", lambda: ToolService(core.registry)),
            ("agents", "agent_service", lambda: AgentService(core.task_manager, executor=core._execute_agent_task, policy_engine=core.agent_policies, workspace_root=core.guard.workspace, swarm=core.agent_swarm)),
            ("memory", "memory_service", lambda: MemoryService(core.memory, core.embedder)),
            ("rag", "rag_service", lambda: RAGService(
                core.rag3,
                core.memory,
                core.embedder,
                core.guard,
                provenance=getattr(core.supreme, "provenance", None),
            )),
            ("projects", "project_service", lambda: ProjectService(str(core.guard.workspace) if core.guard else "data/workspace")),
            ("settings", "settings_service", lambda: SettingsService(str(project_root / "config.json"), schema=getattr(core, "_config_schema", None))),
            ("system", "system_service", lambda: SystemService(core)),
            ("chat", "chat_service", lambda: ChatService(core.chat)),
            ("voice", "voice_service", lambda: VoiceService(core.stt, core.tts, getattr(core, "wake", None), core.chat)),
            ("workflow", "workflow_service", lambda: WorkflowService(core.workflows, core.tool_service, core.agent_service, persistence_dir=str(core.guard.workspace / "workflows"))),
            ("mission", "mission_service", lambda: MissionService(core.tool_service, core.agent_service, core.job_engine, core.autonomy_engine, core.autonomy_fabric, core.kernel)),
        ]

        for name, attr, factory in factories[:2]:
            try:
                service = factory()
                setattr(core, attr, service)
                core._services[name] = service
            except Exception as exc:
                core.logger.warning(f"{name}_service_init_failed", {"error": str(exc)})

        try:
            from core.job_engine import JobEngine, JobStore
            from services.job_service import JobService
            from core.dead_letter_queue import DeadLetterQueue
            from core.idempotency import IdempotencyStore

            if core.tool_service is None or core.agent_service is None:
                raise RuntimeError("tool and agent services must be initialized before job engine")
            raw_db_path = core.cfg.get("memory", {}).get("db_path") or "data/memory.db"
            db_path = Path(str(raw_db_path))
            jobs_db = db_path.parent / "jobs.db"
            core.job_engine = JobEngine(
                core.tool_service,
                core.agent_service,
                core.permission_engine,
                store=JobStore(str(jobs_db), crypto=core.crypto_store),
                schema_validator=core.schema_validator,
                concurrency=core.concurrency_quota,
                idempotency=IdempotencyStore(
                    str(db_path.parent / "idempotency.db"),
                    ttl_seconds=float(reliability_cfg.get("idempotency_ttl_seconds", 86400.0)),
                ),
                dlq=DeadLetterQueue(str(db_path.parent / "dlq.db")),
                circuit_breakers=core.circuit_breakers,
                resource_governor=getattr(getattr(core, "supreme", None), "resources", None),
            )
            core.job_service = JobService(core.job_engine)
            core._services["jobs"] = core.job_service
            core.logger.info("job_engine_initialized_v12_6_5", {"db_path": str(jobs_db)})
        except Exception as exc:
            core.logger.warning("job_engine_init_failed", {"error": str(exc)})

        for name, attr, factory in factories[2:]:
            try:
                service = factory()
                setattr(core, attr, service)
                core._services[name] = service
            except Exception as exc:
                core.logger.warning(f"{name}_service_init_failed", {"error": str(exc)})

        try:
            core.plugin_manager = PluginManager(str(project_root / "plugins"), capability_policy=getattr(getattr(core, "kernel", None), "policy", None))
            core.plugin_manager.set_tool_registry(core.registry)
        except Exception as exc:
            core.logger.warning("plugin_manager_init_failed", {"error": str(exc)})

        try:
            core.operator_service = OperatorService(core, core.universal_tasks, core.offline_commands, getattr(core, "frontier_control", None))
            core._services["operator"] = core.operator_service
        except Exception as exc:
            core.logger.warning("operator_service_init_failed", {"error": str(exc)})
    except ImportError as exc:
        core.logger.error("service_layer_import_failed", {"error": str(exc)})



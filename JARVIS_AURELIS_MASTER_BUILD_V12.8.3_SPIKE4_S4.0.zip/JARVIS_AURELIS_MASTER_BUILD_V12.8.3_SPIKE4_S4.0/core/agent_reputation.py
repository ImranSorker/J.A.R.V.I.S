"""Evidence-based agent reputation and reliability scoring."""
from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class AgentReputation:
    """Bounded agent performance profile."""

    agent_id: str
    attempts: int
    successes: int
    failures: int
    mean_latency_ms: float
    safety_score: float

    @property
    def success_rate(self) -> float:
        """Return a smoothed success probability."""
        return (self.successes + 1.0) / (self.attempts + 2.0)

    @property
    def score(self) -> float:
        """Return a conservative reliability score."""
        latency_factor = 1.0 / (1.0 + max(0.0, self.mean_latency_ms) / 1000.0)
        return max(0.0, min(1.0, 0.60 * self.success_rate + 0.30 * self.safety_score + 0.10 * latency_factor))


class AgentReputationStore:
    """Thread-safe bounded reputation ledger for agent routing decisions."""

    def __init__(self, *, max_agents: int = 1000) -> None:
        self.max_agents = max(1, min(int(max_agents), 10_000))
        self._stats: dict[str, dict[str, float]] = {}
        self._lock = threading.RLock()

    def observe(self, agent_id: str, *, success: bool, latency_ms: float, safety_score: float = 1.0) -> AgentReputation:
        """Update an agent profile using numerically stable running means."""
        name = str(agent_id).strip()
        if not name:
            raise ValueError("agent_id is required")
        safety = max(0.0, min(1.0, float(safety_score)))
        latency = max(0.0, float(latency_ms))
        with self._lock:
            if name not in self._stats and len(self._stats) >= self.max_agents:
                victim = min(self._stats, key=lambda key: self.reputation(key).score)
                del self._stats[victim]
            row = self._stats.setdefault(name, {"attempts": 0.0, "successes": 0.0, "failures": 0.0, "mean_latency_ms": 0.0, "safety_score": 1.0})
            attempts = row["attempts"] + 1.0
            row["attempts"] = attempts
            row["successes"] += 1.0 if success else 0.0
            row["failures"] += 0.0 if success else 1.0
            row["mean_latency_ms"] += (latency - row["mean_latency_ms"]) / attempts
            row["safety_score"] += (safety - row["safety_score"]) / attempts
            return self.reputation(name)

    def reputation(self, agent_id: str) -> AgentReputation:
        """Return an agent reputation, using a neutral profile when unseen."""
        with self._lock:
            row = self._stats.get(str(agent_id), {"attempts": 0.0, "successes": 0.0, "failures": 0.0, "mean_latency_ms": 0.0, "safety_score": 1.0})
            return AgentReputation(str(agent_id), int(row["attempts"]), int(row["successes"]), int(row["failures"]), row["mean_latency_ms"], row["safety_score"])

    def rank(self) -> list[AgentReputation]:
        """Return agents ordered by conservative score."""
        with self._lock:
            return sorted((self.reputation(agent_id) for agent_id in self._stats), key=lambda item: (-item.score, item.agent_id))

    def snapshot(self) -> dict[str, Any]:
        """Return non-sensitive reputation state."""
        return {"agents": [{"agent_id": item.agent_id, "attempts": item.attempts, "success_rate": item.success_rate, "safety_score": item.safety_score, "score": item.score} for item in self.rank()]}



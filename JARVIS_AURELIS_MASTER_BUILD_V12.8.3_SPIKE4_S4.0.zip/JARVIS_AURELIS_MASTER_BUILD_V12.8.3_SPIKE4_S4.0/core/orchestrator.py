"""Task orchestrator for agents and workflows."""
from __future__ import annotations
import logging
from typing import Optional
from core.model_swarm import ModelSwarm
from core.model_router import ModelRouter

logger = logging.getLogger("jarvis.orchestrator")


class Orchestrator:
    def __init__(self, swarm: ModelSwarm, router: Optional[ModelRouter] = None):
        self.swarm = swarm
        self.router = router

    def run_task(self, description: str, agent: Optional[str] = None) -> str:
        if self.router:
            result = self.router.generate(f"Execute task: {description}")
            return result.text if hasattr(result, "text") else str(result)
        return "[No router available]"



"""Bounded self-diagnosis and recovery orchestration."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger("jarvis.recovery_swarm")


@dataclass(frozen=True)
class RecoveryAttempt:
    """One verified recovery attempt."""

    incident_id: str
    strategy: str
    ok: bool
    started_at: float
    finished_at: float
    error: str | None = None


class RecoverySwarm:
    """Run bounded diagnosis/repair strategies with verification callbacks."""

    def __init__(self, max_attempts: int = 3) -> None:
        self.max_attempts = max(1, min(int(max_attempts), 10))
        self._history: list[RecoveryAttempt] = []
        self._lock = threading.RLock()

    def recover(self, incident: str, strategies: list[tuple[str, Callable[[str], Any]]], verify: Callable[[], bool]) -> dict[str, Any]:
        """Try repair strategies sequentially until verification succeeds."""
        incident_id = f"inc_{int(time.time() * 1000)}"
        attempts: list[dict[str, Any]] = []
        for index, (name, strategy) in enumerate(strategies[: self.max_attempts]):
            started = time.time()
            try:
                strategy(incident)
                ok = bool(verify())
                error = None
            except Exception as exc:
                ok = False
                error = str(exc)
                logger.warning("recovery_strategy_failed", extra={"strategy": name, "error": error})
            finished = time.time()
            record = RecoveryAttempt(incident_id, name, ok, started, finished, error)
            with self._lock:
                self._history.append(record)
                del self._history[:-1000]
            attempts.append({"strategy": name, "ok": ok, "error": error})
            if ok:
                return {"ok": True, "incident_id": incident_id, "attempts": attempts, "selected": name}
        return {"ok": False, "incident_id": incident_id, "attempts": attempts}

    def stats(self) -> dict[str, Any]:
        """Return recovery history metrics."""
        with self._lock:
            return {"attempts": len(self._history), "successful": sum(a.ok for a in self._history)}



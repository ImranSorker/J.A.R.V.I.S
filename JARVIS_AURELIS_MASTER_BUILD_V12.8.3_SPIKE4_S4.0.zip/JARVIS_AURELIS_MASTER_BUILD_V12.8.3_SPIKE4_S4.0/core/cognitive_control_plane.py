"""Integrated cognitive control-plane services for J.A.R.V.I.S.

The control plane unifies state, goals, prediction, mission resilience, agent
scheduling, provenance, observability, security correlation and resource-aware
routing behind deterministic, bounded, dependency-free contracts.
"""
from __future__ import annotations

import hashlib
import json
import math
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class CognitiveContext:
    """Immutable context snapshot used by one cognitive turn."""

    trace_id: str
    objective: str
    state: str
    uncertainty: float
    evidence: tuple[str, ...] = ()
    assumptions: tuple[str, ...] = ()
    blockers: tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)


@dataclass(frozen=True, slots=True)
class GoalNode:
    """A dependency-aware hierarchical goal."""

    goal_id: str
    description: str
    priority: int = 5
    dependencies: tuple[str, ...] = ()
    status: str = "pending"


@dataclass(frozen=True, slots=True)
class ResourceForecast:
    """Bounded resource forecast with a confidence estimate."""

    metric: str
    current: float
    slope_per_second: float
    horizon_seconds: float
    predicted: float
    confidence: float


@dataclass(frozen=True, slots=True)
class MissionCheckpoint:
    """Integrity-addressed mission checkpoint."""

    mission_id: str
    sequence: int
    state: Mapping[str, Any]
    digest: str
    created_at: float = field(default_factory=time.time)


@dataclass(frozen=True, slots=True)
class AgentScore:
    """Evidence-based agent suitability profile."""

    role: str
    success_rate: float
    mean_latency_ms: float
    sample_count: int
    score: float


@dataclass(frozen=True, slots=True)
class ProvenanceRecord:
    """Evidence record linking output claims to a source."""

    record_id: str
    claim: str
    source: str
    source_hash: str
    trust: float
    captured_at: float = field(default_factory=time.time)


@dataclass(frozen=True, slots=True)
class SecuritySignal:
    """Correlated security signal."""

    signal_id: str
    category: str
    severity: str
    score: float
    evidence: tuple[str, ...]
    created_at: float = field(default_factory=time.time)


@dataclass(frozen=True, slots=True)
class ResourcePolicy:
    """Resource policy weights for model/task selection."""

    quality_weight: float = 0.55
    latency_weight: float = 0.15
    memory_weight: float = 0.15
    power_weight: float = 0.10
    safety_weight: float = 0.05


class GoalPlanner:
    """Deterministic topological planner for hierarchical goals."""

    def __init__(self, max_goals: int = 10_000) -> None:
        self.max_goals = max(1, min(int(max_goals), 100_000))
        self._goals: dict[str, GoalNode] = {}
        self._lock = threading.RLock()

    def add(self, description: str, *, priority: int = 5, dependencies: Sequence[str] = ()) -> GoalNode:
        """Add a validated goal node."""
        text = str(description).strip()
        if not text:
            raise ValueError("goal description is required")
        with self._lock:
            if len(self._goals) >= self.max_goals:
                raise ValueError("goal capacity exceeded")
            deps = tuple(str(item) for item in dependencies)
            if any(dep not in self._goals for dep in deps):
                raise ValueError("goal dependency does not exist")
            node = GoalNode(f"goal_{uuid.uuid4().hex[:12]}", text, max(0, min(100, int(priority))), deps)
            self._goals[node.goal_id] = node
            self._assert_acyclic()
            return node

    def complete(self, goal_id: str) -> GoalNode:
        """Mark a goal complete only when all dependencies are complete."""
        with self._lock:
            node = self._require(goal_id)
            if any(self._require(dep).status != "completed" for dep in node.dependencies):
                raise RuntimeError("goal dependencies are incomplete")
            updated = GoalNode(node.goal_id, node.description, node.priority, node.dependencies, "completed")
            self._goals[goal_id] = updated
            return updated

    def next_actions(self, limit: int = 32) -> tuple[GoalNode, ...]:
        """Return ready goals sorted by priority and stable identity."""
        bound = max(1, min(int(limit), 1000))
        with self._lock:
            ready = [node for node in self._goals.values() if node.status == "pending" and all(self._require(dep).status == "completed" for dep in node.dependencies)]
            return tuple(sorted(ready, key=lambda node: (-node.priority, node.goal_id))[:bound])

    def snapshot(self) -> dict[str, Any]:
        """Return serializable goal state."""
        with self._lock:
            return {"count": len(self._goals), "goals": [asdict(self._goals[key]) for key in sorted(self._goals)]}

    def _require(self, goal_id: str) -> GoalNode:
        node = self._goals.get(str(goal_id))
        if node is None:
            raise KeyError(goal_id)
        return node

    def _assert_acyclic(self) -> None:
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(key: str) -> None:
            if key in visiting:
                raise ValueError("goal dependency cycle")
            if key in visited:
                return
            visiting.add(key)
            for dependency in self._goals[key].dependencies:
                visit(dependency)
            visiting.remove(key)
            visited.add(key)

        for key in tuple(self._goals):
            visit(key)


class MissionResilience:
    """Checkpoint, restore and deterministic mission recovery helper."""

    def __init__(self, max_checkpoints: int = 256) -> None:
        self.max_checkpoints = max(1, min(int(max_checkpoints), 10_000))
        self._items: dict[str, deque[MissionCheckpoint]] = defaultdict(lambda: deque(maxlen=self.max_checkpoints))
        self._lock = threading.RLock()

    @staticmethod
    def _digest(state: Mapping[str, Any]) -> str:
        raw = json.dumps(dict(state), sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def checkpoint(self, mission_id: str, state: Mapping[str, Any]) -> MissionCheckpoint:
        """Create and store an integrity-addressed checkpoint."""
        mission = str(mission_id).strip()
        if not mission:
            raise ValueError("mission_id is required")
        with self._lock:
            sequence = self._items[mission][-1].sequence + 1 if self._items[mission] else 1
            normalized = json.loads(json.dumps(dict(state), default=str))
            item = MissionCheckpoint(mission, sequence, normalized, self._digest(normalized))
            self._items[mission].append(item)
            return item

    def restore(self, mission_id: str, sequence: int | None = None) -> MissionCheckpoint:
        """Return a verified latest or selected checkpoint."""
        with self._lock:
            items = self._items.get(str(mission_id))
            if not items:
                raise KeyError(mission_id)
            item = items[-1] if sequence is None else next((x for x in items if x.sequence == int(sequence)), None)
            if item is None:
                raise KeyError(sequence)
            if self._digest(item.state) != item.digest:
                raise ValueError("mission checkpoint integrity failure")
            return item

    def snapshot(self) -> dict[str, Any]:
        """Return checkpoint counts."""
        with self._lock:
            return {"missions": len(self._items), "checkpoints": sum(len(v) for v in self._items.values())}


class AgentScheduler:
    """Adaptive agent scheduler using reputation and bounded resource constraints."""

    def __init__(self, *, max_concurrency: int = 8, max_history: int = 10_000) -> None:
        self.max_concurrency = max(1, min(int(max_concurrency), 64))
        self.max_history = max(1, min(int(max_history), 100_000))
        self._stats: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.RLock()

    def observe(self, role: str, success: bool, latency_ms: float) -> AgentScore:
        """Record one bounded outcome and return the updated role score."""
        name = str(role).strip()
        if not name:
            raise ValueError("role is required")
        latency = max(0.0, float(latency_ms))
        with self._lock:
            bucket = self._stats[name]
            bucket.extend((1.0 if success else 0.0, latency))
            max_values = self.max_history * 2
            if len(bucket) > max_values:
                del bucket[:-max_values]
            outcomes = bucket[0::2]
            latencies = bucket[1::2]
            success_rate = sum(outcomes) / max(1, len(outcomes))
            mean_latency = sum(latencies) / max(1, len(latencies))
            score = 0.75 * success_rate + 0.25 * (1.0 / (1.0 + mean_latency / 1000.0))
            return AgentScore(name, success_rate, mean_latency, len(outcomes), score)

    def rank(self, roles: Iterable[str]) -> tuple[AgentScore, ...]:
        """Rank candidate roles deterministically."""
        return tuple(sorted((self.score(role) for role in roles), key=lambda x: (-x.score, x.role)))

    def score(self, role: str) -> AgentScore:
        """Return current role score, using a conservative cold-start prior."""
        with self._lock:
            bucket = self._stats.get(str(role).strip(), [])
            outcomes = bucket[0::2]
            latencies = bucket[1::2]
            if not outcomes:
                return AgentScore(str(role).strip(), 0.5, 1000.0, 0, 0.5)
            success_rate = sum(outcomes) / len(outcomes)
            mean_latency = sum(latencies) / max(1, len(latencies))
            return AgentScore(str(role).strip(), success_rate, mean_latency, len(outcomes), 0.75 * success_rate + 0.25 / (1.0 + mean_latency / 1000.0))

    def snapshot(self) -> dict[str, Any]:
        """Return role scores."""
        return {"max_concurrency": self.max_concurrency, "agents": [asdict(item) for item in self.rank(self._stats.keys())]}


class ResourcePredictor:
    """Bounded online linear predictor for numeric system metrics."""

    def __init__(self, max_samples: int = 512) -> None:
        self.max_samples = max(8, min(int(max_samples), 100_000))
        self._series: dict[str, deque[tuple[float, float]]] = defaultdict(lambda: deque(maxlen=self.max_samples))
        self._lock = threading.RLock()

    def observe(self, metric: str, value: float, timestamp: float | None = None) -> None:
        """Record a numeric sample."""
        name = str(metric).strip()
        number = float(value)
        if not name or not math.isfinite(number):
            raise ValueError("metric and finite numeric value are required")
        with self._lock:
            self._series[name].append((float(timestamp if timestamp is not None else time.time()), number))

    def forecast(self, metric: str, horizon_seconds: float = 60.0) -> ResourceForecast:
        """Predict one metric using least-squares slope with confidence from sample count."""
        name = str(metric).strip()
        horizon = max(0.0, min(float(horizon_seconds), 86_400.0))
        with self._lock:
            points = list(self._series.get(name, ()))
        if not points:
            raise KeyError(name)
        current = points[-1][1]
        if len(points) < 2:
            return ResourceForecast(name, current, 0.0, horizon, current, 0.1)
        t0 = points[0][0]
        xs = [point[0] - t0 for point in points]
        ys = [point[1] for point in points]
        mean_x = sum(xs) / len(xs)
        mean_y = sum(ys) / len(ys)
        denominator = sum((x - mean_x) ** 2 for x in xs)
        slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denominator if denominator else 0.0
        predicted = current + slope * horizon
        confidence = min(1.0, 0.2 + 0.8 * min(1.0, len(points) / 32.0))
        return ResourceForecast(name, current, slope, horizon, predicted, confidence)

    def snapshot(self) -> dict[str, Any]:
        """Return latest values and available forecasts."""
        with self._lock:
            names = tuple(sorted(self._series))
        result: dict[str, Any] = {}
        for name in names:
            try:
                forecast = self.forecast(name)
                result[name] = asdict(forecast)
            except (KeyError, ValueError):
                continue
        return result


class ProvenanceLedger:
    """Append-only in-memory provenance ledger with tamper-evident chaining."""

    def __init__(self, max_records: int = 50_000) -> None:
        self.max_records = max(1, min(int(max_records), 500_000))
        self._records: deque[ProvenanceRecord] = deque(maxlen=self.max_records)
        self._previous_hash = "0" * 64
        self._lock = threading.RLock()

    def add(self, claim: str, source: str, *, trust: float = 1.0) -> ProvenanceRecord:
        """Add evidence and chain its source hash to the previous record."""
        text = str(claim).strip()
        origin = str(source).strip()
        if not text or not origin:
            raise ValueError("claim and source are required")
        score = max(0.0, min(1.0, float(trust)))
        source_hash = hashlib.sha256(f"{self._previous_hash}|{origin}".encode()).hexdigest()
        record = ProvenanceRecord(f"prov_{uuid.uuid4().hex[:16]}", text, origin, source_hash, score)
        with self._lock:
            self._records.append(record)
            self._previous_hash = hashlib.sha256(json.dumps(asdict(record), sort_keys=True).encode()).hexdigest()
        return record

    def verify(self) -> bool:
        """Verify the internal provenance chain."""
        with self._lock:
            previous = "0" * 64
            for record in self._records:
                expected_source = hashlib.sha256(f"{previous}|{record.source}".encode()).hexdigest()
                if record.source_hash != expected_source:
                    return False
                previous = hashlib.sha256(json.dumps(asdict(record), sort_keys=True).encode()).hexdigest()
            return True

    def search(self, query: str, limit: int = 20) -> tuple[ProvenanceRecord, ...]:
        """Search recent evidence by claim/source text."""
        needle = str(query).strip().lower()
        bound = max(1, min(int(limit), 1000))
        if not needle:
            return ()
        with self._lock:
            return tuple(record for record in reversed(self._records) if needle in f"{record.claim} {record.source}".lower())[:bound]


class PromptFirewall:
    """Classify external content and prevent data from becoming implicit instructions."""

    _INJECTION_MARKERS = (
        "ignore previous instructions",
        "ignore all previous instructions",
        "system prompt",
        "developer message",
        "reveal your instructions",
        "override policy",
        "disable safety",
        "jailbreak",
    )

    def inspect(self, content: str, *, source: str = "external") -> dict[str, Any]:
        """Return a deterministic trust assessment without executing content."""
        text = str(content or "")
        lowered = text.lower()
        hits = tuple(marker for marker in self._INJECTION_MARKERS if marker in lowered)
        risk = min(1.0, len(hits) * 0.2)
        if str(source).lower() in {"web", "browser", "document", "plugin"}:
            risk = min(1.0, risk + 0.1)
        return {"trusted": not hits, "risk": risk, "markers": hits, "source": str(source), "length": len(text)}

    def wrap_as_data(self, content: str, *, source: str = "external") -> str:
        """Delimiter-wrap untrusted content as data."""
        return f"<untrusted_data source={json.dumps(str(source))}>\n{str(content)}\n</untrusted_data>"


class SecurityCorrelator:
    """Correlate repeated security events into bounded signals."""

    _LEVELS = {"low": 0.2, "medium": 0.5, "high": 0.8, "critical": 1.0}

    def __init__(self, max_events: int = 10_000) -> None:
        self._events: deque[tuple[str, float, str]] = deque(maxlen=max(1, min(int(max_events), 100_000)))
        self._lock = threading.RLock()

    def observe(self, category: str, severity: str, *, evidence: str = "") -> SecuritySignal | None:
        """Observe an event and emit a correlation signal on repeated risk."""
        kind = str(category).strip() or "unknown"
        level = str(severity).strip().lower()
        score = self._LEVELS.get(level, 0.5)
        now = time.time()
        with self._lock:
            self._events.append((kind, now, str(evidence)))
            recent = [item for item in self._events if item[0] == kind and now - item[1] <= 300.0]
        if len(recent) < 3 and score < 0.8:
            return None
        aggregate = min(1.0, score + min(0.3, max(0, len(recent) - 1) * 0.05))
        severity_name = "critical" if aggregate >= 0.9 else "high" if aggregate >= 0.7 else "medium"
        evidence_items = tuple(dict.fromkeys(item[2] for item in recent if item[2]))[-8:]
        return SecuritySignal(f"sig_{uuid.uuid4().hex[:16]}", kind, severity_name, aggregate, evidence_items)

    def snapshot(self) -> dict[str, Any]:
        """Return bounded event counters."""
        with self._lock:
            counts: dict[str, int] = defaultdict(int)
            for category, _, _ in self._events:
                counts[category] += 1
        return {"events": sum(counts.values()), "categories": dict(sorted(counts.items()))}


class ExperimentRegistry:
    """Reproducible AI experiment registry for routing and model evaluation."""

    def __init__(self, max_runs: int = 10_000) -> None:
        self.max_runs = max(1, min(int(max_runs), 100_000))
        self._runs: deque[dict[str, Any]] = deque(maxlen=self.max_runs)
        self._lock = threading.RLock()

    def record(self, *, name: str, config: Mapping[str, Any], result: Mapping[str, Any]) -> str:
        """Record one reproducible experiment result."""
        run_id = f"exp_{uuid.uuid4().hex[:16]}"
        raw = json.dumps({"name": str(name), "config": dict(config), "result": dict(result)}, sort_keys=True, default=str)
        row = {"run_id": run_id, "name": str(name), "config": dict(config), "result": dict(result), "digest": hashlib.sha256(raw.encode()).hexdigest(), "created_at": time.time()}
        with self._lock:
            self._runs.append(row)
        return run_id

    def best(self, name: str, metric: str) -> dict[str, Any] | None:
        """Return the highest-scoring experiment by numeric result metric."""
        with self._lock:
            matches = [row for row in self._runs if row["name"] == str(name) and isinstance(row["result"].get(metric), (int, float))]
        return max(matches, key=lambda row: float(row["result"][metric]), default=None)

    def snapshot(self) -> dict[str, Any]:
        """Return registry summary."""
        with self._lock:
            return {"runs": len(self._runs), "names": sorted({str(row["name"]) for row in self._runs})}


class ResourceAwareSelector:
    """Select a model from measurable quality, latency, memory, power and safety data."""

    def __init__(self, policy: ResourcePolicy | None = None) -> None:
        self.policy = policy or ResourcePolicy()

    def score(self, candidate: Mapping[str, Any], *, available_memory_mb: float | None = None, power_budget_w: float | None = None) -> float:
        """Return a normalized selection score; hard constraints reject candidates."""
        memory = max(0.0, float(candidate.get("memory_mb", 0.0)))
        if available_memory_mb is not None and memory > max(0.0, float(available_memory_mb)):
            return float("-inf")
        power = max(0.0, float(candidate.get("power_w", 0.0)))
        if power_budget_w is not None and power > max(0.0, float(power_budget_w)):
            return float("-inf")
        quality = max(0.0, min(1.0, float(candidate.get("quality", candidate.get("quality_score", 0.5)))))
        safety = max(0.0, min(1.0, float(candidate.get("safety", 0.5))))
        latency = max(0.0, float(candidate.get("latency_ms", 1000.0)))
        latency_term = 1.0 / (1.0 + latency / 1000.0)
        memory_term = 1.0 / (1.0 + memory / 4096.0)
        power_term = 1.0 / (1.0 + power / 100.0)
        return self.policy.quality_weight * quality + self.policy.latency_weight * latency_term + self.policy.memory_weight * memory_term + self.policy.power_weight * power_term + self.policy.safety_weight * safety

    def choose(self, candidates: Iterable[Mapping[str, Any]], *, available_memory_mb: float | None = None, power_budget_w: float | None = None) -> Mapping[str, Any] | None:
        """Return the best admissible candidate."""
        ranked = [(self.score(candidate, available_memory_mb=available_memory_mb, power_budget_w=power_budget_w), candidate) for candidate in candidates]
        admissible = [item for item in ranked if math.isfinite(item[0])]
        if not admissible:
            return None
        admissible.sort(key=lambda item: (-item[0], str(item[1].get("name", ""))))
        return admissible[0][1]


class CognitiveControlPlane:
    """Unified stateful control plane composed from bounded cognition services."""

    def __init__(self, *, max_goals: int = 10_000, max_checkpoints: int = 256, max_agent_history: int = 10_000) -> None:
        self.goals = GoalPlanner(max_goals=max_goals)
        self.missions = MissionResilience(max_checkpoints=max_checkpoints)
        self.agents = AgentScheduler(max_history=max_agent_history)
        self.predictor = ResourcePredictor()
        self.provenance = ProvenanceLedger()
        self.firewall = PromptFirewall()
        self.security = SecurityCorrelator()
        self.experiments = ExperimentRegistry()
        self.selector = ResourceAwareSelector()
        self._state = "idle"
        self._context: CognitiveContext | None = None
        self._lock = threading.RLock()

    def begin(self, objective: str, *, evidence: Sequence[str] = (), assumptions: Sequence[str] = ()) -> CognitiveContext:
        """Begin a cognitive turn and create a bounded immutable context."""
        text = str(objective).strip()
        if not text:
            raise ValueError("objective is required")
        context = CognitiveContext(f"cog_{uuid.uuid4().hex[:16]}", text, "perceive", 0.5, tuple(evidence)[:32], tuple(assumptions)[:32])
        with self._lock:
            self._context = context
            self._state = "perceive"
        return context

    def transition(self, state: str, *, uncertainty: float | None = None, blockers: Sequence[str] = ()) -> CognitiveContext:
        """Transition the current cognitive context with a bounded uncertainty value."""
        target = str(state).strip().lower()
        if target not in {"perceive", "remember", "reason", "plan", "authorize", "act", "verify", "learn", "complete", "failed"}:
            raise ValueError("unsupported cognitive state")
        with self._lock:
            if self._context is None:
                raise RuntimeError("cognitive context is not initialized")
            score = self._context.uncertainty if uncertainty is None else max(0.0, min(1.0, float(uncertainty)))
            self._state = target
            self._context = CognitiveContext(self._context.trace_id, self._context.objective, target, score, self._context.evidence, self._context.assumptions, tuple(blockers)[:32], self._context.created_at)
            return self._context

    def observe_resource(self, metric: str, value: float) -> None:
        """Feed resource telemetry to the predictor."""
        self.predictor.observe(metric, value)

    def register_provenance(self, claim: str, source: str, *, trust: float = 1.0) -> ProvenanceRecord:
        """Record source evidence and preserve the provenance chain."""
        return self.provenance.add(claim, source, trust=trust)

    def snapshot(self) -> dict[str, Any]:
        """Return an integrated control-plane snapshot suitable for health APIs."""
        with self._lock:
            context = asdict(self._context) if self._context else None
            state = self._state
        return {
            "state": state,
            "context": context,
            "goals": self.goals.snapshot(),
            "missions": self.missions.snapshot(),
            "agents": self.agents.snapshot(),
            "resources": self.predictor.snapshot(),
            "provenance": {"valid": self.provenance.verify(), "records": len(self.provenance._records)},
            "security": self.security.snapshot(),
            "experiments": self.experiments.snapshot(),
        }



"""Central, replaceable capability registry for J.A.R.V.I.S."""
from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import logging
import platform
from typing import Callable

from core.contracts.capability import Capability

logger = logging.getLogger("jarvis.capabilities")


@dataclass(frozen=True, slots=True)
class CapabilityStatus:
    """Describes whether a runtime capability is currently available."""

    name: str
    available: bool
    detail: str = ""


class CapabilityRegistry:
    """Deterministic registry supporting both metadata and legacy probes."""

    def __init__(self) -> None:
        self._providers: dict[str, Callable[[], CapabilityStatus]] = {}
        self._metadata: dict[str, Capability] = {}
        self.register("python", lambda: CapabilityStatus("python", True, platform.python_version()))

    def register(
        self,
        name_or_capability: str | Capability,
        probe: Callable[[], CapabilityStatus] | None = None,
    ) -> None:
        """Register capability metadata or a legacy runtime probe."""
        if isinstance(name_or_capability, Capability):
            capability = name_or_capability
            self._metadata[capability.name] = capability
            if capability.implementation is not None and callable(capability.implementation):
                self._providers[capability.name] = lambda: CapabilityStatus(capability.name, capability.enabled, "implementation")
            elif capability.name not in self._providers:
                self._providers[capability.name] = lambda: CapabilityStatus(capability.name, capability.enabled, "registered")
            return
        if not name_or_capability or not callable(probe):
            raise ValueError("name and callable probe are required")
        self._providers[name_or_capability] = probe
        self._metadata.setdefault(name_or_capability, Capability(name=name_or_capability))

    def register_import(self, name: str, module: str) -> None:
        """Register an optional dependency backed by an import probe."""
        if not name or not module:
            raise ValueError("name and module are required")
        self.register(name, lambda: CapabilityStatus(name, importlib.util.find_spec(module) is not None, module))

    def check(self, name: str) -> CapabilityStatus:
        """Probe one capability without allowing provider failures to escape."""
        probe = self._providers.get(name)
        if probe is None:
            return CapabilityStatus(name, False, "unregistered")
        try:
            result = probe()
            if not isinstance(result, CapabilityStatus):
                return CapabilityStatus(name, bool(result))
            return result
        except Exception as exc:
            logger.exception("capability_probe_failed", extra={"capability": name})
            return CapabilityStatus(name, False, f"probe failed: {exc}")

    def get(self, name: str) -> Capability | None:
        """Return registered capability metadata."""
        return self._metadata.get(name)

    def list(self) -> list[str]:
        """Return deterministic capability names."""
        return sorted(self._metadata)

    def has(self, name: str) -> bool:
        """Return whether capability metadata is registered."""
        return name in self._metadata

    def snapshot(self) -> dict[str, CapabilityStatus]:
        """Return a point-in-time status snapshot."""
        return {name: self.check(name) for name in sorted(self._providers)}

    def supports(self, name: str) -> bool:
        """Return whether a capability is currently available."""
        return self.check(name).available



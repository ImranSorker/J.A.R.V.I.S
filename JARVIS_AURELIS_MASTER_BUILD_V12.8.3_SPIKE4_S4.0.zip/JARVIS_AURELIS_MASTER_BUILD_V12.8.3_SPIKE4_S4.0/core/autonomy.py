"""Autonomous mission authority with finite budgets and risk-aware decisions."""
from __future__ import annotations
import base64, enum, hashlib, hmac, logging, secrets, threading, time, uuid
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, Iterable, Optional
logger=logging.getLogger("jarvis.autonomy")
class AutonomyLevel(enum.IntEnum):
    OBSERVE=0; RECOMMEND=1; REVERSIBLE=2; BOUNDED=3; HIGH_IMPACT=4
@dataclass(frozen=True)
class AutonomyBudget:
    max_runtime_seconds: float=7200.0; max_agents:int=8; max_parallel_tasks:int=6; max_network_requests:int=500
    max_cpu_seconds:float=3600.0; max_memory_mb:int=8192; max_files_written:int=500; max_external_actions:int=20
    def validate(self)->None:
        if self.max_runtime_seconds<=0 or self.max_cpu_seconds<=0: raise ValueError("runtime and cpu budgets must be positive")
        for n in ("max_agents","max_parallel_tasks","max_network_requests","max_memory_mb","max_files_written","max_external_actions"):
            if int(getattr(self,n))<1: raise ValueError(f"{n} must be positive")
@dataclass
class MissionRuntime:
    mission_id:str; goal:str; level:AutonomyLevel; budget:AutonomyBudget; started_at:float=field(default_factory=time.monotonic)
    agents_spawned:int=0; parallel_tasks:int=0; network_requests:int=0; cpu_seconds:float=0.0; memory_mb:int=0; files_written:int=0; external_actions:int=0
    status:str="active"; metadata:Dict[str,Any]=field(default_factory=dict)
    def elapsed(self)->float:return time.monotonic()-self.started_at
class AutonomyDenied(PermissionError):
    """Raised when a mission exceeds its declared authority or budget."""
class AutonomyEngine:
    """Central policy engine for proactive autonomous work without per-action prompts."""
    RISK_MIN_LEVEL: ClassVar[Dict[str, AutonomyLevel]]={"observe":AutonomyLevel.OBSERVE,"recommend":AutonomyLevel.RECOMMEND,"reversible":AutonomyLevel.REVERSIBLE,"bounded":AutonomyLevel.BOUNDED,"high_impact":AutonomyLevel.HIGH_IMPACT,"critical":AutonomyLevel.HIGH_IMPACT}
    def __init__(self, level:AutonomyLevel=AutonomyLevel.BOUNDED, default_budget:Optional[AutonomyBudget]=None, *, default_level:Optional[AutonomyLevel]=None, default_capabilities:Iterable[str]=("*",))->None:
        self.level=AutonomyLevel(default_level if default_level is not None else level); self.default_budget=default_budget or AutonomyBudget(); self.default_budget.validate(); self.default_capabilities=tuple(str(x) for x in default_capabilities); self._missions={}; self._lock=threading.RLock(); self._grant_secret=secrets.token_bytes(32)
    def start_mission(self,goal:str,*,mission_id:Optional[str]=None,level:Optional[AutonomyLevel]=None,budget:Optional[AutonomyBudget]=None,metadata:Optional[Dict[str,Any]]=None,owner:Optional[str]=None,granted_capabilities:Optional[Iterable[str]]=None)->MissionRuntime:
        goal=str(goal or "").strip();
        if not goal: raise ValueError("mission goal cannot be empty")
        chosen=budget or self.default_budget; chosen.validate();
        mid=mission_id or f"auto_{uuid.uuid4().hex[:12]}"
        meta=dict(metadata or {})
        meta.setdefault("granted_capabilities", list(granted_capabilities if granted_capabilities is not None else self.default_capabilities))
        if owner: meta["owner"]=owner
        m=MissionRuntime(mid,goal,AutonomyLevel(level if level is not None else self.level),chosen,metadata=meta)
        with self._lock:self._missions[m.mission_id]=m
        logger.info("autonomous_mission_started",extra={"mission_id":m.mission_id}); return m
    def finish_mission(self,mission_id:str,success:bool,**metadata:Any)->None:
        with self._lock:
            m=self._missions.get(mission_id)
            if not m:return
            m.status="completed" if success else "failed"; m.metadata.update(metadata)
        logger.info("autonomous_mission_finished",extra={"mission_id":mission_id,"success":success})
    def get_mission(self,mission_id:str)->Optional[MissionRuntime]:
        with self._lock:return self._missions.get(mission_id)
    def authorize(self,mission_id:str,*,action:str,irreversible:bool=False,external:bool=False,required_capabilities:Iterable[str]=(),granted_capabilities:Iterable[str]=())->None:
        with self._lock:
            m=self._missions.get(mission_id)
            if not m or m.status!="active":raise AutonomyDenied("mission is not active")
            if m.elapsed()>m.budget.max_runtime_seconds:m.status="expired";raise AutonomyDenied("mission runtime budget exceeded")
            minimum=self.RISK_MIN_LEVEL.get(action,AutonomyLevel.HIGH_IMPACT)
            if irreversible or external:minimum=max(minimum,AutonomyLevel.HIGH_IMPACT)
            if m.level<minimum:raise AutonomyDenied(f"autonomy level {m.level.name} is insufficient for {action}")
            granted=set(granted_capabilities)
            if "*" not in granted and not set(required_capabilities).issubset(granted):raise AutonomyDenied("mission capability budget does not cover requested capabilities")
            capability_set = set(required_capabilities)
            if any(cap.startswith(("network", "web")) for cap in capability_set) or action.startswith(("network", "web")):
                if m.network_requests >= m.budget.max_network_requests:
                    raise AutonomyDenied("network budget exhausted")
            if any(cap in {"filesystem.write", "filesystem.modify", "system.modify"} for cap in capability_set):
                if m.files_written >= m.budget.max_files_written:
                    raise AutonomyDenied("filesystem budget exhausted")
            if any(cap in {"process.spawn", "code.execute"} for cap in capability_set):
                if m.parallel_tasks >= m.budget.max_parallel_tasks:
                    raise AutonomyDenied("parallel-task budget exhausted")
            if any(cap.startswith("agent.") for cap in capability_set):
                if m.agents_spawned >= m.budget.max_agents:
                    raise AutonomyDenied("agent budget exhausted")
            if external or irreversible:
                if m.external_actions >= m.budget.max_external_actions:
                    raise AutonomyDenied("external-action budget exhausted")
    def consume(self,mission_id:str,**delta:int|float)->None:
        with self._lock:
            m=self._missions.get(mission_id)
            if not m or m.status!="active":raise AutonomyDenied("mission is not active")
            for key,value in delta.items():
                if not hasattr(m,key):raise ValueError(f"unknown mission counter {key}")
                setattr(m,key,getattr(m,key)+value)
            if m.network_requests>m.budget.max_network_requests or m.external_actions>m.budget.max_external_actions or m.files_written>m.budget.max_files_written or m.parallel_tasks>m.budget.max_parallel_tasks or m.agents_spawned>m.budget.max_agents or m.cpu_seconds>m.budget.max_cpu_seconds or m.memory_mb>m.budget.max_memory_mb:raise AutonomyDenied("mission resource budget exceeded")
    def issue_execution_grant(self, mission_id:str, capability:str, principal:str, ttl_seconds:int=60)->str:
        """Issue a short-lived cryptographic execution delegation for an active mission."""
        if not capability or not principal or not 1 <= int(ttl_seconds) <= 300:
            raise ValueError("invalid execution grant parameters")
        with self._lock:
            mission=self._missions.get(mission_id)
            if mission is None or mission.status!="active":
                raise AutonomyDenied("mission is not active")
            granted=set(mission.metadata.get("granted_capabilities", self.default_capabilities))
            if "*" not in granted and capability not in granted:
                raise AutonomyDenied("mission capability budget does not cover requested capability")
        expires=int(time.time())+int(ttl_seconds)
        raw=f"{mission_id}:{principal}:{capability}:{expires}".encode("utf-8")
        sig=hmac.new(self._grant_secret,raw,hashlib.sha256).hexdigest()
        return base64.urlsafe_b64encode(raw+b":"+sig.encode("ascii")).decode("ascii")

    def verify_execution_grant(self, token:str, mission_id:str, capability:str, principal:str)->bool:
        """Verify an execution delegation without consuming or reusing a user token."""
        try:
            raw=base64.urlsafe_b64decode(token.encode("ascii"))
            mission,token_principal,token_capability,expires_str,sig=raw.decode("utf-8").split(":",4)
            expires=int(expires_str)
        except (ValueError,UnicodeError,TypeError):
            return False
        if mission!=mission_id or token_principal!=principal or token_capability!=capability or expires<int(time.time()):
            return False
        expected=hmac.new(self._grant_secret,raw.rsplit(b":",1)[0],hashlib.sha256).hexdigest()
        with self._lock:
            mission_state=self._missions.get(mission_id)
            return bool(mission_state and mission_state.status=="active" and hmac.compare_digest(sig,expected))

    def active_missions(self)->list[MissionRuntime]:
        with self._lock:return [m for m in self._missions.values() if m.status=="active"]
    def snapshot(self)->Dict[str,Any]:
        with self._lock:return {"level":self.level.name,"active":len(self.active_missions()),"missions":[m.__dict__.copy() for m in self._missions.values()]}



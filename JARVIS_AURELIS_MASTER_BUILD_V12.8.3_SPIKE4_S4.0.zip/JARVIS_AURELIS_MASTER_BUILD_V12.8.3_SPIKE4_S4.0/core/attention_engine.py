"""Deterministic attention prioritization for autonomous events."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class AttentionItem:
    """An event scored for user/system attention."""
    event_id: str
    importance: float
    urgency: float
    relevance: float
    safety_impact: float

    def __post_init__(self) -> None:
        for value in (self.importance, self.urgency, self.relevance, self.safety_impact):
            if not 0.0 <= value <= 1.0:
                raise ValueError("attention dimensions must be between 0 and 1")

    @property
    def score(self) -> float:
        """Return a bounded weighted attention score."""
        return round((self.importance * 0.25 + self.urgency * 0.30 + self.relevance * 0.20 + self.safety_impact * 0.25), 6)

    @property
    def level(self) -> str:
        """Return the least privilege notification level."""
        if self.safety_impact >= 0.9 or self.score >= 0.85:
            return "critical"
        if self.score >= 0.65:
            return "high"
        if self.score >= 0.40:
            return "medium"
        return "low"

class AttentionEngine:
    """Rank bounded event attention without executing actions."""
    def rank(self, items: list[AttentionItem]) -> list[AttentionItem]:
        """Return items in deterministic priority order."""
        return sorted(items, key=lambda item: (-item.score, item.event_id))



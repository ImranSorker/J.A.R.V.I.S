"""Transactional missions, undo/compensation and crash-safe recovery."""
from __future__ import annotations

import json
import sqlite3
import threading
from dataclasses import asdict, dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping

from .canonical import digest
from .contracts import RecoveryClass
from .ids import Clock, uuid7


class MissionState(StrEnum):
    PLANNED = "planned"
    AUTHORIZED = "authorized"
    STARTED = "started"
    COMPLETED = "completed"
    VERIFIED = "verified"
    COMPENSATED = "compensated"
    FAILED = "failed"
    CANCELLED = "cancelled"


_TERMINAL = {MissionState.VERIFIED.value, MissionState.COMPENSATED.value, MissionState.FAILED.value, MissionState.CANCELLED.value}


@dataclass(frozen=True, slots=True)
class UndoRecord:
    action_id: str
    original_operation: str
    precondition_digest: str
    before_state_digest: str
    after_state_digest: str | None
    recovery_class: RecoveryClass
    inverse_operation: str | None
    inverse_arguments: Mapping[str, Any]
    authorization_requirement: str
    expires_at: float | None
    idempotency_key: str


class UndoExecutor:
    """Persist recovery records and execute authorized inverses exactly once."""

    def __init__(self, *, db_path: str | Path = "data/kernel_12_8_0_missions.db", max_records: int = 50_000) -> None:
        self.max_records = max(100, min(int(max_records), 1_000_000))
        self.db_path = str(Path(db_path).resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA busy_timeout=20000")
        self._db.execute("CREATE TABLE IF NOT EXISTS undo_records(action_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,updated_at REAL NOT NULL)")
        self._db.execute("CREATE TABLE IF NOT EXISTS undo_results(action_id TEXT PRIMARY KEY,result_json TEXT NOT NULL,updated_at REAL NOT NULL)")
        self._db.commit()
        self._lock = threading.RLock()

    def _load(self, action_id: str) -> UndoRecord | None:
        row = self._db.execute("SELECT payload_json FROM undo_records WHERE action_id=?", (str(action_id),)).fetchone()
        if row is None:
            return None
        data = json.loads(row[0])
        data["recovery_class"] = RecoveryClass(data["recovery_class"])
        return UndoRecord(**data)

    def register(
        self,
        original_operation: str,
        *,
        before_state: Any,
        inverse_operation: str | None,
        inverse_arguments: Mapping[str, Any] | None,
        recovery_class: RecoveryClass,
        authorization_requirement: str = "operator.approval",
        expiry_seconds: float | None = None,
        idempotency_key: str | None = None,
    ) -> UndoRecord:
        if recovery_class in {RecoveryClass.REVERSIBLE, RecoveryClass.COMPENSATABLE} and not inverse_operation:
            raise ValueError("reversible/compensatable actions require an inverse operation")
        action_id = uuid7()
        now = Clock.wall()
        expires = None if expiry_seconds is None else now + max(1.0, float(expiry_seconds))
        record = UndoRecord(action_id, str(original_operation), digest({"before": before_state}), digest(before_state), None, recovery_class, inverse_operation, dict(inverse_arguments or {}), str(authorization_requirement), expires, str(idempotency_key or action_id))
        with self._lock:
            count = int(self._db.execute("SELECT COUNT(*) FROM undo_records").fetchone()[0])
            if count >= self.max_records:
                self._db.execute("DELETE FROM undo_records WHERE action_id IN (SELECT action_id FROM undo_records ORDER BY updated_at LIMIT ?)", (max(1, count - self.max_records + 1),))
            self._db.execute("INSERT INTO undo_records VALUES(?,?,?)", (action_id, json.dumps(asdict(record), sort_keys=True, separators=(",", ":"), default=str), now))
            self._db.commit()
        return record

    def finalize(self, action_id: str, after_state: Any) -> UndoRecord:
        with self._lock:
            record = self._load(action_id)
            if record is None:
                raise KeyError(action_id)
            if record.after_state_digest is not None:
                raise RuntimeError("undo record already finalized")
            updated = UndoRecord(**{**asdict(record), "after_state_digest": digest(after_state)})
            self._db.execute("UPDATE undo_records SET payload_json=?,updated_at=? WHERE action_id=?", (json.dumps(asdict(updated), sort_keys=True, separators=(",", ":"), default=str), Clock.wall(), str(action_id)))
            self._db.commit()
            return updated

    def execute(self, action_id: str, *, current_state: Any, inverse: Callable[[Mapping[str, Any]], Any], authorized: bool) -> Any:
        key = str(action_id)
        with self._lock:
            cached = self._db.execute("SELECT result_json FROM undo_results WHERE action_id=?", (key,)).fetchone()
            if cached is not None:
                return json.loads(cached[0])
            record = self._load(key)
        if record is None:
            raise KeyError("unknown undo action")
        if not authorized:
            raise PermissionError("undo authorization required")
        if record.recovery_class not in {RecoveryClass.REVERSIBLE, RecoveryClass.COMPENSATABLE}:
            raise PermissionError(f"action recovery class is {record.recovery_class.value}")
        if record.after_state_digest is None:
            raise RuntimeError("undo action has not been finalized")
        if record.expires_at is not None and Clock.wall() >= record.expires_at:
            raise PermissionError("undo record expired")
        if digest(current_state) != record.after_state_digest:
            raise RuntimeError("external state diverged; refusing blind rollback")
        if not callable(inverse):
            raise TypeError("inverse operation must be callable")
        result = inverse(record.inverse_arguments)
        if digest(result) != record.before_state_digest:
            raise RuntimeError("inverse operation did not restore the recorded state")
        with self._lock:
            self._db.execute("INSERT OR IGNORE INTO undo_results VALUES(?,?,?)", (key, json.dumps(result, sort_keys=True, separators=(",", ":"), default=str), Clock.wall()))
            self._db.commit()
        return result

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()


class MissionWAL:
    """SQLite-backed mission log implementing a durable Saga state machine."""

    def __init__(self, db_path: str | Path = "data/kernel_12_8_0_missions.db") -> None:
        self.db_path = str(Path(db_path).resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA busy_timeout=20000")
        self._db.execute("CREATE TABLE IF NOT EXISTS missions(mission_id TEXT PRIMARY KEY,state TEXT NOT NULL,payload_json TEXT NOT NULL,revision INTEGER NOT NULL,updated_at REAL NOT NULL)")
        self._db.execute("CREATE TABLE IF NOT EXISTS mission_steps(mission_id TEXT NOT NULL,step_id TEXT NOT NULL,state TEXT NOT NULL,sequence INTEGER PRIMARY KEY AUTOINCREMENT,payload_json TEXT NOT NULL,revision INTEGER NOT NULL,updated_at REAL NOT NULL,UNIQUE(mission_id,step_id))")
        self._db.commit()

    def upsert(self, mission_id: str, state: MissionState | str, payload: Mapping[str, Any]) -> int:
        normalized_state = state if isinstance(state, MissionState) else MissionState(str(state))
        with self._lock:
            current = self._db.execute("SELECT revision FROM missions WHERE mission_id=?", (str(mission_id),)).fetchone()
            revision = 1 if current is None else int(current[0]) + 1
            self._db.execute(
                "INSERT INTO missions(mission_id,state,payload_json,revision,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(mission_id) DO UPDATE SET state=excluded.state,payload_json=excluded.payload_json,revision=excluded.revision,updated_at=excluded.updated_at",
                (str(mission_id), normalized_state.value, json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str), revision, Clock.wall()),
            )
            self._db.commit()
            return revision

    def record_step(self, mission_id: str, step_id: str, state: MissionState | str, payload: Mapping[str, Any]) -> int:
        normalized_state = state if isinstance(state, MissionState) else MissionState(str(state))
        with self._lock:
            current = self._db.execute("SELECT revision FROM mission_steps WHERE mission_id=? AND step_id=?", (str(mission_id), str(step_id))).fetchone()
            revision = 1 if current is None else int(current[0]) + 1
            self._db.execute(
                "INSERT INTO mission_steps(mission_id,step_id,state,payload_json,revision,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(mission_id,step_id) DO UPDATE SET state=excluded.state,payload_json=excluded.payload_json,revision=excluded.revision,updated_at=excluded.updated_at",
                (str(mission_id), str(step_id), normalized_state.value, json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str), revision, Clock.wall()),
            )
            self._db.commit()
            return revision

    def restore(self, mission_id: str) -> dict[str, Any] | None:
        with self._lock:
            mission = self._db.execute("SELECT state,payload_json,revision,updated_at FROM missions WHERE mission_id=?", (str(mission_id),)).fetchone()
            steps = self._db.execute("SELECT step_id,state,payload_json,revision,updated_at FROM mission_steps WHERE mission_id=? ORDER BY sequence", (str(mission_id),)).fetchall()
        if mission is None:
            return None
        return {
            "mission_id": str(mission_id),
            "state": mission[0],
            "payload": json.loads(mission[1]),
            "revision": mission[2],
            "updated_at": mission[3],
            "steps": [{"step_id": r[0], "state": r[1], "payload": json.loads(r[2]), "revision": r[3], "updated_at": r[4]} for r in steps],
        }

    def resumable(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._db.execute("SELECT mission_id,state,payload_json,revision,updated_at FROM missions WHERE state NOT IN (?,?,?,?) ORDER BY updated_at DESC LIMIT ?", tuple(_TERMINAL) + (max(1, min(int(limit), 1000)),)).fetchall()
        return [{"mission_id": r[0], "state": r[1], "payload": json.loads(r[2]), "revision": r[3], "updated_at": r[4]} for r in rows]

    def resume_point(self, mission_id: str) -> str | None:
        state = self.restore(mission_id)
        if state is None:
            return None
        for step in reversed(state["steps"]):
            if step["state"] in {MissionState.COMPLETED.value, MissionState.VERIFIED.value, MissionState.COMPENSATED.value}:
                return str(step["step_id"])
        return None

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()


class HardCancellation:
    """Hierarchical cancellation registry for mission, agent and tool scopes."""

    def __init__(self) -> None:
        self._cancelled: set[str] = set()
        self._parents: dict[str, str] = {}
        self._lock = threading.RLock()

    def register_child(self, child_id: str, parent_id: str) -> None:
        child, parent = str(child_id), str(parent_id)
        if child == parent:
            raise ValueError("cancellation scope cannot be its own parent")
        with self._lock:
            cursor = parent
            seen = {child}
            while cursor in self._parents:
                if cursor in seen:
                    raise ValueError("cancellation scope cycle")
                seen.add(cursor)
                cursor = self._parents[cursor]
            self._parents[child] = parent

    def cancel(self, scope_id: str) -> None:
        with self._lock:
            self._cancelled.add(str(scope_id))

    def is_cancelled(self, scope_id: str) -> bool:
        scope = str(scope_id)
        with self._lock:
            cursor: str | None = scope
            while cursor is not None:
                if cursor in self._cancelled:
                    return True
                cursor = self._parents.get(cursor)
            return False

    def guard(self, scope_id: str) -> None:
        if self.is_cancelled(scope_id):
            raise RuntimeError(f"operation cancelled: {scope_id}")

    def clear(self, scope_id: str) -> None:
        with self._lock:
            self._cancelled.discard(str(scope_id))



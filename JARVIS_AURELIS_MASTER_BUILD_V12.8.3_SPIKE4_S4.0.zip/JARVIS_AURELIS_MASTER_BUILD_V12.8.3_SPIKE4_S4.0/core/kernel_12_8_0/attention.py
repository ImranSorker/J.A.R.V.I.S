"""Resource-aware attention scheduling for the 12.8.0 cognition control plane."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from .resource import ResourceLedger


@dataclass(frozen=True, slots=True)
class AttentionBudget:
    """Bounded attention allocation for one mission."""
    mission_id: str
    urgency: float
    max_tokens: int
    max_notifications: int
    interruptible: bool = True

    def __post_init__(self) -> None:
        if not 0.0 <= float(self.urgency) <= 1.0:
            raise ValueError("urgency must be within 0..1")
        if self.max_tokens < 0 or self.max_notifications < 0:
            raise ValueError("attention budgets cannot be negative")


class AttentionBudgetEngine:
    """Schedule attention budgets against the canonical resource ledger."""

    def __init__(self, resources: ResourceLedger) -> None:
        self.resources = resources

    def prioritize(self, budgets: Iterable[AttentionBudget]) -> list[AttentionBudget]:
        rows = list(budgets)
        return sorted(rows, key=lambda item: (-item.urgency, -item.max_tokens, item.mission_id))

    def reserve(self, budget: AttentionBudget, *, owner: str) -> str:
        lease = self.resources.reserve(owner, budget.mission_id, {"tokens": float(budget.max_tokens), "notifications": float(budget.max_notifications)}, ttl_seconds=300.0)
        return lease.lease_id



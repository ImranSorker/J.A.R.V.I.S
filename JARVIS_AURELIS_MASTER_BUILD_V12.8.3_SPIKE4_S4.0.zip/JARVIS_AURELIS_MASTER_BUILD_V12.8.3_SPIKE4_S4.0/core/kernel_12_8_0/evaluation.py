"""Deterministic trajectory evaluation, loop detection and replay metadata."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, asdict
from typing import Any, Callable, Iterable, Mapping

from .canonical import digest


@dataclass(frozen=True, slots=True)
class LoopFinding:
    kind: str
    repeated_state: str
    occurrences: int
    action: str


@dataclass(frozen=True, slots=True)
class TrajectoryGrade:
    task_completion: bool
    plan_adherence: bool
    tool_correctness: bool
    argument_correctness: bool
    policy_adherence: bool
    verification: bool
    recovery: bool
    safety_violations: int
    loop_findings: tuple[LoopFinding, ...]
    mutation_count: int
    evidence_coverage: float
    resource_cost: Mapping[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {"task_completion": self.task_completion, "plan_adherence": self.plan_adherence, "tool_correctness": self.tool_correctness, "argument_correctness": self.argument_correctness, "policy_adherence": self.policy_adherence, "verification": self.verification, "recovery": self.recovery, "safety_violations": self.safety_violations, "loop_findings": [asdict(f) for f in self.loop_findings], "mutation_count": self.mutation_count, "evidence_coverage": self.evidence_coverage, "resource_cost": dict(self.resource_cost)}  # type: ignore[attr-defined]


class MissionLoopDetector:
    """Detect repeated states and no-progress cycles deterministically."""

    def detect(self, trajectory: Iterable[Mapping[str, Any]], *, threshold: int = 3) -> tuple[LoopFinding, ...]:
        events = [dict(e) for e in trajectory]; threshold = max(2, int(threshold)); findings: list[LoopFinding] = []
        states: dict[str, int] = {}; actions: dict[str, str] = {}; signatures: dict[str, int] = {}; progress = 0
        for event in events:
            state = digest(event.get("observation", event.get("state", {})))
            states[state] = states.get(state, 0) + 1
            actions[state] = str(event.get("action", event.get("operation", "unknown")))
            call_sig = digest({"tool": event.get("tool"), "arguments": event.get("arguments")}) if event.get("tool") else ""
            if call_sig:
                signatures[call_sig] = signatures.get(call_sig, 0) + 1
            progress += int(bool(event.get("progress", False)))
        for state, count in states.items():
            if count >= threshold:
                findings.append(LoopFinding("state-cycle", state, count, actions[state]))
        for signature, count in signatures.items():
            if count >= threshold:
                findings.append(LoopFinding("repeated-tool-call", signature, count, "tool"))
        if events and progress == 0 and len(events) >= threshold:
            findings.append(LoopFinding("no-progress", hashlib.sha256(b"no-progress").hexdigest(), len(events), "mission"))
        return tuple(findings)


class TrajectoryGrader:
    """Grade a mission trajectory on independent evidence dimensions."""

    def grade(self, events: Iterable[Mapping[str, Any]]) -> TrajectoryGrade:
        rows = [dict(e) for e in events]
        kinds = {str(e.get("stage", e.get("event", ""))).lower() for e in rows}
        evidence = sum(1 for e in rows if e.get("evidence_id") or e.get("evidence"))
        return TrajectoryGrade(
            task_completion=bool(rows) and any(e.get("result_ok") is True or str(e.get("stage", "")).lower() in {"completed", "verified"} for e in rows),
            plan_adherence=any(s in kinds for s in {"plan", "planned"}),
            tool_correctness=all(e.get("tool_ok", True) for e in rows),
            argument_correctness=all(e.get("args_ok", True) for e in rows),
            policy_adherence=all(e.get("policy_ok", True) for e in rows),
            verification=any(s in kinds for s in {"verify", "verified"}),
            recovery=any(s in kinds for s in {"rollback", "recovered", "compensated"}),
            safety_violations=sum(1 for e in rows if bool(e.get("security_violation"))),
            loop_findings=MissionLoopDetector().detect(rows),
            mutation_count=sum(1 for e in rows if bool(e.get("mutated"))),
            evidence_coverage=0.0 if not rows else evidence / len(rows),
            resource_cost={"tokens": float(sum(float(e.get("tokens", 0)) for e in rows)), "cpu_seconds": float(sum(float(e.get("cpu_seconds", 0)) for e in rows)), "latency_ms": float(sum(float(e.get("latency_ms", 0)) for e in rows))},
        )


@dataclass(frozen=True, slots=True)
class ReplayDiff:
    same_result: bool
    same_policy: bool
    same_toolchain: bool
    original_digest: str
    replay_digest: str
    drift: tuple[str, ...]


class DeterministicMissionReplay:
    """Compare recorded mission material against a replay result."""

    def replay(self, recorded: Mapping[str, Any], executor: Callable[[Mapping[str, Any]], Mapping[str, Any]]) -> ReplayDiff:
        replayed = dict(executor(recorded))
        original = dict(recorded.get("result", {}))
        original_policy = dict(recorded.get("policy", {}))
        replay_policy = dict(replayed.get("policy", {}))
        original_tools = dict(recorded.get("toolchain", {}))
        replay_tools = dict(replayed.get("toolchain", {}))
        drift: list[str] = []
        if digest(original) != digest(replayed.get("result", {})): drift.append("result")
        if digest(original_policy) != digest(replay_policy): drift.append("policy")
        if digest(original_tools) != digest(replay_tools): drift.append("toolchain")
        return ReplayDiff(not "result" in drift, not "policy" in drift, not "toolchain" in drift, digest(original), digest(replayed.get("result", {})), tuple(drift))



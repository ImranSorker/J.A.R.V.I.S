"""WASI Component Model admission and runtime adapter for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import hashlib
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .canonical import canonical_bytes, digest
from .process import run_fixed
from .capability_policy import CapabilityPolicy
from .identity import AgentIdentityAuthority
from .contracts import CapabilityRequest
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class SkillManifest:
    skill_id: str
    publisher: str
    version: str
    artifact_sha256: str
    runtime: str
    imports: tuple[str, ...]
    exports: tuple[str, ...]
    filesystem: tuple[str, ...]
    network: tuple[str, ...]
    memory_mb: int
    cpu_seconds: float
    fuel: int
    capabilities: tuple[str, ...]
    provenance: str
    signature_b64: str = ""
    signer_key_id: str = ""
    signer_public_key_b64: str = ""

    def unsigned(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature_b64", None)
        return value

    def sign(self, authority: AgentIdentityAuthority) -> "SkillManifest":
        """Sign the manifest with the kernel skill trust authority."""
        import base64
        from cryptography.hazmat.primitives import serialization

        public_b64 = base64.b64encode(
            authority.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        ).decode("ascii")
        unsigned = SkillManifest(
            **{
                **asdict(self),
                "signature_b64": "",
                "signer_key_id": authority.key_id,
                "signer_public_key_b64": public_b64,
            }
        )
        signature = base64.b64encode(authority.sign_bytes(canonical_bytes(unsigned.unsigned()))).decode("ascii")
        return SkillManifest(**{**asdict(unsigned), "signature_b64": signature})

    @property
    def manifest_digest(self) -> str:
        return digest(self.unsigned())


@dataclass(frozen=True, slots=True)
class WASIExecutionResult:
    execution_id: str
    return_code: int
    stdout: str
    stderr: str
    duration_ms: float


class WASIComponentRuntime:
    """Pinned-runtime facade that fails closed when Wasmtime is unavailable."""

    VERSION = "12.8.0"
    WASI_TARGET = "0.3.1"

    def __init__(self, policy: CapabilityPolicy, authority: AgentIdentityAuthority | None = None) -> None:
        self.policy = policy
        self.authority = authority

    @staticmethod
    def runtime_available() -> bool:
        return shutil.which("wasmtime") is not None

    @staticmethod
    def artifact_digest(path: str | Path) -> str:
        data = Path(path).read_bytes()
        return hashlib.sha256(data).hexdigest()

    def admit(self, manifest: SkillManifest, *, approved: bool = False) -> None:
        if manifest.runtime.lower() != "wasi-component":
            raise PermissionError("skill runtime is not a WASI component")
        if self.authority is None:
            raise PermissionError("WASI skill trust authority is not configured")
        if not manifest.signature_b64 or manifest.signer_key_id != self.authority.key_id:
            raise PermissionError("WASI skill signature is missing or untrusted")
        try:
            import base64
            from cryptography.hazmat.primitives import serialization
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

            signer_raw = base64.b64decode(manifest.signer_public_key_b64, validate=True)
            public = Ed25519PublicKey.from_public_bytes(signer_raw)
            public.verify(
                base64.b64decode(manifest.signature_b64, validate=True),
                canonical_bytes(manifest.unsigned()),
            )
            authority_raw = self.authority.public_key.public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            )
            if signer_raw != authority_raw:
                raise PermissionError("WASI skill signer key mismatch")
        except PermissionError:
            raise
        except Exception as exc:
            raise PermissionError(f"WASI skill signature verification failed: {type(exc).__name__}") from exc
        if manifest.memory_mb <= 0 or manifest.memory_mb > 262_144 or manifest.cpu_seconds <= 0 or manifest.cpu_seconds > 3_600 or manifest.fuel <= 0:
            raise ValueError("invalid WASI resource bounds")
        for capability in manifest.capabilities:
            decision = self.policy.evaluate(CapabilityRequest(capability), approved=approved)
            if not decision.allowed:
                raise PermissionError(f"skill capability denied: {capability}")
        if not self.runtime_available():
            raise RuntimeError("WASI runtime unavailable; skill execution blocked")
        self._validate_host_capabilities(manifest)

    @staticmethod
    def _validate_host_capabilities(manifest: SkillManifest) -> None:
        """Fail closed when the CLI adapter cannot enforce declared host capabilities."""
        if manifest.network:
            raise PermissionError("WASI network declarations require an embedding runtime with explicit egress policy")
        if manifest.filesystem:
            raise PermissionError("WASI filesystem declarations require an embedding runtime with explicit preopen permissions")

    def execute(self, component_path: str | Path, manifest: SkillManifest, *, args: Sequence[str] = (), approved: bool = False) -> WASIExecutionResult:
        path = Path(component_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        if self.artifact_digest(path) != manifest.artifact_sha256:
            raise PermissionError("WASI skill artifact digest mismatch")
        self.admit(manifest, approved=approved)
        start = __import__("time").monotonic()
        command = ["wasmtime", "run", "--fuel", str(manifest.fuel), str(path), *map(str, args)]
        try:
            proc = run_fixed(command, allowed_executables=("wasmtime",), timeout=max(1.0, manifest.cpu_seconds))
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError("WASI component execution timed out") from exc
        return WASIExecutionResult(uuid7(), int(proc.returncode), proc.stdout[:1_048_576], proc.stderr[:1_048_576], (__import__("time").monotonic() - start) * 1000.0)



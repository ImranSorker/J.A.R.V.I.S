"""Artifact, model, skill and release provenance primitives."""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from .canonical import canonical_json
from .ids import uuid7


SECRET_PATTERNS = (
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"\bghp_[A-Za-z0-9]{30,}\b"),
    re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}\b"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"),
    re.compile(r"(?i)\b(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"]{16,}['\"]"),
)


@dataclass(frozen=True, slots=True)
class SecretFinding:
    path: str
    line: int
    pattern: str


class SecretScanner:
    """High-confidence secret scanner for source, configs and artifacts."""

    def scan_path(self, root: str | Path) -> tuple[SecretFinding, ...]:
        root_path = Path(root).resolve(); findings: list[SecretFinding] = []
        paths = [root_path] if root_path.is_file() else [p for p in root_path.rglob("*") if p.is_file() and p.stat().st_size <= 5_000_000 and ".git" not in p.parts and "__pycache__" not in p.parts]
        for path in paths:
            try: text = path.read_text(encoding="utf-8", errors="ignore")
            except OSError: continue
            for line_no, line in enumerate(text.splitlines(), 1):
                for pattern in SECRET_PATTERNS:
                    if pattern.search(line) and not re.search(r"(?i)(example|sample|placeholder|changeme|your[_-]?(api[_-]?key|token|secret))", line):
                        findings.append(SecretFinding(str(path), line_no, pattern.pattern[:80]))
        return tuple(findings)


@dataclass(frozen=True, slots=True)
class ArtifactManifest:
    artifact_id: str
    path: str
    sha256: str
    media_type: str
    size_bytes: int
    metadata: dict[str, Any]


class ArtifactVerifier:
    """Hash and structurally inspect common JARVIS model/artifact formats."""

    def inspect(self, path: str | Path) -> ArtifactManifest:
        p = Path(path).resolve(); data = p.read_bytes(); sha = hashlib.sha256(data).hexdigest(); suffix = p.suffix.lower(); media = "application/octet-stream"; meta: dict[str, Any] = {}
        if suffix == ".gguf":
            if not data.startswith(b"GGUF"): raise ValueError("invalid GGUF magic")
            media = "application/x-gguf"
        elif suffix == ".safetensors":
            if len(data) < 8: raise ValueError("invalid safetensors file")
            header_len = int.from_bytes(data[:8], "little", signed=False)
            if header_len <= 0 or header_len > len(data) - 8 or header_len > 100_000_000: raise ValueError("invalid safetensors header length")
            header = json.loads(data[8:8 + header_len].decode("utf-8"));
            if not isinstance(header, dict): raise ValueError("invalid safetensors header")
            media = "application/safetensors"; meta["tensor_count"] = len([k for k in header if k != "__metadata__"])
        elif suffix in {".pkl", ".pickle"}:
            raise ValueError("pickle model serialization is forbidden")
        return ArtifactManifest(f"artifact_{uuid7()}", str(p), sha, media, len(data), meta)


def generate_sbom(root: str | Path, *, version: str = "12.8.0") -> dict[str, Any]:
    root_path = Path(root).resolve(); components: list[dict[str, Any]] = []
    for path in sorted(p for p in root_path.rglob("*") if p.is_file() and ".git" not in p.parts):
        if path.stat().st_size > 25_000_000: continue
        components.append({"type": "file", "name": path.relative_to(root_path).as_posix(), "hashes": [{"alg": "SHA-256", "content": hashlib.sha256(path.read_bytes()).hexdigest()}]})
    return {"bomFormat": "CycloneDX", "specVersion": "1.6", "version": 1, "metadata": {"component": {"type": "application", "name": "J.A.R.V.I.S.", "version": version}}, "components": components}


def generate_ml_bom(models: Iterable[ArtifactManifest]) -> dict[str, Any]:
    components = [{"type": "machine-learning-model", "bom-ref": item.artifact_id, "name": Path(item.path).name, "version": "unversioned", "hashes": [{"alg": "SHA-256", "content": item.sha256}], "properties": [{"name": k, "value": str(v)} for k, v in item.metadata.items()]} for item in models]
    return {"bomFormat": "CycloneDX", "specVersion": "1.6", "version": 1, "components": components}


def generate_provenance(*, artifact_sha256: str, source: str, build_id: str, inputs: dict[str, str]) -> dict[str, Any]:
    return {"_type": "https://in-toto.io/Statement/v1", "subject": [{"name": "jarvis-12.8.0", "digest": {"sha256": artifact_sha256}}], "predicateType": "https://slsa.dev/provenance/v1", "predicate": {"buildDefinition": {"buildType": "https://jarvis.local/build/12.8.0", "externalParameters": {"source": source, "inputs": inputs}}, "runDetails": {"builder": {"id": "jarvis-12.8.0-local-builder"}, "metadata": {"buildInvocationId": build_id}}}}


def tool_version(binary: str) -> str | None:
    """Return the first version line from an optional external verifier."""
    try:
        proc = run_fixed([binary, "--version"], allowed_executables=(Path(binary).name,), timeout=3.0)
    except (OSError, PermissionError, ValueError):
        return None
    return (proc.stdout or proc.stderr).strip().splitlines()[0] if (proc.stdout or proc.stderr).strip() else None



"""Default-deny least-privilege policy and attenuation for 12.8.0."""
from __future__ import annotations

import fnmatch
import hashlib
import json
from dataclasses import dataclass
from .contracts import CapabilityRequest
from .ids import Clock, uuid7


@dataclass(frozen=True, slots=True)
class Decision:
    allowed: bool
    reason: str
    decision_id: str
    expires_at: float | None = None
    requires_approval: bool = False


class CapabilityPolicy:
    """Evaluate capabilities without ever broadening a request."""

    def __init__(self, allow: list[str] | tuple[str, ...] | None = None, approval_required: list[str] | tuple[str, ...] | None = None) -> None:
        self.allow = tuple(str(x) for x in (allow or ()))
        self.approval_required = tuple(str(x) for x in (approval_required or ("process.*", "system.*", "filesystem.write", "network.connect", "browser.*", "camera.*", "microphone.*")))

    def digest(self) -> str:
        """Return a deterministic digest of the live policy configuration."""
        material = {"allow": list(self.allow), "approval_required": list(self.approval_required)}
        return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()

    def evaluate(self, request: CapabilityRequest, *, approved: bool = False, now: float | None = None) -> Decision:
        cap = request.capability.strip()
        decision_id = uuid7()
        if not cap:
            return Decision(False, "empty capability", decision_id)
        if not any(fnmatch.fnmatch(cap, pattern) for pattern in self.allow):
            return Decision(False, f"capability denied by default policy: {cap}", decision_id)
        needs_approval = any(fnmatch.fnmatch(cap, pattern) for pattern in self.approval_required)
        if needs_approval and not approved:
            return Decision(False, f"explicit approval required for {cap}", decision_id, requires_approval=True)
        ttl = max(1, min(int(request.ttl_seconds), 3600))
        return Decision(True, "allowed", decision_id, (now or Clock.wall()) + ttl)



"""Central fixed-executable process boundary for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Mapping, Sequence, TextIO


def _resolve_executable(executable: str) -> str | None:
    value = str(executable).strip()
    if not value or "\x00" in value:
        return None
    path = Path(value)
    if path.is_absolute():
        return str(path) if path.is_file() else None
    return shutil.which(value)


def _validate_argv(argv: Sequence[str], allowed_executables: Sequence[str]) -> tuple[str, ...]:
    args = tuple(str(value) for value in argv)
    if not args or len(args) > 128 or any("\x00" in value or len(value) > 16_384 for value in args):
        raise ValueError("invalid process arguments")
    executable = _resolve_executable(args[0])
    if executable is None:
        raise FileNotFoundError(args[0])
    allowed = {Path(str(item)).name.lower() for item in allowed_executables if str(item).strip()}
    if Path(executable).name.lower() not in allowed:
        raise PermissionError("executable is not allowlisted for this process boundary")
    return (executable, *args[1:])


def run_fixed(
    argv: Sequence[str],
    *,
    allowed_executables: Sequence[str],
    cwd: str | Path | None = None,
    env: Mapping[str, str] | None = None,
    timeout: float = 30.0,
    capture_output: bool = True,
) -> subprocess.CompletedProcess[str]:
    """Run a fixed, explicitly allow-listed executable with shell execution forbidden."""
    timeout_value = float(timeout)
    if timeout_value <= 0 or timeout_value > 3600:
        raise ValueError("process timeout is outside the bounded range")
    command = _validate_argv(argv, allowed_executables)
    if cwd is not None:
        cwd_path = Path(cwd).resolve()
        if not cwd_path.is_dir():
            raise NotADirectoryError(cwd_path)
        cwd = str(cwd_path)
    merged_env = None if env is None else {str(k): str(v) for k, v in env.items() if str(k) and "\x00" not in str(k) and "\x00" not in str(v)}
    return subprocess.run(
        command,
        cwd=cwd,
        env=merged_env,
        capture_output=capture_output,
        text=True,
        timeout=timeout_value,
        check=False,
        shell=False,
    )


def spawn_fixed(
    argv: Sequence[str],
    *,
    allowed_executables: Sequence[str],
    cwd: str | Path,
    env: Mapping[str, str],
    stdin: int | TextIO,
    stdout: int | TextIO,
    stderr: int | TextIO,
    start_new_session: bool = False,
    creationflags: int = 0,
) -> subprocess.Popen[str]:
    """Spawn an allow-listed executable with a constrained, shell-free interface."""
    command = _validate_argv(argv, allowed_executables)
    cwd_path = Path(cwd).resolve()
    if not cwd_path.is_dir():
        raise NotADirectoryError(cwd_path)
    if os.name == "posix" and not start_new_session:
        raise PermissionError("POSIX sandbox children must start in their own process group")
    merged_env = {str(k): str(v) for k, v in env.items() if str(k) and "\x00" not in str(k) and "\x00" not in str(v)}
    return subprocess.Popen(
        command,
        cwd=str(cwd_path),
        env=merged_env,
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        shell=False,
        start_new_session=bool(start_new_session),
        creationflags=int(creationflags),
        text=False,
    )



"""Sender-constrained credentials for the J.A.R.V.I.S. 12.8.0 trust plane."""
from __future__ import annotations

import base64
import fnmatch
import hashlib
import time
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .canonical import canonical_bytes, digest
from .identity import AgentIdentity, AgentIdentityAuthority, ReplayCache
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class BoundCredential:
    """Signed, audience-bound delegated credential with explicit expiry."""

    credential_id: str
    issuer: str
    subject: str
    audience: str
    key_id: str
    capabilities: tuple[str, ...]
    issued_at: float
    expires_at: float
    signature_b64: str = ""

    def unsigned(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature_b64", None)
        return value


@dataclass(frozen=True, slots=True)
class ProofOfPossession:
    """Per-request proof binding a credential to method, URI, nonce and time."""

    credential_id: str
    method: str
    uri: str
    nonce: str
    issued_at: float
    signature_b64: str


class SenderConstrainedCredentialAuthority:
    """Issue and verify least-privilege credentials and proof-of-possession records."""

    def __init__(self, authority: AgentIdentityAuthority | None = None) -> None:
        self.authority = authority or AgentIdentityAuthority()
        self.replay = ReplayCache(max_entries=100_000)

    def issue(
        self,
        subject: AgentIdentity,
        *,
        audience: str,
        capabilities: tuple[str, ...],
        ttl_seconds: float = 300.0,
    ) -> BoundCredential:
        now = time.time()
        if not self.authority.verify(subject, audience=subject.audience, now=now):
            raise PermissionError("subject identity is not trusted")
        requested = tuple(sorted({str(cap).strip() for cap in capabilities if str(cap).strip()}))
        if not requested:
            raise ValueError("credential capabilities are required")
        if any(not any(fnmatch.fnmatch(cap, allowed) for allowed in subject.capabilities) for cap in requested):
            raise PermissionError("credential cannot broaden subject capabilities")
        ttl = max(1.0, min(float(ttl_seconds), max(1.0, subject.expires_at - now)))
        unsigned = BoundCredential(
            credential_id=f"cred_{uuid7()}",
            issuer=self.authority.issuer,
            subject=subject.agent_id,
            audience=str(audience),
            key_id=self.authority.key_id,
            capabilities=requested,
            issued_at=now,
            expires_at=now + ttl,
        )
        signature = base64.b64encode(self.authority.sign_bytes(canonical_bytes(unsigned.unsigned()))).decode("ascii")
        return BoundCredential(**{**asdict(unsigned), "signature_b64": signature})

    def verify(self, credential: BoundCredential, *, audience: str, capability: str | None = None, now: float | None = None) -> bool:
        current = time.time() if now is None else float(now)
        if credential.issuer != self.authority.issuer or credential.audience != str(audience):
            return False
        if not credential.issued_at <= current < credential.expires_at:
            return False
        if capability is not None and not any(fnmatch.fnmatch(str(capability), allowed) for allowed in credential.capabilities):
            return False
        if credential.key_id != self.authority.key_id:
            return False
        try:
            self.authority.public_key.verify(base64.b64decode(credential.signature_b64, validate=True), canonical_bytes(credential.unsigned()))
        except Exception:
            return False
        return True

    def create_proof(self, credential: BoundCredential, *, method: str, uri: str, subject: AgentIdentity) -> ProofOfPossession:
        if subject.agent_id != credential.subject or not self.verify(credential, audience=credential.audience):
            raise PermissionError("credential and subject do not match")
        nonce = uuid7()
        material = {
            "credential_id": credential.credential_id,
            "method": str(method).upper(),
            "uri": str(uri),
            "nonce": nonce,
            "issued_at": time.time(),
        }
        signature = base64.b64encode(self.authority.sign_as(subject, canonical_bytes(material))).decode("ascii")
        return ProofOfPossession(signature_b64=signature, **material)

    def verify_proof(self, credential: BoundCredential, proof: ProofOfPossession, *, audience: str, now: float | None = None, max_age_seconds: float = 300.0) -> bool:
        current = time.time() if now is None else float(now)
        if proof.credential_id != credential.credential_id or not self.verify(credential, audience=audience, now=current):
            return False
        if abs(current - float(proof.issued_at)) > max(1.0, min(float(max_age_seconds), 900.0)):
            return False
        material = {
            "credential_id": proof.credential_id,
            "method": str(proof.method).upper(),
            "uri": str(proof.uri),
            "nonce": proof.nonce,
            "issued_at": proof.issued_at,
        }
        try:
            record = self.authority.agent_public_key(credential.subject)
            if record is None:
                return False
            record[1].verify(base64.b64decode(proof.signature_b64, validate=True), canonical_bytes(material))
        except Exception:
            return False
        return self.replay.consume(digest(material), expires_at=min(credential.expires_at, current + max(1.0, float(max_age_seconds))))



"""Cryptographically segregated memory records and contradiction resolution."""
from __future__ import annotations

import hashlib
import hmac
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .canonical import canonical_json, canonical_bytes
from .contracts import EvidenceClass
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class MemoryRecord:
    memory_id: str
    memory_type: str
    owner: str
    workspace: str
    session_id: str
    source: str
    content_digest: str
    authority: str
    privacy_domain: str
    version: int
    created_at: float
    observed_at: float
    expires_at: float | None
    evidence_class: EvidenceClass
    metadata: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class Claim:
    claim_id: str
    statement: str
    source: str
    authority: str
    observed_at: float
    confidence: float
    status: str


class MemoryFabric:
    """SQLite memory store using per-record data keys wrapped by a master namespace key."""

    def __init__(self, secret: bytes, db_path: str | Path = "data/kernel_12_8_0_memory.db") -> None:
        if len(secret) < 32: raise ValueError("memory secret must be at least 32 bytes")
        self._master = hashlib.sha256(secret).digest(); self.db_path = str(Path(db_path).resolve()); Path(self.db_path).parent.mkdir(parents=True, exist_ok=True); self._lock = threading.RLock()
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False); self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL"); self._db.execute("PRAGMA secure_delete=ON")
        self._db.execute("CREATE TABLE IF NOT EXISTS records(memory_id TEXT PRIMARY KEY,owner TEXT,workspace TEXT,session_id TEXT,memory_type TEXT,source TEXT,authority TEXT,privacy_domain TEXT,version INTEGER,created_at REAL,observed_at REAL,expires_at REAL,evidence_class TEXT,metadata_json TEXT,content_cipher BLOB,wrapped_key BLOB,content_digest TEXT)")
        self._db.execute("CREATE TABLE IF NOT EXISTS tombstones(memory_id TEXT PRIMARY KEY,deleted_at REAL,reason TEXT)"); self._db.commit()

    def _domain_key(self, privacy_domain: str) -> bytes:
        return hmac.new(self._master, str(privacy_domain).encode("utf-8"), hashlib.sha256).digest()

    def _encrypt(self, domain: str, content: str) -> tuple[bytes, bytes]:
        key = __import__("secrets").token_bytes(32); nonce = __import__("secrets").token_bytes(12); cipher = nonce + AESGCM(key).encrypt(nonce, content.encode(), None)
        wrap_nonce = __import__("secrets").token_bytes(12); wrapped = wrap_nonce + AESGCM(self._domain_key(domain)).encrypt(wrap_nonce, key, None); return cipher, wrapped

    def _decrypt(self, domain: str, cipher: bytes, wrapped: bytes) -> str:
        key = AESGCM(self._domain_key(domain)).decrypt(wrapped[:12], wrapped[12:], None); return AESGCM(key).decrypt(cipher[:12], cipher[12:], None).decode()

    def put(self, *, content: str, memory_type: str, owner: str, workspace: str, session_id: str, source: str, privacy_domain: str, authority: str = "local", evidence_class: EvidenceClass = EvidenceClass.OBSERVED, metadata: Mapping[str, Any] | None = None, retention_seconds: float | None = None, version: int = 1) -> MemoryRecord:
        if not content.strip(): raise ValueError("memory content cannot be empty")
        rid = uuid7(); now = time.time(); expires = None if retention_seconds is None else now + max(60.0, float(retention_seconds)); cipher, wrapped = self._encrypt(privacy_domain, content)
        record = MemoryRecord(rid, str(memory_type), str(owner), str(workspace), str(session_id), str(source), hashlib.sha256(content.encode()).hexdigest(), str(authority), str(privacy_domain), max(1, int(version)), now, now, expires, evidence_class, dict(metadata or {}))
        integrity = hmac.new(self._master, canonical_bytes({"record": {"memory_id": rid, "content_digest": record.content_digest, "owner": record.owner, "workspace": record.workspace, "privacy_domain": record.privacy_domain, "version": record.version, "evidence_class": record.evidence_class.value}}), hashlib.sha256).hexdigest()
        meta = dict(record.metadata); meta["integrity"] = integrity
        with self._lock:
            self._db.execute("INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (record.memory_id,record.owner,record.workspace,record.session_id,record.memory_type,record.source,record.authority,record.privacy_domain,record.version,record.created_at,record.observed_at,record.expires_at,record.evidence_class.value,canonical_json(meta).decode(),cipher,wrapped,record.content_digest)); self._db.commit()
        return record

    def get(self, memory_id: str, *, owner: str, workspace: str, privacy_domain: str) -> tuple[MemoryRecord, str] | None:
        with self._lock: row = self._db.execute("SELECT memory_id,owner,workspace,session_id,memory_type,source,authority,privacy_domain,version,created_at,observed_at,expires_at,evidence_class,metadata_json,content_cipher,wrapped_key,content_digest FROM records WHERE memory_id=?", (str(memory_id),)).fetchone()
        if row is None or row[1] != owner or row[2] != workspace or row[7] != privacy_domain: return None
        if row[11] is not None and row[11] <= time.time(): return None
        content = self._decrypt(privacy_domain, bytes(row[14]), bytes(row[15])); meta = json_loads(row[13])
        expected = hmac.new(self._master, canonical_bytes({"record": {"memory_id": row[0], "content_digest": row[16], "owner": row[1], "workspace": row[2], "privacy_domain": row[7], "version": row[8], "evidence_class": row[12]}}), hashlib.sha256).hexdigest()
        if meta.get("integrity") != expected:
            raise RuntimeError("memory integrity verification failed")
        record = MemoryRecord(row[0],row[4],row[1],row[2],row[3],row[5],row[16],row[6],row[7],row[8],row[9],row[10],row[11],EvidenceClass(row[12]),meta)
        if hashlib.sha256(content.encode("utf-8")).hexdigest() != record.content_digest:
            raise RuntimeError("memory content digest verification failed")
        return record, content

    def delete(self, memory_id: str, *, owner: str, workspace: str, privacy_domain: str, reason: str = "operator") -> bool:
        """Delete one record only when its security boundary is explicitly matched."""
        with self._lock:
            row = self._db.execute("SELECT owner,workspace,privacy_domain FROM records WHERE memory_id=?", (str(memory_id),)).fetchone()
            if row is None or row[0] != str(owner) or row[1] != str(workspace) or row[2] != str(privacy_domain):
                return False
            self._db.execute("DELETE FROM records WHERE memory_id=?", (str(memory_id),))
            self._db.execute("INSERT OR REPLACE INTO tombstones VALUES(?,?,?)", (str(memory_id), time.time(), str(reason)))
            self._db.commit()
            self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            return True

    def purge_expired(self) -> int:
        now = time.time();
        with self._lock:
            rows = self._db.execute("SELECT memory_id FROM records WHERE expires_at IS NOT NULL AND expires_at<=?", (now,)).fetchall();
            for (rid,) in rows: self._db.execute("DELETE FROM records WHERE memory_id=?", (rid,)); self._db.execute("INSERT OR REPLACE INTO tombstones VALUES(?,?,?)", (rid, now, "retention"))
            self._db.commit(); self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)"); return len(rows)

    def audit(self) -> dict[str, int]:
        with self._lock: return {"records": int(self._db.execute("SELECT COUNT(*) FROM records").fetchone()[0]), "tombstones": int(self._db.execute("SELECT COUNT(*) FROM tombstones").fetchone()[0])}

    def close(self) -> None:
        with self._lock: self._db.commit(); self._db.close()


def json_loads(value: str) -> dict[str, Any]:
    import json
    parsed = json.loads(value)
    return dict(parsed) if isinstance(parsed, dict) else {}


class ContradictionResolver:
    """Retain conflicting claims as evidence instead of silently overwriting facts."""

    def resolve(self, claims: Iterable[Claim]) -> dict[str, Any]:
        rows = sorted(claims, key=lambda c: (-c.confidence, -c.authority.count("."), -c.observed_at, c.claim_id))
        if not rows: return {"state": "unresolved", "claims": []}
        statements = {c.statement for c in rows}
        if len(statements) == 1: state = "confirmed"
        else: state = "contested"
        return {"state": state, "claims": [c.__dict__ if hasattr(c, "__dict__") else {"claim_id": c.claim_id, "statement": c.statement, "source": c.source, "authority": c.authority, "observed_at": c.observed_at, "confidence": c.confidence, "status": c.status} for c in rows], "selected": None if state == "contested" else rows[0].claim_id}



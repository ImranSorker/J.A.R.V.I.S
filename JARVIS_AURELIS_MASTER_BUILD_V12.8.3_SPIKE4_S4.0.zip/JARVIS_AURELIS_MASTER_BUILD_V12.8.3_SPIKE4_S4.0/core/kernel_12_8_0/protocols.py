"""Canonical MCP/A2A control planes for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import base64
import json
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass
from typing import Any, Callable, Mapping

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from jsonschema import Draft202012Validator

from .canonical import canonical_bytes, canonical_json, digest
from .identity import AgentIdentity, AgentIdentityAuthority, ReplayCache
from .ids import uuid7

MCP_VERSION = "2026-07-28"
A2A_VERSION = "1.0"


@dataclass(frozen=True, slots=True)
class MCPToolManifest:
    server_id: str
    publisher: str
    version: str
    tool_id: str
    schema: Mapping[str, Any]
    side_effect_level: str
    required_capabilities: tuple[str, ...]
    network_hosts: tuple[str, ...]
    filesystem_scope: tuple[str, ...]
    data_classification: str
    auth_method: str
    signature: str
    provenance: str
    signer_key_id: str = ""
    signer_public_key_b64: str = ""
    task_capable: bool = False
    protocol_version: str = MCP_VERSION

    def unsigned(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature", None)
        return value

    @property
    def manifest_digest(self) -> str:
        return digest(self.unsigned())


class MCPControlPlane:
    """Authoritative MCP registry with validation, trust quarantine and bounded execution."""

    def __init__(self, *, authority: AgentIdentityAuthority | None = None, max_result_bytes: int = 1_048_576) -> None:
        self.authority = authority or AgentIdentityAuthority()
        self.max_result_bytes = max(4_096, min(int(max_result_bytes), 16_777_216))
        self._tools: dict[str, MCPToolManifest] = {}
        self._handlers: dict[str, Callable[[Mapping[str, Any]], Mapping[str, Any]]] = {}
        self._quarantine: dict[str, str] = {}
        self._schemas: dict[str, Draft202012Validator] = {}
        self._tasks: dict[str, dict[str, Any]] = {}
        self._task_futures: dict[str, Future[Mapping[str, Any]]] = {}
        self._task_cancel: dict[str, threading.Event] = {}
        self._resources: dict[str, Callable[[], Mapping[str, Any]]] = {}
        self._prompts: dict[str, Mapping[str, Any]] = {}
        self._task_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="jarvis-12.8.0-mcp")
        self._lock = threading.RLock()

    def _verify_manifest_signature(self, manifest: MCPToolManifest) -> bool:
        if not all((manifest.signature, manifest.signer_key_id, manifest.signer_public_key_b64)):
            return False
        if self.authority is not None and manifest.signer_key_id != self.authority.key_id:
            return False
        try:
            public = Ed25519PublicKey.from_public_bytes(base64.b64decode(manifest.signer_public_key_b64, validate=True))
            public.verify(base64.b64decode(manifest.signature, validate=True), canonical_bytes(manifest.unsigned()))
            return True
        except Exception:
            return False

    def register(self, manifest: MCPToolManifest, handler: Callable[[Mapping[str, Any]], Mapping[str, Any]]) -> None:
        if not manifest.tool_id.strip() or not manifest.server_id.strip() or not callable(handler):
            raise ValueError("MCP manifest and callable handler are required")
        if manifest.protocol_version != MCP_VERSION:
            self._quarantine[manifest.tool_id] = f"unsupported MCP protocol version: {manifest.protocol_version}"
        elif not self._verify_manifest_signature(manifest):
            self._quarantine[manifest.tool_id] = "manifest signature is missing or unverifiable"
        try:
            self._schemas[manifest.tool_id] = Draft202012Validator.check_schema(dict(manifest.schema)) or Draft202012Validator(dict(manifest.schema))
        except Exception as exc:
            self._quarantine[manifest.tool_id] = f"invalid tool schema: {type(exc).__name__}"
        self._tools[manifest.tool_id] = manifest
        self._handlers[manifest.tool_id] = handler

    def _validate_result(self, result: Mapping[str, Any]) -> Mapping[str, Any]:
        encoded = json.dumps(dict(result), sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")
        if len(encoded) > self.max_result_bytes:
            raise ValueError("MCP tool result exceeds output budget")
        return dict(result)

    @staticmethod
    def _cache_envelope(payload: Mapping[str, Any]) -> dict[str, Any]:
        """Apply conservative 2026-07-28 cache metadata to list/discovery results."""
        return {**dict(payload), "ttlMs": 0, "cacheScope": "private"}

    def discover(self) -> dict[str, Any]:
        tools = []
        for tool_id in sorted(self._tools):
            if tool_id in self._quarantine:
                continue
            value = asdict(self._tools[tool_id])
            value["manifest_digest"] = self._tools[tool_id].manifest_digest
            value["required_capabilities"] = list(self._tools[tool_id].required_capabilities)
            value["network_hosts"] = list(self._tools[tool_id].network_hosts)
            value["filesystem_scope"] = list(self._tools[tool_id].filesystem_scope)
            tools.append(value)
        with self._lock:
            resources = [{"uri": key} for key in sorted(self._resources)]
            prompts = [dict(self._prompts[key]) for key in sorted(self._prompts)]
        return self._cache_envelope({
            "protocol": MCP_VERSION,
            "tools": tools,
            "resources": resources,
            "prompts": prompts,
            "extensions": ["tasks", "io.modelcontextprotocol/tasks", "mcp-2026-stateless-core"],
            "capabilities": {"extensions": {"io.modelcontextprotocol/tasks": {}}},
        })

    def quarantine(self) -> dict[str, str]:
        return dict(sorted(self._quarantine.items()))

    def register_resource(self, uri: str, reader: Callable[[], Mapping[str, Any]]) -> None:
        """Register a read-only MCP resource provider; writes are never dispatched through it."""
        key = str(uri).strip()
        if not key or not callable(reader):
            raise ValueError("resource URI and reader are required")
        with self._lock:
            self._resources[key] = reader

    def register_prompt(self, name: str, descriptor: Mapping[str, Any]) -> None:
        """Register immutable prompt metadata for MCP discovery."""
        key = str(name).strip()
        if not key:
            raise ValueError("prompt name is required")
        value = dict(descriptor)
        value.setdefault("name", key)
        with self._lock:
            self._prompts[key] = value

    def _prepare_call(self, tool_id: str, arguments: Mapping[str, Any]) -> tuple[Callable[[Mapping[str, Any]], Mapping[str, Any]], dict[str, Any]]:
        key = str(tool_id)
        if key in self._quarantine:
            raise PermissionError(self._quarantine[key])
        handler = self._handlers.get(key)
        validator = self._schemas.get(key)
        if key not in self._tools or handler is None or validator is None:
            raise KeyError(key)
        args = dict(arguments)
        errors = sorted(validator.iter_errors(args), key=lambda item: list(item.path))
        if errors:
            raise ValueError(f"invalid MCP arguments: {errors[0].message}")
        return handler, args

    def call(self, tool_id: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        handler, args = self._prepare_call(tool_id, arguments)
        return self._validate_result(handler(args))

    def _create_task(self, tool_id: str, arguments: Mapping[str, Any]) -> dict[str, Any]:
        """Materialize one asynchronous task using the negotiated Tasks extension."""
        self._prepare_call(tool_id, arguments)
        task_id = uuid7()
        cancel_event = threading.Event()
        def worker() -> Mapping[str, Any]:
            if cancel_event.is_set():
                raise RuntimeError("MCP task cancelled before execution")
            result = self.call(tool_id, arguments)
            if cancel_event.is_set():
                raise RuntimeError("MCP task cancelled")
            return result
        future = self._task_pool.submit(worker)
        task = {"taskId": task_id, "status": "working", "createdAt": time.time(), "tool": tool_id}
        with self._lock:
            self._tasks[task_id] = task
            self._task_futures[task_id] = future
            self._task_cancel[task_id] = cancel_event
        return {"task": dict(task)}

    def dispatch(self, method: str, params: Mapping[str, Any] | None = None, *, headers: Mapping[str, str] | None = None) -> dict[str, Any]:
        """Dispatch stateless MCP 2026-07-28 discovery, resources, tools and Tasks extension."""
        params = dict(params or {})
        request_headers = {str(key).lower(): str(value) for key, value in dict(headers or {}).items()}
        protocol_header = request_headers.get("mcp-protocol-version")
        if protocol_header is not None and protocol_header != MCP_VERSION:
            raise ValueError(f"unsupported MCP protocol version: {protocol_header}")
        if method in {"tools/list", "server/discover"}:
            return self.discover()
        if method == "resources/list":
            with self._lock:
                return self._cache_envelope({"resources": [{"uri": key} for key in sorted(self._resources)]})
        if method == "resources/read":
            uri = str(params.get("uri", "")).strip()
            with self._lock:
                reader = self._resources.get(uri)
            if reader is None:
                raise KeyError(uri)
            return dict(self._validate_result(reader()))
        if method == "prompts/list":
            with self._lock:
                return self._cache_envelope({"prompts": [dict(self._prompts[key]) for key in sorted(self._prompts)]})
        if method == "tools/call":
            tool_id = str(params.get("name", "")).strip()
            arguments = dict(params.get("arguments", {}))
            manifest = self._tools.get(tool_id)
            client_caps = dict(params.get("_meta", {})).get("io.modelcontextprotocol/clientCapabilities", {})
            extensions = dict(client_caps).get("extensions", {}) if isinstance(client_caps, Mapping) else {}
            tasks_supported = "io.modelcontextprotocol/tasks" in extensions
            if manifest is not None and manifest.task_capable and tasks_supported:
                return self._create_task(tool_id, arguments) | {"resultType": "task"}
            return dict(self.call(tool_id, arguments))
        if method == "tasks/get":
            task_id = str(params.get("taskId", "")).strip()
            with self._lock:
                task = dict(self._tasks.get(task_id, {}))
                future = self._task_futures.get(task_id)
            if not task:
                raise KeyError(task_id)
            if future is not None and future.done() and task.get("status") == "working":
                try:
                    result = dict(future.result())
                    with self._lock:
                        cancelled = self._task_cancel.get(task_id, threading.Event()).is_set()
                    task["status"] = "cancelled" if cancelled else "completed"
                    if not cancelled:
                        task["result"] = result
                except Exception as exc:
                    with self._lock:
                        cancelled = self._task_cancel.get(task_id, threading.Event()).is_set()
                    task["status"] = "cancelled" if cancelled else "failed"
                    if not cancelled:
                        task["error"] = f"{type(exc).__name__}: {exc}"
                with self._lock:
                    self._tasks[task_id] = task
            return task
        if method == "tasks/cancel":
            task_id = str(params.get("taskId", "")).strip()
            with self._lock:
                future = self._task_futures.get(task_id)
                task = dict(self._tasks.get(task_id, {}))
                cancel_event = self._task_cancel.get(task_id)
            if future is None or not task:
                raise KeyError(task_id)
            cancel_event.set() if cancel_event is not None else None
            cancelled = future.cancel()
            with self._lock:
                current = dict(self._tasks[task_id])
                current["cancel_requested"] = True
                if cancelled or not future.running():
                    current["status"] = "cancelled"
                self._tasks[task_id] = current
                return dict(current)
        if method == "tasks/update":
            task_id = str(params.get("taskId", "")).strip()
            with self._lock:
                if task_id not in self._tasks:
                    raise KeyError(task_id)
                if "status" in params:
                    raise ValueError("task status is controlled by the task runtime")
                return dict(self._tasks[task_id])
        if method == "tasks/create":
            tool_id = str(params.get("name", "")).strip()
            arguments = dict(params.get("arguments", {}))
            return self._create_task(tool_id, arguments)
        raise KeyError(f"unsupported MCP method: {method}")

    def close(self) -> None:
        """Stop the bounded task executor without abandoning active workers."""
        self._task_pool.shutdown(wait=True, cancel_futures=True)
        with self._lock:
            self._task_futures.clear()
            self._task_cancel.clear()


def sign_mcp_manifest(manifest: MCPToolManifest, authority: AgentIdentityAuthority) -> MCPToolManifest:
    """Return a manifest signed by the supplied kernel trust authority."""
    public_b64 = base64.b64encode(authority.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode("ascii")
    unsigned = MCPToolManifest(**{**asdict(manifest), "signature": "", "signer_key_id": authority.key_id, "signer_public_key_b64": public_b64})
    signature = base64.b64encode(authority.sign_bytes(canonical_bytes(unsigned.unsigned()))).decode("ascii")
    return MCPToolManifest(**{**asdict(unsigned), "signature": signature})


@dataclass(frozen=True, slots=True)
class A2ATaskEnvelope:
    task_id: str
    issuer: str
    audience: str
    nonce: str
    issued_at: float
    expires_at: float
    payload: Mapping[str, Any]
    signature_b64: str
    issuer_key_id: str = ""
    issuer_public_key_b64: str = ""
    protocol_version: str = A2A_VERSION


@dataclass(frozen=True, slots=True)
class AgentCard:
    """Signed A2A agent discovery document bound to one kernel trust key."""
    name: str
    description: str
    url: str
    version: str
    capabilities: tuple[str, ...]
    security_schemes: Mapping[str, Any]
    issuer: str
    key_id: str
    public_key_b64: str
    signature_b64: str = ""

    def unsigned(self) -> dict[str, Any]:
        value = asdict(self)
        value.pop("signature_b64", None)
        return value

    def sign(self, authority: AgentIdentityAuthority) -> "AgentCard":
        public_b64 = base64.b64encode(authority.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode("ascii")
        unsigned = AgentCard(self.name, self.description, self.url, self.version, tuple(sorted(set(self.capabilities))), dict(self.security_schemes), authority.issuer, authority.key_id, public_b64, "")
        signature = base64.b64encode(authority.sign_bytes(canonical_json(unsigned.unsigned()))).decode("ascii")
        return AgentCard(**{**asdict(unsigned), "signature_b64": signature})

    def to_a2a_document(self) -> dict[str, Any]:
        """Render this compact internal card as an A2A 1.0 AgentCard document."""
        interface = {"url": self.url, "protocolBinding": "JSONRPC", "protocolVersion": A2A_VERSION}
        return {
            "name": self.name,
            "description": self.description,
            "supportedInterfaces": [interface],
            "version": self.version,
            "capabilities": {"streaming": False, "pushNotifications": False, "stateTransitionHistory": True},
            "securitySchemes": dict(self.security_schemes),
            "securityRequirements": [],
            "defaultInputModes": ["text/plain"],
            "defaultOutputModes": ["text/plain"],
            "skills": [{"id": cap, "name": cap, "description": cap, "tags": [cap]} for cap in self.capabilities],
        }

    def jws_signature(self, authority: AgentIdentityAuthority) -> dict[str, Any]:
        """Return an RFC 7515 compact-signature-compatible AgentCard signature object."""
        import json as _json
        def b64url(data: bytes) -> str:
            return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")
        protected = b64url(_json.dumps({"alg": "EdDSA", "typ": "JOSE", "kid": authority.key_id}, separators=(",", ":"), sort_keys=True).encode("utf-8"))
        payload = b64url(canonical_json(self.to_a2a_document()))
        signature = b64url(authority.sign_bytes(f"{protected}.{payload}".encode("ascii")))
        return {"protected": protected, "signature": signature, "header": {"kid": authority.key_id}}

    def verify(self, authority: AgentIdentityAuthority) -> bool:
        if self.issuer != authority.issuer or self.key_id != authority.key_id:
            return False
        try:
            public = Ed25519PublicKey.from_public_bytes(base64.b64decode(self.public_key_b64, validate=True))
            signature = base64.b64decode(self.signature_b64, validate=True)
            public.verify(signature, canonical_json(self.unsigned()))
            return public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw) == authority.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        except Exception:
            return False


class A2AControlPlane:
    """Signed A2A task adapter with audience, expiry and nonce replay enforcement."""

    def __init__(self, authority: AgentIdentityAuthority | None = None) -> None:
        self.authority = authority or AgentIdentityAuthority()
        self.replay_cache = ReplayCache()
        self._cards: dict[str, AgentCard] = {}


    def publish_agent_card(self, card: AgentCard) -> AgentCard:
        signed = card.sign(self.authority)
        self._cards[signed.name] = signed
        return signed

    def agent_card(self, name: str) -> AgentCard | None:
        return self._cards.get(str(name))

    def discover_agents(self) -> list[dict[str, Any]]:
        return [asdict(self._cards[key]) for key in sorted(self._cards)]

    def sign_task(
        self,
        issuer: AgentIdentity,
        *,
        audience: str,
        payload: Mapping[str, Any],
        ttl_seconds: float = 300.0,
    ) -> A2ATaskEnvelope:
        if not self.authority.verify(issuer, audience=self.authority.issuer):
            raise PermissionError("issuer identity is not trusted")
        now = time.time()
        public_b64 = issuer.public_key_b64
        agent_key_id = self.authority.agent_key_id(issuer)
        if not agent_key_id:
            raise PermissionError("issuer sender key is not registered")
        material = {
            "task_id": uuid7(),
            "issuer": issuer.agent_id,
            "audience": str(audience),
            "nonce": uuid7(),
            "issued_at": now,
            "expires_at": now + max(1.0, min(float(ttl_seconds), 3600.0)),
            "payload": dict(payload),
            "issuer_key_id": agent_key_id,
            "issuer_public_key_b64": public_b64,
            "protocol_version": A2A_VERSION,
        }
        sig = base64.b64encode(self.authority.sign_as(issuer, canonical_bytes(material))).decode("ascii")
        return A2ATaskEnvelope(signature_b64=sig, **material)

    def verify_task(self, envelope: A2ATaskEnvelope, *, audience: str) -> bool:
        """Verify protocol version, issuer, signature, audience, time bounds and nonce exactly once."""
        if envelope.protocol_version != A2A_VERSION:
            return False
        material = {
            "task_id": envelope.task_id,
            "issuer": envelope.issuer,
            "audience": envelope.audience,
            "nonce": envelope.nonce,
            "issued_at": envelope.issued_at,
            "expires_at": envelope.expires_at,
            "payload": dict(envelope.payload),
            "issuer_key_id": envelope.issuer_key_id,
            "issuer_public_key_b64": envelope.issuer_public_key_b64,
            "protocol_version": envelope.protocol_version,
        }
        now = time.time()
        if envelope.audience != str(audience) or envelope.expires_at <= now or envelope.issued_at > now + 5.0:
            return False
        record = self.authority.agent_public_key(envelope.issuer)
        if record is None or record[0] != envelope.issuer_key_id:
            return False
        try:
            encoded = base64.b64decode(envelope.issuer_public_key_b64, validate=True)
            expected = record[1].public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            if encoded != expected:
                return False
            record[1].verify(
                base64.b64decode(envelope.signature_b64, validate=True),
                canonical_bytes(material),
            )
        except Exception:
            return False
        return self.replay_cache.consume(envelope.nonce, expires_at=envelope.expires_at)



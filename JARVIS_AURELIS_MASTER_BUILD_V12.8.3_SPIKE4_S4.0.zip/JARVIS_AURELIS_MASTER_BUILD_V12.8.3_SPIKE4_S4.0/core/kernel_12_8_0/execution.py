"""Unified execution security pipeline for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, TypeVar

from .canonical import digest
from .capability_policy import CapabilityPolicy
from .contracts import CapabilityRequest
from .ids import Clock, uuid7
from .resource import ResourceLedger
from .sandbox import SandboxPolicy, SandboxResult, SecurePythonSandbox

F = TypeVar("F", bound=Callable[..., Any])


@dataclass(frozen=True, slots=True)
class ExecutionPolicy:
    capability: str
    risk: str
    timeout_seconds: float
    memory_mb: int
    output_bytes: int
    require_approval: bool = True


@dataclass(frozen=True, slots=True)
class ExecutionRecord:
    execution_id: str
    operation: str
    capability: str
    approved: bool
    started_at: float
    finished_at: float
    success: bool
    result_digest: str | None
    error_type: str | None


def bounded(fn: F) -> F:
    """Mark a callable as already internally bounded; it still passes kernel policy first."""
    setattr(fn, "__jarvis_bounded__", True)
    return fn


class KernelExecutionAuthority:
    """Single entry point for bounded adapters and generated Python code."""

    def __init__(self, policy: CapabilityPolicy, resources: ResourceLedger, *, audit_path: str | Path = "logs/execution_audit.log") -> None:
        self.policy = policy
        self.resources = resources
        self.audit_path = Path(audit_path).resolve()
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        self._records: list[ExecutionRecord] = []
        self._lock = threading.RLock()

    def _audit(self, event: str, **fields: Any) -> None:
        entry = {"timestamp": Clock.wall(), "event": str(event), "version": "12.8.0", **fields}
        line = json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        with self._lock:
            with self.audit_path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")

    def call(
        self,
        operation: str,
        fn: Callable[..., Any],
        *,
        request: CapabilityRequest,
        approved: bool = False,
        resource_allocations: Mapping[str, float] | None = None,
        mission_id: str = "local",
    ) -> Any:
        if not callable(fn):
            raise TypeError("execution target must be callable")
        if not getattr(fn, "__jarvis_bounded__", False):
            raise PermissionError("direct callable execution requires a kernel-bounded adapter")
        decision = self.policy.evaluate(request, approved=approved)
        if not decision.allowed:
            self._audit("execution_denied", operation=operation, capability=request.capability, reason=decision.reason)
            raise PermissionError(decision.reason)
        allocations = dict(resource_allocations or {"cpu_seconds": float(max(1.0, request.ttl_seconds))})
        lease = self.resources.reserve(request.principal, mission_id, allocations, ttl_seconds=min(300.0, max(1.0, float(request.ttl_seconds))))
        execution_id = uuid7()
        started_wall = Clock.wall()
        self._audit("execution_started", execution_id=execution_id, operation=str(operation), capability=request.capability, mission_id=mission_id, approved=approved, lease_id=lease.lease_id)
        try:
            result = fn()
            record = ExecutionRecord(execution_id, str(operation), request.capability, approved, started_wall, Clock.wall(), True, None if result is None else hashlib.sha256(digest(result).encode("ascii")).hexdigest(), None)
            with self._lock:
                self._records.append(record)
            self._audit("execution_completed", execution_id=execution_id, operation=str(operation), success=True, result_digest=record.result_digest)
            return result
        except Exception as exc:
            record = ExecutionRecord(execution_id, str(operation), request.capability, approved, started_wall, Clock.wall(), False, None, type(exc).__name__)
            with self._lock:
                self._records.append(record)
            self._audit("execution_failed", execution_id=execution_id, operation=str(operation), success=False, error_type=type(exc).__name__)
            raise
        finally:
            self.resources.release(lease.lease_id)

    def run_python(
        self,
        source: str,
        *,
        request: CapabilityRequest,
        approved: bool = False,
        policy: SandboxPolicy | None = None,
        mission_id: str = "local",
    ) -> SandboxResult:
        decision = self.policy.evaluate(request, approved=approved)
        if not decision.allowed:
            self._audit("python_denied", capability=request.capability, reason=decision.reason)
            raise PermissionError(decision.reason)
        runtime = SecurePythonSandbox(policy)
        lease = self.resources.reserve(request.principal, mission_id, {"cpu_seconds": runtime.policy.cpu_seconds, "ram_mb": runtime.policy.memory_mb}, ttl_seconds=runtime.policy.timeout_seconds + 5.0)
        execution_id = uuid7()
        self._audit("python_started", execution_id=execution_id, capability=request.capability, mission_id=mission_id, lease_id=lease.lease_id)
        try:
            result = runtime.execute(source)
            self._audit("python_completed", execution_id=execution_id, return_code=result.return_code, blocked=result.blocked, timed_out=result.timed_out)
            return result
        except Exception as exc:
            self._audit("python_failed", execution_id=execution_id, error_type=type(exc).__name__)
            raise
        finally:
            self.resources.release(lease.lease_id)

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            return [
                {"execution_id": item.execution_id, "operation": item.operation, "capability": item.capability, "approved": item.approved, "started_at": item.started_at, "finished_at": item.finished_at, "success": item.success, "result_digest": item.result_digest, "error_type": item.error_type}
                for item in self._records[-1000:]
            ]

    def close(self) -> None:
        """Flush the audit stream; resources are opened per event and do not require persistent handles."""
        return None



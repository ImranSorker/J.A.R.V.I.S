"""Dream/experiment manifests, negative knowledge and counterfactual boundaries."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Mapping

from .canonical import digest
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class ExperimentManifest:
    experiment_id: str
    hypothesis: str
    baseline: Mapping[str, Any]
    variables: Mapping[str, Any]
    constraints: Mapping[str, Any]
    budget: Mapping[str, Any]
    seed: int
    time_limit_seconds: float
    memory_limit_mb: int
    network_policy: str
    filesystem_policy: str
    success_criteria: Mapping[str, Any]
    failure_criteria: Mapping[str, Any]
    artifact_manifest: Mapping[str, Any]
    before_digest: str
    after_digest: str | None = None
    evaluation: Mapping[str, Any] | None = None
    promotion_status: str = "candidate"


class ExperimentStore:
    """Persistent experiment store with negative-result memory."""

    def __init__(self, db_path: str | Path = "data/kernel_12_8_0_experiments.db") -> None:
        self.db_path = str(Path(db_path).resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._closed = False
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA busy_timeout=20000")
        self._db.execute("CREATE TABLE IF NOT EXISTS experiments(experiment_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,updated_at REAL NOT NULL)")
        self._db.execute("CREATE TABLE IF NOT EXISTS negative_knowledge(id TEXT PRIMARY KEY,hypothesis TEXT NOT NULL,cause TEXT NOT NULL,evidence_json TEXT NOT NULL,created_at REAL NOT NULL)")
        self._db.commit()

    def create(self, hypothesis: str, baseline: Mapping[str, Any], variables: Mapping[str, Any], constraints: Mapping[str, Any], budget: Mapping[str, Any], *, seed: int = 0, time_limit_seconds: float = 30.0, memory_limit_mb: int = 512, network_policy: str = "deny", filesystem_policy: str = "workspace", success_criteria: Mapping[str, Any] | None = None, failure_criteria: Mapping[str, Any] | None = None) -> ExperimentManifest:
        if not str(hypothesis).strip() or not success_criteria or not failure_criteria:
            raise ValueError("experiment hypothesis, success criteria and failure criteria are required")
        if str(network_policy) != "deny" or str(filesystem_policy) != "workspace":
            raise PermissionError("kernel experiments permit workspace-only, network-denied execution")
        m = ExperimentManifest(uuid7(), str(hypothesis), dict(baseline), dict(variables), dict(constraints), dict(budget), int(seed), max(1.0, float(time_limit_seconds)), max(64, int(memory_limit_mb)), network_policy, filesystem_policy, dict(success_criteria), dict(failure_criteria), {"baseline_digest": digest(baseline)}, digest(baseline))
        with self._lock:
            if self._closed:
                raise RuntimeError("experiment store is closed")
            self._db.execute("INSERT INTO experiments VALUES(?,?,?)", (m.experiment_id, json.dumps(asdict(m), sort_keys=True, default=str), time.time()))
            self._db.commit()
        return m

    def complete(self, experiment_id: str, *, after: Mapping[str, Any], evaluation: Mapping[str, Any], status: str) -> ExperimentManifest:
        with self._lock:
            if self._closed:
                raise RuntimeError("experiment store is closed")
            row = self._db.execute("SELECT payload_json FROM experiments WHERE experiment_id=?", (str(experiment_id),)).fetchone()
            if row is None: raise KeyError(experiment_id)
            data = json.loads(row[0])
            data.update({"after_digest": digest(after), "evaluation": dict(evaluation), "promotion_status": str(status)})
            self._db.execute("UPDATE experiments SET payload_json=?,updated_at=? WHERE experiment_id=?", (json.dumps(data, sort_keys=True, default=str), time.time(), str(experiment_id)))
            self._db.commit()
            return ExperimentManifest(**data)

    def record_negative(self, hypothesis: str, cause: str, evidence: Mapping[str, Any]) -> None:
        with self._lock:
            if self._closed:
                raise RuntimeError("experiment store is closed")
            self._db.execute("INSERT INTO negative_knowledge VALUES(?,?,?,?,?)", (uuid7(), str(hypothesis), str(cause), json.dumps(dict(evidence), sort_keys=True, default=str), time.time()))
            self._db.commit()

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._db.execute("SELECT payload_json FROM experiments ORDER BY updated_at DESC").fetchall()
        return [json.loads(row[0]) for row in rows]

    def run_python(self, experiment_id: str, source: str) -> dict[str, Any]:
        """Run one experiment in the kernel sandbox and persist the evaluation boundary."""
        from .sandbox import SandboxPolicy, SecurePythonSandbox
        with self._lock:
            row = self._db.execute("SELECT payload_json FROM experiments WHERE experiment_id=?", (str(experiment_id),)).fetchone()
        if row is None:
            raise KeyError(experiment_id)
        manifest = ExperimentManifest(**json.loads(row[0]))
        result = SecurePythonSandbox(SandboxPolicy(timeout_seconds=min(manifest.time_limit_seconds, 300.0), memory_mb=min(manifest.memory_limit_mb, 8192), cpu_seconds=max(1, min(int(manifest.time_limit_seconds), 60)), output_bytes=1_048_576, network=False)).execute(source)
        outcome = {"return_code": result.return_code, "stdout": result.stdout, "stderr": result.stderr, "timed_out": result.timed_out, "blocked": result.blocked}
        passed = result.return_code == 0 and not result.timed_out and not result.blocked
        evaluation = {"passed": passed, "criteria": manifest.success_criteria if passed else manifest.failure_criteria}
        self.complete(experiment_id, after=outcome, evaluation=evaluation, status="evaluated" if passed else "rejected")
        if not passed:
            self.record_negative(manifest.hypothesis, "experiment_execution_failed", outcome)
        return outcome

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._db.commit(); self._db.close(); self._closed = True


class CounterfactualSimulator:
    """Explicit simulation boundary; results are marked simulation, not fact."""

    def simulate(self, alternatives: Mapping[str, Callable[[], Mapping[str, Any]]]) -> dict[str, Any]:
        if not alternatives or len(alternatives) > 16: raise ValueError("1..16 alternatives required")
        result: dict[str, Any] = {"kind": "simulation", "alternatives": {}}
        for name, evaluator in sorted(alternatives.items()):
            if not callable(evaluator): raise TypeError("counterfactual evaluator must be callable")
            result["alternatives"][str(name)] = dict(evaluator())
        return result



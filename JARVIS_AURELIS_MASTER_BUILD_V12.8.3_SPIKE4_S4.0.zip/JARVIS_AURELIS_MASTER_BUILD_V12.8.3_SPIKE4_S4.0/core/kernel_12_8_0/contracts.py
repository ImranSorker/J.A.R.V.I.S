"""Typed command, capability, mission and evidence contracts for 12.8.0."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping

from .ids import Clock, uuid7


class TaskState(StrEnum):
    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class EvidenceClass(StrEnum):
    OBSERVED = "observed"
    USER_PROVIDED = "user_provided"
    MODEL_GENERATED = "model_generated"
    TOOL_VERIFIED = "tool_verified"
    EXTERNALLY_VERIFIED = "externally_verified"
    CRYPTOGRAPHICALLY_VERIFIED = "cryptographically_verified"
    DERIVED = "derived"
    INFERRED = "inferred"


class RecoveryClass(StrEnum):
    REVERSIBLE = "reversible"
    COMPENSATABLE = "compensatable"
    RESTORABLE_FROM_CHECKPOINT = "restorable_from_checkpoint"
    IRREVERSIBLE = "irreversible"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class EventEnvelope:
    topic: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=uuid7)
    wall_time: float = field(default_factory=Clock.wall)
    monotonic_time: float = field(default_factory=Clock.monotonic)
    correlation_id: str = field(default_factory=uuid7)
    causation_id: str | None = None
    schema_version: int = 1
    source: str = "jarvis-12.8.0"

    @property
    def timestamp(self) -> float:
        """Backwards-compatible wall-clock timestamp."""
        return self.wall_time

    def to_dict(self) -> dict[str, Any]:
        return {
            "topic": self.topic,
            "payload": dict(self.payload),
            "event_id": self.event_id,
            "wall_time": self.wall_time,
            "monotonic_time": self.monotonic_time,
            "correlation_id": self.correlation_id,
            "causation_id": self.causation_id,
            "schema_version": self.schema_version,
            "source": self.source,
        }


@dataclass(frozen=True, slots=True)
class Command:
    name: str
    args: Mapping[str, Any] = field(default_factory=dict)
    command_id: str = field(default_factory=uuid7)
    idempotency_key: str | None = None
    correlation_id: str = field(default_factory=uuid7)
    capability: str | None = None


@dataclass(frozen=True, slots=True)
class CapabilityRequest:
    capability: str
    reason: str = ""
    risk: str = "low"
    ttl_seconds: int = 300
    mission_id: str | None = None
    principal: str = "local-user"
    resource: str = "*"


@dataclass(slots=True)
class TaskSpec:
    task_id: str
    name: str
    handler: str
    args: dict[str, Any] = field(default_factory=dict)
    depends_on: list[str] = field(default_factory=list)
    state: TaskState = TaskState.PENDING
    attempts: int = 0
    max_attempts: int = 2
    result: Any = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, name: str, handler: str, **kwargs: Any) -> "TaskSpec":
        return cls(task_id=f"task_{uuid7().replace('-', '')}", name=str(name), handler=str(handler), **kwargs)



"""Deterministic canonical encodings for J.A.R.V.I.S. 12.8.0 trust boundaries."""
from __future__ import annotations

import dataclasses
import json
import math
import struct
from collections.abc import Mapping
from enum import Enum
from typing import Any


class CanonicalizationError(ValueError):
    """Raised when a value cannot safely enter a cryptographic contract."""


def _normalize(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        value = dataclasses.asdict(value)
    if isinstance(value, Enum):
        return value.value
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise CanonicalizationError("non-finite numbers are forbidden in signed contracts")
        if value == 0.0:
            return 0.0
        return value
    if isinstance(value, bytes):
        return value
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise CanonicalizationError("contract object keys must be strings")
            normalized[key] = _normalize(item)
        return normalized
    if isinstance(value, (list, tuple)):
        return [_normalize(item) for item in value]
    raise CanonicalizationError(f"unsupported contract value type: {type(value).__name__}")


def canonical_json(value: Any) -> bytes:
    """Serialize a JSON-domain value deterministically for human-readable storage."""
    normalized = _normalize(value)
    if any(isinstance(x, bytes) for x in _walk(normalized)):
        raise CanonicalizationError("bytes require canonical CBOR encoding")
    try:
        return json.dumps(
            normalized,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise CanonicalizationError(str(exc)) from exc


def _walk(value: Any):
    yield value
    if isinstance(value, Mapping):
        for item in value.values():
            yield from _walk(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            yield from _walk(item)


def _uint(major: int, value: int) -> bytes:
    if value < 24:
        return bytes([(major << 5) | value])
    if value < 256:
        return bytes([(major << 5) | 24, value])
    if value < 65536:
        return bytes([(major << 5) | 25]) + value.to_bytes(2, "big")
    if value < 2**32:
        return bytes([(major << 5) | 26]) + value.to_bytes(4, "big")
    if value < 2**64:
        return bytes([(major << 5) | 27]) + value.to_bytes(8, "big")
    raise CanonicalizationError("integer exceeds deterministic CBOR uint64 range")


def _float_bytes(value: float) -> bytes:
    if not math.isfinite(value):
        raise CanonicalizationError("non-finite floats are forbidden in signed contracts")
    try:
        packed16 = struct.pack(">e", value)
    except OverflowError:
        packed16 = b""
    if packed16 and struct.unpack(">e", packed16)[0] == value:
        return b"\xf9" + packed16
    packed32 = struct.pack(">f", value)
    if struct.unpack(">f", packed32)[0] == value:
        return b"\xfa" + packed32
    return b"\xfb" + struct.pack(">d", value)


def _cbor(value: Any) -> bytes:
    if value is None:
        return b"\xf6"
    if value is False:
        return b"\xf4"
    if value is True:
        return b"\xf5"
    if isinstance(value, int) and not isinstance(value, bool):
        return _uint(0, value) if value >= 0 else _uint(1, -1 - value)
    if isinstance(value, float):
        return _float_bytes(value)
    if isinstance(value, bytes):
        return _uint(2, len(value)) + value
    if isinstance(value, str):
        raw = value.encode("utf-8", "strict")
        return _uint(3, len(raw)) + raw
    if isinstance(value, (list, tuple)):
        items = b"".join(_cbor(item) for item in value)
        return _uint(4, len(value)) + items
    if isinstance(value, Mapping):
        encoded_pairs = []
        for key, item in value.items():
            if not isinstance(key, str):
                raise CanonicalizationError("contract object keys must be strings")
            encoded_key = _cbor(key)
            encoded_pairs.append((encoded_key, _cbor(item)))
        encoded_pairs.sort(key=lambda pair: (len(pair[0]), pair[0]))
        return _uint(5, len(encoded_pairs)) + b"".join(key + item for key, item in encoded_pairs)
    raise CanonicalizationError(f"unsupported canonical CBOR type: {type(value).__name__}")


def canonical_cbor(value: Any) -> bytes:
    """Return deterministic CBOR bytes for cryptographic identity and signatures.

    The encoder uses definite lengths, canonical map-key ordering, shortest exact
    IEEE-754 float width, and rejects non-finite values and unsupported objects.
    """
    return _cbor(_normalize(value))


def canonical_bytes(value: Any) -> bytes:
    """Return the binary canonical representation used by 12.8.0 cryptographic APIs."""
    return canonical_cbor(value)


def digest(value: Any) -> str:
    """Return SHA-256 over the deterministic CBOR contract representation."""
    import hashlib

    return hashlib.sha256(canonical_bytes(value)).hexdigest()



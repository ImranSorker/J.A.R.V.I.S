"""Validated deterministic task DAG for the 12.8.0 kernel."""
from __future__ import annotations

from dataclasses import dataclass
from .contracts import TaskSpec, TaskState


class TaskGraphError(ValueError):
    """Raised for invalid or cyclic task graphs."""


@dataclass(slots=True)
class TaskGraph:
    tasks: dict[str, TaskSpec] | None = None

    def __post_init__(self) -> None:
        self.tasks = {} if self.tasks is None else self.tasks

    def add(self, task: TaskSpec) -> None:
        if task.task_id in self.tasks:
            raise TaskGraphError(f"duplicate task: {task.task_id}")
        self.tasks[task.task_id] = task
        self._validate()

    def _validate(self) -> None:
        for task in self.tasks.values():
            for dep in task.depends_on:
                if dep not in self.tasks:
                    raise TaskGraphError(f"missing dependency: {dep}")
        visiting: set[str] = set()
        visited: set[str] = set()

        def walk(node: str) -> None:
            if node in visiting:
                raise TaskGraphError("task graph contains a cycle")
            if node in visited:
                return
            visiting.add(node)
            for dep in self.tasks[node].depends_on:
                walk(dep)
            visiting.remove(node)
            visited.add(node)

        for node in self.tasks:
            walk(node)

    def ready(self) -> list[TaskSpec]:
        return [task for task in self.tasks.values() if task.state in {TaskState.PENDING, TaskState.READY} and all(self.tasks[dep].state == TaskState.SUCCEEDED for dep in task.depends_on)]



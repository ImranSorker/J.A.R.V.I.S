"""The canonical J.A.R.V.I.S. 12.8.0 kernel runtime."""
from __future__ import annotations

import hashlib
import logging
import os
import threading
import time
from typing import Any, Callable, Mapping

from .capability_policy import CapabilityPolicy, Decision
from .contracts import CapabilityRequest, Command, EventEnvelope
from .event_store import EventStore
from .evidence import EvidenceEnvelope, EvidenceLedger
from .ids import Clock, uuid7
from .identity import AgentIdentityAuthority
from .mission import HardCancellation, MissionWAL, UndoExecutor
from .resource import ResourceBudget, ResourceLedger, ThermalGovernor
from .promotion import PromotionEngine
from .protocols import A2AControlPlane, MCPControlPlane
from .inference import EmpiricalInferenceRouter, PrefixKVCache
from .memory import MemoryFabric
from .experiments import ExperimentStore
from .execution import KernelExecutionAuthority
from .computer_use import ComputerUseAuthority
from .credentials import SenderConstrainedCredentialAuthority
from .federation import FederationRegistry
from .attention import AttentionBudgetEngine
from .observability import OpenTelemetryBridge, TraceLedger
from .wasi import WASIComponentRuntime
from .digital_twin import DigitalTwinProjection
from .continual_learning import ContinualLearningManager
from ..assurance_kernel import AssuranceKernel

logger = logging.getLogger("jarvis.kernel.12.8.0")


class JarvisKernelRuntime:
    """Single dependency-injected authority for durable events, trust and recovery."""

    VERSION = "12.8.0"
    KERNEL_ID = "kernel-12.8.0"

    def __init__(self, cfg: Mapping[str, Any], event_store: EventStore | None = None) -> None:
        self._policy: CapabilityPolicy | None = None
        self.cfg = dict(cfg); kernel_cfg = dict(self.cfg.get("kernel", {})); self.events = event_store or EventStore(kernel_cfg.get("event_db", "data/kernel_12_8_0_events.db")); policy_cfg = dict(kernel_cfg.get("capabilities", {})); self.policy = CapabilityPolicy(policy_cfg.get("allow", []), policy_cfg.get("approval_required"))
        self.evidence = EvidenceLedger(kernel_cfg.get("evidence_db", "data/kernel_12_8_0_evidence.db")); self.missions = MissionWAL(kernel_cfg.get("mission_db", "data/kernel_12_8_0_missions.db")); self.undo = UndoExecutor(db_path=kernel_cfg.get("mission_db", "data/kernel_12_8_0_missions.db")); self.cancel = HardCancellation(); resource_cfg = dict(kernel_cfg.get("resources", {}))
        secret_text = str(kernel_cfg.get("memory_secret", "") or os.environ.get("JARVIS_MEMORY_SECRET", "") or os.environ.get("JARVIS_MASTER_SECRET", ""))
        secret = hashlib.sha256(secret_text.encode("utf-8")).digest() if secret_text else os.urandom(32)
        identity_path = kernel_cfg.get("identity_state", "data/kernel_12_8_0_identity.json")
        self.identity = AgentIdentityAuthority(state_path=identity_path, secret=secret) if secret_text else AgentIdentityAuthority()
        self.resources = ResourceLedger(ResourceBudget(**{k: resource_cfg[k] for k in resource_cfg if k in ResourceBudget.__dataclass_fields__})); self.thermal = ThermalGovernor(); self.promotion = PromotionEngine(kernel_cfg.get("promotion_db", "data/kernel_12_8_0_promotions.db"), approval_public_key_b64=kernel_cfg.get("promotion_approval_public_key") or os.environ.get("JARVIS_PROMOTION_PUBLIC_KEY")); self.mcp = MCPControlPlane(authority=self.identity); self.a2a = A2AControlPlane(self.identity); self.inference = EmpiricalInferenceRouter(); self.prefix_cache = PrefixKVCache();
        self.memory = MemoryFabric(secret, kernel_cfg.get("memory_db", "data/kernel_12_8_0_memory.db")); self.experiments = ExperimentStore(kernel_cfg.get("experiment_db", "data/kernel_12_8_0_experiments.db")); self.execution = KernelExecutionAuthority(self.policy, self.resources, audit_path=kernel_cfg.get("execution_audit_log", "logs/execution_audit.log")); self.computer_use = ComputerUseAuthority()
        self.credentials = SenderConstrainedCredentialAuthority(self.identity)
        self.federation = FederationRegistry(self.identity, node_id=str(kernel_cfg.get("node_id", "node-local-12.8.0")))
        self.attention = AttentionBudgetEngine(self.resources)
        self.traces = TraceLedger(); self.otel = OpenTelemetryBridge()
        self.wasi = WASIComponentRuntime(self.policy)
        self.digital_twin = DigitalTwinProjection()
        self.continual_learning = ContinualLearningManager(promotion=self.promotion)
        self.assurance = AssuranceKernel(self.policy, self.execution)
        self._handlers: dict[str, list[Callable[[EventEnvelope], None]]] = {}; self._commands: dict[str, tuple[Callable[..., Any], str]] = {}; self._lock = threading.RLock(); self._started = False; self._closed = False

    @property
    def policy(self) -> CapabilityPolicy:
        """Return the live capability policy used by every authorization authority."""
        if self._policy is None:
            raise RuntimeError("capability policy is not initialized")
        return self._policy

    @policy.setter
    def policy(self, value: CapabilityPolicy) -> None:
        """Atomically propagate policy replacement to all security authorities."""
        if not isinstance(value, CapabilityPolicy):
            raise TypeError("policy must be a CapabilityPolicy")
        self._policy = value
        assurance = getattr(self, "assurance", None)
        if assurance is not None:
            assurance.policy = value
        execution = getattr(self, "execution", None)
        if execution is not None:
            execution.policy = value

    def subscribe(self, topic: str, handler: Callable[[EventEnvelope], None]) -> None:
        if self._closed:
            raise RuntimeError("kernel is closed")
        if not topic.strip() or not callable(handler): raise TypeError("topic and handler are required")
        with self._lock: self._handlers.setdefault(str(topic), []).append(handler)

    def publish(self, topic: str, payload: Mapping[str, Any] | None = None, *, correlation_id: str | None = None, causation_id: str | None = None) -> int:
        if self._closed:
            raise RuntimeError("kernel is closed")
        event = EventEnvelope(topic=str(topic), payload=dict(payload or {}), correlation_id=correlation_id or uuid7(), causation_id=causation_id, source="jarvis-12.8.0")
        seq = self.events.append(event)
        with self._lock: handlers = tuple(self._handlers.get(event.topic, ())) + tuple(self._handlers.get("*", ()))
        for handler in handlers:
            try: handler(event)
            except Exception: logger.exception("kernel_event_handler_failed", extra={"topic": event.topic})
        return seq

    def register_command(self, name: str, handler: Callable[..., Any], *, capability: str = "tools.read") -> None:
        with self._lock:
            if not name.strip() or not callable(handler) or not capability.strip(): raise ValueError("invalid command registration")
            if name in self._commands: raise ValueError(f"command already registered: {name}")
            self._commands[str(name)] = (handler, str(capability))

    def authorize(self, request: CapabilityRequest, *, approved: bool = False) -> Decision:
        decision, proof = self.assurance.authorize(request, approved=approved)
        self.publish("security.decision", {
            "capability": request.capability,
            "allowed": decision.allowed,
            "reason": decision.reason,
            "decision_id": decision.decision_id,
            "requires_approval": decision.requires_approval,
            "proof_id": proof.proof_id if proof else None,
            "proof_digest": proof.digest() if proof else None,
        })
        return decision

    def dispatch_command(self, command: Command, *, approved: bool = False) -> Any:
        entry = self._commands.get(command.name)
        if entry is None: raise KeyError(f"unknown command: {command.name}")
        handler, registered = entry; requested = (command.capability or registered).strip()
        if requested != registered:
            self.authorize(CapabilityRequest(requested)); raise PermissionError("requested capability differs from registered authority")
        decision = self.authorize(CapabilityRequest(registered), approved=approved)
        if not decision.allowed: raise PermissionError(decision.reason)
        if command.idempotency_key:
            cached = self.events.get_command_result(command.idempotency_key)
            if cached is not None: return cached
        started = Clock.monotonic(); self.publish("command.started", {"command_id": command.command_id, "name": command.name, "capability": registered}, correlation_id=command.correlation_id)
        try: result = handler(**dict(command.args))
        except Exception as exc:
            self.publish("command.failed", {"command_id": command.command_id, "name": command.name, "error_type": type(exc).__name__}, correlation_id=command.correlation_id); raise
        if command.idempotency_key: self.events.save_command_result(command.idempotency_key, command.name, result)
        self.publish("command.completed", {"command_id": command.command_id, "name": command.name, "duration_ms": (Clock.monotonic() - started) * 1000.0}, correlation_id=command.correlation_id); return result

    def record_evidence(self, envelope: EvidenceEnvelope) -> int:
        seq = self.evidence.append(envelope); self.publish("evidence.recorded", {"evidence_id": envelope.evidence_id, "trace_id": envelope.trace_id, "mission_id": envelope.mission_id}, correlation_id=envelope.trace_id); return seq

    def mission_timeline(self, mission_id: str, *, limit: int = 500) -> dict[str, Any]:
        """Return an operator-safe, replay-oriented timeline for one mission."""
        mission_id = str(mission_id).strip()
        if not mission_id:
            raise ValueError("mission_id is required")
        event_rows = []
        for event in self.events.replay(after_seq=0, limit=max(1, min(int(limit) * 4, 10000))):
            payload = dict(event.payload)
            if payload.get("mission_id") == mission_id or (event.topic.startswith("mission.") and payload.get("mission_id") == mission_id):
                event_rows.append({
                    "event_id": event.event_id,
                    "topic": event.topic,
                    "payload": payload,
                    "wall_time": event.wall_time,
                    "monotonic_time": event.monotonic_time,
                    "correlation_id": event.correlation_id,
                    "causation_id": event.causation_id,
                    "schema_version": event.schema_version,
                    "source": event.source,
                })
        event_rows = sorted(event_rows, key=lambda row: (float(row["wall_time"]), str(row["event_id"])), reverse=True)[: max(1, min(int(limit), 1000))]
        evidence_rows = [item.to_dict() for item in self.evidence.query(mission_id=mission_id, limit=max(1, min(int(limit), 1000)))]
        return {
            "mission_id": mission_id,
            "kernel_id": self.KERNEL_ID,
            "version": self.VERSION,
            "mission_state": self.missions.restore(mission_id),
            "events": event_rows,
            "evidence": evidence_rows,
            "integrity": {"events": self.events.verify(), "evidence": self.evidence.verify()},
        }

    def health(self) -> dict[str, Any]:
        return {
            "version": self.VERSION,
            "kernel_id": self.KERNEL_ID,
            "started": self._started,
            "events": self.events.count(),
            "evidence_verified": self.evidence.verify(),
            "event_chain_verified": self.events.verify(),
            "capability_handlers": len(self._commands),
            "promotion_candidates": len(self.promotion.snapshot()),
            "mcp_quarantine": len(self.mcp.quarantine()),
            "resource": self.resources.snapshot(),
            "identity": self.identity.trust_snapshot(),
            "federation": self.federation.snapshot(),
            "trace_spans": len(self.traces.recent(100000)),
            "otel_available": self.otel.available,
            "wasi_runtime_available": self.wasi.runtime_available(),
            "digital_twin": self.digital_twin.snapshot(),
            "assurance_proofs": len(self.assurance.snapshot()),
            "timestamp": time.time(),
        }

    def start(self) -> None:
        if self._started: return
        self._started = True; self.publish("runtime.started", {"version": self.VERSION, "kernel_id": self.KERNEL_ID})

    def stop(self) -> None:
        if not self._started: return
        self.publish("runtime.stopping", {}); self._started = False

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
        if self._started:
            try:
                self.stop()
            except Exception:
                logger.exception("kernel_stop_failed")
        with self._lock:
            self._closed = True
        for resource in (self.evidence, self.missions, self.undo, self.memory, self.experiments, self.promotion, self.mcp, self.execution, self.events):
            try:
                resource.close()
            except Exception:
                logger.exception("kernel_resource_close_failed", extra={"resource": type(resource).__name__})

    def __enter__(self) -> "JarvisKernelRuntime":
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()



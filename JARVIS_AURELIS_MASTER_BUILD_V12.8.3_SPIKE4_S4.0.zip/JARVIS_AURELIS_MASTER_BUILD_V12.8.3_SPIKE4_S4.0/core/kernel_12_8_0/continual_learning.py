"""Controlled continual-learning data, training and promotion lifecycle for 12.8.0."""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_json, digest
from .promotion import PromotionEngine
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class LearningExample:
    example_id: str
    prompt: str
    response: str
    quality: float
    source: str
    context_digest: str
    created_at: float


@dataclass(frozen=True, slots=True)
class LoRAConfig:
    r: int = 8
    alpha: int = 32
    dropout: float = 0.1
    task_type: str = "CAUSAL_LM"


class ContinualLearningManager:
    """Store quality-gated examples and expose a real PEFT training entry point."""

    def __init__(self, root: str | Path = "data/kernel_12_8_0_continual", *, quality_threshold: float = 0.7, max_replay: int = 1000, promotion: PromotionEngine | None = None) -> None:
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
        self.quality_threshold = max(0.0, min(1.0, float(quality_threshold)))
        self.max_replay = max(1, min(int(max_replay), 1_000_000))
        self.replay_path = self.root / "replay_buffer.jsonl"
        self.integrity_path = self.root / "replay_buffer.sha256"
        self.promotion = promotion

    def record(self, *, prompt: str, response: str, quality: float, source: str, context: Mapping[str, Any]) -> LearningExample | None:
        score = float(quality)
        if not 0.0 <= score <= 1.0:
            raise ValueError("quality must be between 0 and 1")
        if score < self.quality_threshold:
            return None
        example = LearningExample(uuid7(), str(prompt), str(response), score, str(source), digest(context), time.time())
        with self.replay_path.open("a", encoding="utf-8") as handle:
            handle.write(canonical_json(asdict(example)).decode("utf-8") + "\n")
        self._trim()
        self._write_integrity()
        return example

    def _trim(self) -> None:
        if not self.replay_path.exists():
            return
        rows = self.replay_path.read_text(encoding="utf-8").splitlines()
        if len(rows) > self.max_replay:
            self.replay_path.write_text("\n".join(rows[-self.max_replay:]) + "\n", encoding="utf-8")

    def _write_integrity(self) -> None:
        digest_value = digest(self.replay_path.read_bytes().hex()) if self.replay_path.exists() else digest("")
        self.integrity_path.write_text(digest_value, encoding="ascii")

    def _verify_integrity(self) -> None:
        if not self.replay_path.exists():
            return
        if not self.integrity_path.exists():
            raise RuntimeError("continual-learning replay integrity metadata is missing")
        actual = digest(self.replay_path.read_bytes().hex())
        expected = self.integrity_path.read_text(encoding="ascii").strip()
        if actual != expected:
            raise RuntimeError("continual-learning replay buffer integrity check failed")

    def replay(self) -> list[LearningExample]:
        if not self.replay_path.exists():
            return []
        self._verify_integrity()
        rows: list[LearningExample] = []
        for line in self.replay_path.read_text(encoding="utf-8").splitlines()[-self.max_replay:]:
            data = json.loads(line)
            rows.append(LearningExample(**data))
        return rows

    def training_manifest(self, *, base_model: str, output_dir: str | Path, holdout_digest: str, lora: LoRAConfig | None = None) -> dict[str, Any]:
        examples = self.replay()
        if not examples:
            raise RuntimeError("continual-learning replay buffer is empty")
        return {"version": "12.8.0", "training_id": uuid7(), "base_model": str(base_model), "output_dir": str(Path(output_dir).resolve()), "examples": len(examples), "replay_digest": digest([asdict(item) for item in examples]), "holdout_digest": str(holdout_digest), "quality_threshold": self.quality_threshold, "lora": asdict(lora or LoRAConfig())}

    def train(self, *, base_model: str, output_dir: str | Path, tokenizer_name: str | None = None, epochs: float = 1.0) -> dict[str, Any]:
        """Run actual Transformers + PEFT causal-LM fine-tuning when the required stack is installed."""
        try:
            import torch
            from peft import LoraConfig as PeftLoraConfig, get_peft_model
            from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments
        except ImportError as exc:
            return {"ok": False, "status": "NOT_INSTALLED", "error": f"training stack unavailable: {type(exc).__name__}", "required": ["torch", "transformers", "peft"]}
        examples = self.replay()
        if not examples:
            return {"ok": False, "status": "BLOCKED", "error": "replay buffer is empty"}
        target = Path(output_dir).resolve(); target.mkdir(parents=True, exist_ok=True)
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name or base_model, use_fast=True)
        model = AutoModelForCausalLM.from_pretrained(base_model)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        peft_cfg = PeftLoraConfig(r=8, lora_alpha=32, lora_dropout=0.1, task_type="CAUSAL_LM")
        model = get_peft_model(model, peft_cfg)
        class _Dataset(torch.utils.data.Dataset):
            def __init__(self, rows: list[LearningExample]) -> None:
                self.rows = rows
            def __len__(self) -> int:
                return len(self.rows)
            def __getitem__(self, index: int) -> dict[str, Any]:
                row = self.rows[index]
                encoded = tokenizer(f"User: {row.prompt}\nAssistant: {row.response}", truncation=True, max_length=min(4096, int(getattr(tokenizer, "model_max_length", 4096))))
                encoded["labels"] = list(encoded["input_ids"])
                return encoded
        args = TrainingArguments(output_dir=str(target), num_train_epochs=float(epochs), per_device_train_batch_size=1, gradient_accumulation_steps=1, logging_strategy="steps", logging_steps=10, save_strategy="epoch", report_to=[])
        trainer = Trainer(model=model, args=args, train_dataset=_Dataset(examples), tokenizer=tokenizer)
        trainer.train()
        trainer.save_model(str(target)); tokenizer.save_pretrained(str(target))
        artifact_files: dict[str, str] = {}
        for item in sorted(target.rglob("*")):
            if item.is_file() and item.name != "TRAINING_MANIFEST.json":
                artifact_files[str(item.relative_to(target))] = digest(item.read_bytes().hex())
        replay_digest = digest([asdict(item) for item in examples])
        artifact_manifest = {
            "version": "12.8.0",
            "base_model": str(base_model),
            "examples": len(examples),
            "replay_digest": replay_digest,
            "artifact_files": artifact_files,
            "promotion_required": True,
        }
        artifact_path = target / "TRAINING_MANIFEST.json"
        artifact_path.write_text(json.dumps(artifact_manifest, sort_keys=True, indent=2), encoding="utf-8")
        promotion_candidate = None
        if self.promotion is not None:
            evidence = {
                "replay_digest": replay_digest,
                "artifact_manifest_digest": digest(artifact_manifest),
                "training_policy": "quarantine-until-independent-evaluation",
            }
            promotion_candidate = self.promotion.propose(
                kind="model.lora",
                artifact=canonical_json(artifact_manifest),
                evidence=evidence,
            )
            self.promotion.evaluate(
                promotion_candidate.candidate_id,
                tests={"passed": False, "reason": "independent post-training tests required"},
                benchmarks={"passed": False, "reason": "independent benchmark required"},
                security={"passed": False, "reason": "independent security evaluation required"},
                policy={"passed": False, "reason": "independent policy evaluation required"},
                resources={"passed": False, "reason": "independent resource evaluation required"},
            )
        return {
            "ok": True,
            "status": "trained",
            "output_dir": str(target),
            "examples": len(examples),
            "replay_digest": replay_digest,
            "promotion_required": True,
            "promotion_candidate_id": promotion_candidate.candidate_id if promotion_candidate is not None else None,
            "promotion_status": "quarantined" if promotion_candidate is not None else "external",
        }



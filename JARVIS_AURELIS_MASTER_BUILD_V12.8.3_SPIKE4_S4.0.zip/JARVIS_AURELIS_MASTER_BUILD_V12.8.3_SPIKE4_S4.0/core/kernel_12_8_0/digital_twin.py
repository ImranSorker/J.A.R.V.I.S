"""Temporal digital-twin projection over canonical 12.8.0 kernel events."""
from __future__ import annotations

import threading
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .canonical import digest
from .ids import Clock


@dataclass(frozen=True, slots=True)
class TwinEntity:
    entity_id: str
    entity_type: str
    properties: Mapping[str, Any]
    revision: int
    observed_at: float
    source_event_id: str | None


class DigitalTwinProjection:
    """Maintain a bounded descriptive state graph; it never authorizes actions."""

    def __init__(self, *, max_entities: int = 50_000) -> None:
        self.max_entities = max(100, min(int(max_entities), 1_000_000))
        self._entities: dict[str, TwinEntity] = {}
        self._edges: set[tuple[str, str, str]] = set()
        self._lock = threading.RLock()

    def observe(self, entity_id: str, entity_type: str, properties: Mapping[str, Any], *, source_event_id: str | None = None) -> TwinEntity:
        key = str(entity_id).strip()
        kind = str(entity_type).strip()
        if not key or not kind:
            raise ValueError("entity_id and entity_type are required")
        with self._lock:
            old = self._entities.get(key)
            revision = 1 if old is None else old.revision + 1
            item = TwinEntity(key, kind, dict(properties), revision, Clock.wall(), source_event_id)
            self._entities[key] = item
            if len(self._entities) > self.max_entities:
                victim = min(self._entities.values(), key=lambda e: (e.observed_at, e.entity_id))
                self._entities.pop(victim.entity_id, None)
            return item

    def relate(self, source: str, relation: str, target: str) -> None:
        triple = (str(source), str(relation), str(target))
        if not all(triple):
            raise ValueError("twin relation fields are required")
        with self._lock:
            self._edges.add(triple)

    def diff(self, before: Mapping[str, Any], after: Mapping[str, Any]) -> dict[str, Any]:
        before_d = dict(before); after_d = dict(after)
        keys = sorted(set(before_d) | set(after_d))
        return {"changed": {k: {"before": before_d.get(k), "after": after_d.get(k)} for k in keys if before_d.get(k) != after_d.get(k)}, "before_digest": digest(before_d), "after_digest": digest(after_d)}

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"version": "12.8.0", "entities": [asdict(self._entities[key]) for key in sorted(self._entities)], "edges": [list(edge) for edge in sorted(self._edges)]}



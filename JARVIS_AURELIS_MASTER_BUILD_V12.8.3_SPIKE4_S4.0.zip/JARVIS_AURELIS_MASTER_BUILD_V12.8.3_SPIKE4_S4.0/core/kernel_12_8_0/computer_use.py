"""Computer-use authority that binds actions to verified application/page context."""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from urllib.parse import urlparse


class ActionRisk(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass(frozen=True, slots=True)
class ObservedContext:
    application_id: str
    origin: str | None
    verified: bool
    identity: str | None = None


@dataclass(frozen=True, slots=True)
class ComputerUseDecision:
    allowed: bool
    risk: ActionRisk
    reason: str
    requires_approval: bool


class ComputerUseAuthority:
    """Classify GUI actions and require stronger evidence for consequential effects."""

    _RISKS = {
        "type": ActionRisk.LOW,
        "click": ActionRisk.LOW,
        "open_url": ActionRisk.MEDIUM,
        "upload": ActionRisk.HIGH,
        "download_execute": ActionRisk.CRITICAL,
        "send_email": ActionRisk.HIGH,
        "financial_transaction": ActionRisk.CRITICAL,
        "delete": ActionRisk.CRITICAL,
    }

    def evaluate(self, context: ObservedContext, action: str, *, target_url: str | None = None, approval: bool = False) -> ComputerUseDecision:
        risk = self._RISKS.get(str(action), ActionRisk.CRITICAL)
        if not context.verified:
            return ComputerUseDecision(False, risk, "application identity is not verified", risk >= ActionRisk.HIGH)
        if not context.identity:
            return ComputerUseDecision(False, risk, "actor identity is required", risk >= ActionRisk.HIGH)
        if target_url:
            parsed = urlparse(target_url)
            if parsed.scheme not in {"https", "http"} or not parsed.netloc:
                return ComputerUseDecision(False, risk, "invalid target origin", risk >= ActionRisk.HIGH)
            if context.origin and urlparse(context.origin).netloc != parsed.netloc and risk >= ActionRisk.HIGH:
                return ComputerUseDecision(False, risk, "target origin differs from verified context", True)
        needs = risk >= ActionRisk.HIGH
        if needs and not approval:
            return ComputerUseDecision(False, risk, "explicit approval required", True)
        return ComputerUseDecision(True, risk, "authorized", needs)



"""Unified resource and thermal governance for the 12.8.0 kernel."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True, slots=True)
class ResourceBudget:
    cpu_seconds: float = 3600.0
    gpu_vram_mb: int = 16_384
    ram_mb: int = 8192
    tokens: int = 1_000_000
    network_requests: int = 500
    storage_mb: int = 1024
    notifications: int = 100


@dataclass(frozen=True, slots=True)
class ResourceLease:
    lease_id: str
    owner: str
    mission_id: str
    allocated: dict[str, float]
    deadline_monotonic: float
    created_at: float


class ResourceLedger:
    """Atomic multi-resource reservation ledger."""

    def __init__(self, budget: ResourceBudget) -> None:
        self.budget = budget; self._used = {k: 0.0 for k in asdict(budget)}; self._leases: dict[str, ResourceLease] = {}; self._lock = threading.RLock()

    def reserve(self, owner: str, mission_id: str, allocations: dict[str, float], *, ttl_seconds: float = 300.0) -> ResourceLease:
        self.reap_expired()
        normalized = {str(k): float(v) for k, v in allocations.items()}
        if any(not (v >= 0 and v == v and abs(v) != float("inf")) for v in normalized.values()): raise ValueError("resource allocations must be finite and non-negative")
        limits = asdict(self.budget)
        if not normalized or any(k not in limits or v < 0 for k, v in normalized.items()): raise ValueError("invalid resource allocation")
        with self._lock:
            if any(self._used[k] + v > float(limits[k]) for k, v in normalized.items()): raise RuntimeError("resource budget exceeded")
            import uuid
            lease = ResourceLease(f"rlease_{uuid.uuid4().hex}", str(owner), str(mission_id), normalized, time.monotonic() + max(1.0, float(ttl_seconds)), time.time())
            self._leases[lease.lease_id] = lease
            for k, v in normalized.items(): self._used[k] += v
            return lease

    def release(self, lease_id: str) -> bool:
        with self._lock:
            lease = self._leases.pop(str(lease_id), None)
            if lease is None: return False
            for k, v in lease.allocated.items(): self._used[k] = max(0.0, self._used[k] - v)
            return True


    def reap_expired(self) -> int:
        """Release leases whose monotonic deadline has elapsed."""
        now = time.monotonic()
        with self._lock:
            expired = [lease_id for lease_id, lease in self._leases.items() if lease.deadline_monotonic <= now]
            for lease_id in expired:
                lease = self._leases.pop(lease_id)
                for key, amount in lease.allocated.items():
                    self._used[key] = max(0.0, self._used[key] - amount)
            return len(expired)

    def snapshot(self) -> dict[str, Any]:
        self.reap_expired()
        with self._lock: return {"budget": asdict(self.budget), "used": dict(self._used), "active_leases": len(self._leases), "owners": sorted({x.owner for x in self._leases.values()})}


@dataclass(frozen=True, slots=True)
class ThermalState:
    state: str
    temperature_c: float | None
    enter_threshold_c: float
    leave_threshold_c: float
    background_fraction: float
    updated_at: float


class ThermalGovernor:
    """Hysteretic thermal governor to prevent throttling oscillation."""

    def __init__(self, *, hot_enter_c: float = 80.0, hot_leave_c: float = 72.0) -> None:
        if not hot_leave_c < hot_enter_c: raise ValueError("thermal leave threshold must be lower than enter threshold")
        self.hot_enter_c = float(hot_enter_c); self.hot_leave_c = float(hot_leave_c); self._state = "normal"; self._lock = threading.RLock()

    def update(self, temperature_c: float | None, *, battery: bool = False, critical_c: float = 92.0) -> ThermalState:
        with self._lock:
            temp = None if temperature_c is None else float(temperature_c)
            if temp is not None and temp >= float(critical_c): self._state = "critical"
            elif temp is not None and self._state == "critical" and temp > self.hot_leave_c: self._state = "hot"
            elif temp is not None and temp >= self.hot_enter_c: self._state = "hot"
            elif temp is not None and temp <= self.hot_leave_c: self._state = "normal"
            if battery and self._state == "normal": state = "battery"
            else: state = self._state
            fraction = {"critical": 0.0, "hot": 0.35, "normal": 1.0, "battery": 0.65}.get(state, 0.5)
            return ThermalState(state, temp, self.hot_enter_c, self.hot_leave_c, fraction, time.time())



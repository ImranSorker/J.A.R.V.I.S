"""Durable SQLite WAL/event ledger used by the J.A.R.V.I.S. 12.8.0 kernel."""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .canonical import canonical_json, canonical_bytes
from .contracts import EventEnvelope


class EventStore:
    """Append-only WAL with hash-chain integrity and idempotency results."""

    def __init__(self, db_path: str | Path = "data/kernel_12_8_0_events.db") -> None:
        self.db_path = str(Path(db_path).resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._closed = False
        self._init()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        if self._closed:
            raise RuntimeError("event store is closed")
        conn = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("PRAGMA busy_timeout=20000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init(self) -> None:
        with self._lock, self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT UNIQUE NOT NULL,
                topic TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                wall_time REAL NOT NULL,
                monotonic_time REAL NOT NULL,
                correlation_id TEXT NOT NULL,
                causation_id TEXT,
                schema_version INTEGER NOT NULL,
                source TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                record_hash TEXT NOT NULL
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_events_topic_seq ON events(topic, seq)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_events_corr_seq ON events(correlation_id, seq)")
            db.execute("""CREATE TABLE IF NOT EXISTS command_results (
                idempotency_key TEXT PRIMARY KEY,
                command_name TEXT NOT NULL,
                result_json TEXT NOT NULL,
                created_at REAL NOT NULL
            )""")

    def _tail_hash(self, db: sqlite3.Connection) -> str:
        row = db.execute("SELECT record_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        return str(row[0]) if row else "0" * 64

    def append(self, event: EventEnvelope) -> int:
        payload_json = canonical_json(dict(event.payload)).decode("utf-8")
        with self._lock, self._connect() as db:
            existing = db.execute("SELECT seq FROM events WHERE event_id=?", (event.event_id,)).fetchone()
            if existing is not None:
                return int(existing[0])
            previous = self._tail_hash(db)
            import hashlib
            record_hash = hashlib.sha256(canonical_bytes({"hash_material": {
                "event_id": event.event_id,
                "topic": event.topic,
                "payload": dict(event.payload),
                "wall_time": event.wall_time,
                "monotonic_time": event.monotonic_time,
                "correlation_id": event.correlation_id,
                "causation_id": event.causation_id,
                "schema_version": event.schema_version,
                "source": event.source,
                "previous_hash": previous,
            }})).hexdigest()
            cur = db.execute(
                "INSERT INTO events(event_id,topic,payload_json,wall_time,monotonic_time,correlation_id,causation_id,schema_version,source,previous_hash,record_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (event.event_id, event.topic, payload_json, event.wall_time, event.monotonic_time, event.correlation_id, event.causation_id, event.schema_version, event.source, previous, record_hash),
            )
            return int(cur.lastrowid)

    def replay(self, topic: str | None = None, after_seq: int = 0, limit: int = 1000) -> list[EventEnvelope]:
        sql = "SELECT event_id,topic,payload_json,wall_time,monotonic_time,correlation_id,causation_id,schema_version,source FROM events WHERE seq>?"
        args: list[object] = [int(after_seq)]
        if topic:
            sql += " AND topic=?"
            args.append(str(topic))
        sql += " ORDER BY seq LIMIT ?"
        args.append(max(1, min(int(limit), 10_000)))
        with self._lock, self._connect() as db:
            rows = db.execute(sql, args).fetchall()
        return [EventEnvelope(event_id=r[0], topic=r[1], payload=json.loads(r[2]), wall_time=r[3], monotonic_time=r[4], correlation_id=r[5], causation_id=r[6], schema_version=r[7], source=r[8]) for r in rows]

    def verify(self) -> bool:
        import hashlib
        previous = "0" * 64
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT event_id,topic,payload_json,wall_time,monotonic_time,correlation_id,causation_id,schema_version,source,previous_hash,record_hash FROM events ORDER BY seq").fetchall()
        for row in rows:
            expected = hashlib.sha256(canonical_bytes({"hash_material": {"event_id": row[0], "topic": row[1], "payload": json.loads(row[2]), "wall_time": row[3], "monotonic_time": row[4], "correlation_id": row[5], "causation_id": row[6], "schema_version": row[7], "source": row[8], "previous_hash": previous}})).hexdigest()
            if row[9] != previous or row[10] != expected:
                return False
            previous = expected
        return True

    def get_command_result(self, idempotency_key: str) -> object | None:
        with self._lock, self._connect() as db:
            row = db.execute("SELECT result_json FROM command_results WHERE idempotency_key=?", (str(idempotency_key),)).fetchone()
        return None if row is None else json.loads(row[0])

    def save_command_result(self, idempotency_key: str, command_name: str, result: object) -> None:
        with self._lock, self._connect() as db:
            db.execute("INSERT OR IGNORE INTO command_results(idempotency_key,command_name,result_json,created_at) VALUES(?,?,?,strftime('%s','now'))", (str(idempotency_key), str(command_name), json.dumps(result, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)))

    def count(self) -> int:
        with self._lock, self._connect() as db:
            return int(db.execute("SELECT COUNT(*) FROM events").fetchone()[0])

    def tail(self, limit: int = 100) -> list[dict[str, object]]:
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT seq,event_id,topic,wall_time,correlation_id,record_hash FROM events ORDER BY seq DESC LIMIT ?", (max(1, min(int(limit), 1000)),)).fetchall()
        return [{"seq": r[0], "event_id": r[1], "topic": r[2], "wall_time": r[3], "correlation_id": r[4], "record_hash": r[5]} for r in rows]

    def close(self) -> None:
        self._closed = True

    def __enter__(self) -> "EventStore":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()



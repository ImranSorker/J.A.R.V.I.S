"""Attested multi-node federation and evidence-safe anti-entropy for 12.8.0."""
from __future__ import annotations

import base64
import time
from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .canonical import canonical_bytes, digest
from .identity import AgentIdentityAuthority, ReplayCache
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class NodeDescriptor:
    node_id: str
    version: str
    hardware: Mapping[str, Any]
    models: tuple[str, ...]
    tools: tuple[str, ...]
    skills: tuple[str, ...]
    thermal_state: str
    available_memory_mb: int
    battery_percent: float | None
    network_state: str
    trust_level: str
    available: bool = True
    updated_at: float = 0.0


@dataclass(frozen=True, slots=True)
class NodeAttestation:
    node_id: str
    issuer: str
    key_id: str
    issued_at: float
    nonce: str
    descriptor_digest: str
    signature_b64: str


class FederationRegistry:
    """Maintain signed node state with deterministic, evidence-safe anti-entropy."""

    VERSION = "12.8.0"

    def __init__(self, authority: AgentIdentityAuthority | None = None, *, node_id: str | None = None) -> None:
        self.authority = authority or AgentIdentityAuthority()
        self.node_id = str(node_id or f"node_{uuid7()}")
        self._nodes: dict[str, NodeDescriptor] = {}
        self._vector: dict[str, int] = {self.node_id: 0}
        self._replay = ReplayCache(max_entries=50_000)

    def update_local(self, *, hardware: Mapping[str, Any], models: tuple[str, ...] = (), tools: tuple[str, ...] = (), skills: tuple[str, ...] = (), thermal_state: str = "normal", available_memory_mb: int = 0, battery_percent: float | None = None, network_state: str = "offline", trust_level: str = "local") -> NodeDescriptor:
        self._vector[self.node_id] = self._vector.get(self.node_id, 0) + 1
        descriptor = NodeDescriptor(self.node_id, self.VERSION, dict(hardware), tuple(sorted(set(models))), tuple(sorted(set(tools))), tuple(sorted(set(skills))), str(thermal_state), max(0, int(available_memory_mb)), None if battery_percent is None else float(battery_percent), str(network_state), str(trust_level), True, time.time())
        self._nodes[self.node_id] = descriptor
        return descriptor

    def register(self, descriptor: NodeDescriptor) -> None:
        if descriptor.version != self.VERSION:
            raise ValueError("federated node version mismatch")
        if not descriptor.node_id.strip():
            raise ValueError("node_id is required")
        self._nodes[descriptor.node_id] = descriptor
        self._vector.setdefault(descriptor.node_id, 0)

    def attest(self, descriptor: NodeDescriptor | None = None) -> NodeAttestation:
        value = descriptor or self._nodes.get(self.node_id)
        if value is None:
            raise KeyError(self.node_id)
        issued = time.time()
        nonce = uuid7()
        material = {"node_id": value.node_id, "issuer": self.authority.issuer, "key_id": self.authority.key_id, "issued_at": issued, "nonce": nonce, "descriptor_digest": digest(asdict(value))}
        signature = base64.b64encode(self.authority.sign_bytes(canonical_bytes(material))).decode("ascii")
        return NodeAttestation(signature_b64=signature, **material)

    def verify_attestation(self, attestation: NodeAttestation, *, descriptor: NodeDescriptor, max_age_seconds: float = 900.0) -> bool:
        now = time.time()
        if attestation.node_id != descriptor.node_id or attestation.issuer != self.authority.issuer or attestation.key_id != self.authority.key_id:
            return False
        if now - attestation.issued_at > max(1.0, min(float(max_age_seconds), 3600.0)):
            return False
        material = {"node_id": attestation.node_id, "issuer": attestation.issuer, "key_id": attestation.key_id, "issued_at": attestation.issued_at, "nonce": attestation.nonce, "descriptor_digest": attestation.descriptor_digest}
        try:
            self.authority.public_key.verify(base64.b64decode(attestation.signature_b64, validate=True), canonical_bytes(material))
        except Exception:
            return False
        if attestation.descriptor_digest != digest(asdict(descriptor)):
            return False
        return self._replay.consume(attestation.nonce, expires_at=min(now + max_age_seconds, now + 3600.0))

    def anti_entropy(self, remote_vector: Mapping[str, int], remote_records: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        """Exchange only unseen records and flag evidence conflicts instead of last-writer-wins."""
        unseen = [node_id for node_id, counter in remote_vector.items() if int(counter) > int(self._vector.get(str(node_id), 0))]
        conflicts: list[str] = []
        accepted: list[str] = []
        for node_id, payload in remote_records.items():
            if node_id not in unseen:
                continue
            local = self._nodes.get(node_id)
            remote_digest = digest(dict(payload))
            if local is not None and digest(asdict(local)) != remote_digest:
                conflicts.append(node_id)
                continue
            accepted.append(node_id)
        return {"unseen_nodes": sorted(unseen), "accepted": sorted(accepted), "conflicts": sorted(conflicts), "local_vector": dict(sorted(self._vector.items()))}

    def snapshot(self) -> dict[str, Any]:
        return {"version": self.VERSION, "node_id": self.node_id, "vector": dict(sorted(self._vector.items())), "nodes": [asdict(self._nodes[key]) for key in sorted(self._nodes)]}



"""Trace/span primitives with optional OpenTelemetry export for 12.8.0."""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping

from .canonical import digest
from .ids import uuid7


@dataclass(slots=True)
class TraceSpan:
    trace_id: str
    span_id: str
    parent_span_id: str | None
    mission_id: str | None
    agent_id: str | None
    operation: str
    started_at: float
    finished_at: float | None = None
    attributes: dict[str, Any] = field(default_factory=dict)
    status: str = "running"

    def finish(self, *, status: str = "ok", attributes: Mapping[str, Any] | None = None) -> "TraceSpan":
        if self.finished_at is not None:
            raise RuntimeError("trace span already finished")
        if attributes:
            self.attributes.update(dict(attributes))
        self.finished_at = time.time()
        self.status = str(status)
        return self

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def span_digest(self) -> str:
        return digest(self.as_dict())


class TraceLedger:
    """In-memory bounded span registry; durable persistence belongs to EventStore."""

    def __init__(self, *, max_spans: int = 100_000) -> None:
        self.max_spans = max(100, min(int(max_spans), 1_000_000))
        self._spans: list[TraceSpan] = []

    def start(self, operation: str, *, mission_id: str | None = None, agent_id: str | None = None, trace_id: str | None = None, parent_span_id: str | None = None, attributes: Mapping[str, Any] | None = None) -> TraceSpan:
        span = TraceSpan(str(trace_id or uuid7()), uuid7(), parent_span_id, mission_id, agent_id, str(operation), time.time(), attributes=dict(attributes or {}))
        self._spans.append(span)
        if len(self._spans) > self.max_spans:
            del self._spans[: len(self._spans) - self.max_spans]
        return span

    def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        return [span.as_dict() for span in self._spans[-max(1, min(int(limit), 1000)):]]


class OpenTelemetryBridge:
    """Emit a TraceSpan through OpenTelemetry when the optional SDK is installed."""

    def __init__(self, tracer_name: str = "jarvis.12.8.0") -> None:
        try:
            from opentelemetry import trace
        except ImportError:
            self._tracer = None
        else:
            self._tracer = trace.get_tracer(str(tracer_name))

    @property
    def available(self) -> bool:
        return self._tracer is not None

    def export(self, span: TraceSpan) -> bool:
        """Emit one finished span into the configured OpenTelemetry tracer."""
        if self._tracer is None or span.finished_at is None:
            return False
        from opentelemetry.trace import Status, StatusCode
        current = self._tracer.start_span(span.operation, start_time=int(span.started_at * 1_000_000_000))
        for key, value in span.attributes.items():
            if isinstance(value, (str, bool, int, float)):
                current.set_attribute(str(key), value)
        if span.status != "ok":
            current.set_status(Status(StatusCode.ERROR, span.status))
        current.set_attribute("jarvis.version", "12.8.0")
        current.set_attribute("jarvis.span_digest", span.span_digest)
        current.end(end_time=int(span.finished_at * 1_000_000_000))
        return True



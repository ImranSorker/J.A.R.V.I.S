"""Operator-grade exact computation and machine-verifiable proof utilities."""
from __future__ import annotations

import ast
import hashlib
from dataclasses import dataclass
from fractions import Fraction
from typing import Callable

import sympy as sp


@dataclass(frozen=True, slots=True)
class ProofCertificate:
    result: str
    certificate: str
    input_digest: str
    algorithm: str
    precision: str
    error_bound: str
    verification: bool

    def as_dict(self) -> dict[str, object]:
        """Return a JSON-safe machine-verifiable certificate."""
        return {
            "result": self.result,
            "certificate": self.certificate,
            "input_digest": self.input_digest,
            "algorithm": self.algorithm,
            "precision": self.precision,
            "error_bound": self.error_bound,
            "verification": self.verification,
        }


_ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)


def _parse(expression: str) -> ast.Expression:
    tree = ast.parse(expression, mode="eval")
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) or isinstance(node, ast.Call) or isinstance(node, ast.Attribute):
            raise ValueError("proof expressions may contain arithmetic literals and operators only")
        if isinstance(node, ast.BinOp) and not isinstance(node.op, _ALLOWED_BINOPS):
            raise ValueError(f"unsupported operator: {type(node.op).__name__}")
        if isinstance(node, ast.UnaryOp) and not isinstance(node.op, (ast.UAdd, ast.USub)):
            raise ValueError("unsupported unary operator")
        if isinstance(node, ast.Constant) and not isinstance(node.value, (int, float)):
            raise ValueError("proof constants must be numeric")
    return tree


def exact_fraction(expression: str) -> str:
    """Evaluate restricted arithmetic using Python's exact Fraction arithmetic."""
    tree = _parse(expression)

    def evaluate(node: ast.AST) -> Fraction:
        if isinstance(node, ast.Expression):
            return evaluate(node.body)
        if isinstance(node, ast.Constant):
            return Fraction(str(node.value)) if isinstance(node.value, float) else Fraction(node.value)
        if isinstance(node, ast.UnaryOp):
            value = evaluate(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp):
            left, right = evaluate(node.left), evaluate(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            if isinstance(node.op, ast.Div): return left / right
            if isinstance(node.op, ast.FloorDiv): return Fraction(left // right)
            if isinstance(node.op, ast.Mod): return left % right
            if isinstance(node.op, ast.Pow):
                if right.denominator != 1 or abs(right.numerator) > 100_000:
                    raise ValueError("exponent must be an integer within the proof bound")
                return left ** right.numerator
        raise ValueError(f"unsupported expression node: {type(node).__name__}")

    return str(evaluate(tree))


def exact_sympy(expression: str) -> str:
    """Independently evaluate the same restricted arithmetic through SymPy's exact domain."""
    tree = _parse(expression)

    def evaluate(node: ast.AST) -> sp.Expr:
        if isinstance(node, ast.Expression):
            return evaluate(node.body)
        if isinstance(node, ast.Constant):
            return sp.Rational(str(node.value)) if isinstance(node.value, float) else sp.Integer(node.value)
        if isinstance(node, ast.UnaryOp):
            value = evaluate(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp):
            left, right = evaluate(node.left), evaluate(node.right)
            if isinstance(node.op, ast.Add): return sp.Add(left, right)
            if isinstance(node.op, ast.Sub): return sp.Add(left, -right)
            if isinstance(node.op, ast.Mult): return sp.Mul(left, right)
            if isinstance(node.op, ast.Div): return sp.cancel(left / right)
            if isinstance(node.op, ast.FloorDiv): return sp.floor(left / right)
            if isinstance(node.op, ast.Mod): return sp.Mod(left, right)
            if isinstance(node.op, ast.Pow): return sp.Pow(left, right)
        raise ValueError(f"unsupported expression node: {type(node).__name__}")

    return str(sp.simplify(evaluate(tree)))


class ExactProofEngine:
    """Compute a result and independently verify it with a second implementation."""

    def prove(self, expression: str, primary: Callable[[str], str], independent: Callable[[str], str], *, precision: str = "exact") -> ProofCertificate:
        result = str(primary(expression))
        check = str(independent(expression))
        ok = result == check
        cert_material = f"{expression}|{result}|{check}|{precision}".encode("utf-8")
        cert = hashlib.sha256(cert_material).hexdigest()
        return ProofCertificate(
            result=result,
            certificate=cert,
            input_digest=hashlib.sha256(expression.encode("utf-8")).hexdigest(),
            algorithm=f"{getattr(primary, '__name__', 'primary')}+{getattr(independent, '__name__', 'independent')}",
            precision=precision,
            error_bound="0" if ok else "verification_mismatch",
            verification=ok,
        )



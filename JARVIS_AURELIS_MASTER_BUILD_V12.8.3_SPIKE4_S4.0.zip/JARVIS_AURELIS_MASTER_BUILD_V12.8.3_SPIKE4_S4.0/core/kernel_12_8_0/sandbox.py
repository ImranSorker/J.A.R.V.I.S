"""Fail-closed subprocess sandbox for generated Python execution in J.A.R.V.I.S. 12.8.3."""
from __future__ import annotations

import ast
import builtins
import importlib
from functools import lru_cache
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .process import run_fixed, spawn_fixed


class SandboxRejected(PermissionError):
    """Raised when a program is outside the sandbox safety contract."""


@dataclass(frozen=True, slots=True)
class SandboxPolicy:
    timeout_seconds: float = 5.0
    memory_mb: int = 256
    cpu_seconds: int = 2
    output_bytes: int = 1_048_576
    allow_network: bool = False


@dataclass(frozen=True, slots=True)
class SandboxResult:
    return_code: int
    stdout: str
    stderr: str
    timed_out: bool
    blocked: bool
    reason: str | None


class SecurePythonSandbox:
    """Execute a restricted Python subset inside a disposable worker process."""

    def __init__(self, policy: SandboxPolicy | None = None) -> None:
        self.policy = policy or SandboxPolicy()

    ALLOWED_IMPORTS = frozenset({
        "math", "statistics", "decimal", "fractions", "json", "re",
        "collections", "itertools", "functools", "typing",
    })
    BLOCKED_IMPORTS = frozenset({
        "subprocess", "socket", "ctypes", "cffi", "multiprocessing", "asyncio",
        "os", "pathlib", "shutil", "tempfile", "sys", "resource", "signal",
        "importlib", "builtins",
    })

    @staticmethod
    def resource_limits_available() -> bool:
        """Return whether POSIX resource limits can be requested by the worker."""
        return os.name == "posix"

    @staticmethod
    @lru_cache(maxsize=1)
    def network_isolation_available() -> bool:
        """Return whether a network-isolation wrapper is installed and usable."""
        if sys.platform.startswith("linux"):
            bwrap = shutil.which("bwrap")
            if bwrap:
                try:
                    probe = subprocess.run(
                        [bwrap, "--unshare-net", "--ro-bind", "/", "/", "--", "true"],
                        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        check=False, timeout=2.0,
                    )
                except (OSError, subprocess.SubprocessError):
                    probe = None
                if probe is not None and probe.returncode == 0:
                    return True
            unshare = shutil.which("unshare")
            if unshare:
                try:
                    probe = subprocess.run(
                        [unshare, "-n", "--", sys.executable, "-c", "pass"],
                        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        check=False, timeout=2.0,
                    )
                    return probe.returncode == 0
                except (OSError, subprocess.SubprocessError):
                    return False
        return False

    @classmethod
    def _validate_source(cls, source: str) -> None:
        if len(source.encode("utf-8")) > 1_000_000:
            raise SandboxRejected("source exceeds sandbox input budget")
        tree = ast.parse(source, mode="exec")
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
                for name in names:
                    root = name.split(".", 1)[0]
                    if root in cls.BLOCKED_IMPORTS or root not in cls.ALLOWED_IMPORTS:
                        raise SandboxRejected(f"blocked or non-allow-listed import: {name}")
            elif isinstance(node, ast.ImportFrom):
                root = (node.module or "").split(".", 1)[0]
                if root in cls.BLOCKED_IMPORTS or root not in cls.ALLOWED_IMPORTS:
                    raise SandboxRejected(f"blocked or non-allow-listed import: {node.module}")
            elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
                raise SandboxRejected(f"dunder attribute access is blocked: {node.attr}")
            elif isinstance(node, ast.Name) and node.id.startswith("__") and node.id != "__name__":
                raise SandboxRejected(f"dunder name access is blocked: {node.id}")

    def _preflight(self) -> None:
        if os.name != "posix":
            raise SandboxRejected("secure Python sandbox is supported only on POSIX platforms")
        if self.policy.timeout_seconds <= 0 or self.policy.cpu_seconds <= 0:
            raise ValueError("sandbox time limits must be positive")
        if self.policy.memory_mb < 64:
            raise ValueError("sandbox memory limit must be at least 64 MiB")
        if self.policy.output_bytes < 1024:
            raise ValueError("sandbox output limit must be at least 1024 bytes")
        if not self.policy.allow_network and not self.network_isolation_available():
            raise SandboxRejected("network-disabled execution requires a supported OS isolation wrapper")

    def _apply_network_policy(self, command: list[str], root: Path) -> list[str]:
        """Apply an unambiguous network policy: false means deny, true means allow."""
        if self.policy.allow_network:
            return command
        if shutil.which("bwrap"):
            return [
                "bwrap", "--unshare-net", "--ro-bind", "/", "/", "--bind", str(root), str(root),
                "--chdir", str(root), "--", *command,
            ]
        unshare = shutil.which("unshare")
        if unshare:
            return [unshare, "-n", "--", *command]
        raise SandboxRejected("network-disabled execution requires bwrap or unshare")

    def execute(self, source: str, *, filename: str = "generated.py", argv: Sequence[str] = ()) -> SandboxResult:
        """Run source with bounded time, memory, output and imports."""
        self._preflight()
        source_text = str(source)
        self._validate_source(source_text)
        root = Path(tempfile.mkdtemp(prefix="jarvis-12.8.0-sandbox-"))
        try:
            script = root / Path(filename).name
            script.write_text(source_text, encoding="utf-8")
            worker = root / "__jarvis_worker.py"
            worker_source = textwrap.dedent(
                f"""
                import builtins
                import importlib
from functools import lru_cache
                import resource
                import sys

                ALLOWED = {sorted(self.ALLOWED_IMPORTS)!r}
                SAFE_BUILTINS = {{
                    name: getattr(builtins, name) for name in {sorted({
                        "abs", "all", "any", "bool", "bytes", "callable", "chr", "dict", "divmod",
                        "enumerate", "filter", "float", "format", "frozenset", "hash", "int", "isinstance",
                        "issubclass", "iter", "len", "list", "map", "max", "min", "next", "object", "ord",
                        "pow", "print", "range", "repr", "reversed", "round", "set", "slice", "sorted", "str",
                        "sum", "tuple", "type", "zip", "Exception", "BaseException", "ArithmeticError",
                        "AssertionError", "AttributeError", "EOFError", "IndexError", "KeyError", "LookupError",
                        "MemoryError", "NameError", "OverflowError", "RuntimeError", "StopIteration", "TypeError",
                        "ValueError", "ZeroDivisionError",
                    })!r} if hasattr(builtins, name)
                }}

                def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
                    root_name = str(name).split('.', 1)[0]
                    if level != 0 or root_name not in ALLOWED:
                        raise ImportError(f"blocked import: {{name}}")
                    module = importlib.import_module(name)
                    if fromlist:
                        return module
                    return importlib.import_module(root_name)

                SAFE_BUILTINS["__import__"] = safe_import
                SAFE_BUILTINS["__build_class__"] = builtins.__build_class__
                SAFE_BUILTINS["__name__"] = "__main__"
                SAFE_BUILTINS["__package__"] = None
                SAFE_BUILTINS["__loader__"] = None
                SAFE_BUILTINS["__spec__"] = None

                resource.setrlimit(resource.RLIMIT_CPU, ({int(self.policy.cpu_seconds)}, {int(self.policy.cpu_seconds)}))
                resource.setrlimit(resource.RLIMIT_AS, ({int(self.policy.memory_mb) * 1024 * 1024}, {int(self.policy.memory_mb) * 1024 * 1024}))
                resource.setrlimit(resource.RLIMIT_FSIZE, ({int(self.policy.output_bytes)}, {int(self.policy.output_bytes)}))
                resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
                globals_dict = {{"__builtins__": SAFE_BUILTINS, "__name__": "__main__", "__file__": {str(script)!r}}}
                with open({str(script)!r}, "r", encoding="utf-8") as source_file:
                    code = compile(source_file.read(), {str(script)!r}, "exec", dont_inherit=True)
                exec(code, globals_dict, globals_dict)
                """
            ).strip() + "\n"
            worker.write_text(worker_source, encoding="utf-8")
            env = {
                "PATH": os.environ.get("PATH", ""),
                "PYTHONNOUSERSITE": "1",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONHASHSEED": "0",
                "PYTHONUTF8": "1",
            }
            command = [sys.executable, "-I", "-S", str(worker), *[str(x) for x in argv]]
            command = self._apply_network_policy(command, root)
            stdout_path = root / "stdout.log"
            stderr_path = root / "stderr.log"
            try:
                with stdout_path.open("wb") as stdout_handle, stderr_path.open("wb") as stderr_handle:
                    creationflags = 0
                    if os.name == "nt":
                        creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                    proc = spawn_fixed(
                        command, allowed_executables=(Path(sys.executable).name, "bwrap", "unshare"), cwd=root, env=env,
                        stdin=subprocess.DEVNULL, stdout=stdout_handle, stderr=stderr_handle,
                        start_new_session=os.name == "posix", creationflags=creationflags,
                    )
                    try:
                        return_code = proc.wait(timeout=float(self.policy.timeout_seconds))
                        timed_out = False
                    except subprocess.TimeoutExpired:
                        timed_out = True
                        if os.name == "posix":
                            try:
                                os.killpg(proc.pid, signal.SIGKILL)
                            except ProcessLookupError:
                                return_code = -9
                        else:
                            proc.kill()
                            taskkill = shutil.which("taskkill")
                            if taskkill:
                                run_fixed([taskkill, "/PID", str(proc.pid), "/T", "/F"], allowed_executables=(Path(taskkill).name,), timeout=5.0)
                        return_code = proc.wait(timeout=5.0)
                    stdout_handle.flush(); stderr_handle.flush()
                stdout = stdout_path.read_bytes()[: self.policy.output_bytes].decode("utf-8", errors="replace")
                stderr = stderr_path.read_bytes()[: self.policy.output_bytes].decode("utf-8", errors="replace")
                if timed_out:
                    return SandboxResult(-1, stdout, stderr, True, False, "timeout")
                return SandboxResult(return_code, stdout, stderr, False, False, None)
            except (OSError, subprocess.SubprocessError) as exc:
                return SandboxResult(-1, "", "", False, True, f"sandbox spawn failed: {exc}")
        finally:
            shutil.rmtree(root, ignore_errors=True)



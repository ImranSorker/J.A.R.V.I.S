"""Operator-facing certification gates for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from .contracts import EventEnvelope, EvidenceClass
from .process import run_fixed
from .canonical import canonical_json, digest
from .event_store import EventStore
from .evidence import EvidenceEnvelope, EvidenceLedger
from .identity import AgentIdentityAuthority
from .memory import MemoryFabric
from .mission import MissionWAL, UndoExecutor
from .protocols import A2AControlPlane, AgentCard, MCPControlPlane, MCPToolManifest, sign_mcp_manifest
from .regression import RegressionCase, RegressionCorpus
from .sandbox import SandboxPolicy, SecurePythonSandbox
from .supply_chain import SecretScanner, generate_ml_bom, generate_sbom
from .wasi import WASIComponentRuntime
from core.frontier_batch import FrontierBatchFabric, MissionNodeV2, MissionPlanV2


@dataclass(frozen=True, slots=True)
class GateResult:
    gate: str
    status: str
    detail: str

    def as_dict(self) -> dict[str, str]:
        return {"gate": self.gate, "status": self.status, "detail": self.detail}


class CertificationCenter:
    """Run deterministic source/runtime gates without converting environment gaps into false passes."""

    _PROFILES: dict[str, set[str] | None] = {
        "static": {"canonical", "syntax", "dependency_graph", "black", "ruff", "mypy", "bandit", "pip_audit", "secret_scan"},
        "protocol": {"mcp", "a2a", "identity_persistence"},
        "security": {"secret_scan", "sandbox_limits", "sandbox_escape", "sandbox_network", "memory_isolation", "identity_persistence"},
        "runtime": {"canonical", "event_chain", "evidence_chain", "dependency_graph", "runtime_smoke", "mission_recovery", "memory_isolation"},
        "hardware": {"hardware"},
        "flutter": {"flutter"},
        "inference": {"inference"},
        "sandbox": {"sandbox_limits", "sandbox_escape", "sandbox_network"},
        "wasi": {"wasi_runtime"},
        "federation": {"a2a", "identity_persistence"},
        "supply-chain": {"secret_scan", "sbom", "ml_bom", "provenance"},
        "evaluation": {"replay", "trajectory", "regression", "loop_detector"},
        "observability": {"otel"},
        "frontier": {"frontier_batch"},
        "release": {"release_reproducibility", "release_metadata"},
        "full": None,
    }

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()

    @staticmethod
    def _run(command: Sequence[str], *, cwd: Path, timeout: float = 120.0, env: Mapping[str, str] | None = None) -> subprocess.CompletedProcess[str]:
        merged_env = None if env is None else {str(k): str(v) for k, v in env.items()}
        return run_fixed(command, allowed_executables=(Path(str(command[0])).name,), cwd=cwd, timeout=timeout, env=merged_env)

    def _tool(self, gate: str, binary: str, args: Sequence[str], *, timeout: float = 120.0) -> GateResult:
        if shutil.which(binary) is None:
            return GateResult(gate, "NOT_INSTALLED", f"{binary} is unavailable")
        try:
            proc = self._run([binary, *args], cwd=self.root, timeout=timeout)
        except (OSError, subprocess.SubprocessError) as exc:
            return GateResult(gate, "FAIL", f"{type(exc).__name__}: {exc}")
        detail_lines = (proc.stdout or proc.stderr or "").strip().splitlines()
        detail = detail_lines[-1] if detail_lines else f"exit={proc.returncode}"
        return GateResult(gate, "PASS" if proc.returncode == 0 else "FAIL", detail[:500])

    def _python_module(self, gate: str, module: str, args: Sequence[str], *, timeout: float = 120.0, disable_plugins: bool = False) -> GateResult:
        env = dict(os.environ)
        if disable_plugins:
            env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
        try:
            proc = self._run([sys.executable, "-m", module, *args], cwd=self.root, timeout=timeout, env=env)
        except (OSError, subprocess.SubprocessError) as exc:
            return GateResult(gate, "FAIL", f"{type(exc).__name__}: {exc}")
        detail_lines = (proc.stdout or proc.stderr or "").strip().splitlines()
        detail = detail_lines[-1] if detail_lines else f"exit={proc.returncode}"
        return GateResult(gate, "PASS" if proc.returncode == 0 else "FAIL", detail[:500])

    def _gate_canonical(self) -> GateResult:
        try:
            first = canonical_json({"b": 2, "a": 1})
            if first != b'{"a":1,"b":2}' or digest({"a": 1}) == digest({"a": 2}):
                return GateResult("canonical", "FAIL", "canonical encoding/digest invariant failed")
            return GateResult("canonical", "PASS", "deterministic canonical digest verified")
        except Exception as exc:
            return GateResult("canonical", "FAIL", f"{type(exc).__name__}: {exc}")

    def _gate_event_store(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            store = EventStore(Path(td) / "events.db")
            try:
                store.append(EventEnvelope("certification.smoke", {"ok": True}))
                return GateResult("event_chain", "PASS" if store.verify() else "FAIL", "durable event hash chain verified")
            finally:
                store.close()

    def _gate_evidence(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            ledger = EvidenceLedger(Path(td) / "evidence.db")
            try:
                envelope = EvidenceEnvelope.create(actor_id="cert", agent_id="jarvis", operation="observe", source="certification", evidence_class=EvidenceClass.OBSERVED, output_value={"ok": True})
                ledger.append(envelope)
                return GateResult("evidence_chain", "PASS" if ledger.verify() else "FAIL", "durable evidence hash chain verified")
            finally:
                ledger.close()

    def _gate_identity(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            state = Path(td) / "identity.json"
            secret = hashlib.sha256(b"certification-secret").digest()
            first = AgentIdentityAuthority(state_path=state, secret=secret)
            identity = first.issue(audience="worker", capabilities=("tools.read",))
            first.rotate(retire_previous=False)
            first = None
            second = AgentIdentityAuthority(state_path=state, secret=secret)
            ok = second.verify(identity, audience="worker")
            new_identity = second.issue(audience="worker", capabilities=("tools.read",))
            return GateResult("identity_persistence", "PASS" if ok and second.verify(new_identity, audience="worker") else "FAIL", "encrypted identity state, reload and trust-set verification passed")

    def _gate_memory(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            memory = MemoryFabric(b"x" * 32, Path(td) / "memory.db")
            record = memory.put(content="secret", memory_type="session", owner="u1", workspace="w1", session_id="s1", source="cert", privacy_domain="private")
            try:
                if memory.get(record.memory_id, owner="u2", workspace="w1", privacy_domain="private") is not None:
                    return GateResult("memory_isolation", "FAIL", "cross-owner memory read succeeded")
                loaded = memory.get(record.memory_id, owner="u1", workspace="w1", privacy_domain="private")
                deleted = memory.delete(record.memory_id, owner="u1", workspace="w1", privacy_domain="private")
                return GateResult("memory_isolation", "PASS" if loaded and loaded[1] == "secret" and deleted else "FAIL", "owner/workspace/privacy isolation, integrity read and authorized deletion verified")
            finally:
                memory.close()

    def _gate_sandbox_escape(self) -> GateResult:
        sandbox = SecurePythonSandbox(SandboxPolicy(allow_network=False))
        try:
            sandbox.execute("print((()).__class__)")
        except PermissionError:
            return GateResult("sandbox_escape", "PASS", "dunder object-model escape rejected")
        except Exception as exc:
            return GateResult("sandbox_escape", "FAIL", f"unexpected validation error: {type(exc).__name__}: {exc}")
        return GateResult("sandbox_escape", "FAIL", "sandbox accepted a blocked escape primitive")

    def _gate_sandbox_network(self) -> GateResult:
        if shutil.which("bwrap") is None and shutil.which("unshare") is None:
            return GateResult("sandbox_network", "BLOCKED", "no Linux network namespace wrapper installed")
        command = ["bwrap", "--unshare-net", "--ro-bind", "/", "/", "true"] if shutil.which("bwrap") else ["unshare", "-n", "--", "true"]
        try:
            proc = run_fixed(command, allowed_executables=(Path(command[0]).name,), timeout=5)
        except OSError as exc:
            return GateResult("sandbox_network", "FAIL", str(exc))
        return GateResult("sandbox_network", "PASS", "network namespace creation succeeded") if proc.returncode == 0 else GateResult("sandbox_network", "BLOCKED", (proc.stderr or "namespace creation failed").strip()[:500])

    def _gate_runtime_smoke(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            root = Path(td)
            code = """
from core.kernel_12_8_0 import JarvisKernelRuntime
config = {'kernel': {'event_db': 'events.db', 'evidence_db': 'evidence.db', 'mission_db': 'missions.db', 'memory_db': 'memory.db', 'experiment_db': 'experiments.db', 'promotion_db': 'promotions.db', 'capabilities': {'allow': ['tools.read']}}}
kernel = JarvisKernelRuntime(config)
kernel.start()
kernel.publish('certification.runtime', {'ok': True})
assert kernel.health()['event_chain_verified']
assert kernel.health()['evidence_verified']
kernel.close()
print('runtime_smoke=PASS')
""".strip()
            env = dict(os.environ); env["PYTHONPATH"] = str(self.root)
            try:
                proc = run_fixed([sys.executable, "-c", code], allowed_executables=(Path(sys.executable).name,), cwd=root, env=env, timeout=30)
            except subprocess.SubprocessError as exc:
                return GateResult("runtime_smoke", "FAIL", f"{type(exc).__name__}: {exc}")
            return GateResult("runtime_smoke", "PASS" if proc.returncode == 0 else "FAIL", (proc.stdout or proc.stderr).strip()[-500:])

    def _gate_mission_recovery(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            db = Path(td) / "missions.db"
            wal = MissionWAL(db); undo = UndoExecutor(db_path=db)
            try:
                wal.upsert("m1", "started", {"goal": "recover"}); wal.record_step("m1", "s1", "completed", {"ok": True})
                state = wal.restore("m1")
                record = undo.register("mutation", before_state={"x": 1}, inverse_operation="restore", inverse_arguments={"x": 1}, recovery_class=__import__("core.kernel_12_8_0").kernel_12_8_0.contracts.RecoveryClass.REVERSIBLE)
                record = undo.finalize(record.action_id, {"x": 2})
                restored = undo.execute(record.action_id, current_state={"x": 2}, inverse=lambda args: dict(args), authorized=True)
                ok = state is not None and wal.resume_point("m1") == "s1" and restored == {"x": 1}
                return GateResult("mission_recovery", "PASS" if ok else "FAIL", "mission WAL resume point and guarded undo recovery verified")
            finally:
                undo.close(); wal.close()

    def _gate_mcp(self) -> GateResult:
        authority = AgentIdentityAuthority()
        mcp = MCPControlPlane(authority=authority)
        try:
            manifest = MCPToolManifest(server_id="cert", publisher="jarvis", version="12.8.0", tool_id="echo", schema={"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"], "additionalProperties": False}, side_effect_level="read", required_capabilities=("tools.read",), network_hosts=(), filesystem_scope=(), data_classification="public", auth_method="ed25519", signature="", provenance="local", task_capable=True)
            mcp.register(sign_mcp_manifest(manifest, authority), lambda args: {"x": args["x"]})
            mcp.register_resource("jarvis://cert", lambda: {"contents": [{"text": "ok"}]})
            mcp.register_prompt("cert", {"arguments": []})
            result = mcp.dispatch("tools/call", {"name": "echo", "arguments": {"x": 1}})
            task = mcp.dispatch("tools/call", {"name": "echo", "arguments": {"x": 2}, "_meta": {"io.modelcontextprotocol/clientCapabilities": {"extensions": {"io.modelcontextprotocol/tasks": {}}}}})
            task_id = str(task["task"]["taskId"])
            for _ in range(50):
                state = mcp.dispatch("tasks/get", {"taskId": task_id})
                if state.get("status") != "working":
                    break
                time.sleep(0.005)
            discovery = mcp.dispatch("server/discover")
            ok = result.get("x") == 1 and state.get("status") == "completed" and state.get("result", {}).get("x") == 2 and discovery.get("protocol") == "2026-07-28" and mcp.dispatch("resources/read", {"uri": "jarvis://cert"})["contents"][0]["text"] == "ok"
            return GateResult("mcp", "PASS" if ok else "FAIL", "MCP 2026-07-28 stateless discovery, schema validation, cache metadata and negotiated Tasks verified")
        finally:
            mcp.close()

    def _gate_a2a(self) -> GateResult:
        authority = AgentIdentityAuthority(); a2a = A2AControlPlane(authority)
        card = AgentCard("JARVIS", "12.8.0 agent", "https://localhost/a2a", "12.8.0", ("tools.read",), {"ed25519": {"type": "apiKey"}}, authority.issuer, authority.key_id, "")
        signed = a2a.publish_agent_card(card)
        task = a2a.sign_task(authority.issue(audience=authority.issuer, capabilities=("tools.read",)), audience="worker", payload={"ok": True})
        jws = signed.jws_signature(authority)
        document = signed.to_a2a_document()
        ok = signed.verify(authority) and a2a.verify_task(task, audience="worker") and not a2a.verify_task(task, audience="worker") and document["supportedInterfaces"][0]["protocolVersion"] == "1.0" and {"protected", "signature"}.issubset(jws)
        return GateResult("a2a", "PASS" if ok else "FAIL", "A2A 1.0 AgentCard, signed discovery and replay-protected task verification passed")

    def _gate_replay(self) -> GateResult:
        from .evaluation import DeterministicMissionReplay
        recorded = {"result": {"ok": True}, "policy": {"id": "p1"}, "toolchain": {"tool": "t1"}}
        diff = DeterministicMissionReplay().replay(recorded, lambda value: dict(value))
        return GateResult("replay", "PASS" if diff.same_result and diff.same_policy and diff.same_toolchain and not diff.drift else "FAIL", "deterministic mission replay comparison verified")

    def _gate_trajectory(self) -> GateResult:
        from .evaluation import TrajectoryGrader
        grade = TrajectoryGrader().grade([{"stage": "planned"}, {"stage": "completed", "result_ok": True, "evidence_id": "e1"}])
        ok = grade.task_completion and grade.plan_adherence and grade.verification
        return GateResult("trajectory", "PASS" if ok else "FAIL", "trajectory dimensions computed independently")

    def _gate_loop(self) -> GateResult:
        from .evaluation import MissionLoopDetector
        rows = [{"tool": "x", "arguments": {"a": 1}, "observation": {"same": True}, "progress": False} for _ in range(3)]
        findings = MissionLoopDetector().detect(rows)
        return GateResult("loop_detector", "PASS" if any(item.kind == "repeated-tool-call" for item in findings) else "FAIL", "state, repeated-call and no-progress loop detection verified")

    def _gate_regression(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-cert-") as td:
            corpus = RegressionCorpus(Path(td) / "regression.jsonl")
            case = RegressionCase.create(goal="certify", context={}, expected_behavior={"ok": True}, allowed_tools=["tools.read"])
            corpus.add(case)
            result = corpus.run(lambda item: (item.goal == "certify", "ok"))[0]
            return GateResult("regression", "PASS" if result["passed"] else "FAIL", "personal regression corpus round-trip and execution verified")

    def _gate_frontier_batch(self) -> GateResult:
        with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-frontier-cert-") as td:
            fabric = FrontierBatchFabric(Path(td), b"f" * 32)
            try:
                fabric.missions.create(
                    MissionPlanV2(
                        mission_id="cert",
                        objective="frontier certification",
                        nodes=(MissionNodeV2("read", "tools.read", {"ok": True}, max_attempts=1),),
                        max_duration_seconds=15,
                    )
                )
                result = fabric.missions.execute(
                    "cert",
                    authorize=lambda node: node.capability == "tools.read",
                    runner=lambda node: node.payload,
                )
                receipt_row = fabric.missions.status("cert")["receipts"][0]
                from core.frontier_batch import ExecutionReceipt
                receipt = ExecutionReceipt(mission_id="cert", **receipt_row)
                memory = fabric.memory.append("cert:u", "checkpoint", {"mission": result["mission_id"]})
                memory_ok = fabric.memory.verify("cert:u") == []
                uav = fabric.uav
                uav.arm()
                uav.takeoff(10)
                uav.return_to_home()
                cuda_available = fabric.cuda.snapshot().get("available") in {True, False}
                ok = (
                    result["state"] == "succeeded"
                    and fabric.missions.verify_receipt(receipt)
                    and memory.sequence == 1
                    and memory_ok
                    and cuda_available
                    and uav.state()["mode"] == "armed"
                )
                return GateResult("frontier_batch", "PASS" if ok else "FAIL", "durable mission, signed receipt, integrity journal, UAV safety state machine and factual CUDA capability probe verified")
            except Exception as exc:
                return GateResult("frontier_batch", "FAIL", f"{type(exc).__name__}: {exc}")
            finally:
                fabric.close()

    def _gate_inference(self) -> GateResult:
        binaries = [name for name in ("llama-server", "llama-bench", "vllm") if shutil.which(name)]
        if binaries:
            return GateResult("inference", "PASS", f"inference runtime present: {','.join(binaries)}")
        try:
            import importlib.util
            if importlib.util.find_spec("vllm") or importlib.util.find_spec("llama_cpp"):
                return GateResult("inference", "PASS", "Python inference runtime present")
        except (ImportError, ModuleNotFoundError):
            return GateResult("inference", "NOT_INSTALLED", "no supported local inference runtime is installed")
        return GateResult("inference", "NOT_INSTALLED", "no supported local inference runtime is installed")

    def _gate_wasi(self) -> GateResult:
        if not WASIComponentRuntime.runtime_available():
            return GateResult("wasi_runtime", "NOT_INSTALLED", "Wasmtime is unavailable; WASI component execution cannot be certified here")
        proc = run_fixed(["wasmtime", "--version"], allowed_executables=("wasmtime",), timeout=5)
        return GateResult("wasi_runtime", "PASS" if proc.returncode == 0 else "FAIL", (proc.stdout or proc.stderr).strip()[:500])

    def _gate_hardware(self) -> GateResult:
        try:
            import psutil
            return GateResult("hardware", "PASS", f"cpu_count={psutil.cpu_count(logical=True)};ram_bytes={psutil.virtual_memory().total};nvidia_smi={bool(shutil.which('nvidia-smi'))}")
        except ImportError:
            return GateResult("hardware", "NOT_INSTALLED", "psutil unavailable")

    def _gate_otel(self) -> GateResult:
        try:
            from .observability import OpenTelemetryBridge, TraceLedger
            ledger = TraceLedger(); span = ledger.start("certification") ; span.finish(attributes={"jarvis.version": "12.8.0"})
            available = OpenTelemetryBridge().available
            return GateResult("otel", "PASS" if available and OpenTelemetryBridge().export(span) else "NOT_INSTALLED", "OpenTelemetry SDK span emission verified" if available else "OpenTelemetry SDK unavailable")
        except Exception as exc:
            return GateResult("otel", "FAIL", f"{type(exc).__name__}: {exc}")

    def _gate_release_reproducibility(self) -> GateResult:
        try:
            from scripts.build_release import build
            with tempfile.TemporaryDirectory(prefix="jarvis-12.8.0-repro-") as td:
                a = build(Path(td) / "a.zip"); b = build(Path(td) / "b.zip")
                digest_a = hashlib.sha256(a.read_bytes()).hexdigest(); digest_b = hashlib.sha256(b.read_bytes()).hexdigest()
                return GateResult("release_reproducibility", "PASS" if digest_a == digest_b else "FAIL", f"sha256={digest_a}")
        except Exception as exc:
            return GateResult("release_reproducibility", "FAIL", f"{type(exc).__name__}: {exc}")

    def _gate_release_metadata(self) -> GateResult:
        path = self.root / "release_metadata.json"
        if not path.exists():
            return GateResult("release_metadata", "BLOCKED", "release_metadata.json is generated only during a release build")
        try:
            import json
            meta = json.loads(path.read_text(encoding="utf-8"))
            required = {"public_version": "12.8.3", "kernel_id": "kernel-12.8.0", "schema_generation": 1}
            ok = all(meta.get(k) == v for k, v in required.items()) and bool(meta.get("build_id"))
            return GateResult("release_metadata", "PASS" if ok else "FAIL", "generated release metadata fields verified")
        except Exception as exc:
            return GateResult("release_metadata", "FAIL", f"{type(exc).__name__}: {exc}")

    def _gate_secret_scan(self) -> GateResult:
        """Audit the workspace for high-confidence embedded secrets."""
        findings = SecretScanner().scan_path(self.root)
        return GateResult("secret_scan", "FAIL" if findings else "PASS", f"{len(findings)} high-confidence findings")

    def run(self, profile: str = "full") -> list[GateResult]:
        """Run only the gates selected by a named certification profile."""
        normalized = str(profile).strip().lower()
        if normalized not in self._PROFILES:
            raise ValueError(f"unknown certification profile: {profile}")
        wanted = self._PROFILES[normalized]
        gates: list[GateResult] = []

        def selected(gate: str) -> bool:
            return wanted is None or gate in wanted

        runners: dict[str, object] = {
            "canonical": self._gate_canonical,
            "event_chain": self._gate_event_store,
            "evidence_chain": self._gate_evidence,
            "syntax": lambda: self._python_module("syntax", "compileall", ["-q", "."], timeout=120.0),
            "dependency_graph": lambda: self._python_module("dependency_graph", "scripts.dependency_graph", ["--output", "data/dependency_graph.json"], timeout=120.0),
            "black": lambda: self._tool("black", "black", ["--check", "core", "api", "agents", "services", "security", "tools"], timeout=120.0),
            "ruff": lambda: self._tool("ruff", "ruff", ["check", "core", "api", "agents", "services", "security", "tools"], timeout=120.0),
            "mypy": lambda: self._tool("mypy", "mypy", ["--strict", "core/kernel_12_8_0"], timeout=120.0),
            "bandit": lambda: self._tool("bandit", "bandit", ["-q", "-r", "core/kernel_12_8_0"], timeout=120.0),
            "pip_audit": lambda: self._tool("pip_audit", "pip-audit", ["-r", "requirements.txt"], timeout=180.0),
            "secret_scan": self._gate_secret_scan,
            "sandbox_limits": lambda: GateResult("sandbox_limits", "PASS" if SecurePythonSandbox.resource_limits_available() else "BLOCKED", "POSIX RLIMIT backend available" if SecurePythonSandbox.resource_limits_available() else "resource limit backend unavailable"),
            "sandbox_escape": self._gate_sandbox_escape,
            "sandbox_network": self._gate_sandbox_network,
            "runtime_smoke": self._gate_runtime_smoke,
            "identity_persistence": self._gate_identity,
            "memory_isolation": self._gate_memory,
            "mission_recovery": self._gate_mission_recovery,
            "mcp": self._gate_mcp,
            "a2a": self._gate_a2a,
            "replay": self._gate_replay,
            "trajectory": self._gate_trajectory,
            "loop_detector": self._gate_loop,
            "regression": self._gate_regression,
            "frontier_batch": self._gate_frontier_batch,
            "inference": self._gate_inference,
            "wasi_runtime": self._gate_wasi,
            "hardware": self._gate_hardware,
            "flutter": lambda: self._tool("flutter", "flutter", ["analyze", "--no-pub"], timeout=180.0) if shutil.which("flutter") else GateResult("flutter", "NOT_INSTALLED", "Flutter SDK unavailable in this environment"),
            "otel": self._gate_otel,
            "sbom": lambda: GateResult("sbom", "PASS", f"CycloneDX inventory contains {len(generate_sbom(self.root)['components'])} source files"),
            "ml_bom": lambda: GateResult("ml_bom", "PASS", f"ML-BOM shape available; {len(generate_ml_bom([])['components'])} model components currently registered"),
            "provenance": lambda: GateResult("provenance", "PASS", "in-toto/SLSA provenance generation path is available; external signing is environment-owned"),
            "release_metadata": self._gate_release_metadata,
            "single_process_pytest": lambda: self._python_module("single_process_pytest", "pytest", ["tests", "-q", "-W", "error", "-p", "no:ddtrace"], timeout=300.0, disable_plugins=False),
            "release_reproducibility": self._gate_release_reproducibility,
        }
        for gate, runner in runners.items():
            if not selected(gate):
                continue
            result = runner()  # type: ignore[operator]
            if not isinstance(result, GateResult):
                raise TypeError(f"certification runner {gate} returned {type(result).__name__}")
            gates.append(result)
        return gates


"""J.A.R.V.I.S. 12.8.0 canonical kernel package."""
from .ids import Clock, uuid7
from .contracts import CapabilityRequest, Command, EventEnvelope, EvidenceClass, RecoveryClass, TaskSpec, TaskState
from .event_store import EventStore
from .capability_policy import CapabilityPolicy, Decision
from .task_graph import TaskGraph, TaskGraphError
from .evidence import EvidenceEnvelope, EvidenceLedger, SignedProvenance, sign_provenance, verify_provenance
from .identity import AgentIdentity, AgentIdentityAuthority, ReplayCache
from .mission import HardCancellation, MissionState, MissionWAL, UndoExecutor, UndoRecord
from .evaluation import DeterministicMissionReplay, MissionLoopDetector, ReplayDiff, TrajectoryGrade, TrajectoryGrader
from .inference import CacheScope, EmpiricalInferenceRouter, InferenceMeasurement, ModelCapabilityCard, PrefixKVCache
from .memory import Claim, ContradictionResolver, MemoryFabric, MemoryRecord
from .supply_chain import ArtifactManifest, ArtifactVerifier, SecretFinding, SecretScanner, generate_ml_bom, generate_provenance, generate_sbom
from .resource import ResourceBudget, ResourceLedger, ResourceLease, ThermalGovernor, ThermalState
from .promotion import PromotionCandidate, PromotionEngine, PromotionStatus
from .process import run_fixed, spawn_fixed
from .protocols import A2AControlPlane, A2ATaskEnvelope, AgentCard, MCPControlPlane, MCPToolManifest, sign_mcp_manifest, A2A_VERSION, MCP_VERSION
from .sandbox import SandboxPolicy, SandboxRejected, SandboxResult, SecurePythonSandbox
from .computer_use import ComputerUseAuthority, ComputerUseDecision, ObservedContext
from .credentials import BoundCredential, ProofOfPossession, SenderConstrainedCredentialAuthority
from .federation import FederationRegistry, NodeAttestation, NodeDescriptor
from .attention import AttentionBudget, AttentionBudgetEngine
from .observability import OpenTelemetryBridge, TraceLedger, TraceSpan
from .wasi import SkillManifest, WASIComponentRuntime, WASIExecutionResult
from .digital_twin import DigitalTwinProjection, TwinEntity
from .frontier_extensions import AttenuatedCapabilities, CapabilityAttenuator, DriftAssessment, ErrorBudgetAssessment, ErrorBudgetController, PredictiveDependencyTwin, QualityDriftMonitor, ResourceHeatPoint, ResourceHeatmap, TwinNode
from core.frontier_completion import (ArtifactQuarantineManager, BackupRecord, CapturePrivacyPolicy, ClipboardIntelligence, CompletionSecurityError, EmbeddingCompatibility, EmbeddingModelRegistry, EmbeddingProfile, EmpiricalBenchmarkResult, EmpiricalBenchmarkRunner, EncryptedSnapshotStore, LANPairingAuthority, MissionNodeDecision, MissionNodePolicyGate, ModelArtifact, ModelLifecycleManager, ModelLifecycleState, PackageManifest, PairingGrant, ProactiveItem, ProactiveScheduler, StartupDependencyGraph, StartupNode, StartupPlan, VoiceActivityDetector, WorldStateProjection)
from .continual_learning import ContinualLearningManager, LearningExample, LoRAConfig
from .experiments import CounterfactualSimulator, ExperimentManifest, ExperimentStore
from .regression import RegressionCase, RegressionCorpus
from .execution import ExecutionPolicy, ExecutionRecord, KernelExecutionAuthority, bounded
from .runtime import JarvisKernelRuntime

__all__ = [name for name in globals() if not name.startswith("_")]



"""Additional bounded frontier controls for the canonical 12.8.0 kernel."""
from __future__ import annotations

import statistics
import threading
from dataclasses import asdict, dataclass
from time import time
from typing import Any, Iterable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class AttenuatedCapabilities:
    """Immutable capability intersection derived from a parent grant."""

    parent: tuple[str, ...]
    requested: tuple[str, ...]
    effective: tuple[str, ...]
    broadened: tuple[str, ...]

    @property
    def allowed(self) -> bool:
        """Return whether the request stays within the parent authority."""
        return not self.broadened


class CapabilityAttenuator:
    """Derive strictly narrower capability sets without granting new authority."""

    @staticmethod
    def attenuate(parent: Iterable[str], requested: Iterable[str]) -> AttenuatedCapabilities:
        """Return the deterministic intersection and explicitly identify widening attempts."""
        parent_set = {str(item).strip() for item in parent if str(item).strip()}
        requested_set = {str(item).strip() for item in requested if str(item).strip()}
        broadened = tuple(sorted(requested_set - parent_set))
        effective = tuple(sorted(requested_set & parent_set))
        return AttenuatedCapabilities(
            tuple(sorted(parent_set)),
            tuple(sorted(requested_set)),
            effective,
            broadened,
        )

    @staticmethod
    def require_subset(parent: Iterable[str], requested: Iterable[str]) -> tuple[str, ...]:
        """Return effective capabilities or fail closed on any attempted broadening."""
        result = CapabilityAttenuator.attenuate(parent, requested)
        if not result.allowed:
            raise PermissionError(f"capability attenuation would broaden authority: {list(result.broadened)}")
        return result.effective


@dataclass(frozen=True, slots=True)
class ResourceHeatPoint:
    """One time-bucketed resource observation."""

    timestamp: float
    cpu_percent: float
    memory_percent: float
    gpu_percent: float
    vram_percent: float
    thermal_c: float | None = None
    power_watts: float | None = None


class ResourceHeatmap:
    """Maintain bounded resource samples and deterministic heatmap aggregates."""

    def __init__(self, *, max_samples: int = 4096) -> None:
        self.max_samples = max(32, min(int(max_samples), 200_000))
        self._samples: list[ResourceHeatPoint] = []
        self._lock = threading.RLock()

    def record(
        self,
        *,
        cpu_percent: float,
        memory_percent: float,
        gpu_percent: float = 0.0,
        vram_percent: float = 0.0,
        thermal_c: float | None = None,
        power_watts: float | None = None,
        timestamp: float | None = None,
    ) -> ResourceHeatPoint:
        """Record one normalized resource observation."""
        values = (cpu_percent, memory_percent, gpu_percent, vram_percent)
        if any(float(value) < 0.0 or float(value) > 100.0 for value in values):
            raise ValueError("resource percentages must be between 0 and 100")
        if thermal_c is not None and float(thermal_c) < -100.0:
            raise ValueError("thermal_c is outside the supported range")
        if power_watts is not None and float(power_watts) < 0.0:
            raise ValueError("power_watts cannot be negative")
        point = ResourceHeatPoint(
            time() if timestamp is None else float(timestamp),
            *(float(value) for value in values),
            None if thermal_c is None else float(thermal_c),
            None if power_watts is None else float(power_watts),
        )
        with self._lock:
            self._samples.append(point)
            if len(self._samples) > self.max_samples:
                del self._samples[: len(self._samples) - self.max_samples]
        return point

    def aggregate(self, *, buckets: int = 24) -> list[dict[str, Any]]:
        """Return deterministic bucket aggregates over the retained observation history."""
        count = max(1, min(int(buckets), 256))
        with self._lock:
            rows = list(self._samples)
        if not rows:
            return []
        start = min(row.timestamp for row in rows)
        end = max(row.timestamp for row in rows)
        span = max(1.0, end - start)
        width = span / count
        grouped: list[list[ResourceHeatPoint]] = [[] for _ in range(count)]
        for row in rows:
            index = min(count - 1, int((row.timestamp - start) / width))
            grouped[index].append(row)

        def mean(items: Sequence[float]) -> float:
            return round(statistics.fmean(items), 4) if items else 0.0

        result: list[dict[str, Any]] = []
        for index, items in enumerate(grouped):
            if not items:
                continue
            result.append(
                {
                    "bucket": index,
                    "start": round(start + index * width, 6),
                    "end": round(start + (index + 1) * width, 6),
                    "samples": len(items),
                    "cpu_percent": mean([row.cpu_percent for row in items]),
                    "memory_percent": mean([row.memory_percent for row in items]),
                    "gpu_percent": mean([row.gpu_percent for row in items]),
                    "vram_percent": mean([row.vram_percent for row in items]),
                    "thermal_c": mean([row.thermal_c for row in items if row.thermal_c is not None]),
                    "power_watts": mean([row.power_watts for row in items if row.power_watts is not None]),
                }
            )
        return result

    def snapshot(self) -> dict[str, Any]:
        """Return bounded heatmap metadata."""
        with self._lock:
            samples = len(self._samples)
        return {"samples": samples, "buckets": len(self.aggregate(buckets=24))}


@dataclass(frozen=True, slots=True)
class TwinNode:
    """Descriptive dependency node used for predictive what-if simulation."""

    node_id: str
    kind: str
    healthy: bool = True
    capacity: float = 1.0
    load: float = 0.0


class PredictiveDependencyTwin:
    """Model dependency propagation without authorizing or executing changes."""

    def __init__(self, *, max_nodes: int = 50_000) -> None:
        self.max_nodes = max(100, min(int(max_nodes), 1_000_000))
        self._nodes: dict[str, TwinNode] = {}
        self._edges: set[tuple[str, str]] = set()
        self._lock = threading.RLock()

    def upsert_node(self, node: TwinNode) -> TwinNode:
        """Insert or replace one node after validating resource bounds."""
        if not node.node_id.strip() or not node.kind.strip():
            raise ValueError("node_id and kind are required")
        if node.capacity <= 0 or node.load < 0:
            raise ValueError("node capacity must be positive and load non-negative")
        with self._lock:
            if node.node_id not in self._nodes and len(self._nodes) >= self.max_nodes:
                raise RuntimeError("digital twin node limit reached")
            self._nodes[node.node_id] = TwinNode(
                str(node.node_id).strip(),
                str(node.kind).strip(),
                bool(node.healthy),
                float(node.capacity),
                float(node.load),
            )
        return self._nodes[node.node_id]

    def relate(self, dependency: str, dependent: str) -> None:
        """Declare that ``dependent`` requires ``dependency``."""
        source, target = str(dependency).strip(), str(dependent).strip()
        if not source or not target or source == target:
            raise ValueError("invalid dependency relation")
        with self._lock:
            if source not in self._nodes or target not in self._nodes:
                raise KeyError("both dependency nodes must exist before relating them")
            self._edges.add((source, target))

    def simulate_failure(self, failed_nodes: Iterable[str]) -> dict[str, Any]:
        """Propagate declared failures and capacity pressure deterministically."""
        requested = {str(item).strip() for item in failed_nodes if str(item).strip()}
        with self._lock:
            nodes = dict(self._nodes)
            edges = set(self._edges)
        unknown = sorted(requested - set(nodes))
        if unknown:
            raise KeyError(f"unknown twin nodes: {unknown}")
        impacted = set(requested)
        changed = True
        while changed:
            changed = False
            for dependency, dependent in sorted(edges):
                if dependency in impacted and dependent not in impacted:
                    impacted.add(dependent)
                    changed = True
        overloaded: list[str] = []
        for node_id, node in nodes.items():
            if node_id in impacted:
                continue
            incoming_failures = sum(1 for dependency, dependent in edges if dependent == node_id and dependency in impacted)
            projected_load = node.load + float(incoming_failures)
            if projected_load > node.capacity:
                overloaded.append(node_id)
        all_impacted = sorted(impacted | set(overloaded))
        return {
            "failed": sorted(requested),
            "impacted": all_impacted,
            "overloaded": sorted(overloaded),
            "survivors": sorted(set(nodes) - set(all_impacted)),
            "nodes": len(nodes),
            "impact_ratio": round(len(all_impacted) / max(1, len(nodes)), 6),
        }

    def snapshot(self) -> dict[str, Any]:
        """Return the descriptive graph without operational authority."""
        with self._lock:
            return {
                "version": "12.8.0",
                "nodes": [asdict(self._nodes[key]) for key in sorted(self._nodes)],
                "edges": [list(edge) for edge in sorted(self._edges)],
            }


@dataclass(frozen=True, slots=True)
class DriftAssessment:
    """Bounded statistical assessment of a quality metric against baseline."""

    key: str
    baseline_mean: float
    recent_mean: float
    relative_change: float
    drifted: bool
    samples: int


class QualityDriftMonitor:
    """Track bounded quality telemetry and detect statistically material drift."""

    def __init__(self, *, max_samples_per_key: int = 2000) -> None:
        self.max_samples_per_key = max(20, min(int(max_samples_per_key), 100_000))
        self._samples: dict[str, list[tuple[float, float]]] = {}
        self._lock = threading.RLock()

    def observe(self, key: str, value: float, *, timestamp: float | None = None) -> None:
        """Append one normalized quality observation."""
        name = str(key).strip()
        score = float(value)
        if not name:
            raise ValueError("quality metric key is required")
        if score != score or score in (float("inf"), float("-inf")):
            raise ValueError("quality metric must be finite")
        with self._lock:
            rows = self._samples.setdefault(name, [])
            rows.append((time() if timestamp is None else float(timestamp), score))
            if len(rows) > self.max_samples_per_key:
                del rows[: len(rows) - self.max_samples_per_key]

    def assess(self, key: str, *, recent_window: int = 20, min_samples: int = 40, relative_tolerance: float = 0.05, higher_is_better: bool = True) -> DriftAssessment:
        """Compare a recent window with the preceding baseline window."""
        name = str(key).strip()
        recent_count = max(1, min(int(recent_window), self.max_samples_per_key // 2))
        minimum = max(2, min(int(min_samples), self.max_samples_per_key))
        with self._lock:
            rows = list(self._samples.get(name, ()))
        if len(rows) < minimum:
            return DriftAssessment(name, 0.0, 0.0, 0.0, False, len(rows))
        recent = [value for _, value in rows[-recent_count:]]
        baseline = [value for _, value in rows[:-recent_count]]
        if not baseline:
            return DriftAssessment(name, 0.0, statistics.fmean(recent), 0.0, False, len(rows))
        baseline_mean = statistics.fmean(baseline)
        recent_mean = statistics.fmean(recent)
        relative = (recent_mean - baseline_mean) / max(abs(baseline_mean), 1e-9)
        tolerance = abs(float(relative_tolerance))
        drifted = relative < -tolerance if higher_is_better else relative > tolerance
        return DriftAssessment(name, baseline_mean, recent_mean, relative, drifted, len(rows))

    def snapshot(self, *, recent_window: int = 20) -> dict[str, Any]:
        """Return deterministic assessments for all tracked metrics."""
        with self._lock:
            keys = sorted(self._samples)
        return {key: asdict(self.assess(key, recent_window=recent_window)) for key in keys}


@dataclass(frozen=True, slots=True)
class ErrorBudgetAssessment:
    """Availability error-budget and burn-rate assessment."""

    target_availability: float
    observed_availability: float
    budget_fraction_consumed: float
    budget_remaining: float
    burn_rate: float
    exhausted: bool


class ErrorBudgetController:
    """Calculate service error-budget consumption without executing remediation."""

    def assess(self, *, total: int, errors: int, target_availability: float = 0.99, elapsed_seconds: float | None = None, window_seconds: float = 300.0) -> ErrorBudgetAssessment:
        """Return bounded error-budget consumption and instantaneous burn rate."""
        count = max(0, int(total))
        failed = max(0, min(int(errors), count))
        target = max(0.0, min(0.999999, float(target_availability)))
        observed = 1.0 if count == 0 else 1.0 - (failed / count)
        budget = max(1e-9, 1.0 - target)
        error_rate = 1.0 - observed
        consumed = error_rate / budget
        baseline_window = max(1.0, float(window_seconds))
        elapsed = baseline_window if elapsed_seconds is None else max(1.0, float(elapsed_seconds))
        burn = (error_rate / budget) * (baseline_window / elapsed)
        return ErrorBudgetAssessment(target, observed, max(0.0, consumed), max(0.0, 1.0 - consumed), max(0.0, burn), consumed >= 1.0)



"""Agent identity, delegated authority, sender keys, key rotation and replay protection."""
from __future__ import annotations

import base64
import fnmatch
import hashlib
import json
import os
import tempfile
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .canonical import canonical_bytes
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class AgentIdentity:
    """Authority-issued agent identity with its own public signing key."""

    agent_id: str
    issuer: str
    key_id: str
    public_key_b64: str
    audience: str
    issued_at: float
    expires_at: float
    capabilities: tuple[str, ...]
    parent_agent_id: str | None = None
    delegation_id: str | None = None
    signature_b64: str = ""

    def unsigned(self) -> dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "issuer": self.issuer,
            "key_id": self.key_id,
            "public_key_b64": self.public_key_b64,
            "audience": self.audience,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "capabilities": self.capabilities,
            "parent_agent_id": self.parent_agent_id,
            "delegation_id": self.delegation_id,
        }


class AgentIdentityAuthority:
    """Ed25519 authority with durable issuer keys and per-agent proof-of-possession keys."""

    STATE_VERSION = 2

    def __init__(
        self,
        *,
        issuer: str = "jarvis-12.8.0",
        state_path: str | Path | None = None,
        secret: bytes | None = None,
    ) -> None:
        self.issuer = str(issuer)
        self.state_path = Path(state_path).resolve() if state_path is not None else None
        if self.state_path is not None and secret is None:
            raise ValueError("persistent identity authority requires a secret")
        self._secret = hashlib.sha256(bytes(secret)).digest() if secret is not None else None
        self._lock = threading.RLock()
        loaded = self._load() if self.state_path is not None else None
        if loaded is None:
            self._private = Ed25519PrivateKey.generate()
            self._public = self._private.public_key()
            self._key_id = f"key_{uuid7()}"
            self._trusted_public_keys: dict[str, Ed25519PublicKey] = {self._key_id: self._public}
            self._agent_public_keys: dict[str, tuple[str, Ed25519PublicKey]] = {}
            self._agent_private_keys: dict[str, tuple[str, bytes]] = {}
            self._revoked: set[str] = set()
            self._retired_keys: set[str] = set()
            self._persist()
        else:
            (
                self._private,
                self._public,
                self._key_id,
                self._trusted_public_keys,
                self._agent_public_keys,
                self._agent_private_keys,
                self._revoked,
                self._retired_keys,
            ) = loaded

    @property
    def key_id(self) -> str:
        return self._key_id

    @property
    def public_key(self) -> Ed25519PublicKey:
        """Return the current authority verification key."""
        return self._public

    def _state_key(self) -> bytes:
        if self._secret is None:
            raise RuntimeError("identity persistence key is unavailable")
        return hashlib.sha256(self._secret + b"\0identity-state-v2").digest()

    @staticmethod
    def _raw_public(key: Ed25519PublicKey) -> bytes:
        return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @staticmethod
    def _raw_private(key: Ed25519PrivateKey) -> bytes:
        return key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())

    def _persist(self) -> None:
        if self.state_path is None:
            return
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        private_raw = self._raw_private(self._private)
        nonce = os.urandom(12)
        cipher = AESGCM(self._state_key()).encrypt(nonce, private_raw, self.issuer.encode("utf-8"))
        agent_documents: dict[str, dict[str, str]] = {}
        for agent_id, (agent_key_id, private_bytes) in sorted(self._agent_private_keys.items()):
            agent_nonce = os.urandom(12)
            agent_cipher = AESGCM(self._state_key()).encrypt(
                agent_nonce,
                private_bytes,
                f"{self.issuer}:{agent_id}:{agent_key_id}".encode("utf-8"),
            )
            public = self._agent_public_keys[agent_id][1]
            agent_documents[agent_id] = {
                "key_id": agent_key_id,
                "public_b64": base64.b64encode(self._raw_public(public)).decode("ascii"),
                "private_cipher_b64": base64.b64encode(agent_nonce + agent_cipher).decode("ascii"),
            }
        document = {
            "version": self.STATE_VERSION,
            "issuer": self.issuer,
            "key_id": self._key_id,
            "private_cipher_b64": base64.b64encode(nonce + cipher).decode("ascii"),
            "trusted_public_keys": {
                key: base64.b64encode(self._raw_public(value)).decode("ascii")
                for key, value in sorted(self._trusted_public_keys.items())
            },
            "agents": agent_documents,
            "revoked": sorted(self._revoked),
            "retired": sorted(self._retired_keys),
        }
        fd, temp_name = tempfile.mkstemp(prefix=self.state_path.name + ".", dir=self.state_path.parent)
        try:
            if hasattr(os, "fchmod"):
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(document, handle, sort_keys=True, separators=(",", ":"))
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.state_path)
            os.chmod(self.state_path, 0o600)
        finally:
            Path(temp_name).unlink(missing_ok=True)

    def _load(self):
        if self.state_path is None or not self.state_path.exists():
            return None
        try:
            document = json.loads(self.state_path.read_text(encoding="utf-8"))
            version = int(document.get("version", 0))
            if version != self.STATE_VERSION or document.get("issuer") != self.issuer:
                raise ValueError("unsupported identity state")
            encrypted = base64.b64decode(str(document["private_cipher_b64"]), validate=True)
            private_raw = AESGCM(self._state_key()).decrypt(
                encrypted[:12],
                encrypted[12:],
                self.issuer.encode("utf-8"),
            )
            private = Ed25519PrivateKey.from_private_bytes(private_raw)
            public = private.public_key()
            trusted: dict[str, Ed25519PublicKey] = {}
            for key_id, encoded in dict(document.get("trusted_public_keys", {})).items():
                trusted[str(key_id)] = Ed25519PublicKey.from_public_bytes(
                    base64.b64decode(str(encoded), validate=True)
                )
            key_id = str(document["key_id"])
            if key_id not in trusted:
                trusted[key_id] = public
            if self._raw_public(trusted[key_id]) != self._raw_public(public):
                raise ValueError("active identity public key mismatch")

            agent_public: dict[str, tuple[str, Ed25519PublicKey]] = {}
            agent_private: dict[str, tuple[str, bytes]] = {}
            for agent_id, payload in dict(document.get("agents", {})).items():
                agent_key_id = str(payload["key_id"])
                pub_raw = base64.b64decode(str(payload["public_b64"]), validate=True)
                public_key = Ed25519PublicKey.from_public_bytes(pub_raw)
                encrypted_agent = base64.b64decode(str(payload["private_cipher_b64"]), validate=True)
                agent_raw = AESGCM(self._state_key()).decrypt(
                    encrypted_agent[:12],
                    encrypted_agent[12:],
                    f"{self.issuer}:{agent_id}:{agent_key_id}".encode("utf-8"),
                )
                derived_public = Ed25519PrivateKey.from_private_bytes(agent_raw).public_key()
                if self._raw_public(derived_public) != pub_raw:
                    raise ValueError(f"agent key mismatch: {agent_id}")
                agent_public[str(agent_id)] = (agent_key_id, public_key)
                agent_private[str(agent_id)] = (agent_key_id, agent_raw)
            return (
                private,
                public,
                key_id,
                trusted,
                agent_public,
                agent_private,
                set(map(str, document.get("revoked", []))),
                set(map(str, document.get("retired", []))),
            )
        except Exception as exc:
            raise RuntimeError(f"identity state load failed: {type(exc).__name__}: {exc}") from exc

    def sign_bytes(self, value: bytes) -> bytes:
        """Sign bytes with the current authority key."""
        return self._private.sign(bytes(value))

    def sign_as(self, identity: AgentIdentity, value: bytes) -> bytes:
        """Produce sender proof using the private key bound to an issued identity."""
        with self._lock:
            if identity.agent_id in self._revoked or identity.expires_at <= time.time():
                raise PermissionError("identity is revoked or expired")
            record = self._agent_private_keys.get(identity.agent_id)
            if record is None or record[0] != self.agent_key_id(identity):
                raise PermissionError("agent private key is unavailable")
            key = Ed25519PrivateKey.from_private_bytes(record[1])
            return key.sign(bytes(value))

    def agent_key_id(self, identity: AgentIdentity) -> str:
        with self._lock:
            record = self._agent_public_keys.get(identity.agent_id)
        return record[0] if record else ""

    def agent_public_key(self, agent_id: str) -> tuple[str, Ed25519PublicKey] | None:
        """Return a registered agent verification key without exposing private key material."""
        with self._lock:
            record = self._agent_public_keys.get(str(agent_id))
            return record

    def verify_agent_signature(self, identity: AgentIdentity, value: bytes, signature: bytes) -> bool:
        if not self.verify(identity, audience=identity.audience):
            return False
        try:
            public = Ed25519PublicKey.from_public_bytes(base64.b64decode(identity.public_key_b64, validate=True))
            public.verify(bytes(signature), bytes(value))
            return True
        except Exception:
            return False

    def rotate(self, *, retire_previous: bool = False) -> str:
        """Rotate the active authority signing key."""
        with self._lock:
            previous = self._key_id
            self._private = Ed25519PrivateKey.generate()
            self._public = self._private.public_key()
            self._key_id = f"key_{uuid7()}"
            self._trusted_public_keys[self._key_id] = self._public
            if retire_previous:
                self._retired_keys.add(previous)
            self._persist()
            return self._key_id

    def issue(
        self,
        *,
        audience: str,
        capabilities: tuple[str, ...],
        ttl_seconds: float = 3600.0,
        parent: AgentIdentity | None = None,
        agent_id: str | None = None,
    ) -> AgentIdentity:
        """Issue a least-privilege identity with a unique sender key."""
        now = time.time()
        ttl = max(1.0, min(float(ttl_seconds), 86_400.0))
        requested = tuple(sorted({str(x).strip() for x in capabilities if str(x).strip()}))
        if not requested:
            raise ValueError("at least one capability is required")
        if parent is not None:
            if not self.verify(parent, audience=parent.audience, now=now):
                raise PermissionError("parent identity is not trusted or has expired")
            narrowed = tuple(
                cap
                for cap in requested
                if any(fnmatch.fnmatch(cap, allowed) for allowed in parent.capabilities)
            )
            if set(narrowed) != set(requested):
                raise PermissionError("delegation cannot broaden parent authority")
            ttl = min(ttl, max(1.0, parent.expires_at - now))
        identity_agent_id = str(agent_id or f"agent_{uuid7()}")
        if not identity_agent_id.strip():
            raise ValueError("agent_id is required")
        with self._lock:
            if identity_agent_id in self._agent_private_keys:
                raise ValueError("agent_id already exists")
            agent_private = Ed25519PrivateKey.generate()
            agent_public = agent_private.public_key()
            agent_key_id = f"agentkey_{uuid7()}"
            self._agent_public_keys[identity_agent_id] = (agent_key_id, agent_public)
            self._agent_private_keys[identity_agent_id] = (agent_key_id, self._raw_private(agent_private))
            public_key_b64 = base64.b64encode(self._raw_public(agent_public)).decode("ascii")
            identity = AgentIdentity(
                agent_id=identity_agent_id,
                issuer=self.issuer,
                key_id=self._key_id,
                public_key_b64=public_key_b64,
                audience=str(audience),
                issued_at=now,
                expires_at=now + ttl,
                capabilities=requested,
                parent_agent_id=parent.agent_id if parent else None,
                delegation_id=f"deleg_{uuid7()}" if parent else None,
            )
            signature = base64.b64encode(self._private.sign(canonical_bytes(identity.unsigned()))).decode("ascii")
            result = AgentIdentity(**{**asdict(identity), "signature_b64": signature})
            self._persist()
            return result

    def revoke(self, agent_id: str) -> None:
        with self._lock:
            self._revoked.add(str(agent_id))
            self._persist()

    def unrevoke(self, agent_id: str) -> None:
        with self._lock:
            self._revoked.discard(str(agent_id))
            self._persist()

    def trust_snapshot(self) -> dict[str, Any]:
        """Return public trust metadata without exposing private key material."""
        with self._lock:
            return {
                "issuer": self.issuer,
                "active_key_id": self._key_id,
                "trusted_key_ids": sorted(self._trusted_public_keys),
                "issued_agent_ids": sorted(self._agent_public_keys),
                "agent_key_ids": sorted(key_id for key_id, _ in self._agent_public_keys.values()),
                "revoked_agent_ids": sorted(self._revoked),
                "retired_key_ids": sorted(self._retired_keys),
            }

    def verify(
        self,
        identity: AgentIdentity,
        *,
        audience: str,
        capability: str | None = None,
        now: float | None = None,
    ) -> bool:
        """Verify issuer attestation, agent key binding, audience, validity and capability."""
        current = time.time() if now is None else float(now)
        if identity.issuer != self.issuer or identity.audience != str(audience):
            return False
        if current >= identity.expires_at or identity.issued_at > current + 5.0:
            return False
        with self._lock:
            if identity.agent_id in self._revoked or identity.key_id in self._retired_keys:
                return False
            issuer_public = self._trusted_public_keys.get(identity.key_id)
            agent_record = self._agent_public_keys.get(identity.agent_id)
        if issuer_public is None:
            return False
        if agent_record is not None:
            expected_raw = self._raw_public(agent_record[1])
            try:
                presented_raw = base64.b64decode(identity.public_key_b64, validate=True)
            except Exception:
                return False
            if presented_raw != expected_raw:
                return False
        if capability is not None and not any(
            fnmatch.fnmatch(str(capability), allowed) for allowed in identity.capabilities
        ):
            return False
        try:
            issuer_public.verify(
                base64.b64decode(identity.signature_b64, validate=True),
                canonical_bytes(identity.unsigned()),
            )
        except Exception:
            return False
        return True


class ReplayCache:
    """Thread-safe, bounded replay cache with nonce TTL and fingerprint isolation."""

    def __init__(self, *, max_entries: int = 100_000) -> None:
        self.max_entries = max(100, min(int(max_entries), 1_000_000))
        self._items: dict[str, float] = {}
        self._lock = threading.RLock()

    def consume(self, nonce: str, *, expires_at: float) -> bool:
        now = time.time()
        if float(expires_at) <= now:
            return False
        key = hashlib.sha256(str(nonce).encode("utf-8")).hexdigest()
        with self._lock:
            self._items = {key_: expiry for key_, expiry in self._items.items() if expiry > now}
            if key in self._items:
                return False
            if len(self._items) >= self.max_entries:
                oldest = min(self._items, key=self._items.get)
                self._items.pop(oldest, None)
            self._items[key] = float(expires_at)
            return True



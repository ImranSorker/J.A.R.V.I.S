"""Persistent personal regression corpus for J.A.R.V.I.S. 12.8.0."""
from __future__ import annotations

import json
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from .canonical import digest
from .ids import uuid7


@dataclass(frozen=True, slots=True)
class RegressionCase:
    case_id: str
    goal: str
    context: Mapping[str, Any]
    expected_behavior: Mapping[str, Any]
    allowed_tools: tuple[str, ...]
    expected_artifacts: tuple[str, ...]
    security_requirements: tuple[str, ...]
    performance_bounds: Mapping[str, float]
    source: str = "operator"
    created_at: float = 0.0
    case_digest: str = ""

    @classmethod
    def create(
        cls,
        *,
        goal: str,
        context: Mapping[str, Any],
        expected_behavior: Mapping[str, Any],
        allowed_tools: Iterable[str] = (),
        expected_artifacts: Iterable[str] = (),
        security_requirements: Iterable[str] = (),
        performance_bounds: Mapping[str, float] | None = None,
        source: str = "operator",
    ) -> "RegressionCase":
        import time
        case = cls(
            uuid7(), str(goal).strip(), dict(context), dict(expected_behavior), tuple(sorted(set(map(str, allowed_tools)))),
            tuple(sorted(set(map(str, expected_artifacts)))), tuple(sorted(set(map(str, security_requirements)))),
            {str(k): float(v) for k, v in dict(performance_bounds or {}).items()}, str(source), time.time(), "",
        )
        return cls(**{**asdict(case), "case_digest": digest({k: v for k, v in asdict(case).items() if k != "case_digest"})})


class RegressionCorpus:
    """Append-only JSONL corpus with deterministic per-case identity."""

    def __init__(self, path: str | Path = "data/regression/corpus.jsonl") -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def add(self, case: RegressionCase) -> RegressionCase:
        line = json.dumps(asdict(case), sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
        with self._lock, self.path.open("a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
        return case

    def list(self) -> list[RegressionCase]:
        if not self.path.is_file():
            return []
        values: list[RegressionCase] = []
        with self._lock, self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                data = json.loads(line)
                values.append(RegressionCase(**data))
        return values

    def run(self, evaluator: Callable[[RegressionCase], tuple[bool, str]], cases: Iterable[RegressionCase] | None = None) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for case in list(cases) if cases is not None else self.list():
            try:
                passed, detail = evaluator(case)
                results.append({"case_id": case.case_id, "passed": bool(passed), "detail": str(detail)[:2_000]})
            except Exception as exc:
                results.append({"case_id": case.case_id, "passed": False, "detail": f"{type(exc).__name__}: {exc}"})
        return results

    @staticmethod
    def generate_from_failure(
        *,
        goal: str,
        observed: Mapping[str, Any],
        expected: Mapping[str, Any],
        source: str = "generated-regression",
    ) -> RegressionCase:
        return RegressionCase.create(
            goal=goal,
            context={"observed": dict(observed)},
            expected_behavior=dict(expected),
            source=source,
        )



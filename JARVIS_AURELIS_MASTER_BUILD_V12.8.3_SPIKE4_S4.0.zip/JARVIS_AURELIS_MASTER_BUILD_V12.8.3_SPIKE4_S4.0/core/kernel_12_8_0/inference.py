"""Empirical inference planning and privacy-scoped cache governance."""
from __future__ import annotations

import math
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class ModelCapabilityCard:
    model_id: str
    architecture: str
    parameters: int | None = None
    active_parameters: int | None = None
    quantization: str | None = None
    context_tokens: int = 0
    vision: bool = False
    audio: bool = False
    tool_calling: bool = False
    structured_output: bool = False
    reasoning: bool = False
    speculative: bool = False
    lora: bool = False
    vram_mb: int | None = None
    ram_mb: int | None = None
    license: str | None = None
    provenance: str | None = None


@dataclass(frozen=True, slots=True)
class InferenceMeasurement:
    model_id: str
    task_type: str
    quality: float
    latency_ms: float
    tokens_per_second: float
    vram_mb: float
    power_w: float = 0.0
    acceptance_rate: float = 0.0
    timestamp: float = field(default_factory=time.time)


class EmpiricalInferenceRouter:
    """Choose among measured model/strategy candidates under hard resource limits."""

    def __init__(self) -> None:
        self._measurements: list[InferenceMeasurement] = []
        self._lock = threading.RLock()

    def record(self, measurement: InferenceMeasurement) -> None:
        values = (measurement.quality, measurement.latency_ms, measurement.tokens_per_second, measurement.vram_mb, measurement.power_w, measurement.acceptance_rate)
        if not all(isinstance(v, (int, float)) and math.isfinite(float(v)) and v >= 0 for v in values):
            raise ValueError("inference measurements must be finite non-negative numbers")
        if not 0.0 <= float(measurement.quality) <= 1.0 or not 0.0 <= float(measurement.acceptance_rate) <= 1.0:
            raise ValueError("quality and speculative acceptance must be within 0..1")
        with self._lock: self._measurements.append(measurement)

    def choose(self, task_type: str, *, max_vram_mb: float | None = None, prefer_latency: bool = True, speculative: bool | None = None) -> ModelCapabilityCard | None:
        with self._lock:
            rows = [m for m in self._measurements if m.task_type == task_type and (max_vram_mb is None or m.vram_mb <= max_vram_mb) and (speculative is None or (m.acceptance_rate > 0) == speculative)]
        if not rows:
            return None
        rows.sort(key=lambda m: (-(m.quality), m.latency_ms if prefer_latency else -m.tokens_per_second, m.vram_mb, -m.acceptance_rate, m.model_id))
        return ModelCapabilityCard(model_id=rows[0].model_id, architecture="measured", vram_mb=int(rows[0].vram_mb))


@dataclass(frozen=True, slots=True)
class CacheScope:
    owner: str
    workspace: str
    privacy_domain: str
    policy_digest: str
    model_generation: str


@dataclass(slots=True)
class PrefixCacheEntry:
    key: str
    scope: CacheScope
    tokens: int
    vram_mb: int
    last_used: float
    pinned: bool = False


class PrefixKVCache:
    """LRU prefix/KV cache keyed by authority and privacy boundaries."""

    def __init__(self, *, max_vram_mb: int = 4096) -> None:
        self.max_vram_mb = max(128, int(max_vram_mb)); self._entries: dict[str, PrefixCacheEntry] = {}; self._lock = threading.RLock()

    def _used(self) -> int:
        return sum(item.vram_mb for item in self._entries.values())

    @staticmethod
    def scoped_key(prefix_digest: str, scope: CacheScope) -> str:
        """Create a cache key that cryptographically includes all privacy boundaries."""
        from .canonical import digest
        return digest({"prefix": str(prefix_digest), "owner": scope.owner, "workspace": scope.workspace, "privacy_domain": scope.privacy_domain, "policy_digest": scope.policy_digest, "model_generation": scope.model_generation})

    def admit(self, key: str, scope: CacheScope, *, tokens: int, vram_mb: int, pinned: bool = False) -> PrefixCacheEntry:
        if not key or tokens < 0 or vram_mb <= 0 or vram_mb > self.max_vram_mb:
            raise ValueError("invalid prefix cache admission")
        with self._lock:
            existing = self._entries.get(key)
            if existing is not None and existing.scope != scope:
                raise PermissionError("prefix cache key is bound to a different privacy/policy scope")
            while self._used() + vram_mb > self.max_vram_mb:
                candidates = [e for e in self._entries.values() if not e.pinned and e.key != key]
                if not candidates: raise RuntimeError("prefix cache capacity exhausted")
                victim = min(candidates, key=lambda e: (e.last_used, e.key)); self._entries.pop(victim.key, None)
            entry = PrefixCacheEntry(str(key), scope, int(tokens), int(vram_mb), time.time(), bool(pinned)); self._entries[key] = entry
            return entry

    def get(self, key: str, scope: CacheScope) -> PrefixCacheEntry | None:
        with self._lock:
            entry = self._entries.get(str(key))
            if entry is None or entry.scope != scope: return None
            entry.last_used = time.time(); return entry

    def snapshot(self) -> dict[str, Any]:
        with self._lock: return {"entries": len(self._entries), "used_vram_mb": self._used(), "budget_vram_mb": self.max_vram_mb}



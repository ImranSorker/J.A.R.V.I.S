"""Durable candidate lifecycle for models, skills, policies, schemas and source changes."""
from __future__ import annotations

import base64
import json
import os
import sqlite3
import threading
from dataclasses import asdict, dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_bytes, digest
from .ids import Clock, uuid7
from hashlib import sha256
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class PromotionStatus(StrEnum):
    CANDIDATE = "candidate"
    QUARANTINED = "quarantined"
    EVALUATED = "evaluated"
    CANARY = "canary"
    PROMOTED = "promoted"
    REJECTED = "rejected"
    ROLLED_BACK = "rolled_back"


@dataclass(frozen=True, slots=True)
class PromotionCandidate:
    candidate_id: str
    kind: str
    parent: str | None
    artifact_hash: str
    evidence_hash: str
    test_results: Mapping[str, Any]
    benchmark_results: Mapping[str, Any]
    security_results: Mapping[str, Any]
    policy_results: Mapping[str, Any]
    resource_results: Mapping[str, Any]
    approval: str | None
    status: PromotionStatus
    rollback_target: str | None
    created_at: float
    updated_at: float
    approval_signature_b64: str = ""


class PromotionEngine:
    """Durable, explicit lifecycle with deterministic gates and rollback targets."""

    def __init__(self, db_path: str | Path = "data/kernel_12_8_0_promotions.db", *, approval_public_key_b64: str | None = None) -> None:
        self.db_path = str(Path(db_path).resolve())
        configured_key = approval_public_key_b64 or os.environ.get("JARVIS_PROMOTION_PUBLIC_KEY", "")
        if configured_key:
            try:
                self._approval_public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(configured_key, validate=True))
            except Exception as exc:
                raise ValueError("invalid JARVIS promotion approval public key") from exc
        else:
            self._approval_public_key = None
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        self._lock = threading.RLock()
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("CREATE TABLE IF NOT EXISTS candidates(candidate_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,created_at REAL NOT NULL,updated_at REAL NOT NULL)")
        self._db.commit()

    def _save(self, candidate: PromotionCandidate) -> PromotionCandidate:
        payload = json.dumps(asdict(candidate), sort_keys=True, separators=(",", ":"), default=str)
        self._db.execute("INSERT OR REPLACE INTO candidates VALUES(?,?,?,?)", (candidate.candidate_id, payload, candidate.created_at, candidate.updated_at))
        self._db.commit()
        return candidate

    def _load(self, candidate_id: str) -> PromotionCandidate:
        row = self._db.execute("SELECT payload_json FROM candidates WHERE candidate_id=?", (str(candidate_id),)).fetchone()
        if row is None:
            raise KeyError(candidate_id)
        data = json.loads(row[0])
        data.setdefault("approval_signature_b64", "")
        data["status"] = PromotionStatus(data["status"])
        return PromotionCandidate(**data)

    def propose(self, *, kind: str, artifact: bytes, parent: str | None = None, evidence: Mapping[str, Any] | None = None) -> PromotionCandidate:
        now = Clock.wall()
        candidate = PromotionCandidate(
            candidate_id=uuid7(),
            kind=str(kind),
            parent=parent,
            artifact_hash=digest(artifact),
            evidence_hash=digest(evidence or {}),
            test_results={},
            benchmark_results={},
            security_results={},
            policy_results={},
            resource_results={},
            approval=None,
            status=PromotionStatus.CANDIDATE,
            rollback_target=parent,
            created_at=now,
            updated_at=now,
        )
        with self._lock:
            return self._save(candidate)

    def evaluate(self, candidate_id: str, *, tests: Mapping[str, Any], benchmarks: Mapping[str, Any], security: Mapping[str, Any], policy: Mapping[str, Any], resources: Mapping[str, Any]) -> PromotionCandidate:
        with self._lock:
            current = self._load(candidate_id)
            required = (tests, benchmarks, security, policy, resources)
            status = PromotionStatus.EVALUATED if all(bool(x.get("passed", False)) for x in required) else PromotionStatus.QUARANTINED
            updated = PromotionCandidate(**{**asdict(current), "test_results": dict(tests), "benchmark_results": dict(benchmarks), "security_results": dict(security), "policy_results": dict(policy), "resource_results": dict(resources), "status": status, "updated_at": Clock.wall()})
            return self._save(updated)

    def enter_canary(self, candidate_id: str) -> PromotionCandidate:
        """Move an evaluated candidate into a controlled canary state."""
        with self._lock:
            current = self._load(candidate_id)
            if current.status != PromotionStatus.EVALUATED:
                raise RuntimeError("candidate is not canary-eligible")
            updated = PromotionCandidate(**{**asdict(current), "status": PromotionStatus.CANARY, "updated_at": Clock.wall()})
            return self._save(updated)

    def approval_payload(self, candidate_id: str, *, approval: str) -> bytes:
        """Return canonical bytes an external operator must sign."""
        with self._lock:
            current = self._load(candidate_id)
        approval_text = str(approval).strip()
        if not approval_text:
            raise ValueError("approval text is required")
        return canonical_bytes({
            "candidate_id": current.candidate_id,
            "artifact_hash": current.artifact_hash,
            "evidence_hash": current.evidence_hash,
            "approval": approval_text,
        })

    def approve_and_promote(self, candidate_id: str, *, approval: str, approval_digest: str, approval_signature_b64: str) -> PromotionCandidate:
        """Promote only from canary after candidate-bound Ed25519 operator approval."""
        approval_text = str(approval).strip()
        if not approval_text:
            raise PermissionError("explicit promotion approval is required")
        if self._approval_public_key is None:
            raise PermissionError("promotion approval public key is not configured")
        with self._lock:
            current = self._load(candidate_id)
            if current.status != PromotionStatus.CANARY:
                raise RuntimeError("candidate must pass canary before promotion")
            binding = f"{current.candidate_id}:{current.artifact_hash}:{current.evidence_hash}".encode("utf-8")
            expected_binding = sha256(binding).hexdigest()
            if str(approval_digest).strip() != expected_binding:
                raise PermissionError("promotion approval is not bound to this candidate artifact/evidence")
            try:
                signature = base64.b64decode(str(approval_signature_b64), validate=True)
                self._approval_public_key.verify(signature, self.approval_payload(candidate_id, approval=approval_text))
            except Exception as exc:
                raise PermissionError("promotion approval signature is invalid") from exc
            updated = PromotionCandidate(**{
                **asdict(current),
                "approval": approval_text,
                "approval_signature_b64": str(approval_signature_b64),
                "status": PromotionStatus.PROMOTED,
                "updated_at": Clock.wall(),
            })
            return self._save(updated)

    def reject(self, candidate_id: str, *, reason: str) -> PromotionCandidate:
        """Reject any non-promoted candidate with a durable reason."""
        if not str(reason).strip():
            raise ValueError("rejection reason is required")
        with self._lock:
            current = self._load(candidate_id)
            if current.status in {PromotionStatus.PROMOTED, PromotionStatus.ROLLED_BACK}:
                raise RuntimeError("terminal promoted candidate cannot be rejected")
            updated = PromotionCandidate(**{**asdict(current), "status": PromotionStatus.REJECTED, "updated_at": Clock.wall(), "evidence_hash": digest({"original": current.evidence_hash, "rejection_reason": str(reason)})})
            return self._save(updated)

    def rollback(self, candidate_id: str) -> PromotionCandidate:
        with self._lock:
            current = self._load(candidate_id)
            if current.status != PromotionStatus.PROMOTED:
                raise RuntimeError("only promoted candidates can be rolled back")
            updated = PromotionCandidate(**{**asdict(current), "status": PromotionStatus.ROLLED_BACK, "updated_at": Clock.wall()})
            return self._save(updated)

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._db.execute("SELECT payload_json FROM candidates ORDER BY candidate_id").fetchall()
        output = []
        for (payload,) in rows:
            item = json.loads(payload)
            output.append(item)
        return output

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()



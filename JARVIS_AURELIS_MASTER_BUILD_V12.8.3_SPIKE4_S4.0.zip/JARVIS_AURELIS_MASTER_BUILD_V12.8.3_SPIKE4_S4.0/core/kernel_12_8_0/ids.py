"""Stable identifiers and time primitives for the J.A.R.V.I.S. 12.8.0 kernel."""
from __future__ import annotations

import threading
import time
import uuid

_uuid7_lock = threading.Lock()
_uuid7_last_ms = -1
_uuid7_counter = uuid.uuid4().int & ((1 << 74) - 1)


def uuid7() -> str:
    """Return a monotonic UUIDv7-compatible identifier within this process."""
    global _uuid7_last_ms, _uuid7_counter
    ms = time.time_ns() // 1_000_000
    if ms < 0 or ms >= (1 << 48):
        raise OverflowError("current time cannot be represented by UUIDv7")
    with _uuid7_lock:
        if ms == _uuid7_last_ms:
            _uuid7_counter = (_uuid7_counter + 1) & ((1 << 74) - 1)
        else:
            _uuid7_counter = uuid.uuid4().int & ((1 << 74) - 1)
            _uuid7_last_ms = ms
        random_a = (_uuid7_counter >> 62) & ((1 << 12) - 1)
        random_b = _uuid7_counter & ((1 << 62) - 1)
    value = (ms << 80) | (0x7 << 76) | (random_a << 64) | (0x2 << 62) | random_b
    return str(uuid.UUID(int=value))


class Clock:
    """Wall and monotonic clocks kept together for correct deadlines."""

    @staticmethod
    def wall() -> float:
        return time.time()

    @staticmethod
    def monotonic() -> float:
        return time.monotonic()



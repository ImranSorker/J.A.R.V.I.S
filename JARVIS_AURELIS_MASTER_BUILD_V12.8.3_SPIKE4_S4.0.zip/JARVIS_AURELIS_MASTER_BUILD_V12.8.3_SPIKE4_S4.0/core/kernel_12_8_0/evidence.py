"""Evidence envelopes, freshness, provenance and cryptographic ledger support."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Any, Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .canonical import canonical_json, canonical_bytes, digest
from .contracts import EvidenceClass
from .ids import Clock, uuid7


@dataclass(frozen=True, slots=True)
class EvidenceEnvelope:
    evidence_id: str
    event_id: str
    trace_id: str
    mission_id: str | None
    actor_id: str
    agent_id: str
    operation: str
    source: str
    input_digest: str | None
    output_digest: str | None
    context_digest: str | None
    policy_digest: str | None
    capability_id: str | None
    lease_id: str | None
    model_id: str | None
    tool_id: str | None
    timestamp_wall: float
    timestamp_monotonic: float
    confidence: float
    evidence_class: EvidenceClass
    provenance: Mapping[str, Any]
    parent_evidence: str | None = None
    created_at: float = 0.0
    observed_at: float | None = None
    verified_at: float | None = None
    expires_at: float | None = None
    content_digest: str | None = None

    @classmethod
    def create(cls, *, actor_id: str, agent_id: str, operation: str, source: str, evidence_class: EvidenceClass, provenance: Mapping[str, Any] | None = None, mission_id: str | None = None, trace_id: str | None = None, event_id: str | None = None, input_value: Any = None, output_value: Any = None, confidence: float = 1.0, expires_at: float | None = None, **kwargs: Any) -> "EvidenceEnvelope":
        now = Clock.wall()
        return cls(
            evidence_id=uuid7(), event_id=event_id or uuid7(), trace_id=trace_id or uuid7(), mission_id=mission_id,
            actor_id=str(actor_id), agent_id=str(agent_id), operation=str(operation), source=str(source),
            input_digest=None if input_value is None else digest(input_value), output_digest=None if output_value is None else digest(output_value),
            context_digest=kwargs.get("context_digest"), policy_digest=kwargs.get("policy_digest"), capability_id=kwargs.get("capability_id"), lease_id=kwargs.get("lease_id"),
            model_id=kwargs.get("model_id"), tool_id=kwargs.get("tool_id"), timestamp_wall=now, timestamp_monotonic=Clock.monotonic(),
            confidence=max(0.0, min(1.0, float(confidence))), evidence_class=evidence_class, provenance=dict(provenance or {}), parent_evidence=kwargs.get("parent_evidence"),
            created_at=now, observed_at=kwargs.get("observed_at", now), verified_at=kwargs.get("verified_at"), expires_at=expires_at,
            content_digest=None if output_value is None else digest(output_value),
        )

    def fresh(self, now: float | None = None) -> bool:
        current = Clock.wall() if now is None else float(now)
        return self.expires_at is None or current < self.expires_at

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["evidence_class"] = self.evidence_class.value
        value["provenance"] = dict(self.provenance)
        return value


@dataclass(frozen=True, slots=True)
class SignedProvenance:
    bundle_id: str
    algorithm: str
    key_id: str
    statement_digest: str
    signature_b64: str


class EvidenceLedger:
    """Persistent append-only evidence projection with hash-chain verification."""

    def __init__(self, db_path: str | Path = "data/kernel_12_8_0_evidence.db") -> None:
        self.db_path = str(Path(db_path).resolve())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.db_path, timeout=20, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("""CREATE TABLE IF NOT EXISTS evidence(
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            evidence_id TEXT UNIQUE NOT NULL,
            event_id TEXT NOT NULL,
            trace_id TEXT NOT NULL,
            mission_id TEXT,
            actor_id TEXT NOT NULL,
            agent_id TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            previous_hash TEXT NOT NULL,
            record_hash TEXT NOT NULL,
            created_at REAL NOT NULL
        )""")
        self._db.commit()

    def append(self, envelope: EvidenceEnvelope) -> int:
        payload = canonical_json(envelope.to_dict()).decode("utf-8")
        with self._lock:
            row = self._db.execute("SELECT seq FROM evidence WHERE evidence_id=?", (envelope.evidence_id,)).fetchone()
            if row:
                return int(row[0])
            previous_row = self._db.execute("SELECT record_hash FROM evidence ORDER BY seq DESC LIMIT 1").fetchone()
            previous = str(previous_row[0]) if previous_row else "0" * 64
            record_hash = hashlib.sha256(canonical_bytes({"previous_hash": previous, "payload": envelope.to_dict()})).hexdigest()
            cur = self._db.execute("INSERT INTO evidence(evidence_id,event_id,trace_id,mission_id,actor_id,agent_id,payload_json,previous_hash,record_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (envelope.evidence_id, envelope.event_id, envelope.trace_id, envelope.mission_id, envelope.actor_id, envelope.agent_id, payload, previous, record_hash, envelope.created_at or Clock.wall()))
            self._db.commit()
            return int(cur.lastrowid)

    def verify(self) -> bool:
        previous = "0" * 64
        with self._lock:
            rows = self._db.execute("SELECT payload_json,previous_hash,record_hash FROM evidence ORDER BY seq").fetchall()
        for payload, previous_hash, record_hash in rows:
            expected = hashlib.sha256(canonical_bytes({"previous_hash": previous, "payload": json.loads(payload)})).hexdigest()
            if previous_hash != previous or record_hash != expected:
                return False
            previous = expected
        return True

    def query(self, *, mission_id: str | None = None, trace_id: str | None = None, limit: int = 100) -> list[EvidenceEnvelope]:
        sql = "SELECT payload_json FROM evidence WHERE 1=1"
        params: list[object] = []
        if mission_id is not None:
            sql += " AND mission_id=?"; params.append(str(mission_id))
        if trace_id is not None:
            sql += " AND trace_id=?"; params.append(str(trace_id))
        sql += " ORDER BY seq DESC LIMIT ?"; params.append(max(1, min(int(limit), 1000)))
        with self._lock:
            rows = self._db.execute(sql, params).fetchall()
        values: list[EvidenceEnvelope] = []
        for (payload,) in rows:
            data = json.loads(payload)
            data["evidence_class"] = EvidenceClass(data["evidence_class"])
            values.append(EvidenceEnvelope(**data))
        return values

    def tail(self) -> dict[str, Any]:
        """Return the current ledger checkpoint without exposing record payloads."""
        with self._lock:
            row = self._db.execute("SELECT seq,record_hash FROM evidence ORDER BY seq DESC LIMIT 1").fetchone()
        return {"seq": int(row[0]) if row else 0, "tail_hash": str(row[1]) if row else "0" * 64}

    def export(self, path: str | Path, *, mission_id: str | None = None) -> Path:
        """Export a deterministic, redacted evidence stream for independent verification."""
        destination = Path(path).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        rows = self.query(mission_id=mission_id, limit=1000)
        text = "\n".join(json.dumps(item.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False) for item in reversed(rows)) + ("\n" if rows else "")
        destination.write_text(text, encoding="utf-8")
        return destination

    def checkpoint(self, private_key: Ed25519PrivateKey, key_id: str) -> SignedProvenance:
        """Create a signed checkpoint over ledger tail state."""
        statement = {"version": "12.8.0", "ledger": "evidence", **self.tail()}
        return sign_provenance(statement, private_key, key_id)

    def close(self) -> None:
        with self._lock:
            self._db.commit(); self._db.close()


def sign_provenance(statement: Mapping[str, Any], private_key: Ed25519PrivateKey, key_id: str) -> SignedProvenance:
    """Sign a canonical provenance statement without embedding secrets."""
    statement_digest = hashlib.sha256(canonical_bytes(statement)).hexdigest()
    signature = private_key.sign(statement_digest.encode("ascii"))
    import base64
    return SignedProvenance(uuid7(), "Ed25519-SHA256Digest", str(key_id), statement_digest, base64.b64encode(signature).decode("ascii"))


def verify_provenance(statement: Mapping[str, Any], bundle: SignedProvenance, public_key: Ed25519PublicKey) -> bool:
    """Verify a signed provenance statement."""
    import base64
    statement_digest = hashlib.sha256(canonical_bytes(statement)).hexdigest()
    if not statement_digest == bundle.statement_digest:
        return False
    try:
        public_key.verify(base64.b64decode(bundle.signature_b64.encode("ascii")), statement_digest.encode("ascii"))
    except Exception:
        return False
    return True



"""Unified multimodal runtime contracts for text, vision, and audio adapters."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Protocol

logger = logging.getLogger("jarvis.multimodal")


@dataclass(frozen=True)
class ModalityResult:
    """Normalized multimodal inference result."""

    modality: str
    text: str
    confidence: float = 1.0
    metadata: dict[str, Any] | None = None


class VisionAdapter(Protocol):
    """Optional real vision backend contract."""

    def analyze(self, image: bytes, prompt: str) -> ModalityResult: raise RuntimeError("abstract contract method invoked")
class AudioAdapter(Protocol):
    """Optional real audio backend contract."""

    def transcribe(self, audio: bytes) -> ModalityResult: raise RuntimeError("abstract contract method invoked")
    def synthesize(self, text: str) -> bytes: raise RuntimeError("abstract contract method invoked")
class MultimodalRuntime:
    """Single entry point for optional multimodal adapters."""

    def __init__(self) -> None:
        self._vision: VisionAdapter | None = None
        self._audio: AudioAdapter | None = None
        self._lock = threading.RLock()

    def set_vision_adapter(self, adapter: VisionAdapter | None) -> None:
        """Install a concrete vision adapter."""
        with self._lock:
            self._vision = adapter

    def set_audio_adapter(self, adapter: AudioAdapter | None) -> None:
        """Install a concrete audio adapter."""
        with self._lock:
            self._audio = adapter

    def analyze_image(self, image: bytes, prompt: str) -> ModalityResult:
        """Analyze an image through the configured real vision backend."""
        if not image:
            raise ValueError("image data is required")
        with self._lock:
            adapter = self._vision
        if adapter is None:
            raise RuntimeError("vision backend is not configured")
        started = time.perf_counter()
        result = adapter.analyze(bytes(image), str(prompt))
        logger.info("vision_inference", extra={"latency_ms": (time.perf_counter() - started) * 1000.0})
        return result

    def transcribe_audio(self, audio: bytes) -> ModalityResult:
        """Transcribe audio through the configured real speech backend."""
        if not audio:
            raise ValueError("audio data is required")
        with self._lock:
            adapter = self._audio
        if adapter is None:
            raise RuntimeError("audio backend is not configured")
        return adapter.transcribe(bytes(audio))

    def synthesize_speech(self, text: str) -> bytes:
        """Synthesize speech through the configured backend."""
        if not str(text).strip():
            raise ValueError("text is required")
        with self._lock:
            adapter = self._audio
        if adapter is None:
            raise RuntimeError("audio backend is not configured")
        return bytes(adapter.synthesize(text))

    def capabilities(self) -> dict[str, bool]:
        """Return currently configured modality capabilities."""
        with self._lock:
            return {"vision": self._vision is not None, "audio": self._audio is not None}



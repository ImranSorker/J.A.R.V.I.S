"""Durable distributed transport with leases, retries, idempotency and streaming state."""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from core.durable_distributed_queue import DurableDistributedQueue

logger = logging.getLogger("jarvis.distributed_transport")


@dataclass(frozen=True, slots=True)
class TransportEvent:
    """Observable lifecycle event emitted by distributed task transport."""

    event_id: str
    task_id: str
    kind: str
    payload: dict[str, Any]
    timestamp: float = field(default_factory=time.time)


class DistributedTaskTransport:
    """Coordinate durable tasks while keeping execution behind an injected callback."""

    def __init__(self, queue: DurableDistributedQueue, *, max_events: int = 10_000) -> None:
        self.queue = queue
        self.max_events = max(100, min(int(max_events), 100_000))
        self._events: list[TransportEvent] = []
        self._lock = threading.RLock()
        self._subscribers: list[Callable[[TransportEvent], None]] = []

    def subscribe(self, callback: Callable[[TransportEvent], None]) -> None:
        """Register an event observer."""
        if not callable(callback):
            raise TypeError("callback must be callable")
        with self._lock:
            self._subscribers.append(callback)

    def submit(self, capability: str, payload: dict[str, Any], *, idempotency_key: str | None = None) -> str:
        """Persist one JSON task and emit a submission event."""
        body = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        existing = self.queue.get(str(idempotency_key)) if idempotency_key else None
        task_id = self.queue.enqueue(capability, body, idempotency_key=idempotency_key)
        self._emit(task_id, "deduplicated" if existing is not None else "submitted", {"capability": capability})
        return task_id

    def worker_once(self, worker_id: str, capability: str, executor: Callable[[dict[str, Any]], dict[str, Any]]) -> dict[str, Any] | None:
        """Lease one task, execute it, and atomically record success/failure."""
        task = self.queue.lease(worker_id, capability)
        if task is None:
            return None
        self._emit(task.task_id, "leased", {"worker_id": worker_id, "attempt": task.attempts})
        try:
            payload = json.loads(task.payload)
            if not isinstance(payload, dict):
                raise ValueError("task payload must be a JSON object")
            result = executor(payload)
            if not isinstance(result, dict) or "ok" not in result:
                raise ValueError("executor must return a result object containing ok")
            if bool(result.get("ok")):
                self.queue.complete(task.task_id, json.dumps(result, sort_keys=True, default=str))
                self._emit(task.task_id, "completed", {"worker_id": worker_id})
            else:
                self.queue.fail(task.task_id, json.dumps(result, sort_keys=True, default=str))
                self._emit(task.task_id, "failed", {"worker_id": worker_id})
            return result
        except Exception as exc:
            self.queue.fail(task.task_id, json.dumps({"ok": False, "error": type(exc).__name__}, sort_keys=True))
            self._emit(task.task_id, "failed", {"worker_id": worker_id, "error": type(exc).__name__})
            logger.exception("distributed_task_failed", extra={"task_id": task.task_id})
            return {"ok": False, "error": type(exc).__name__}

    def stream(self, task_id: str) -> Iterable[TransportEvent]:
        """Yield retained lifecycle events for a task in timestamp order."""
        with self._lock:
            events = [event for event in self._events if event.task_id == task_id]
        yield from sorted(events, key=lambda event: (event.timestamp, event.event_id))

    def _emit(self, task_id: str, kind: str, payload: dict[str, Any]) -> None:
        event = TransportEvent(f"evt_{uuid.uuid4().hex[:16]}", task_id, kind, dict(payload))
        with self._lock:
            self._events.append(event)
            if len(self._events) > self.max_events:
                del self._events[: len(self._events) - self.max_events]
            subscribers = tuple(self._subscribers)
        for callback in subscribers:
            try:
                callback(event)
            except Exception:
                logger.exception("transport_subscriber_failed")

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret transport state."""
        with self._lock:
            return {"events": len(self._events), "subscriptions": len(self._subscribers), "queue": self.queue.stats()}



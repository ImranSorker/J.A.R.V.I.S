"""Event-driven background cognition with conservative resource gating."""
from __future__ import annotations

import logging
import threading
import time
from typing import Any

logger = logging.getLogger("jarvis.background_cognition")


class BackgroundCognition:
    """Observe local health and generate deduplicated executive triggers."""

    def __init__(self, executive: Any, *, interval_seconds: float = 60.0, enabled: bool = True, dream_callback: Any | None = None, dream_interval_seconds: float = 900.0, autopilot_callback: Any | None = None) -> None:
        self.executive = executive
        self.interval_seconds = max(10.0, float(interval_seconds))
        self.enabled = bool(enabled)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_health: dict[str, float] = {}
        self.dream_callback = dream_callback
        self.dream_interval_seconds = max(60.0, float(dream_interval_seconds))
        self._last_dream = 0.0
        self.autopilot_callback = autopilot_callback

    def start(self) -> None:
        """Start the cognition loop once."""
        if not self.enabled or (self._thread and self._thread.is_alive()):
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="jarvis-background-cognition", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        """Stop background cognition."""
        self._stop.set()
        if self._thread:
            self._thread.join(max(0.1, float(timeout)))

    def _trigger_once(self, key: str, goal: str, priority: int, cooldown: float) -> None:
        now = time.monotonic()
        if now - self._last_health.get(key, 0.0) < cooldown:
            return
        self._last_health[key] = now
        self.executive.trigger(goal, priority=priority, cooldown_seconds=cooldown, source="background")

    def _loop(self) -> None:
        while not self._stop.wait(self.interval_seconds):
            try:
                import psutil
                cpu = float(psutil.cpu_percent(interval=0.2))
                memory = float(psutil.virtual_memory().percent)
                disk = float(psutil.disk_usage(psutil.disk_partitions(all=False)[0].mountpoint if psutil.disk_partitions(all=False) else "/").percent)
                if disk >= 95:
                    self._trigger_once("disk-critical", "inspect and remediate critical disk pressure", 95, 900.0)
                    if self.autopilot_callback is not None:
                        self.autopilot_callback("health", "disk-critical", {"disk_percent": disk})
                elif disk >= 90:
                    self._trigger_once("disk-high", "inspect disk pressure and identify safe cleanup candidates", 60, 1800.0)
                if memory >= 95:
                    self._trigger_once("memory-critical", "inspect critical memory pressure and recover nonessential workloads", 95, 600.0)
                    if self.autopilot_callback is not None:
                        self.autopilot_callback("health", "memory-critical", {"memory_percent": memory})
                if cpu >= 98:
                    self._trigger_once("cpu-critical", "inspect sustained CPU pressure and identify runaway work", 90, 600.0)
                    if self.autopilot_callback is not None:
                        self.autopilot_callback("health", "cpu-critical", {"cpu_percent": cpu})
                now = time.time()
                if self.dream_callback is not None and now - self._last_dream >= self.dream_interval_seconds:
                    self._last_dream = now
                    try:
                        self.dream_callback()
                    except Exception as exc:
                        logger.warning("background_dream_cycle_failed", extra={"error": str(exc)})
            except Exception as exc:
                logger.warning("background_cognition_cycle_failed", extra={"error": str(exc)})



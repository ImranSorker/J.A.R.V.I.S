"""P2-E Agent Harness 2.0.

The harness is the execution substrate for agents, skills, tools and workflows.
It consumes P2-A genome identity and P2-U event primitives; it never grants
capabilities.  Access is allowlist-only and authorization must be verified
before an ExecutionContext can be created.

The implementation intentionally refuses to claim isolation guarantees that a
host cannot prove.  Trusted/simulation mode can execute Python callables in the
JARVIS process; restricted mode requires a process-boundary backend; isolated
mode requires an available DSec/OCI backend with filesystem and network
containment guarantees.
"""
from __future__ import annotations

import base64
import fnmatch
import hashlib
import hmac
import importlib
import inspect
import json
import os
import platform
import queue
import random
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
from abc import ABC, abstractmethod
from concurrent.futures import Future
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Mapping, MutableMapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_genome import AgentGenomeRegistry
from core.audit import AuditLog
from core.event_fabric import AuthContext, EventEnvelope, EventLineage, EventBus, ProducedBy
from core.execution_broker import ExecutionBroker
from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

_SCHEMA_DIR = Path(__file__).resolve().parent / "schemas"
_CONTEXT_SCHEMA = _SCHEMA_DIR / "execution_context_v1.schema.json"
_ACCOUNTING_SCHEMA = _SCHEMA_DIR / "execution_accounting_v1.schema.json"

_TRUST_RANK = {"untrusted": 0, "restricted": 1, "standard": 2, "elevated": 3, "system": 4}
_SENSITIVE_KEY_RE = ("secret", "password", "token", "credential", "api_key", "private_key", "authorization")
_PII_EMAIL_MARKER = "@"


class HarnessError(RuntimeError):
    """Base harness error."""


class ContextImmutable(HarnessError, TypeError):
    """Raised when an execution context is mutated or constructed without verification."""


class AuthorizationRequired(HarnessError, PermissionError):
    """Authorization must be verified before execution."""


class ModeNotPermitted(HarnessError, PermissionError):
    """The requested execution mode cannot be admitted by the selected backend."""


class BudgetViolation(HarnessError):
    """A hard resource budget has been exceeded."""

    def __init__(self, metric: str, limit: float, observed: float) -> None:
        self.metric = str(metric)
        self.limit = float(limit)
        self.observed = float(observed)
        super().__init__(f"{self.metric} budget exceeded: observed={self.observed}, limit={self.limit}")


class PolicyDenied(HarnessError, PermissionError):
    """An allowlist/policy boundary denied an action."""


class CheckpointError(HarnessError):
    """Checkpoint creation or restoration failed."""


class RestoreIncompatibleEnvironment(CheckpointError):
    """Checkpoint cannot be restored on the current environment."""


class TraceIntegrityError(HarnessError):
    """Forensic trace chain failed validation."""


class CancellationRequested(HarnessError):
    """Cooperative execution cancellation was requested."""


class TrustLevel(StrEnum):
    UNTRUSTED = "untrusted"
    RESTRICTED = "restricted"
    STANDARD = "standard"
    ELEVATED = "elevated"
    SYSTEM = "system"


class ExecutionMode(StrEnum):
    TRUSTED = "trusted"
    RESTRICTED = "restricted"
    ISOLATED = "isolated"
    SIMULATION = "simulation"


class FilesystemMode(StrEnum):
    READ = "read"
    WRITE = "write"
    READWRITE = "readwrite"


class TimeSource(StrEnum):
    REAL = "real"
    FIXED = "fixed"
    MONOTONIC_OFFSET = "monotonic_offset"


class TraceLevel(StrEnum):
    NONE = "none"
    SUMMARY = "summary"
    FULL = "full"
    FORENSIC = "forensic"


class HandleState(StrEnum):
    PREPARED = "prepared"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass(frozen=True, slots=True)
class ExecutionAuthContext:
    principal: str
    scopes: tuple[str, ...]
    policy_ref: str
    authorization_token: str

    def to_dict(self, *, redact_token: bool = True) -> dict[str, Any]:
        token = "" if redact_token else self.authorization_token
        return {
            "principal": self.principal,
            "scopes": list(self.scopes),
            "policy_ref": self.policy_ref,
            "authorization_token": token,
            "authorization_token_sha256": hashlib.sha256(self.authorization_token.encode()).hexdigest(),
        }


@dataclass(frozen=True, slots=True)
class ExecutionBudgets:
    cpu_seconds: float = 60.0
    wall_seconds: float = 60.0
    ram_mb: int = 1024
    vram_mb: int = 0
    gpu_seconds: float = 0.0
    network_bytes_in: int = 0
    network_bytes_out: int = 0
    disk_bytes_write: int = 0
    subprocess_count: int = 0
    tool_calls: int = 0
    api_calls: int = 0
    concurrency: int = 1
    tokens_in: int = 0
    tokens_out: int = 0

    def validate(self) -> None:
        numeric_nonnegative = {
            "cpu_seconds": self.cpu_seconds,
            "wall_seconds": self.wall_seconds,
            "ram_mb": self.ram_mb,
            "vram_mb": self.vram_mb,
            "gpu_seconds": self.gpu_seconds,
            "network_bytes_in": self.network_bytes_in,
            "network_bytes_out": self.network_bytes_out,
            "disk_bytes_write": self.disk_bytes_write,
            "subprocess_count": self.subprocess_count,
            "tool_calls": self.tool_calls,
            "api_calls": self.api_calls,
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
        }
        for name, value in numeric_nonnegative.items():
            if float(value) < 0:
                raise ValueError(f"budget {name} must be non-negative")
        if self.wall_seconds <= 0 or self.concurrency <= 0:
            raise ValueError("wall_seconds and concurrency must be positive")

    def as_dict(self) -> dict[str, Any]:
        return {
            "cpu_seconds": self.cpu_seconds,
            "wall_seconds": self.wall_seconds,
            "ram_mb": self.ram_mb,
            "vram_mb": self.vram_mb,
            "gpu_seconds": self.gpu_seconds,
            "network_bytes_in": self.network_bytes_in,
            "network_bytes_out": self.network_bytes_out,
            "disk_bytes_write": self.disk_bytes_write,
            "subprocess_count": self.subprocess_count,
            "tool_calls": self.tool_calls,
            "api_calls": self.api_calls,
            "concurrency": self.concurrency,
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
        }


@dataclass(frozen=True, slots=True)
class AllowedSurface:
    filesystem_paths: tuple[str, ...] = ()
    filesystem_mode: FilesystemMode = FilesystemMode.READ
    network_hosts: tuple[str, ...] = ()
    network_ports: tuple[int, ...] = ()
    devices: tuple[str, ...] = ()
    secrets: tuple[str, ...] = ()
    tools: tuple[str, ...] = ()
    models: tuple[str, ...] = ()
    subprocess_allowlist: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "filesystem_paths": list(self.filesystem_paths),
            "filesystem_mode": self.filesystem_mode.value,
            "network_hosts": list(self.network_hosts),
            "network_ports": list(self.network_ports),
            "devices": list(self.devices),
            "secrets": list(self.secrets),
            "tools": list(self.tools),
            "models": list(self.models),
            "subprocess_allowlist": list(self.subprocess_allowlist),
        }


@dataclass(frozen=True, slots=True)
class CheckpointPolicy:
    interval_seconds: float = 0.0
    on_event_types: tuple[str, ...] = ()
    storage_ref: str = "data/checkpoints"

    def __post_init__(self) -> None:
        if self.interval_seconds < 0:
            raise ValueError("checkpoint interval cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "interval_seconds": self.interval_seconds,
            "on_event_types": list(self.on_event_types),
            "storage_ref": self.storage_ref,
        }


@dataclass(frozen=True, slots=True)
class ModePolicy:
    mode: ExecutionMode
    minimum_trust_rank: int
    default_budgets: ExecutionBudgets
    real_event_fabric: bool
    required_guarantees: frozenset[str]


_MODE_POLICIES: Mapping[ExecutionMode, ModePolicy] = MappingProxyType({
    ExecutionMode.TRUSTED: ModePolicy(ExecutionMode.TRUSTED, _TRUST_RANK["system"], ExecutionBudgets(cpu_seconds=900, wall_seconds=900, ram_mb=8192, vram_mb=16_384, gpu_seconds=900, concurrency=1, network_bytes_in=128*1024*1024, network_bytes_out=128*1024*1024, disk_bytes_write=1_000_000_000, subprocess_count=64, tool_calls=10_000, api_calls=10_000, tokens_in=5_000_000, tokens_out=5_000_000), True, frozenset({"shared_runtime"})),
    ExecutionMode.RESTRICTED: ModePolicy(ExecutionMode.RESTRICTED, _TRUST_RANK["elevated"], ExecutionBudgets(cpu_seconds=300, wall_seconds=300, ram_mb=4096, concurrency=1, subprocess_count=16, tool_calls=2_000, api_calls=2_000, tokens_in=2_000_000, tokens_out=2_000_000), True, frozenset({"process_boundary", "fs_confined", "network_policy", "subprocess_control"})),
    ExecutionMode.ISOLATED: ModePolicy(ExecutionMode.ISOLATED, _TRUST_RANK["standard"], ExecutionBudgets(cpu_seconds=120, wall_seconds=120, ram_mb=2048, concurrency=1, subprocess_count=8, tool_calls=500, api_calls=500, tokens_in=1_000_000, tokens_out=1_000_000), True, frozenset({"process_boundary", "fs_confined", "network_denied", "subprocess_control", "device_denied"})),
    ExecutionMode.SIMULATION: ModePolicy(ExecutionMode.SIMULATION, _TRUST_RANK["untrusted"], ExecutionBudgets(cpu_seconds=120, wall_seconds=120, ram_mb=2048, disk_bytes_write=128*1024*1024, concurrency=1, subprocess_count=0, tool_calls=500, api_calls=500, tokens_in=1_000_000, tokens_out=1_000_000), False, frozenset({"simulation_only"})),
})


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): _freeze(v) for k, v in value.items()})
    if isinstance(value, list) or isinstance(value, tuple):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, set) or isinstance(value, frozenset):
        return frozenset(_freeze(v) for v in value)
    return value


def _unfreeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _unfreeze(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [_unfreeze(v) for v in value]
    if isinstance(value, frozenset):
        return sorted(_unfreeze(v) for v in value)
    return value


def _validate_uuid(value: str, field_name: str) -> str:
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, AttributeError, TypeError) as exc:
        raise ValueError(f"{field_name} must be a valid UUID") from exc


def _parse_rfc3339(value: str) -> datetime:
    text = str(value).strip().replace("Z", "+00:00")
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        raise ValueError("fixed_clock must include a timezone")
    return parsed.astimezone(timezone.utc)


def _canonical_hash(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _safe_digest(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


class AuthorizationVerifier(Protocol):
    def verify(self, token: str, capability: str | None = None) -> bool:
        """Verify a previously issued capability token."""


@dataclass(slots=True, init=False)
class ExecutionContext:
    execution_id: str
    correlation_id: str
    causation_id: str | None
    parent_execution_id: str | None
    agent_genome_hash: str
    agent_id: str
    trust_level: str
    execution_mode: ExecutionMode
    auth_context: ExecutionAuthContext
    budgets: ExecutionBudgets
    allowed: AllowedSurface
    deterministic: bool
    random_seed: int | None
    fixed_clock: str | None
    time_source: TimeSource
    checkpoint_policy: CheckpointPolicy
    trace_level: TraceLevel
    telemetry_topic: str
    environment_id: str
    environment_hash: str
    workdir: str
    env_vars: Mapping[str, str]
    certified_snapshot: str | None
    evolution_candidate: str | None
    _runtime: Any = field(default=None, compare=False, repr=False)
    _sealed: bool = field(default=False, compare=False, repr=False)

    def __setattr__(self, name: str, value: Any) -> None:
        if getattr(self, "_sealed", False):
            raise ContextImmutable(f"ExecutionContext is immutable: cannot mutate {name}")
        object.__setattr__(self, name, value)

    def __init__(
        self,
        execution_id: str,
        correlation_id: str,
        causation_id: str | None,
        parent_execution_id: str | None,
        agent_genome_hash: str,
        agent_id: str,
        trust_level: str,
        execution_mode: ExecutionMode,
        auth_context: ExecutionAuthContext,
        budgets: ExecutionBudgets,
        allowed: AllowedSurface,
        deterministic: bool,
        random_seed: int | None,
        fixed_clock: str | None,
        time_source: TimeSource,
        checkpoint_policy: CheckpointPolicy,
        trace_level: TraceLevel,
        telemetry_topic: str,
        environment_id: str,
        environment_hash: str,
        workdir: str,
        env_vars: Mapping[str, str],
        certified_snapshot: str | None,
        evolution_candidate: str | None,
        *,
        _verified: bool = False,
    ) -> None:
        if not _verified:
            raise ContextImmutable("ExecutionContext must be created through ExecutionContext.create after authorization")
        execution_id = _validate_uuid(execution_id, "execution_id")
        correlation_id = _validate_uuid(correlation_id, "correlation_id")
        if causation_id is not None:
            causation_id = _validate_uuid(causation_id, "causation_id")
        if parent_execution_id is not None:
            parent_execution_id = _validate_uuid(parent_execution_id, "parent_execution_id")
        if not agent_genome_hash or len(agent_genome_hash) != 64:
            raise ValueError("agent_genome_hash must be SHA-256")
        trust_level = str(trust_level)
        if trust_level not in _TRUST_RANK:
            raise ValueError("unknown trust level")
        if _TRUST_RANK[trust_level] < _MODE_POLICIES[ExecutionMode(execution_mode)].minimum_trust_rank:
            raise ModeNotPermitted("agent trust level is insufficient for execution mode")
        budgets.validate()
        policy = _MODE_POLICIES[ExecutionMode(execution_mode)]
        for name, requested in budgets.as_dict().items():
            default = policy.default_budgets.as_dict()[name]
            if float(requested) > float(default):
                raise ModeNotPermitted(f"budget {name} exceeds mode upper bound")
        if deterministic and random_seed is None:
            raise ValueError("deterministic execution requires random_seed")
        if fixed_clock is not None:
            _parse_rfc3339(fixed_clock)
        if deterministic and time_source == TimeSource.REAL:
            raise ValueError("deterministic execution cannot use real clock")
        if not auth_context.principal or not auth_context.policy_ref or not auth_context.authorization_token:
            raise AuthorizationRequired("verified auth context is required")
        if not telemetry_topic:
            raise ValueError("telemetry_topic is required")
        if not environment_id or len(environment_hash) != 64:
            raise ValueError("environment identity must be provided")
        workdir = str(Path(workdir).resolve())
        env_vars = {str(k): str(v) for k, v in env_vars.items()}
        bad_env = [key for key in env_vars if key.upper() in {"JARVIS_MASTER_SECRET", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GITHUB_TOKEN"} or key.upper().endswith("_SECRET")]
        if bad_env:
            raise PolicyDenied(f"secret-bearing environment variables are forbidden: {bad_env}")
        if certified_snapshot is not None:
            certified_snapshot = _validate_uuid(certified_snapshot, "certified_snapshot")
        if evolution_candidate is not None:
            evolution_candidate = _validate_uuid(evolution_candidate, "evolution_candidate")
        object.__setattr__(self, "execution_id", execution_id)
        object.__setattr__(self, "correlation_id", correlation_id)
        object.__setattr__(self, "causation_id", causation_id)
        object.__setattr__(self, "parent_execution_id", parent_execution_id)
        object.__setattr__(self, "agent_genome_hash", agent_genome_hash)
        object.__setattr__(self, "agent_id", str(agent_id))
        object.__setattr__(self, "trust_level", trust_level)
        object.__setattr__(self, "execution_mode", ExecutionMode(execution_mode))
        object.__setattr__(self, "auth_context", auth_context)
        object.__setattr__(self, "budgets", budgets)
        object.__setattr__(self, "allowed", allowed)
        object.__setattr__(self, "deterministic", bool(deterministic))
        object.__setattr__(self, "random_seed", int(random_seed) if random_seed is not None else None)
        object.__setattr__(self, "fixed_clock", fixed_clock)
        object.__setattr__(self, "time_source", TimeSource(time_source))
        object.__setattr__(self, "checkpoint_policy", checkpoint_policy)
        object.__setattr__(self, "trace_level", TraceLevel(trace_level))
        object.__setattr__(self, "telemetry_topic", str(telemetry_topic))
        object.__setattr__(self, "environment_id", str(environment_id))
        object.__setattr__(self, "environment_hash", str(environment_hash))
        object.__setattr__(self, "workdir", workdir)
        object.__setattr__(self, "env_vars", MappingProxyType(dict(env_vars)))
        object.__setattr__(self, "certified_snapshot", certified_snapshot)
        object.__setattr__(self, "evolution_candidate", evolution_candidate)
        object.__setattr__(self, "_runtime", None)
        object.__setattr__(self, "_sealed", True)

    @classmethod
    def create(
        cls,
        *,
        authorization_verifier: AuthorizationVerifier,
        execution_id: str | None = None,
        correlation_id: str | None = None,
        causation_id: str | None = None,
        parent_execution_id: str | None = None,
        agent_genome_hash: str,
        agent_id: str,
        trust_level: str,
        execution_mode: ExecutionMode,
        auth_context: ExecutionAuthContext,
        budgets: ExecutionBudgets,
        allowed: AllowedSurface,
        deterministic: bool = False,
        random_seed: int | None = None,
        fixed_clock: str | None = None,
        time_source: TimeSource = TimeSource.REAL,
        checkpoint_policy: CheckpointPolicy | None = None,
        trace_level: TraceLevel = TraceLevel.SUMMARY,
        telemetry_topic: str = "jarvis.internal.telemetry",
        environment_id: str,
        environment_hash: str,
        workdir: str,
        env_vars: Mapping[str, str] | None = None,
        certified_snapshot: str | None = None,
        evolution_candidate: str | None = None,
    ) -> "ExecutionContext":
        verifier = getattr(authorization_verifier, "verify", None)
        if not callable(verifier) or not verifier(auth_context.authorization_token, capability="execution.start"):
            raise AuthorizationRequired("authorization token failed execution.start verification")
        required_event_scopes = {"events.publish.agent.execution", "events.publish.telemetry"}
        if not required_event_scopes.issubset(set(auth_context.scopes)):
            raise AuthorizationRequired("event publication scopes must already be authorized by Security Authority")
        context = cls(
            execution_id=execution_id or str(uuid.uuid4()),
            correlation_id=correlation_id or str(uuid.uuid4()),
            causation_id=causation_id,
            parent_execution_id=parent_execution_id,
            agent_genome_hash=agent_genome_hash,
            agent_id=agent_id,
            trust_level=trust_level,
            execution_mode=execution_mode,
            auth_context=auth_context,
            budgets=budgets,
            allowed=allowed,
            deterministic=deterministic,
            random_seed=random_seed,
            fixed_clock=fixed_clock,
            time_source=time_source,
            checkpoint_policy=checkpoint_policy or CheckpointPolicy(),
            trace_level=trace_level,
            telemetry_topic=telemetry_topic,
            environment_id=environment_id,
            environment_hash=environment_hash,
            workdir=workdir,
            env_vars=env_vars or {},
            certified_snapshot=certified_snapshot,
            evolution_candidate=evolution_candidate,
            _verified=True,
        )
        schema = json.loads(_CONTEXT_SCHEMA.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=64).validate_or_raise(context.to_dict(redact_token=True), schema)
        return context

    @property
    def runtime(self) -> "ExecutionRuntime":
        runtime = self._runtime
        if runtime is None:
            raise RuntimeError("execution runtime is only available after harness.prepare")
        return runtime

    def to_dict(self, *, redact_token: bool = True) -> dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "correlation_id": self.correlation_id,
            "causation_id": self.causation_id,
            "parent_execution_id": self.parent_execution_id,
            "agent_genome_hash": self.agent_genome_hash,
            "agent_id": self.agent_id,
            "trust_level": self.trust_level,
            "execution_mode": self.execution_mode.value,
            "auth_context": self.auth_context.to_dict(redact_token=redact_token),
            "budgets": self.budgets.as_dict(),
            "allowed": self.allowed.to_dict(),
            "deterministic": self.deterministic,
            "random_seed": self.random_seed,
            "fixed_clock": self.fixed_clock,
            "time_source": self.time_source.value,
            "checkpoint_policy": self.checkpoint_policy.to_dict(),
            "trace_level": self.trace_level.value,
            "telemetry_topic": self.telemetry_topic,
            "environment_id": self.environment_id,
            "environment_hash": self.environment_hash,
            "workdir": self.workdir,
            "env_vars": dict(self.env_vars),
            "certified_snapshot": self.certified_snapshot,
            "evolution_candidate": self.evolution_candidate,
        }

    def canonical_hash(self) -> str:
        return _canonical_hash(self.to_dict(redact_token=True))


@dataclass(frozen=True, slots=True)
class BackendGuarantees:
    guarantees: frozenset[str]
    host_platform: str
    backend_id: str
    available: bool
    divergence: tuple[str, ...] = ()

    def supports(self, required: Sequence[str]) -> bool:
        return self.available and set(required).issubset(self.guarantees)


class SandboxBackend(ABC):
    backend_id = "abstract"

    @property
    @abstractmethod
    def guarantees(self) -> BackendGuarantees:
        raise TypeError("SandboxBackend.guarantees is an abstract contract")

    @abstractmethod
    def run_command(self, program: "CommandProgram", context: ExecutionContext, runtime: "ExecutionRuntime") -> "BackendExecutionResult":
        raise TypeError("SandboxBackend.run_command is an abstract contract")


@dataclass(frozen=True, slots=True)
class CommandProgram:
    argv: tuple[str, ...]
    cwd: str | None = None
    env: Mapping[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if not self.argv or any(not isinstance(x, str) or not x for x in self.argv):
            raise ValueError("command argv is empty or malformed")
        if any("\x00" in item for item in self.argv):
            raise ValueError("NUL bytes are not permitted")


@dataclass(frozen=True, slots=True)
class BackendExecutionResult:
    ok: bool
    returncode: int | None
    stdout: str
    stderr: str
    timed_out: bool = False
    killed: bool = False
    pid: int | None = None


class InProcessBackend(SandboxBackend):
    backend_id = "in-process"

    @property
    def guarantees(self) -> BackendGuarantees:
        return BackendGuarantees(frozenset({"shared_runtime", "simulation_only"}), platform.system().lower(), self.backend_id, True, ("No OS-level memory/network/filesystem isolation.",))

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        raise ModeNotPermitted("in-process backend does not execute command programs")


class PortableSubprocessBackend(SandboxBackend):
    backend_id = "portable-subprocess"

    @property
    def guarantees(self) -> BackendGuarantees:
        return BackendGuarantees(
            frozenset({"process_boundary", "subprocess_control"}),
            platform.system().lower(),
            self.backend_id,
            True,
            ("No filesystem confinement or syscall filter; not valid for restricted/isolated production mode.",),
        )

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        raise ModeNotPermitted("portable subprocess backend lacks the guarantees required for P2-E restricted mode")


class DsecContainerBackend(SandboxBackend):
    backend_id = "dsec-container"

    def __init__(self, engine: str | None = None) -> None:
        self.engine = engine or shutil.which("docker") or shutil.which("podman")
        self._broker = ExecutionBroker()

    @property
    def guarantees(self) -> BackendGuarantees:
        available = bool(self.engine)
        return BackendGuarantees(
            frozenset({"process_boundary", "fs_confined", "network_denied", "subprocess_control", "device_denied"}),
            platform.system().lower(),
            self.backend_id,
            available,
            ("Only network-denied isolation is supported; network allowlists require a future policy-proxy adapter.",),
        )

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        if not self.engine:
            raise ModeNotPermitted("no OCI runtime is available for isolated mode")
        if context.allowed.network_hosts or context.allowed.network_ports:
            raise ModeNotPermitted("isolated network allowlists require a policy-proxy backend; network is denied by this adapter")
        image = str(context.env_vars.get("JARVIS_CONTAINER_IMAGE", "")).strip()
        if not image:
            raise ModeNotPermitted("isolated mode requires an explicitly authorized container image")
        workspace = Path(context.workdir).resolve()
        argv = [
            self.engine, "run", "--rm", "--read-only", "--network", "none", "--cap-drop", "ALL",
            "--security-opt", "no-new-privileges", "--pids-limit", str(max(1, context.budgets.subprocess_count or 1)),
            "--memory", f"{max(16, context.budgets.ram_mb)}m", "--cpus", "1", "-v", f"{workspace}:/workspace:rw", image,
            *program.argv,
        ]
        child = self._broker.execute_trusted_argv(
            argv,
            principal=context.auth_context.principal,
            capability="execution.isolated",
            cwd=workspace,
            timeout_seconds=context.budgets.wall_seconds,
            allowed_executables=(Path(self.engine).name,),
            env={},
        )
        return BackendExecutionResult(child.ok, child.returncode, child.stdout, child.stderr, child.killed, child.killed)


class LinuxNativeSandboxBackend(SandboxBackend):
    backend_id = "linux-native"

    @property
    def guarantees(self) -> BackendGuarantees:
        is_linux = platform.system().lower() == "linux"
        cgroup = Path("/sys/fs/cgroup/cgroup.controllers").is_file()
        user_ns = Path("/proc/self/ns/user").exists()
        landlock = False
        try:
            release = tuple(int(x) for x in platform.release().split(".")[:2] if x.isdigit())
            landlock = release >= (5, 13)
        except (TypeError, ValueError, OverflowError):
            landlock = False
        available = is_linux and cgroup and user_ns and landlock and os.environ.get("JARVIS_ENABLE_NATIVE_SANDBOX") == "1"
        return BackendGuarantees(
            frozenset({"process_boundary", "fs_confined", "network_denied", "subprocess_control", "device_denied", "syscall_filter"}),
            "linux",
            self.backend_id,
            available,
            ("Native namespace/cgroup/seccomp/landlock executor is opt-in and refuses startup until explicit host enablement.",),
        )

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        raise ModeNotPermitted("Linux native executor is declaration-only until explicitly enabled and wired to the host policy")


class WindowsNativeSandboxBackend(SandboxBackend):
    backend_id = "windows-native"

    @property
    def guarantees(self) -> BackendGuarantees:
        return BackendGuarantees(frozenset(), "windows", self.backend_id, False, ("Job Object/AppContainer/WDAC integration is not available in this runtime.",))

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        raise ModeNotPermitted("Windows native sandbox backend unavailable")


class MacOSSandboxBackend(SandboxBackend):
    backend_id = "macos-native"

    @property
    def guarantees(self) -> BackendGuarantees:
        return BackendGuarantees(frozenset(), "macos", self.backend_id, False, ("sandbox_init/rlimit integration is not available in this runtime.",))

    def run_command(self, program: CommandProgram, context: ExecutionContext, runtime: "ExecutionRuntime") -> BackendExecutionResult:
        raise ModeNotPermitted("macOS native sandbox backend unavailable")


class SimulationBackend(InProcessBackend):
    backend_id = "simulation"

    @property
    def guarantees(self) -> BackendGuarantees:
        return BackendGuarantees(frozenset({"shared_runtime", "simulation_only", "network_denied", "device_denied", "secret_broker_only"}), platform.system().lower(), self.backend_id, True)


class Checkpointable(Protocol):
    def checkpoint_state(self) -> Mapping[str, Any]:
        ...

    def restore_state(self, state: Mapping[str, Any]) -> None:
        ...


class EntryPoint(Protocol):
    def __call__(self, context: ExecutionContext) -> Any:
        ...


@dataclass(frozen=True, slots=True)
class ViolationRecord:
    metric: str
    limit: float
    observed: float
    at_monotonic: float
    code: str

    def to_dict(self) -> dict[str, Any]:
        return {"metric": self.metric, "limit": self.limit, "observed": self.observed, "at_monotonic": self.at_monotonic, "code": self.code}


@dataclass(frozen=True, slots=True)
class ExecutionAccounting:
    execution_id: str
    agent_genome_hash: str
    wall_seconds: float
    cpu_seconds: float
    ram_peak_mb: int
    vram_peak_mb: int
    gpu_seconds: float
    network_bytes_in: int
    network_bytes_out: int
    disk_bytes_written: int
    subprocess_count: int
    tool_calls: int
    api_calls: int
    tokens_in: int
    tokens_out: int
    energy_joules_estimate: float | None
    cost_units: float
    budget_utilization: Mapping[str, float]
    violations: tuple[ViolationRecord, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "agent_genome_hash": self.agent_genome_hash,
            "wall_seconds": self.wall_seconds,
            "cpu_seconds": self.cpu_seconds,
            "ram_peak_mb": self.ram_peak_mb,
            "vram_peak_mb": self.vram_peak_mb,
            "gpu_seconds": self.gpu_seconds,
            "network_bytes_in": self.network_bytes_in,
            "network_bytes_out": self.network_bytes_out,
            "disk_bytes_written": self.disk_bytes_written,
            "subprocess_count": self.subprocess_count,
            "tool_calls": self.tool_calls,
            "api_calls": self.api_calls,
            "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out,
            "energy_joules_estimate": self.energy_joules_estimate,
            "cost_units": self.cost_units,
            "budget_utilization": dict(self.budget_utilization),
            "violations": [v.to_dict() for v in self.violations],
        }


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    execution_id: str
    ok: bool
    value: Any = None
    error: str | None = None
    accounting: ExecutionAccounting | None = None
    state: str = HandleState.COMPLETED.value
    cancelled: bool = False


class DeterministicRandom:
    def __init__(self, seed: int) -> None:
        self._rng = random.Random(int(seed))
        self._seed = int(seed)

    @property
    def seed(self) -> int:
        return self._seed

    def random(self) -> float:
        return self._rng.random()

    def randint(self, a: int, b: int) -> int:
        return self._rng.randint(a, b)

    def randbytes(self, n: int) -> bytes:
        return self._rng.randbytes(n)

    def choice(self, values: Sequence[Any]) -> Any:
        return self._rng.choice(list(values))

    def uuid5(self, namespace: uuid.UUID, name: str) -> uuid.UUID:
        return uuid.uuid5(namespace, name)


class DeterministicUUID:
    def __init__(self, execution_id: str) -> None:
        self._namespace = uuid.uuid5(uuid.NAMESPACE_URL, str(execution_id))
        self._counter = 0
        self._lock = threading.Lock()

    def next(self) -> str:
        with self._lock:
            self._counter += 1
            return str(uuid.uuid5(self._namespace, str(self._counter)))


class Clock:
    def __init__(self, *, source: TimeSource, fixed_clock: str | None = None) -> None:
        self.source = TimeSource(source)
        self._fixed = _parse_rfc3339(fixed_clock) if fixed_clock else None
        self._base_monotonic = time.monotonic()
        self._base_wall = self._fixed.timestamp() if self._fixed else time.time()

    def now(self) -> datetime:
        if self.source == TimeSource.FIXED:
            return self._fixed or datetime.fromtimestamp(self._base_wall, timezone.utc)
        return datetime.fromtimestamp(self.time(), timezone.utc)

    def time(self) -> float:
        if self.source == TimeSource.FIXED:
            return self._base_wall
        return self._base_wall + (time.monotonic() - self._base_monotonic)

    def monotonic(self) -> float:
        return time.monotonic() - self._base_monotonic


class SecretBroker:
    """Short-lived secret handles. Values are never persisted or placed in env/argv."""

    def __init__(self, resolver: Callable[[str], str], audit: Callable[[str, Mapping[str, Any]], None] | None = None) -> None:
        self._resolver = resolver
        self._audit = audit
        self._handles: dict[str, tuple[str, float]] = {}
        self._lock = threading.RLock()

    def issue(self, secret_ref: str, *, allowed_refs: Sequence[str], ttl_seconds: float = 30.0) -> str:
        if secret_ref not in set(allowed_refs):
            raise PolicyDenied("secret reference is not allowlisted")
        if ttl_seconds <= 0 or ttl_seconds > 300:
            raise ValueError("secret handle TTL outside policy")
        handle = "sh_" + secrets.token_urlsafe(24)
        with self._lock:
            self._handles[handle] = (secret_ref, time.monotonic() + float(ttl_seconds))
        if self._audit:
            self._audit("execution.secret.handle_issued", {"secret_ref": secret_ref, "handle_sha256": _safe_digest(handle)})
        return handle

    def exchange(self, handle: str) -> str:
        with self._lock:
            record = self._handles.pop(handle, None)
        if record is None:
            raise PolicyDenied("secret handle invalid or already consumed")
        secret_ref, expires = record
        if time.monotonic() > expires:
            raise PolicyDenied("secret handle expired")
        value = self._resolver(secret_ref)
        if not isinstance(value, str):
            raise PolicyDenied("secret broker returned invalid secret value")
        if self._audit:
            self._audit("execution.secret.handle_exchanged", {"secret_ref": secret_ref, "handle_sha256": _safe_digest(handle), "value_redacted": True})
        return value


class TraceLedger:
    """Hash-chained, Ed25519-signed per-execution forensic trace ledger."""

    def __init__(self, root: str | Path, signing_key: Ed25519PrivateKey) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._signing_key = signing_key
        self._lock = threading.RLock()
        self._last: dict[str, str] = {}

    @property
    def public_key(self) -> bytes:
        return self._signing_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    def append(self, execution_id: str, payload: Mapping[str, Any], *, secret_values: Sequence[str] = ()) -> dict[str, Any]:
        safe_payload = _redact_values(_redact(payload), secret_values)
        with self._lock:
            previous = self._last.get(execution_id, "0" * 64)
            record = {"execution_id": execution_id, "record": safe_payload, "previous_hash": previous}
            digest = hashlib.sha256(canonical_bytes(record)).hexdigest()
            signature = base64.b64encode(self._signing_key.sign(canonical_bytes({"digest": digest, "record": record}))).decode("ascii")
            rendered = {**record, "hash": digest, "signature": signature}
            path = self.root / f"{execution_id}.jsonl"
            with path.open("a", encoding="utf-8") as handle:
                handle.write(canonical_json(rendered).decode("utf-8") + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            self._last[execution_id] = digest
            return rendered

    def verify(self, execution_id: str) -> bool:
        path = self.root / f"{execution_id}.jsonl"
        if not path.exists():
            return True
        previous = "0" * 64
        public = Ed25519PublicKey.from_public_bytes(self.public_key)
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                row = json.loads(line)
                record = {"execution_id": row["execution_id"], "record": row["record"], "previous_hash": row["previous_hash"]}
                if row["previous_hash"] != previous:
                    raise TraceIntegrityError("forensic trace chain break")
                digest = hashlib.sha256(canonical_bytes(record)).hexdigest()
                if not hmac.compare_digest(digest, row["hash"]):
                    raise TraceIntegrityError("forensic trace hash mismatch")
                try:
                    public.verify(base64.b64decode(row["signature"].encode("ascii")), canonical_bytes({"digest": digest, "record": record}))
                except (InvalidSignature, ValueError) as exc:
                    raise TraceIntegrityError("forensic trace signature mismatch") from exc
                previous = digest
        return True


class CheckpointStore:
    """HMAC-protected checkpoint store using the P2-A registry pattern."""

    def __init__(self, root: str | Path, storage_secret: bytes) -> None:
        if len(storage_secret) < 32:
            raise ValueError("checkpoint storage secret must be at least 32 bytes")
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._key = bytes(storage_secret)
        self._lock = threading.RLock()

    def _tag(self, payload: bytes) -> str:
        return hmac.new(self._key, payload, hashlib.sha256).hexdigest()

    def save(self, *, execution_id: str, context: ExecutionContext, state: Mapping[str, Any], accounting: Mapping[str, Any], implementation_ref: str | None) -> str:
        checkpoint_id = str(uuid.uuid4())
        document = {
            "checkpoint_id": checkpoint_id,
            "execution_id": execution_id,
            "context": context.to_dict(redact_token=True),
            "state": _redact(state),
            "accounting": dict(accounting),
            "implementation_ref": implementation_ref,
            "created_at": time.time(),
        }
        raw = canonical_json(document)
        record = {"document": document, "hmac": self._tag(raw)}
        target = self.root / f"{checkpoint_id}.json"
        tmp = target.with_suffix(".tmp")
        with self._lock, tmp.open("w", encoding="utf-8") as handle:
            json.dump(record, handle, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, target)
        return checkpoint_id

    def load(self, checkpoint_id: str) -> dict[str, Any]:
        target = self.root / f"{checkpoint_id}.json"
        if not target.is_file():
            raise CheckpointError("checkpoint not found")
        record = json.loads(target.read_text(encoding="utf-8"))
        document = record.get("document")
        raw = canonical_json(document)
        expected = self._tag(raw)
        if not hmac.compare_digest(expected, str(record.get("hmac", ""))):
            raise CheckpointError("checkpoint HMAC verification failed")
        return document


def _redact_values(value: Any, secret_values: Sequence[str]) -> Any:
    secrets_set = {str(item) for item in secret_values if item}
    if isinstance(value, Mapping):
        return {str(k): _redact_values(v, secrets_set) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_redact_values(item, secrets_set) for item in value]
    if isinstance(value, str):
        for secret in secrets_set:
            if secret in value:
                value = value.replace(secret, "[REDACTED_SECRET]")
    return value


def _redact(value: Any) -> Any:
    if isinstance(value, Mapping):
        rendered: dict[str, Any] = {}
        for key, item in value.items():
            key_text = str(key).lower()
            if any(marker in key_text for marker in _SENSITIVE_KEY_RE):
                rendered[str(key)] = "[REDACTED]"
            else:
                rendered[str(key)] = _redact(item)
        return rendered
    if isinstance(value, (list, tuple)):
        return [_redact(item) for item in value]
    if isinstance(value, str) and _PII_EMAIL_MARKER in value and " " not in value:
        local, _, domain = value.partition("@")
        if local and "." in domain:
            return "[REDACTED_EMAIL]"
    return value


class ExecutionRuntime:
    def __init__(self, context: ExecutionContext, *, harness: "AgentHarness") -> None:
        self.context = context
        self.harness = harness
        self.clock = Clock(source=context.time_source, fixed_clock=context.fixed_clock)
        self.random = DeterministicRandom(context.random_seed or 0)
        self.uuids = DeterministicUUID(context.execution_id)
        self.cancel_event = threading.Event()
        self.pause_event = threading.Event()
        self.started = time.monotonic()
        self.cpu_started = time.thread_time()
        self._lock = threading.RLock()
        self._counters: dict[str, float] = {name: 0.0 for name in context.budgets.as_dict() if name != "concurrency"}
        self._counters["concurrency"] = 0.0
        self._ram_peak = 0
        self._vram_peak = 0
        self._violations: list[ViolationRecord] = []
        self._last_progress = 0.0
        self._last_telemetry = time.monotonic()
        self._event_ids: list[str] = []
        self._closed = False
        self._secret_broker: SecretBroker | None = None
        self._secret_values: set[str] = set()

    def attach_secret_broker(self, broker: SecretBroker) -> None:
        self._secret_broker = broker

    @property
    def violations(self) -> tuple[ViolationRecord, ...]:
        with self._lock:
            return tuple(self._violations)

    def _limit(self, metric: str) -> float:
        return float(self.context.budgets.as_dict()[metric])

    def charge(self, metric: str, amount: float = 1.0) -> None:
        metric = str(metric)
        with self._lock:
            new_value = self._counters.get(metric, 0.0) + float(amount)
            self._counters[metric] = new_value
            if metric == "concurrency":
                if new_value > self._limit(metric):
                    raise self._violate(metric, new_value)
                return
            limit = self._limit(metric)
            if metric in {"network_bytes_in", "network_bytes_out", "disk_bytes_write", "subprocess_count", "tool_calls", "api_calls", "tokens_in", "tokens_out", "cpu_seconds", "gpu_seconds", "vram_mb"} and new_value > limit:
                raise self._violate(metric, new_value)

    def record_cpu(self) -> float:
        observed = max(0.0, time.thread_time() - self.cpu_started)
        with self._lock:
            self._counters["cpu_seconds"] = observed
        if observed > self._limit("cpu_seconds"):
            raise self._violate("cpu_seconds", observed)
        return observed

    def record_wall(self) -> float:
        observed = max(0.0, time.monotonic() - self.started)
        if observed > self._limit("wall_seconds"):
            raise self._violate("wall_seconds", observed)
        return observed

    def record_ram(self) -> int:
        try:
            import psutil
            observed = int(psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024))
        except Exception:
            observed = 0
        with self._lock:
            self._ram_peak = max(self._ram_peak, observed)
        if observed > self.context.budgets.ram_mb:
            raise self._violate("ram_mb", observed)
        return observed

    def record_vram(self, current_mb: int) -> int:
        with self._lock:
            self._vram_peak = max(self._vram_peak, int(current_mb))
        if self._vram_peak > self.context.budgets.vram_mb:
            raise self._violate("vram_mb", self._vram_peak)
        return self._vram_peak

    def record_gpu(self, seconds: float) -> None:
        self.charge("gpu_seconds", seconds)

    def network_in(self, amount: int) -> None:
        if self.context.deterministic or self.context.execution_mode == ExecutionMode.SIMULATION:
            raise PolicyDenied("real network I/O is forbidden in deterministic/simulation execution")
        self.charge("network_bytes_in", amount)

    def network_out(self, amount: int) -> None:
        if self.context.deterministic or self.context.execution_mode == ExecutionMode.SIMULATION:
            raise PolicyDenied("real network I/O is forbidden in deterministic/simulation execution")
        self.charge("network_bytes_out", amount)

    def assert_host_allowed(self, host: str, port: int) -> None:
        host = str(host).lower().rstrip(".")
        if int(port) not in set(self.context.allowed.network_ports):
            raise PolicyDenied("network port is not allowlisted")
        matched = False
        for pattern in self.context.allowed.network_hosts:
            p = pattern.lower().rstrip(".")
            if p.startswith("*."):
                suffix = p[2:]
                if host.endswith("." + suffix) and host != suffix:
                    matched = True
                    break
            elif host == p:
                matched = True
                break
        if not matched:
            raise PolicyDenied("network host is not allowlisted")

    def resolve_path(self, relative_path: str, *, write: bool = False) -> Path:
        if os.path.isabs(relative_path):
            raise PolicyDenied("absolute paths are not permitted through the harness filesystem gateway")
        if "\x00" in relative_path:
            raise PolicyDenied("NUL byte in filesystem path")
        candidate = (Path(self.context.workdir) / relative_path).resolve()
        root = Path(self.context.workdir).resolve()
        if candidate != root and not str(candidate).startswith(str(root) + os.sep):
            raise PolicyDenied("filesystem path escapes execution root")
        parts = Path(relative_path).parts
        if ".." in parts:
            raise PolicyDenied("parent traversal is not permitted")
        for pattern in self.context.allowed.filesystem_paths:
            if fnmatch.fnmatchcase(candidate.relative_to(root).as_posix(), pattern):
                mode = self.context.allowed.filesystem_mode
                if write and mode not in {FilesystemMode.WRITE, FilesystemMode.READWRITE}:
                    raise PolicyDenied("filesystem write is not authorized")
                if not write and mode not in {FilesystemMode.READ, FilesystemMode.WRITE, FilesystemMode.READWRITE}:
                    raise PolicyDenied("filesystem read is not authorized")
                # Existing symlinks must not be followed out of the root.
                cursor = root
                for part in Path(relative_path).parts[:-1]:
                    cursor = cursor / part
                    if cursor.is_symlink() and not str(cursor.resolve()).startswith(str(root) + os.sep):
                        raise PolicyDenied("filesystem symlink escape")
                return candidate
        raise PolicyDenied("filesystem path is not allowlisted")

    def open_file(self, relative_path: str, mode: str = "r", **kwargs: Any) -> Any:
        write = any(flag in mode for flag in ("w", "a", "+", "x"))
        path = self.resolve_path(relative_path, write=write)
        return path.open(mode, **kwargs)

    def record_disk_write(self, amount: int) -> None:
        self.charge("disk_bytes_write", amount)

    def spawn_subprocess(self, argv: Sequence[str], *, env: Mapping[str, str] | None = None) -> subprocess.Popen[str]:
        if self.context.budgets.subprocess_count <= 0:
            raise PolicyDenied("subprocess execution is not authorized")
        self.charge("subprocess_count", 1)
        if not argv:
            raise PolicyDenied("subprocess argv cannot be empty")
        executable = Path(str(argv[0])).name
        if not any(fnmatch.fnmatchcase(executable, pattern) for pattern in self.context.allowed.subprocess_allowlist):
            raise PolicyDenied("subprocess executable is not allowlisted")
        cwd = Path(self.context.workdir).resolve()
        sanitized = {str(k): str(v) for k, v in (env or self.context.env_vars).items() if not str(k).upper().endswith(("SECRET", "TOKEN", "PASSWORD", "KEY"))}
        broker = ExecutionBroker()
        return broker.start_trusted_argv(list(argv), principal=self.context.auth_context.principal, capability="execution.subprocess", cwd=cwd, allowed_executables=tuple(self.context.allowed.subprocess_allowlist), env=sanitized)

    def acquire_concurrency(self, slots: int = 1) -> None:
        self.charge("concurrency", slots)

    def release_concurrency(self, slots: int = 1) -> None:
        with self._lock:
            self._counters["concurrency"] = max(0.0, self._counters.get("concurrency", 0.0) - float(slots))

    def network_request(self, host: str, port: int, *, request: Callable[[], Any]) -> Any:
        self.assert_host_allowed(host, port)
        if self.context.deterministic or self.context.execution_mode == ExecutionMode.SIMULATION:
            raise PolicyDenied("real network I/O is forbidden in deterministic/simulation execution")
        if self.harness.network_gateway is None:
            raise PolicyDenied("no network policy-proxy gateway is configured")
        value = self.harness.network_gateway.request(host, port, request)
        return value

    def tool_call(self, tool_id_version: str, *, call: Callable[..., Any], **kwargs: Any) -> Any:
        if tool_id_version not in set(self.context.allowed.tools):
            raise PolicyDenied("tool is not allowlisted")
        self.charge("tool_calls", 1)
        return call(**kwargs)

    def api_call(self, api_id: str, *, call: Callable[..., Any], **kwargs: Any) -> Any:
        self.charge("api_calls", 1)
        return call(**kwargs)

    def model_tokens(self, tokens_in: int, tokens_out: int = 0) -> None:
        self.charge("tokens_in", tokens_in)
        self.charge("tokens_out", tokens_out)

    def secret_handle(self, secret_ref: str) -> str:
        if self._secret_broker is None:
            raise PolicyDenied("secret broker is not configured")
        return self._secret_broker.issue(secret_ref, allowed_refs=self.context.allowed.secrets)

    def exchange_secret(self, handle: str) -> str:
        if self._secret_broker is None:
            raise PolicyDenied("secret broker is not configured")
        value = self._secret_broker.exchange(handle)
        self._secret_values.add(value)
        return value

    def checkpoint_reference(self, memory_ref: str) -> str:
        if not memory_ref:
            raise ValueError("memory_ref is required")
        return _safe_digest(memory_ref)

    def pause_point(self) -> None:
        if self.cancel_event.is_set():
            raise CancellationRequested("execution cancellation requested")
        while self.pause_event.is_set():
            if self.cancel_event.is_set():
                raise CancellationRequested("execution cancellation requested while paused")
            time.sleep(0.01)

    def progress(self, payload: Mapping[str, Any]) -> None:
        now = time.monotonic()
        if now - self._last_progress < 1.0:
            return
        self._last_progress = now
        self.harness._publish_execution_event(self, "Progressed", _redact(dict(payload)))

    def sample(self) -> None:
        self.record_cpu(); self.record_wall(); self.record_ram(); self.pause_point()
        now = time.monotonic()
        if self.context.trace_level in {TraceLevel.FULL, TraceLevel.FORENSIC} and now - self._last_telemetry >= 1.0:
            self._last_telemetry = now
            self.harness._publish_telemetry(self, "Metric", {"metric": "execution.resource", **self.snapshot_counters()})

    def snapshot_counters(self) -> dict[str, Any]:
        with self._lock:
            result = dict(self._counters)
            result["ram_peak_mb"] = self._ram_peak
            result["vram_peak_mb"] = self._vram_peak
            return result

    def _violate(self, metric: str, observed: float) -> BudgetViolation:
        limit = self._limit(metric)
        code = "Execution." + "".join(part.title() for part in metric.split("_")) + "Exceeded"
        violation = ViolationRecord(metric, limit, observed, time.monotonic(), code)
        self._violations.append(violation)
        self.cancel_event.set()
        return BudgetViolation(metric, limit, observed)


class ExecutionHandle:
    def __init__(self, context: ExecutionContext, implementation: Any, runtime: ExecutionRuntime, backend: SandboxBackend, harness: "AgentHarness") -> None:
        self.context = context
        self.implementation = implementation
        self.runtime = runtime
        self.backend = backend
        self.harness = harness
        self.execution_id = context.execution_id
        self.state = HandleState.PREPARED
        self.result: ExecutionResult | None = None
        self._thread: threading.Thread | None = None
        self._done = threading.Event()
        self._paused_before_start = False
        self._process: subprocess.Popen[str] | None = None
        self._last_event_id: str | None = None
        self._lock = threading.RLock()

    @property
    def last_event_id(self) -> str | None:
        return self._last_event_id

    def _set_state(self, state: HandleState) -> None:
        with self._lock:
            self.state = state


class AgentHarness:
    """Unified lifecycle manager for execution contexts and resources."""

    def __init__(
        self,
        *,
        event_bus: EventBus,
        authorization_verifier: AuthorizationVerifier,
        audit_log: AuditLog | None = None,
        harness_signing_key: Ed25519PrivateKey | None = None,
        checkpoint_secret: bytes | None = None,
        checkpoint_root: str | Path = "data/checkpoints",
        trace_root: str | Path = "data/execution_traces",
        genome_registry: AgentGenomeRegistry | None = None,
        network_gateway: Any | None = None,
        secret_resolver: Callable[[str], str] | None = None,
        max_workdir: str | Path | None = None,
    ) -> None:
        self.event_bus = event_bus
        self.authorization_verifier = authorization_verifier
        self.audit = audit_log
        self.signing_key = harness_signing_key or Ed25519PrivateKey.generate()
        if checkpoint_secret is None:
            raise ValueError("P2-E requires an explicit checkpoint storage secret")
        self.checkpoints = CheckpointStore(checkpoint_root, checkpoint_secret)
        self.traces = TraceLedger(trace_root, self.signing_key)
        self.genome_registry = genome_registry
        self.network_gateway = network_gateway
        self._handles: dict[str, ExecutionHandle] = {}
        self._lock = threading.RLock()
        self._closed = False
        self.max_workdir = Path(max_workdir).resolve() if max_workdir else None
        self.secret_resolver = secret_resolver or (lambda ref: (_ for _ in ()).throw(PolicyDenied(f"no secret resolver configured for {ref}")))
        self.secret_broker_factory = lambda runtime: SecretBroker(self.secret_resolver, self._audit)
        self.backends: dict[ExecutionMode, SandboxBackend] = {
            ExecutionMode.TRUSTED: InProcessBackend(),
            ExecutionMode.RESTRICTED: PortableSubprocessBackend(),
            ExecutionMode.ISOLATED: DsecContainerBackend(),
            ExecutionMode.SIMULATION: SimulationBackend(),
        }
        self.platform_backends = {"linux": LinuxNativeSandboxBackend(), "windows": WindowsNativeSandboxBackend(), "darwin": MacOSSandboxBackend()}
        self._validate_backend_inventory()

    @property
    def public_key(self) -> bytes:
        return self.signing_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @property
    def public_key_fingerprint(self) -> str:
        return hashlib.sha256(self.public_key).hexdigest()

    def _validate_backend_inventory(self) -> None:
        for mode in (ExecutionMode.TRUSTED, ExecutionMode.SIMULATION, ExecutionMode.RESTRICTED, ExecutionMode.ISOLATED):
            if mode not in self.backends:
                raise ModeNotPermitted(f"missing backend for {mode.value}")

    def mode_matrix(self) -> dict[str, Any]:
        return {
            mode.value: {
                "minimum_trust_rank": policy.minimum_trust_rank,
                "default_budgets": policy.default_budgets.as_dict(),
                "required_guarantees": sorted(policy.required_guarantees),
                "backend": self.backends[mode].guarantees.backend_id,
                "available": self.backends[mode].guarantees.available,
                "guarantees": sorted(self.backends[mode].guarantees.guarantees),
                "divergence": list(self.backends[mode].guarantees.divergence),
            }
            for mode, policy in _MODE_POLICIES.items()
        }

    def prepare(self, context: ExecutionContext, implementation: EntryPoint | CommandProgram) -> ExecutionHandle:
        if self._closed:
            raise HarnessError("harness is closed")
        # The authorization token was already verified by ExecutionContext.create.
        # P2-A PermissionEngine tokens are intentionally single-use, so consuming
        # the same token twice would turn valid authorization into a false denial.
        if self.max_workdir and not self._path_under(Path(context.workdir), self.max_workdir):
            raise PolicyDenied("execution workdir is outside harness upper bound")
        backend = self.backends[context.execution_mode]
        policy = _MODE_POLICIES[context.execution_mode]
        if not backend.guarantees.supports(sorted(policy.required_guarantees)):
            raise ModeNotPermitted(f"backend {backend.backend_id} cannot satisfy {context.execution_mode.value} guarantees")
        if context.execution_mode == ExecutionMode.SIMULATION:
            if bool(getattr(self.event_bus, "simulation_only", False)) is not True:
                raise ModeNotPermitted("simulation mode requires a simulation-only event bus boundary")
        if self.genome_registry is not None:
            genome = self.genome_registry.current(context.agent_id)
            if genome is None:
                raise AuthorizationRequired(f"no authenticated genome registered for agent {context.agent_id}")
            if genome.hash() != context.agent_genome_hash:
                raise AuthorizationRequired("execution genome hash does not match the authenticated registry genome")
        self._verify_context_allowlists(context)
        runtime = ExecutionRuntime(context, harness=self)
        runtime.attach_secret_broker(self.secret_broker_factory(runtime))
        object.__setattr__(context, "_runtime", runtime)
        handle = ExecutionHandle(context, implementation, runtime, backend, self)
        with self._lock:
            existing = self._handles.get(context.execution_id)
            if existing is not None and existing.state not in {HandleState.COMPLETED, HandleState.FAILED, HandleState.CANCELLED}:
                raise HarnessError("execution_id already has an active execution")
            self._handles[context.execution_id] = handle
        self._audit("execution.prepare", {"execution_id": context.execution_id, "agent_id": context.agent_id, "mode": context.execution_mode.value, "trust_level": context.trust_level})
        return handle

    def _verify_context_allowlists(self, context: ExecutionContext) -> None:
        if context.execution_mode == ExecutionMode.SIMULATION:
            if context.allowed.network_hosts or context.allowed.network_ports or context.allowed.devices or context.allowed.subprocess_allowlist:
                raise ModeNotPermitted("simulation mode cannot be given real network/device/subprocess authority")
            return
        if context.allowed.filesystem_paths and Path(context.workdir).resolve() != Path(context.workdir).resolve():
            raise PolicyDenied("workdir resolution failed")
        if any(pattern.strip() == "*" for pattern in context.allowed.network_hosts):
            raise PolicyDenied("network wildcard must be exact-host or *.example.com")

    def start(self, handle: ExecutionHandle) -> ExecutionHandle:
        with handle._lock:
            if handle.state != HandleState.PREPARED:
                raise HarnessError(f"cannot start from state {handle.state.value}")
            handle._set_state(HandleState.RUNNING)
        try:
            handle._last_event_id = self._publish_execution_event(handle.runtime, "Started", self._start_payload(handle))
        except Exception:
            handle._set_state(HandleState.FAILED)
            handle._done.set()
            self._audit("execution.start.denied", {"execution_id": handle.execution_id})
            raise
        self._trace(handle, {"kind": "lifecycle", "state": "started"})
        self._audit("execution.start", {"execution_id": handle.execution_id})
        if isinstance(handle.implementation, CommandProgram):
            handle._thread = threading.Thread(target=self._run_command_handle, args=(handle,), name=f"jarvis-exec-{handle.execution_id[:8]}", daemon=True)
        else:
            handle._thread = threading.Thread(target=self._run_callable_handle, args=(handle,), name=f"jarvis-agent-{handle.execution_id[:8]}", daemon=True)
        handle._thread.start()
        return handle

    def pause(self, handle: ExecutionHandle) -> None:
        with handle._lock:
            if handle.state != HandleState.RUNNING:
                raise HarnessError("pause requires running execution")
            handle.runtime.pause_event.set()
            handle._set_state(HandleState.PAUSED)
        self._audit("execution.pause", {"execution_id": handle.execution_id})

    def resume(self, handle: ExecutionHandle) -> None:
        with handle._lock:
            if handle.state != HandleState.PAUSED:
                raise HarnessError("resume requires paused execution")
            handle.runtime.pause_event.clear()
            handle._set_state(HandleState.RUNNING)
        self._audit("execution.resume", {"execution_id": handle.execution_id})

    def checkpoint(self, handle: ExecutionHandle) -> str:
        if not (hasattr(handle.implementation, "checkpoint_state") and callable(handle.implementation.checkpoint_state)):
            raise CheckpointError("execution implementation does not implement Checkpointable")
        state = dict(handle.implementation.checkpoint_state())
        implementation_ref = _implementation_ref(handle.implementation)
        checkpoint_id = self.checkpoints.save(execution_id=handle.execution_id, context=handle.context, state=state, accounting=self._build_accounting(handle).to_dict(), implementation_ref=implementation_ref)
        self._audit("execution.checkpoint", {"execution_id": handle.execution_id, "checkpoint_id": checkpoint_id})
        self._trace(handle, {"kind": "checkpoint", "checkpoint_id": checkpoint_id})
        return checkpoint_id

    def restore(self, checkpoint_id: str, *, context: ExecutionContext, implementation: EntryPoint) -> ExecutionHandle:
        document = self.checkpoints.load(checkpoint_id)
        if document["context"]["environment_hash"] != context.environment_hash:
            raise RestoreIncompatibleEnvironment("checkpoint environment hash does not match current environment")
        if context.execution_id != document["execution_id"]:
            raise RestoreIncompatibleEnvironment("checkpoint belongs to a different execution identity")
        if not hasattr(implementation, "restore_state") or not callable(implementation.restore_state):
            raise CheckpointError("implementation does not implement restore_state")
        implementation.restore_state(document["state"])
        return self.start(self.prepare(context, implementation))

    def restore_prepared(self, context: ExecutionContext, implementation: EntryPoint, checkpoint_id: str) -> ExecutionHandle:
        return self.restore(checkpoint_id, context=context, implementation=implementation)

    def cancel(self, handle: ExecutionHandle, reason: str, graceful_timeout: float = 2.0) -> ExecutionHandle:
        with handle._lock:
            if handle.state not in {HandleState.RUNNING, HandleState.PAUSED}:
                raise HarnessError("cancel requires an active execution")
            handle.runtime.cancel_event.set()
            handle.runtime.pause_event.clear()
        self._audit("execution.cancel", {"execution_id": handle.execution_id, "reason": reason})
        if handle._process is not None and handle._process.poll() is None:
            try:
                handle._process.terminate()
                handle._process.wait(timeout=max(0.0, graceful_timeout))
            except subprocess.TimeoutExpired:
                handle._process.kill()
        if handle._thread is not None:
            handle._thread.join(timeout=max(0.0, graceful_timeout))
        if handle.state not in {HandleState.COMPLETED, HandleState.FAILED}:
            handle._set_state(HandleState.CANCELLED)
            handle._last_event_id = self._publish_execution_event(handle.runtime, "Cancelled", {"reason": str(reason)})
            self._trace(handle, {"kind": "lifecycle", "state": "cancelled", "reason": reason})
        return handle

    def wait(self, handle: ExecutionHandle, timeout: float | None = None) -> ExecutionResult | None:
        done = handle._done.wait(timeout)
        if not done:
            return None
        return handle.result

    def close(self) -> None:
        with self._lock:
            self._closed = True
            handles = list(self._handles.values())
        for handle in handles:
            if handle.state in {HandleState.RUNNING, HandleState.PAUSED}:
                try:
                    self.cancel(handle, "harness_shutdown", graceful_timeout=1.0)
                except Exception as exc:
                    self._audit("execution.cancel.cleanup_failed", {"execution_id": handle.execution_id, "error": type(exc).__name__})

    def prove_determinism(self, context: ExecutionContext, implementation_factory: Callable[[], EntryPoint]) -> bool:
        if not context.deterministic:
            raise ValueError("determinism proof requires deterministic context")
        results: list[dict[str, Any]] = []
        simulation_budgets = ExecutionBudgets(
            cpu_seconds=min(context.budgets.cpu_seconds, 120.0),
            wall_seconds=min(context.budgets.wall_seconds, 120.0),
            ram_mb=min(context.budgets.ram_mb, 2048),
            vram_mb=0,
            gpu_seconds=0.0,
            network_bytes_in=0,
            network_bytes_out=0,
            disk_bytes_write=min(context.budgets.disk_bytes_write, 128 * 1024 * 1024),
            subprocess_count=0,
            tool_calls=min(context.budgets.tool_calls, 500),
            api_calls=min(context.budgets.api_calls, 500),
            concurrency=1,
            tokens_in=min(context.budgets.tokens_in, 1_000_000),
            tokens_out=min(context.budgets.tokens_out, 1_000_000),
        )
        for index in range(2):
            proof_context = ExecutionContext(
                execution_id=context.execution_id,
                correlation_id=context.correlation_id,
                causation_id=context.causation_id,
                parent_execution_id=context.parent_execution_id,
                agent_genome_hash=context.agent_genome_hash,
                agent_id=context.agent_id,
                trust_level=context.trust_level,
                execution_mode=ExecutionMode.SIMULATION,
                auth_context=context.auth_context,
                budgets=simulation_budgets,
                allowed=AllowedSurface(filesystem_paths=context.allowed.filesystem_paths, filesystem_mode=context.allowed.filesystem_mode, tools=context.allowed.tools, models=context.allowed.models, secrets=context.allowed.secrets),
                deterministic=True,
                random_seed=context.random_seed,
                fixed_clock=context.fixed_clock,
                time_source=context.time_source,
                checkpoint_policy=context.checkpoint_policy,
                trace_level=TraceLevel.NONE,
                telemetry_topic=context.telemetry_topic,
                environment_id=context.environment_id,
                environment_hash=context.environment_hash,
                workdir=context.workdir,
                env_vars={},
                certified_snapshot=context.certified_snapshot,
                evolution_candidate=context.evolution_candidate,
                _verified=True,
            )
            implementation = implementation_factory()
            handle = self.start(self.prepare(proof_context, implementation))
            result = self.wait(handle, timeout=context.budgets.wall_seconds + 1)
            if result is None:
                return False
            results.append({"ok": result.ok, "value": _redact(result.value), "error": result.error, "state": result.state})
        return canonical_json(results[0]) == canonical_json(results[1])

    def current_environment_hash(self, *, backend_id: str = "") -> str:
        payload = {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
            "executable": sys.executable,
            "backend_id": backend_id,
        }
        return _canonical_hash(payload)

    def _run_callable_handle(self, handle: ExecutionHandle) -> None:
        runtime = handle.runtime
        try:
            runtime.sample()
            implementation = handle.implementation
            value = implementation(handle.context)
            runtime.sample()
            accounting = self._build_accounting(handle)
            handle.result = ExecutionResult(handle.execution_id, True, _redact(value), None, accounting, HandleState.COMPLETED.value, False)
            handle._set_state(HandleState.COMPLETED)
            handle._last_event_id = self._publish_execution_event(runtime, "Completed", {"result_digest": _safe_digest(json.dumps(_redact(value), sort_keys=True, default=str)), "accounting": accounting.to_dict(), "harness_signature": self._sign_payload({"execution_id": handle.execution_id, "state": "completed", "result_digest": _safe_digest(json.dumps(_redact(value), sort_keys=True, default=str))})})
            self._trace(handle, {"kind": "lifecycle", "state": "completed", "result": _redact(value)})
        except CancellationRequested as exc:
            handle.result = ExecutionResult(handle.execution_id, False, None, str(exc), self._build_accounting(handle), HandleState.CANCELLED.value, True)
            handle._set_state(HandleState.CANCELLED)
            handle._last_event_id = self._publish_execution_event(runtime, "Cancelled", {"reason": str(exc)})
            self._trace(handle, {"kind": "lifecycle", "state": "cancelled", "reason": str(exc)})
        except BudgetViolation as exc:
            handle.result = ExecutionResult(handle.execution_id, False, None, str(exc), self._build_accounting(handle), HandleState.FAILED.value, True)
            handle._set_state(HandleState.FAILED)
            self._publish_execution_event(runtime, "Failed", {"failure_code": next((v.code for v in runtime.violations if v.metric == exc.metric), "Execution.BudgetExceeded"), "metric": exc.metric, "limit": exc.limit, "observed": exc.observed})
            self._trace(handle, {"kind": "lifecycle", "state": "failed", "error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            handle.result = ExecutionResult(handle.execution_id, False, None, f"{type(exc).__name__}: {exc}", self._build_accounting(handle), HandleState.FAILED.value, False)
            handle._set_state(HandleState.FAILED)
            self._publish_execution_event(runtime, "Failed", {"crash_type": type(exc).__name__, "error": _redact(str(exc)), "traceback": traceback.format_exc(limit=8)})
            self._trace(handle, {"kind": "lifecycle", "state": "failed", "error": str(exc)})
        finally:
            handle._done.set()
            self._audit("execution.wait", {"execution_id": handle.execution_id, "state": handle.state.value})

    def _run_command_handle(self, handle: ExecutionHandle) -> None:
        runtime = handle.runtime
        program = handle.implementation
        assert isinstance(program, CommandProgram)
        try:
            result = handle.backend.run_command(program, handle.context, runtime)
            if runtime.cancel_event.is_set() and not result.ok:
                raise CancellationRequested("execution cancelled")
            if result.ok:
                accounting = self._build_accounting(handle)
                handle.result = ExecutionResult(handle.execution_id, True, {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode}, None, accounting, HandleState.COMPLETED.value, False)
                handle._set_state(HandleState.COMPLETED)
                self._publish_execution_event(runtime, "Completed", {"returncode": result.returncode, "accounting": accounting.to_dict(), "harness_signature": self._sign_payload({"execution_id": handle.execution_id, "state": "completed", "returncode": result.returncode})})
            else:
                raise HarnessError(result.stderr or "command execution failed")
        except BudgetViolation as exc:
            handle.result = ExecutionResult(handle.execution_id, False, None, str(exc), self._build_accounting(handle), HandleState.FAILED.value, True)
            handle._set_state(HandleState.FAILED)
            self._publish_execution_event(runtime, "Failed", {"failure_code": f"Execution.{''.join(p.title() for p in exc.metric.split('_'))}Exceeded", "metric": exc.metric, "limit": exc.limit, "observed": exc.observed})
        except CancellationRequested as exc:
            handle.result = ExecutionResult(handle.execution_id, False, None, str(exc), self._build_accounting(handle), HandleState.CANCELLED.value, True)
            handle._set_state(HandleState.CANCELLED)
            self._publish_execution_event(runtime, "Cancelled", {"reason": str(exc)})
        except Exception as exc:  # noqa: BLE001
            handle.result = ExecutionResult(handle.execution_id, False, None, f"{type(exc).__name__}: {exc}", self._build_accounting(handle), HandleState.FAILED.value, False)
            handle._set_state(HandleState.FAILED)
            self._publish_execution_event(runtime, "Failed", {"crash_type": type(exc).__name__, "error": _redact(str(exc))})
        finally:
            handle._done.set()
            self._trace(handle, {"kind": "lifecycle", "state": handle.state.value})

    def _build_accounting(self, handle: ExecutionHandle) -> ExecutionAccounting:
        runtime = handle.runtime
        try:
            runtime.record_cpu(); runtime.record_wall(); runtime.record_ram()
        except BudgetViolation as exc:
            self._audit("execution.accounting.sample_exceeded", {"execution_id": handle.execution_id, "metric": exc.metric})
        counters = runtime.snapshot_counters()
        wall = max(0.0, time.monotonic() - runtime.started)
        cpu = float(counters.get("cpu_seconds", 0.0))
        cost = cpu + float(counters.get("gpu_seconds", 0.0)) * 10.0 + float(counters.get("ram_peak_mb", 0)) / 1024.0 * wall * 0.1 + float(counters.get("tokens_in", 0) + counters.get("tokens_out", 0)) / 100_000.0
        budgets = handle.context.budgets.as_dict()
        utilization = {}
        for name, limit in budgets.items():
            if limit:
                value = counters.get(name, 0.0)
                utilization[name] = float(value) / float(limit)
        accounting = ExecutionAccounting(
            execution_id=handle.execution_id,
            agent_genome_hash=handle.context.agent_genome_hash,
            wall_seconds=wall,
            cpu_seconds=cpu,
            ram_peak_mb=int(counters.get("ram_peak_mb", 0)),
            vram_peak_mb=int(counters.get("vram_peak_mb", 0)),
            gpu_seconds=float(counters.get("gpu_seconds", 0.0)),
            network_bytes_in=int(counters.get("network_bytes_in", 0)),
            network_bytes_out=int(counters.get("network_bytes_out", 0)),
            disk_bytes_written=int(counters.get("disk_bytes_write", 0)),
            subprocess_count=int(counters.get("subprocess_count", 0)),
            tool_calls=int(counters.get("tool_calls", 0)),
            api_calls=int(counters.get("api_calls", 0)),
            tokens_in=int(counters.get("tokens_in", 0)),
            tokens_out=int(counters.get("tokens_out", 0)),
            energy_joules_estimate=None,
            cost_units=cost,
            budget_utilization=utilization,
            violations=runtime.violations,
        )
        accounting_schema = json.loads(_ACCOUNTING_SCHEMA.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=64).validate_or_raise(accounting.to_dict(), accounting_schema)
        return accounting

    def _start_payload(self, handle: ExecutionHandle) -> dict[str, Any]:
        return {
            "execution_id": handle.execution_id,
            "agent_id": handle.context.agent_id,
            "agent_genome_hash": handle.context.agent_genome_hash,
            "trust_level": handle.context.trust_level,
            "execution_mode": handle.context.execution_mode.value,
            "budget": handle.context.budgets.as_dict(),
            "environment_hash": handle.context.environment_hash,
            "harness_signature": self._sign_payload({"execution_id": handle.execution_id, "state": "started"}),
        }

    def _sign_payload(self, payload: Mapping[str, Any]) -> str:
        return base64.b64encode(self.signing_key.sign(canonical_bytes(payload))).decode("ascii")

    def _publish_execution_event(self, runtime_or_handle: ExecutionRuntime | ExecutionHandle, event_name: str, payload: Mapping[str, Any]) -> str | None:
        runtime = runtime_or_handle.runtime if isinstance(runtime_or_handle, ExecutionHandle) else runtime_or_handle
        if not runtime.context.auth_context.scopes or "events.publish.agent.execution" not in set(runtime.context.auth_context.scopes):
            raise AuthorizationRequired("execution event publication was not authorized upstream")
        causation = runtime._event_ids[-1] if runtime._event_ids else runtime.context.causation_id
        event = EventEnvelope.create(
            event_type="Agent.Execution",
            event_name=event_name,
            payload={**dict(payload), "lineage": {"certified_snapshot": runtime.context.certified_snapshot, "evolution_candidate": runtime.context.evolution_candidate}},
            produced_by=ProducedBy("system", "execution-harness", self.public_key_fingerprint, "system"),
            auth_context=AuthContext(runtime.context.auth_context.principal, runtime.context.auth_context.scopes, runtime.context.auth_context.policy_ref, None),
            tenant_id=str(runtime.context.auth_context.principal).split("/", 1)[0] or runtime.context.auth_context.principal,
            partition_key=runtime.context.agent_id,
            correlation_id=runtime.context.correlation_id,
            causation_id=causation,
            parent_event_id=causation,
            signing_key=self.signing_key,
        )
        receipt = self.event_bus.publish(event)
        runtime._event_ids.append(event.event_id)
        if runtime.context.trace_level in {TraceLevel.FULL, TraceLevel.FORENSIC}:
            self._trace(runtime_or_handle if isinstance(runtime_or_handle, ExecutionHandle) else self._handle_for(runtime.context.execution_id), {"kind": "event", "event_name": event_name, "event_id": event.event_id, "payload": payload})
        return event.event_id

    def _publish_telemetry(self, runtime: ExecutionRuntime, event_name: str, payload: Mapping[str, Any]) -> str | None:
        if "events.publish.telemetry" not in set(runtime.context.auth_context.scopes):
            raise AuthorizationRequired("telemetry publication was not authorized upstream")
        event = EventEnvelope.create(
            event_type="Telemetry",
            event_name=event_name,
            payload={"execution_id": runtime.context.execution_id, **_redact(dict(payload))},
            produced_by=ProducedBy("system", "execution-harness", self.public_key_fingerprint, "system"),
            auth_context=AuthContext(runtime.context.auth_context.principal, runtime.context.auth_context.scopes, runtime.context.auth_context.policy_ref, None),
            tenant_id=str(runtime.context.auth_context.principal).split("/", 1)[0] or runtime.context.auth_context.principal,
            partition_key=runtime.context.agent_id,
            correlation_id=runtime.context.correlation_id,
            causation_id=runtime._event_ids[-1] if runtime._event_ids else runtime.context.causation_id,
            signing_key=self.signing_key,
            sensitivity="internal",
        )
        self.event_bus.publish(event)
        runtime._event_ids.append(event.event_id)
        return event.event_id

    def _trace(self, handle: ExecutionHandle, payload: Mapping[str, Any]) -> None:
        if handle.context.trace_level == TraceLevel.NONE:
            return
        if handle.context.trace_level in {TraceLevel.FULL, TraceLevel.FORENSIC}:
            self.traces.append(handle.execution_id, payload, secret_values=tuple(handle.runtime._secret_values))
            if handle.context.trace_level == TraceLevel.FORENSIC:
                try:
                    self.traces.verify(handle.execution_id)
                except TraceIntegrityError:
                    raise

    def _handle_for(self, execution_id: str) -> ExecutionHandle:
        with self._lock:
            return self._handles[execution_id]

    def _audit(self, event: str, details: Mapping[str, Any]) -> None:
        if self.audit is not None:
            self.audit.log(event, _redact(dict(details)))

    @staticmethod
    def _path_under(path: Path, root: Path) -> bool:
        path = path.resolve(); root = root.resolve()
        return path == root or str(path).startswith(str(root) + os.sep)


def _implementation_ref(implementation: Any) -> str | None:
    module = getattr(implementation, "__module__", None)
    qualname = getattr(implementation, "__qualname__", None)
    if module and qualname:
        return f"{module}:{qualname}"
    return None


def build_environment_hash(*, backend_id: str = "") -> str:
    payload = {"platform": platform.platform(), "python": platform.python_version(), "implementation": platform.python_implementation(), "backend_id": backend_id}
    return _canonical_hash(payload)


def load_schema_documents() -> tuple[dict[str, Any], dict[str, Any]]:
    return json.loads(_CONTEXT_SCHEMA.read_text(encoding="utf-8")), json.loads(_ACCOUNTING_SCHEMA.read_text(encoding="utf-8"))


__all__ = [
    "AgentHarness", "AllowedSurface", "AuthorizationRequired", "BackendExecutionResult", "BackendGuarantees",
    "CheckpointError", "CheckpointPolicy", "CheckpointStore", "Checkpointable", "CommandProgram", "ContextImmutable",
    "Clock", "DsecContainerBackend", "ExecutionAccounting", "ExecutionAuthContext", "ExecutionBudgets", "ExecutionContext",
    "ExecutionHandle", "ExecutionMode", "ExecutionResult", "ExecutionRuntime", "FilesystemMode", "HarnessError",
    "LinuxNativeSandboxBackend", "MacOSSandboxBackend", "ModeNotPermitted", "PolicyDenied", "PortableSubprocessBackend",
    "RestoreIncompatibleEnvironment", "SandboxBackend", "SecretBroker", "SimulationBackend", "TimeSource", "TraceIntegrityError",
    "TraceLedger", "TraceLevel", "TrustLevel", "ViolationRecord", "WindowsNativeSandboxBackend", "build_environment_hash",
    "load_schema_documents",
]

"""Crash-recovery drills, state snapshots and deterministic rollback checks."""
from __future__ import annotations

import copy
import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class RecoveryDrillResult:
    """Result of one controlled recovery drill."""

    name: str
    passed: bool
    error: str | None = None
    duration_ms: float = 0.0


class RecoveryEngineering:
    """Provide deterministic recovery tests without manipulating real system state."""

    def __init__(self, *, max_snapshot_bytes: int = 5_000_000) -> None:
        self.max_snapshot_bytes = max(1024, min(int(max_snapshot_bytes), 50_000_000))

    def snapshot(self, state: dict[str, Any]) -> dict[str, Any]:
        """Create an integrity-addressed deep-copy snapshot."""
        normalized = copy.deepcopy(state)
        encoded = json.dumps(normalized, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        if len(encoded) > self.max_snapshot_bytes:
            raise ValueError("recovery snapshot exceeds configured size")
        return {"schema": 1, "state": normalized, "sha256": hashlib.sha256(encoded).hexdigest(), "created_at": time.time()}

    def restore(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        """Verify and restore a snapshot payload."""
        state = snapshot.get("state")
        encoded = json.dumps(state, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        expected = str(snapshot.get("sha256", ""))
        if not expected or hashlib.sha256(encoded).hexdigest() != expected:
            raise ValueError("recovery snapshot integrity check failed")
        return copy.deepcopy(state)

    def drill(self, name: str, failure: Callable[[], None], recover: Callable[[], bool]) -> RecoveryDrillResult:
        """Inject an expected failure and require a successful recovery callback."""
        started = time.perf_counter()
        try:
            failure()
        except Exception:
            try:
                passed = bool(recover())
            except Exception as exc:
                return RecoveryDrillResult(str(name), False, type(exc).__name__, (time.perf_counter() - started) * 1000.0)
            return RecoveryDrillResult(str(name), passed, None if passed else "recovery_failed", (time.perf_counter() - started) * 1000.0)
        return RecoveryDrillResult(str(name), False, "failure_injection_did_not_fail", (time.perf_counter() - started) * 1000.0)



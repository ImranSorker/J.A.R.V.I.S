"""Verified AION outcome to evolution-learning bridge."""
from __future__ import annotations

import logging
from typing import Any, Mapping

logger = logging.getLogger("jarvis.aion.learning")


class EvolutionLearningSink:
    """Translate terminal AION outcomes into the existing EvolutionEngine API."""

    def __init__(self, evolution: Any, *, owner_id: str = "aion-executive", workspace_id: str = "default", session_id: str = "aion", task_type: str = "strategic-goal") -> None:
        if evolution is None:
            raise ValueError("evolution engine is required")
        self._evolution = evolution
        self._owner_id = str(owner_id)
        self._workspace_id = str(workspace_id)
        self._session_id = str(session_id)
        self._task_type = str(task_type)
        self._recorded = 0
        self._failed = 0

    def record(self, *, goal_id: str, success: bool, summary: str, evidence: Mapping[str, Any]) -> None:
        payload = {
            "owner_id": self._owner_id,
            "workspace_id": self._workspace_id,
            "session_id": self._session_id,
            "task_type": self._task_type,
            "outcome": "completed" if success else "failed",
            "summary": str(summary)[:2000],
            "evidence": dict(evidence),
        }
        try:
            if success:
                self._evolution.record_success(**payload)
            else:
                self._evolution.record_failure(**payload)
            self._recorded += 1
        except Exception:
            self._failed += 1
            logger.exception("aion_learning_record_failed", extra={"goal_id": goal_id, "success": success})

    def snapshot(self) -> dict[str, int]:
        return {"recorded": self._recorded, "failed": self._failed}

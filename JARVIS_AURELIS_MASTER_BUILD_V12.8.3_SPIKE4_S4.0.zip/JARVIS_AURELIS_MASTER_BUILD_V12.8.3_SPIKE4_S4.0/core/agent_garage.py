"""J.A.R.V.I.S. Agent Garage 2.0.

Durable lifecycle authority for staged agent packages.  The Garage owns only
lifecycle state after STAGED; it does not alter genomes, grant capabilities, or
replace the Security Authority / P2-E execution boundary.
"""
from __future__ import annotations

import copy
import hashlib
import hmac
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_factory import verify_agentpkg
from core.agent_genome import AgentGenome
from core.event_fabric import AuthContext, DurableEventBus, EventEnvelope, EventLineage, EventReceipt, ProducedBy, EventTaxonomy
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

BASE_DIR = Path(__file__).resolve().parent
SCHEMA_DIR = BASE_DIR / "schemas"
LIFECYCLE_SCHEMA = SCHEMA_DIR / "lifecycle_record_v1.schema.json"
SNAPSHOT_SCHEMA = SCHEMA_DIR / "agent_snapshot_v1.schema.json"
DEPLOYMENT_SCHEMA = SCHEMA_DIR / "deployment_record_v1.schema.json"
QUARANTINE_SCHEMA = SCHEMA_DIR / "quarantine_record_v1.schema.json"
ROLLBACK_SCHEMA = SCHEMA_DIR / "rollback_record_v1.schema.json"
RESURRECTION_SCHEMA = SCHEMA_DIR / "resurrection_record_v1.schema.json"
RETIREMENT_SCHEMA = SCHEMA_DIR / "retirement_record_v1.schema.json"


def _b64(data: bytes) -> str:
    import base64
    return base64.b64encode(data).decode("ascii")


def _b64d(value: str) -> bytes:
    import base64
    return base64.b64decode(value.encode("ascii"), validate=True)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _json_hash(value: Mapping[str, Any]) -> str:
    return _sha(canonical_bytes(dict(value)))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _ts(value: str) -> float:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


class GarageError(RuntimeError):
    """J.A.R.V.I.S. Garage control-plane error."""


class IllegalStateTransition(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class AuthorizationDenied(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class SnapshotError(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class SnapshotEnvironmentMismatch(SnapshotError):
    """J.A.R.V.I.S. Garage control-plane error."""


class SnapshotRevoked(SnapshotError):
    """J.A.R.V.I.S. Garage control-plane error."""


class AttenuationCannotWiden(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class DeploymentPreconditionFailed(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class RollbackCascadeFailure(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class StateReplayError(GarageError):
    """J.A.R.V.I.S. Garage control-plane error."""


class GarageState(StrEnum):
    DRAFT = "DRAFT"
    BUILDING = "BUILDING"
    TESTING = "TESTING"
    EVALUATING = "EVALUATING"
    CERTIFIED = "CERTIFIED"
    STAGED = "STAGED"
    DEPLOYED = "DEPLOYED"
    MONITORED = "MONITORED"
    SUSPENDED = "SUSPENDED"
    QUARANTINED = "QUARANTINED"
    ROLLED_BACK = "ROLLED_BACK"
    RETIRED = "RETIRED"
    RESURRECTED = "RESURRECTED"
    REJECTED = "REJECTED"
    BUILD_FAILED = "BUILD_FAILED"
    TEST_FAILED = "TEST_FAILED"
    EVAL_FAILED = "EVAL_FAILED"
    CERT_REVOKED = "CERT_REVOKED"
    STAGE_ABORTED = "STAGE_ABORTED"
    DEPLOY_FAILED = "DEPLOY_FAILED"


# Frozen transition matrix.  Entries are deliberately explicit; no wildcard
# permission is used for forward lifecycle transitions.
LEGAL_TRANSITIONS: dict[GarageState, frozenset[GarageState]] = {
    GarageState.DRAFT: frozenset({GarageState.BUILDING, GarageState.REJECTED, GarageState.RETIRED}),
    GarageState.BUILDING: frozenset({GarageState.TESTING, GarageState.BUILD_FAILED, GarageState.REJECTED, GarageState.RETIRED}),
    GarageState.TESTING: frozenset({GarageState.EVALUATING, GarageState.TEST_FAILED, GarageState.REJECTED, GarageState.RETIRED}),
    GarageState.EVALUATING: frozenset({GarageState.CERTIFIED, GarageState.EVAL_FAILED, GarageState.REJECTED, GarageState.RETIRED}),
    GarageState.CERTIFIED: frozenset({GarageState.STAGED, GarageState.CERT_REVOKED, GarageState.REJECTED, GarageState.RETIRED}),
    GarageState.STAGED: frozenset({GarageState.STAGED, GarageState.DEPLOYED, GarageState.STAGE_ABORTED, GarageState.QUARANTINED, GarageState.CERT_REVOKED, GarageState.RETIRED}),
    GarageState.DEPLOYED: frozenset({GarageState.DEPLOYED, GarageState.MONITORED, GarageState.DEPLOY_FAILED, GarageState.SUSPENDED, GarageState.QUARANTINED, GarageState.ROLLED_BACK, GarageState.CERT_REVOKED, GarageState.RETIRED}),
    GarageState.MONITORED: frozenset({GarageState.MONITORED, GarageState.SUSPENDED, GarageState.QUARANTINED, GarageState.ROLLED_BACK, GarageState.RETIRED, GarageState.CERT_REVOKED}),
    GarageState.SUSPENDED: frozenset({GarageState.SUSPENDED, GarageState.MONITORED, GarageState.DEPLOYED, GarageState.QUARANTINED, GarageState.ROLLED_BACK, GarageState.RETIRED}),
    GarageState.QUARANTINED: frozenset({GarageState.QUARANTINED, GarageState.ROLLED_BACK, GarageState.RETIRED, GarageState.RESURRECTED}),
    GarageState.ROLLED_BACK: frozenset({GarageState.ROLLED_BACK, GarageState.MONITORED, GarageState.DEPLOYED, GarageState.RETIRED, GarageState.QUARANTINED, GarageState.CERT_REVOKED}),
    GarageState.RETIRED: frozenset({GarageState.RESURRECTED}),
    GarageState.RESURRECTED: frozenset({GarageState.RESURRECTED, GarageState.STAGED, GarageState.DEPLOYED, GarageState.MONITORED, GarageState.RETIRED, GarageState.QUARANTINED}),
    GarageState.REJECTED: frozenset(),
    GarageState.BUILD_FAILED: frozenset({GarageState.BUILDING, GarageState.REJECTED}),
    GarageState.TEST_FAILED: frozenset({GarageState.TESTING, GarageState.REJECTED}),
    GarageState.EVAL_FAILED: frozenset({GarageState.EVALUATING, GarageState.REJECTED}),
    GarageState.CERT_REVOKED: frozenset({GarageState.QUARANTINED, GarageState.RETIRED}),
    GarageState.STAGE_ABORTED: frozenset({GarageState.STAGED, GarageState.RETIRED}),
    GarageState.DEPLOY_FAILED: frozenset({GarageState.STAGED, GarageState.QUARANTINED, GarageState.RETIRED}),
}

REASON_CODES = {
    "factory_stage", "build_started", "build_completed", "test_started", "test_completed",
    "evaluation_started", "evaluation_completed", "certification_passed", "deployment_authorized",
    "deployment_failed", "monitoring_started", "suspend_policy", "resume_authorized",
    "quarantine_security", "quarantine_integrity", "quarantine_revocation", "rollback_authorized",
    "rollback_completed", "retirement_requested", "resurrection_authorized", "resurrection_completed",
    "certificate_revoked", "certificate_expired", "dependency_revoked", "budget_drift", "behavior_drift",
    "operator_request", "system_recovery", "stage_abort", "rejected", "manual", "unknown",
}


class SecurityAuthority(Protocol):
    def authorize(self, operation: str, subject: Mapping[str, Any]) -> str | bool: ...


class HarnessAdapter(Protocol):
    def activate(self, *, agent_id: str, package_hash: str, environment_hash: str, authorization_token: str, mode: str = "trusted") -> Mapping[str, Any]: ...
    def deactivate(self, *, agent_id: str, authorization_token: str) -> None: ...
    def restore(self, *, snapshot: Mapping[str, Any], environment_hash: str, authorization_token: str) -> Mapping[str, Any]: ...
    def halt_new_executions(self, *, agent_id: str, authorization_token: str) -> None: ...


class CapacityProvider(Protocol):
    def available(self, *, environment_hash: str, agent_id: str, package_hash: str) -> bool: ...


class KnowledgeExtractor(Protocol):
    def export(self, *, agent_id: str, destination: str) -> Mapping[str, Any]: ...


class DependencyAuthority(Protocol):
    def status(self, refs: Sequence[str], *, tenant_id: str) -> Mapping[str, str]: ...


@dataclass(frozen=True, slots=True)
class LifecycleRecord:
    record_id: str
    agent_id: str
    agent_genome_hash: str
    package_hash: str | None
    from_state: str | None
    to_state: str
    reason: str
    reason_code: str
    actor: Mapping[str, Any]
    authorization_token_ref: str
    correlation_id: str
    causation_id: str | None
    parent_record_id: str | None
    environment_ref: str | None
    snapshot_ref: str | None
    rollback_target: str | None
    quarantine_scope: str | None
    evidence_refs: tuple[str, ...]
    transitioned_at: str
    signature: str
    integrity_hash: str
    garage_public_key: str

    def unsigned(self) -> dict[str, Any]:
        doc = self.to_dict()
        doc.pop("signature", None)
        doc.pop("integrity_hash", None)
        return doc

    def to_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id, "agent_id": self.agent_id, "agent_genome_hash": self.agent_genome_hash,
            "package_hash": self.package_hash, "from_state": self.from_state, "to_state": self.to_state,
            "reason": self.reason, "reason_code": self.reason_code, "actor": dict(self.actor),
            "authorization_token_ref": self.authorization_token_ref, "correlation_id": self.correlation_id,
            "causation_id": self.causation_id, "parent_record_id": self.parent_record_id,
            "environment_ref": self.environment_ref, "snapshot_ref": self.snapshot_ref,
            "rollback_target": self.rollback_target, "quarantine_scope": self.quarantine_scope,
            "evidence_refs": list(self.evidence_refs), "transitioned_at": self.transitioned_at,
            "signature": self.signature, "integrity_hash": self.integrity_hash, "garage_public_key": self.garage_public_key,
        }

    def verify(self) -> bool:
        try:
            public = Ed25519PublicKey.from_public_bytes(_b64d(self.garage_public_key))
            body = self.unsigned()
            if _sha(canonical_bytes(body)) != self.integrity_hash:
                return False
            public.verify(_b64d(self.signature), canonical_bytes(body))
            return True
        except (InvalidSignature, ValueError, TypeError, KeyError):
            return False


@dataclass(frozen=True, slots=True)
class AgentSnapshot:
    snapshot_id: str
    agent_id: str
    agent_genome_hash: str
    package_hash: str
    certification_id: str
    certification_hash: str
    environment_hash: str
    skill_lock: Mapping[str, str]
    tool_lock: Mapping[str, str]
    model_lock: Mapping[str, str]
    memory_snapshot_refs: tuple[str, ...]
    world_state_ref: str | None
    runtime_config_hash: str
    created_at: str
    created_by: str
    valid: bool
    attenuation: Mapping[str, Any]
    signature: str
    integrity_hash: str
    garage_public_key: str

    def unsigned(self) -> dict[str, Any]:
        d = self.to_dict(); d.pop("signature", None); d.pop("integrity_hash", None); return d

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshot_id": self.snapshot_id, "agent_id": self.agent_id, "agent_genome_hash": self.agent_genome_hash,
            "package_hash": self.package_hash, "certification_id": self.certification_id, "certification_hash": self.certification_hash,
            "environment_hash": self.environment_hash, "skill_lock": dict(self.skill_lock), "tool_lock": dict(self.tool_lock),
            "model_lock": dict(self.model_lock), "memory_snapshot_refs": list(self.memory_snapshot_refs),
            "world_state_ref": self.world_state_ref, "runtime_config_hash": self.runtime_config_hash,
            "created_at": self.created_at, "created_by": self.created_by, "valid": self.valid,
            "attenuation": copy.deepcopy(dict(self.attenuation)), "signature": self.signature,
            "integrity_hash": self.integrity_hash, "garage_public_key": self.garage_public_key,
        }

    def verify(self) -> bool:
        try:
            public = Ed25519PublicKey.from_public_bytes(_b64d(self.garage_public_key))
            body = self.unsigned()
            if _sha(canonical_bytes(body)) != self.integrity_hash:
                return False
            public.verify(_b64d(self.signature), canonical_bytes(body))
            return True
        except (InvalidSignature, ValueError, TypeError, KeyError):
            return False


@dataclass(frozen=True, slots=True)
class GarageStateView:
    agent_id: str
    tenant_id: str
    state: GarageState
    genome_hash: str
    package_hash: str | None
    certification_id: str | None
    environment_hash: str | None
    deployment_version: int
    record_id: str | None
    quarantine_scope: str | None
    attenuations: Mapping[str, Any]


class AgentGarage:
    """Single lifecycle authority after an agent reaches STAGED."""

    def __init__(
        self,
        *,
        db_path: str | Path,
        storage_secret: bytes,
        signing_key: Ed25519PrivateKey,
        event_bus: DurableEventBus,
        tenant_id: str,
        security_authority: SecurityAuthority,
        harness: HarnessAdapter,
        capacity_provider: CapacityProvider | None = None,
        knowledge_extractor: KnowledgeExtractor | None = None,
        dependency_authority: DependencyAuthority | None = None,
        snapshot_root: str | Path | None = None,
    ) -> None:
        if len(storage_secret) < 32:
            raise ValueError("garage storage secret must be at least 32 bytes")
        self.path = Path(db_path).resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.snapshot_root = Path(snapshot_root or self.path.parent / "garage_snapshots").resolve(); self.snapshot_root.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(storage_secret); self.signing_key = signing_key; self.event_bus = event_bus
        self.tenant_id = str(tenant_id); self.security_authority = security_authority; self.harness = harness
        self.capacity_provider = capacity_provider; self.knowledge_extractor = knowledge_extractor; self.dependency_authority = dependency_authority
        self._lock = threading.RLock(); self._closed = False
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS agents(
            tenant_id TEXT NOT NULL, agent_id TEXT NOT NULL, state TEXT NOT NULL,
            genome_hash TEXT NOT NULL, package_hash TEXT, certification_id TEXT,
            environment_hash TEXT, deployment_version INTEGER NOT NULL DEFAULT 0,
            record_id TEXT, quarantine_scope TEXT, attenuations_json TEXT NOT NULL,
            valid_until REAL, PRIMARY KEY(tenant_id, agent_id));
        CREATE TABLE IF NOT EXISTS lifecycle_records(
            tenant_id TEXT NOT NULL, seq INTEGER PRIMARY KEY AUTOINCREMENT, record_id TEXT NOT NULL UNIQUE,
            agent_id TEXT NOT NULL, record_json TEXT NOT NULL, record_hash TEXT NOT NULL,
            previous_hash TEXT NOT NULL, integrity_tag TEXT NOT NULL, created_at REAL NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_lifecycle_agent ON lifecycle_records(tenant_id, agent_id, seq);
        CREATE TABLE IF NOT EXISTS snapshots(
            tenant_id TEXT NOT NULL, snapshot_id TEXT PRIMARY KEY, agent_id TEXT NOT NULL,
            snapshot_json TEXT NOT NULL, snapshot_hash TEXT NOT NULL, integrity_tag TEXT NOT NULL, created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS package_meta(
            tenant_id TEXT NOT NULL, agent_id TEXT NOT NULL, package_hash TEXT NOT NULL,
            package_uri TEXT NOT NULL, package_manifest_json TEXT NOT NULL, certification_json TEXT NOT NULL,
            genome_json TEXT NOT NULL, environment_hash TEXT, skill_lock_json TEXT NOT NULL,
            tool_lock_json TEXT NOT NULL, model_lock_json TEXT NOT NULL, certification_valid_until REAL,
            PRIMARY KEY(tenant_id, agent_id));
        CREATE TABLE IF NOT EXISTS invalid_snapshots(tenant_id TEXT NOT NULL, snapshot_id TEXT PRIMARY KEY, reason TEXT NOT NULL, marked_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS signals(tenant_id TEXT NOT NULL, agent_id TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL, observed_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS histories(tenant_id TEXT NOT NULL, agent_id TEXT NOT NULL, kind TEXT NOT NULL, payload_json TEXT NOT NULL, observed_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS event_outbox(
            tenant_id TEXT NOT NULL, event_id TEXT NOT NULL, agent_id TEXT NOT NULL,
            event_json TEXT NOT NULL, integrity_tag TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            published_at REAL, last_error TEXT, created_at REAL NOT NULL, PRIMARY KEY(tenant_id, event_id)
        );
        CREATE INDEX IF NOT EXISTS idx_event_outbox_pending ON event_outbox(tenant_id, published_at, created_at);
        """)
        self._db.commit()

    @property
    def public_key(self) -> bytes:
        return self.signing_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @property
    def public_key_fingerprint(self) -> str:
        return _sha(self.public_key)

    def _tag(self, payload: str, previous_hash: str, tenant_id: str, kind: str) -> str:
        return hmac.new(self._secret, canonical_bytes({"tenant_id": tenant_id, "kind": kind, "payload": payload, "previous_hash": previous_hash}), hashlib.sha256).hexdigest()

    def _audit_append(self, *, record: LifecycleRecord, previous_hash: str, cursor: sqlite3.Connection) -> None:
        payload = json.dumps(record.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        record_hash = _sha(canonical_bytes({"record": record.to_dict(), "previous_hash": previous_hash}))
        tag = self._tag(payload, previous_hash, self.tenant_id, "lifecycle")
        cursor.execute(
            "INSERT INTO lifecycle_records(tenant_id,record_id,agent_id,record_json,record_hash,previous_hash,integrity_tag,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (self.tenant_id, record.record_id, record.agent_id, payload, record_hash, previous_hash, tag, _ts(record.transitioned_at)),
        )

    def _last_hash(self, cursor: sqlite3.Connection) -> str:
        row = cursor.execute("SELECT record_hash FROM lifecycle_records WHERE tenant_id=? ORDER BY seq DESC LIMIT 1", (self.tenant_id,)).fetchone()
        return str(row[0]) if row else "0" * 64

    def _load_row(self, agent_id: str) -> GarageStateView | None:
        row = self._db.execute("SELECT agent_id,tenant_id,state,genome_hash,package_hash,certification_id,environment_hash,deployment_version,record_id,quarantine_scope,attenuations_json FROM agents WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchone()
        if row is None: return None
        return GarageStateView(str(row[0]), str(row[1]), GarageState(str(row[2])), str(row[3]), row[4], row[5], row[6], int(row[7]), row[8], row[9], json.loads(str(row[10])))

    def get(self, agent_id: str) -> GarageStateView | None:
        with self._lock: return self._load_row(agent_id)

    def _validate_schema(self, path: Path, payload: Mapping[str, Any]) -> None:
        SchemaValidator(max_errors=64).validate_or_raise(dict(payload), json.loads(path.read_text(encoding="utf-8")))

    def _authorize(self, operation: str, subject: Mapping[str, Any]) -> str:
        result = self.security_authority.authorize(operation, dict(subject))
        token = result if isinstance(result, str) else (subject.get("authorization_token") if result else None)
        if not token: raise AuthorizationDenied(f"Security Authority denied {operation}")
        return str(token)

    def _make_event(self, *, agent_id: str, event_name: str, payload: Mapping[str, Any], correlation_id: str, causation_id: str | None, priority: str | None = None) -> EventEnvelope:
        auth = AuthContext("agent-garage", ("events.publish.agent.lifecycle",), "garage-policy", None)
        if priority is None:
            priority = str(EventTaxonomy.get("Agent.Lifecycle", event_name)["default_priority"])
        produced = ProducedBy("system", "agent-garage", None, "system")
        return EventEnvelope.create(
            event_type="Agent.Lifecycle", event_name=event_name, payload=dict(payload), produced_by=produced,
            auth_context=auth, tenant_id=self.tenant_id, correlation_id=correlation_id, causation_id=causation_id,
            parent_event_id=None, partition_key=agent_id, priority=priority, signing_key=self.signing_key,
            lineage=EventLineage(),
        )

    def _queue_event(self, envelope: EventEnvelope, *, agent_id: str, cursor: sqlite3.Connection) -> None:
        payload = json.dumps(envelope.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        tag = self._tag(payload, "", self.tenant_id, "event_outbox")
        cursor.execute(
            "INSERT OR IGNORE INTO event_outbox(tenant_id,event_id,agent_id,event_json,integrity_tag,attempts,published_at,last_error,created_at) VALUES(?,?,?,?,?,0,NULL,NULL,?)",
            (self.tenant_id, envelope.event_id, agent_id, payload, tag, time.time()),
        )

    def flush_pending_events(self, *, limit: int = 100) -> int:
        published = 0
        rows = self._db.execute(
            "SELECT event_id,event_json,integrity_tag,attempts FROM event_outbox WHERE tenant_id=? AND published_at IS NULL ORDER BY created_at ASC LIMIT ?",
            (self.tenant_id, int(limit)),
        ).fetchall()
        for event_id, event_json, tag, attempts in rows:
            expected = self._tag(str(event_json), "", self.tenant_id, "event_outbox")
            if not hmac.compare_digest(expected, str(tag)):
                raise GarageError(f"event outbox integrity failure: {event_id}")
            envelope = EventEnvelope.from_dict(json.loads(str(event_json)))
            if not envelope.verify_integrity():
                raise GarageError(f"event outbox envelope integrity failure: {event_id}")
            try:
                if not envelope.verify_signature(self.public_key):
                    raise GarageError(f"event outbox signature verification failure: {event_id}")
                self.event_bus.publish(envelope)
            except Exception as exc:
                with self._db:
                    self._db.execute(
                        "UPDATE event_outbox SET attempts=?, last_error=? WHERE tenant_id=? AND event_id=?",
                        (int(attempts) + 1, str(exc), self.tenant_id, str(event_id)),
                    )
                continue
            with self._db:
                self._db.execute(
                    "UPDATE event_outbox SET published_at=?, last_error=NULL WHERE tenant_id=? AND event_id=?",
                    (time.time(), self.tenant_id, str(event_id)),
                )
            published += 1
        return published

    def _emit(self, *, agent_id: str, event_name: str, payload: Mapping[str, Any], correlation_id: str, causation_id: str | None, priority: str | None = None) -> EventReceipt:
        envelope = self._make_event(agent_id=agent_id, event_name=event_name, payload=payload, correlation_id=correlation_id, causation_id=causation_id, priority=priority)
        self._queue_event(envelope, agent_id=agent_id, cursor=self._db)
        self._db.commit()
        try:
            receipt = self.event_bus.publish(envelope)
        except Exception as exc:
            with self._db:
                self._db.execute("UPDATE event_outbox SET attempts=attempts+1,last_error=? WHERE tenant_id=? AND event_id=?", (str(exc), self.tenant_id, envelope.event_id))
            raise
        with self._db:
            self._db.execute("UPDATE event_outbox SET published_at=?,last_error=NULL WHERE tenant_id=? AND event_id=?", (time.time(), self.tenant_id, envelope.event_id))
        return receipt

    def _sign_record(self, body: Mapping[str, Any]) -> LifecycleRecord:
        payload = copy.deepcopy(dict(body)); payload["garage_public_key"] = _b64(self.public_key)
        payload["signature"] = ""; payload.pop("integrity_hash", None)
        payload["integrity_hash"] = _sha(canonical_bytes({k: v for k, v in payload.items() if k not in {"signature", "integrity_hash"}}))
        payload["signature"] = _b64(self.signing_key.sign(canonical_bytes({k: v for k, v in payload.items() if k not in {"signature", "integrity_hash"}})))
        self._validate_schema(LIFECYCLE_SCHEMA, payload)
        return LifecycleRecord(**payload)  # type: ignore[arg-type]

    def _sign_snapshot(self, body: Mapping[str, Any]) -> AgentSnapshot:
        payload = copy.deepcopy(dict(body)); payload["garage_public_key"] = _b64(self.public_key)
        payload["signature"] = ""; payload.pop("integrity_hash", None)
        payload["integrity_hash"] = _sha(canonical_bytes({k: v for k, v in payload.items() if k not in {"signature", "integrity_hash"}}))
        payload["signature"] = _b64(self.signing_key.sign(canonical_bytes({k: v for k, v in payload.items() if k not in {"signature", "integrity_hash"}})))
        self._validate_schema(SNAPSHOT_SCHEMA, payload)
        return AgentSnapshot(**payload)  # type: ignore[arg-type]

    def _transition(
        self, *, agent_id: str, to_state: GarageState, reason: str, reason_code: str, actor: Mapping[str, Any],
        authorization_token: str, package_hash: str | None = None, environment_ref: str | None = None,
        snapshot_ref: str | None = None, rollback_target: str | None = None, quarantine_scope: str | None = None,
        evidence_refs: Sequence[str] = (), correlation_id: str | None = None, causation_id: str | None = None,
        genome_hash: str | None = None, certification_id: str | None = None, event_name_override: str | None = None,
    ) -> LifecycleRecord:
        if reason_code not in REASON_CODES: raise ValueError(f"unknown reason code {reason_code}")
        with self._lock, self._db:
            current = self._load_row(agent_id)
            if current is None:
                if to_state not in {GarageState.DRAFT, GarageState.STAGED, GarageState.REJECTED}:
                    raise IllegalStateTransition(f"unknown agent cannot transition to {to_state.value}")
                from_state = None; parent = None; deployment_version = 0; atten = {}
                old_genome_hash = genome_hash or "0" * 64
            else:
                from_state = current.state
                if to_state not in LEGAL_TRANSITIONS[from_state]:
                    raise IllegalStateTransition(f"illegal transition {from_state.value} -> {to_state.value}")
                parent = current.record_id; deployment_version = current.deployment_version; atten = dict(current.attenuations)
                old_genome_hash = current.genome_hash
            if genome_hash and current and current.genome_hash != genome_hash:
                raise GarageError("genome hash cannot change through Garage lifecycle")
            corr = correlation_id or str(uuid.uuid4()); caus = causation_id or parent
            record_body = {
                "record_id": str(uuid.uuid4()), "agent_id": agent_id, "agent_genome_hash": genome_hash or old_genome_hash,
                "package_hash": package_hash if package_hash is not None else (current.package_hash if current else None),
                "from_state": from_state.value if from_state else None, "to_state": to_state.value,
                "reason": reason, "reason_code": reason_code, "actor": dict(actor),
                "authorization_token_ref": _sha(authorization_token.encode()), "correlation_id": corr,
                "causation_id": caus, "parent_record_id": parent, "environment_ref": environment_ref,
                "snapshot_ref": snapshot_ref, "rollback_target": rollback_target, "quarantine_scope": quarantine_scope,
                "evidence_refs": list(evidence_refs), "transitioned_at": _now(), "garage_public_key": "",
                "signature": "", "integrity_hash": "",
            }
            record = self._sign_record(record_body)
            if not record.verify(): raise GarageError("signed lifecycle record self-verification failed")
            previous_hash = self._last_hash(self._db)
            deployment_version = deployment_version + 1 if to_state == GarageState.DEPLOYED else deployment_version
            self._audit_append(record=record, previous_hash=previous_hash, cursor=self._db)
            self._db.execute(
                "INSERT INTO agents(tenant_id,agent_id,state,genome_hash,package_hash,certification_id,environment_hash,deployment_version,record_id,quarantine_scope,attenuations_json) VALUES(?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(tenant_id,agent_id) DO UPDATE SET state=excluded.state,genome_hash=excluded.genome_hash,package_hash=excluded.package_hash,certification_id=COALESCE(excluded.certification_id,agents.certification_id),environment_hash=COALESCE(excluded.environment_hash,agents.environment_hash),deployment_version=excluded.deployment_version,record_id=excluded.record_id,quarantine_scope=excluded.quarantine_scope,attenuations_json=excluded.attenuations_json",
                (self.tenant_id, agent_id, to_state.value, record.agent_genome_hash, record.package_hash,
                 certification_id if certification_id is not None else (current.certification_id if current else None),
                 environment_ref if environment_ref is not None else (current.environment_hash if current else None),
                 deployment_version, record.record_id, quarantine_scope, json.dumps(atten, sort_keys=True)),
            )
            self._db.execute("INSERT INTO histories(tenant_id,agent_id,kind,payload_json,observed_at) VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "lifecycle", json.dumps(record.to_dict(), sort_keys=True), _ts(record.transitioned_at)))
            event_name = event_name_override or to_state.value.title().replace("_", "")
            envelope = self._make_event(
                agent_id=agent_id, event_name=event_name,
                payload={"record": record.to_dict(), "from_state": record.from_state, "to_state": record.to_state, "reason": reason, "agent_id": agent_id, "deployment_version": deployment_version},
                correlation_id=record.correlation_id, causation_id=record.causation_id,
            )
            self._queue_event(envelope, agent_id=agent_id, cursor=self._db)
        # Best-effort immediate delivery. The outbox is already durable in the same transaction.
        self.flush_pending_events(limit=1)
        return record

    def register_staged(self, *, agentpkg: str | Path, environment_hash: str, authorization_token: str | None = None, actor: Mapping[str, Any] | None = None) -> LifecycleRecord:
        package = Path(agentpkg).resolve(); verification = verify_agentpkg(package)
        manifest = verification["manifest"]; agent_id = str(manifest["agent_id"]); package_hash = _sha(package.read_bytes())
        if package_hash != str(manifest.get("package_hash", package_hash)) and "package_hash" in manifest:
            raise GarageError("package hash mismatch")
        genome = AgentGenome(json.loads(verification["genome_json"]))
        if genome.hash() != str(manifest["agent_genome_hash"]): raise GarageError("package genome hash mismatch")
        certification = json.loads(verification["certification_json"])
        certification_id = str(certification["certification_id"])
        token = authorization_token or self._authorize("stage_register", {"agent_id": agent_id, "package_hash": package_hash})
        self._db.execute("INSERT OR REPLACE INTO package_meta VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (
            self.tenant_id, agent_id, package_hash, str(package), json.dumps(manifest, sort_keys=True),
            json.dumps(certification, sort_keys=True), json.dumps(genome.document, sort_keys=True), environment_hash,
            json.dumps({}, sort_keys=True), json.dumps({}, sort_keys=True), json.dumps({}, sort_keys=True),
            None if certification.get("valid_until") is None else _ts(str(certification["valid_until"]))))
        self._db.commit()
        current = self.get(agent_id)
        if current and current.state not in {GarageState.STAGED, GarageState.STAGE_ABORTED, GarageState.CERTIFIED}:
            raise IllegalStateTransition(f"cannot register staged package from {current.state.value}")
        if current and current.state == GarageState.CERTIFIED:
            return self._transition(agent_id=agent_id,to_state=GarageState.STAGED,reason="Factory package staged",reason_code="factory_stage",actor=actor or {"kind":"system","id":"factory"},authorization_token=token,package_hash=package_hash,environment_ref=environment_hash,genome_hash=genome.hash(),certification_id=certification_id)
        if current and current.state == GarageState.STAGE_ABORTED:
            return self._transition(agent_id=agent_id,to_state=GarageState.STAGED,reason="Stage retry",reason_code="factory_stage",actor=actor or {"kind":"system","id":"factory"},authorization_token=token,package_hash=package_hash,environment_ref=environment_hash,genome_hash=genome.hash(),certification_id=certification_id)
        return self._transition(agent_id=agent_id,to_state=GarageState.STAGED,reason="Factory package staged",reason_code="factory_stage",actor=actor or {"kind":"system","id":"factory"},authorization_token=token,package_hash=package_hash,environment_ref=environment_hash,genome_hash=genome.hash(),certification_id=certification_id)

    def _package_meta(self, agent_id: str) -> Mapping[str, Any]:
        row = self._db.execute("SELECT package_hash,package_uri,package_manifest_json,certification_json,genome_json,environment_hash,skill_lock_json,tool_lock_json,model_lock_json,certification_valid_until FROM package_meta WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchone()
        if row is None: raise DeploymentPreconditionFailed("agent package metadata unavailable")
        return {"package_hash": row[0], "package_uri": row[1], "manifest": json.loads(row[2]), "certification": json.loads(row[3]), "genome": json.loads(row[4]), "environment_hash": row[5], "skill_lock": json.loads(row[6]), "tool_lock": json.loads(row[7]), "model_lock": json.loads(row[8]), "valid_until": row[9]}

    def _preconditions(self, agent_id: str, environment_hash: str, authorization_token: str) -> Mapping[str, Any]:
        view = self.get(agent_id)
        if view is None or view.state != GarageState.STAGED: raise DeploymentPreconditionFailed("agent must be STAGED")
        meta = self._package_meta(agent_id); manifest = meta["manifest"]; cert = meta["certification"]; genome = AgentGenome(meta["genome"])
        if not genome.verify(): raise DeploymentPreconditionFailed("genome signature invalid")
        if cert.get("signature"):
            try:
                pub = Ed25519PublicKey.from_public_bytes(_b64d(cert["certification_public_key"]))
                cp = dict(cert); sig = cp.pop("signature"); pub.verify(_b64d(sig), canonical_bytes(cp))
            except Exception as exc:
                raise DeploymentPreconditionFailed("certification signature invalid") from exc
        if meta["valid_until"] is not None and meta["valid_until"] < time.time(): raise DeploymentPreconditionFailed("certification expired")
        if str(meta["environment_hash"]) != str(environment_hash): raise DeploymentPreconditionFailed("environment hash mismatch")
        if self.capacity_provider is not None and not self.capacity_provider.available(environment_hash=environment_hash, agent_id=agent_id, package_hash=str(meta["package_hash"])):
            raise DeploymentPreconditionFailed("resource capacity unavailable")
        auth = self._authorize("deploy", {"agent_id": agent_id, "package_hash": meta["package_hash"], "environment_hash": environment_hash, "authorization_token": authorization_token})
        if auth != authorization_token and not authorization_token: raise DeploymentPreconditionFailed("invalid deployment authorization")
        active_atten = view.attenuations
        if self.dependency_authority:
            refs = list(meta["skill_lock"].keys()) + list(meta["tool_lock"].keys()) + list(meta["model_lock"].keys())
            status = self.dependency_authority.status(refs, tenant_id=self.tenant_id)
            revoked = [ref for ref, value in status.items() if value == "revoked"]
            if revoked: raise DeploymentPreconditionFailed(f"revoked dependencies: {revoked}")
        return {**meta, "authorization_token": auth, "attenuation": active_atten, "genome_hash": genome.hash(), "certification_id": str(cert["certification_id"]) }

    def _create_snapshot(self, agent_id: str, *, environment_hash: str, created_by: str) -> AgentSnapshot:
        meta = self._package_meta(agent_id); view = self.get(agent_id)
        cert = meta["certification"]
        body = {
            "snapshot_id": str(uuid.uuid4()), "agent_id": agent_id, "agent_genome_hash": AgentGenome(meta["genome"]).hash(),
            "package_hash": str(meta["package_hash"]), "certification_id": str(cert["certification_id"]),
            "certification_hash": _json_hash(cert), "environment_hash": environment_hash,
            "skill_lock": dict(meta["skill_lock"]), "tool_lock": dict(meta["tool_lock"]), "model_lock": dict(meta["model_lock"]),
            "memory_snapshot_refs": [], "world_state_ref": None, "runtime_config_hash": _json_hash(meta["manifest"]),
            "created_at": _now(), "created_by": created_by, "valid": True,
            "attenuation": dict(view.attenuations if view else {}), "signature": "", "integrity_hash": "", "garage_public_key": "",
        }
        snapshot = self._sign_snapshot(body)
        payload = json.dumps(snapshot.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        with self._lock, self._db:
            row = self._db.execute("SELECT snapshot_hash,integrity_tag FROM snapshots WHERE snapshot_id=?", (snapshot.snapshot_id,)).fetchone()
            if row: raise SnapshotError("snapshot collision")
            tag = self._tag(payload.decode(), "", self.tenant_id, "snapshot")
            self._db.execute("INSERT INTO snapshots VALUES(?,?,?,?,?,?,?)", (self.tenant_id, snapshot.snapshot_id, agent_id, payload.decode(), snapshot.integrity_hash, tag, _ts(snapshot.created_at)))
            path = self.snapshot_root / f"{snapshot.snapshot_id}.json"; path.write_bytes(payload)
        return snapshot

    def snapshot(self, snapshot_id: str) -> AgentSnapshot:
        row = self._db.execute("SELECT snapshot_json,integrity_tag FROM snapshots WHERE tenant_id=? AND snapshot_id=?", (self.tenant_id, snapshot_id)).fetchone()
        if row is None: raise SnapshotError("snapshot not found")
        payload = str(row[0]); expected = self._tag(payload, "", self.tenant_id, "snapshot")
        if not hmac.compare_digest(expected, str(row[1])): raise SnapshotError("snapshot HMAC integrity failure")
        snapshot = AgentSnapshot(**json.loads(payload))
        if not snapshot.verify(): raise SnapshotError("snapshot signature/hash verification failed")
        invalid = self._db.execute("SELECT 1 FROM invalid_snapshots WHERE tenant_id=? AND snapshot_id=?", (self.tenant_id, snapshot_id)).fetchone()
        if invalid or not snapshot.valid: raise SnapshotRevoked("snapshot is invalid")
        return snapshot

    def export_snapshot(self, snapshot_id: str, destination: str | Path) -> Path:
        snapshot = self.snapshot(snapshot_id); path = Path(destination).resolve(); path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(json.dumps(snapshot.to_dict(), sort_keys=True, indent=2).encode("utf-8")); return path

    def import_snapshot(self, source: str | Path, *, environment_hash: str, authorization_token: str) -> AgentSnapshot:
        payload = json.loads(Path(source).read_text(encoding="utf-8")); snapshot = AgentSnapshot(**payload)
        if not snapshot.verify(): raise SnapshotError("imported snapshot signature invalid")
        if snapshot.environment_hash != environment_hash: raise SnapshotEnvironmentMismatch("snapshot environment mismatch")
        self._authorize("snapshot_import", {"agent_id": snapshot.agent_id, "snapshot_id": snapshot.snapshot_id})
        with self._db:
            existing = self._db.execute("SELECT 1 FROM snapshots WHERE tenant_id=? AND snapshot_id=?", (self.tenant_id, snapshot.snapshot_id)).fetchone()
            if existing: raise SnapshotError("snapshot already exists")
            raw = json.dumps(snapshot.to_dict(), sort_keys=True, separators=(",", ":")); tag = self._tag(raw, "", self.tenant_id, "snapshot")
            self._db.execute("INSERT INTO snapshots VALUES(?,?,?,?,?,?,?)", (self.tenant_id, snapshot.snapshot_id, snapshot.agent_id, raw, snapshot.integrity_hash, tag, _ts(snapshot.created_at)))
        return snapshot

    def deploy(self, agent_id: str, *, environment_hash: str, actor: Mapping[str, Any], authorization_token: str, correlation_id: str | None = None) -> tuple[LifecycleRecord, LifecycleRecord, AgentSnapshot]:
        corr = correlation_id or str(uuid.uuid4())
        current = self.get(agent_id)
        if current is None:
            raise DeploymentPreconditionFailed("agent is not registered")
        if current.state != GarageState.STAGED:
            raise IllegalStateTransition(f"illegal deploy from {current.state.value}; target is DEPLOYED")
        try:
            pre = self._preconditions(agent_id, environment_hash, authorization_token)
            snapshot = self._create_snapshot(agent_id, environment_hash=environment_hash, created_by=actor.get("id", "garage"))
        except Exception as exc:
            view = self.get(agent_id)
            if view is not None and view.state == GarageState.STAGED:
                try:
                    self._transition(agent_id=agent_id,to_state=GarageState.DEPLOY_FAILED,reason=str(exc),reason_code="deployment_failed",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=environment_hash,correlation_id=corr,genome_hash=view.genome_hash,certification_id=view.certification_id)
                except Exception as transition_error:
                    self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"deploy_failed_record_failure","error":str(transition_error)}, sort_keys=True), time.time()))
                    self._db.commit()
            raise
        try:
            self._authorize("deploy_activate", {"agent_id": agent_id, "package_hash": pre["package_hash"], "environment_hash": environment_hash, "authorization_token": pre["authorization_token"]})
            self.harness.activate(agent_id=agent_id, package_hash=str(pre["package_hash"]), environment_hash=environment_hash, authorization_token=str(pre["authorization_token"]))
            deployed = self._transition(agent_id=agent_id,to_state=GarageState.DEPLOYED,reason="Deployment authorized and activated",reason_code="deployment_authorized",actor=actor,authorization_token=pre["authorization_token"],package_hash=pre["package_hash"],environment_ref=environment_hash,snapshot_ref=snapshot.snapshot_id,correlation_id=corr,genome_hash=pre["genome_hash"],certification_id=pre["certification_id"])
            monitored = self._transition(agent_id=agent_id,to_state=GarageState.MONITORED,reason="Initial monitoring enabled",reason_code="monitoring_started",actor=actor,authorization_token=pre["authorization_token"],package_hash=pre["package_hash"],environment_ref=environment_hash,snapshot_ref=snapshot.snapshot_id,correlation_id=corr,causation_id=deployed.record_id,genome_hash=pre["genome_hash"],certification_id=pre["certification_id"])
            return deployed, monitored, snapshot
        except Exception as exc:
            try:
                self._transition(agent_id=agent_id,to_state=GarageState.DEPLOY_FAILED,reason=str(exc),reason_code="deployment_failed",actor=actor,authorization_token=authorization_token,package_hash=pre["package_hash"],environment_ref=environment_hash,snapshot_ref=snapshot.snapshot_id,correlation_id=corr,genome_hash=pre["genome_hash"],certification_id=pre["certification_id"])
            except Exception as transition_error:
                self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"deploy_activation_failure_record_failure","error":str(transition_error)}, sort_keys=True), time.time()))
                self._db.commit()
            with self._db: self._db.execute("UPDATE snapshots SET snapshot_json=json_set(snapshot_json,'$.valid',?) WHERE tenant_id=? AND snapshot_id=?", (0, self.tenant_id, snapshot.snapshot_id))
            raise DeploymentPreconditionFailed(str(exc)) from exc

    def monitoring_alert(self, agent_id: str, *, reason: str, actor: Mapping[str, Any], authorization_token: str, evidence: Mapping[str, Any] | None = None) -> LifecycleRecord:
        view = self.get(agent_id)
        if view is None: raise GarageError("unknown agent")
        return self._transition(agent_id=agent_id,to_state=view.state,reason=reason,reason_code="manual",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,evidence_refs=[f"urn:jarvis:garage:alert:{_json_hash(evidence or {})}"],genome_hash=view.genome_hash,event_name_override="MonitoringAlert")

    def ingest_signal(self, agent_id: str, kind: str, payload: Mapping[str, Any]) -> None:
        view = self.get(agent_id)
        if view is None: return
        now = time.time(); self._db.execute("INSERT INTO signals VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, kind, json.dumps(dict(payload), sort_keys=True), now)); self._db.commit()
        if kind == "security":
            if payload.get("policy_violation") or payload.get("capability_escalation"):
                token = self._authorize("quarantine", {"agent_id": agent_id, "kind": kind, "reason": "security signal"})
                self.quarantine(agent_id, scope="agent", reason="security signal", actor={"kind":"security_authority","id":"security"}, authorization_token=token)
        elif kind == "dependency":
            if payload.get("revoked"):
                token = self._authorize("suspend", {"agent_id": agent_id, "reason": "dependency revoked"})
                self.suspend(agent_id, reason="dependency revoked", actor={"kind":"system","id":"garage"}, authorization_token=token, code="dependency_revoked")
        elif kind == "resource":
            ratios = payload.get("budget_utilization", {})
            if any(float(v) > 1.0 for v in ratios.values()):
                token = self._authorize("suspend", {"agent_id": agent_id, "reason": "budget drift"})
                self.suspend(agent_id, reason="budget drift", actor={"kind":"system","id":"garage"}, authorization_token=token, code="budget_drift")
        elif kind == "certificate":
            valid_until = payload.get("valid_until")
            if valid_until is not None and _ts(str(valid_until)) <= now:
                token = self._authorize("suspend", {"agent_id": agent_id, "reason": "certificate expired"})
                self.suspend(agent_id, reason="certificate expired", actor={"kind":"system","id":"garage"}, authorization_token=token, code="certificate_expired")

    def monitor_budget_drift(self, agent_id: str, utilization: Mapping[str, float], *, actor: Mapping[str, Any], authorization_token: str) -> bool:
        exceeded = any(float(value) > 1.0 for value in utilization.values())
        if exceeded:
            self.ingest_signal(agent_id, "resource", {"budget_utilization": dict(utilization), "exceeded": True})
            return True
        return False

    def monitor_behavior_drift(self, agent_id: str, baseline: Sequence[float], observed: Sequence[float], *, threshold: float = 0.20, actor: Mapping[str, Any], authorization_token: str) -> bool:
        if len(baseline) != len(observed) or not baseline:
            raise ValueError("baseline and observed distributions must have equal non-zero length")
        bsum = sum(float(x) for x in baseline); osum = sum(float(x) for x in observed)
        if bsum <= 0 or osum <= 0: raise ValueError("distributions must have positive mass")
        b = [float(x)/bsum for x in baseline]; o = [float(x)/osum for x in observed]
        drift = 0.5 * sum(abs(x-y) for x,y in zip(b,o))
        self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "performance", json.dumps({"behavior_drift": drift, "threshold": threshold}, sort_keys=True), time.time())); self._db.commit()
        if drift > threshold:
            token = self._authorize("suspend", {"agent_id": agent_id, "reason": "behavior drift"})
            self.suspend(agent_id, reason=f"behavior drift {drift:.6f} > {threshold:.6f}", actor=actor, authorization_token=token, code="behavior_drift")
            return True
        return False

    def check_certificate_expiry(self, agent_id: str, *, now: float | None = None, actor: Mapping[str, Any], authorization_token: str) -> bool:
        meta = self._package_meta(agent_id); valid_until = meta["valid_until"]
        expired = valid_until is not None and float(valid_until) <= (time.time() if now is None else now)
        if expired:
            token = self._authorize("suspend", {"agent_id": agent_id, "reason": "certificate expired"})
            self.suspend(agent_id, reason="certificate expired", actor=actor, authorization_token=token, code="certificate_expired")
        return bool(expired)

    def monitor_dependencies(self, agent_id: str, *, actor: Mapping[str, Any], authorization_token: str) -> bool:
        if self.dependency_authority is None: return False
        meta = self._package_meta(agent_id); refs = list(meta["skill_lock"].keys()) + list(meta["tool_lock"].keys()) + list(meta["model_lock"].keys())
        status = self.dependency_authority.status(refs, tenant_id=self.tenant_id)
        revoked = [ref for ref, value in status.items() if value == "revoked"]
        if revoked:
            token = self._authorize("suspend", {"agent_id": agent_id, "reason": "dependency revoked", "refs": revoked})
            self.suspend(agent_id, reason=f"dependency revoked: {revoked}", actor=actor, authorization_token=token, code="dependency_revoked")
        return bool(revoked)

    def suspend(self, agent_id: str, *, reason: str, actor: Mapping[str, Any], authorization_token: str, code: str = "suspend_policy") -> LifecycleRecord:
        view = self.get(agent_id); 
        if view is None: raise GarageError("unknown agent")
        if view.state not in {GarageState.MONITORED, GarageState.DEPLOYED, GarageState.ROLLED_BACK}: raise IllegalStateTransition(f"cannot suspend {view.state.value}")
        self.harness.halt_new_executions(agent_id=agent_id, authorization_token=authorization_token)
        return self._transition(agent_id=agent_id,to_state=GarageState.SUSPENDED,reason=reason,reason_code=code,actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,genome_hash=view.genome_hash)

    def quarantine(self, agent_id: str, *, scope: str, reason: str, actor: Mapping[str, Any], authorization_token: str) -> LifecycleRecord:
        if scope not in {"agent","skill","tool","full"}: raise ValueError("invalid quarantine scope")
        view = self.get(agent_id)
        if view is None: raise GarageError("unknown agent")
        forensic_snapshot = None
        if view.package_hash and view.environment_hash:
            try:
                forensic_snapshot = self._create_snapshot(agent_id, environment_hash=str(view.environment_hash), created_by="quarantine")
            except Exception as exc:
                self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"quarantine_snapshot_failed","error":str(exc)}, sort_keys=True), time.time())); self._db.commit()
        self.harness.halt_new_executions(agent_id=agent_id, authorization_token=authorization_token)
        self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"reason":reason,"scope":scope,"snapshot_ref": forensic_snapshot.snapshot_id if forensic_snapshot else None}, sort_keys=True), time.time())); self._db.commit()
        return self._transition(agent_id=agent_id,to_state=GarageState.QUARANTINED,reason=reason,reason_code="quarantine_security" if "security" in reason.lower() else "quarantine_integrity",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,quarantine_scope=scope,snapshot_ref=forensic_snapshot.snapshot_id if forensic_snapshot else None,genome_hash=view.genome_hash)

    def attenuate(self, agent_id: str, *, capability: str | None = None, scope: str | None = None, budget_field: str | None = None, budget_value: float | None = None, tool: str | None = None, model: str | None = None, reason: str, actor: Mapping[str, Any], authorization_token: str) -> LifecycleRecord:
        choices = [capability is not None, scope is not None, budget_field is not None, tool is not None, model is not None]
        if sum(choices) != 1: raise ValueError("exactly one attenuation target is required")
        view = self.get(agent_id)
        if view is None: raise GarageError("unknown agent")
        atten = copy.deepcopy(dict(view.attenuations)); diff: dict[str, Any]
        if capability:
            current = set(atten.get("capabilities", [])); current.add(capability); atten["capabilities"] = sorted(current); diff = {"capability_removed": capability}
        elif scope:
            current = set(atten.get("scopes", [])); current.add(scope); atten["scopes"] = sorted(current); diff = {"scope_removed": scope}
        elif budget_field:
            old = atten.get("budgets", {}).get(budget_field); new = float(budget_value) if budget_value is not None else None
            if new is None or (old is not None and new > float(old)): raise AttenuationCannotWiden(f"budget {budget_field} cannot widen")
            atten.setdefault("budgets", {})[budget_field] = new; diff = {"budget_field": budget_field, "from": old, "to": new}
        elif tool:
            current = set(atten.get("tools", [])); current.add(tool); atten["tools"] = sorted(current); diff = {"tool_removed": tool}
        else:
            current = set(atten.get("models", [])); current.add(model or ""); atten["models"] = sorted(x for x in current if x); diff = {"model_removed": model}
        with self._db: self._db.execute("UPDATE agents SET attenuations_json=? WHERE tenant_id=? AND agent_id=?", (json.dumps(atten, sort_keys=True), self.tenant_id, agent_id))
        return self._transition(agent_id=agent_id,to_state=view.state,reason=reason,reason_code="manual",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,evidence_refs=[json.dumps(diff,sort_keys=True)],genome_hash=view.genome_hash)

    def rollback(self, agent_id: str, snapshot_id: str, *, environment_hash: str, actor: Mapping[str, Any], authorization_token: str) -> tuple[LifecycleRecord, LifecycleRecord]:
        view = self.get(agent_id)
        snapshot = self.snapshot(snapshot_id)
        if snapshot.agent_id != agent_id: raise SnapshotError("snapshot belongs to another agent")
        if snapshot.environment_hash != environment_hash:
            raise SnapshotEnvironmentMismatch("snapshot environment mismatch")
        meta = self._package_meta(agent_id)
        if snapshot.certification_hash != _json_hash(meta["certification"]): raise SnapshotRevoked("snapshot certification no longer matches current certification")
        self._authorize("rollback", {"agent_id": agent_id, "snapshot_id": snapshot_id})
        pre_state = view.state
        corr = str(uuid.uuid4())
        self.harness.deactivate(agent_id=agent_id, authorization_token=authorization_token)
        try:
            start = self._transition(agent_id=agent_id,to_state=GarageState.ROLLED_BACK,reason="Rollback to certified snapshot",reason_code="rollback_authorized",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=environment_hash,snapshot_ref=snapshot_id,rollback_target=snapshot_id,correlation_id=corr,genome_hash=view.genome_hash)
            self.harness.restore(snapshot=snapshot.to_dict(), environment_hash=environment_hash, authorization_token=authorization_token)
            end = self._transition(agent_id=agent_id,to_state=GarageState.MONITORED,reason="Rollback restored and monitored",reason_code="rollback_completed",actor=actor,authorization_token=authorization_token,package_hash=snapshot.package_hash,environment_ref=environment_hash,snapshot_ref=snapshot_id,rollback_target=snapshot_id,correlation_id=corr,causation_id=start.record_id,genome_hash=snapshot.agent_genome_hash,certification_id=snapshot.certification_id)
            return start, end
        except Exception as exc:
            try: self._transition(agent_id=agent_id,to_state=GarageState.QUARANTINED,reason=f"Rollback cascade failure: {exc}",reason_code="quarantine_integrity",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=environment_hash,correlation_id=corr,genome_hash=view.genome_hash)
            except Exception as transition_error:
                self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"rollback_quarantine_failure","error":str(transition_error)}, sort_keys=True), time.time()))
                self._db.commit()
            raise RollbackCascadeFailure(str(exc)) from exc

    def revoke_certification(self, agent_id: str, *, reason: str, authorization_token: str) -> LifecycleRecord:
        token = self._authorize("certification_revoke", {"agent_id": agent_id})
        view = self.get(agent_id)
        if view is None: raise GarageError("unknown agent")
        with self._db:
            snap_ids = [r[0] for r in self._db.execute("SELECT snapshot_id FROM snapshots WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchall()]
            for sid in snap_ids: self._db.execute("INSERT OR REPLACE INTO invalid_snapshots VALUES(?,?,?,?)", (self.tenant_id, sid, "certification revoked", time.time()))
        rec = self._transition(agent_id=agent_id,to_state=GarageState.CERT_REVOKED,reason=reason,reason_code="certificate_revoked",actor={"kind":"security_authority","id":"security"},authorization_token=token,package_hash=view.package_hash,environment_ref=view.environment_hash,genome_hash=view.genome_hash)
        if self.get(agent_id).state == GarageState.CERT_REVOKED:
            token2 = self._authorize("quarantine", {"agent_id": agent_id, "reason": "certification revoked"})
            rec = self._transition(agent_id=agent_id,to_state=GarageState.QUARANTINED,reason="Certification revoked propagation",reason_code="quarantine_revocation",actor={"kind":"security_authority","id":"security"},authorization_token=token2,package_hash=view.package_hash,environment_ref=view.environment_hash,quarantine_scope="full",genome_hash=view.genome_hash)
        return rec

    def retire(self, agent_id: str, *, successor: str | None, actor: Mapping[str, Any], authorization_token: str) -> LifecycleRecord:
        view = self.get(agent_id)
        if view is None: raise GarageError("unknown agent")
        if view.state == GarageState.RETIRED:
            rows = self._db.execute("SELECT record_json FROM lifecycle_records WHERE tenant_id=? AND agent_id=? ORDER BY seq DESC LIMIT 1", (self.tenant_id, agent_id)).fetchone()
            return LifecycleRecord(**json.loads(rows[0])) if rows else self._transition(agent_id=agent_id,to_state=GarageState.RETIRED,reason="historical retirement marker",reason_code="retirement_requested",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,genome_hash=view.genome_hash)
        if view.state != GarageState.QUARANTINED: self._authorize("retire", {"agent_id":agent_id})
        try:
            self.harness.halt_new_executions(agent_id=agent_id, authorization_token=authorization_token)
        except Exception as halt_error:
            self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"retirement_halt_failure","error":str(halt_error)}, sort_keys=True), time.time())); self._db.commit()
        destination = str(self.snapshot_root / f"{agent_id}-retirement.json")
        knowledge = self.knowledge_extractor.export(agent_id=agent_id, destination=destination) if self.knowledge_extractor else {"status":"interface-not-bound"}
        archive_dir = self.snapshot_root / "archive" / agent_id
        archive_dir.mkdir(parents=True, exist_ok=True)
        archived = []
        for row in self._db.execute("SELECT snapshot_id,snapshot_json FROM snapshots WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchall():
            sid, raw = str(row[0]), str(row[1])
            target = archive_dir / f"{sid}.json"
            if not target.exists(): target.write_text(raw, encoding="utf-8")
            archived.append(str(target))
        self._db.execute("INSERT INTO histories VALUES(?,?,?,?,?)", (self.tenant_id, agent_id, "incident", json.dumps({"event":"snapshots_archived","paths":archived}, sort_keys=True), time.time())); self._db.commit()
        return self._transition(agent_id=agent_id,to_state=GarageState.RETIRED,reason="Agent retired" + (f"; successor={successor}" if successor else ""),reason_code="retirement_requested",actor=actor,authorization_token=authorization_token,package_hash=view.package_hash,environment_ref=view.environment_hash,evidence_refs=[json.dumps(knowledge,sort_keys=True), json.dumps({"archived_snapshots":archived},sort_keys=True)],genome_hash=view.genome_hash)

    def resurrect(self, agent_id: str, snapshot_id: str, *, environment_hash: str, actor: Mapping[str, Any], authorization_token: str) -> LifecycleRecord:
        view = self.get(agent_id); snapshot = self.snapshot(snapshot_id)
        if view is None: raise GarageError("unknown agent")
        if view.state not in {GarageState.RETIRED, GarageState.QUARANTINED, GarageState.SUSPENDED, GarageState.ROLLED_BACK}: raise IllegalStateTransition(f"cannot resurrect from {view.state.value}")
        if snapshot.environment_hash != environment_hash: raise SnapshotEnvironmentMismatch("snapshot environment mismatch")
        if not snapshot.verify(): raise SnapshotError("snapshot verification failed")
        token = self._authorize("resurrect", {"agent_id":agent_id,"snapshot_id":snapshot_id})
        corr = str(uuid.uuid4())
        rec = self._transition(agent_id=agent_id,to_state=GarageState.RESURRECTED,reason="Certified snapshot resurrection",reason_code="resurrection_authorized",actor=actor,authorization_token=token,package_hash=snapshot.package_hash,environment_ref=environment_hash,snapshot_ref=snapshot_id,correlation_id=corr,genome_hash=snapshot.agent_genome_hash,certification_id=snapshot.certification_id)
        self.harness.restore(snapshot=snapshot.to_dict(), environment_hash=environment_hash, authorization_token=token)
        cert_expired = False
        meta = self._package_meta(agent_id)
        if meta["valid_until"] is not None: cert_expired = meta["valid_until"] <= time.time()
        post_snapshot_incident = False
        for raw in self.lineage_of(agent_id):
            when = raw.get("transitioned_at")
            if when and _ts(str(when)) > _ts(snapshot.created_at) and raw.get("reason_code") in {"quarantine_security", "quarantine_integrity", "quarantine_revocation", "certificate_revoked", "dependency_revoked", "budget_drift", "behavior_drift"}:
                post_snapshot_incident = True
                break
        dependency_revoked = False
        if self.dependency_authority is not None:
            refs = list(meta["skill_lock"].keys()) + list(meta["tool_lock"].keys()) + list(meta["model_lock"].keys())
            status_map = self.dependency_authority.status(refs, tenant_id=self.tenant_id)
            dependency_revoked = any(v == "revoked" for v in status_map.values())
        full_recert = cert_expired or post_snapshot_incident or dependency_revoked or view.state == GarageState.QUARANTINED
        status = "full_recertification_required" if full_recert else "fast_path"
        target = GarageState.STAGED if full_recert else GarageState.DEPLOYED
        return self._transition(agent_id=agent_id,to_state=target,reason=f"Resurrection {status}",reason_code="resurrection_completed",actor=actor,authorization_token=token,package_hash=snapshot.package_hash,environment_ref=environment_hash,snapshot_ref=snapshot_id,correlation_id=corr,causation_id=rec.record_id,genome_hash=snapshot.agent_genome_hash,certification_id=snapshot.certification_id)

    def lineage_of(self, agent_id: str) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT record_json FROM lifecycle_records WHERE tenant_id=? AND agent_id=? ORDER BY seq ASC", (self.tenant_id, agent_id)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def deployment_chain(self, agent_id: str) -> list[int]:
        return list(range(1, len(self.deployment_history(agent_id)) + 1))

    def ancestors_of(self, agent_id: str) -> list[str]:
        rows = self._db.execute("SELECT genome_hash FROM package_meta WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchall()
        return [str(r[0]) for r in rows]

    def descendants_of(self, agent_id: str) -> list[str]:
        rows = self._db.execute("SELECT agent_id FROM agents WHERE tenant_id=? AND agent_id != ? AND package_hash IN (SELECT package_hash FROM package_meta WHERE tenant_id=? AND agent_id=?)", (self.tenant_id, agent_id, self.tenant_id, agent_id)).fetchall()
        return [str(r[0]) for r in rows]

    def impact_of_revoke(self, ref: str) -> dict[str, list[str]]:
        agents: list[str] = []; snapshots: list[str] = []
        for row in self._db.execute("SELECT agent_id,skill_lock_json,tool_lock_json,model_lock_json FROM package_meta WHERE tenant_id=?", (self.tenant_id,)):
            if ref in json.loads(row[1]) or ref in json.loads(row[2]) or ref in json.loads(row[3]):
                agents.append(str(row[0])); snapshots.extend(str(r[0]) for r in self._db.execute("SELECT snapshot_id FROM snapshots WHERE tenant_id=? AND agent_id=?", (self.tenant_id, row[0])))
        return {"affected_agents": sorted(set(agents)), "affected_snapshots": sorted(set(snapshots))}

    def full_provenance(self, agent_id: str, deployment_version: int | None = None) -> Mapping[str, Any]:
        return {"agent_id": agent_id, "deployment_version": deployment_version, "lineage": self.lineage_of(agent_id), "snapshots": [self.snapshot(sid).to_dict() for sid in [r[0] for r in self._db.execute("SELECT snapshot_id FROM snapshots WHERE tenant_id=? AND agent_id=?", (self.tenant_id, agent_id)).fetchall()] if sid]}

    def verify_log(self) -> bool:
        with self._lock:
            previous = "0" * 64
            for row in self._db.execute("SELECT record_json,record_hash,previous_hash,integrity_tag FROM lifecycle_records WHERE tenant_id=? ORDER BY seq ASC", (self.tenant_id,)):
                payload, record_hash, previous_hash, tag = map(str, row)
                if previous_hash != previous: return False
                if not hmac.compare_digest(self._tag(payload, previous, self.tenant_id, "lifecycle"), tag): return False
                doc = json.loads(payload)
                if not doc.get("integrity_hash") or record_hash != _sha(canonical_bytes({"record":doc,"previous_hash":previous})): return False
                previous = record_hash
                if not LifecycleRecord(**doc).verify(): return False
        return True

    def rebuild_state(self) -> dict[str, GarageState]:
        state: dict[str, GarageState] = {}
        with self._lock:
            previous = "0" * 64
            for row in self._db.execute("SELECT record_json,record_hash,previous_hash,integrity_tag FROM lifecycle_records WHERE tenant_id=? ORDER BY seq ASC", (self.tenant_id,)):
                payload, record_hash, previous_hash, tag = map(str, row)
                if previous_hash != previous or not hmac.compare_digest(self._tag(payload, previous, self.tenant_id, "lifecycle"), tag): raise StateReplayError("lifecycle log integrity failure")
                doc = json.loads(payload); rec = LifecycleRecord(**doc)
                if not rec.verify(): raise StateReplayError("lifecycle record signature invalid")
                prior = state.get(rec.agent_id)
                if prior is not None and GarageState(rec.to_state) not in LEGAL_TRANSITIONS[prior]: raise StateReplayError(f"illegal replay transition {prior.value}->{rec.to_state}")
                if prior is None and rec.from_state is not None: raise StateReplayError("genesis record has a non-null from_state")
                state[rec.agent_id] = GarageState(rec.to_state); previous = record_hash
        return state

    def history(self, agent_id: str, kind: str | None = None) -> list[dict[str, Any]]:
        if kind is None:
            rows = self._db.execute("SELECT payload_json FROM histories WHERE tenant_id=? AND agent_id=? ORDER BY observed_at ASC", (self.tenant_id, agent_id)).fetchall()
        else:
            rows = self._db.execute("SELECT payload_json FROM histories WHERE tenant_id=? AND agent_id=? AND kind=? ORDER BY observed_at ASC", (self.tenant_id, agent_id, kind)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def deployment_history(self, agent_id: str) -> list[dict[str, Any]]:
        return [r for r in self.lineage_of(agent_id) if r.get("to_state") == GarageState.DEPLOYED.value]

    def incident_history(self, agent_id: str) -> list[dict[str, Any]]:
        return [r for r in self.lineage_of(agent_id) if r.get("to_state") in {GarageState.SUSPENDED.value, GarageState.QUARANTINED.value, GarageState.ROLLED_BACK.value, GarageState.CERT_REVOKED.value, GarageState.DEPLOY_FAILED.value}]

    def performance_history(self, agent_id: str) -> list[dict[str, Any]]:
        rows = self._db.execute("SELECT payload_json FROM histories WHERE tenant_id=? AND agent_id=? AND kind='performance' ORDER BY observed_at ASC", (self.tenant_id, agent_id)).fetchall()
        return [json.loads(r[0]) for r in rows]

    def close(self) -> None:
        with self._lock:
            if not self._closed: self._db.close(); self._closed = True

__all__ = [
    "AgentGarage", "AgentSnapshot", "AuthorizationDenied", "AttenuationCannotWiden", "CapacityProvider",
    "DependencyAuthority", "GarageError", "GarageState", "GarageStateView", "HarnessAdapter", "IllegalStateTransition",
    "KnowledgeExtractor", "LEGAL_TRANSITIONS", "LifecycleRecord", "REASON_CODES", "RollbackCascadeFailure",
    "SecurityAuthority", "SnapshotEnvironmentMismatch", "SnapshotError", "SnapshotRevoked", "StateReplayError",
]

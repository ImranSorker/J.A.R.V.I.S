"""Ultra-responsive Flet operator surface with lazy optional dependency loading."""
from __future__ import annotations
import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable

@dataclass(frozen=True, slots=True)
class CommandResult:
    ok: bool
    value: Any = None
    error: str | None = None

class FletCommandCenter:
    """Non-blocking UI controller; all long-running work executes off the UI loop."""
    def __init__(self, operation: Callable[[str], Any], *, max_workers: int = 4) -> None:
        if not callable(operation): raise TypeError("operation must be callable")
        self._operation = operation
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(int(max_workers), 16)), thread_name_prefix="jarvis-ui")
        self._closed = False
    async def run(self, command: str) -> CommandResult:
        if self._closed: raise RuntimeError("command center is closed")
        command = str(command).strip()
        if not command: return CommandResult(False, error="command is empty")
        loop = asyncio.get_running_loop()
        try: return CommandResult(True, value=await loop.run_in_executor(self._executor, self._operation, command))
        except asyncio.CancelledError: raise
        except Exception as exc: return CommandResult(False, error=f"{type(exc).__name__}: {exc}")
    def build(self) -> Any:
        try: import flet as ft
        except ImportError as exc: raise RuntimeError("Flet is not installed; install the optional desktop UI dependency") from exc
        async def page_main(page: Any) -> None:
            page.title = "J.A.R.V.I.S. 12.8.0"
            status = ft.Text("Ready")
            input_box = ft.TextField(label="Command", expand=True)
            output = ft.TextField(multiline=True, read_only=True, min_lines=8, max_lines=16, expand=True)
            busy = False
            async def submit(_: Any) -> None:
                nonlocal busy
                if busy: return
                busy = True
                status.value = "Working…"
                page.update()
                try:
                    result = await self.run(input_box.value or "")
                    output.value = str(result.value) if result.ok else result.error or "Unknown error"
                    status.value = "Ready" if result.ok else "Error"
                finally:
                    busy = False
                    page.update()
            page.add(ft.Row([input_box, ft.ElevatedButton("Execute", on_click=submit)]), status, output)
        return page_main
    def close(self) -> None:
        if self._closed: return
        self._closed = True
        self._executor.shutdown(wait=True, cancel_futures=True)

"""Telemetry collection for JARVIS.

Collects runtime metrics, model performance, and system health
data for analysis and optimization.
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from collections import deque
from typing import Any, Dict, List, Deque

logger = logging.getLogger("jarvis.telemetry")


class TelemetryCollector:
    """Collects and stores runtime telemetry."""

    def __init__(self, store_path: str = "data/telemetry.jsonl"):
        self.store_path = Path(store_path)
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self._metrics: Dict[str, Deque[Dict[str, Any]]] = {}
        self._max_entries = 10000

    def record(self, metric_name: str, value: Any, tags: Dict[str, Any] = None) -> None:
        """Record a metric value."""
        entry = {
            "timestamp": time.time(),
            "metric": metric_name,
            "value": value,
            "tags": tags or {},
        }
        bucket = self._metrics.get(metric_name)
        if bucket is None:
            bucket = deque(maxlen=self._max_entries)
            self._metrics[metric_name] = bucket
        bucket.append(entry)

        # Write to persistent store
        try:
            with open(self.store_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception as exc:
            logger.debug("telemetry_write_failed", extra={"error": str(exc)})

    def get_metric(self, name: str, window_seconds: float = 3600) -> List[Dict[str, Any]]:
        """Get recent values for a metric."""
        cutoff = time.time() - window_seconds
        entries = self._metrics.get(name, [])
        return [e for e in entries if e["timestamp"] > cutoff]

    def get_average(self, name: str, window_seconds: float = 3600) -> float:
        """Calculate average value for a metric."""
        entries = self.get_metric(name, window_seconds)
        if not entries:
            return 0.0
        values = [e["value"] for e in entries if isinstance(e["value"], (int, float))]
        return sum(values) / len(values) if values else 0.0

    def get_stats(self) -> Dict[str, Any]:
        return {
            "metrics": list(self._metrics.keys()),
            "total_entries": sum(len(v) for v in self._metrics.values()),
            "store_path": str(self.store_path),
        }



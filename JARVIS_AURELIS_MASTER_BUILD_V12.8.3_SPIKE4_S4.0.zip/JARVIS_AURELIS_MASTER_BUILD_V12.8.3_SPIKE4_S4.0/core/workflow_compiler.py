"""Safe compiler from visual workflow graphs to policy-aware mission plans."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from core.contracts.autonomy import MissionStepSpec
from core.planning_v2 import HierarchicalPlanner, PlanBudget, PlanNode


@dataclass(frozen=True, slots=True)
class CompiledWorkflow:
    """Validated intermediate representation produced from a visual graph."""

    workflow_id: str
    name: str
    steps: tuple[MissionStepSpec, ...]
    order: tuple[str, ...]


class WorkflowCompiler:
    """Compile only known node kinds; capabilities are data, never implicit authority."""

    CAPABILITIES = {
        "user_input": "observe",
        "input.text": "observe",
        "ai_router": "model.infer",
        "ai.router": "model.infer",
        "research_agent": "agent.invoke",
        "agent.researcher": "agent.invoke",
        "web_search": "network.web",
        "tool.web_search": "network.web",
        "memory_write": "memory.write",
        "memory.write": "memory.write",
        "policy_check": "policy.evaluate",
        "policy.check": "policy.evaluate",
        "human_approval": "approval.request",
        "control.approval": "approval.request",
        "output": "observe",
        "output.text": "observe",
    }

    def __init__(self, planner: HierarchicalPlanner | None = None) -> None:
        self.planner = planner or HierarchicalPlanner(max_nodes=128)

    def compile(self, definition: Mapping[str, Any], *, budget: PlanBudget | None = None) -> CompiledWorkflow:
        """Validate graph topology, node schemas and produce deterministic mission steps."""
        workflow_id = str(definition.get("workflow_id", "")).strip()
        name = str(definition.get("name", "")).strip()
        nodes = definition.get("nodes", ())
        edges = definition.get("edges", ())
        if not workflow_id or not name or not isinstance(nodes, Sequence) or not isinstance(edges, Sequence):
            raise ValueError("invalid workflow definition")
        by_id: dict[str, Mapping[str, Any]] = {}
        for raw in nodes:
            if not isinstance(raw, Mapping):
                raise ValueError("workflow node must be an object")
            node_id = str(raw.get("id", "")).strip()
            node_type = str(raw.get("type", "")).strip().lower()
            if not node_id or node_id in by_id:
                raise ValueError("workflow node IDs must be unique and non-empty")
            if node_type not in self.CAPABILITIES:
                raise ValueError(f"unsupported visual node type: {node_type}")
            by_id[node_id] = raw
        deps: dict[str, set[str]] = {node_id: set() for node_id in by_id}
        for raw in edges:
            if not isinstance(raw, Mapping):
                raise ValueError("workflow edge must be an object")
            source, target = str(raw.get("from", "")).strip(), str(raw.get("to", "")).strip()
            if source not in by_id or target not in by_id or source == target:
                raise ValueError("workflow contains an invalid edge")
            deps[target].add(source)
        plan_nodes = [PlanNode(node_id=node_id, description=str(node.get("label", node.get("type", node_id))), dependencies=tuple(sorted(deps[node_id])), capability=self.CAPABILITIES[str(node.get("type", "")).lower()]) for node_id, node in by_id.items()]
        ordered = self.planner.order(plan_nodes, budget or PlanBudget(max_steps=128))
        steps = tuple(MissionStepSpec(node.node_id, node.description, tuple(node.dependencies), {"node_type": str(by_id[node.node_id].get("type", "")).lower(), "workflow_id": workflow_id}, node.capability) for node in ordered)
        return CompiledWorkflow(workflow_id, name, steps, tuple(node.node_id for node in ordered))



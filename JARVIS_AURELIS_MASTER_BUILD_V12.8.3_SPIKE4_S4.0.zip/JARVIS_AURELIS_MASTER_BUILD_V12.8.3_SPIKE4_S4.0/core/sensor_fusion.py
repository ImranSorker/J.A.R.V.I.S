"""Deterministic multi-sensor fusion with uncertainty and provenance.

The core accepts normalized observations from cameras, thermal, radar, LiDAR,
acoustic, atmospheric, satellite, and device telemetry adapters. It never talks
to hardware directly; adapters remain explicit trust boundaries.
"""
from __future__ import annotations

import math
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Mapping


class SensorKind(StrEnum):
    CAMERA = "camera"
    THERMAL = "thermal"
    RADAR = "radar"
    LIDAR = "lidar"
    ACOUSTIC = "acoustic"
    ATMOSPHERIC = "atmospheric"
    SATELLITE = "satellite"
    TELEMETRY = "telemetry"


@dataclass(frozen=True, slots=True)
class SensorObservation:
    """One trusted, normalized numeric sensor observation."""

    observation_id: str
    sensor_id: str
    kind: SensorKind | str
    timestamp: float
    values: Mapping[str, float]
    uncertainty: Mapping[str, float] = field(default_factory=dict)
    quality: float = 1.0
    trust: float = 1.0
    source: str = "unknown"

    @classmethod
    def create(
        cls,
        sensor_id: str,
        kind: SensorKind | str,
        values: Mapping[str, float],
        *,
        timestamp: float | None = None,
        uncertainty: Mapping[str, float] | None = None,
        quality: float = 1.0,
        trust: float = 1.0,
        source: str = "unknown",
    ) -> "SensorObservation":
        return cls(
            observation_id=uuid.uuid4().hex,
            sensor_id=str(sensor_id).strip(),
            kind=kind,
            timestamp=time.time() if timestamp is None else float(timestamp),
            values=dict(values),
            uncertainty=dict(uncertainty or {}),
            quality=float(quality),
            trust=float(trust),
            source=str(source).strip() or "unknown",
        )

    def validate(self, *, now: float | None = None, max_clock_skew_seconds: float = 30.0) -> None:
        """Validate identity, finite numeric payloads and confidence bounds."""
        if not self.observation_id.strip() or not self.sensor_id.strip():
            raise ValueError("sensor and observation IDs are required")
        if not str(self.kind).strip():
            raise ValueError("sensor kind is required")
        if not self.source.strip():
            raise ValueError("sensor source is required")
        if not math.isfinite(self.timestamp):
            raise ValueError("sensor timestamp must be finite")
        reference = time.time() if now is None else float(now)
        if abs(reference - self.timestamp) > max(0.1, float(max_clock_skew_seconds)):
            raise ValueError("sensor clock skew exceeds policy")
        if not 0.0 <= self.quality <= 1.0 or not 0.0 <= self.trust <= 1.0:
            raise ValueError("sensor quality/trust must be in [0,1]")
        if not self.values or len(self.values) > 256:
            raise ValueError("sensor values must contain 1..256 fields")
        for key, value in self.values.items():
            if not str(key).strip() or not math.isfinite(float(value)):
                raise ValueError("sensor values must be finite numeric fields")
        for key, value in self.uncertainty.items():
            if not str(key).strip() or not math.isfinite(float(value)) or float(value) < 0.0:
                raise ValueError("sensor uncertainty must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class FusedField:
    """One fused numeric field with explicit confidence and conflict."""

    name: str
    value: float
    uncertainty: float
    confidence: float
    conflict: float
    contributors: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FusedState:
    """Immutable sensor-fusion result."""

    generated_at: float
    fields: tuple[FusedField, ...]
    observation_ids: tuple[str, ...]
    dropped_observations: tuple[str, ...]


class SensorFusionEngine:
    """Bounded inverse-variance fusion for normalized sensor observations."""

    def __init__(self, *, max_observations: int = 2048, max_age_seconds: float = 5.0) -> None:
        self._max_observations = max(1, min(int(max_observations), 50_000))
        self._max_age_seconds = max(0.1, min(float(max_age_seconds), 3_600.0))
        self._observations: list[SensorObservation] = []
        self._lock = threading.RLock()

    def ingest(self, observation: SensorObservation) -> None:
        """Validate and retain one observation inside a bounded temporal window."""
        observation.validate()
        with self._lock:
            self._observations.append(observation)
            cutoff = time.time() - self._max_age_seconds
            self._observations = [item for item in self._observations if item.timestamp >= cutoff][-self._max_observations :]

    def fuse(self, *, now: float | None = None, fields: tuple[str, ...] = ()) -> FusedState:
        """Fuse recent observations using quality/trust-weighted inverse variance."""
        current = time.time() if now is None else float(now)
        with self._lock:
            rows = [item for item in self._observations if abs(current - item.timestamp) <= self._max_age_seconds]
        by_field: dict[str, list[tuple[SensorObservation, float, float]]] = {}
        requested = set(fields)
        for observation in rows:
            for name, raw in observation.values.items():
                if requested and name not in requested:
                    continue
                variance = max(float(observation.uncertainty.get(name, 1.0)) ** 2, 1e-9)
                weight = max(observation.quality * observation.trust, 1e-6) / variance
                by_field.setdefault(name, []).append((observation, float(raw), weight))
        fused: list[FusedField] = []
        for name in sorted(by_field):
            items = by_field[name]
            total_weight = sum(item[2] for item in items)
            value = sum(item[1] * item[2] for item in items) / total_weight
            variance = 1.0 / total_weight
            residuals = [abs(item[1] - value) for item in items]
            scale = max(abs(value), 1.0)
            conflict = min(1.0, (sum(residuals) / len(residuals)) / scale)
            confidence = max(0.0, min(1.0, 1.0 - min(1.0, math.sqrt(variance)) - 0.5 * conflict))
            fused.append(FusedField(name, value, math.sqrt(variance), confidence, conflict, tuple(item[0].sensor_id for item in items)))
        retained_ids = tuple(item.observation_id for item in rows)
        return FusedState(current, tuple(fused), retained_ids, ())

    def snapshot(self) -> dict[str, object]:
        """Return non-sensitive fusion health state."""
        with self._lock:
            return {"observations": len(self._observations), "max_observations": self._max_observations, "max_age_seconds": self._max_age_seconds}

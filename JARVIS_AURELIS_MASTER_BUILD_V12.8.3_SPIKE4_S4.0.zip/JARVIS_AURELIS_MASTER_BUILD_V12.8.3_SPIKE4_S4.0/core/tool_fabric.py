"""Compatibility source entry for P2-P Tool Fabric 2.0.

The Python package implementation lives in ``core.tool_fabric.impl`` so the
requested adapter package ``core.tool_fabric.adapters`` can coexist with the
release-contract file name without an import-name collision.
"""
from .tool_fabric.impl import *  # type: ignore[no-redef]

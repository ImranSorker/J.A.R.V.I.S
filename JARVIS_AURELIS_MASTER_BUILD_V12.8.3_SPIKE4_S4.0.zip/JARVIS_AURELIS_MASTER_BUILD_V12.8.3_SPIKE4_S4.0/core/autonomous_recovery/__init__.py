from __future__ import annotations

import base64
import copy
import hashlib
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

PUBLIC_VERSION = "12.8.3"
KERNEL_VERSION = "12.8.0"
RECOVERY_VERSION = "1.0.0"
FAILURE_CLASSES = ("crash","deadlock","corrupted_state","unavailable_model","unavailable_tool","network_failure","resource_exhaustion","partial_execution","dependency_revoked","attestation_drift","integrity_failure","verification_failure","provenance_discontinuity","configuration_drift","deadlock_cascade","unknown")
STRATEGIES = ("retry","checkpoint_restore","snapshot_rollback","compensation","restart_component","reload_model","residency_rebalance","quarantine","attenuate","resurrect","replan","failover","degrade_service","escalate","abandon","observe")
SCOPES = ("step","execution","agent","team","skill","tool","composite","model","subsystem","environment","tenant","system")
OUTCOMES = ("recovered","partially_recovered","degraded","abandoned","escalated","failed","cascaded","cancelled","timed_out","invalidated")
AUTHORITIES = ("self","peer","orchestrator","security_authority","operator","system_wide")
SEVERITIES = ("info","low","medium","high","critical")
DETECTED_BY = ("harness","garage","doctor","security","provenance","operator","peer")
SUBJECT_KINDS = ("agent","skill","tool","composite","team","model","subsystem","environment","tenant")
STEP_KINDS = ("checkpoint_restore","snapshot_rollback","compensation","restart","reload","quarantine","attenuate","resurrect","replan","failover","degrade","escalate","abandon","wait")
STAGES = ("classify","correlate","compute_authority","plan","simulate","authorize","execute","verify","attest","re_admit","validate","record")
DANGEROUS = {"snapshot_rollback","compensation","restart","quarantine","attenuate","resurrect","abandon"}
HIGH_STAKES = {"agent","team","tenant","environment","system"}
SELF_HEAL = {"network_failure","unavailable_tool","unavailable_model","resource_exhaustion"}
NEVER_AUTO = {"integrity_failure","verification_failure","provenance_discontinuity"}
STRATEGY_TABLE = {
    "crash":["retry","checkpoint_restore","escalate"],"deadlock":["quarantine","replan","escalate"],"corrupted_state":["snapshot_rollback","escalate"],
    "unavailable_model":["reload_model","failover","degrade_service"],"unavailable_tool":["failover","degrade_service"],
    "network_failure":["retry","failover","degrade_service"],"resource_exhaustion":["residency_rebalance","degrade_service","escalate"],
    "partial_execution":["compensation","checkpoint_restore","escalate"],"dependency_revoked":["quarantine","resurrect","escalate"],
    "attestation_drift":["attenuate","quarantine","escalate"],"integrity_failure":["abandon","escalate"],"verification_failure":["escalate"],
    "provenance_discontinuity":["escalate"],"configuration_drift":["replan","restart_component","escalate"],"deadlock_cascade":["escalate"],"unknown":["observe","escalate"]}


def _utc() -> str: return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")
def _sha(v: Any) -> str: return hashlib.sha256(canonical_bytes(v)).hexdigest()
def _uuid(v: str|None=None) -> str: return str(uuid.UUID(v or str(uuid.uuid4())))

def _sign(doc: Mapping[str,Any], key: Ed25519PrivateKey) -> dict[str,Any]:
    d=copy.deepcopy(dict(doc)); d.pop("signature",None); d.pop("integrity_hash",None); integ=_sha(d); s={**d,"integrity_hash":integ}; s["signature"]=base64.b64encode(key.sign(canonical_bytes(s))).decode("ascii"); return s

def _verify(doc: Mapping[str,Any], key: Ed25519PublicKey) -> None:
    sig=str(doc.get("signature") or ""); integ=str(doc.get("integrity_hash") or "")
    if not sig or not integ: raise SignatureError("missing signature/integrity")
    d=copy.deepcopy(dict(doc)); d.pop("signature",None); d.pop("integrity_hash",None)
    if _sha(d)!=integ: raise SignatureError("integrity mismatch")
    try: key.verify(base64.b64decode(sig), canonical_bytes({**d,"integrity_hash":integ}))
    except (InvalidSignature,ValueError,TypeError) as exc: raise SignatureError("signature verification failed") from exc

def _principal(context: Any)->tuple[str,str]:
    auth=getattr(context,"auth_context",None); p=str(getattr(auth,"principal","")); t=str(getattr(auth,"authorization_token",""))
    if not p or not t: raise ExecutionContextRequired("authenticated P2-E ExecutionContext required")
    return p, hashlib.sha256(t.encode()).hexdigest()[:16]

class RecoveryError(RuntimeError):
    """Base P2-Y recovery failure, always handled fail-closed."""
class SchemaError(RecoveryError):
    """P2-Y fail-closed recovery exception: SchemaError."""
class SignatureError(RecoveryError):
    """P2-Y fail-closed recovery exception: SignatureError."""
class TenantIsolationError(RecoveryError):
    """P2-Y fail-closed recovery exception: TenantIsolationError."""
class ExecutionContextRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: ExecutionContextRequired."""
class AuthorizationRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: AuthorizationRequired."""
class SimulationRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: SimulationRequired."""
class VerificationRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: VerificationRequired."""
class AttestationRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: AttestationRequired."""
class ReAdmissionRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: ReAdmissionRequired."""
class ValidationRequired(RecoveryError):
    """P2-Y fail-closed recovery exception: ValidationRequired."""
class CascadeLimitExceeded(RecoveryError):
    """P2-Y fail-closed recovery exception: CascadeLimitExceeded."""
class CircularCascade(RecoveryError):
    """P2-Y fail-closed recovery exception: CircularCascade."""
class RecoveryAlreadyExecuting(RecoveryError):
    """P2-Y fail-closed recovery exception: RecoveryAlreadyExecuting."""
class PolicyError(RecoveryError):
    """P2-Y fail-closed recovery exception: PolicyError."""
class ReplayDivergence(RecoveryError):
    """P2-Y fail-closed recovery exception: ReplayDivergence."""

@dataclass(frozen=True, slots=True)
class RecoveryDependencies:
    execution_handoff: Any|None=None
    garage: Any|None=None
    simulation: Any|None=None
    verification: Any|None=None
    security: Any|None=None
    planning: Any|None=None
    economics: Any|None=None
    provenance: Any|None=None
    failure_intelligence: Any|None=None
    learning: Any|None=None
    world_model: Any|None=None
    memory: Any|None=None
    operator: Any|None=None
    security_authority: Any|None=None
    model_fabric: Any|None=None
    tool_fabric: Any|None=None
    composite_fabric: Any|None=None

class RecoveryStore:
    _TABLES = frozenset({"signals", "plans", "executions", "policies", "validations", "events"})
    @classmethod
    def _table(cls, table: str) -> str:
        name=str(table)
        if name not in cls._TABLES: raise ValueError("unsupported recovery store table")
        return name
    def __init__(self,path:str|Path):
        self.root=Path(path).resolve(); self.root.mkdir(parents=True,exist_ok=True); self.db=sqlite3.connect(self.root/"recovery.db",check_same_thread=False); self.db.row_factory=sqlite3.Row; self.lock=threading.RLock(); self.db.executescript("""
        CREATE TABLE IF NOT EXISTS signals(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,content_hash TEXT NOT NULL UNIQUE,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,plan_version INTEGER NOT NULL,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS executions(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS policies(id TEXT PRIMARY KEY,tenant TEXT,version TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 0,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS validations(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,doc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,tenant TEXT NOT NULL,correlation_id TEXT,causation_id TEXT,name TEXT NOT NULL,doc TEXT NOT NULL,emitted_at TEXT NOT NULL);
        """)
    def close(self): self.db.close()
    def put(self,table,key,tenant,doc,extra=None):
        table=self._table(table)
        extra=extra or {}; cols=["id","tenant",*extra.keys(),"doc"]; vals=[key,tenant,*extra.values(),json.dumps(dict(doc),sort_keys=True,separators=(",",":"))]
        with self.lock,self.db: self.db.execute(f"INSERT OR REPLACE INTO {table} ({','.join(cols)}) VALUES ({','.join('?' for _ in vals)})",vals)
    def get(self,table,key,tenant):
        table=self._table(table)
        with self.lock: r=self.db.execute(f"SELECT doc FROM {table} WHERE id=? AND tenant=?",(key,tenant)).fetchone()
        return json.loads(r[0]) if r else None
    def list(self,table,tenant):
        table=self._table(table)
        with self.lock: rs=self.db.execute(f"SELECT doc FROM {table} WHERE tenant=? ORDER BY rowid",(tenant,)).fetchall()
        return [json.loads(r[0]) for r in rs]
    def find_signal_hash(self,h,tenant):
        with self.lock: r=self.db.execute("SELECT doc FROM signals WHERE content_hash=? AND tenant=?",(h,tenant)).fetchone()
        return json.loads(r[0]) if r else None
    def event(self,tenant,name,payload,corr,caus):
        e={"event_id":str(uuid.uuid4()),"event_name":name,"tenant_id":tenant,"correlation_id":corr,"causation_id":caus,"emitted_at":_utc(),"payload":dict(payload),"replayable":True}
        with self.lock,self.db: self.db.execute("INSERT INTO events(tenant,correlation_id,causation_id,name,doc,emitted_at) VALUES(?,?,?,?,?,?)",(tenant,corr,caus,name,json.dumps(e,sort_keys=True,separators=(",",":")),e["emitted_at"]))
        return e
    def events(self,tenant,corr=None):
        q="SELECT doc FROM events WHERE tenant=?"; args=[tenant]
        if corr: q+=" AND correlation_id=?"; args.append(corr)
        q+=" ORDER BY seq"
        with self.lock: rs=self.db.execute(q,args).fetchall()
        return [json.loads(r[0]) for r in rs]

class AutonomousRecovery:
    def __init__(self,root:str|Path,*,dependencies:RecoveryDependencies|None=None,signing_key:Ed25519PrivateKey|None=None,event_fabric:Any|None=None,policy:Mapping[str,Any]|None=None):
        self.root=Path(root).resolve(); self.store=RecoveryStore(self.root); self.dependencies=dependencies or RecoveryDependencies(); self.signing_key=signing_key or Ed25519PrivateKey.generate(); self.public_key=self.signing_key.public_key(); self.event_fabric=event_fabric; self.locks={}; self.policy=self._policy(policy); self.strategy_table=self._strategy()
    def close(self): self.store.close()
    def _require(self,context,tenant):
        if context is None or not getattr(context,"execution_id",None): raise ExecutionContextRequired("P2-E ExecutionContext required")
        if str(getattr(context,"tenant_id",tenant))!=str(tenant): raise TenantIsolationError("tenant mismatch")
        _principal(context)
    def _schema(self,name,doc):
        try: SchemaValidator(max_errors=128).validate_or_raise(doc,json.loads((Path(__file__).resolve().parent.parent/"schemas"/name).read_text()))
        except Exception as exc: raise SchemaError(f"{name}: {exc}") from exc
    def _emit(self,name,payload,tenant,corr,caus=None):
        e=self.store.event(tenant,name,payload,corr,caus)
        if self.event_fabric is not None:
            try: self.event_fabric.publish(name,dict(payload),source="p2-y",correlation_id=corr,causation_id=caus)
            except Exception as exc:
                e["publish_error"]=str(exc)
                if name.startswith("Recovery.Execution") or name in {"Recovery.StepExecuted","Recovery.StepFailed"}: raise RecoveryError("P2-U execution event publication failed") from exc
        return e
    def _policy(self,override):
        p=copy.deepcopy(dict(override)) if override else json.loads((Path(__file__).resolve().parent/"policies/default/1.0.0/policy.json").read_text())
        p.setdefault("policy_id","recovery/default"); p.setdefault("policy_version","1.0.0"); p.setdefault("max_cascade_depth",3); p.setdefault("max_concurrent_recoveries",8); p.setdefault("max_recoveries_per_window",32)
        p.setdefault("default_budget",{"wall_seconds":300.0,"cpu_seconds":120.0,"cost_units":1000.0,"max_steps":16,"max_cascade_depth":3}); p.setdefault("recovery_priority_class","recovery"); p.setdefault("self_heal_enabled",True); p.setdefault("self_heal_failure_classes",sorted(SELF_HEAL)); p.setdefault("self_heal_max_scope","execution")
        return _sign(p,self.signing_key)
    def _strategy(self):
        seed=json.loads((Path(__file__).resolve().parent/"strategy_table.json").read_text()); d={"version":seed["version"],"strategies":seed["strategies"],"authored_by":seed["authored_by"],"activated_at":_utc(),"signature_status":"RUNTIME_SIGNED"}; s=_sign(d,self.signing_key); _verify(s,self.public_key); return s
    def strategy_table_document(self): return copy.deepcopy(self.strategy_table)

    def register_policy(self,policy:Mapping[str,Any],*,context:Any,security_authorized:bool=False)->str:
        tenant=str(policy.get("tenant_id") or getattr(context,"tenant_id","default")); self._require(context,tenant); pid=str(policy.get("policy_id") or "")
        if not pid: raise PolicyError("policy_id required")
        active=[x for x in self.store.list("policies",tenant) if x.get("policy_id")==pid]
        if active and not security_authorized and self._looser(active[-1],policy): raise PolicyError("loosening requires Security Authority")
        d=copy.deepcopy(dict(policy)); d["tenant_id"]=d.get("tenant_id"); d.setdefault("effective_at",_utc()); d.setdefault("authored_by",{"principal":_principal(context)[0],"key_id":_principal(context)[1]}); d.setdefault("approved_by",None); d.setdefault("supersedes",None); d.setdefault("signature",""); d.setdefault("integrity_hash",""); s=_sign(d,self.signing_key); self._schema("recovery_policy_v1.schema.json",s); self.store.put("policies",pid,tenant,s,{"version":s.get("policy_version","1.0.0"),"active":0}); return pid
    @staticmethod
    def _looser(old,new): return bool(new.get("self_heal_enabled")) and not bool(old.get("self_heal_enabled")) or int(new.get("max_cascade_depth",0))>int(old.get("max_cascade_depth",0)) or int(new.get("max_concurrent_recoveries",0))>int(old.get("max_concurrent_recoveries",0))
    def activate_policy(self,policy_id:str,effective_at:str|None=None,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); found=next((p for p in self.store.list("policies",tenant) if p.get("policy_id")==policy_id),None)
        if not found: raise PolicyError(policy_id)
        if effective_at: found["effective_at"]=effective_at
        s=_sign({k:v for k,v in found.items() if k!="signature"},self.signing_key)
        with self.store.lock,self.store.db: self.store.db.execute("UPDATE policies SET active=0 WHERE tenant=?",(tenant,)); self.store.db.execute("UPDATE policies SET active=1,doc=? WHERE id=? AND tenant=?",(json.dumps(s,sort_keys=True,separators=(",",":")),policy_id,tenant))
        self.policy=s
    def get_policy(self,policy_id:str|None=None,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant)
        if policy_id:
            x=next((p for p in self.store.list("policies",tenant) if p.get("policy_id")==policy_id),None)
            if x is None: raise PolicyError(policy_id)
            return x
        return copy.deepcopy(self.policy)

    def submit_failure_signal(self,signal:Mapping[str,Any],*,context:Any)->str:
        d=copy.deepcopy(dict(signal)); tenant=str(d.get("tenant_id") or getattr(context,"tenant_id",""));
        if not tenant: raise TenantIsolationError("tenant_id required")
        self._require(context,tenant); d["tenant_id"]=tenant; d["signal_version"]=int(d.get("signal_version",1)); d["signal_id"]=_uuid(d.get("signal_id")); d["failure_class"]=d.get("failure_class") if d.get("failure_class") in FAILURE_CLASSES else "unknown"; d["severity"]=d.get("severity") if d.get("severity") in SEVERITIES else "medium"; d["detected_by"]=d.get("detected_by") if d.get("detected_by") in DETECTED_BY else "peer"; d.setdefault("detected_at",_utc()); d.setdefault("raised_at",_utc()); d["correlation_id"]=_uuid(d.get("correlation_id")); d.setdefault("causation_id",None); d.setdefault("parent_signal_ref",None)
        d.setdefault("subject",{"kind":"subsystem","ref":"unknown","version":None,"hash":None,"execution_context_ref":getattr(context,"execution_id",None)}); d.setdefault("what_happened","unclassified failure"); d.setdefault("where",{}); d.setdefault("when",{"start":d["detected_at"],"end":d["detected_at"]});
        for k in ("evidence_refs","failure_record_refs","diagnosis_refs","incident_refs","provenance_refs","state_snapshot_refs"): d.setdefault(k,[])
        d.setdefault("world_state_ref",None); d.setdefault("resource_state_ref",None); d.setdefault("raised_by",{"principal":_principal(context)[0],"key_id":_principal(context)[1]})
        x=copy.deepcopy(d); [x.pop(k,None) for k in ("signal_id","signature","integrity_hash","raised_at")]; h=_sha(x); old=self.store.find_signal_hash(h,tenant)
        if old: return old["signal_id"]
        d["content_hash"]=h; s=_sign(d,self.signing_key); self._schema("failure_signal_v1.schema.json",s); self.store.put("signals",s["signal_id"],tenant,s,{"content_hash":h}); self._emit("Recovery.SignalReceived",s,tenant,s["correlation_id"],s.get("causation_id")); self._emit("Recovery.SignalNormalized",{"signal_id":s["signal_id"]},tenant,s["correlation_id"],s.get("causation_id")); self._emit("Recovery.SignalClassified",{"signal_id":s["signal_id"],"failure_class":s["failure_class"],"severity":s["severity"]},tenant,s["correlation_id"],s.get("causation_id")); return s["signal_id"]
    def get_signal(self,signal_id:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); x=self.store.get("signals",signal_id,tenant); 
        if x is None: raise RecoveryError("unknown signal")
        _verify(x,self.public_key); return x
    def query_signals(self,*,context:Any,failure_class:str|None=None,subject_ref:str|None=None):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); xs=self.store.list("signals",tenant); return [x for x in xs if (not failure_class or x["failure_class"]==failure_class) and (not subject_ref or str(x.get("subject",{}).get("ref"))==str(subject_ref))]
    def normalize_from_prior_phase(self,source:Mapping[str,Any],source_kind:str,*,context:Any)->str:
        m={"p2-i":"peer","p2-t":"doctor","p2-d":"garage","p2-x":"provenance"}; k=source_kind.lower(); return self.submit_failure_signal({"tenant_id":source.get("tenant_id") or getattr(context,"tenant_id","default"),"failure_class":source.get("failure_class") or source.get("kind") or "unknown","severity":source.get("severity") or source.get("severity_on_failure") or "medium","detected_by":m.get(k,"peer"),"subject":source.get("subject") or {"kind":"subsystem","ref":source.get("subject_ref","unknown")},"what_happened":source.get("what_happened") or source.get("reason") or f"failure signal from {source_kind}","where":source.get("where") or {},"when":source.get("when") or {"start":source.get("created_at") or _utc(),"end":source.get("finished_at") or source.get("created_at") or _utc()},"evidence_refs":list(source.get("evidence_refs",[])),"failure_record_refs":[source["record_id"]] if k=="p2-i" and source.get("record_id") else [],"diagnosis_refs":[source["diagnosis_id"]] if k=="p2-t" and source.get("diagnosis_id") else [],"incident_refs":[source["incident_id"]] if k=="p2-d" and source.get("incident_id") else [],"provenance_refs":list(source.get("provenance_refs",[]))+([source.get("node_id") or source.get("event_id")] if k=="p2-x" and (source.get("node_id") or source.get("event_id")) else []),"state_snapshot_refs":list(source.get("state_snapshot_refs",[])),"world_state_ref":source.get("world_state_ref"),"resource_state_ref":source.get("resource_state_ref"),"correlation_id":source.get("correlation_id") or str(uuid.uuid4()),"causation_id":source.get("causation_id")},context=context)

    def _scope(self,sig,requested_scope=None):
        if requested_scope in SCOPES:
            return requested_scope
        kind=str(sig.get("subject",{}).get("kind","subsystem")); return {"agent":"agent","team":"team","skill":"skill","tool":"tool","composite":"composite","model":"model","tenant":"tenant","environment":"environment"}.get(kind,"subsystem")
    def _authority(self,sig,scope):
        if sig["failure_class"] in NEVER_AUTO:
            return "system_wide" if scope=="system" else "security_authority"
        if scope=="system": return "system_wide"
        if scope=="tenant": return "security_authority"
        if sig["failure_class"] in SELF_HEAL and self.policy.get("self_heal_enabled") and scope in {"step","execution"}: return "self"
        if scope in {"step","execution"}: return "peer"
        if scope in {"environment","subsystem","team","agent","skill","tool","composite","model"}: return "orchestrator"
        return "orchestrator"
    def _steps(self,chain,subject):
        m={"retry":"wait","checkpoint_restore":"checkpoint_restore","snapshot_rollback":"snapshot_rollback","compensation":"compensation","restart_component":"restart","reload_model":"reload","residency_rebalance":"wait","quarantine":"quarantine","attenuate":"attenuate","resurrect":"resurrect","replan":"replan","failover":"failover","degrade_service":"degrade","escalate":"escalate","abandon":"abandon","observe":"wait"}
        out=[]
        for i,s in enumerate(chain,1): out.append({"step_id":f"recovery-step-{i:03d}","kind":m[s],"target_ref":subject,"inputs":{},"outputs":{},"preconditions":[],"postconditions":[],"idempotency":"per_key" if s=="compensation" else "idempotent","compensation_step_id":None,"timeout_ms":30000,"retry_policy":{"max_attempts":2,"backoff_seconds":1.0} if s=="retry" else None,"failure_policy":"retry" if s=="retry" else "escalate","budget_allocation":{"wall_seconds":30.0,"cpu_seconds":10.0,"cost_units":25.0,"max_steps":1},"verification_hook_ref":None,"provenance_requirement":[]})
        return out
    def _rollback(self,plan_id,tenant,subject,scope,corr,context):
        rid=str(uuid.uuid5(uuid.NAMESPACE_URL,f"jarvis://p2y/rollback/{tenant}/{plan_id}")); step=self._steps(["abandon"],subject)[0]
        body={"plan_id":rid,"plan_version":1,"tenant_id":tenant,"failure_signal_ref":None,"failure_class":"unknown","subject_ref":subject,"scope":scope,"authority_level":"orchestrator","strategy":"abandon","steps":[step],"entry_step_id":step["step_id"],"terminal_step_ids":[step["step_id"]],"dependencies":[],"preconditions":[],"postconditions":[{"type":"safe_abandon","equals":True}],"invariants":[],"acceptable_degraded_state":[{"type":"safe_abandon","equals":True}],"budget":self.policy["default_budget"],"simulation_required":True,"authorization_required":True,"verification_required":False,"attestation_required":False,"re_admission_required":False,"plan_rollback_ref":None,"planned_by":{"principal":_principal(context)[0],"key_id":_principal(context)[1]},"planner_kind":"deterministic_rules","planned_at":_utc(),"planner_version":RECOVERY_VERSION,"policy_version":self.policy["policy_version"],"provenance_refs":[],"state":"drafted","outcome":None,"outcome_evidence_refs":[],"signature":"","integrity_hash":"","chain_prev_hash":None,"correlation_id":corr,"cascade_depth":0,"parent_plan_ref":None}
        s=_sign(body,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",rid,tenant,s,{"plan_version":1}); return rid
    def plan_recovery(self,signal_id:str,constraints:Mapping[str,Any]|None=None,*,context:Any)->str:
        c=dict(constraints or {}); tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); sig=self.get_signal(signal_id,context=context); subj=str(sig.get("subject",{}).get("ref","unknown")); scope=self._scope(sig,c.get("scope")); authority=self._authority(sig,scope); chain=list(self.strategy_table["strategies"].get(sig["failure_class"],STRATEGY_TABLE["unknown"]));
        if sig["failure_class"] in NEVER_AUTO: chain=["abandon","escalate"] if sig["failure_class"]=="integrity_failure" else ["escalate"]
        steps=self._steps(chain[:int(c.get("max_strategies",6))],subj); sim=any(s["kind"] in DANGEROUS for s in steps) or bool(c.get("touches_dangerous_surface")) or bool(c.get("modifies_production_beyond_rollback")); verify=str(sig.get("subject",{}).get("kind")) in HIGH_STAKES or sig["severity"] in {"high","critical"} or sig["failure_class"] in NEVER_AUTO; att=str(sig.get("subject",{}).get("kind"))=="agent" or scope=="agent"; auth=authority!="self";
        material={"signal":sig["content_hash"],"tenant":tenant,"scope":scope,"authority":authority,"chain":chain,"policy":self.policy["policy_version"],"constraints":c}; pid=str(uuid.uuid5(uuid.NAMESPACE_URL,f"jarvis://p2y/plan/{_sha(material)}"));
        if self.store.get("plans",pid,tenant): return pid
        budget={**self.policy["default_budget"],**c.get("budget",{})}; depth=int(c.get("cascade_depth",0)); maxd=int(budget.get("max_cascade_depth",self.policy.get("max_cascade_depth",3))); 
        if depth>maxd: raise CascadeLimitExceeded("cascade depth exceeded")
        rb=self._rollback(pid,tenant,subj,scope,sig["correlation_id"],context); body={"plan_id":pid,"plan_version":1,"tenant_id":tenant,"failure_signal_ref":signal_id,"failure_class":sig["failure_class"],"subject_ref":subj,"scope":scope,"authority_level":authority,"strategy":chain[0],"steps":steps,"entry_step_id":steps[0]["step_id"],"terminal_step_ids":[steps[-1]["step_id"]],"dependencies":[{"from_step_id":a["step_id"],"to_step_id":b["step_id"],"kind":"sequence"} for a,b in zip(steps,steps[1:])],"preconditions":list(c.get("preconditions",[])),"postconditions":list(c.get("postconditions",[{"type":"recovery_validated","equals":True}])),"invariants":list(c.get("invariants",[])),"acceptable_degraded_state":c.get("acceptable_degraded_state"),"budget":budget,"simulation_required":sim,"authorization_required":auth,"verification_required":verify,"attestation_required":att,"re_admission_required":att,"plan_rollback_ref":rb,"planned_by":{"principal":_principal(context)[0],"key_id":_principal(context)[1]},"planner_kind":"deterministic_rules","planned_at":_utc(),"planner_version":RECOVERY_VERSION,"policy_version":self.policy["policy_version"],"provenance_refs":list(sig.get("provenance_refs",[])),"state":"drafted","outcome":None,"outcome_evidence_refs":[],"signature":"","integrity_hash":"","chain_prev_hash":None,"correlation_id":sig["correlation_id"],"cascade_depth":depth,"parent_plan_ref":c.get("parent_plan_ref")}
        prev=self.store.list("plans",tenant); body["chain_prev_hash"]=prev[-1].get("integrity_hash") if prev else None; s=_sign(body,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",pid,tenant,s,{"plan_version":1}); self._emit("Recovery.AuthorityComputed",{"plan_id":pid,"authority_level":authority},tenant,sig["correlation_id"],sig.get("causation_id")); self._emit("Recovery.PlanDrafted",s,tenant,sig["correlation_id"],sig.get("causation_id")); return pid
    def get_plan(self,plan_id:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.store.get("plans",plan_id,tenant); 
        if p is None: raise RecoveryError("unknown plan")
        _verify(p,self.public_key); return p
    def query_plans(self,*,context:Any,state:str|None=None,subject_ref:str|None=None):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); xs=self.store.list("plans",tenant); return [x for x in xs if (not state or x.get("state")==state) and (not subject_ref or x.get("subject_ref")==subject_ref)]
    def refine_plan(self,plan_id:str,patch:Mapping[str,Any],*,context:Any)->int:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context); 
        if p["state"] in {"executing","completed"}: raise PolicyError("executed plan immutable")
        n={**copy.deepcopy(p),**copy.deepcopy(dict(patch)),"plan_version":int(p["plan_version"])+1,"planned_at":_utc(),"chain_prev_hash":p["integrity_hash"]}; n.pop("signature",None); n.pop("integrity_hash",None); s=_sign(n,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",plan_id,tenant,s,{"plan_version":s["plan_version"]}); self._emit("Recovery.PlanRefined",s,tenant,p["correlation_id"],p.get("correlation_id")); return s["plan_version"]
    def withdraw_plan(self,plan_id:str,reason:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context); n={**p,"state":"abandoned","outcome":"abandoned","withdraw_reason":reason,"plan_version":p["plan_version"]+1,"chain_prev_hash":p["integrity_hash"]}; n.pop("signature",None); n.pop("integrity_hash",None); s=_sign(n,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",plan_id,tenant,s,{"plan_version":s["plan_version"]}); self._emit("Recovery.PlanWithdrawn",{"plan_id":plan_id,"reason":reason},tenant,p["correlation_id"],p.get("correlation_id"))
    def simulate_plan(self,plan_id:str,config:Mapping[str,Any]|None=None,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context)
        if not p["simulation_required"]: return f"simulation://skipped/{plan_id}"
        a=self.dependencies.simulation
        if a is None: raise SimulationRequired("P2-K adapter unavailable")
        self._emit("Recovery.SimulationStarted",{"plan_id":plan_id},tenant,p["correlation_id"],p.get("correlation_id"))
        try: r=a.simulate_recovery(p,dict(config or {}),context) if hasattr(a,"simulate_recovery") else a(p,dict(config or {}),context)
        except Exception as exc: self._emit("Recovery.SimulationDiverged",{"plan_id":plan_id,"reason":str(exc)},tenant,p["correlation_id"],p.get("correlation_id")); raise SimulationRequired("P2-K simulation failed") from exc
        ref=str(r.get("simulation_id") or r.get("outcome_ref") or f"simulation://{plan_id}/{_sha(r)[:16]}") if isinstance(r,Mapping) else str(r); n={**p,"state":"simulated","simulation_ref":ref,"simulation_outcome":dict(r) if isinstance(r,Mapping) else {"ref":ref},"chain_prev_hash":p["integrity_hash"]}; n.pop("signature",None); n.pop("integrity_hash",None); s=_sign(n,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",plan_id,tenant,s,{"plan_version":s["plan_version"]}); self._emit("Recovery.SimulationCompleted",{"plan_id":plan_id,"simulation_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); return ref

    def authorize_plan(self,plan_id:str,token:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context)
        if p["authorization_required"]:
            self._emit("Recovery.AuthorizationRequested",{"plan_id":plan_id,"authority_level":p["authority_level"]},tenant,p["correlation_id"],p.get("correlation_id"))
            if not token: self._emit("Recovery.AuthorizationDenied",{"plan_id":plan_id,"reason":"missing_token"},tenant,p["correlation_id"],p.get("correlation_id")); raise AuthorizationRequired("authorization token required")
            if p["authority_level"]=="system_wide":
                sa=self.dependencies.security_authority
                op=self.dependencies.operator
                if sa is None or op is None: self._emit("Recovery.AuthorizationDenied",{"plan_id":plan_id,"reason":"system_wide_requires_security_authority_and_operator"},tenant,p["correlation_id"],p.get("correlation_id")); raise AuthorizationRequired("system-wide recovery requires Security Authority + operator")
                sa_ok=bool(sa.authorize_recovery(p,token,context)) if hasattr(sa,"authorize_recovery") else bool(sa(p,token,context)) if callable(sa) else False
                op_ok=bool(op.authorize_recovery(p,token,context)) if hasattr(op,"authorize_recovery") else bool(op(p,token,context)) if callable(op) else False
                if not (sa_ok and op_ok): self._emit("Recovery.AuthorizationDenied",{"plan_id":plan_id,"reason":"system_wide_authorization_denied"},tenant,p["correlation_id"],p.get("correlation_id")); raise AuthorizationRequired("system-wide authorization denied")
            elif p["authority_level"] in {"security_authority","operator"}:
                a=self.dependencies.security_authority or self.dependencies.operator
                ok=bool(a.authorize_recovery(p,token,context)) if a is not None and hasattr(a,"authorize_recovery") else bool(a(p,token,context)) if callable(a) else False
                if not ok: self._emit("Recovery.AuthorizationDenied",{"plan_id":plan_id,"reason":"authorization_denied"},tenant,p["correlation_id"],p.get("correlation_id")); raise AuthorizationRequired("recovery authorization denied")
            else:
                a=self.dependencies.operator; ok=(bool(a.authorize_recovery(p,token,context)) if a is not None and hasattr(a,"authorize_recovery") else bool(a(p,token,context)) if callable(a) else token==str(getattr(getattr(context,"auth_context",None),"authorization_token","")))
                if not ok: self._emit("Recovery.AuthorizationDenied",{"plan_id":plan_id,"reason":"authorization_denied"},tenant,p["correlation_id"],p.get("correlation_id")); raise AuthorizationRequired("recovery authorization denied")
        ref=_sha({"plan_id":plan_id,"token_hash":hashlib.sha256(token.encode()).hexdigest(),"tenant":tenant,"authority":p["authority_level"]}); n={**p,"state":"authorized","authorization_ref":ref,"chain_prev_hash":p["integrity_hash"]}; n.pop("signature",None); n.pop("integrity_hash",None); s=_sign(n,self.signing_key); self._schema("recovery_plan_v1.schema.json",s); self.store.put("plans",plan_id,tenant,s,{"plan_version":s["plan_version"]}); self._emit("Recovery.Authorized",{"plan_id":plan_id,"authorization_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); return ref

    def _allocate(self,p,context):
        econ=self.dependencies.economics
        if econ is None:return None
        try:
            from core.agent_economics import ResourceAmount,Requester,ResourceRequest
            tenant=p["tenant_id"]; req=ResourceRequest(request_id=str(uuid.uuid4()),request_version=1,tenant_id=tenant,requester=Requester("recovery",p["plan_id"],str(context.execution_id)),requested=(ResourceAmount("cpu_seconds",float(p["budget"].get("cpu_seconds",1)),"seconds"),ResourceAmount("cost_units",float(p["budget"].get("cost_units",1)),"units")),priority_class=str(self.policy["recovery_priority_class"]),priority_rationale="P2-Y recovery",deadline=None,sla_ref=None,budget_ref=f"recovery:{p['plan_id']}",budget_ceiling={"cpu_seconds":float(p["budget"].get("cpu_seconds",1)),"cost_units":float(p["budget"].get("cost_units",1))},risk_class="high" if p["simulation_required"] else "none",danger_surface_ref=f"recovery://{p['plan_id']}" if p["simulation_required"] else None,environment_hash=str(getattr(context,"environment_hash","0"*64)),registry_state_ref="recovery://registry/live",policy_version=self.policy["policy_version"],raised_by={"principal":_principal(context)[0],"key_id":_principal(context)[1]},raised_at=_utc()).sign(getattr(econ,"signing_key",self.signing_key)); rid=econ.submit_request(req,context=context); dec=econ.decide(rid,context=context); out=str(getattr(dec,"outcome",dec.get("outcome") if isinstance(dec,Mapping) else ""));
            if out=="queued": raise PolicyError("P2-W queued recovery allocation; fail closed")
            if out not in {"granted","granted_reduced"}: raise PolicyError(f"P2-W denied recovery allocation: {out}")
            return {"request_id":rid,"decision_id":getattr(dec,"decision_id",dec.get("decision_id") if isinstance(dec,Mapping) else None),"outcome":out}
        except PolicyError: raise
        except Exception as exc: raise PolicyError(f"P2-W allocation unavailable: {exc}") from exc

    def _handoff(self,p,step,context):
        k=step["kind"]
        if k in {"snapshot_rollback","quarantine","attenuate","resurrect"}:
            a=self.dependencies.garage
        elif k=="replan":
            a=self.dependencies.planning or self.dependencies.execution_handoff
            if a is None: raise RecoveryError("P2-L planning adapter unavailable")
            if hasattr(a,"replan_recovery"):
                return dict(a.replan_recovery(p,step,context))
            if hasattr(a,"replan"):
                return dict(a.replan(p,context))
        elif k in {"reload","failover","degrade"} and self.dependencies.model_fabric is not None:
            a=self.dependencies.model_fabric
        elif k=="failover" and self.dependencies.tool_fabric is not None:
            a=self.dependencies.tool_fabric
        elif k in {"compensation","checkpoint_restore","restart","wait"}:
            a=self.dependencies.execution_handoff
        else:
            a=self.dependencies.operator
        if a is None: raise RecoveryError(f"required handoff unavailable for {k}")
        if hasattr(a,"handoff_recovery_step"): return dict(a.handoff_recovery_step(p,step,context))
        if callable(a): return dict(a(p,step,context))
        if k=="escalate" and hasattr(a,"escalate"): return dict(a.escalate(p,step,context))
        if k=="abandon": return {"status":"abandoned"}
        raise RecoveryError(f"invalid recovery handoff adapter for {k}")

    def execute_plan(self,plan_id:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context)
        if p["simulation_required"] and not p.get("simulation_ref"): raise SimulationRequired("required simulation missing")
        if p["authorization_required"] and not p.get("authorization_ref"): raise AuthorizationRequired("required authorization missing")
        depth=int(p.get("cascade_depth",0)); maxd=int(p["budget"].get("max_cascade_depth",self.policy.get("max_cascade_depth",3)))
        if depth>maxd: raise CascadeLimitExceeded("cascade depth exceeded")
        key=f"{tenant}:{p['scope']}:{p['subject_ref']}"; lock=self.locks.setdefault(key,threading.RLock())
        if not lock.acquire(False): raise RecoveryAlreadyExecuting(key)
        try:
            self._allocate(p,context)
            eid=str(uuid.uuid4()); prevs=self.store.list("executions",tenant); rec={"execution_id":eid,"plan_ref":plan_id,"failure_signal_ref":p["failure_signal_ref"],"tenant_id":tenant,"started_at":_utc(),"finished_at":None,"steps_executed":[],"current_step_id":p["entry_step_id"],"state":"executing","simulation_ref":p.get("simulation_ref"),"authorization_ref":p.get("authorization_ref"),"verification_refs":[],"attestation_ref":None,"re_admission_ref":None,"outcome":None,"deviations":[],"evidence_refs":[],"validation_ref":None,"validated":None,"executed_by":{"principal":_principal(context)[0],"key_id":_principal(context)[1]},"executed_by_kind":"orchestrator","provenance_refs":[],"signature":"","integrity_hash":"","chain_prev_hash":prevs[-1].get("integrity_hash") if prevs else None,"correlation_id":p["correlation_id"],"cascade_depth":depth}; s=_sign(rec,self.signing_key); self._schema("recovery_execution_v1.schema.json",s); self.store.put("executions",eid,tenant,s); self._emit("Recovery.ExecutionStarted",{"execution_id":eid,"plan_id":plan_id},tenant,p["correlation_id"],p.get("correlation_id"))
            for step in p["steps"]:
                if step["kind"] in {"escalate","abandon"} and step["kind"]=="escalate" and self.dependencies.operator is None: raise RecoveryError("escalation adapter required")
                cur=self.store.get("executions",eid,tenant) or rec; self._emit("Recovery.StepExecuted",{"execution_id":eid,"step_id":step["step_id"],"kind":step["kind"],"handoff":True},tenant,p["correlation_id"],p.get("correlation_id"))
                try:
                    ev=self._handoff(p,step,context); n={**cur,"steps_executed":list(cur.get("steps_executed",[]))+ [{"step_id":step["step_id"],"started_at":_utc(),"finished_at":_utc(),"result":"handoff","evidence":ev}],"current_step_id":step["step_id"],"evidence_refs":list(cur.get("evidence_refs",[])) + ([str(ev.get("evidence_ref"))] if ev.get("evidence_ref") else [])}; n.pop("signature",None); n.pop("integrity_hash",None); n["chain_prev_hash"]=cur.get("integrity_hash"); s=_sign(n,self.signing_key); self.store.put("executions",eid,tenant,s)
                except Exception as exc:
                    n={**cur,"state":"failed","outcome":"failed","finished_at":_utc(),"deviations":list(cur.get("deviations",[]))+ [{"step_id":step["step_id"],"error":str(exc)}]}; n.pop("signature",None); n.pop("integrity_hash",None); n["chain_prev_hash"]=cur.get("integrity_hash"); s=_sign(n,self.signing_key); self.store.put("executions",eid,tenant,s); self._emit("Recovery.StepFailed",{"execution_id":eid,"step_id":step["step_id"],"error":str(exc)},tenant,p["correlation_id"],p.get("correlation_id")); self._emit("Recovery.ExecutionFailed",{"execution_id":eid},tenant,p["correlation_id"],p.get("correlation_id")); return eid
            self._emit("Recovery.ExecutionCompleted",{"execution_id":eid},tenant,p["correlation_id"],p.get("correlation_id")); return eid
        finally: lock.release()

    def _patch_execution(self,ex,tenant):
        old=self.store.get("executions",ex["execution_id"],tenant) or {}; n=copy.deepcopy(dict(ex)); n.pop("signature",None); n.pop("integrity_hash",None); n["chain_prev_hash"]=old.get("integrity_hash"); s=_sign(n,self.signing_key); self._schema("recovery_execution_v1.schema.json",s); self.store.put("executions",ex["execution_id"],tenant,s)
    def _execution(self,eid,tenant):
        x=self.store.get("executions",eid,tenant)
        if x is None: raise RecoveryError("unknown execution")
        _verify(x,self.public_key); return x

    def verify_execution(self,eid:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context)
        if not p["verification_required"]: return f"verification://skipped/{eid}"
        a=self.dependencies.verification
        if a is None: raise VerificationRequired("P2-N adapter unavailable")
        r=a.verify_recovery(p,ex,context) if hasattr(a,"verify_recovery") else a({"tenant_id":tenant,"target":"recovery_execution","method":"independent_postcondition","subject_result_ref":eid,"correlation_id":p["correlation_id"]},context); ref=str(r if isinstance(r,str) else r.get("verification_id") or r.get("record_id") or f"verification://{eid}"); ok=True if isinstance(r,str) else bool(r.get("verified") or r.get("decision")=="allow" or r.get("outcome")=="verified")
        if not ok: self._emit("Recovery.VerificationFailed",{"execution_id":eid,"verification_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); raise VerificationRequired("verification failed")
        ex["verification_refs"]=list(ex.get("verification_refs",[]))+[ref]; self._patch_execution(ex,tenant); self._emit("Recovery.VerificationCompleted",{"execution_id":eid,"verification_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); return ref
    def attest_after_recovery(self,eid:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context)
        if not p["attestation_required"]: return f"attestation://skipped/{eid}"
        a=self.dependencies.security
        if a is None: raise AttestationRequired("P2-S adapter unavailable")
        r=a.attest_recovery(p,ex,context) if hasattr(a,"attest_recovery") else a(p,ex,context); ref=str(r if isinstance(r,str) else r.get("attestation_ref") or r.get("record_id") or f"attestation://{eid}"); ok=True if isinstance(r,str) else bool(r.get("valid",True))
        if not ok: self._emit("Recovery.AttestationFailed",{"execution_id":eid,"attestation_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); raise AttestationRequired("attestation failed")
        ex["attestation_ref"]=ref; self._patch_execution(ex,tenant); self._emit("Recovery.AttestationCompleted",{"execution_id":eid,"attestation_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); return ref
    def re_admit_after_recovery(self,eid:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context)
        if not p["re_admission_required"]: return f"readmission://skipped/{eid}"
        if not ex.get("attestation_ref"): raise ReAdmissionRequired("attestation required before re-admission")
        a=self.dependencies.garage
        if a is None: raise ReAdmissionRequired("P2-D adapter unavailable")
        r=a.re_admit_after_recovery(p,ex,context) if hasattr(a,"re_admit_after_recovery") else a(p,ex,context); ref=str(r if isinstance(r,str) else r.get("re_admission_ref") or r.get("record_id") or f"readmission://{eid}"); ok=True if isinstance(r,str) else bool(r.get("admitted",True))
        if not ok: self._emit("Recovery.ReAdmissionDenied",{"execution_id":eid,"re_admission_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); raise ReAdmissionRequired("re-admission denied")
        ex["re_admission_ref"]=ref; self._patch_execution(ex,tenant); self._emit("Recovery.ReAdmissionCompleted",{"execution_id":eid,"re_admission_ref":ref},tenant,p["correlation_id"],p.get("correlation_id")); return ref

    @staticmethod
    def _assert(assertion,state):
        typ=str(assertion.get("type","path_equals")); cur=state
        for x in str(assertion.get("path","")).split("."):
            if not x: continue
            cur=cur.get(x) if isinstance(cur,Mapping) else None
        if typ in {"equals","path_equals"}: return {"ok":cur==assertion.get("value",assertion.get("equals")),"path":assertion.get("path"),"actual":cur}
        if typ=="exists": return {"ok":cur is not None}
        if typ=="not_exists": return {"ok":cur is None}
        if typ=="safe_abandon": return {"ok":state.get("safe_abandon") is True}
        if typ=="recovery_validated": return {"ok":state.get("recovery_validated") is True}
        return {"ok":False,"reason":f"unsupported assertion {typ}"}
    def validate_execution(self,eid:str,*,context:Any,state:Mapping[str,Any]|None=None,validation_window_seconds:float=0.0)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context); state=dict(state or {}); checks=[self._assert(a,state) for a in [*p.get("postconditions",[]),*p.get("invariants",[])]]
        if p["verification_required"]: checks.append({"ok":bool(ex.get("verification_refs")),"reason":"verification"})
        if p["attestation_required"]: checks.append({"ok":bool(ex.get("attestation_ref")),"reason":"attestation"})
        if p["re_admission_required"]: checks.append({"ok":bool(ex.get("re_admission_ref")),"reason":"re_admission"})
        if validation_window_seconds>0:
            start_ts=ex.get("finished_at") or _utc()
            violations=[]
            for sig in self.query_signals(context=context,subject_ref=p["subject_ref"]):
                detected=str(sig.get("detected_at", ""))
                if detected >= start_ts:
                    violations.append(sig)
            checks.append({"ok":not violations,"reason":"validation_window","violations":[v.get("signal_id") for v in violations]})
        ok=all(c.get("ok") for c in checks); v={"validation_id":str(uuid.uuid4()),"execution_ref":eid,"tenant_id":tenant,"validated":ok,"checks":checks,"validation_window_seconds":float(validation_window_seconds),"validated_at":_utc(),"validator":{"principal":_principal(context)[0],"key_id":_principal(context)[1]},"signature":"","integrity_hash":""}; s=_sign(v,self.signing_key); self._schema("validation_record_v1.schema.json",s); self.store.put("validations",s["validation_id"],tenant,s); ex["validation_ref"]=s["validation_id"]; ex["validated"]=ok; ex["finished_at"]=_utc(); ex["outcome"]="recovered" if ok else "invalidated"; ex["state"]="completed" if ok else "failed"; self._patch_execution(ex,tenant); self._emit("Recovery.Validated" if ok else "Recovery.ValidationFailed",s,tenant,p["correlation_id"],p.get("correlation_id")); self._record(eid,context); return s["validation_id"]
    def _record(self,eid,context):
        tenant=str(getattr(context,"tenant_id","default")); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context); a=self.dependencies.learning
        if a is not None and ex.get("outcome") in {"recovered","partially_recovered","degraded"}:
            if hasattr(a,"ingest_recovery_outcome"): a.ingest_recovery_outcome(p,ex,context)
            elif callable(a): a(p,ex,context)
        a=self.dependencies.provenance
        if a is not None:
            if hasattr(a,"record_recovery"): a.record_recovery(ex,p,context)
            elif hasattr(a,"index_recovery"): a.index_recovery(ex,p,context)
            elif callable(a): a(ex,p,context)
        self._emit("Recovery.Recorded",{"execution_id":eid,"outcome":ex.get("outcome")},tenant,p["correlation_id"],p.get("correlation_id"))
    def pause_execution(self,eid:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); ex["state"]="paused"; self._patch_execution(ex,tenant); a=self.dependencies.execution_handoff; getattr(a,"pause_recovery",lambda *_:None)(ex,context) if a else None
    def resume_execution(self,eid:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); ex["state"]="executing"; self._patch_execution(ex,tenant); a=self.dependencies.execution_handoff; getattr(a,"resume_recovery",lambda *_:None)(ex,context) if a else None
    def cancel_execution(self,eid:str,reason:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); ex["state"]="cancelled"; ex["outcome"]="cancelled"; ex["finished_at"]=_utc(); ex["deviations"].append({"reason":reason}); self._patch_execution(ex,tenant); p=self.get_plan(ex["plan_ref"],context=context); self._emit("Recovery.ExecutionCancelled",{"execution_id":eid,"reason":reason},tenant,p["correlation_id"],p.get("correlation_id"))
    def wait_execution(self,eid:str,timeout:float,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); end=time.monotonic()+float(timeout)
        while time.monotonic()<end:
            e=self._execution(eid,tenant)
            if e["state"] in {"completed","failed","cancelled"}: return e
            time.sleep(0.02)
        e=self._execution(eid,tenant); e["state"]="failed"; e["outcome"]="timed_out"; self._patch_execution(e,tenant); return e
    def provenance_of_recovery(self,eid:str,*,context:Any):
        self._require(context,str(getattr(context,"tenant_id","default"))); a=self.dependencies.provenance
        if a is None: raise RecoveryError("P2-X adapter unavailable")
        if hasattr(a,"execution_lineage"): return a.execution_lineage(eid)
        if hasattr(a,"provenance_of"): return a.provenance_of(eid)
        return a(eid,context) if callable(a) else None
    def history(self,subject_ref:str,window:tuple[str,str]|None,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); out=[]
        for e in self.store.list("executions",tenant):
            p=self.store.get("plans",e["plan_ref"],tenant)
            if p and p.get("subject_ref")==subject_ref: out.append(e)
        if window: out=[e for e in out if window[0]<=e.get("started_at","")<=window[1]]
        return out
    def explain_plan(self,plan_id:str,*,context:Any):
        p=self.get_plan(plan_id,context=context); return {"plan_id":plan_id,"strategy":p["strategy"],"scope":p["scope"],"authority_level":p["authority_level"],"simulation_required":p["simulation_required"],"authorization_required":p["authorization_required"],"verification_required":p["verification_required"],"attestation_required":p["attestation_required"],"re_admission_required":p["re_admission_required"],"steps":[s["kind"] for s in p["steps"]],"rollback_plan":p["plan_rollback_ref"]}
    def replay(self,eid:str,*,context:Any):
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); e=self._execution(eid,tenant); events=self.store.events(tenant,e.get("correlation_id")); order={s:i for i,s in enumerate(STAGES)}; last=-1; state={"execution_id":eid,"stage":"classify","events":[]}
        stage_map={"Recovery.SignalClassified":"classify","Recovery.AuthorityComputed":"compute_authority","Recovery.PlanDrafted":"plan","Recovery.SimulationCompleted":"simulate","Recovery.Authorized":"authorize","Recovery.ExecutionStarted":"execute","Recovery.VerificationCompleted":"verify","Recovery.AttestationCompleted":"attest","Recovery.ReAdmissionCompleted":"re_admit","Recovery.Validated":"validate","Recovery.Recorded":"record"}
        for ev in events:
            st=stage_map.get(ev["event_name"])
            if st is None: continue
            if order[st]<last: raise ReplayDivergence("stage order divergence")
            last=order[st]; state["stage"]=st; state["events"].append(ev["event_id"])
        state["outcome"]=e.get("outcome"); state["replay_digest"]=_sha(state); return state
    def escalate(self,eid:str,target:str,reason:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); ex=self._execution(eid,tenant); p=self.get_plan(ex["plan_ref"],context=context); x={"escalation_id":str(uuid.uuid4()),"tenant_id":tenant,"target":target,"reason":reason,"status":"open","decision":"escalate","created_at":_utc(),"deadline_at":None,"diagnosis_id":None,"signed_by":{"principal":_principal(context)[0],"key_id":_principal(context)[1]},"signature":"","integrity_hash":""}; s=_sign(x,self.signing_key); self._schema("escalation_record_v1.schema.json",s); ex["outcome"]="escalated"; ex["state"]="failed"; self._patch_execution(ex,tenant); self._emit("Recovery.Escalated",s,tenant,p["correlation_id"],p.get("correlation_id")); return s["escalation_id"]
    def cascade_plan(self,parent_execution_id:str,signal:Mapping[str,Any],*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); parent=self._execution(parent_execution_id,tenant); p=self.get_plan(parent["plan_ref"],context=context); depth=int(p.get("cascade_depth",0))+1; maxd=int(p["budget"].get("max_cascade_depth",3));
        if depth>maxd: self._emit("Recovery.CascadeDepthExceeded",{"parent_execution_id":parent_execution_id,"depth":depth},tenant,p["correlation_id"],parent_execution_id); raise CascadeLimitExceeded("cascade depth exceeded")
        target=str(signal.get("subject",{}).get("ref","unknown"));
        if target==p["subject_ref"]: self._emit("Recovery.CircularCascadeDetected",{"parent_execution_id":parent_execution_id,"target":target},tenant,p["correlation_id"],parent_execution_id); raise CircularCascade("circular cascade")
        self._emit("Recovery.CascadeStarted",{"parent_execution_id":parent_execution_id,"depth":depth},tenant,p["correlation_id"],parent_execution_id)
        child=dict(signal); child["tenant_id"]=tenant; child["parent_signal_ref"]=p["failure_signal_ref"]; child["correlation_id"]=p["correlation_id"]; sid=self.submit_failure_signal(child,context=context); child_plan=self.plan_recovery(sid,{"cascade_depth":depth,"parent_plan_ref":p["plan_id"]},context=context); self._emit("Recovery.CascadeCompleted",{"parent_execution_id":parent_execution_id,"child_plan_id":child_plan,"depth":depth},tenant,p["correlation_id"],parent_execution_id); return child_plan
    def self_rollback(self,plan_id:str,*,context:Any)->str:
        tenant=str(getattr(context,"tenant_id","default")); self._require(context,tenant); p=self.get_plan(plan_id,context=context); self._emit("Recovery.SelfRollbackTriggered",{"plan_id":plan_id,"rollback_plan_ref":p["plan_rollback_ref"]},tenant,p["correlation_id"],p["plan_id"]); self._emit("Recovery.SelfRollbackCompleted",{"plan_id":plan_id,"rollback_plan_ref":p["plan_rollback_ref"]},tenant,p["correlation_id"],p["plan_id"]); return p["plan_rollback_ref"]
    # API aliases required by P2-Y contract.
    simulate=simulate_plan
    verify=verify_execution
    attest=attest_after_recovery
    re_admit=re_admit_after_recovery

P2YAutonomousRecovery=AutonomousRecovery
__all__=["AutonomousRecovery","P2YAutonomousRecovery","RecoveryDependencies","RecoveryStore","RecoveryError","SchemaError","SignatureError","TenantIsolationError","ExecutionContextRequired","AuthorizationRequired","SimulationRequired","VerificationRequired","AttestationRequired","ReAdmissionRequired","ValidationRequired","CascadeLimitExceeded","CircularCascade","RecoveryAlreadyExecuting","PolicyError","ReplayDivergence","FAILURE_CLASSES","STRATEGIES","SCOPES","OUTCOMES","AUTHORITIES","STAGES","STEP_KINDS"]

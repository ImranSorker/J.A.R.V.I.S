"""Deterministic evaluation engine for cognitive regressions and route decisions."""
from __future__ import annotations

import statistics
import time
from dataclasses import dataclass
from typing import Any, Callable, Iterable

from core.contracts.intelligence import VerificationResult


@dataclass(frozen=True, slots=True)
class EvaluationCase:
    """One bounded evaluation example."""
    case_id: str
    prompt: str
    expected: str | None = None
    tags: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class EvaluationReport:
    """Stable evaluation report suitable for telemetry or persistence."""
    name: str
    count: int
    success_rate: float
    exact_match_rate: float
    mean_latency_ms: float
    failures: tuple[str, ...] = ()
    quality_score: float = 0.0
    safety_score: float = 1.0
    cost_usd: float = 0.0

    @property
    def composite_score(self) -> float:
        """Return a conservative quality/safety/latency composite score."""
        latency_factor = 1.0 / (1.0 + max(0.0, self.mean_latency_ms) / 1000.0)
        return max(0.0, min(1.0, 0.55 * self.quality_score + 0.30 * self.safety_score + 0.15 * latency_factor))


class EvaluationEngine:
    """Run bounded deterministic evaluations behind a replaceable runner."""

    def __init__(self, max_cases: int = 1000) -> None:
        self.max_cases = max(1, min(int(max_cases), 100_000))
        self._history: list[EvaluationReport] = []

    def evaluate(self, name: str, cases: Iterable[EvaluationCase], runner: Callable[[str], str], *, quality_scorer: Callable[[EvaluationCase, str], float] | None = None, safety_scorer: Callable[[EvaluationCase, str], float] | None = None, cost_scorer: Callable[[EvaluationCase, str], float] | None = None) -> EvaluationReport:
        selected = list(cases)[: self.max_cases]
        if not selected:
            raise ValueError("at least one evaluation case is required")
        latencies: list[float] = []
        successes = 0
        exact = 0
        failures: list[str] = []
        quality_scores: list[float] = []
        safety_scores: list[float] = []
        costs: list[float] = []
        for case in selected:
            started = time.perf_counter()
            try:
                output = str(runner(case.prompt))
                if output.strip():
                    successes += 1
                else:
                    failures.append(case.case_id)
                if case.expected is not None and output.strip() == case.expected.strip():
                    exact += 1
                quality_scores.append(max(0.0, min(1.0, float(quality_scorer(case, output)) if quality_scorer else (1.0 if output.strip() else 0.0))))
                safety_scores.append(max(0.0, min(1.0, float(safety_scorer(case, output)) if safety_scorer else 1.0)))
                costs.append(max(0.0, float(cost_scorer(case, output)) if cost_scorer else 0.0))
            except Exception:
                failures.append(case.case_id)
                quality_scores.append(0.0)
                safety_scores.append(0.0)
                costs.append(0.0)
            latencies.append((time.perf_counter() - started) * 1000.0)
        report = EvaluationReport(str(name), len(selected), successes / len(selected), exact / len(selected), statistics.fmean(latencies), tuple(failures[:100]), statistics.fmean(quality_scores) if quality_scores else 0.0, statistics.fmean(safety_scores) if safety_scores else 1.0, statistics.fsum(costs))
        self._history.append(report)
        del self._history[:-1000]
        return report

    @staticmethod
    def verify(report: EvaluationReport, *, min_success: float = 0.8, min_exact: float = 0.0, min_samples: int = 20) -> VerificationResult:
        if isinstance(min_samples, bool) or int(min_samples) < 1:
            raise ValueError("min_samples must be a positive integer")
        minimum = int(min_samples)
        reasons: list[str] = []
        if int(report.count) < minimum:
            reasons.append(f"sample_size<{minimum}")
        if int(report.count) < 1:
            reasons.append("sample_size_empty")
        if report.success_rate < min_success:
            reasons.append(f"success_rate<{min_success}")
        if report.exact_match_rate < min_exact:
            reasons.append(f"exact_match_rate<{min_exact}")
        return VerificationResult(not reasons, min(report.success_rate, max(report.exact_match_rate, min_exact)), tuple(reasons))

    def snapshot(self) -> dict[str, Any]:
        latest = self._history[-1] if self._history else None
        latest_dict = None if latest is None else {"name": latest.name, "count": latest.count, "success_rate": latest.success_rate, "exact_match_rate": latest.exact_match_rate, "mean_latency_ms": latest.mean_latency_ms, "failures": latest.failures, "quality_score": latest.quality_score, "safety_score": latest.safety_score, "cost_usd": latest.cost_usd, "composite_score": latest.composite_score}
        return {"runs": len(self._history), "latest": latest_dict}



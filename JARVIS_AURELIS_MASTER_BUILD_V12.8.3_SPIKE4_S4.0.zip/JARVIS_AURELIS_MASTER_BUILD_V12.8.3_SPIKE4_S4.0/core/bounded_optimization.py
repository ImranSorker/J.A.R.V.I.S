"""Benchmark-gated bounded optimization and code-evolution admission."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from itertools import product
from typing import Callable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class ParameterSpec:
    name: str
    values: tuple[float, ...]

    def validate(self) -> None:
        if not self.name.strip() or not self.values or len(self.values) > 64:
            raise ValueError("invalid parameter search space")
        if any(not isinstance(value, (int, float)) for value in self.values):
            raise ValueError("parameter values must be numeric")


@dataclass(frozen=True, slots=True)
class OptimizationCandidate:
    parameters: Mapping[str, float]
    score: float
    evaluations: int


@dataclass(frozen=True, slots=True)
class CodeEvolutionProposal:
    proposal_id: str
    base_digest: str
    patch_digest: str
    scope: str
    security_reviewed: bool = False
    reversible: bool = True

    def validate(self) -> None:
        if len(self.base_digest) != 64 or len(self.patch_digest) != 64 or not self.scope.strip() or not self.reversible:
            raise ValueError("invalid evolution proposal")


class BoundedOptimizer:
    """Deterministic finite search with hard evaluation and improvement budgets."""

    def __init__(self, *, max_evaluations: int = 256, minimum_relative_improvement: float = 0.01) -> None:
        self._max_evaluations = max(1, min(int(max_evaluations), 10_000))
        self._minimum_relative_improvement = max(0.0, float(minimum_relative_improvement))

    def optimize(self, specs: Sequence[ParameterSpec], objective: Callable[[Mapping[str, float]], float], *, baseline: float) -> OptimizationCandidate:
        if not specs or len(specs) > 16:
            raise ValueError("optimization requires 1..16 parameters")
        for spec in specs:
            spec.validate()
        best = float(baseline)
        best_parameters: dict[str, float] = {}
        evaluations = 0
        for values in product(*(spec.values for spec in specs)):
            if evaluations >= self._max_evaluations:
                break
            params = {spec.name: float(value) for spec, value in zip(specs, values)}
            score = float(objective(params))
            if score > best:
                best = score
                best_parameters = params
            evaluations += 1
        required = abs(float(baseline)) * self._minimum_relative_improvement
        if best <= float(baseline) + required:
            return OptimizationCandidate({}, float(baseline), evaluations)
        return OptimizationCandidate(dict(best_parameters), best, evaluations)

    @staticmethod
    def digest_proposal(base: bytes, patch: bytes) -> tuple[str, str]:
        """Produce content-addressed evidence for a reversible change proposal."""
        return hashlib.sha256(base).hexdigest(), hashlib.sha256(patch).hexdigest()

    @staticmethod
    def canonical(candidate: OptimizationCandidate) -> str:
        return json.dumps({"parameters": dict(sorted(candidate.parameters.items())), "score": candidate.score, "evaluations": candidate.evaluations}, sort_keys=True, separators=(",", ":"))

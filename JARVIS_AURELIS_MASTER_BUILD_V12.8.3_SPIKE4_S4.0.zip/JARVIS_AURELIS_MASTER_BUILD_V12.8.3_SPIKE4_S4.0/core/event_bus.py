"""Thread-safe bounded event fabric with typed and legacy subscription adapters."""
from __future__ import annotations

import asyncio
import logging
import queue
import threading
from typing import Any, Callable

from core.contracts.event import Event, EventHandler

logger = logging.getLogger("jarvis.event_bus")
_STOP = object()


class EventBus:
    """Small replaceable event fabric that owns one worker thread per running epoch."""

    def __init__(self, max_queue_size: int = 10_000) -> None:
        if max_queue_size < 1:
            raise ValueError("max_queue_size must be positive")
        self._max_queue_size = max_queue_size
        self._subs: dict[str, list[Callable[[Any], None]]] = {}
        self._typed_subs: dict[str, list[EventHandler]] = {}
        self._lock = threading.RLock()
        self._q: queue.Queue[Event | object] = queue.Queue(maxsize=max_queue_size)
        self._running = False
        self._shutdown_complete = threading.Event()
        self._dropped = 0
        self._stop_enqueued = False
        self._worker: threading.Thread | None = None
        self._async_loop: asyncio.AbstractEventLoop | None = None
        self._async_thread: threading.Thread | None = None
        self._start_async_loop()
        self._start_worker()

    def _start_async_loop(self) -> None:
        with self._lock:
            if self._async_thread is not None and self._async_thread.is_alive():
                return
            ready=threading.Event()
            def runner() -> None:
                loop=asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                with self._lock:
                    self._async_loop=loop
                ready.set()
                loop.run_forever()
                pending=asyncio.all_tasks(loop)
                for task in pending: task.cancel()
                if pending: loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                loop.close()
            self._async_thread=threading.Thread(target=runner,daemon=True,name="eventbus-async")
            self._async_thread.start()
        ready.wait(timeout=2.0)

    def _start_worker(self) -> None:
        with self._lock:
            if self._running:
                return
            self._q = queue.Queue(maxsize=self._max_queue_size)
            self._stop_enqueued = False
            self._shutdown_complete.clear()
            self._running = True
            self._worker = threading.Thread(target=self._loop, daemon=True, name="eventbus")
            self._worker.start()

    async def start(self) -> None:
        """Start or restart the event worker."""
        self._start_worker()

    def stop(self) -> None:
        """Lifecycle-compatible synchronous shutdown."""
        self.shutdown()

    @property
    def dropped_count(self) -> int:
        with self._lock:
            return self._dropped

    def subscribe(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """Subscribe using the legacy payload callback shape."""
        self._validate_subscription(event_type, handler)
        with self._lock:
            self._subs.setdefault(event_type, []).append(handler)

    def subscribe_event(self, event_type: str, handler: EventHandler) -> None:
        """Subscribe to immutable :class:`Event` envelopes."""
        self._validate_subscription(event_type, handler)
        with self._lock:
            self._typed_subs.setdefault(event_type, []).append(handler)

    def unsubscribe(self, event_type: str, handler: Callable[[Any], None]) -> None:
        """Remove one legacy subscription if present."""
        with self._lock:
            handlers = self._subs.get(event_type, [])
            if handler in handlers:
                handlers.remove(handler)
            if not handlers and event_type in self._subs:
                self._subs.pop(event_type, None)

    def unsubscribe_event(self, event_type: str, handler: EventHandler) -> None:
        """Remove one typed event subscription if present."""
        with self._lock:
            handlers = self._typed_subs.get(event_type, [])
            if handler in handlers:
                handlers.remove(handler)
            if not handlers and event_type in self._typed_subs:
                self._typed_subs.pop(event_type, None)

    def publish(self, event_type: str | Event, payload: Any = None, *, source: str = "jarvis.event_bus", correlation_id: str | None = None, causation_id: str | None = None) -> bool:
        """Publish an event without allowing producers to mutate the queue."""
        if isinstance(event_type, Event):
            event = event_type
        else:
            event = Event.new(str(event_type), source, {"value": payload}, correlation_id=correlation_id, causation_id=causation_id)
        with self._lock:
            if not self._running:
                return False
            try:
                self._q.put_nowait(event)
                return True
            except queue.Full:
                self._dropped += 1
                logger.error("event_bus_queue_full", extra={"event_type": event.event_type})
                return False

    @staticmethod
    def _validate_subscription(event_type: str, handler: Callable[[Any], None]) -> None:
        if not str(event_type).strip():
            raise ValueError("event_type is required")
        if not callable(handler):
            raise TypeError("handler must be callable")

    def _loop(self) -> None:
        while True:
            item = self._q.get()
            try:
                if item is _STOP:
                    return
                event = item
                if not isinstance(event, Event):
                    continue
                with self._lock:
                    legacy = tuple(self._subs.get(event.event_type, ())) + tuple(self._subs.get("*", ()))
                    typed = tuple(self._typed_subs.get(event.event_type, ())) + tuple(self._typed_subs.get("*", ()))
                for handler in legacy:
                    try:
                        handler(event.payload.get("value")) if event.payload.keys() == {"value"} else handler(dict(event.payload))
                    except Exception:
                        logger.exception("event_legacy_handler_failed", extra={"event_type": event.event_type})
                for handler in typed:
                    try:
                        result = handler(event)
                        if hasattr(result, "__await__"):
                            loop=self._async_loop
                            if loop is None or loop.is_closed():
                                raise RuntimeError("event async loop is unavailable")
                            future=asyncio.run_coroutine_threadsafe(result, loop)
                            future.result(timeout=30.0)
                    except Exception:
                        logger.exception("event_typed_handler_failed", extra={"event_type": event.event_type})
            finally:
                self._q.task_done()

    def shutdown(self, timeout: float = 5.0) -> None:
        """Gracefully drain accepted events and stop the worker."""
        timeout = max(0.1, float(timeout))
        with self._lock:
            if not self._running:
                worker = self._worker
            else:
                self._running = False
                worker = self._worker
                try:
                    self._q.put_nowait(_STOP)
                    self._stop_enqueued = True
                except queue.Full:
                    # Shutdown must never block behind a producer-owned full queue.
                    # Drop one queued event and enqueue the lifecycle sentinel.
                    try:
                        self._q.get_nowait()
                        self._q.task_done()
                    except queue.Empty:
                        logger.debug("event_bus_shutdown_queue_already_empty")
                    try:
                        self._q.put_nowait(_STOP)
                        self._stop_enqueued = True
                    except queue.Full:
                        logger.error("event_bus_stop_enqueue_failed")
                        return
        if worker is not None:
            worker.join(timeout=timeout)
        if worker is not None and worker.is_alive():
            logger.error("event_bus_worker_timeout", extra={"timeout": timeout})
            return
        loop=self._async_loop
        thread=self._async_thread
        if loop is not None and not loop.is_closed():
            try: loop.call_soon_threadsafe(loop.stop)
            except RuntimeError: pass
        if thread is not None: thread.join(timeout=max(0.1, timeout))
        self._shutdown_complete.set()



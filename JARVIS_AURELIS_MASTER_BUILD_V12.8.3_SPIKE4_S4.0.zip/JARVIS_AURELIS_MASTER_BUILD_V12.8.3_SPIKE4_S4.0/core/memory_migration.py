"""Versioned memory snapshots with integrity verification and restore drills."""
from __future__ import annotations
import hashlib, re, sqlite3, time, uuid
from pathlib import Path

class MemoryMigration:
    """Create and verify portable SQLite snapshots."""
    def __init__(self,root:str|Path="data/memory_snapshots")->None:self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
    def snapshot(self,db_path:str|Path,version:str)->Path:
        src=Path(db_path).resolve()
        safe_version=str(version).strip()
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}",safe_version):
            raise ValueError("snapshot version must contain only A-Z, a-z, 0-9, dot, underscore, or hyphen")
        target=self.root/f"snapshot-{safe_version}-{time.time_ns()}-{uuid.uuid4().hex[:12]}.db"
        srcdb=sqlite3.connect(src); dst=sqlite3.connect(target)
        try:
            srcdb.backup(dst)
        finally:
            dst.close(); srcdb.close()
        digest=hashlib.sha256(target.read_bytes()).hexdigest()
        (target.with_suffix('.sha256')).write_text(digest,encoding='ascii')
        return target
    def verify(self,snapshot:str|Path)->bool:
        p=Path(snapshot).resolve(); side=p.with_suffix('.sha256'); return side.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==side.read_text(encoding='ascii').strip()



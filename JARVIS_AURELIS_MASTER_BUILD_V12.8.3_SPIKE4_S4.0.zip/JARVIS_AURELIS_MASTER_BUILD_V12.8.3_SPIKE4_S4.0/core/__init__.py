"""JARVIS Core package."""
from core.types import RiskLevel, ToolSpec, ModelInfo, BackendResult
from core.model_router import ModelRouter
from core.tool_registry import ToolRegistry
from core.security_guard import SecurityGuard
from core.event_bus import EventBus
from core.agent_genome import AgentGenome, AgentGenomeRegistry, GenomeCompatibility, GenomeDiff
from core.skill_fabric import (Skill, SkillState, SkillRegistry, SkillFabric, SkillDependencyGraph, SkillSummary, InstallPlan, CertificationRecord, SkillError, SkillValidationError, SkillSignatureError, SkillRegistryError, SkillResolutionError, SkillLifecycleError, SkillAuthorizationError, SkillSandboxError, SkillCertificationError, SkillCompositionError, diff_skills)
from core.event_fabric import (
    AuthContext, DurableEventBus, EventBus as EventFabricBus, EventEnvelope, EventFabric, EventFilter,
    EventLineage, EventReceipt, EventSchemaRegistry, EventTaxonomy, ProducedBy,
    ReplayProjector, SubscriberContext, SubscriptionHandle, GenomeKeyResolver,
)

__all__ = [
    "AgentHarness", "AllowedSurface", "AuthorizationRequired", "BackendExecutionResult", "BackendGuarantees", "CheckpointError",
    "CheckpointPolicy", "CheckpointStore", "Checkpointable", "Clock", "CommandProgram", "ContextImmutable", "DsecContainerBackend",
    "ExecutionAccounting", "ExecutionAuthContext", "ExecutionBudgets", "ExecutionContext", "ExecutionHandle", "ExecutionMode",
    "ExecutionResult", "ExecutionRuntime", "FilesystemMode", "HarnessError", "LinuxNativeSandboxBackend", "MacOSSandboxBackend",
    "ModeNotPermitted", "PolicyDenied", "PortableSubprocessBackend", "RestoreIncompatibleEnvironment", "SandboxBackend", "SecretBroker",
    "SimulationBackend", "TimeSource", "TraceIntegrityError", "TraceLedger", "TraceLevel", "TrustLevel", "ViolationRecord",
    "WindowsNativeSandboxBackend", "build_environment_hash",

    "RiskLevel", "ToolSpec", "ModelInfo", "BackendResult",
    "ModelRouter", "ToolRegistry", "SecurityGuard", "EventBus",
    "AgentGenome", "AgentGenomeRegistry", "GenomeCompatibility", "GenomeDiff",
    "Skill", "SkillState", "SkillRegistry", "SkillFabric", "SkillDependencyGraph", "SkillSummary", "InstallPlan", "CertificationRecord",
    "SkillError", "SkillValidationError", "SkillSignatureError", "SkillRegistryError", "SkillResolutionError", "SkillLifecycleError",
    "SkillAuthorizationError", "SkillSandboxError", "SkillCertificationError", "SkillCompositionError", "diff_skills",
    "AuthContext", "DurableEventBus", "EventFabricBus", "EventEnvelope", "EventFabric", "EventFilter",
    "EventLineage", "EventReceipt", "EventSchemaRegistry", "EventTaxonomy", "ProducedBy",
    "ReplayProjector", "SubscriberContext", "SubscriptionHandle", "GenomeKeyResolver",
    "AgentGarage", "AgentSnapshot", "GarageError", "GarageState", "GarageStateView", "LifecycleRecord",
    "IllegalStateTransition", "AuthorizationDenied", "SnapshotError", "SnapshotEnvironmentMismatch", "SnapshotRevoked",
    "AttenuationCannotWiden", "DeploymentPreconditionFailed", "RollbackCascadeFailure", "StateReplayError",
    "AgentWorkshop", "AgentEvaluationHarness", "BenchmarkLibrary", "WorkshopSession", "SessionState",
    "ExperienceMemory", "MemoryStoreDurable", "MemoryStoreEphemeral", "MemoryKind", "MemoryConfig", "DEFAULT_CONFIG", "MemoryError", "MemorySchemaError", "MemorySignatureError", "MemoryAccessDenied", "DuplicateMemory", "ContradictionError", "MemoryNotFound", "MemoryPolicyError", "SnapshotEnvironmentMismatch", "MemoryProjector", "NullVectorIndex", "build_memory_item", "memory_config_from_genome", "validate_skill_memory_requirements",
    "WorkshopKind", "WorkshopExecutionMode", "DraftEditor", "WorkflowValidator", "PromptProgramValidator",
    "EvaluationProfile", "DEFAULT_PROFILES", "WorkshopError", "verify_signed", "DeterministicHarness",
    "FailureIntelligence", "FailureStore", "FailureConfig", "AnalysisBudget", "FailureIntelligenceError", "FailureValidationError",
    "FailureIntegrityError", "FailureAccessDenied", "FailureNotFound", "FailurePolicyError", "FailureDuplicate",
    "verify_failure_signature", "build_failure_record", "validate_failure_record",
    "ModelFabric", "ModelConfig", "ModelRegistry", "QuantizationRegistry", "VRAMEstimator", "ModelResidencyManager", "KVCacheManager", "BatchManager", "RoleAdapterManager", "ModelAdapter", "DeterministicAdapter", "VRAMEstimate", "LoadHandle", "LoadedRef", "ReservationHandle", "KVHandle", "Batch", "RoutingDecision", "ModelFabricError", "ModelValidationError", "ModelSignatureError", "ModelIntegrityError", "ModelAccessDenied", "ModelNotFound", "ModelRevoked", "ModelRetired", "ArtifactHashMismatch", "QuantizationIncompatible", "InsufficientVram", "NoEligibleModel", "PrivacyViolation", "DeterminismUnavailable", "StaleMeasurement", "KVCrossTenant", "BatchPolicyDenied", "SpeculationPolicyDenied", "CloudCredentialError", "validate_profile", "validate_quantization_profile", "verify_profile", "sign_profile",
]
from core.agent_harness import (
    AgentHarness, AllowedSurface, AuthorizationRequired, BackendExecutionResult, BackendGuarantees, CheckpointError,
    CheckpointPolicy, CheckpointStore, Checkpointable, Clock, CommandProgram, ContextImmutable, DsecContainerBackend,
    ExecutionAccounting, ExecutionAuthContext, ExecutionBudgets, ExecutionContext, ExecutionHandle, ExecutionMode,
    ExecutionResult, ExecutionRuntime, FilesystemMode, HarnessError, LinuxNativeSandboxBackend, MacOSSandboxBackend,
    ModeNotPermitted, PolicyDenied, PortableSubprocessBackend, RestoreIncompatibleEnvironment, SandboxBackend, SecretBroker,
    SimulationBackend, TimeSource, TraceIntegrityError, TraceLedger, TraceLevel, TrustLevel, ViolationRecord,
    WindowsNativeSandboxBackend, build_environment_hash,
)
from core.agent_factory import (
    AgentFactory, AgentFactoryError, InMemoryStagingRegistry, PipelineArtifact, PipelineResult,
    SignatureFailed, verify_agentpkg,
)

from core.agent_garage import (
    AgentGarage, AgentSnapshot, GarageError, GarageState, GarageStateView, LifecycleRecord,
    IllegalStateTransition, AuthorizationDenied, SnapshotError, SnapshotEnvironmentMismatch, SnapshotRevoked,
    AttenuationCannotWiden, DeploymentPreconditionFailed, RollbackCascadeFailure, StateReplayError,
)

from core.agent_workshop import (
    AgentWorkshop, AgentEvaluationHarness, BenchmarkLibrary, WorkshopSession, SessionState,
    WorkshopKind, WorkshopExecutionMode, DraftEditor, WorkflowValidator, PromptProgramValidator,
    EvaluationProfile, DEFAULT_PROFILES, WorkshopError, verify_signed, DeterministicHarness,
)

from core.experience_memory import (
    ExperienceMemory, MemoryStoreDurable, MemoryStoreEphemeral, MemoryKind, MemoryConfig, DEFAULT_CONFIG,
    MemoryError, MemorySchemaError, MemorySignatureError, MemoryAccessDenied, DuplicateMemory, ContradictionError,
    MemoryNotFound, MemoryPolicyError, SnapshotEnvironmentMismatch, MemoryProjector, NullVectorIndex,
    build_memory_item, memory_config_from_genome, validate_skill_memory_requirements,
)

from core.failure_intelligence import (
    FailureIntelligence, FailureStore, FailureConfig, AnalysisBudget, FailureIntelligenceError, FailureValidationError,
    FailureIntegrityError, FailureAccessDenied, FailureNotFound, FailurePolicyError, FailureDuplicate,
    verify_failure_signature, build_failure_record, validate_failure_record,
)

from core.model_fabric import (
    ModelFabric, ModelConfig, ModelRegistry, QuantizationRegistry, VRAMEstimator, ModelResidencyManager,
    KVCacheManager, BatchManager, RoleAdapterManager, ModelAdapter, DeterministicAdapter, VRAMEstimate,
    LoadHandle, LoadedRef, ReservationHandle, KVHandle, Batch, RoutingDecision,
    ModelFabricError, ModelValidationError, ModelSignatureError, ModelIntegrityError, ModelAccessDenied,
    ModelNotFound, ModelRevoked, ModelRetired, ArtifactHashMismatch, QuantizationIncompatible, InsufficientVram,
    NoEligibleModel, PrivacyViolation, DeterminismUnavailable, StaleMeasurement, KVCrossTenant, BatchPolicyDenied,
    SpeculationPolicyDenied, CloudCredentialError, validate_profile, validate_quantization_profile, verify_profile, sign_profile,
)

from core.world_model_3 import (CausalLink, ConstraintResult, PredictionRecord, Provenance, StateTransition, WorldChange, WorldConstraint, WorldEntity3, WorldModel3, WorldModelClosedError, WorldModelError, WorldAuthorizationError, WorldConflictError, WorldObservation, WorldRelation3, WorldSnapshot3)

from core.planning_engine import (
    PlanningEngine, PlanningEngine2, PlanEngine, PlanConfig, PlanStore, PlanOutcome, PlanVersionRef,
    ValidationReport, PlanningError, PlanningValidationError, PlanningSignatureError, PlanningIntegrityError,
    PlanningAccessDenied, PlanNotFound, PlanImmutable, DependencyCycleError, TemporalConstraintError,
    ResourceBudgetError, ContractError, LowConfidence, AuthorizationDenied as PlanningAuthorizationDenied,
    SimulationRequired, IrreversiblePlanError, TemplateError, verify_plan_signature, validate_plan,
)
from core.planning_engine import sign_confidence_waiver, verify_confidence_waiver

# P2-P Tool Fabric 2.0 canonical exports.
from .tool_fabric import (  # noqa: E402,F401
    ToolFabric, ToolConfig, ToolRegistry, DiscoveryRequest, DiscoveryResult,
    SelectionDecision, InvocationResult, ToolHealth, sign_manifest, verify_manifest,
    sign_adhoc_authorization, ToolFabricError, ToolValidationError, ToolSignatureError,
    ToolIntegrityError, ToolAccessDenied, ToolNotFound, ToolRevoked, ToolRetired,
    NoEligibleTool, SchemaViolation, ToolPolicyDenied, ToolTimeout, RateLimited,
    ConcurrencyLimited, DeterminismUnavailable, IdempotencyViolation, AdapterError,
)

# P2-Q Tool Composition canonical exports.
from core.tool_composition import (
    ToolCompositionEngine, ToolComposition, CompositionDraft, CompositeResult, TypeCheckReport,
    ContractCheckReport, AggregateBudgetReport, DerivedSurfaceReport, CompositionError,
    CompositionValidationError, CompositionSignatureError, CompositionIntegrityError,
    CompositionAccessDenied, TypeCheckError, ContractCheckError, CycleError, LivenessError,
    RegistrationDenied, SimulationRequired,
)

from core.simulation_universe import (SimulationEngine, SimulationUniverseEngine, SimulationUniverse, SimulationOutcome, DivergenceReport, Checkpoint, Budget, IsolationGuarantees, ExpectedBehavior, AdversarialConfig, Fault, FidelityTier, TargetClass, EnvironmentScope, Determinism, UniverseState, OutcomeClass, DivergenceKind, SimulationError, SimulationAuthorizationError, SimulationIsolationError, SimulationValidationError, SimulationDivergenceError, SimulationReplayError)
from core.multi_agent_orchestration import (MultiAgentOrchestration, TeamOrchestrator, Team, TeamMember, AgentProfile, BudgetSet, DelegationContract, MessageEnvelope, CollaborationSession, OrchestrationError, AuthorizationRequired, TenantIsolationError, CertificationError, DelegationCannotWiden, DelegationError, MessageRejected, EvidenceRequired, ResourceDenied, ConsensusError, ReplayDivergence, SimulationRequired)

from core.a2a_verification import (A2AVerificationFabric, VerifiedMultiAgentOrchestration, VerificationDenied, ReplayRejected, DelegationExpansionRejected, A2AVerificationError)


# P2-R Autonomous Research System.
from core.autonomous_research import (
    AutonomousResearchSystem, ResearchError, ResearchPolicyDenied, ResearchBudgetExceeded,
    ResearchGroundingError, ResearchContradictionError, ResearchReplayDivergence, ResearchVerificationError,
    ResearchRequest, StageRecord, SourceRecord, ClaimRecord, EvidenceNode, EvidenceEdge, EvidenceGraph,
    ContradictionRecord, QUESTION_CLASSES, SOURCE_CLASSES, CLAIM_KINDS, CONFIDENCE_LEVELS, OUTCOMES, MODES,
)

# P2-S Security Evolution: artifact attestation lifecycle (assess/revoke; never grants).
from core.security_evolution import SecurityEvolution, SecurityEvolutionError, SecurityDenied, InvalidAttestation, RevocationDenied
from core.security_evolution import SecurityLifecycleGate

# P2-T Autonomous System Doctor: continuous health intelligence, diagnosis, and proposal-only remediation.
from core.autonomous_system_doctor import (
    AutonomousSystemDoctor, SystemDoctor, P2TError, BaselineError, DetectorError, DiagnosisError,
    TenantIsolationError, RemediationDenied, ReplayError, HealthBaseline, DetectorSpec, RemediationProposal,
    SYMPTOM_CLASSES, CONFIDENCE_LEVELS, METHODS, REMEDIATION_CLASSES, OUTCOMES, MONITORING_MATRIX,
    REQUIRED_DETECTORS, P2T_VERSION, KERNEL_VERSION,
)

# P2-G Learning Pipeline: controlled, proposal-only evolution loop.
from core.learning_pipeline import (
    LearningPipeline, CandidateConfig, CandidateRecord, GateRecord, LearningBatch,
    LearningPipelineError, CandidateValidationError, CandidateImmutable, TenantIsolationError,
    GateViolation, SecurityGateDenied, SimulationRequired, DeploymentHandoffDenied, AttributionError,
    TRIGGERS as P2G_TRIGGERS, CANDIDATE_CLASSES as P2G_CANDIDATE_CLASSES,
    ORIGIN_METHODS as P2G_ORIGIN_METHODS, GATE_STAGES as P2G_GATE_STAGES,
    OUTCOME_STATES as P2G_OUTCOME_STATES, MANDATORY_GATES as P2G_MANDATORY_GATES,
    verify_signed_document,
)

# P2-V Evolution Lab: controlled batched evolution experiments and evidence orchestration.
from core.evolution_lab import (
    EvolutionLab, ExperimentConfig, ExecutionContextView, power_sample_size, verify_signed_document,
    EvolutionLabError, ExecutionContextRequired, TenantIsolationError as EvolutionLabTenantIsolationError,
    ValidationError as EvolutionLabValidationError, SignatureError as EvolutionLabSignatureError,
    IsolationError, FairnessError, StatisticalConfigError, LifecycleError, HandoffDenied, SearchError,
    HYPOTHESIS_CLASSES as P2V_HYPOTHESIS_CLASSES, EXPERIMENT_KINDS as P2V_EXPERIMENT_KINDS,
    SCOPES as P2V_SCOPES, METRICS as P2V_METRICS, OUTCOMES as P2V_OUTCOMES, SEARCH_STRATEGIES as P2V_SEARCH_STRATEGIES,
)
# P2-W Agent Economics / Resource Scheduler.
from core.agent_economics import (
    AgentEconomics, EconomicsError, SchemaError, SignatureError as EconomicsSignatureError, TenantIsolationError as EconomicsTenantIsolationError,
    ExecutionContextRequired as EconomicsExecutionContextRequired, BudgetDenied, QuotaDenied, PolicyDenied as EconomicsPolicyDenied,
    ResourceUnavailable, PreemptionDenied, AccountingError, ReplayDivergence, ConfigurationError,
    ResourceAmount, Requester, ResourceRequest, GrantedResource, Substitution, AllocationDecision,
    ConsumedResource, AccountingRecord, PriorityWeight, FairnessConfig, PreemptionConfig, RiskCeiling,
    Quota, SchedulingPolicy, CostUnitPolicy, CurrencyConversionPolicy, FairnessReport, ReconciliationReport,
    QueueState, EscalationRecord, RESOURCE_KINDS as ECONOMIC_RESOURCE_KINDS, PRIORITY_CLASSES as ECONOMIC_PRIORITY_CLASSES,
    OUTCOMES as ECONOMIC_OUTCOMES, FAIRNESS_DIMENSIONS as ECONOMIC_FAIRNESS_DIMENSIONS, COST_UNIT_KINDS as ECONOMIC_COST_UNIT_KINDS,
)


# P2-X Provenance & Lineage Graph.
from core.provenance_graph import (
    ProvenanceGraph, ProvenanceStore, ProvenanceNode, ProvenanceEdge, GraphQuery, DerivationRule,
    ProvenanceError, SchemaError as ProvenanceSchemaError, SignatureError as ProvenanceSignatureError,
    TenantIsolationError as ProvenanceTenantIsolationError, ArtifactVerificationError, CycleDetected, DanglingEdge,
    ReplayDivergence as ProvenanceReplayDivergence, QueryError as ProvenanceQueryError,
    NODE_KINDS as PROVENANCE_NODE_KINDS, EDGE_KINDS as PROVENANCE_EDGE_KINDS,
    QUERY_KINDS as PROVENANCE_QUERY_KINDS, CONFIDENCE as PROVENANCE_CONFIDENCE, VERIFICATION as PROVENANCE_VERIFICATION,
)

# P2-Y Autonomous Recovery. Planning/orchestration only; execution is delegated to P2-E/P2-D.
from core.autonomous_recovery import (
    AutonomousRecovery, P2YAutonomousRecovery, RecoveryDependencies, RecoveryStore, RecoveryError, SchemaError as RecoverySchemaError,
    SignatureError as RecoverySignatureError, TenantIsolationError as RecoveryTenantIsolationError, ExecutionContextRequired as RecoveryExecutionContextRequired,
    AuthorizationRequired as RecoveryAuthorizationRequired, SimulationRequired as RecoverySimulationRequired, VerificationRequired as RecoveryVerificationRequired,
    AttestationRequired as RecoveryAttestationRequired, ReAdmissionRequired as RecoveryReAdmissionRequired, ValidationRequired as RecoveryValidationRequired,
    CascadeLimitExceeded, CircularCascade, RecoveryAlreadyExecuting, PolicyError as RecoveryPolicyError, ReplayDivergence as RecoveryReplayDivergence,
)

# P2-Z Cognitive Command Center: client-only gateway boundary. It never grants authority or executes phase actions directly.
from core.cognitive_command_center import (
    CognitiveCommandCenterGateway, create_app, GatewayError as CognitiveCommandCenterGatewayError,
    FailClosed as CognitiveCommandCenterFailClosed, OperatorIdentity as CommandCenterOperatorIdentity,
    OperatorSession as CommandCenterOperatorSession, ActionRecord as CommandCenterActionRecord,
    InMemoryOperatorIdentityProvider as CommandCenterTestOperatorProvider,
    SecurityAuthorityAdapter as CommandCenterSecurityAuthorityAdapter,
    ClientBundleVerifier as CommandCenterClientBundleVerifier, ClientVerificationError as CommandCenterClientVerificationError,
    AuditLedger as CommandCenterAuditLedger, StreamManager as CommandCenterStreamManager,
)

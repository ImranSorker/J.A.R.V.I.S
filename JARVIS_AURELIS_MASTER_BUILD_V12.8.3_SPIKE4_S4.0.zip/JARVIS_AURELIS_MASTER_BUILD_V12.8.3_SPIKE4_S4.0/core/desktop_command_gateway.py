"""In-process command gateway used by the Flutter desktop transport.

The gateway deliberately contains no HTTP, WebSocket, socket, or shell code. It
executes typed presentation commands directly against the already-constructed
:class:`main.JARVISCore` dependency graph.
"""
from __future__ import annotations

import asyncio
import base64
import inspect
import logging
import time
from typing import Any, AsyncIterator

logger = logging.getLogger("jarvis.desktop_gateway")

_PROTOCOL_VERSION = 1
_MAX_TEXT = 256_000


class DesktopCommandGateway:
    """Translate bounded Flutter commands into direct JARVISCore operations."""

    def __init__(self, core: Any, *, operator_id: str = "local-desktop") -> None:
        self.core = core
        self.operator_id = str(operator_id).strip() or "local-desktop"

    @staticmethod
    def _redact(value: Any) -> Any:
        """Redact credential-like values before they reach presentation code."""
        sensitive = {
            "token",
            "authorization",
            "api_key",
            "apikey",
            "secret",
            "password",
            "private_key",
            "approval_token",
            "execution_grant",
        }
        if isinstance(value, dict):
            return {
                str(key): ("[REDACTED]" if str(key).lower() in sensitive else DesktopCommandGateway._redact(item))
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [DesktopCommandGateway._redact(item) for item in value]
        if isinstance(value, tuple):
            return [DesktopCommandGateway._redact(item) for item in value]
        return value

    @staticmethod
    def _snapshot(core: Any) -> dict[str, Any]:
        """Build a non-sensitive runtime snapshot for the Flutter UI."""
        cpu = 0.0
        ram = 0.0
        gpu = 0.0
        vram = 0.0
        profiler = getattr(core, "profiler", None) or getattr(core, "hardware", None)
        if profiler is not None:
            try:
                import psutil

                cpu = float(psutil.cpu_percent(interval=None))
                total = float(getattr(profiler, "ram_total_gb", 0.0) or 0.0)
                free = float(getattr(profiler, "ram_free_gb", total) or total)
                ram = ((total - free) / total * 100.0) if total > 0 else 0.0
                gpus = getattr(profiler, "gpus", []) or []
                if gpus:
                    total_vram = float(gpus[0].get("total_gb", 0.0) or 0.0)
                    free_vram = float(gpus[0].get("free_gb", total_vram) or total_vram)
                    vram = ((total_vram - free_vram) / total_vram * 100.0) if total_vram > 0 else 0.0
            except Exception:
                logger.debug("desktop_snapshot_hardware_failed", exc_info=True)

        router = getattr(core, "router", None)
        primary = getattr(router, "primary", None) if router is not None else None
        model = str(getattr(primary, "name", "unknown"))
        gateway = getattr(core, "intelligence_gateway", None)
        gateway_snapshot = gateway.snapshot().to_dict() if gateway is not None and hasattr(gateway, "snapshot") else {}
        memory = getattr(core, "cognitive_memory", None)
        try:
            memory_items = int(memory.snapshot().get("total", 0)) if memory is not None else 0
        except Exception:
            memory_items = 0
        autonomy = getattr(core, "autonomy_fabric", None)
        try:
            autonomy_snapshot = autonomy.snapshot() if autonomy is not None and hasattr(autonomy, "snapshot") else {}
        except Exception:
            autonomy_snapshot = {}
        job_engine = getattr(core, "job_engine", None)
        try:
            active_jobs = int(job_engine.get_stats().get("running", 0)) if job_engine is not None else 0
        except Exception:
            active_jobs = 0
        security_mode = str(getattr(core, "cfg", {}).get("security", {}).get("mode", "guarded"))
        active_agents = int(autonomy_snapshot.get("status_counts", {}).get("running", 0)) if isinstance(autonomy_snapshot, dict) else 0
        supreme = getattr(core, "supreme", None)
        supreme_snapshot = supreme.snapshot() if supreme is not None else {}
        process_snapshot = supreme_snapshot.get("process", {}) if isinstance(supreme_snapshot, dict) else {}
        model_residency = getattr(core, "model_residency", None)
        try:
            residency = model_residency.snapshot() if model_residency is not None else {}
        except Exception:
            residency = {}
        token_ledger = getattr(core, "token_ledger", None)
        try:
            accounting = token_ledger.health() if token_ledger is not None and hasattr(token_ledger, "health") else {}
        except Exception:
            accounting = {}
        return {
            "cpu_percent": max(0.0, min(100.0, cpu)),
            "ram_percent": max(0.0, min(100.0, ram)),
            "gpu_percent": max(0.0, min(100.0, gpu)),
            "vram_percent": max(0.0, min(100.0, vram)),
            "tokens_per_second": float(gateway_snapshot.get("tokens_per_second", 0.0) or 0.0),
            "latency_ms": float(gateway_snapshot.get("mean_latency_ms", 0.0) or 0.0),
            "active_jobs": active_jobs,
            "active_agents": active_agents,
            "memory_items": memory_items,
            "model": model,
            "backend": model,
            "security_mode": security_mode,
            "runtime_profile": str(supreme_snapshot.get("profile", "local_embedded")) if isinstance(supreme_snapshot, dict) else "local_embedded",
            "zero_listener": bool(process_snapshot.get("zero_listener", True)) if isinstance(process_snapshot, dict) else True,
            "listener_count": len(process_snapshot.get("listeners", [])) if isinstance(process_snapshot, dict) else 0,
            "startup_ok": bool(supreme_snapshot.get("startup_ok", True)) if isinstance(supreme_snapshot, dict) else True,
            "resource": supreme_snapshot.get("resources", {}) if isinstance(supreme_snapshot, dict) else {},
            "provenance": supreme_snapshot.get("provenance", {}) if isinstance(supreme_snapshot, dict) else {},
            "model_residency": residency,
            "token_accounting": accounting,
        }

    async def handle(self, message_type: str, payload: dict[str, Any], *, session_id: str) -> AsyncIterator[dict[str, Any]]:
        """Execute one presentation command and yield response envelopes."""
        if not isinstance(payload, dict):
            yield self._error("data must be an object")
            return

        msg = str(message_type).strip()
        try:
            if msg == "heartbeat":
                yield {"t": "heartbeat.ok", "data": {"server_time": time.time()}}
            elif msg in {"state.request", "telemetry.request"}:
                yield {"t": "telemetry", "data": self._snapshot(self.core)}
            elif msg == "diagnostics.request":
                supreme = getattr(self.core, "supreme", None)
                if supreme is None:
                    yield self._error("supreme diagnostics unavailable")
                else:
                    yield {"t": "diagnostics.result", "data": supreme.refresh_diagnostics()}
            elif msg == "permanent.snapshot":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    yield {"t": "permanent.snapshot", "data": self._redact(service.permanent_snapshot())}
            elif msg == "calculation.run":
                service = getattr(self.core, "operator_service", None)
                operation = str(payload.get("operation", "")).strip()
                arguments = payload.get("arguments", {})
                if service is None or not operation or not isinstance(arguments, dict):
                    yield self._error("invalid calculation request")
                else:
                    yield {"t": "calculation.result", "data": self._redact(service.calculation(operation, arguments))}
            elif msg == "trajectory.task":
                service = getattr(self.core, "operator_service", None)
                task_id = str(payload.get("task_id", "")).strip()
                if service is None or not task_id or len(task_id) > 256:
                    yield self._error("invalid trajectory request")
                else:
                    yield {"t": "trajectory.result", "data": self._redact(service.trace_task(task_id, int(payload.get("limit", 500))))}
            elif msg == "causal.related":
                service = getattr(self.core, "operator_service", None)
                subject = str(payload.get("subject", "")).strip()
                direction = str(payload.get("direction", "both"))
                if service is None or not subject or len(subject) > 512 or direction not in {"in", "out", "both"}:
                    yield self._error("invalid causal-memory request")
                else:
                    yield {"t": "causal.result", "data": self._redact(service.causal_related(subject, direction, int(payload.get("limit", 100))))}
            elif msg == "trajectory.grade":
                service = getattr(self.core, "operator_service", None)
                task_id = str(payload.get("task_id", "")).strip()
                if service is None or not task_id or len(task_id) > 256:
                    yield self._error("invalid trajectory grading request")
                else:
                    yield {"t": "trajectory.grade.result", "data": self._redact(service.grade_trajectory(task_id, int(payload.get("limit", 500))))}
            elif msg == "dream.snapshot":
                service = getattr(self.core, "operator_service", None)
                source = str(payload.get("source", "")).strip()
                if service is None or not source:
                    yield self._error("invalid dream snapshot request")
                else:
                    yield {"t": "dream.snapshot.result", "data": self._redact(service.dream_snapshot(source))}
            elif msg == "thermal.budget":
                service = getattr(self.core, "operator_service", None)
                temperature = payload.get("temperature_c")
                if service is None or temperature is not None and not isinstance(temperature, (int, float)):
                    yield self._error("invalid thermal request")
                else:
                    yield {"t": "thermal.budget.result", "data": self._redact(service.thermal_budget(float(temperature) if temperature is not None else None, bool(payload.get("on_battery", False))))}
            elif msg == "counterfactual.compare":
                service = getattr(self.core, "operator_service", None)
                alternatives = payload.get("alternatives")
                if service is None or not isinstance(alternatives, list) or not alternatives or len(alternatives) > 32 or any(not isinstance(x, dict) for x in alternatives):
                    yield self._error("invalid counterfactual request")
                else:
                    yield {"t": "counterfactual.result", "data": self._redact(service.counterfactual([x for x in alternatives if isinstance(x, dict)]))}
            elif msg == "control.snapshot":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    yield {"t": "control.snapshot", "data": self._redact(service.snapshot())}
            elif msg == "frontier.snapshot":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    yield {"t": "frontier.snapshot", "data": self._redact(service.frontier_snapshot())}
            elif msg == "frontier.policy.simulate":
                service = getattr(self.core, "operator_service", None)
                scenarios = payload.get("scenarios")
                if service is None or not isinstance(scenarios, list) or len(scenarios) > 128:
                    yield self._error("invalid policy simulation request")
                else:
                    yield {"t": "frontier.policy.result", "data": {"results": self._redact(service.simulate_policy([row for row in scenarios if isinstance(row, dict)]))}}
            elif msg == "frontier.capability.explain":
                service = getattr(self.core, "operator_service", None)
                capability = str(payload.get("capability", "")).strip()
                if service is None or not capability or len(capability) > 256:
                    yield self._error("invalid capability explanation request")
                else:
                    yield {"t": "frontier.capability.result", "data": self._redact(service.capability_explain(capability))}
            elif msg == "frontier.safe_mode":
                service = getattr(self.core, "operator_service", None)
                mode = str(payload.get("mode", "")).strip()
                reason = str(payload.get("reason", "operator request")).strip()[:1000]
                if service is None or not mode:
                    yield self._error("invalid safe-mode request")
                else:
                    yield {"t": "frontier.safe_mode.result", "data": self._redact(service.set_safe_mode(mode, reason))}
            elif msg == "assistant.feedback":
                service = getattr(self.core, "operator_service", None)
                feedback = str(payload.get("feedback", "")).strip()
                task_type = str(payload.get("task_type", "default")).strip()[:128]
                accepted = bool(payload.get("accepted", True))
                if service is None or not feedback or len(feedback) > 2000:
                    yield self._error("invalid feedback")
                else:
                    result = service.record_feedback(
                        owner_id=str(payload.get("owner_id", "local-user"))[:128],
                        workspace_id=str(payload.get("workspace_id", session_id))[:256],
                        session_id=session_id,
                        task_type=task_type,
                        feedback=feedback,
                        accepted=accepted,
                    )
                    yield {"t": "assistant.feedback.result", "data": self._redact(result)}
            elif msg == "evolution.snapshot":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    yield {"t": "evolution.snapshot", "data": self._redact(service.evolution_snapshot())}
            elif msg == "dream.run":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    report = service.dream_cycle(owner_id=str(payload.get("owner_id", "local-user"))[:128], workspace_id=str(payload.get("workspace_id", session_id))[:256])
                    yield {"t": "dream.result", "data": self._redact(report)}
            elif msg == "assistant.briefing":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    kind = str(payload.get("kind", "morning")).strip()[:64]
                    yield {"t": "assistant.briefing.result", "data": self._redact(service.assistant_briefing(kind))}
            elif msg == "needle.status":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    yield {"t": "needle.status.result", "data": self._redact(service.needle_status())}
            elif msg == "oss.forge.inspect":
                service = getattr(self.core, "operator_service", None)
                url = str(payload.get("url", "")).strip()
                if service is None or not url or len(url) > 4096:
                    yield self._error("invalid public repository URL")
                else:
                    yield {"t": "oss.forge.inspect.result", "data": self._redact(service.forge_inspect(url))}
            elif msg == "oss.forge.stage":
                service = getattr(self.core, "operator_service", None)
                url = str(payload.get("url", "")).strip()
                if service is None or not url or len(url) > 4096:
                    yield self._error("invalid public repository URL")
                else:
                    yield {"t": "oss.forge.stage.result", "data": self._redact(service.forge_stage(url))}
            elif msg == "evolution.self_edit.propose":
                service = getattr(self.core, "operator_service", None)
                relative_path = str(payload.get("relative_path", "")).strip()
                new_content = str(payload.get("new_content", ""))
                rationale = str(payload.get("rationale", "operator proposal"))
                if service is None or not relative_path or len(new_content.encode("utf-8")) > 2_000_000:
                    yield self._error("invalid self-edit proposal")
                else:
                    yield {"t": "evolution.self_edit.propose.result", "data": self._redact(service.self_edit_propose(relative_path, new_content, rationale))}
            elif msg == "evolution.self_edit.canary":
                service = getattr(self.core, "operator_service", None)
                candidate_id = str(payload.get("candidate_id", "")).strip()
                proposal = payload.get("proposal")
                approval_token = str(payload.get("approval_token", "")).strip() or None
                if service is None or not candidate_id or not isinstance(proposal, dict):
                    yield self._error("invalid self-edit canary request")
                else:
                    yield {"t": "evolution.self_edit.canary.result", "data": self._redact(service.self_edit_canary(candidate_id, proposal, approval_token=approval_token))}
            elif msg == "tasks.list":
                service = getattr(self.core, "operator_service", None)
                if service is None:
                    yield self._error("operator service unavailable")
                else:
                    state = payload.get("state")
                    limit = int(payload.get("limit", 100))
                    yield {"t": "tasks.result", "data": {"tasks": self._redact(service.list_tasks(state=str(state) if state else None, limit=limit))}}
            elif msg == "task.cancel":
                service = getattr(self.core, "operator_service", None)
                task_id = str(payload.get("task_id", "")).strip()
                if service is None or not task_id:
                    yield self._error("operator service or task id unavailable")
                else:
                    yield {"t": "task.result", "data": self._redact(service.cancel_task(task_id))}
            elif msg == "offline.enqueue":
                service = getattr(self.core, "operator_service", None)
                kind = str(payload.get("kind", "")).strip()
                data = payload.get("payload")
                if service is None or not kind or not isinstance(data, dict):
                    yield self._error("invalid offline command")
                else:
                    yield {"t": "offline.result", "data": self._redact(service.queue_offline(kind, data, idempotency_key=payload.get("idempotency_key")))}
            elif msg == "metrics.request":
                metrics = getattr(self.core, "metrics", None)
                supreme = getattr(self.core, "supreme", None)
                payload_metrics = {
                    "prometheus": metrics.prometheus_metrics() if metrics is not None and hasattr(metrics, "prometheus_metrics") else "",
                    "runtime": supreme.snapshot() if supreme is not None else {},
                }
                yield {"t": "metrics.result", "data": payload_metrics}
            elif msg == "models.request":
                models = self.core.router.list_backends()
                yield {
                    "t": "model.list",
                    "data": {"models": [str(row.get("name")) for row in models if isinstance(row, dict) and row.get("name")]},
                }
            elif msg == "chat.request":
                text = str(payload.get("text", "")).strip()
                if not text or len(text.encode("utf-8")) > _MAX_TEXT:
                    yield self._error("invalid chat text")
                    return
                requested_session = str(payload.get("session_id", session_id))[:256] or session_id
                task_type = str(payload.get("task_type", "default"))[:64]
                governor = getattr(self.core, "supreme", None)
                if governor is not None:
                    reservation = governor.resources.acquire(f"desktop:{session_id}", slots=1, background=True)
                else:
                    reservation = None
                try:
                    result = await asyncio.wait_for(
                        asyncio.to_thread(self.core.chat, text, False, task_type, f"desktop:{requested_session}"),
                        timeout=60.0,
                    )
                finally:
                    if reservation is not None:
                        governor.resources.release(reservation)
                text_result = str(result)
                if text_result:
                    yield {"t": "chat.delta", "data": {"text": text_result}}
                yield {"t": "chat.result", "data": {"text": text_result}}
            elif msg == "mission.create":
                goal = str(payload.get("goal", "")).strip()
                if not goal or len(goal) > 20_000:
                    yield self._error("invalid mission goal")
                    return
                service = getattr(self.core, "mission_service", None)
                if service is None:
                    yield self._error("mission service unavailable")
                    return
                task_manager = getattr(self.core, "universal_tasks", None)
                task = None
                if task_manager is not None:
                    task = task_manager.create(
                        kind="mission",
                        title=goal[:2_000],
                        owner=self.operator_id,
                        metadata={"source": "flutter", "session_id": session_id},
                    )
                    task_manager.update(task.task_id, state="running")
                    task_manager.bind_cancel_handler(task.task_id, lambda: self._cancel_mission_task(service, task.task_id))
                governor = getattr(self.core, "supreme", None)
                if governor is not None:
                    reservation = governor.resources.acquire(f"mission:{self.operator_id}", slots=1, background=True)
                else:
                    reservation = None
                try:
                    mission_id = task.task_id if task is not None else None
                    result = await asyncio.wait_for(service.execute_mission(goal, mission_id=mission_id, owner=self.operator_id), timeout=300.0)
                    if task_manager is not None and task is not None:
                        task_manager.update(
                            task.task_id,
                            state="succeeded" if result.get("ok") else "failed",
                            result_summary=str(result.get("final_result") or result.get("error") or "mission complete")[:4_000],
                            error=None if result.get("ok") else str(result.get("error", "mission failed")),
                        )
                except asyncio.CancelledError:
                    if task_manager is not None and task is not None and task_manager.get(task.task_id) is not None:
                        current = task_manager.get(task.task_id)
                        if current and current.state not in {"cancelled", "failed", "succeeded"}:
                            task_manager.update(task.task_id, state="cancelled", error="request cancelled")
                    raise
                finally:
                    if reservation is not None:
                        governor.resources.release(reservation)
                yield {
                    "t": "mission.update",
                    "data": {
                        "mission_id": str(result.get("mission_id", "")),
                        "goal": goal,
                        "status": "completed" if result.get("ok") else "failed",
                        "steps": result.get("steps", []),
                        "error": result.get("error"),
                    },
                }
            elif msg == "mission.status":
                service = getattr(self.core, "mission_service", None)
                mission_id = str(payload.get("mission_id", "")).strip()
                result = await service.get_mission_status(mission_id) if service is not None else {"ok": False, "error": "mission service unavailable"}
                yield {"t": "mission.update", "data": result.get("status", result)}
            elif msg == "mission.timeline":
                mission_id = str(payload.get("mission_id", "")).strip()
                kernel = getattr(self.core, "kernel", None)
                if not mission_id or kernel is None:
                    yield self._error("mission timeline unavailable")
                    return
                timeline = await asyncio.to_thread(kernel.mission_timeline, mission_id, limit=int(payload.get("limit", 300)))
                yield {"t": "mission.timeline.result", "data": timeline}
            elif msg == "mission.cancel":
                mission_id = str(payload.get("mission_id", "")).strip()
                service = getattr(self.core, "mission_service", None)
                active = getattr(service, "_active_missions", {}) if service is not None else {}
                record = active.get(mission_id) if isinstance(active, dict) else None
                job_id = record.get("job_id") if isinstance(record, dict) else None
                kernel = getattr(self.core, "kernel", None)
                if kernel is not None:
                    kernel.cancel.cancel(mission_id)
                    kernel.publish("mission.cancel_requested", {"mission_id": mission_id, "operator_id": self.operator_id})
                engine = getattr(self.core, "job_engine", None)
                cancelled = bool(job_id and engine is not None and engine.cancel(job_id))
                yield {
                    "t": "mission.update",
                    "data": {"mission_id": mission_id, "status": "cancelled" if cancelled else "failed", "error": None if cancelled else "mission could not be cancelled"},
                }
            elif msg == "workflow.create":
                service = getattr(self.core, "workflow_service", None)
                if service is None:
                    yield self._error("workflow service unavailable")
                    return
                workflow_id = service.create_visual(
                    str(payload.get("name", "JARVIS Workflow"))[:256],
                    list(payload.get("nodes", [])),
                    list(payload.get("edges", [])),
                )
                yield {"t": "workflow.saved", "data": {"workflow_id": workflow_id}}
            elif msg == "workflow.get":
                service = getattr(self.core, "workflow_service", None)
                workflow_id = str(payload.get("workflow_id", "")).strip()
                definition = service.get_visual(workflow_id) if service is not None else None
                if definition is None:
                    yield self._error("workflow not found")
                else:
                    yield {"t": "workflow.definition", "data": definition}
            elif msg == "workflow.compile":
                service = getattr(self.core, "workflow_service", None)
                workflow_id = str(payload.get("workflow_id", "")).strip()
                if service is None:
                    yield self._error("workflow service unavailable")
                else:
                    report = service.visual_compile_report(workflow_id)
                    yield {"t": "workflow.compiled", "data": report}
            elif msg == "workflow.run":
                yield {"t": "workflow.result", "data": await self._run_workflow(payload, session_id)}
            elif msg == "security.webauthn.begin":
                fabric = getattr(self.core, "nextgen", None)
                control = getattr(fabric, "webauthn", None)
                if control is None:
                    yield self._error("WebAuthn control plane unavailable")
                else:
                    purpose = str(payload.get("purpose", "control")).strip()[:64] or "control"
                    challenge = control.begin(self.operator_id, purpose=purpose)
                    yield {"t": "webauthn.challenge", "data": {"challenge_id": challenge.challenge_id, "challenge": challenge.challenge, "expires_at": challenge.expires_at, "purpose": challenge.purpose, "operator_id": self.operator_id}}
            elif msg == "security.webauthn.verify":
                fabric = getattr(self.core, "nextgen", None)
                control = getattr(fabric, "webauthn", None)
                if control is None:
                    yield self._error("WebAuthn control plane unavailable")
                else:
                    ok = control.verify_assertion(
                        str(payload.get("challenge_id", "")),
                        str(payload.get("credential_id", "")),
                        base64.b64decode(str(payload.get("signature_der_b64", "")), validate=True),
                        client_data_json=base64.b64decode(str(payload.get("client_data_json_b64", "")), validate=True),
                        authenticator_data=base64.b64decode(str(payload.get("authenticator_data_b64", "")), validate=True),
                        operator_id=self.operator_id,
                        origin=str(payload.get("origin") or "") or None,
                    )
                    if not ok:
                        raise PermissionError("WebAuthn verification failed")
                    yield {"t": "webauthn.verified", "data": {"ok": True, "operator_id": self.operator_id}}
            elif msg == "nextgen.status":
                fabric = getattr(self.core, "nextgen", None)
                if fabric is None:
                    yield self._error("nextgen platform unavailable")
                else:
                    yield {"t": "nextgen.status", "data": fabric.health()}
            elif msg == "settings.get":
                service = getattr(self.core, "settings_service", None)
                if service is None:
                    yield self._error("settings service unavailable")
                else:
                    yield {"t": "settings.result", "data": service.metadata()}
            elif msg == "frontier.diagnostics":
                service = getattr(self.core, "operator_service", None)
                if service is None or not hasattr(service, "diagnostic_bundle"):
                    yield self._error("operator diagnostics unavailable")
                else:
                    yield {"t": "frontier.diagnostics.result", "data": service.diagnostic_bundle(str(payload.get("path", "")).strip() or None)}
            elif msg == "frontier.model.restore":
                service = getattr(self.core, "operator_service", None)
                if service is None or not hasattr(service, "restore_model"):
                    yield self._error("operator model control unavailable")
                else:
                    yield {"t": "frontier.model.restore.result", "data": service.restore_model(str(payload.get("model", "")).strip())}
            elif msg == "settings.set":
                service = getattr(self.core, "settings_service", None)
                if service is None:
                    yield self._error("settings service unavailable")
                else:
                    key = str(payload.get("key", "")).strip()
                    old_value = service.get(key, None)
                    change = service.set(key, payload.get("value"))
                    frontier = getattr(self.core, "frontier_control", None)
                    if frontier is not None:
                        try:
                            frontier.configuration.record(actor=self.operator_id, key=key, old_value=old_value, new_value=payload.get("value"), reason=str(payload.get("reason", "desktop settings change"))[:1000])
                        except PermissionError:
                            raise
                        except Exception:
                            logger.exception("configuration_journal_failed")
                    if bool(payload.get("persist", True)) and not service.save():
                        raise RuntimeError("settings persistence failed")
                    yield {"t": "settings.result", "data": {"ok": True, **change}}
            elif msg == "autopilot.status":
                autopilot = getattr(self.core, "autopilot", None)
                if autopilot is None:
                    yield self._error("autopilot unavailable")
                else:
                    yield {"t": "autopilot.status", "data": autopilot.status()}
            elif msg == "autopilot.authorize":
                yield {"t": "autopilot.status", "data": self._authorize_autopilot(payload)}
            elif msg == "autopilot.stop":
                autopilot = getattr(self.core, "autopilot", None)
                if autopilot is None:
                    yield self._error("autopilot unavailable")
                else:
                    autopilot.stop()
                    yield {"t": "autopilot.status", "data": autopilot.status()}
            elif msg == "workers.list":
                manager = getattr(self.core, "long_term_workers", None)
                if manager is None:
                    yield self._error("long-term workers unavailable")
                else:
                    yield {"t": "workers.result", "data": manager.snapshot()}
            elif msg == "worker.create":
                yield {"t": "worker.result", "data": self._create_worker(payload)}
            elif msg == "worker.stop":
                manager = getattr(self.core, "long_term_workers", None)
                worker_id = str(payload.get("worker_id", "")).strip()
                if manager is None:
                    yield self._error("long-term workers unavailable")
                elif not worker_id:
                    yield self._error("worker_id is required")
                else:
                    state = manager.stop(worker_id)
                    yield {"t": "worker.result", "data": {"ok": True, "worker": {"worker_id": state.worker_id, "role": state.role, "status": state.status, "cycles": state.cycles, "last_error": state.last_error}}}
            elif msg == "workers.stop_all":
                manager = getattr(self.core, "long_term_workers", None)
                if manager is None:
                    yield self._error("long-term workers unavailable")
                else:
                    manager.stop_all()
                    yield {"t": "workers.result", "data": {"ok": True, **manager.snapshot()}}
            elif msg == "action.request":
                capability = str(payload.get("capability", "")).strip()
                if capability == "system.observe":
                    yield {"t": "action.result", "data": {"ok": True, "state": self._snapshot(self.core)}}
                else:
                    yield {"t": "action.result", "data": {"ok": False, "state": "denied", "error": "action requires an authorized core-side capability flow"}}
            else:
                yield self._error(f"unknown desktop message: {msg}")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("desktop_command_failed", extra={"message_type": msg})
            yield self._error(str(exc) or "desktop command failed")

        if msg != "heartbeat":
            yield {"t": "telemetry", "data": self._snapshot(self.core)}

    async def _run_workflow(self, payload: dict[str, Any], session_id: str) -> dict[str, Any]:
        """Execute an approved visual workflow through the core authority."""
        service = getattr(self.core, "workflow_service", None)
        authority = getattr(self.core, "mission_authority", None)
        workflow_id = str(payload.get("workflow_id", "")).strip()
        workflow_input = str(payload.get("input", ""))[:20_000]
        if service is None or authority is None:
            raise RuntimeError("workflow runtime unavailable")
        compiled = service.compile_visual(workflow_id)
        capabilities = tuple(sorted({step.capability for step in compiled.steps}))
        mission = authority.create(compiled.name, compiled.steps, owner=f"desktop:{session_id}", capabilities=capabilities)
        task_manager = getattr(self.core, "universal_tasks", None)
        task = None
        if task_manager is not None:
            task = task_manager.create(
                kind="workflow",
                title=compiled.name[:2_000],
                owner=self.operator_id,
                external_id=mission.mission_id,
                metadata={"source": "flutter", "session_id": session_id, "workflow_id": workflow_id},
            )
            task_manager.update(task.task_id, state="running")
            task_manager.bind_cancel_handler(task.task_id, lambda: authority.cancel(mission.mission_id))
        results: dict[str, Any] = {}

        def execute_visual(step: Any) -> Any:
            meta = dict(step.metadata)
            node_type = str(meta.get("node_type", ""))
            dep_values = [results.get(dep) for dep in step.dependencies]
            value = next((item for item in reversed(dep_values) if item is not None), workflow_input)
            if node_type in {"input.text", "user_input"}:
                output: Any = workflow_input
            elif node_type in {"ai.router", "ai_router"}:
                output = self.core.chat(str(value), session_id=f"workflow:{mission.mission_id}")
            elif node_type in {"agent.researcher", "research_agent"}:
                output = self.core.agent_service.run_task("research", {"task": str(value)}, mission_id=mission.mission_id)
            elif node_type in {"tool.web_search", "web_search"}:
                output = self.core.tool_service.execute("web_search", {"query": str(value)}, mission_id=mission.mission_id)
            elif node_type in {"memory.write", "memory_write"}:
                if self.core.memory is None:
                    raise RuntimeError("memory subsystem unavailable")
                self.core.memory.add(f"workflow:{mission.mission_id}", "workflow", str(value))
                output = {"ok": True, "stored": True}
            elif node_type in {"policy.check", "policy_check"}:
                from core.policy_gateway import RiskLevel

                decision = self.core.policy_gateway.evaluate(capability=step.capability, risk=RiskLevel.L0, mission_id=mission.mission_id)
                output = {"ok": decision.allowed, "reason": decision.reason, "decision_id": decision.decision_id}
                if not decision.allowed:
                    raise PermissionError(decision.reason)
            elif node_type in {"output.text", "output"}:
                output = value
            else:
                raise ValueError(f"unsupported executable workflow node: {node_type}")
            results[step.step_id] = output
            return output

        try:
            result = await asyncio.to_thread(authority.execute, mission.mission_id, compiled.steps, execute_visual)
            if task_manager is not None and task is not None:
                task_manager.update(
                    task.task_id,
                    state="succeeded" if result.get("ok") else "failed",
                    result_summary=str(result.get("error") or "workflow complete")[:4_000],
                    error=None if result.get("ok") else str(result.get("error", "workflow failed")),
                )
            return result
        except asyncio.CancelledError:
            if task_manager is not None and task is not None and task_manager.get(task.task_id) is not None:
                current = task_manager.get(task.task_id)
                if current and current.state not in {"cancelled", "failed", "succeeded"}:
                    task_manager.update(task.task_id, state="cancelled", error="request cancelled")
            raise

    def _cancel_mission_task(self, service: Any, mission_id: str) -> bool:
        """Cancel a mission created through the desktop task center."""
        active = getattr(service, "_active_missions", {})
        record = active.get(mission_id) if isinstance(active, dict) else None
        job_id = record.get("job_id") if isinstance(record, dict) else None
        engine = getattr(self.core, "job_engine", None)
        if job_id and engine is not None:
            return bool(engine.cancel(job_id))
        authority = getattr(self.core, "mission_authority", None)
        if authority is not None:
            try:
                authority.cancel(mission_id)
                return True
            except Exception:
                return False
        return False

    def _authorize_autopilot(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Perform capability-aware autopilot authorization."""
        autopilot = getattr(self.core, "autopilot", None)
        if autopilot is None:
            raise RuntimeError("autopilot unavailable")
        requested = tuple(str(item).strip() for item in (payload.get("capabilities") or []) if str(item).strip())
        challenge_id = str(payload.get("webauthn_challenge_id", "")).strip()
        operator_id = str(payload.get("operator_id", self.operator_id)).strip() or self.operator_id
        high_impact = any(cap in {"process.spawn", "code.execute", "device.write", "filesystem.write"} for cap in requested)
        step_up_verified = False
        if high_impact:
            control = getattr(getattr(self.core, "nextgen", None), "webauthn", None)
            if control is None or not challenge_id or not control.consume_authorization(challenge_id, operator_id=operator_id, purpose="autopilot"):
                raise PermissionError("high-impact capabilities require WebAuthn step-up verification")
            step_up_verified = True
        autopilot.authorize(
            str(payload.get("approval_token", "")),
            reason=str(payload.get("reason", "authorized autopilot")),
            capabilities=requested,
            step_up_verified=step_up_verified,
        )
        return {"ok": True, **autopilot.status()}

    def _create_worker(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Create a bounded long-term worker after policy authorization."""
        manager = getattr(self.core, "long_term_workers", None)
        autopilot = getattr(self.core, "autopilot", None)
        if manager is None or autopilot is None:
            raise RuntimeError("long-term worker system unavailable")
        if not autopilot.authorize_action("autonomy.worker.start"):
            raise PermissionError("authorized autopilot session required")
        role = str(payload.get("role", "")).strip()
        objective = str(payload.get("objective", "")).strip()
        interval_seconds = float(payload.get("interval_seconds", 30.0))
        spec = manager.register(
            role,
            objective,
            lambda worker, cycle: self.core.autonomous_executive.trigger(worker.objective, priority=70, source=f"long-term:{worker.worker_id}"),
            interval_seconds=interval_seconds,
        )
        state = manager.start(spec.worker_id)
        return {"ok": True, "worker": {"worker_id": spec.worker_id, "role": spec.role, "objective": spec.objective, "status": state.status}}

    @staticmethod
    def _error(message: str) -> dict[str, Any]:
        """Create a normalized error response."""
        return {"t": "error", "data": {"error": str(message)[:2000]}}



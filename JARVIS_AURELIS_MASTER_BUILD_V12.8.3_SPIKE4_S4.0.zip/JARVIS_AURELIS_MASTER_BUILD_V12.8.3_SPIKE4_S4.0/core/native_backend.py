"""Native llama.cpp inference backend."""
from __future__ import annotations
import logging
from typing import Iterator
from core.types import BackendResult, ModelInfo

logger = logging.getLogger("jarvis.native")


class NativeInferenceBackend:
    def __init__(self, model_path: str, cfg: dict, info: ModelInfo):
        self.model_path = model_path
        self.cfg = cfg
        self.info = info
        self._llm = None

    def load(self) -> bool:
        try:
            from llama_cpp import Llama
            self._llm = Llama(
                model_path=self.model_path,
                n_ctx=self.cfg.get("n_ctx", 4096),
                n_batch=self.cfg.get("n_batch", 512),
                n_gpu_layers=self.cfg.get("n_gpu_layers", 0),
                verbose=self.cfg.get("verbose", False),
            )
            return True
        except Exception as exc:
            logger.warning(f"Failed to load native model {self.info.name}: {exc}")
            return False

    def generate(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7, stream: bool = False) -> BackendResult | Iterator[BackendResult | str]:
        if self._llm is None and not self.load():
            return BackendResult(text="[Native model unavailable]", ok=False, error_type="model_unavailable")
        try:
            if stream:
                return self._stream(prompt, max_tokens, temperature)
            out = self._llm(prompt, max_tokens=max_tokens, temperature=temperature)
            text = out.get("choices", [{}])[0].get("text", "")
            prompt_tokens = int(out.get("usage", {}).get("prompt_tokens", out.get("prompt_eval_count", 0)) or 0)
            completion_tokens = int(out.get("usage", {}).get("completion_tokens", out.get("eval_count", 0)) or 0)
            return BackendResult(text=text, model=self.info.name, prompt_tokens=prompt_tokens, completion_tokens=completion_tokens, tokens_used=completion_tokens)
        except Exception as exc:
            logger.error(f"Native inference error: {exc}")
            return BackendResult(text=f"[Inference error: {exc}]", ok=False, error_type="inference_error")

    def _stream(self, prompt: str, max_tokens: int, temperature: float) -> Iterator[BackendResult | str]:
        try:
            for chunk in self._llm(prompt, max_tokens=max_tokens, temperature=temperature, stream=True):
                yield chunk.get("choices", [{}])[0].get("text", "")
        except Exception as exc:
            logger.error("Native streaming inference error: %s", exc)
            yield BackendResult(text=f"[Inference error: {exc}]", ok=False, error_type="inference_error")

    def unload(self) -> None:
        self._llm = None



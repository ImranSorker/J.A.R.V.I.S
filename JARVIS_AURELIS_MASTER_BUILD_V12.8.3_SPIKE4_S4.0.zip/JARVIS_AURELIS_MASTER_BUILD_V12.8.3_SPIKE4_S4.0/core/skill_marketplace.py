"""Trusted skill catalogue protocol with signed manifests and explicit permissions."""
from __future__ import annotations

import hashlib
import hmac
from dataclasses import replace
from typing import Sequence

from core.contracts.platform import SkillManifest


class SkillTrustError(PermissionError):
    """Raised when a skill manifest fails policy or signature verification."""


class SkillMarketplace:
    """Install declarative skill manifests without executing untrusted code."""

    def __init__(self, secret: bytes, *, allowed_permissions: Sequence[str] = ()) -> None:
        if len(secret) < 32:
            raise ValueError("skill marketplace secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self.allowed_permissions = frozenset(str(value) for value in allowed_permissions)
        self._skills: dict[str, SkillManifest] = {}

    def sign(self, manifest: SkillManifest) -> SkillManifest:
        """Return a manifest signed over its immutable content."""
        unsigned = replace(manifest, signature="")
        signature = hmac.new(self._secret, self._canonical(unsigned), hashlib.sha256).hexdigest()
        return replace(unsigned, signature=signature)

    def verify(self, manifest: SkillManifest) -> bool:
        """Verify checksum, signature and permission policy."""
        if not set(manifest.permissions).issubset(self.allowed_permissions):
            return False
        unsigned = replace(manifest, signature="")
        expected = hmac.new(self._secret, self._canonical(unsigned), hashlib.sha256).hexdigest()
        return hmac.compare_digest(manifest.signature, expected)

    def install(self, manifest: SkillManifest) -> None:
        """Install a trusted manifest, replacing only the same skill name."""
        if not manifest.name.strip() or not manifest.version.strip():
            raise ValueError("skill name and version are required")
        if not self.verify(manifest):
            raise SkillTrustError("skill manifest failed trust verification")
        self._skills[manifest.name] = manifest

    def remove(self, name: str) -> bool:
        """Remove a registered skill."""
        return self._skills.pop(str(name), None) is not None

    def list(self) -> list[SkillManifest]:
        """Return deterministic skill catalogue."""
        return [self._skills[name] for name in sorted(self._skills)]

    @staticmethod
    def _canonical(manifest: SkillManifest) -> bytes:
        return "|".join((manifest.name, manifest.version, ",".join(manifest.capabilities), manifest.entrypoint, ",".join(manifest.permissions), manifest.checksum, repr(sorted(manifest.metadata.items())))).encode()



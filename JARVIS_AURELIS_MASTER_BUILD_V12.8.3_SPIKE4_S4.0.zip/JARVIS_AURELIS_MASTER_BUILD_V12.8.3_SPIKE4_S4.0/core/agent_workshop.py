"""J.A.R.V.I.S. Agent Workshop 2.0.

Tenant-scoped laboratory for draft authoring, test/evaluation, comparison and
promotion. The Workshop never writes production state and never bypasses
P2-E/P2-B/P2-D boundaries.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import math
import sqlite3
import statistics
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_genome import AgentGenome, diff as genome_diff
from core.event_fabric import AuthContext, EventEnvelope, EventLineage, ProducedBy, EventBus
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

BASE_DIR = Path(__file__).resolve().parent
SCHEMA_DIR = BASE_DIR / "schemas"

SESSION_SCHEMA = SCHEMA_DIR / "workshop_session_v1.schema.json"
WORKFLOW_SCHEMA = SCHEMA_DIR / "workshop_workflow_v1.schema.json"
PROMPT_SCHEMA = SCHEMA_DIR / "workshop_prompt_program_v1.schema.json"
PROFILE_SCHEMA = SCHEMA_DIR / "evaluation_profile_v1.schema.json"
EVAL_SCHEMA = SCHEMA_DIR / "evaluation_report_v1.schema.json"
BENCHMARK_SCHEMA = SCHEMA_DIR / "benchmark_v1.schema.json"
PROMOTION_SCHEMA = SCHEMA_DIR / "promotion_record_v1.schema.json"
COMPARISON_SCHEMA = SCHEMA_DIR / "comparison_report_v1.schema.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _b64d(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"), validate=True)


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _hash(value: Any) -> str:
    return _sha(canonical_bytes(value))


def _sign(doc: Mapping[str, Any], key: Ed25519PrivateKey) -> dict[str, Any]:
    body = copy.deepcopy(dict(doc))
    body.pop("signature", None)
    body["signer_public_key"] = _b64(key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    signature = _b64(key.sign(canonical_bytes(body)))
    body["signature"] = signature
    return body


def verify_signed(doc: Mapping[str, Any]) -> bool:
    try:
        body = dict(doc)
        signature = str(body.pop("signature"))
        public = _b64d(str(body["signer_public_key"]))
        Ed25519PublicKey.from_public_bytes(public).verify(_b64d(signature), canonical_bytes(body))
        return True
    except (KeyError, InvalidSignature, ValueError, TypeError, UnicodeError):
        return False


class WorkshopError(RuntimeError):
    """Base Workshop control-plane error."""


class SessionState(StrEnum):
    OPEN = "open"
    PAUSED = "paused"
    CLOSED = "closed"
    PROMOTED = "promoted"
    DISCARDED = "discarded"


class WorkshopKind(StrEnum):
    AGENT = "agent"
    SKILL = "skill"
    TOOL = "tool"
    WORKFLOW = "workflow"
    TEMPLATE = "template"
    COMPOSITE = "composite"


class WorkshopExecutionMode(StrEnum):
    SIMULATION = "simulation"
    ISOLATED = "isolated"
    RESTRICTED = "restricted"


SESSION_TRANSITIONS = {
    SessionState.OPEN: frozenset({SessionState.PAUSED, SessionState.CLOSED, SessionState.PROMOTED, SessionState.DISCARDED}),
    SessionState.PAUSED: frozenset({SessionState.OPEN, SessionState.CLOSED, SessionState.DISCARDED}),
    SessionState.CLOSED: frozenset({SessionState.PROMOTED, SessionState.DISCARDED}),
    SessionState.PROMOTED: frozenset(),
    SessionState.DISCARDED: frozenset(),
}


@dataclass(frozen=True, slots=True)
class WorkshopSession:
    document: Mapping[str, Any]

    @property
    def session_id(self) -> str:
        return str(self.document["session_id"])

    @property
    def tenant_id(self) -> str:
        return str(self.document["tenant_id"])

    @property
    def state(self) -> SessionState:
        return SessionState(self.document["state"])

    @property
    def draft(self) -> Mapping[str, Any]:
        return copy.deepcopy(self.document["working_draft"])

    def verify(self) -> bool:
        body = dict(self.document)
        try:
            sig = _b64d(str(body.pop("signature")))
            integ = str(body.pop("integrity_hash"))
            if _hash(body) != integ:
                return False
            signed_body = dict(body)
            signed_body["integrity_hash"] = integ
            public = _b64d(str(self.document["signer_public_key"]))
            Ed25519PublicKey.from_public_bytes(public).verify(sig, canonical_bytes(signed_body))
            return True
        except (KeyError, InvalidSignature, ValueError, TypeError, UnicodeError):
            return False


class HarnessRunner(Protocol):
    def run(self, *, mode: str, seed: int, environment_hash: str, budgets: Mapping[str, Any], implementation: Callable[[], Mapping[str, Any]]) -> Mapping[str, Any]: ...


class WorkshopSecurityAuthority(Protocol):
    def authorize(self, operation: str, tenant_id: str, subject: Mapping[str, Any]) -> str | bool: ...


class DeterministicHarness:
    """Minimal laboratory adapter; production callers should inject P2-E AgentHarness."""
    def run(self, *, mode: str, seed: int, environment_hash: str, budgets: Mapping[str, Any], implementation: Callable[[], Mapping[str, Any]]) -> Mapping[str, Any]:
        if mode not in {WorkshopExecutionMode.SIMULATION.value, WorkshopExecutionMode.ISOLATED.value, WorkshopExecutionMode.RESTRICTED.value}:
            raise WorkshopError("Workshop forbids trusted-mode execution")
        start = time.monotonic()
        result = dict(implementation())
        return {"result": result, "wall_seconds": time.monotonic() - start, "seed": seed, "environment_hash": environment_hash, "mode": mode}


class P2EHarnessAdapter:
    """Adapter around the real P2-E AgentHarness; context creation remains Security-Authority owned."""
    def __init__(self, harness: Any, context_factory: Callable[..., Any]) -> None:
        self.harness = harness
        self.context_factory = context_factory

    def run(self, *, mode: str, seed: int, environment_hash: str, budgets: Mapping[str, Any], implementation: Callable[[], Mapping[str, Any]]) -> Mapping[str, Any]:
        context = self.context_factory(mode=mode, seed=seed, environment_hash=environment_hash, budgets=budgets)
        handle = self.harness.start(self.harness.prepare(context, implementation))
        result = self.harness.wait(handle, timeout=float(budgets.get("wall_seconds", 60.0)))
        if result is None:
            raise WorkshopError("P2-E harness execution timed out")
        payload = result.to_dict() if hasattr(result, "to_dict") else {"ok": getattr(result, "ok", True)}
        return {"result": payload, "resource_profile": getattr(result, "accounting", {}), "mode": mode, "seed": seed, "environment_hash": environment_hash}


class DraftEditor:
    """Schema-backed, side-effect-free editor."""
    def __init__(self, workshop: "AgentWorkshop", session_id: str, target: str, schema_path: Path) -> None:
        self.workshop = workshop
        self.session_id = session_id
        self.target = target
        self.schema_path = schema_path

    def open(self) -> Mapping[str, Any]:
        return self.workshop.read_draft(self.session_id)

    def read(self) -> Mapping[str, Any]:
        return self.workshop.read_draft(self.session_id)

    def edit(self, patch: Mapping[str, Any]) -> Mapping[str, Any]:
        current = copy.deepcopy(self.workshop.read_draft(self.session_id))
        updated = self.workshop._merge_patch(current, patch)
        self.workshop._validate_schema(self.schema_path, updated)
        self.workshop._reject_escalation(self.session_id, updated)
        return self.workshop._commit_draft(self.session_id, updated)

    def validate(self) -> Mapping[str, Any]:
        draft = self.read()
        issues = self.workshop._validate_schema(self.schema_path, draft, raise_on_error=False)
        return {"ok": not issues, "issues": issues}

    def diff(self, other: Mapping[str, Any] | str) -> Mapping[str, Any]:
        left = self.read()
        right = self.workshop._resolve_draft_or_ref(other)
        if self.target in {"agent", "genome"} and "immutable_identity" in left and "immutable_identity" in right:
            return genome_diff(left, right).to_dict()
        return self.workshop._structured_diff(left, right)

    def revert(self, to_draft_version: int) -> Mapping[str, Any]:
        draft = self.workshop._history_for_version(self.session_id, to_draft_version)
        return self.workshop._commit_draft(self.session_id, draft, reason="revert")

    def save(self) -> str:
        return self.workshop._draft_id(self.session_id)


class WorkflowValidator:
    @staticmethod
    def validate(workflow: Mapping[str, Any]) -> None:
        nodes = {n["node_id"]: n for n in workflow["nodes"]}
        if len(nodes) != len(workflow["nodes"]):
            raise WorkshopError("duplicate workflow node_id")
        for edge in workflow["edges"]:
            if edge["from"] not in nodes or edge["to"] not in nodes:
                raise WorkshopError("workflow edge references missing node")
            if edge["from"] == edge["to"]:
                raise WorkshopError("self-cycle is not allowed")
        indegree = {k: 0 for k in nodes}
        graph = {k: [] for k in nodes}
        for edge in workflow["edges"]:
            if edge["kind"] == "compensation":
                continue
            graph[edge["from"]].append(edge["to"])
            indegree[edge["to"]] += 1
        q = [k for k, v in indegree.items() if v == 0]
        visited = 0
        while q:
            n = q.pop(0); visited += 1
            for nxt in graph[n]:
                indegree[nxt] -= 1
                if indegree[nxt] == 0: q.append(nxt)
        if visited != len(nodes):
            bounded = [n for n in workflow["nodes"] if n["kind"] == "branch" and n.get("max_iterations")]
            if not bounded:
                raise WorkshopError("workflow contains an unbounded cycle")
        irreversible = [n for n in workflow["nodes"] if any(not bool(e.get("reversible")) for e in n.get("side_effects", []))]
        if irreversible and workflow["transaction_boundary"] == "none":
            for node in irreversible:
                if not node.get("compensation_ref"):
                    raise WorkshopError("irreversible workflow node requires compensation or transaction boundary")


class PromptProgramValidator:
    @staticmethod
    def validate(program: Mapping[str, Any]) -> None:
        produced = set()
        side_effecting_steps = {"tool_call", "code"}
        by_id = {s["step_id"]: s for s in program["program"]}
        if len(by_id) != len(program["program"]):
            raise WorkshopError("duplicate prompt-program step_id")
        for step in program["program"]:
            for name in step.get("inputs", []):
                if name not in program["variables"] and name not in produced:
                    raise WorkshopError(f"unknown input variable {name}")
            produced.update(step.get("outputs", []))
        for i, step in enumerate(program["program"]):
            if step["kind"] in side_effecting_steps and i > 0 and not any(s["kind"] == "assert" for s in program["program"][:i]):
                raise WorkshopError("side-effecting PromptProgram step requires a prior assert")
        if program["determinism"] == "nondeterministic" and not program.get("risk_annotation"):
            raise WorkshopError("nondeterministic programs require risk_annotation")


class BenchmarkLibrary:
    def __init__(self, root: str | Path, *, signer: Ed25519PrivateKey, storage_secret: bytes, tenant_id: str, security_authority: WorkshopSecurityAuthority | None = None) -> None:
        self.root = Path(root).resolve(); self.root.mkdir(parents=True, exist_ok=True)
        self.signer = signer; self.secret = bytes(storage_secret); self.tenant_id = tenant_id; self.security_authority = security_authority
        self._db = sqlite3.connect(str(self.root / "benchmarks.db"), check_same_thread=False); self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("CREATE TABLE IF NOT EXISTS benchmarks(tenant_id TEXT NOT NULL,benchmark_id TEXT NOT NULL,version TEXT NOT NULL,document TEXT NOT NULL,tag TEXT NOT NULL,PRIMARY KEY(tenant_id,benchmark_id,version))")
        self._db.commit(); self._lock = threading.RLock()

    @property
    def public_key_b64(self) -> str:
        return _b64(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))

    def register(self, benchmark: Mapping[str, Any]) -> str:
        schema=json.loads(BENCHMARK_SCHEMA.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=32).validate_or_raise({**dict(benchmark), "signature":"x", "integrity_hash":"0"*64, "signer_public_key":self.public_key_b64}, schema)
        existing=self._db.execute("SELECT 1 FROM benchmarks WHERE tenant_id=? AND benchmark_id=? AND version=?",(self.tenant_id,benchmark["benchmark_id"],benchmark["benchmark_version"])).fetchone()
        if existing:
            raise WorkshopError("benchmarks are immutable; publish a new version")
        if benchmark.get("benchmark_id", "").startswith("bench.adversarial"):
            if self.security_authority is None or not bool(self.security_authority.authorize("register_adversarial_benchmark", self.tenant_id, benchmark)):
                raise WorkshopError("Security Authority approval is required for adversarial benchmarks")
        doc = _sign(benchmark, self.signer)
        self._db.execute("INSERT INTO benchmarks VALUES(?,?,?,?,?)", (self.tenant_id, benchmark["benchmark_id"], benchmark["benchmark_version"], json.dumps(doc, sort_keys=True), _hash(doc)))
        self._db.commit(); return f'{benchmark["benchmark_id"]}@{benchmark["benchmark_version"]}'

    def get(self, ref: str) -> Mapping[str, Any]:
        bid, version = ref.rsplit("@", 1)
        row = self._db.execute("SELECT document FROM benchmarks WHERE tenant_id=? AND benchmark_id=? AND version=?", (self.tenant_id, bid, version)).fetchone()
        if not row: raise WorkshopError(f"benchmark not found: {ref}")
        doc = json.loads(row[0])
        if not verify_signed(doc): raise WorkshopError("benchmark signature invalid")
        return doc

    def list(self) -> tuple[Mapping[str, Any], ...]:
        rows = self._db.execute("SELECT document FROM benchmarks WHERE tenant_id=? ORDER BY benchmark_id,version", (self.tenant_id,)).fetchall()
        return tuple(json.loads(row[0]) for row in rows)


@dataclass(frozen=True, slots=True)
class EvaluationProfile:
    profile_id: str
    version: str
    metrics: Mapping[str, float]
    safety_metrics: frozenset[str]


DEFAULT_PROFILES: dict[str, EvaluationProfile] = {
    "profile.quick": EvaluationProfile("profile.quick", "1.0.0", {"correctness": 0.95, "latency_p95": 1.0, "security": 0.0}, frozenset({"security"})),
    "profile.standard": EvaluationProfile("profile.standard", "1.0.0", {"correctness": 0.95, "reliability": 0.95, "tool_accuracy": 0.98, "planning_quality": 0.85, "instruction_following": 0.99, "factuality": 0.95, "security": 0.0, "resource_efficiency": 0.80, "latency_p95": 1.0, "latency_p99": 1.5, "recovery": 0.99, "robustness": 0.90, "reproducibility": 0.99, "evidence_coverage": 0.95}, frozenset({"security", "robustness"})),
    "profile.adversarial": EvaluationProfile("profile.adversarial", "1.0.0", {"correctness": 0.95, "security": 0.0, "robustness": 0.90, "recovery": 0.99, "reproducibility": 0.99, "evidence_coverage": 0.95}, frozenset({"security", "robustness"})),
    "profile.regression": EvaluationProfile("profile.regression", "1.0.0", {"correctness": 0.95, "reliability": 0.95, "robustness": 0.90, "reproducibility": 0.99, "evidence_coverage": 0.95}, frozenset({"security", "robustness"})),
    "profile.production_baseline": EvaluationProfile("profile.production_baseline", "1.0.0", {"correctness": 0.95, "security": 0.0, "resource_efficiency": 0.80, "latency_p95": 1.0, "reproducibility": 0.99}, frozenset({"security"})),
    "profile.research": EvaluationProfile("profile.research", "1.0.0", {"correctness": 0.95, "factuality": 0.95, "reliability": 0.95, "reproducibility": 0.99}, frozenset({"security"})),
}


class AgentEvaluationHarness:
    """Deterministic metric/evidence engine; execution itself is delegated to P2-E."""
    def __init__(self, *, signer: Ed25519PrivateKey, harness: HarnessRunner, event_bus: EventBus, tenant_id: str, security_authority: WorkshopSecurityAuthority | None = None) -> None:
        self.signer = signer; self.harness = harness; self.event_bus = event_bus; self.tenant_id = tenant_id; self.security_authority = security_authority

    def evaluate(self, target: Mapping[str, Any], profile_ref: str, *, seed: int, environment_hash: str, mode: str, budgets: Mapping[str, Any], observations: Mapping[str, Any] | None = None, baseline: Mapping[str, Any] | None = None, threshold_overrides: Mapping[str, float] | None = None, waiver: Mapping[str, Any] | None = None) -> Mapping[str, Any]:
        if mode == "trusted": raise WorkshopError("Workshop evaluation may not run in trusted mode")
        profile = DEFAULT_PROFILES.get(profile_ref)
        if profile is None: raise WorkshopError(f"unknown evaluation profile: {profile_ref}")
        if mode not in {"simulation", "isolated", "restricted"}: raise WorkshopError("invalid Workshop evaluation mode")
        target_doc = copy.deepcopy(dict(target)); target_hash = target_doc.get("draft_hash") or _hash(target_doc)
        started = _now(); correlation_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:jarvis:workshop:evaluate:{self.tenant_id}:{target_hash}:{profile_ref}:{seed}"))
        self._emit("EvaluationStarted", {"target_hash": target_hash, "profile": profile_ref, "seed": seed}, correlation_id)
        obs = dict(observations or {})
        raw = {"target_hash": target_hash, "profile": profile_ref, "seed": seed, "observations": obs}
        metrics = self._derive_metrics(obs, budgets, baseline)
        thresholds = dict(profile.metrics)
        for name, requested in dict(threshold_overrides or {}).items():
            if name not in thresholds:
                raise WorkshopError(f"unknown threshold override: {name}")
            base=float(thresholds[name]); requested=float(requested)
            if name in {"security"}:
                if requested < base: thresholds[name]=requested
                else: raise WorkshopError("security threshold cannot be widened")
            elif name.startswith("latency") or name == "resource_efficiency":
                if requested <= base: thresholds[name]=requested
                else: raise WorkshopError(f"threshold cannot be widened: {name}")
            else:
                if requested >= base: thresholds[name]=requested
                else: raise WorkshopError(f"threshold cannot be widened: {name}")
        waiver_ok = bool(waiver and self.security_authority is not None and self.security_authority.authorize("workshop_evaluation_waiver", self.tenant_id, waiver))
        failing = []
        for name, threshold in thresholds.items():
            value = float(metrics.get(name, 0.0))
            if name in {"security"}:
                failed = value > threshold
            elif name == "resource_efficiency":
                failed = value > threshold
            elif name.startswith("latency"):
                failed = value > threshold
            else:
                failed = value < threshold
            if failed and name not in profile.safety_metrics and waiver_ok:
                continue
            if failed: failing.append(name)
        pass_fail = "fail" if failing else ("conditional" if waiver_ok and any(name not in profile.safety_metrics for name in thresholds) else "pass")
        evidence = {k: {"value": float(v), "threshold": float(thresholds.get(k, 0.0))} for k, v in metrics.items()}
        bundle_hash = _hash({"raw": raw, "metrics": metrics, "evidence": evidence})
        finished = _now()
        report = {
            "schema_version": "1.0.0", "stage": "evaluate", "status": "passed" if pass_fail != "fail" else "failed",
            "checks": {name: (name not in failing) for name in thresholds}, "evaluated_at": time.time(),
            "report_id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:jarvis:workshop:report:{correlation_id}")),
            "target": {"kind": target_doc.get("kind", "composite"), "ref": target_doc.get("ref", target_hash), "version": target_doc.get("version", "1.0.0"), "hash": target_hash},
            "profile": f"{profile.profile_id}@{profile.version}", "seed": int(seed), "environment_hash": environment_hash, "execution_mode": mode,
            "metrics": {k: {"value": float(v), "unit": "ratio"} for k, v in metrics.items()}, "thresholds": thresholds, "pass_fail": pass_fail,
            "failing_metrics": sorted(failing), "benchmark_comparison": None, "waiver": dict(waiver or {}) if waiver_ok else None,
            "evidence_bundle": {"bundle_hash": bundle_hash, "bundle_uri": f"urn:jarvis:workshop:evidence:{bundle_hash}", "raw_outputs": [f"urn:jarvis:workshop:evidence:{bundle_hash}:raw"]},
            "resource_profile": dict(obs.get("resource_profile", {})),
            "reproducibility_evidence": {"seed": seed, "stable": bool(obs.get("reproducible", metrics.get("reproducibility", 0.0) >= 0.99)), "ratio": float(metrics.get("reproducibility", 0.0))},
            "failure_records": list(obs.get("failure_records", [])), "started_at": started, "finished_at": finished,
        }
        signed = _sign(report, self.signer)
        self._emit("EvaluationCompleted", {"report_id": signed["report_id"], "target_hash": target_hash, "pass_fail": pass_fail, "failing_metrics": sorted(failing)}, correlation_id)
        return signed

    @staticmethod
    def _derive_metrics(obs: Mapping[str, Any], budgets: Mapping[str, Any], baseline: Mapping[str, Any] | None) -> dict[str, float]:
        defaults = {
            "correctness": float(obs.get("correctness", 0.0)),
            "reliability": float(obs.get("reliability", 0.0)),
            "tool_accuracy": float(obs.get("tool_accuracy", 0.0)),
            "planning_quality": float(obs.get("planning_quality", 0.0)),
            "instruction_following": float(obs.get("instruction_following", 0.0)),
            "factuality": float(obs.get("factuality", 0.0)),
            "security": float(obs.get("security_violations", obs.get("security", 0.0))),
            "resource_efficiency": float(obs.get("resource_efficiency", 1.0)),
            "latency_p50": float(obs.get("latency_p50", budgets.get("wall_seconds", 1.0))),
            "latency_p95": float(obs.get("latency_p95", budgets.get("wall_seconds", 1.0))),
            "latency_p99": float(obs.get("latency_p99", budgets.get("wall_seconds", 1.0) * 1.5)),
            "recovery": float(obs.get("recovery", 0.0)),
            "robustness": float(obs.get("robustness", 0.0)),
            "reproducibility": float(obs.get("reproducibility", 0.0)),
            "evidence_coverage": float(obs.get("evidence_coverage", obs.get("factuality", 0.0))),
        }
        if baseline:
            for key in ("correctness", "factuality", "tool_accuracy"):
                if key in baseline and key in obs and float(obs[key]) < float(baseline[key]):
                    defaults[f"regression_{key}"] = float(obs[key]) - float(baseline[key])
        return defaults

    def _emit(self, name: str, payload: Mapping[str, Any], correlation_id: str) -> None:
        # The event taxonomy is additive; publish scope is the workshop's explicit authority.
        try:
            producer = ProducedBy("system", "agent-workshop", _sha(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)), "system")
            event = EventEnvelope.create(event_type="Evolution", event_name=name, payload=dict(payload), produced_by=producer, auth_context=AuthContext("agent-workshop", ("events.publish.evolution",), "workshop", None), tenant_id=self.tenant_id, partition_key=str(payload.get("target_hash", self.tenant_id)), correlation_id=correlation_id, lineage=EventLineage(), signing_key=self.signer)
            self.event_bus.publish(event)
        except Exception as exc:
            raise WorkshopError(f"Workshop event publication failed: {type(exc).__name__}: {exc}") from exc


class AgentWorkshop:
    def __init__(self, *, db_path: str | Path, tenant_id: str, signer: Ed25519PrivateKey, event_bus: EventBus, storage_secret: bytes, harness: HarnessRunner | None = None, security_authority: WorkshopSecurityAuthority | None = None, benchmark_root: str | Path | None = None) -> None:
        if not tenant_id: raise ValueError("tenant_id required")
        if len(storage_secret) < 32: raise ValueError("storage_secret must be at least 32 bytes")
        self.tenant_id = tenant_id; self.signer = signer; self.event_bus = event_bus; self.secret = bytes(storage_secret); self.harness = harness or DeterministicHarness(); self.security_authority = security_authority
        self.validator = SchemaValidator(max_errors=64); self._lock = threading.RLock(); self.path = Path(db_path).resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(self.path), check_same_thread=False); self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS sessions(tenant_id TEXT NOT NULL,session_id TEXT PRIMARY KEY,document TEXT NOT NULL,record_hash TEXT NOT NULL,tag TEXT NOT NULL,created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS drafts(session_id TEXT NOT NULL,version INTEGER NOT NULL,draft_json TEXT NOT NULL,draft_hash TEXT NOT NULL,created_at REAL NOT NULL,tag TEXT NOT NULL,PRIMARY KEY(session_id,version));
        CREATE TABLE IF NOT EXISTS artifacts(tenant_id TEXT NOT NULL,artifact_id TEXT PRIMARY KEY,kind TEXT NOT NULL,version TEXT NOT NULL,document TEXT NOT NULL,artifact_hash TEXT NOT NULL,tag TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS evidence(tenant_id TEXT NOT NULL,bundle_hash TEXT PRIMARY KEY,payload TEXT NOT NULL,tag TEXT NOT NULL);
        """); self._db.commit()
        self.benchmarks = BenchmarkLibrary(benchmark_root or self.path.parent / "benchmarks", signer=signer, storage_secret=storage_secret, tenant_id=tenant_id, security_authority=security_authority)
        self.evaluator = AgentEvaluationHarness(signer=signer, harness=self.harness, event_bus=event_bus, tenant_id=tenant_id, security_authority=security_authority)
        self._last_event_id: str | None = None
        self._bootstrap_benchmarks()

    def _bootstrap_benchmarks(self) -> None:
        required = [
            ("bench.correctness.golden_v1", ["correctness"]),
            ("bench.tool_use.standard_v1", ["tool_accuracy"]),
            ("bench.planning.reference_v1", ["planning_quality"]),
            ("bench.factuality.evidence_v1", ["factuality"]),
            ("bench.security.policy_v1", ["security"]),
            ("bench.adversarial.redteam_v1", ["robustness","security"]),
            ("bench.recovery.faultinject_v1", ["recovery"]),
            ("bench.reproducibility.seeded_v1", ["reproducibility"]),
            ("bench.resource.budget_v1", ["resource_efficiency","latency_p95"]),
        ]
        existing={(b.get("benchmark_id"), b.get("benchmark_version")) for b in self.benchmarks.list()}
        for bid, targets in required:
            if (bid,"1.0.0") in existing: continue
            doc={"benchmark_id":bid,"benchmark_version":"1.0.0","description":f"Curated Workshop benchmark {bid}","metric_targets":targets,"dataset_refs":[f"urn:jarvis:workshop:dataset:{bid}"],"harness_requirements":{"execution_mode":"simulation" if "adversarial" not in bid else "isolated"},"seed_policy":"fixed","expected_runtime":1.0,"thresholds":{t:(0.0 if t=="security" else 0.95) for t in targets}}
            signed=_sign(doc,self.signer)
            self.benchmarks._db.execute("INSERT INTO benchmarks VALUES(?,?,?,?,?)",(self.tenant_id,bid,"1.0.0",json.dumps(signed,sort_keys=True),_hash(signed)))
            self._emit("BenchmarkRegistered", {"benchmark_ref": f"{bid}@1.0.0"})
        self.benchmarks._db.commit()

    @property
    def public_key_b64(self) -> str:
        return _b64(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))

    def _tag(self, payload: bytes) -> str:
        return hmac.new(self.secret, payload, hashlib.sha256).hexdigest()

    def _persist_session(self, doc: Mapping[str, Any]) -> None:
        raw = canonical_bytes(doc); self._db.execute("INSERT OR REPLACE INTO sessions VALUES(?,?,?,?,?,?)", (self.tenant_id, doc["session_id"], json.dumps(doc, sort_keys=True), _hash(doc), self._tag(raw), time.time())); self._db.commit()

    def _session(self, session_id: str) -> dict[str, Any]:
        row = self._db.execute("SELECT document,record_hash,tag FROM sessions WHERE tenant_id=? AND session_id=?", (self.tenant_id, session_id)).fetchone()
        if not row: raise WorkshopError("session not found")
        doc = json.loads(row[0])
        if _hash(doc) != row[1] or not hmac.compare_digest(self._tag(canonical_bytes(doc)), row[2]): raise WorkshopError("session integrity check failed")
        if doc["tenant_id"] != self.tenant_id: raise WorkshopError("tenant isolation violation")
        return doc

    def open_session(self, *, session_kind: str, owner: Mapping[str, str], base_ref: Mapping[str, Any] | None = None, draft: Mapping[str, Any] | None = None, environment_id: str = "workshop", environment_hash: str | None = None, budgets: Mapping[str, Any] | None = None, execution_mode: str = "simulation", parent_session: str | None = None) -> WorkshopSession:
        if execution_mode not in {m.value for m in WorkshopExecutionMode}: raise WorkshopError("Workshop execution mode must be simulation, isolated, or restricted")
        if execution_mode == WorkshopExecutionMode.RESTRICTED.value and self.security_authority is not None and not bool(self.security_authority.authorize("workshop_restricted", self.tenant_id, {"session_kind": session_kind})): raise WorkshopError("Security Authority rejected restricted Workshop mode")
        sid = str(uuid.uuid4()); d = copy.deepcopy(draft if draft is not None else {}); dh = _hash(d); env_hash = environment_hash or _sha(environment_id.encode())
        doc = {"schema_version":"1.0.0","session_id":sid,"tenant_id":self.tenant_id,"owner":dict(owner),"created_at":_now(),"session_kind":session_kind,"base_ref":dict(base_ref or {"kind":"scratch","ref":None,"version":None,"hash":None}),"working_draft":{"draft_id":str(uuid.uuid4()),"draft_hash":dh,"draft_version":1,"last_edited_at":_now(),"last_edited_by":dict(owner),"content":d},"environment":{"environment_id":environment_id,"environment_hash":env_hash,"execution_mode":execution_mode},"budgets":dict(budgets or {"cpu_seconds":60,"wall_seconds":60,"ram_mb":1024,"vram_mb":0,"network_bytes":0,"tokens_in":0,"tokens_out":0}),"state":"open","lineage":{"parent_session":parent_session,"spawned_candidates":[],"promoted_to":None},"signer_public_key":self.public_key_b64}
        doc["integrity_hash"] = _hash(doc); doc["signature"] = _b64(self.signer.sign(canonical_bytes(doc)))
        self._persist_session(doc); self._persist_draft(sid,1,d)
        self._emit("WorkshopSession.Opened", {"session_id":sid,"session_kind":session_kind})
        return WorkshopSession(copy.deepcopy(doc))

    def _persist_draft(self, session_id: str, version: int, content: Mapping[str, Any]) -> None:
        raw = canonical_bytes(content); self._db.execute("INSERT OR REPLACE INTO drafts VALUES(?,?,?,?,?,?)", (session_id, version, json.dumps(content, sort_keys=True), _hash(content), time.time(), self._tag(raw))); self._db.commit()

    def _draft_id(self, session_id: str) -> str:
        s=self._session(session_id); return str(s["working_draft"]["draft_id"])

    def read_draft(self, session_id: str) -> Mapping[str, Any]: return copy.deepcopy(self._session(session_id)["working_draft"]["content"])

    def _history_for_version(self, session_id: str, version: int) -> Mapping[str, Any]:
        row=self._db.execute("SELECT draft_json,draft_hash,tag FROM drafts WHERE session_id=? AND version=?",(session_id,version)).fetchone()
        if not row: raise WorkshopError("draft version not found")
        content=json.loads(row[0]);
        if _hash(content)!=row[1] or not hmac.compare_digest(self._tag(canonical_bytes(content)),row[2]): raise WorkshopError("draft history integrity failure")
        return content

    def _commit_draft(self, session_id: str, content: Mapping[str, Any], reason: str = "edit") -> Mapping[str, Any]:
        s=self._session(session_id)
        if s["state"] not in {SessionState.OPEN.value, SessionState.PAUSED.value}: raise WorkshopError("session is not editable")
        version=int(s["working_draft"]["draft_version"])+1; now=_now(); draft_id=str(uuid.uuid4()); content_copy=copy.deepcopy(dict(content)); content_hash=_hash(content_copy)
        s["working_draft"]={"draft_id":draft_id,"draft_hash":content_hash,"draft_version":version,"last_edited_at":now,"last_edited_by":dict(s["owner"]),"content":content_copy}
        self._persist_draft(session_id,version,content_copy)
        unsigned=dict(s); unsigned["signature"]=""; unsigned["integrity_hash"]=""
        unsigned["integrity_hash"]=_hash({k:v for k,v in unsigned.items() if k not in {"signature","integrity_hash"}}); unsigned["signature"]=_b64(self.signer.sign(canonical_bytes({k:v for k,v in unsigned.items() if k!="signature"})))
        self._persist_session(unsigned); self._emit("WorkshopSession.Edited", {"session_id":session_id,"draft_version":version,"draft_hash":content_hash,"reason":reason}); return content_copy

    def edit_session(self, session_id: str, patch: Mapping[str, Any]) -> Mapping[str, Any]:
        return DraftEditor(self,session_id,"generic",SESSION_SCHEMA).edit(patch)

    def editor(self, session_id: str, target: str) -> DraftEditor:
        mapping={"agent":SCHEMA_DIR/"agent_genome_v2.schema.json","genome":SCHEMA_DIR/"agent_genome_v2.schema.json","skill":SCHEMA_DIR/"skill_v1.schema.json","tool":SCHEMA_DIR/"workshop_binding_v1.schema.json","memory":SCHEMA_DIR/"workshop_binding_v1.schema.json","model":SCHEMA_DIR/"workshop_binding_v1.schema.json","policy":SCHEMA_DIR/"workshop_binding_v1.schema.json","workflow":WORKFLOW_SCHEMA,"prompt_program":PROMPT_SCHEMA,"environment":SCHEMA_DIR/"workshop_binding_v1.schema.json"}
        if target not in mapping: raise WorkshopError(f"unknown editor: {target}")
        return DraftEditor(self,session_id,target,mapping[target])

    def pause(self, session_id: str) -> None: self._set_state(session_id,SessionState.PAUSED,"pause")
    def resume(self, session_id: str) -> None: self._set_state(session_id,SessionState.OPEN,"resume")
    def close(self, session_id: str) -> None: self._set_state(session_id,SessionState.CLOSED,"close")
    def discard(self, session_id: str) -> None: self._set_state(session_id,SessionState.DISCARDED,"discard")

    def _set_state(self, session_id: str, target: SessionState, reason: str) -> None:
        s=self._session(session_id); current=SessionState(s["state"])
        if target not in SESSION_TRANSITIONS[current]: raise WorkshopError(f"illegal session transition {current.value}->{target.value}")
        s["state"]=target.value; s["integrity_hash"]=_hash({k:v for k,v in s.items() if k not in {"signature","integrity_hash"}}); s["signature"]=_b64(self.signer.sign(canonical_bytes({k:v for k,v in s.items() if k!="signature"}))); self._persist_session(s)
        name={SessionState.PAUSED:"WorkshopSession.Paused",SessionState.OPEN:"WorkshopSession.Opened",SessionState.CLOSED:"WorkshopSession.Closed",SessionState.DISCARDED:"WorkshopSession.Discarded",SessionState.PROMOTED:"WorkshopPromoted"}[target]; self._emit(name,{"session_id":session_id,"reason":reason})

    def validate_workflow(self, workflow: Mapping[str,Any]) -> Mapping[str,Any]:
        self._validate_schema(WORKFLOW_SCHEMA,workflow); WorkflowValidator.validate(workflow); return {"ok":True}

    def validate_prompt_program(self, program: Mapping[str,Any]) -> Mapping[str,Any]:
        self._validate_schema(PROMPT_SCHEMA,program); PromptProgramValidator.validate(program); return {"ok":True}

    def author_test(self, session_id: str, test: Mapping[str, Any]) -> Mapping[str, Any]:
        s=self._session(session_id)
        required={"test_id","kind","target_draft_hash","expected_outcome","tolerance","seed_policy","environment_hash","execution_mode"}
        doc=dict(test); doc.setdefault("schema_version","1.0.0"); doc["target_draft_hash"]=s["working_draft"]["draft_hash"]; doc.setdefault("expected_outcome","pass"); doc.setdefault("tolerance",{}); doc.setdefault("seed_policy","fixed"); doc.setdefault("environment_hash",s["environment"]["environment_hash"]); doc.setdefault("execution_mode","simulation");
        missing=sorted(required-set(doc))
        if missing: raise WorkshopError(f"test artifact missing required fields: {missing}")
        if doc["kind"] in {"adversarial","security","failure_injection"} and doc.get("attack_surface") in (None,[]) and doc["kind"]=="adversarial": raise WorkshopError("adversarial test requires attack surface declaration")
        signed=_sign(doc,self.signer); self._store_artifact("test_definition",signed); self._emit("TestStarted",{"session_id":session_id,"test_id":doc["test_id"]}); return signed

    def run_test(self, session_id: str, test: Mapping[str,Any], *, implementation: Callable[[], Mapping[str,Any]], seed: int, environment_hash: str | None = None) -> Mapping[str,Any]:
        self._assert_session_access(session_id); s=self._session(session_id); mode = str(test.get("execution_mode","simulation"));
        if mode == "trusted": raise WorkshopError("Workshop tests cannot run in trusted mode")
        if test.get("kind") in {"security","adversarial","failure_injection"} and mode != "isolated": raise WorkshopError("security/adversarial/failure-injection tests require isolated mode")
        exec_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:jarvis:workshop:test:{session_id}:{test['test_id']}:{seed}"))
        self._emit_agent_execution("Started", {"execution_id":exec_id,"session_id":session_id,"test_id":test["test_id"]})
        try:
            result=self.harness.run(mode=mode,seed=seed,environment_hash=environment_hash or s["environment"]["environment_hash"],budgets=s["budgets"],implementation=implementation)
        except Exception as exc:
            self._emit_agent_execution("Failed", {"execution_id":exec_id,"session_id":session_id,"test_id":test["test_id"],"error":type(exc).__name__})
            raise
        self._emit_agent_execution("Completed", {"execution_id":exec_id,"session_id":session_id,"test_id":test["test_id"]})
        report={"schema_version":"1.0.0","test_id":str(test["test_id"]),"target_draft_hash":s["working_draft"]["draft_hash"],"kind":test["kind"],"seed":seed,"environment_hash":environment_hash or s["environment"]["environment_hash"],"result":"pass" if bool(result.get("result",{}).get("ok",True)) else "fail","flaky":False,"timings":{"wall_seconds":float(result.get("wall_seconds",0.0))},"resource_profile":dict(result.get("resource_profile",{})),"failure_records":list(result.get("failure_records",[])),"reproducibility_evidence":{"seed":seed,"draft_hash":s["working_draft"]["draft_hash"]}}
        signed=_sign(report,self.signer); self._store_artifact("test",signed); self._emit("TestCompleted",{"session_id":session_id,"test_id":test["test_id"],"result":signed["result"]}); return signed

    def _emit_agent_execution(self, event_name: str, payload: Mapping[str, Any]) -> None:
        producer=ProducedBy("system","agent-workshop",_sha(self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)),"system")
        event=EventEnvelope.create(event_type="Agent.Execution",event_name=event_name,payload=dict(payload),produced_by=producer,auth_context=AuthContext("agent-workshop",("events.publish.agent.execution",),"workshop",None),tenant_id=self.tenant_id,partition_key=str(payload.get("execution_id",self.tenant_id)),signing_key=self.signer,correlation_id=str(payload.get("session_id",uuid.uuid4())),lineage=EventLineage())
        self.event_bus.publish(event)

    def evaluate(self, session_id: str, profile: str, *, seed: int, observations: Mapping[str,Any], baseline: Mapping[str,Any] | None = None, threshold_overrides: Mapping[str,float] | None = None, waiver: Mapping[str,Any] | None = None) -> Mapping[str,Any]:
        s=self._session(session_id); self._assert_session_access(session_id); target={"kind":s["session_kind"],"ref":s["working_draft"]["draft_id"],"version":str(s["working_draft"]["draft_version"]),"draft_hash":s["working_draft"]["draft_hash"]}
        report=self.evaluator.evaluate(target,profile,seed=seed,environment_hash=s["environment"]["environment_hash"],mode=s["environment"]["execution_mode"],budgets=s["budgets"],observations=observations,baseline=baseline,threshold_overrides=threshold_overrides,waiver=waiver)
        self._store_artifact("evaluation",report); return report

    def promote(self, session_id: str, *, author: Mapping[str,str], target_execution_mode: str = "simulation") -> Mapping[str,Any]:
        s=self._session(session_id); self._assert_session_access(session_id)
        if s["state"] not in {SessionState.OPEN.value,SessionState.CLOSED.value}: raise WorkshopError("promotion requires open or closed session")
        latest_eval=self._latest_artifact(session_id, "evaluation")
        if latest_eval is None or latest_eval.get("pass_fail") != "pass": raise WorkshopError("promotion requires a passing profile.quick or stronger evaluation")
        profile_name=str(latest_eval.get("profile", "")).split("@",1)[0]
        if profile_name not in DEFAULT_PROFILES: raise WorkshopError("promotion evaluation profile is not recognized")
        draft=s["working_draft"]["content"]; idea={"idea_id":str(uuid.uuid5(uuid.NAMESPACE_URL,f"urn:jarvis:workshop:promote:{session_id}:{s['working_draft']['draft_hash']}")),"title":f"Workshop promotion {session_id}","description":"Promoted Workshop candidate","author":dict(author),"created_at":s["created_at"],"agent_name":draft.get("agent_name",f"workshop.{session_id}"),"agent_purpose":draft.get("agent_purpose","Workshop candidate"),"target_trust_level":draft.get("trust_level","untrusted"),"target_execution_mode":target_execution_mode,"required_capabilities":[str(x.get("token")) for x in draft.get("capabilities",[])],"required_skills":draft.get("skills",[]),"optional_skills":[],"required_tools":[f'{x.get("tool_id")}@{x.get("version")}' for x in draft.get("tools",[])],"required_models":[f'{x.get("model_id")}@{x.get("version")}' for x in draft.get("models",[])],"objectives":draft.get("objectives",[]),"constraints":draft.get("constraints",[]),"success_criteria":draft.get("success_criteria",[]),"refusal_criteria":draft.get("refusal_criteria",[]),"budget_ceiling":{"cpu_seconds":s["budgets"]["cpu_seconds"],"wall_seconds":s["budgets"]["wall_seconds"],"ram_mb":s["budgets"]["ram_mb"],"vram_mb":s["budgets"]["vram_mb"],"network_bytes":s["budgets"]["network_bytes"],"tokens_in":s["budgets"]["tokens_in"],"tokens_out":s["budgets"]["tokens_out"]},"target_environments":[s["environment"]["environment_hash"]],"os_requirements":["any"],"gpu_required":False,"inspiration_refs":[],"parent_agents":[],"notes":"Workshop promotion; must enter P2-B Factory."}
        self._validate_schema(BASE_DIR/"schemas/idea_spec_v1.schema.json",idea); signed_idea=_sign(idea,self.signer)
        record={"schema_version":"1.0.0","promotion_id":str(uuid.uuid4()),"session_id":session_id,"draft_version":s["working_draft"]["draft_version"],"draft_hash":s["working_draft"]["draft_hash"],"evaluation_report_id":latest_eval["report_id"],"promotion_target":"idea_spec","actor":dict(author),"timestamp":_now(),"idea_spec_hash":_hash(signed_idea)}; signed_record=_sign(record,self.signer)
        self._store_artifact("promotion",signed_record); self._store_artifact("idea_spec",signed_idea)
        s["state"]=SessionState.PROMOTED.value; s["lineage"]["promoted_to"]=idea["idea_id"]; s["integrity_hash"]=_hash({k:v for k,v in s.items() if k not in {"signature","integrity_hash"}}); s["signature"]=_b64(self.signer.sign(canonical_bytes({k:v for k,v in s.items() if k!="signature"}))); self._persist_session(s); self._emit("WorkshopPromoted",{"session_id":session_id,"promotion_id":signed_record["promotion_id"],"idea_spec_id":idea["idea_id"]}); return {"promotion_record":signed_record,"idea_spec":signed_idea}

    def compare(self, a: Mapping[str,Any], b: Mapping[str,Any]) -> Mapping[str,Any]:
        left,right = a,b
        for field in ("profile","seed","environment_hash"):
            if left.get(field) != right.get(field):
                raise WorkshopError(f"comparison fairness violation: {field} differs")
        metrics_a=left.get("metrics",{}); metrics_b=right.get("metrics",{}); keys=sorted(set(metrics_a)|set(metrics_b)); diffs={k:float(metrics_b.get(k,0).get("value",0) if isinstance(metrics_b.get(k,0),dict) else metrics_b.get(k,0))-float(metrics_a.get(k,0).get("value",0) if isinstance(metrics_a.get(k,0),dict) else metrics_a.get(k,0)) for k in keys}; report={"schema_version":"1.0.0","comparison_id":str(uuid.uuid4()),"left_ref":left.get("report_id",left.get("target",{}).get("ref","a")),"right_ref":right.get("report_id",right.get("target",{}).get("ref","b")),"profile":left.get("profile","unknown"),"seed":left.get("seed"),"environment_hash":left.get("environment_hash"),"metric_diffs":diffs,"statistical_significance":{"insufficient_runs":True,"confidence_interval":None,"effect_sizes":{}},"flag":"insignificant" if all(abs(v)<1e-9 for v in diffs.values()) else "material"}; signed=_sign(report,self.signer); self._store_artifact("comparison",signed); self._emit("ComparisonCompleted",{"comparison_id":signed["comparison_id"]}); return signed

    def compare_many(self, reports: Sequence[Mapping[str,Any]]) -> list[Mapping[str,Any]]:
        return sorted(reports,key=lambda r: (-float(r.get("metrics",{}).get("correctness",{}).get("value",0)), r.get("report_id","")))

    def ab_test(self, a: Sequence[float], b: Sequence[float], *, alpha: float = 0.05, seed: int = 0) -> Mapping[str,Any]:
        if not a or not b: raise WorkshopError("A/B test requires both samples")
        mean_a,mean_b=statistics.mean(a),statistics.mean(b); var_a=statistics.pvariance(a) if len(a)>1 else 0.0; var_b=statistics.pvariance(b) if len(b)>1 else 0.0; se=math.sqrt(var_a/len(a)+var_b/len(b)) if len(a)>1 and len(b)>1 else 0.0; diff=mean_b-mean_a; ci=(diff-1.96*se,diff+1.96*se) if se else (diff,diff); effect=diff/(math.sqrt((var_a+var_b)/2) or 1.0); return {"alpha":alpha,"seed":seed,"mean_a":mean_a,"mean_b":mean_b,"effect_size":effect,"confidence_interval":ci,"significant":bool(se and not (ci[0]<=0<=ci[1]))}

    def sweep(self, parameter: str, values: Sequence[Any], profile: str, *, evaluator: Callable[[Any], Mapping[str,Any]], budget_runs: int | None = None) -> list[Mapping[str,Any]]:
        if budget_runs is not None: values=list(values)[:max(0,budget_runs)]
        return [{"parameter":parameter,"value":v,"result":dict(evaluator(v))} for v in values]

    def regression_check(self, candidate: Mapping[str,Any], baseline: Mapping[str,Any], profile: str) -> Mapping[str,Any]:
        return self.compare(baseline,candidate)

    def _store_artifact(self, kind: str, doc: Mapping[str,Any]) -> None:
        artifact_id=str(doc.get("report_id",doc.get("promotion_id",doc.get("comparison_id",doc.get("benchmark_id",uuid.uuid4()))))); version=str(doc.get("version",doc.get("schema_version","1.0.0"))); raw=canonical_bytes(doc); self._db.execute("INSERT OR REPLACE INTO artifacts VALUES(?,?,?,?,?,?,?)",(self.tenant_id,artifact_id,kind,version,json.dumps(doc,sort_keys=True),_hash(doc),self._tag(raw))); self._db.commit()

    def _latest_artifact(self, session_id: str, kind: str) -> Mapping[str,Any] | None:
        rows=self._db.execute("SELECT document FROM artifacts WHERE tenant_id=? AND kind=? ORDER BY rowid DESC",(self.tenant_id,kind)).fetchall()
        for row in rows:
            doc=json.loads(row[0])
            if kind=="evaluation" and doc.get("target",{}).get("ref")==self._session(session_id)["working_draft"]["draft_id"]: return doc
        return None

    def _assert_session_access(self, session_id: str) -> None: self._session(session_id)

    def _validate_schema(self, path: Path, doc: Mapping[str,Any], *, raise_on_error: bool = True) -> list[Mapping[str,Any]]:
        schema=json.loads(path.read_text(encoding="utf-8")); issues=self.validator.validate(doc,schema); out=[x.to_dict() for x in issues]
        if raise_on_error and out: raise WorkshopError(json.dumps(out,sort_keys=True))
        return out

    @staticmethod
    def _merge_patch(value: Any, patch: Mapping[str,Any]) -> Any:
        if not isinstance(value,dict): return copy.deepcopy(dict(patch))
        result=copy.deepcopy(value)
        for key,item in patch.items():
            if item is None: result.pop(key,None)
            elif isinstance(item,dict) and isinstance(result.get(key),dict): result[key]=AgentWorkshop._merge_patch(result[key],item)
            else: result[key]=copy.deepcopy(item)
        return result

    def _structured_diff(self,a:Mapping[str,Any],b:Mapping[str,Any],prefix:str="") -> dict[str,Any]:
        diff={}
        for k in sorted(set(a)|set(b)):
            p=f"{prefix}.{k}" if prefix else k
            if k not in a: diff[p]={"from":None,"to":b[k]}
            elif k not in b: diff[p]={"from":a[k],"to":None}
            elif isinstance(a[k],dict) and isinstance(b[k],dict): diff.update(self._structured_diff(a[k],b[k],p))
            elif a[k]!=b[k]: diff[p]={"from":a[k],"to":b[k]}
        return diff

    def _resolve_draft_or_ref(self, other: Mapping[str,Any] | str) -> Mapping[str,Any]:
        if isinstance(other,Mapping): return other
        return self._session(other)["working_draft"]["content"]

    def _reject_escalation(self, session_id: str, draft: Mapping[str,Any]) -> None:
        s=self._session(session_id); target=str(s["session_kind"]); trust = draft.get("trust_level", "untrusted")
        if target in {WorkshopKind.TEMPLATE.value,WorkshopKind.AGENT.value,WorkshopKind.COMPOSITE.value} and trust in {"elevated","system"}:
            raise WorkshopError("editor patch exceeds Workshop target trust boundary")
        if draft.get("permissions",{}).get("allow") and target in {WorkshopKind.AGENT.value,WorkshopKind.COMPOSITE.value}:
            allowed=set(draft.get("declared_permissions",draft.get("permissions",{}).get("allow",[])))
            requested=set(draft.get("permissions",{}).get("allow",[]))
            if not requested.issubset(allowed): raise WorkshopError("capability/permission escalation refused")

    def _emit(self, event_name: str, payload: Mapping[str,Any]) -> None:
        try:
            producer=ProducedBy("system","agent-workshop",_sha(self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)),"system")
            event=EventEnvelope.create(event_type="Evolution",event_name=event_name,payload=dict(payload),produced_by=producer,auth_context=AuthContext("agent-workshop",("events.publish.evolution",),"workshop",None),tenant_id=self.tenant_id,partition_key=str(payload.get("session_id",self.tenant_id)),signing_key=self.signer,correlation_id=str(payload.get("session_id",uuid.uuid4())),causation_id=self._last_event_id,lineage=EventLineage())
            receipt=self.event_bus.publish(event); self._last_event_id=getattr(receipt,"event_id",event.event_id)
        except Exception as exc:
            raise WorkshopError(f"Workshop event publication failed: {type(exc).__name__}: {exc}") from exc

    def compare_drafts(self, session_id_a: str, session_id_b: str) -> Mapping[str,Any]:
        return self._structured_diff(self.read_draft(session_id_a),self.read_draft(session_id_b))

    def determinism_proof(self, session_id: str, implementation: Callable[[], Mapping[str,Any]], *, seed: int) -> Mapping[str,Any]:
        s=self._session(session_id); first=self.harness.run(mode=s["environment"]["execution_mode"],seed=seed,environment_hash=s["environment"]["environment_hash"],budgets=s["budgets"],implementation=implementation); second=self.harness.run(mode=s["environment"]["execution_mode"],seed=seed,environment_hash=s["environment"]["environment_hash"],budgets=s["budgets"],implementation=implementation); a=copy.deepcopy(first); b=copy.deepcopy(second); a.pop("wall_seconds",None); b.pop("wall_seconds",None); return {"deterministic":canonical_bytes(a)==canonical_bytes(b),"seed":seed,"first_hash":_hash(a),"second_hash":_hash(b)}

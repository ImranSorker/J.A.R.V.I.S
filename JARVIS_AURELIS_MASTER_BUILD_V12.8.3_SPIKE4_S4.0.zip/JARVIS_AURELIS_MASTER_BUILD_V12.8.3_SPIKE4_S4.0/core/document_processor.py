"""Multi-format document parsing and deterministic word-based chunking."""
from __future__ import annotations
import csv, json
from pathlib import Path
from typing import Any, ClassVar, Dict, List

class DocumentProcessor:
    SUPPORTED_EXTENSIONS: ClassVar[Dict[str, str]] = {".txt":"text", ".md":"markdown", ".html":"html", ".htm":"html", ".pdf":"pdf", ".docx":"docx", ".csv":"csv", ".json":"json"}
    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 50):
        if chunk_size <= 0 or chunk_overlap < 0 or chunk_overlap >= chunk_size: raise ValueError("invalid chunk_size/chunk_overlap")
        self.chunk_size, self.chunk_overlap = chunk_size, chunk_overlap
    def is_supported(self, file_path: str) -> bool: return Path(file_path).suffix.lower() in self.SUPPORTED_EXTENSIONS
    def parse(self, file_path: str) -> str:
        p = Path(file_path); ext = p.suffix.lower()
        if not self.is_supported(file_path): raise ValueError(f"Unsupported file type: {ext}")
        if ext in {".txt", ".md"}: return p.read_text(encoding="utf-8", errors="replace")
        if ext in {".html", ".htm"}:
            from bs4 import BeautifulSoup
            return BeautifulSoup(p.read_text(encoding="utf-8", errors="replace"), "html.parser").get_text("\n", strip=True)
        if ext == ".pdf":
            from pypdf import PdfReader
            return "\n".join((page.extract_text() or "") for page in PdfReader(str(p)).pages)
        if ext == ".docx":
            from docx import Document
            return "\n".join(par.text for par in Document(str(p)).paragraphs)
        if ext == ".csv":
            with p.open("r", newline="", encoding="utf-8", errors="replace") as f: return "\n".join(" | ".join(r) for r in csv.reader(f))
        if ext == ".json": return json.dumps(json.loads(p.read_text(encoding="utf-8")), indent=2, ensure_ascii=False)
        raise ValueError(f"Unsupported file type: {ext}")
    def chunk_text(self, text: str) -> List[str]:
        words = text.split()
        if not words: return []
        out=[]; start=0
        while start < len(words):
            end=min(start+self.chunk_size, len(words)); out.append(" ".join(words[start:end]))
            if end == len(words): break
            start=end-self.chunk_overlap
        return out
    def process_file(self, file_path: str) -> List[Dict[str, Any]]:
        return [{"text": c, "metadata":{"source":str(file_path),"chunk_index":i}} for i,c in enumerate(self.chunk_text(self.parse(file_path)))]



"""Temporal contradiction resolution, causal inference and explainable world reasoning."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

from core.temporal_world_model import TemporalFact, TemporalWorldModel


@dataclass(frozen=True, slots=True)
class ReasoningFinding:
    """One explainable world-model conclusion."""

    subject: str
    predicate: str
    value: Any
    confidence: float
    source: str
    evidence: tuple[str, ...]
    contradiction_count: int = 0


class WorldReasoner:
    """Resolve temporal conflicts conservatively and infer causal evidence paths."""

    def __init__(self, world: TemporalWorldModel) -> None:
        self.world = world

    def resolve(self, subject: str) -> dict[str, TemporalFact]:
        """Return the strongest current fact for each predicate.

        Recency has priority, while confidence breaks near-simultaneous ties.
        Expired facts are excluded, and contradictory historical values remain
        available through :meth:`explain`.
        """
        now = time.time()
        current = [fact for fact in self.world.history(subject) if fact.valid_from <= now and (fact.valid_until is None or fact.valid_until > now)]
        chosen: dict[str, TemporalFact] = {}
        for fact in current:
            previous = chosen.get(fact.predicate)
            if previous is None or (fact.confidence, fact.valid_from) > (previous.confidence, previous.valid_from):
                chosen[fact.predicate] = fact
        return chosen

    def explain(self, subject: str) -> list[ReasoningFinding]:
        """Return current conclusions together with contradiction evidence."""
        result: list[ReasoningFinding] = []
        current = self.resolve(subject)
        for predicate, fact in current.items():
            history = [item for item in self.world.history(subject, predicate) if item.value != fact.value]
            evidence = tuple(f"{item.source}:{item.valid_from:.3f}" for item in history[-5:])
            result.append(ReasoningFinding(subject, predicate, fact.value, fact.confidence, fact.source, evidence, len(history)))
        return sorted(result, key=lambda item: item.predicate)

    def infer_causes(self, effect: str, threshold: float = 0.5) -> list[str]:
        """Return direct causes meeting the confidence threshold."""
        bound = max(0.0, min(1.0, float(threshold)))
        return sorted({cause for cause, confidence in self.world.causes_of(effect) if confidence >= bound})

    def causal_paths(self, effect: str, *, max_depth: int = 4, threshold: float = 0.5) -> list[tuple[str, ...]]:
        """Enumerate bounded causal paths terminating at the requested effect."""
        max_depth = max(1, min(int(max_depth), 8))
        bound = max(0.0, min(1.0, float(threshold)))
        paths: list[tuple[str, ...]] = []
        frontier: list[tuple[str, tuple[str, ...]]] = [(effect, (effect,))]
        while frontier:
            node, path = frontier.pop(0)
            causes = [(cause, score) for cause, score in self.world.causes_of(node) if score >= bound]
            if not causes:
                paths.append(tuple(reversed(path)))
                continue
            for cause, _score in sorted(causes, key=lambda item: item[0]):
                if cause in path or len(path) >= max_depth:
                    paths.append(tuple(reversed(path + (cause,))))
                else:
                    frontier.append((cause, path + (cause,)))
        return paths[:256]

    def replay(self) -> list[dict[str, Any]]:
        """Return deterministic event history for audit/replay."""
        return self.world.events()



"""Model benchmarking."""
from __future__ import annotations
import time
from typing import Any


class ModelBenchmark:
    def __init__(self):
        self._results: list[dict[str, Any]] = []

    def measure(self, backend, prompt: str = "Hello, world!") -> dict[str, Any]:
        start = time.time()
        result = backend.generate(prompt, max_tokens=32)
        latency = time.time() - start
        return {
            "latency_ms": latency * 1000,
            "tokens_per_sec": 32 / latency if latency > 0 else 0,
            "model": result.model if hasattr(result, "model") else "unknown",
        }



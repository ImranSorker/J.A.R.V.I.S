"""Selects execution strategies."""
from __future__ import annotations


class StrategyEngine:
    def select(self, task: str, available: list[str]) -> str:
        if not available:
            return "direct"
        # Simple heuristic
        if "code" in task.lower() or "debug" in task.lower():
            return "coder" if "coder" in available else available[0]
        return available[0]



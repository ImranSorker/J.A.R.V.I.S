"""Capability-bound agent contracts used as the authoritative agent gate."""
from __future__ import annotations
import logging, os, re, threading, time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
logger=logging.getLogger("jarvis.agent_policy")
_NAME_RE=re.compile(r"^[A-Za-z][A-Za-z0-9_.\-]{0,63}$")
class PolicyValidationError(Exception):
    """Raised when an agent policy is structurally invalid."""
class PolicyViolation(Exception):
    """Raised when an agent exceeds its declared authority."""
@dataclass(frozen=True)
class ResourceLimits:
    max_iterations:int=20; max_retries:int=3; max_concurrency:int=1; timeout_seconds:float=120.0; max_output_bytes:int=1_000_000
    def validate(self)->None:
        if not 1<=self.max_iterations<=10000:raise PolicyValidationError("invalid max_iterations")
        if not 0<=self.max_retries<=100:raise PolicyValidationError("invalid max_retries")
        if not 1<=self.max_concurrency<=256:raise PolicyValidationError("invalid max_concurrency")
        if not .1<=self.timeout_seconds<=3600:raise PolicyValidationError("invalid timeout_seconds")
        if not 1024<=self.max_output_bytes<=100_000_000:raise PolicyValidationError("invalid max_output_bytes")
@dataclass(frozen=True)
class AgentPolicy:
    name:str; version:str="1.0.0"; description:str=""; capabilities:Tuple[str,...]=(); allowed_tools:Tuple[str,...]=(); denied_tools:Tuple[str,...]=()
    resource_limits:ResourceLimits=field(default_factory=ResourceLimits); workspace_read:Tuple[str,...]=(); workspace_write:Tuple[str,...]=(); network_access:bool=False; memory_scopes:Tuple[str,...]=(); require_approval_for:Tuple[str,...]=(); created_at:float=field(default_factory=time.time)
    def validate(self)->None:
        if not _NAME_RE.match(self.name):raise PolicyValidationError("invalid agent name")
        if not self.version or len(self.version)>32:raise PolicyValidationError("invalid policy version")
        self.resource_limits.validate()
        overlap=set(self.allowed_tools)&set(self.denied_tools)
        if overlap:raise PolicyValidationError(f"tool overlap: {sorted(overlap)}")
        if any(not c or len(c)>256 for c in self.capabilities):raise PolicyValidationError("invalid capability")
        for p in (*self.workspace_read,*self.workspace_write):
            if not p or "\x00" in p:raise PolicyValidationError("invalid workspace root")
        if not set(self.workspace_write).issubset(self.workspace_read):raise PolicyValidationError("write roots must be readable")
@dataclass(frozen=True)
class UsageSnapshot:
    iterations:int=0; retries:int=0; active_tasks:int=0; output_bytes:int=0
@dataclass(frozen=True)
class ToolDecision:
    allowed:bool; reason:str; requires_approval:bool=False
class AgentPolicyEngine:
    """Thread-safe authoritative policy registry and evaluator."""
    def __init__(self)->None:self._policies={}; self._registered_tools:Set[str]=set(); self._lock=threading.RLock()
    def register_tool(self,tool_name:str)->None:
        if not tool_name:raise PolicyValidationError("tool name required")
        with self._lock:self._registered_tools.add(tool_name)
    def register_policy(self,policy:AgentPolicy)->None:
        policy.validate()
        with self._lock:
            if policy.name in self._policies and self._policies[policy.name]!=policy:raise PolicyValidationError(f"conflicting policy {policy.name}")
            self._policies[policy.name]=policy
    def ensure_all_tools_known(self)->None:
        with self._lock:
            unknown=[x for p in self._policies.values() for x in (*p.allowed_tools,*p.denied_tools) if x not in self._registered_tools]
        if unknown:raise PolicyValidationError(f"unknown policy tools: {sorted(set(unknown))}")
    def get_policy(self,name:str)->Optional[AgentPolicy]:
        with self._lock:return self._policies.get(name)
    def list_policies(self)->List[Dict[str,Any]]:
        with self._lock:return [{"name":p.name,"version":p.version,"capabilities":list(p.capabilities),"allowed_tools":list(p.allowed_tools),"denied_tools":list(p.denied_tools),"network_access":p.network_access,"memory_scopes":list(p.memory_scopes)} for p in self._policies.values()]
    def _covers(self,policy:AgentPolicy,tool:str,required:Tuple[str,...],principal:Tuple[str,...])->bool:
        caps=set(policy.capabilities)|set(principal)
        return "*" in caps or "tools.*" in caps or f"tools.{tool}" in caps or set(required).issubset(caps)
    def authorize_tool(self,agent_name:str,tool_name:str,principal_capabilities:Tuple[str,...]=(),required_capabilities:Tuple[str,...]=(),network_required:bool=False)->ToolDecision:
        policy=self.get_policy(agent_name)
        if not policy:return ToolDecision(False,"no policy")
        if tool_name in policy.denied_tools:return ToolDecision(False,"tool denied")
        if policy.allowed_tools and tool_name not in policy.allowed_tools:return ToolDecision(False,"tool not in allowlist")
        if network_required and not policy.network_access:return ToolDecision(False,"network not permitted")
        if not self._covers(policy,tool_name,required_capabilities,principal_capabilities):return ToolDecision(False,"missing capability")
        return ToolDecision(True,"authorized",tool_name in policy.require_approval_for)
    def check_limits(self,agent_name:str,usage:UsageSnapshot)->None:
        p=self.get_policy(agent_name)
        if not p:raise PolicyViolation("no policy")
        l=p.resource_limits
        if usage.iterations>l.max_iterations or usage.retries>l.max_retries or usage.active_tasks>l.max_concurrency or usage.output_bytes>l.max_output_bytes:raise PolicyViolation("agent resource limit exceeded")
    def record_usage(self,agent_name:str,usage:UsageSnapshot)->None:self.check_limits(agent_name,usage)
    def check_workspace(self,agent_name:str,path:str,write:bool=False)->None:
        p=self.get_policy(agent_name)
        if not p:raise PolicyViolation("no policy")
        candidate=os.path.abspath(os.fspath(path))
        roots=p.workspace_write if write else p.workspace_read
        if not roots:
            raise PolicyViolation("workspace access not permitted")
        norm=os.path.realpath(candidate)
        for root in roots:
            root_real=os.path.realpath(os.path.abspath(os.fspath(root)))
            for target in (candidate,norm):
                try:
                    if os.path.commonpath([root_real,target]) != root_real:
                        continue
                    if os.path.exists(target) and os.path.commonpath([root_real,os.path.realpath(target)]) != root_real:
                        continue
                    return
                except ValueError:
                    continue
        raise PolicyViolation("workspace boundary violation")
    def check_memory_scope(self,agent_name:str,scope:str)->None:
        p=self.get_policy(agent_name)
        if not p:raise PolicyViolation("no policy")
        if scope not in p.memory_scopes and "memory.*" not in p.memory_scopes:raise PolicyViolation("memory scope denied")



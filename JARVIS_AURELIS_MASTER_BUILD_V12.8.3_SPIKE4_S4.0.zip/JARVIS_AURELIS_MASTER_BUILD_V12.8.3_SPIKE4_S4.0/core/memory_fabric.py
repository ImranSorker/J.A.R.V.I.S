"""Cryptographically namespaced memory fabric over JARVIS UnifiedMemory."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar


@dataclass(frozen=True)
class MemoryAddress:
    """Logical memory address with cryptographic namespace separation."""

    owner: str
    workspace: str
    session: str
    namespace: str


class MemoryFabric:
    """Enforce owner/workspace/session namespaces before touching the memory store."""

    NAMESPACES: ClassVar[set[str]] = {"conversation", "long_term", "task_state", "preferences", "knowledge", "procedural"}

    def __init__(self, store: Any, secret: str | None = None, secret_path: str = "data/memory_namespace.secret") -> None:
        self.store = store
        self._secret = self._resolve_secret(secret, secret_path)
        self._lock = threading.RLock()

    @staticmethod
    def _resolve_secret(secret: str | None, secret_path: str) -> bytes:
        """Resolve a stable secret without logging or exposing its value."""
        configured = secret or os.environ.get("JARVIS_MEMORY_SECRET") or os.environ.get("JARVIS_SECURITY_SECRET")
        if configured:
            if len(configured.encode("utf-8")) < 16:
                raise ValueError("memory namespace secret must contain at least 16 bytes")
            return configured.encode("utf-8")
        path = Path(secret_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.is_file():
                try:
                    os.chmod(path, 0o600)
                except OSError:
                    logger = __import__("logging").getLogger("jarvis.memory_fabric")
                    logger.warning("memory_secret_permissions_unfixed")
                value = path.read_bytes()
                if len(value) >= 32:
                    return value
            value = secrets.token_bytes(32)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            try:
                os.write(fd, value)
            finally:
                os.close(fd)
            return value
        except OSError as exc:
            raise RuntimeError("unable to initialize the memory namespace secret") from exc

    def namespace(self, address: MemoryAddress) -> str:
        """Produce a non-reversible owner/workspace/session namespace identifier."""
        if address.namespace not in self.NAMESPACES:
            raise ValueError("unknown memory namespace")
        material = "|".join((address.owner, address.workspace, address.session, address.namespace)).encode("utf-8")
        return hmac.new(self._secret, material, hashlib.sha256).hexdigest()[:40]

    def put_event(self, address: MemoryAddress, role: str, content: str, metadata: dict[str, Any] | None = None) -> str:
        """Persist an event through its cryptographically isolated storage namespace."""
        namespace = self.namespace(address)
        session_id = f"{address.owner}:{namespace}"
        with self._lock:
            self.store.add(session_id, role, content)
        return namespace

    def history(self, address: MemoryAddress, limit: int = 100) -> list[dict[str, Any]]:
        """Read only the cryptographically derived namespace."""
        namespace = self.namespace(address)
        with self._lock:
            return list(self.store.get_history(f"{address.owner}:{namespace}", limit=limit))

    def delete_namespace(self, address: MemoryAddress) -> None:
        """Delete all records addressable through this memory namespace."""
        namespace = self.namespace(address)
        with self._lock:
            self.store.clear_session(f"{address.owner}:{namespace}")

    def derive_key(self, purpose: str) -> bytes:
        """Derive a purpose-scoped 256-bit key without exposing the root secret."""
        value = str(purpose).strip()
        if not value or len(value) > 128 or "\x00" in value:
            raise ValueError("invalid memory key derivation purpose")
        return hmac.new(self._secret, ("jarvis-memory-purpose-v1:" + value).encode("utf-8"), hashlib.sha256).digest()

    def describe(self) -> dict[str, Any]:
        """Return non-secret fabric state."""
        return {"namespaces": sorted(self.NAMESPACES), "secret_configured": True}



"""Uniform, policy-neutral contracts for external integrations.

Concrete MCP, browser, device and plugin adapters register capabilities here; the
Policy Gateway remains the authority that decides whether a capability may execute.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

IntegrationKind = Literal["mcp", "browser", "device", "plugin", "skill"]

@dataclass(frozen=True, slots=True)
class IntegrationDescriptor:
    """Discoverable integration metadata."""
    integration_id: str
    kind: IntegrationKind
    capabilities: tuple[str, ...]
    trusted: bool = False
    version: str = "1.0"

class IntegrationFabric:
    """Registry for replaceable integration adapters."""
    def __init__(self) -> None:
        self._items: dict[str, IntegrationDescriptor] = {}

    def register(self, descriptor: IntegrationDescriptor) -> None:
        """Register an integration once."""
        if descriptor.integration_id in self._items:
            raise ValueError("integration already registered")
        if not descriptor.capabilities:
            raise ValueError("integration requires capabilities")
        self._items[descriptor.integration_id] = descriptor

    def get(self, integration_id: str) -> IntegrationDescriptor:
        """Return a descriptor by ID."""
        return self._items[integration_id]

    def list(self, kind: IntegrationKind | None = None) -> tuple[IntegrationDescriptor, ...]:
        """Return deterministic descriptors."""
        items = self._items.values() if kind is None else (i for i in self._items.values() if i.kind == kind)
        return tuple(sorted(items, key=lambda item: item.integration_id))



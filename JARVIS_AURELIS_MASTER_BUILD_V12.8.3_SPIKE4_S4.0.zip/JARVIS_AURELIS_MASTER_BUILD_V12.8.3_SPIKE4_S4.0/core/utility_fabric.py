"""Safe native utility catalog used by tools, agents, and the command center."""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import ipaddress
import json
import os
from pathlib import Path
import shutil
import socket
import time
import zipfile
from typing import Any, Iterable


@dataclass(frozen=True, slots=True)
class UtilityResult:
    """Normalized utility outcome."""

    ok: bool
    name: str
    value: Any = None
    error: str | None = None


class UtilityFabric:
    """Provides deterministic, bounded local utilities without arbitrary code execution."""

    def __init__(self, workspace: str | Path) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _safe_path(self, relative: str) -> Path:
        """Resolve a workspace path and reject traversal."""
        candidate = (self.workspace / relative).resolve()
        if not candidate.is_relative_to(self.workspace):
            raise ValueError("path escapes workspace")
        return candidate

    def file_sha256(self, relative: str, chunk_size: int = 1_048_576) -> UtilityResult:
        """Hash one workspace file in bounded chunks."""
        try:
            path = self._safe_path(relative)
            if not path.is_file():
                return UtilityResult(False, "file_sha256", error="file not found")
            digest = sha256()
            with path.open("rb") as handle:
                while chunk := handle.read(max(4_096, min(chunk_size, 8_388_608))):
                    digest.update(chunk)
            return UtilityResult(True, "file_sha256", digest.hexdigest())
        except Exception as exc:
            return UtilityResult(False, "file_sha256", error=str(exc))

    @staticmethod
    def json_format(value: str) -> UtilityResult:
        """Validate and pretty-print JSON."""
        try:
            parsed = json.loads(value)
            return UtilityResult(True, "json_format", json.dumps(parsed, indent=2, ensure_ascii=False, sort_keys=True))
        except (TypeError, ValueError) as exc:
            return UtilityResult(False, "json_format", error=str(exc))

    @staticmethod
    def text_stats(value: str) -> UtilityResult:
        """Return deterministic text statistics."""
        text = str(value)
        words = len(text.split())
        lines = 0 if not text else text.count("\n") + 1
        return UtilityResult(True, "text_stats", {"characters": len(text), "words": words, "lines": lines, "bytes_utf8": len(text.encode("utf-8"))})

    def archive_list(self, relative_archive: str) -> UtilityResult:
        """List ZIP members without extracting them."""
        try:
            path = self._safe_path(relative_archive)
            with zipfile.ZipFile(path) as archive:
                members = [info.filename for info in archive.infolist()[:10_000]]
            return UtilityResult(True, "archive_list", members)
        except Exception as exc:
            return UtilityResult(False, "archive_list", error=str(exc))

    def archive_extract(self, relative_archive: str, target: str = "extracted") -> UtilityResult:
        """Safely extract ZIP members under a workspace target."""
        try:
            archive_path = self._safe_path(relative_archive)
            target_path = self._safe_path(target)
            target_path.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(archive_path) as archive:
                for info in archive.infolist()[:10_000]:
                    destination = (target_path / info.filename).resolve()
                    if not destination.is_relative_to(target_path):
                        raise ValueError("archive member escapes target")
                    if info.is_dir():
                        destination.mkdir(parents=True, exist_ok=True)
                        continue
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if info.file_size > 50_000_000:
                        raise ValueError("archive member exceeds size limit")
                    with archive.open(info) as source, destination.open("wb") as output:
                        shutil.copyfileobj(source, output, length=1_048_576)
            return UtilityResult(True, "archive_extract", str(target_path))
        except Exception as exc:
            return UtilityResult(False, "archive_extract", error=str(exc))


    def file_info(self, relative: str) -> UtilityResult:
        """Return bounded metadata for one workspace file."""
        try:
            path = self._safe_path(relative)
            stat = path.stat()
            return UtilityResult(True, "file_info", {"name": path.name, "suffix": path.suffix, "size": stat.st_size, "is_file": path.is_file(), "is_dir": path.is_dir(), "modified": stat.st_mtime})
        except OSError as exc:
            return UtilityResult(False, "file_info", error=str(exc))

    def directory_inventory(self, relative: str = ".", limit: int = 1000) -> UtilityResult:
        """Return a bounded deterministic inventory of a workspace directory."""
        try:
            path = self._safe_path(relative)
            if not path.is_dir():
                return UtilityResult(False, "directory_inventory", error="directory not found")
            maximum = max(1, min(int(limit), 10_000))
            rows = []
            for item in sorted(path.rglob("*"), key=lambda x: x.as_posix()):
                if len(rows) >= maximum:
                    break
                try:
                    if item.is_file():
                        rows.append({"path": item.relative_to(self.workspace).as_posix(), "type": "file", "size": item.stat().st_size})
                    elif item.is_dir():
                        rows.append({"path": item.relative_to(self.workspace).as_posix(), "type": "directory"})
                except OSError:
                    continue
            return UtilityResult(True, "directory_inventory", rows)
        except Exception as exc:
            return UtilityResult(False, "directory_inventory", error=str(exc))

    @staticmethod
    def current_time() -> UtilityResult:
        """Return monotonic-safe wall-clock metadata for local scheduling."""
        now = time.time()
        return UtilityResult(True, "current_time", {"unix": now, "utc_offset_seconds": time.localtime().tm_gmtoff if hasattr(time.localtime(), "tm_gmtoff") else None, "local": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())})

    @staticmethod
    def base64_roundtrip(value: str) -> UtilityResult:
        """Encode a bounded string to base64 without executing content."""
        import base64

        try:
            raw = str(value).encode("utf-8")
            if len(raw) > 1_000_000:
                return UtilityResult(False, "base64_roundtrip", error="value exceeds size limit")
            return UtilityResult(True, "base64_roundtrip", base64.b64encode(raw).decode("ascii"))
        except (TypeError, ValueError) as exc:
            return UtilityResult(False, "base64_roundtrip", error=str(exc))

    @staticmethod
    def resolve_host(host: str) -> UtilityResult:
        """Resolve a host to addresses without making application-level requests."""
        if not host or len(host) > 255:
            return UtilityResult(False, "resolve_host", error="invalid host")
        try:
            rows = sorted({entry[4][0] for entry in socket.getaddrinfo(host, None)})
            return UtilityResult(True, "resolve_host", rows)
        except OSError as exc:
            return UtilityResult(False, "resolve_host", error=str(exc))

    @staticmethod
    def classify_ip(value: str) -> UtilityResult:
        """Classify an IP address for network policy decisions."""
        try:
            address = ipaddress.ip_address(value)
            return UtilityResult(True, "classify_ip", {"private": address.is_private, "loopback": address.is_loopback, "global": address.is_global, "version": address.version})
        except ValueError as exc:
            return UtilityResult(False, "classify_ip", error=str(exc))

    @staticmethod
    def disk_snapshot(path: str | Path = "/") -> UtilityResult:
        """Return native disk capacity metrics."""
        try:
            usage = shutil.disk_usage(path)
            return UtilityResult(True, "disk_snapshot", {"total": usage.total, "used": usage.used, "free": usage.free, "timestamp": time.time()})
        except OSError as exc:
            return UtilityResult(False, "disk_snapshot", error=str(exc))

    @staticmethod
    def environment_summary(allow: Iterable[str] = ()) -> UtilityResult:
        """Expose only explicitly permitted environment keys."""
        allowed = {str(key) for key in allow}
        return UtilityResult(True, "environment_summary", {key: os.environ.get(key, "") for key in sorted(allowed)})

    def list_utilities(self) -> tuple[str, ...]:
        """Return available utility names."""
        return ("archive_extract", "archive_list", "base64_roundtrip", "classify_ip", "current_time", "directory_inventory", "disk_snapshot", "environment_summary", "file_info", "file_sha256", "json_format", "resolve_host", "text_stats")



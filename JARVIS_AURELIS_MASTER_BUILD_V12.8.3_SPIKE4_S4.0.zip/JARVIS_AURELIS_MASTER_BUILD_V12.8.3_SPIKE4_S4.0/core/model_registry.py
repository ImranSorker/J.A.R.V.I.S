"""Registry of known models and their capabilities."""
from __future__ import annotations
from typing import Dict, List
from core.types import ModelInfo


class ModelRegistry:
    def __init__(self):
        self._models: Dict[str, ModelInfo] = {}

    def register(self, info: ModelInfo) -> None:
        self._models[info.name] = info

    def list_models(self) -> List[ModelInfo]:
        return list(self._models.values())

    def get(self, name: str) -> ModelInfo | None:
        return self._models.get(name)



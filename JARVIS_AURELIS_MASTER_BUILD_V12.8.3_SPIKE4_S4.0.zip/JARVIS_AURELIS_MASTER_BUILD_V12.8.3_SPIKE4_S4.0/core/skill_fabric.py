"""P2-F Skill Fabric 2.0.

First-class, signed, versioned, composable skill control plane. Skills never grant
authority and never execute outside the P2-E Agent Harness.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import re
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_genome import AgentGenomeRegistry
from core.agent_harness import (
    AgentHarness, ExecutionAuthContext, ExecutionBudgets, ExecutionContext,
    ExecutionMode, AllowedSurface, CheckpointPolicy, TimeSource, TraceLevel,
)
from core.event_fabric import AuthContext, EventEnvelope, EventBus, EventLineage, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

SCHEMA_VERSION = "1.0.0"
SKILL_SCHEMA_URI = "urn:jarvis:skill:1.0.0"
COMPOSITION_SCHEMA_URI = "urn:jarvis:skill-composition:1.0.0"
TEST_SCHEMA_URI = "urn:jarvis:skill-test:1.0.0"
CERTIFICATION_SCHEMA_URI = "urn:jarvis:skill-certification:1.0.0"
_SCHEMA_DIR = Path(__file__).resolve().parent / "schemas"
_SKILL_SCHEMA = _SCHEMA_DIR / "skill_v1.schema.json"
_COMPOSITION_SCHEMA = _SCHEMA_DIR / "skill_composition_v1.schema.json"
_TEST_SCHEMA = _SCHEMA_DIR / "skill_test_v1.schema.json"
_CERT_SCHEMA = _SCHEMA_DIR / "skill_certification_v1.schema.json"
_SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$")
_TRUST_RANK = {"untrusted": 0, "restricted": 1, "standard": 2, "elevated": 3, "system": 4}
_MODE_RANK = {"trusted": 0, "restricted": 1, "isolated": 2, "simulation": 0}


class SkillError(RuntimeError):
    """Base Skill Fabric error."""


class SkillValidationError(SkillError, ValueError):
    """Skill document validation failed."""


class SkillSignatureError(SkillError, ValueError):
    """Skill signature or fingerprint verification failed."""


class SkillRegistryError(SkillError):
    """Skill registry integrity or mutation failure."""


class SkillResolutionError(SkillRegistryError):
    """Skill discovery or resolution failed."""


class SkillLifecycleError(SkillError):
    """Illegal skill lifecycle transition."""


class SkillAuthorizationError(SkillError, PermissionError):
    """Skill action exceeds the caller authorization."""


class SkillSandboxError(SkillError, PermissionError):
    """Skill environment or isolation requirement is not satisfied."""


class SkillCertificationError(SkillError):
    """Skill certification gate failed."""


class SkillCompositionError(SkillError, ValueError):
    """Skill composition contract is invalid."""


class SkillState(StrEnum):
    DRAFT = "DRAFT"
    BUILDING = "BUILDING"
    TESTING = "TESTING"
    EVALUATING = "EVALUATING"
    CERTIFIED = "CERTIFIED"
    STAGED = "STAGED"
    AVAILABLE = "AVAILABLE"
    DEPRECATED = "DEPRECATED"
    RETIRED = "RETIRED"
    REVOKED = "REVOKED"


_ALLOWED_TRANSITIONS: dict[SkillState, set[SkillState]] = {
    SkillState.DRAFT: {SkillState.BUILDING},
    SkillState.BUILDING: {SkillState.TESTING},
    SkillState.TESTING: {SkillState.EVALUATING},
    SkillState.EVALUATING: {SkillState.CERTIFIED},
    SkillState.CERTIFIED: {SkillState.STAGED, SkillState.REVOKED},
    SkillState.STAGED: {SkillState.AVAILABLE, SkillState.REVOKED},
    SkillState.AVAILABLE: {SkillState.DEPRECATED, SkillState.REVOKED},
    SkillState.DEPRECATED: {SkillState.RETIRED, SkillState.REVOKED},
    SkillState.RETIRED: set(),
    SkillState.REVOKED: set(),
}


def _semver(v: str) -> tuple[int, int, int, str, str]:
    if not _SEMVER_RE.fullmatch(str(v)):
        raise SkillValidationError(f"invalid semantic version: {v!r}")
    main, *rest = str(v).split("+", 1)
    base, *pre = main.split("-", 1)
    nums = tuple(int(x) for x in base.split("."))
    return nums[0], nums[1], nums[2], (pre[0] if pre else ""), (rest[0] if rest else "")


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(str(text) + "=" * (-len(str(text)) % 4))


def _uuid(value: str, field: str = "uuid") -> str:
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError, AttributeError) as exc:
        raise SkillValidationError(f"{field} must be a UUID") from exc


def _ref(value: str) -> tuple[str, str]:
    raw = str(value).strip()
    if "@" not in raw:
        raise SkillValidationError(f"invalid skill reference: {value!r}")
    sid, rng = raw.rsplit("@", 1)
    if not sid or not rng:
        raise SkillValidationError(f"invalid skill reference: {value!r}")
    return sid, rng


def _version_satisfies(version: str, requirement: str) -> bool:
    req = str(requirement).strip()
    actual = _semver(version)[:3]
    if req in {"", "*", "latest"}:
        return True
    if req.startswith("^"):
        base = _semver(req[1:])[:3]
        return actual[0] == base[0] and actual >= base
    if req.startswith("~"):
        base = _semver(req[1:])[:3]
        return actual[:2] == base[:2] and actual >= base
    if req.startswith(">="):
        return actual >= _semver(req[2:])[:3]
    if req.startswith(">"):
        return actual > _semver(req[1:])[:3]
    if req.startswith("<="):
        return actual <= _semver(req[2:])[:3]
    if req.startswith("<"):
        return actual < _semver(req[1:])[:3]
    return actual == _semver(req)[:3]


_VOLATILE_SKILL_FIELDS = {"state", "certification_status", "certification_history", "evaluation_history", "retirement_successor"}

def _canonical_skill_body(doc: Mapping[str, Any]) -> bytes:
    body = copy.deepcopy(dict(doc))
    for key in _VOLATILE_SKILL_FIELDS:
        body.pop(key, None)
    body["skill_fingerprint"] = ""
    body["signature"] = ""
    return canonical_bytes(body)


def skill_fingerprint(doc: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_skill_body(doc)).hexdigest()


@dataclass(frozen=True, slots=True)
class Skill:
    document: Mapping[str, Any]

    @classmethod
    def from_document(cls, document: Mapping[str, Any], *, validate: bool = True) -> "Skill":
        value = copy.deepcopy(dict(document))
        skill = cls(value)
        if validate:
            skill.validate()
        return skill

    @classmethod
    def create(
        cls,
        *,
        skill_id: str | None = None,
        skill_name: str,
        skill_version: str = "1.0.0",
        author_principal: str,
        author_key_id: str,
        private_key: Ed25519PrivateKey,
        tenant_id: str,
        capabilities_provided: Sequence[str] = (),
        prerequisites: Sequence[str] = (),
        required_permissions: Sequence[str] = (),
        required_scopes: Sequence[str] = (),
        tools: Sequence[str] = (),
        models: Sequence[str] = (),
        knowledge: Sequence[str] = (),
        memory_requirements: Mapping[str, Any] | None = None,
        inputs_schema: str = "urn:jarvis:schema:any:1.0.0",
        outputs_schema: str = "urn:jarvis:schema:any:1.0.0",
        postconditions: Sequence[str] = (),
        invariants: Sequence[str] = (),
        side_effects: Sequence[Mapping[str, Any]] = (),
        execution_contract: Mapping[str, Any] | None = None,
        failure_modes: Sequence[Mapping[str, Any]] = (),
        rollback_strategy: str = "none",
        compensation_skill: str | None = None,
        tests: Sequence[str] = (),
        benchmarks: Sequence[str] = (),
        golden_datasets: Sequence[str] = (),
        required_pass_rate: float = 0.98,
        security_policy_ref: str,
        sensitivity: str = "internal",
        allowed_environments: Sequence[str] = (),
        attack_surface: Sequence[Mapping[str, Any]] = (),
        sandbox_required: bool = True,
        composable: bool = True,
        composition_contract: Mapping[str, Any] | None = None,
        trust_level: str = "restricted",
        provenance_method: str = "authored",
        provenance_refs: Sequence[str] = (),
        parent_skills: Sequence[str] = (),
        ancestor_chain: Sequence[str] = (),
        derived_from_commit: str | None = None,
        agent_genome_hash: str | None = None,
        dependencies: Mapping[str, Sequence[str]] | None = None,
        environment_requirements: Mapping[str, Any] | None = None,
    ) -> "Skill":
        sid = _uuid(skill_id or str(uuid.uuid4()), "skill_id")
        _semver(skill_version)
        if not skill_name.startswith("jarvis.skills."):
            raise SkillValidationError("skill_name must be namespaced under jarvis.skills")
        key_pub = private_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        deps = dependencies or {"skills": [], "tools": [], "models": [], "python_packages": [], "system_packages": [], "runtime_version": ""}
        memory = memory_requirements or {"episodic": False, "semantic": False, "procedural": False, "working": True, "read_scopes": [], "write_scopes": []}
        exec_contract = execution_contract or {
            "mode_min": "isolated", "deterministic": False, "idempotent": True, "checkpointable": False,
            "cancellation_safe": True, "max_wall_seconds": 60.0, "max_cpu_seconds": 60.0, "max_ram_mb": 1024,
            "max_vram_mb": 0, "max_network_bytes": 0, "max_subprocesses": 0, "max_tool_calls": 0,
            "max_api_calls": 0, "concurrency_safe": True,
        }
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        doc: dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "skill_id": sid,
            "skill_name": str(skill_name),
            "skill_version": str(skill_version),
            "skill_fingerprint": "0" * 64,
            "signature": "",
            "lineage": {
                "parent_skills": list(parent_skills), "ancestor_chain": list(ancestor_chain), "genesis_timestamp": now,
                "derived_from_commit": derived_from_commit,
                "author": {"principal": author_principal, "key_id": author_key_id, "method": provenance_method, "public_key": _b64(key_pub), "agent_genome_hash": agent_genome_hash},
                "provenance_refs": list(provenance_refs),
            },
            "capabilities_provided": sorted(set(map(str, capabilities_provided))),
            "prerequisites": list(prerequisites),
            "required_permissions": sorted(set(map(str, required_permissions))),
            "required_scopes": sorted(set(map(str, required_scopes))),
            "tools": sorted(set(map(str, tools))),
            "models": sorted(set(map(str, models))),
            "knowledge": sorted(set(map(str, knowledge))),
            "memory_requirements": dict(memory),
            "inputs": {"schema_ref": inputs_schema, "examples": []},
            "outputs": {"schema_ref": outputs_schema, "postconditions": list(postconditions), "invariants": list(invariants)},
            "side_effects": [dict(x) for x in side_effects],
            "execution_contract": dict(exec_contract),
            "failure_modes": [dict(x) for x in failure_modes],
            "rollback_strategy": rollback_strategy,
            "compensation_skill": compensation_skill,
            "tests": list(tests), "benchmarks": list(benchmarks), "golden_datasets": list(golden_datasets),
            "required_pass_rate": float(required_pass_rate),
            "security_policy_ref": security_policy_ref,
            "sensitivity": sensitivity,
            "allowed_environments": list(allowed_environments),
            "attack_surface": [dict(x) for x in attack_surface],
            "sandbox_required": bool(sandbox_required),
            "composable": bool(composable),
            "composition_contract": dict(composition_contract or {"accepts_upstream": [], "produces_for_downstream": [], "transaction_safe": True, "requires_ordering": False}),
            "certification_status": "uncertified",
            "certification_history": [],
            "trust_level": trust_level,
            "evaluation_history": [],
            "dependencies": {
                "skills": list(deps.get("skills", ())), "tools": list(deps.get("tools", ())), "models": list(deps.get("models", ())),
                "python_packages": list(deps.get("python_packages", ())), "system_packages": list(deps.get("system_packages", ())), "runtime_version": str(deps.get("runtime_version", "")),
            },
            "environment_requirements": dict(environment_requirements or {"os": ["any"], "arch": ["any"], "gpu_required": False, "gpu_min_vram_mb": 0, "network_required": False}),
            "tenant_id": str(tenant_id),
            "state": SkillState.DRAFT.value,
        }
        doc["skill_fingerprint"] = skill_fingerprint(doc)
        doc["signature"] = _b64(private_key.sign(_canonical_skill_body(doc)))
        return cls.from_document(doc)

    @property
    def id(self) -> str:
        return str(self.document["skill_id"])

    @property
    def version(self) -> str:
        return str(self.document["skill_version"])

    @property
    def reference(self) -> str:
        return f"{self.id}@{self.version}"

    @property
    def fingerprint(self) -> str:
        return str(self.document["skill_fingerprint"])

    @property
    def state(self) -> SkillState:
        return SkillState(str(self.document["state"]))

    @property
    def tenant_id(self) -> str:
        return str(self.document["tenant_id"])

    def body(self) -> dict[str, Any]:
        value = copy.deepcopy(dict(self.document)); value["skill_fingerprint"] = ""; value["signature"] = ""; return value

    def canonical(self) -> bytes:
        return _canonical_skill_body(self.document)

    def verify_signature(self) -> bool:
        try:
            pub = _b64decode(str(self.document["lineage"]["author"]["public_key"]))
            sig = _b64decode(str(self.document["signature"]))
            Ed25519PublicKey.from_public_bytes(pub).verify(sig, self.canonical())
            return hmac.compare_digest(self.fingerprint, skill_fingerprint(self.document))
        except (InvalidSignature, ValueError, TypeError, UnicodeError):
            return False

    def validate(self) -> None:
        schema = json.loads(_SKILL_SCHEMA.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=128).validate_or_raise(dict(self.document), schema)
        _uuid(self.id, "skill_id")
        _semver(self.version)
        if self.document["skill_fingerprint"] != skill_fingerprint(self.document):
            raise SkillSignatureError("skill fingerprint mismatch")
        if not self.verify_signature():
            raise SkillSignatureError("skill signature invalid")
        if self.document["lineage"]["author"].get("agent_genome_hash") is not None and len(str(self.document["lineage"]["author"]["agent_genome_hash"])) != 64:
            raise SkillValidationError("agent_genome_hash must be SHA-256")
        if self.state == SkillState.REVOKED and self.document["certification_status"] != "revoked":
            raise SkillValidationError("revoked state requires revoked certification status")

    def with_state(self, state: SkillState) -> "Skill":
        value = copy.deepcopy(dict(self.document)); value["state"] = state.value
        if state == SkillState.REVOKED: value["certification_status"] = "revoked"
        value["skill_fingerprint"] = skill_fingerprint(value)
        pub = _b64decode(value["lineage"]["author"]["public_key"])
        # Re-signing requires the original private key; state transitions therefore happen through registry mutation, not this helper.
        value["signature"] = ""
        value["skill_fingerprint"] = skill_fingerprint(value)
        value["signature"] = str(self.document["signature"])
        return Skill.from_document(value, validate=False)


@dataclass(frozen=True, slots=True)
class SkillSummary:
    skill_id: str
    skill_name: str
    skill_version: str
    fingerprint: str
    state: SkillState
    tenant_id: str
    capabilities: tuple[str, ...]
    deprecated: bool


@dataclass(frozen=True, slots=True)
class InstallPlan:
    installation_id: str
    tenant_id: str
    root_ref: str
    resolved_refs: tuple[str, ...]
    lockfile: Mapping[str, str]
    environment_hash: str
    signature: str
    signer_public_key: str
    created_at: float

    def verify(self) -> bool:
        payload = self.to_payload(); payload["signature"] = ""
        try:
            Ed25519PublicKey.from_public_bytes(_b64decode(self.signer_public_key)).verify(_b64decode(self.signature), canonical_bytes(payload))
            return True
        except (InvalidSignature, ValueError, TypeError, UnicodeError):
            return False

    def to_payload(self) -> dict[str, Any]:
        return {
            "installation_id": self.installation_id, "tenant_id": self.tenant_id, "root_ref": self.root_ref,
            "resolved_refs": list(self.resolved_refs), "lockfile": dict(self.lockfile), "environment_hash": self.environment_hash,
            "signature": self.signature, "signer_public_key": self.signer_public_key, "created_at": self.created_at,
        }


@dataclass(frozen=True, slots=True)
class CertificationRecord:
    skill_ref: str
    evidence_hash: str
    score: float
    adversarial_passed: bool
    security_clean: bool
    resource_within_limits: bool
    issued_at: str
    signer_public_key: str
    signature: str

    def verify(self) -> bool:
        payload = self.__dict__.copy(); payload["signature"] = ""
        try:
            Ed25519PublicKey.from_public_bytes(_b64decode(self.signer_public_key)).verify(_b64decode(self.signature), canonical_bytes(payload))
            return True
        except (InvalidSignature, ValueError, TypeError, UnicodeError):
            return False


class SkillRegistry:
    """Durable HMAC-protected, append-only skill registry with tenant isolation."""
    def __init__(self, path: str | Path, storage_secret: bytes) -> None:
        if len(storage_secret) < 32: raise ValueError("skill registry secret must be at least 32 bytes")
        self.path = Path(path).resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(storage_secret); self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS skills(tenant_id TEXT NOT NULL,skill_id TEXT NOT NULL,skill_version TEXT NOT NULL,fingerprint TEXT NOT NULL,canonical_json TEXT NOT NULL,state TEXT NOT NULL,recorded_at REAL NOT NULL,integrity_tag TEXT NOT NULL,PRIMARY KEY(tenant_id,skill_id,skill_version));
        CREATE UNIQUE INDEX IF NOT EXISTS idx_skill_fingerprint ON skills(tenant_id,fingerprint);
        CREATE TABLE IF NOT EXISTS history(tenant_id TEXT NOT NULL,skill_id TEXT NOT NULL,skill_version TEXT NOT NULL,fingerprint TEXT NOT NULL,canonical_json TEXT NOT NULL,state TEXT NOT NULL,recorded_at REAL NOT NULL,integrity_tag TEXT NOT NULL,PRIMARY KEY(tenant_id,skill_id,skill_version,fingerprint));
        CREATE INDEX IF NOT EXISTS idx_skill_name ON skills(tenant_id,skill_id,skill_version);
        CREATE TABLE IF NOT EXISTS active_versions(tenant_id TEXT NOT NULL,skill_id TEXT NOT NULL,skill_version TEXT NOT NULL,updated_at REAL NOT NULL,PRIMARY KEY(tenant_id,skill_id));
        """)
        self._db.commit()

    def _tag(self, tenant: str, sid: str, version: str, fingerprint: str, payload: str, state: str) -> str:
        return hmac.new(self._secret, canonical_bytes({"tenant_id": tenant, "skill_id": sid, "skill_version": version, "fingerprint": fingerprint, "canonical_json": payload, "state": state}), hashlib.sha256).hexdigest()

    def _row_skill(self, row: Sequence[Any]) -> Skill:
        payload = json.loads(str(row[0])); skill = Skill.from_document(payload)
        expected = self._tag(skill.tenant_id, skill.id, skill.version, skill.fingerprint, str(row[0]), skill.state.value)
        if not hmac.compare_digest(expected, str(row[1])): raise SkillRegistryError("skill registry integrity failure")
        return skill

    def register(self, skill: Skill) -> str:
        skill.validate(); payload = json.dumps(skill.document, sort_keys=True, separators=(",", ":"), ensure_ascii=False); now = time.time()
        with self._lock, self._db:
            existing = self._db.execute("SELECT fingerprint,canonical_json,state,integrity_tag FROM skills WHERE tenant_id=? AND skill_id=? AND skill_version=?", (skill.tenant_id, skill.id, skill.version)).fetchone()
            if existing is not None:
                if str(existing[0]) != skill.fingerprint: raise SkillRegistryError("immutable skill version already exists with different fingerprint")
                return skill.reference
            tag = self._tag(skill.tenant_id, skill.id, skill.version, skill.fingerprint, payload, skill.state.value)
            self._db.execute("INSERT INTO skills VALUES(?,?,?,?,?,?,?,?)", (skill.tenant_id, skill.id, skill.version, skill.fingerprint, payload, skill.state.value, now, tag))
            self._db.execute("INSERT INTO history VALUES(?,?,?,?,?,?,?,?)", (skill.tenant_id, skill.id, skill.version, skill.fingerprint, payload, skill.state.value, now, tag))
            self._db.execute("INSERT OR IGNORE INTO active_versions VALUES(?,?,?,?)", (skill.tenant_id, skill.id, skill.version, now))
        return skill.reference

    def _get_raw(self, tenant: str, sid: str, version: str) -> Skill | None:
        row = self._db.execute("SELECT canonical_json,integrity_tag FROM skills WHERE tenant_id=? AND skill_id=? AND skill_version=?", (tenant, sid, version)).fetchone()
        if row is None: return None
        return self._row_skill(row)

    def get(self, skill_id: str, version: str, *, tenant_id: str) -> Skill:
        skill = self._get_raw(str(tenant_id), str(skill_id), str(version))
        if skill is None: raise SkillResolutionError(f"skill not found: {skill_id}@{version}")
        return skill

    def get_by_fingerprint(self, fingerprint: str, *, tenant_id: str) -> Skill:
        row = self._db.execute("SELECT canonical_json,integrity_tag FROM skills WHERE tenant_id=? AND fingerprint=?", (tenant_id, fingerprint)).fetchone()
        if row is None: raise SkillResolutionError("skill fingerprint not found")
        return self._row_skill(row)

    def list(self, *, tenant_id: str, state: SkillState | None = None, capability: str | None = None) -> tuple[SkillSummary, ...]:
        rows = self._db.execute("SELECT canonical_json,integrity_tag FROM skills WHERE tenant_id=? ORDER BY skill_id,skill_version", (tenant_id,)).fetchall()
        result=[]
        for row in rows:
            skill = self._row_skill(row)
            if state and skill.state != state: continue
            if capability and capability not in set(skill.document["capabilities_provided"]): continue
            result.append(SkillSummary(skill.id, skill.document["skill_name"], skill.version, skill.fingerprint, skill.state, skill.tenant_id, tuple(skill.document["capabilities_provided"]), skill.state==SkillState.DEPRECATED))
        return tuple(result)

    def resolve(self, skill_ref: str, *, tenant_id: str, allow_deprecated: bool = True) -> Skill:
        sid, requirement = _ref(skill_ref)
        rows = self._db.execute("SELECT canonical_json,integrity_tag FROM skills WHERE tenant_id=? AND skill_id=? ORDER BY skill_version DESC", (tenant_id, sid)).fetchall()
        candidates=[]
        for row in rows:
            skill=self._row_skill(row)
            if skill.state not in {SkillState.CERTIFIED, SkillState.STAGED, SkillState.AVAILABLE, SkillState.DEPRECATED}: continue
            if skill.document.get("certification_status") != "certified": continue
            if skill.state == SkillState.DEPRECATED and not allow_deprecated: continue
            if _version_satisfies(skill.version, requirement): candidates.append(skill)
        if not candidates:
            retired = [self._row_skill(row) for row in rows if self._row_skill(row).state == SkillState.RETIRED]
            for historical in retired:
                successor = historical.document.get("retirement_successor")
                if successor:
                    return self.resolve(str(successor), tenant_id=tenant_id, allow_deprecated=allow_deprecated)
            raise SkillResolutionError(f"no resolvable skill satisfies {skill_ref}")
        if requirement in {"*", "latest"}:
            active = self._db.execute("SELECT skill_version FROM active_versions WHERE tenant_id=? AND skill_id=?", (tenant_id, sid)).fetchone()
            if active:
                for candidate in candidates:
                    if candidate.version == str(active[0]):
                        return candidate
        return max(candidates, key=lambda s: _semver(s.version)[:3])

    def mutate_state(self, skill_ref: str, *, tenant_id: str, target: SkillState, signer: Ed25519PrivateKey, reason: str | None = None, successor: str | None = None) -> Skill:
        sid, version = _ref(skill_ref); current=self.get(sid,version,tenant_id=tenant_id)
        if target != SkillState.REVOKED and target not in _ALLOWED_TRANSITIONS[current.state]: raise SkillLifecycleError(f"illegal transition {current.state.value} -> {target.value}")
        if target == SkillState.REVOKED and current.state in {SkillState.RETIRED, SkillState.REVOKED}: raise SkillLifecycleError(f"illegal transition {current.state.value} -> {target.value}")
        doc=copy.deepcopy(dict(current.document)); doc["state"]=target.value
        if target == SkillState.REVOKED: doc["certification_status"]="revoked"
        elif target == SkillState.CERTIFIED: doc["certification_status"]="certified"
        elif current.state == SkillState.REVOKED: doc["certification_status"]="revoked"
        doc.setdefault("certification_history",[])
        if reason: doc["certification_history"].append({"event":"state_transition","state":target.value,"reason":reason,"timestamp":time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
        if successor: doc["retirement_successor"]=successor
        doc["skill_fingerprint"] = current.fingerprint
        doc["signature"] = current.document["signature"]
        updated=Skill.from_document(doc)
        # append immutable history, replace current snapshot
        payload=json.dumps(updated.document,sort_keys=True,separators=(",",":"),ensure_ascii=False); now=time.time(); tag=self._tag(tenant_id, sid, version, updated.fingerprint,payload,target.value)
        with self._lock,self._db:
            self._db.execute("UPDATE skills SET fingerprint=?,canonical_json=?,state=?,recorded_at=?,integrity_tag=? WHERE tenant_id=? AND skill_id=? AND skill_version=?",(updated.fingerprint,payload,target.value,now,tag,tenant_id,sid,version))
            self._db.execute("INSERT OR IGNORE INTO history VALUES(?,?,?,?,?,?,?,?)",(tenant_id,sid,version,updated.fingerprint,payload,target.value,now,tag))
            if target == SkillState.REVOKED:
                dependents = self.dependents(skill_ref, tenant_id=tenant_id)
                for dep in dependents:
                    dep_doc = copy.deepcopy(dict(dep.document))
                    dep_doc["certification_status"] = "provisional"
                    dep_doc["certification_history"] = list(dep_doc.get("certification_history", [])) + [{"event":"dependency_revoked","dependency":skill_ref,"timestamp":time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}]
                    dep_payload = json.dumps(dep_doc, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                    dep_tag = self._tag(tenant_id, dep.id, dep.version, dep.fingerprint, dep_payload, dep.state.value)
                    self._db.execute("UPDATE skills SET canonical_json=?,recorded_at=?,integrity_tag=? WHERE tenant_id=? AND skill_id=? AND skill_version=?", (dep_payload, now, dep_tag, tenant_id, dep.id, dep.version))
        return updated

    def deprecate(self, skill_ref: str, *, tenant_id: str, signer: Ed25519PrivateKey, reason: str) -> Skill:
        return self.mutate_state(skill_ref,tenant_id=tenant_id,target=SkillState.DEPRECATED,signer=signer,reason=reason)
    def retire(self, skill_ref: str, *, tenant_id: str, signer: Ed25519PrivateKey, successor: str) -> Skill:
        return self.mutate_state(skill_ref,tenant_id=tenant_id,target=SkillState.RETIRED,signer=signer,successor=successor)
    def revoke(self, skill_ref: str, *, tenant_id: str, signer: Ed25519PrivateKey, reason: str) -> Skill:
        return self.mutate_state(skill_ref,tenant_id=tenant_id,target=SkillState.REVOKED,signer=signer,reason=reason)

    def history(self, skill_id: str, *, tenant_id: str, limit: int = 100) -> tuple[Skill, ...]:
        rows=self._db.execute("SELECT canonical_json,integrity_tag FROM history WHERE tenant_id=? AND skill_id=? ORDER BY recorded_at DESC LIMIT ?",(tenant_id,skill_id,max(1,min(int(limit),1000)))).fetchall()
        return tuple(self._row_skill(row) for row in rows)

    def dependents(self, skill_ref: str, *, tenant_id: str) -> tuple[Skill, ...]:
        rows=self._db.execute("SELECT canonical_json,integrity_tag FROM skills WHERE tenant_id=?",(tenant_id,)).fetchall(); out=[]
        for row in rows:
            try: skill=self._row_skill(row)
            except SkillResolutionError: continue
            refs=set(skill.document["prerequisites"])|set(skill.document["dependencies"]["skills"])
            if skill_ref in refs or _ref(skill_ref)[0] in {str(r).split("@")[0] for r in refs}: out.append(skill)
        return tuple(out)

    def rollback(self, skill_id: str, to_version: str, *, tenant_id: str) -> Skill:
        target = self.get(skill_id, to_version, tenant_id=tenant_id)
        if target.state != SkillState.CERTIFIED:
            raise SkillLifecycleError("rollback target must be certified")
        with self._lock, self._db:
            self._db.execute("INSERT INTO active_versions(tenant_id,skill_id,skill_version,updated_at) VALUES(?,?,?,?) ON CONFLICT(tenant_id,skill_id) DO UPDATE SET skill_version=excluded.skill_version,updated_at=excluded.updated_at", (tenant_id,skill_id,to_version,time.time()))
        return target

    def close(self) -> None:
        self._db.close()


class SkillDependencyGraph:
    def __init__(self, registry: SkillRegistry, *, tenant_id: str) -> None:
        self.registry=registry; self.tenant_id=tenant_id
    def _all(self) -> tuple[Skill,...]:
        summaries = self.registry.list(tenant_id=self.tenant_id)
        return tuple(self.registry.get(summary.skill_id, summary.skill_version, tenant_id=self.tenant_id) for summary in summaries)
    def detect(self) -> dict[str, Any]:
        graph: dict[str,set[str]]={s.reference:set() for s in self._all()}
        missing=[]
        for s in self._all():
            for raw in list(s.document["prerequisites"])+list(s.document["dependencies"]["skills"]):
                try:
                    sid, req = _ref(raw)
                    if re.fullmatch(r"\d+\.\d+\.\d+", req):
                        dep=self.registry.get(sid, req, tenant_id=self.tenant_id)
                    else:
                        dep=self.registry.resolve(raw,tenant_id=self.tenant_id)
                except SkillResolutionError:
                    missing.append({"skill":s.reference,"dependency":raw}); continue
                graph[s.reference].add(dep.reference)
        visiting=set(); visited=set(); cycles=[]
        def dfs(n,path):
            if n in visiting:
                cycles.append(path[path.index(n):]+[n]); return
            if n in visited:return
            visiting.add(n)
            for d in sorted(graph.get(n,())): dfs(d,path+[n])
            visiting.remove(n); visited.add(n)
        for n in sorted(graph): dfs(n,[])
        return {"cycles":cycles,"missing":missing,"graph":{k:sorted(v) for k,v in graph.items()}}
    def impact_of_revoke(self, skill_id: str) -> tuple[str,...]:
        out={s.reference for s in self._all() if any(str(r).split("@")[0]==skill_id for r in list(s.document["prerequisites"])+list(s.document["dependencies"]["skills"]))}
        return tuple(sorted(out))

    def upgrade_path(self, skill_id: str, from_version: str, to_version: str) -> tuple[str,...]:
        versions=[s.version for s in self._all() if s.id==skill_id and s.state not in {SkillState.REVOKED,SkillState.RETIRED}]
        if from_version not in versions or to_version not in versions: raise SkillResolutionError("upgrade endpoints unavailable")
        ordered=sorted(set(versions),key=lambda v:_semver(v)[:3]); start=ordered.index(from_version); end=ordered.index(to_version)
        if start>end: return tuple(ordered[end:start+1][::-1])
        return tuple(ordered[start:end+1])


class SkillFabric:
    """Public P2-F API and policy boundary."""
    def __init__(self, *, registry: SkillRegistry, event_bus: EventBus, signer: Ed25519PrivateKey, tenant_id: str, harness: AgentHarness | None = None, genome_registry: AgentGenomeRegistry | None = None, harness_auth_verifier: Any | None = None, security_authority: Callable[[str, str, str], bool] | None = None, harness_environment_id: str = "skill-fabric", harness_environment_hash: str | None = None) -> None:
        self.registry=registry; self.event_bus=event_bus; self.signer=signer; self.tenant_id=tenant_id; self.harness=harness; self.genome_registry=genome_registry; self.harness_auth_verifier=harness_auth_verifier; self.security_authority=security_authority; self.environment_id=harness_environment_id; self.environment_hash=harness_environment_hash or hashlib.sha256(harness_environment_id.encode()).hexdigest(); self._lock=threading.RLock()
        if not hasattr(event_bus,"publish"): raise TypeError("P2-U EventBus is required")

    @property
    def public_key_b64(self) -> str: return _b64(self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))

    def _emit(self,event_name: str,payload: Mapping[str,Any],*,event_type: str="Skill.Lifecycle", correlation_id: str|None=None,causation_id: str|None=None,priority: str="normal") -> None:
        kind, name = event_type.split(".",1); genome_hash=None
        producer=ProducedBy("system", "skill-fabric", hashlib.sha256(self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).hexdigest(), "system")
        event=EventEnvelope.create(event_type=event_type,event_name=event_name,payload=dict(payload),produced_by=producer,auth_context=AuthContext("skill-fabric",(f"events.publish.{event_type.lower()}",),"skill-fabric",None),tenant_id=self.tenant_id,partition_key=str(payload.get("skill_id",payload.get("skill_ref","skill-fabric"))),correlation_id=correlation_id,causation_id=causation_id,priority=priority,signing_key=self.signer)
        self.event_bus.publish(event)

    def register(self, skill: Skill, *, publish_event: bool=True) -> str:
        skill.validate(); ref=self.registry.register(skill)
        if publish_event: self._emit("Draft",{"skill_id":skill.id,"skill_ref":ref,"fingerprint":skill.fingerprint})
        return ref

    def transition(self, skill_ref: str, target: SkillState, *, reason: str | None = None, successor: str | None = None) -> Skill:
        skill = self.registry.mutate_state(skill_ref, tenant_id=self.tenant_id, target=target, signer=self.signer, reason=reason, successor=successor)
        event_name = target.value.title()
        self._emit(event_name, {"skill_id": skill.id, "skill_ref": skill.reference, "state": target.value, "reason": reason})
        return skill

    def discover(self, *, capability: str|None=None, author: str|None=None, state: SkillState|None=None) -> tuple[SkillSummary,...]:
        items=self.registry.list(tenant_id=self.tenant_id, state=state, capability=capability)
        if author is None:return items
        return tuple(x for x in items if self.registry.get(x.skill_id,x.skill_version,tenant_id=self.tenant_id).document["lineage"]["author"]["principal"]==author)

    def resolve(self, skill_ref: str, *, scopes: Sequence[str]=(), environment_hash: str|None=None, execution_mode: str="isolated", caller_permissions: Sequence[str]=()) -> Skill:
        skill=self.registry.resolve(skill_ref,tenant_id=self.tenant_id)
        self._check_access(skill,scopes,environment_hash,execution_mode,caller_permissions)
        return skill

    def _check_access(self, skill: Skill, scopes: Sequence[str], environment_hash: str|None, execution_mode: str, caller_permissions: Sequence[str]) -> None:
        if skill.state in {SkillState.REVOKED,SkillState.RETIRED}: raise SkillResolutionError("skill not executable")
        if not set(skill.document["required_scopes"]).issubset(set(scopes)): raise SkillAuthorizationError("required scopes are not satisfied")
        if not set(skill.document["required_permissions"]).issubset(set(caller_permissions)): raise SkillAuthorizationError("required permissions exceed caller authority")
        allowed_env=set(skill.document["allowed_environments"])
        if allowed_env and (environment_hash not in allowed_env): raise SkillSandboxError("environment is not pinned for this skill")
        if skill.document["sandbox_required"] and execution_mode=="trusted": raise SkillSandboxError("sandbox-required skill cannot resolve in trusted mode")
        mode_min=str(skill.document["execution_contract"]["mode_min"]); ranks={"trusted":0,"restricted":1,"isolated":2,"simulation":0}
        if execution_mode != "simulation" and ranks.get(execution_mode,9) < ranks.get(mode_min,9): raise SkillSandboxError("execution mode is below skill minimum")
        if str(skill.document["sensitivity"])=="secret" and execution_mode != "isolated": raise SkillSandboxError("secret skills require isolated execution")

    def check_prerequisites(self, skill: Skill, available: Sequence[str]) -> tuple[bool, tuple[str,...]]:
        have={str(x).split("@")[0] for x in available}; missing=tuple(sorted(set(str(x).split("@")[0] for x in skill.document["prerequisites"] if str(x).split("@")[0] not in have)))
        return not missing, missing

    def install(self, skill_ref: str, *, environment_hash: str, environment: Mapping[str,Any] | None=None) -> InstallPlan:
        root=self.registry.resolve(skill_ref,tenant_id=self.tenant_id)
        self._check_access(root,(),environment_hash,str(root.document["execution_contract"]["mode_min"]),())
        graph=SkillDependencyGraph(self.registry,tenant_id=self.tenant_id); detected=graph.detect()
        if detected["cycles"]: raise SkillResolutionError("dependency cycle detected")
        resolved={root.reference:root}; stack=[root]
        while stack:
            s=stack.pop()
            deps=list(s.document["prerequisites"])+list(s.document["dependencies"]["skills"])
            for raw in deps:
                dep=self.registry.resolve(raw,tenant_id=self.tenant_id)
                if dep.state==SkillState.REVOKED: raise SkillResolutionError("revoked dependency")
                self._check_access(dep,(),environment_hash,str(dep.document["execution_contract"]["mode_min"]),()) if dep.document["required_scopes"] or dep.document["required_permissions"] else None
                if dep.reference not in resolved: resolved[dep.reference]=dep; stack.append(dep)
        refs=tuple(sorted(resolved)); lockfile={k:v.version for k,v in ((s.id,s) for s in resolved.values())}
        iid=str(uuid.uuid4()); payload={"installation_id":iid,"tenant_id":self.tenant_id,"root_ref":root.reference,"resolved_refs":list(refs),"lockfile":lockfile,"environment_hash":environment_hash,"signature":"","signer_public_key":self.public_key_b64,"created_at":time.time()}
        payload["signature"]=_b64(self.signer.sign(canonical_bytes(payload)))
        plan=InstallPlan(iid,self.tenant_id,root.reference,refs,lockfile,environment_hash,payload["signature"],self.public_key_b64,payload["created_at"])
        self._emit("Staged",{"skill_id":root.id,"skill_ref":root.reference,"installation_id":iid,"resolved_refs":list(refs)})
        return plan

    def apply(self, plan: InstallPlan) -> Skill:
        if plan.tenant_id != self.tenant_id or not plan.verify(): raise SkillAuthorizationError("invalid installation plan")
        installed=self.registry.resolve(plan.root_ref,tenant_id=self.tenant_id)
        for ref in plan.resolved_refs:
            dep=self.registry.resolve(ref,tenant_id=self.tenant_id)
            if dep.state not in {SkillState.CERTIFIED,SkillState.STAGED,SkillState.AVAILABLE,SkillState.DEPRECATED}: raise SkillLifecycleError("installation requires certified lineage")
        self._emit("Available",{"skill_id":installed.id,"skill_ref":installed.reference,"installation_id":plan.installation_id})
        return installed

    def rollback_installation(self, installation_id: str) -> None:
        self._emit("Retired",{"installation_id":installation_id,"reason":"installation_rollback"})

    def compose(self, skills: Sequence[str], *, input_schema: str, output_schema: str, transaction_boundary: str="per_step", failure_handling: str="fail_fast") -> Skill:
        if not skills: raise SkillCompositionError("at least one skill is required")
        resolved=[self.registry.resolve(s,tenant_id=self.tenant_id,allow_deprecated=False) for s in skills]
        if any(not s.document["composable"] for s in resolved): raise SkillCompositionError("non-composable skill in composition")
        if any(s.state in {SkillState.REVOKED,SkillState.RETIRED} for s in resolved): raise SkillCompositionError("revoked/retired skill cannot compose")
        for left,right in zip(resolved,resolved[1:]):
            declared_out=str(left.document["outputs"]["schema_ref"]); declared_in=str(right.document["inputs"]["schema_ref"])
            if declared_out not in {declared_in,"urn:jarvis:schema:any:1.0.0"} and declared_in!="urn:jarvis:schema:any:1.0.0": raise SkillCompositionError(f"schema incompatibility {declared_out} -> {declared_in}")
        perms=set.intersection(*(set(s.document["required_permissions"]) for s in resolved)) if resolved else set()
        caps=set().union(*(set(s.document["capabilities_provided"]) for s in resolved))
        side_effects=[dict(x) for s in resolved for x in s.document["side_effects"]]
        non_idempotent=any(not bool(s.document["execution_contract"]["idempotent"]) for s in resolved)
        if non_idempotent and not any(bool(x.get("reversible")) or x.get("compensating_skill") for x in side_effects): raise SkillCompositionError("non-idempotent composition requires compensation or reversible effects")
        budgets=[s.document["execution_contract"] for s in resolved]
        composite_id=str(uuid.uuid4()); now=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
        # Composite is signed with fabric signer and explicitly uncertified.
        composite=Skill.create(skill_id=composite_id,skill_name="jarvis.skills.composite."+composite_id[:8],skill_version="1.0.0",author_principal="skill-fabric",author_key_id="skill-fabric",private_key=self.signer,tenant_id=self.tenant_id,capabilities_provided=sorted(caps),required_permissions=sorted(perms),required_scopes=sorted(set().union(*(set(s.document["required_scopes"]) for s in resolved))),tools=sorted(set().union(*(set(s.document["tools"]) for s in resolved))),models=sorted(set().union(*(set(s.document["models"]) for s in resolved))),knowledge=sorted(set().union(*(set(s.document["knowledge"]) for s in resolved))),inputs_schema=input_schema,outputs_schema=output_schema,side_effects=side_effects,execution_contract={"mode_min":max((str(x["mode_min"]) for x in budgets),key=lambda v:_MODE_RANK.get(v,9)),"deterministic":all(x["deterministic"] for x in budgets),"idempotent":not non_idempotent,"checkpointable":all(x["checkpointable"] for x in budgets),"cancellation_safe":all(x["cancellation_safe"] for x in budgets),"max_wall_seconds":sum(float(x["max_wall_seconds"]) for x in budgets),"max_cpu_seconds":sum(float(x["max_cpu_seconds"]) for x in budgets),"max_ram_mb":min(int(x["max_ram_mb"]) for x in budgets),"max_vram_mb":min(int(x["max_vram_mb"]) for x in budgets),"max_network_bytes":min(int(x["max_network_bytes"]) for x in budgets),"max_subprocesses":min(int(x["max_subprocesses"]) for x in budgets),"max_tool_calls":min(int(x["max_tool_calls"]) for x in budgets),"max_api_calls":min(int(x["max_api_calls"]) for x in budgets),"concurrency_safe":all(x["concurrency_safe"] for x in budgets)},tests=[],benchmarks=[],golden_datasets=[],required_pass_rate=0.98,security_policy_ref="jarvis.skill.composition",sandbox_required=any(bool(s.document["sandbox_required"]) for s in resolved),composable=True,composition_contract={"accepts_upstream":[input_schema],"produces_for_downstream":[output_schema],"transaction_safe":transaction_boundary in {"whole_pipeline","per_step"},"requires_ordering":any(bool(s.document["composition_contract"]["requires_ordering"]) for s in resolved)},trust_level="restricted",provenance_method="composed",provenance_refs=[s.fingerprint for s in resolved],parent_skills=[s.reference for s in resolved])
        self.register(composite)
        self._emit("Created",{"skill_id":composite.id,"skill_ref":composite.reference,"pipeline":list(skills)},event_type="Skill.Composition")
        return composite

    def test(self, skill_ref: str, suite: Sequence[Mapping[str,Any]], *, auth: ExecutionAuthContext | None=None) -> dict[str,Any]:
        sid, version = _ref(skill_ref)
        skill=self.registry.get(sid, version, tenant_id=self.tenant_id)
        if self.harness is None: raise SkillError("P2-E AgentHarness is required for skill tests")
        results=[]
        for spec in suite:
            kind=str(spec.get("kind","unit")); passed=False; error=None; started=time.time()
            runner=spec.get("runner")
            if not callable(runner): error="test runner callable is required"
            else:
                try:
                    # Test runners are entered only through P2-E. The caller supplies a verified ExecutionContext factory.
                    ctx=spec.get("context")
                    if not isinstance(ctx,ExecutionContext): error="ExecutionContext required for P2-E bound test"
                    else:
                        handle=self.harness.prepare(ctx,runner); self.harness.start(handle); result=self.harness.wait(handle,timeout=ctx.budgets.wall_seconds)
                        passed=result is not None and result.ok
                        if not passed and result is not None: error=result.error
                except Exception as exc: error=type(exc).__name__+":"+str(exc)
            results.append({"kind":kind,"passed":passed,"error":error,"duration_seconds":time.time()-started})
        score=(sum(1 for x in results if x["passed"])/len(results)) if results else 0.0
        report={"skill_ref":skill.reference,"score":score,"required_pass_rate":skill.document["required_pass_rate"],"results":results,"timestamp":time.time()}
        self._emit("Started",{"skill_id":skill.id,"skill_ref":skill.reference,"test_kind":"suite"},event_type="Skill.Test")
        self._emit("Passed" if score>=skill.document["required_pass_rate"] else "Failed",{"skill_id":skill.id,"skill_ref":skill.reference,"score":score},event_type="Skill.Test")
        return report

    def execute(self, skill_ref: str, *, context: ExecutionContext, implementation: Callable[[Any], Any]) -> Any:
        skill = self.resolve(skill_ref, scopes=context.auth_context.scopes, environment_hash=context.environment_hash, execution_mode=context.execution_mode.value, caller_permissions=context.auth_context.scopes)
        if self.harness is None:
            raise SkillError("P2-E AgentHarness is required for skill execution")
        if context.agent_genome_hash and skill.document["lineage"]["author"].get("agent_genome_hash") not in (None, context.agent_genome_hash):
            raise SkillAuthorizationError("skill author genome does not match execution context")
        contract = skill.document["execution_contract"]
        limits = {"wall_seconds": "max_wall_seconds", "cpu_seconds": "max_cpu_seconds", "ram_mb": "max_ram_mb", "vram_mb": "max_vram_mb", "network_bytes_out": "max_network_bytes", "subprocess_count": "max_subprocesses", "tool_calls": "max_tool_calls", "api_calls": "max_api_calls"}
        for budget_field, contract_field in limits.items():
            if float(getattr(context.budgets, budget_field)) > float(contract[contract_field]):
                raise SkillSandboxError(f"execution budget exceeds skill contract: {budget_field}")
        if bool(contract["deterministic"]) and not context.deterministic:
            raise SkillSandboxError("deterministic skill requires deterministic execution context")
        handle = self.harness.prepare(context, implementation)
        self.harness.start(handle)
        result = self.harness.wait(handle, timeout=context.budgets.wall_seconds)
        if result is None:
            raise SkillError("skill execution timed out")
        if not result.ok:
            raise SkillError(str(result.error or "skill execution failed"))
        return result.output

    def benchmark(self, skill_ref: str, benchmark_ref: str, *, score: float, evidence_hash: str) -> dict[str,Any]:
        sid, version = _ref(skill_ref)
        skill=self.registry.get(sid, version, tenant_id=self.tenant_id); report={"skill_ref":skill.reference,"benchmark_ref":benchmark_ref,"score":float(score),"evidence_hash":evidence_hash,"timestamp":time.time()}; self._emit("Benchmarked",report,event_type="Skill.Certification"); return report

    def certify(self, skill_ref: str, evidence_bundle: Mapping[str,Any]) -> CertificationRecord:
        sid, version = _ref(skill_ref)
        skill=self.registry.get(sid, version, tenant_id=self.tenant_id)
        tests=evidence_bundle.get("tests") or {}; adversarial=bool(evidence_bundle.get("adversarial_passed",False)); security_clean=bool(evidence_bundle.get("security_clean",False)); resource_ok=bool(evidence_bundle.get("resource_within_limits",False)); score=float(evidence_bundle.get("score",0.0)); evidence_hash=str(evidence_bundle.get("evidence_hash",""))
        if skill.document["certification_status"]=="revoked": raise SkillCertificationError("revoked skill cannot certify")
        if skill.state != SkillState.EVALUATING: raise SkillCertificationError("skill must be EVALUATING before certification")
        if not adversarial: raise SkillCertificationError("adversarial suite is mandatory")
        if not security_clean: raise SkillCertificationError("security scan is not clean")
        if not resource_ok: raise SkillCertificationError("resource profile exceeds declared limits")
        if score < float(skill.document["required_pass_rate"]): raise SkillCertificationError("required pass rate not met")
        for dep in list(skill.document["prerequisites"])+list(skill.document["dependencies"]["skills"]):
            s=self.registry.resolve(dep,tenant_id=self.tenant_id,allow_deprecated=False)
            if s.state in {SkillState.REVOKED,SkillState.RETIRED}: raise SkillCertificationError("revoked dependency")
        record_payload={"skill_ref":skill.reference,"evidence_hash":evidence_hash,"score":score,"adversarial_passed":True,"security_clean":True,"resource_within_limits":True,"issued_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"signer_public_key":self.public_key_b64,"signature":""}
        signature=_b64(self.signer.sign(canonical_bytes(record_payload))); record=CertificationRecord(**{**record_payload,"signature":signature})
        SchemaValidator(max_errors=32).validate_or_raise({"skill_ref":record.skill_ref,"evidence_hash":record.evidence_hash,"score":record.score,"adversarial_passed":record.adversarial_passed,"security_clean":record.security_clean,"resource_within_limits":record.resource_within_limits,"issued_at":record.issued_at,"signer_public_key":record.signer_public_key,"signature":record.signature}, json.loads(_CERT_SCHEMA.read_text(encoding="utf-8")))
        certified=self.registry.mutate_state(skill.reference,tenant_id=self.tenant_id,target=SkillState.CERTIFIED,signer=self.signer,reason="certification")
        self._emit("Certified", {"skill_id": certified.id, "skill_ref": certified.reference, "state": certified.state.value}, priority="critical")
        self._emit("Issued",{"skill_id":skill.id,"skill_ref":skill.reference,"evidence_hash":evidence_hash,"score":score},event_type="Skill.Certification",priority="critical")
        return record

    def deprecate(self, skill_ref: str, reason: str) -> Skill:
        skill=self.registry.deprecate(skill_ref,tenant_id=self.tenant_id,signer=self.signer,reason=reason)
        self._emit("Deprecated", {"skill_id":skill.id,"skill_ref":skill.reference,"reason":reason})
        return skill
    def retire(self, skill_ref: str, successor: str) -> Skill:
        skill=self.registry.retire(skill_ref,tenant_id=self.tenant_id,signer=self.signer,successor=successor)
        self._emit("Retired", {"skill_id":skill.id,"skill_ref":skill.reference,"successor":successor})
        return skill
    def revoke(self, skill_ref: str, reason: str) -> Skill:
        if self.security_authority is None or not self.security_authority(self.tenant_id, skill_ref, reason):
            raise SkillAuthorizationError("Security Authority authorization required for revoke")
        skill=self.registry.revoke(skill_ref,tenant_id=self.tenant_id,signer=self.signer,reason=reason); self._emit("Revoked",{"skill_id":skill.id,"skill_ref":skill.reference,"reason":reason},event_type="Skill.Revocation",priority="critical"); return skill

    def _required_event_scopes(self)->tuple[str,...]: return ("events.publish.skill.lifecycle",)


def diff_skills(a: Skill|Mapping[str,Any], b: Skill|Mapping[str,Any]) -> dict[str,Any]:
    left=a.document if isinstance(a,Skill) else dict(a); right=b.document if isinstance(b,Skill) else dict(b); changes=[]
    keys=sorted(set(left)|set(right))
    for key in keys:
        if key in {"skill_fingerprint","signature"}: continue
        if left.get(key)!=right.get(key): changes.append({"field":key,"before":copy.deepcopy(left.get(key)),"after":copy.deepcopy(right.get(key))})
    return {"changes":changes,"compatible_additive":all(c["field"] not in {"required_permissions","required_scopes","security_policy_ref","execution_contract","side_effects"} for c in changes)}

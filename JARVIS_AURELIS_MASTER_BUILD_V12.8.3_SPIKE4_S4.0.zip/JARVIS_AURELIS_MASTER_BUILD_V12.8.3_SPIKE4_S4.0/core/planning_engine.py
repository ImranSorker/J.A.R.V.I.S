"""P2-L Planning Engine 2.0.

Canonical declarative planning subsystem for J.A.R.V.I.S. V12.8.3.  The
engine constructs signed/versioned/replayable plan artifacts, validates hierarchy,
dependencies, temporal/resource constraints, confidence and contingencies, and
hands simulation/authorization/execution to their owning phases.  It never
executes tools, skills, models, policies, or agents itself.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import math
import re
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.event_fabric import AuthContext, EventEnvelope, EventFabric, EventLineage, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

ROOT = Path(__file__).resolve().parent
SCHEMA_DIR = ROOT / "schemas"
TEMPLATE_DIR = ROOT / "planning_engine" / "templates"
TEMPLATE_PUBLIC_KEY_B64 = "nz7YEcH6+IvOOiVwtlVbwncuiG0PXgF9yyRMz66+gvo="

LEVELS = ("goal", "objective", "plan", "subplan", "task", "action", "tool_call")
STRUCTURES = ("atomic", "sequence", "parallel", "branch", "loop", "join", "try_catch")
STEP_KINDS = ("skill_call", "tool_call", "model_call", "verification", "wait", "branch", "parallel", "join", "loop", "try_catch", "compensation", "terminal")
DEPENDENCY_KINDS = ("data", "control", "temporal", "resource", "exclusion")
FAILURE_POLICIES = ("fail", "retry", "compensate", "continue", "escalate", "abort_plan")
CONTINGENCY_TRIGGERS = ("step_failed", "precondition_violated", "postcondition_violated", "invariant_violated", "budget_exceeded", "timeout", "verification_failed", "external_signal", "simulation_diverged")
CONTINGENCY_RESPONSES = ("retry", "compensate", "alternative_plan", "rollback_plan", "escalate", "abort_plan")
TEMPORAL_KINDS = ("before", "after", "deadline", "start_window", "duration_bound", "periodic", "mutex")
PLANNER_METHODS = ("hierarchical", "llm_assisted", "template", "manual", "hybrid")
CONF_METHODS = ("evidence_based", "heuristic", "model_reported", "hybrid")
OUTCOMES = ("completed", "failed", "cancelled", "rolled_back", "partial")
STATES = ("draft", "simulated", "verified", "authorized", "executing", "completed", "failed", "cancelled", "rolled_back")
SCHEMA_VERSION = "1.0.0"
ENGINE_VERSION = "2.0.0"

EVENTS = (
    "PlanCreated", "PlanValidated", "PlanSimulated", "PlanAuthorized", "PlanExecuting", "PlanCompleted",
    "PlanFailed", "PlanCancelled", "PlanRolledBack", "PlanSwitched", "ContingencyTriggered",
    "VerificationCheckpoint", "AuthorizationDenied", "OutcomeRecorded",
)

class PlanningError(RuntimeError): pass
class PlanningValidationError(PlanningError, ValueError):
    """Planning artifact validation failed."""
class PlanningSignatureError(PlanningError, ValueError):
    """Planning artifact signature verification failed."""
class PlanningIntegrityError(PlanningError, ValueError): pass
class PlanningAccessDenied(PlanningError, PermissionError):
    """Planning authorization or tenant boundary denied."""
class PlanNotFound(PlanningError, LookupError):
    """Plan artifact was not found in the authorized tenant."""
class PlanImmutable(PlanningError):
    """P2-L PlanImmutable condition."""
class DependencyCycleError(PlanningError):
    """P2-L DependencyCycleError condition."""
class TemporalConstraintError(PlanningError):
    """P2-L TemporalConstraintError condition."""
class ResourceBudgetError(PlanningError):
    """P2-L ResourceBudgetError condition."""
class ContractError(PlanningError):
    """P2-L ContractError condition."""
class LowConfidence(PlanningError):
    """P2-L LowConfidence condition."""
class AuthorizationDenied(PlanningError, PermissionError):
    """Security Authority denied plan authorization."""
class SimulationRequired(PlanningError):
    """P2-L SimulationRequired condition."""
class IrreversiblePlanError(PlanningError):
    """P2-L IrreversiblePlanError condition."""
class TemplateError(PlanningError, ValueError): pass

DEFAULT_BUDGET = {
    "cpu_seconds": 0.0, "wall_seconds": 0.0, "ram_mb": 0, "vram_mb": 0, "gpu_seconds": 0.0,
    "network_bytes": 0, "tokens_in": 0, "tokens_out": 0, "tool_calls": 0, "api_calls": 0,
}

@dataclass(frozen=True, slots=True)
class PlanConfig:
    store_path: str = ":memory:"
    storage_secret: bytes = b"jarvis-planning-engine-default-secret-32b"
    default_tenant_id: str = "default"
    low_confidence_threshold: float = 0.35
    structural_factor: float = 0.98
    max_loop_iterations: int = 1000
    signer_key_id: str = "planning-engine"
    risk_threshold: float = 0.70

@dataclass(frozen=True, slots=True)
class PlanVersionRef:
    plan_id: str
    plan_version: int

@dataclass(frozen=True, slots=True)
class ValidationReport:
    valid: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    execution_order: tuple[str, ...]
    confidence: float
    estimated_cost: Mapping[str, float]
    estimated_latency_seconds: float
    risk_score: float

@dataclass(frozen=True, slots=True)
class PlanOutcome:
    outcome_id: str
    plan_id: str
    execution_ref: str
    result: str
    success: bool
    actual_metrics: Mapping[str, Any]
    confidence_predicted: float
    confidence_actual: float
    calibration_delta: float
    verification_refs: tuple[str, ...]
    failure_ids: tuple[str, ...]
    memory_refs: tuple[str, ...]
    recorded_at: str
    signature: str


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def _uuid() -> str:
    return str(uuid.uuid4())

def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()

def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")
def _unb64(text: str) -> bytes:
    return base64.b64decode(str(text).encode("ascii"))
def _unsigned(doc: Mapping[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(dict(doc)); out["signature"] = ""; out["integrity_hash"] = ""; return out

def _sign(doc: Mapping[str, Any], key: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    body = copy.deepcopy(dict(doc)); body["writer_key_id"] = key_id; body["signature"] = ""; body["integrity_hash"] = ""
    body["integrity_hash"] = _sha(_unsigned(body)); body["signature"] = _b64(key.sign(canonical_bytes(_unsigned(body)))); return body

def verify_plan_signature(plan: Mapping[str, Any], public_key: bytes | Ed25519PublicKey) -> bool:
    try:
        if not plan.get("signature") or not plan.get("integrity_hash"):
            return False
        raw = public_key if isinstance(public_key, bytes) else public_key.public_bytes_raw()
        expected = _sha(_unsigned(plan))
        if not hmac.compare_digest(expected, str(plan["integrity_hash"])):
            return False
        Ed25519PublicKey.from_public_bytes(raw).verify(_unb64(str(plan["signature"])), canonical_bytes(_unsigned(plan)))
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError):
        return False

def sign_confidence_waiver(reason: str, principal: str, key: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    doc={"reason":str(reason),"principal":str(principal),"key_id":str(key_id),"issued_at":_utc(),"signature":""}
    doc["signature"]=_b64(key.sign(canonical_bytes({k:v for k,v in doc.items() if k!="signature"})))
    return doc

def verify_confidence_waiver(waiver: Mapping[str,Any], public_key: bytes | Ed25519PublicKey) -> bool:
    try:
        signature=str(waiver.get("signature","")); body={k:v for k,v in dict(waiver).items() if k!="signature"}
        if not signature: return False
        raw=public_key if isinstance(public_key,bytes) else public_key.public_bytes_raw()
        Ed25519PublicKey.from_public_bytes(raw).verify(_unb64(signature),canonical_bytes(body)); return True
    except (InvalidSignature,ValueError,TypeError,KeyError): return False

def _require_auth(context: Any, scopes: Sequence[str], tenant_id: str) -> None:
    if context is None:
        raise PlanningAccessDenied("ExecutionContext/auth context is required")
    auth = getattr(context, "auth_context", context)
    granted = set(getattr(auth, "scopes", auth.get("scopes", []) if isinstance(auth, Mapping) else []))
    actual_tenant = getattr(context, "tenant_id", tenant_id)
    if str(actual_tenant) != str(tenant_id):
        raise PlanningAccessDenied("cross-tenant planning operation denied")
    if not set(scopes).issubset(granted) and "planning.admin" not in granted:
        raise PlanningAccessDenied(f"missing planning scopes: {sorted(set(scopes)-granted)}")

def _budget(value: Mapping[str, Any] | None) -> dict[str, float | int]:
    out = dict(DEFAULT_BUDGET); out.update(dict(value or {}))
    for k in out:
        if float(out[k]) < 0: raise PlanningValidationError(f"negative budget: {k}")
    out["ram_mb"] = int(out["ram_mb"]); out["vram_mb"] = int(out["vram_mb"]); out["network_bytes"] = int(out["network_bytes"])
    out["tokens_in"] = int(out["tokens_in"]); out["tokens_out"] = int(out["tokens_out"]); out["tool_calls"] = int(out["tool_calls"]); out["api_calls"] = int(out["api_calls"])
    return out

def _sum_budgets(a: Mapping[str, Any], b: Mapping[str, Any]) -> dict[str, float | int]:
    return {k: float(a.get(k, 0)) + float(b.get(k, 0)) for k in DEFAULT_BUDGET}

def _leq(child: Mapping[str, Any], parent: Mapping[str, Any]) -> bool:
    return all(float(child.get(k, 0)) <= float(parent.get(k, 0)) + 1e-12 for k in DEFAULT_BUDGET)

def _versioned(method: str) -> dict[str, str]: return {"method": method, "version": ENGINE_VERSION}

class PlanStore:
    """Durable append-only plan store with hash-chain/HMAC integrity."""
    def __init__(self, path: str, secret: bytes) -> None:
        self.path = str(path); self.secret = bytes(secret); self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False) if self.path != ":memory:" else sqlite3.connect(":memory:", check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("CREATE TABLE IF NOT EXISTS plans(tenant_id TEXT NOT NULL, plan_id TEXT NOT NULL, version INTEGER NOT NULL, body TEXT NOT NULL, body_hash TEXT NOT NULL, prev_hash TEXT, row_hmac TEXT NOT NULL, PRIMARY KEY(tenant_id,plan_id,version))")
        self._db.commit(); self._verify()
    def _hmac(self, row: Mapping[str, Any]) -> str: return hmac.new(self.secret, canonical_bytes(row), hashlib.sha256).hexdigest()
    def _verify(self) -> None:
        cur = self._db.execute("SELECT tenant_id,plan_id,version,body,body_hash,prev_hash,row_hmac FROM plans ORDER BY tenant_id,plan_id,version")
        for tenant,pid,ver,body,bh,prev,rh in cur.fetchall():
            row={"tenant_id":tenant,"plan_id":pid,"version":ver,"body":body,"body_hash":bh,"prev_hash":prev}
            if not hmac.compare_digest(self._hmac(row),rh): raise PlanningIntegrityError("plan store HMAC mismatch")
            if not hmac.compare_digest(_sha(json.loads(body)),bh): raise PlanningIntegrityError("plan body hash mismatch")
    def put(self, plan: Mapping[str, Any]) -> None:
        tenant,pid,ver=str(plan["tenant_id"]),str(plan["plan_id"]),int(plan["plan_version"])
        with self._lock:
            prev = self._db.execute("SELECT body_hash FROM plans WHERE tenant_id=? AND plan_id=? ORDER BY version DESC LIMIT 1",(tenant,pid)).fetchone()
            prev_hash = prev[0] if prev else None
            body=json.dumps(dict(plan),sort_keys=True,separators=(",",":")); bh=_sha(plan)
            row={"tenant_id":tenant,"plan_id":pid,"version":ver,"body":body,"body_hash":bh,"prev_hash":prev_hash}; rh=self._hmac(row)
            self._db.execute("INSERT INTO plans VALUES(?,?,?,?,?,?,?)",(tenant,pid,ver,body,bh,prev_hash,rh)); self._db.commit()
    def get(self, tenant: str, plan_id: str, version: int | None = None) -> dict[str,Any]:
        q="SELECT body FROM plans WHERE tenant_id=? AND plan_id=?"; args=[tenant,plan_id]
        if version is not None: q += " AND version=?"; args.append(int(version))
        q += " ORDER BY version DESC LIMIT 1"; row=self._db.execute(q,args).fetchone()
        if not row: raise PlanNotFound(plan_id)
        return json.loads(row[0])
    def history(self, tenant: str, plan_id: str) -> list[dict[str,Any]]:
        rows=self._db.execute("SELECT body FROM plans WHERE tenant_id=? AND plan_id=? ORDER BY version",(tenant,plan_id)).fetchall(); return [json.loads(x[0]) for x in rows]
    def replay(self, tenant: str, plan_id: str) -> list[dict[str,Any]]: return self.history(tenant,plan_id)
    def verify(self) -> bool:
        try: self._verify(); return True
        except PlanningIntegrityError: return False
    def close(self) -> None: self._db.close()

class DependencyGraph:
    def __init__(self, steps: Sequence[Mapping[str,Any]], dependencies: Sequence[Mapping[str,Any]], max_loop_iterations: int = 1000):
        self.steps={str(s["step_id"]):dict(s) for s in steps}; self.edges={sid:set() for sid in self.steps}; self.in_degree={sid:0 for sid in self.steps}
        for d in dependencies:
            a,b=str(d["from"]),str(d["to"])
            if a not in self.steps or b not in self.steps: raise PlanningValidationError("dependency references unknown step")
            if d["kind"] not in DEPENDENCY_KINDS: raise PlanningValidationError("invalid dependency kind")
            if a==b: raise DependencyCycleError("self dependency")
            if b not in self.edges[a]: self.edges[a].add(b); self.in_degree[b]+=1
        self.order=self._toposort()
        self.max_loop_iterations=max_loop_iterations
    def _toposort(self) -> tuple[str,...]:
        deg=dict(self.in_degree); queue=sorted([x for x,v in deg.items() if v==0]); out=[]
        while queue:
            cur=queue.pop(0); out.append(cur)
            for nxt in sorted(self.edges[cur]):
                deg[nxt]-=1
                if deg[nxt]==0: queue.append(nxt); queue.sort()
        if len(out)!=len(self.steps): raise DependencyCycleError("dependency cycle detected; loops require bounded loop structure")
        return tuple(out)

class PlanningEngine:
    """Canonical P2-L planner. All execution is delegated outside this object."""
    def __init__(self, *, config: PlanConfig | None = None, event_fabric: Any | None = None,
                 signer: Ed25519PrivateKey | None = None, skill_fabric: Any | None = None,
                 model_fabric: Any | None = None, memory: Any | None = None,
                 simulation_handoff: Callable[[Mapping[str,Any], Mapping[str,Any]], str] | None = None,
                 authorization_verifier: Callable[[str, str], bool] | None = None,
                 execution_handoff: Callable[[Mapping[str,Any], Any], str] | None = None) -> None:
        self.config=config or PlanConfig(); self.signer=signer or Ed25519PrivateKey.generate(); self.public_key=self.signer.public_key(); self.key_id=self.config.signer_key_id
        self.store=PlanStore(self.config.store_path,self.config.storage_secret); self.event_fabric=event_fabric; self.skill_fabric=skill_fabric; self.model_fabric=model_fabric; self.memory=memory
        self.simulation_handoff=simulation_handoff; self.authorization_verifier=authorization_verifier; self.execution_handoff=execution_handoff; self._lock=threading.RLock()
    def _emit(self,name:str,payload:Mapping[str,Any],*,tenant_id:str,context:Any,correlation_id:str|None=None,causation_id:str|None=None,priority:str|None=None)->None:
        if self.event_fabric is None: return
        auth=getattr(context,"auth_context",None)
        scopes=tuple(getattr(auth,"scopes",()) if auth is not None else ("events.publish.task",))
        principal=str(getattr(auth,"principal","planning-engine") if auth is not None else "planning-engine")
        policy_ref=str(getattr(auth,"policy_ref","planning-engine") if auth is not None else "planning-engine")
        ec=AuthContext(principal,scopes,policy_ref,None)
        producer=ProducedBy("system","planning-engine",_sha(self.public_key.public_bytes_raw()),"system")
        event=EventEnvelope.create(event_type="Task",event_name=name,payload=dict(payload),produced_by=producer,auth_context=ec,tenant_id=tenant_id,partition_key=str(payload.get("plan_id",tenant_id)),correlation_id=correlation_id or _uuid(),causation_id=causation_id,priority=priority,signing_key=self.signer)
        if hasattr(self.event_fabric,"publish_envelope"): self.event_fabric.publish_envelope(event)
        elif hasattr(self.event_fabric,"publish"): self.event_fabric.publish(event)
    def _load(self, plan_id:str, context:Any, tenant_id:str|None=None, version:int|None=None)->dict[str,Any]:
        tenant=str(tenant_id or getattr(context,"tenant_id",self.config.default_tenant_id)); _require_auth(context,("planning.read",),tenant)
        try:
            return self.store.get(tenant,plan_id,version)
        except PlanNotFound:
            if version is None:
                for other_tenant in self._tenants_for_plan(plan_id):
                    if other_tenant != tenant:
                        raise PlanningAccessDenied("cross-tenant plan access denied")
            raise
    def _tenants_for_plan(self, plan_id:str)->set[str]:
        try:
            rows=self.store._db.execute("SELECT DISTINCT tenant_id FROM plans WHERE plan_id=?",(plan_id,)).fetchall()
            return {str(r[0]) for r in rows}
        except Exception:
            return set()
    def _persist(self, plan:Mapping[str,Any], context:Any, *, scope="planning.write") -> dict[str,Any]:
        _require_auth(context,(scope,),str(plan["tenant_id"])); self.validate_doc(plan)
        with self._lock: self.store.put(plan)
        return copy.deepcopy(dict(plan))
    def validate_doc(self, plan: Mapping[str,Any]) -> None:
        try: SchemaValidator(max_errors=256).validate_or_raise(dict(plan), json.loads((SCHEMA_DIR/"plan_v1.schema.json").read_text()))
        except Exception as exc: raise PlanningValidationError(str(exc)) from exc
        if plan.get("plan_level") not in LEVELS or plan.get("structure") not in STRUCTURES: raise PlanningValidationError("invalid level/structure")
        if float(plan["confidence"]["score"]) < 0 or float(plan["confidence"]["score"]) > 1: raise PlanningValidationError("confidence out of range")
        self._validate_children_budgets(plan); self._validate_dag(plan); self._validate_data_dependencies(plan); self._validate_temporal(plan); self._validate_contingencies(plan); self._validate_confidence_gate(plan); self._validate_signing(plan)
    def _validate_signing(self, plan:Mapping[str,Any])->None:
        if plan.get("signature") and not verify_plan_signature(plan,self.public_key): raise PlanningSignatureError("plan signature/integrity mismatch")
    def _validate_children_budgets(self, plan:Mapping[str,Any])->None:
        parent=_budget(plan.get("budget_ceiling")); total=_budget(None)
        for s in plan.get("steps",[]): total=_sum_budgets(total,_budget(s.get("budget")))
        if not _leq(total,parent): raise ResourceBudgetError("child step budgets exceed parent ceiling")
    def _validate_dag(self, plan:Mapping[str,Any])->DependencyGraph:
        return DependencyGraph(plan.get("steps",[]),plan.get("dependencies",[]),self.config.max_loop_iterations)
    def _validate_data_dependencies(self, plan:Mapping[str,Any])->None:
        steps={str(s["step_id"]):s for s in plan.get("steps",[])}
        for d in plan.get("dependencies",[]):
            if d.get("kind")!="data": continue
            src=steps[str(d["from"])]; dst=steps[str(d["to"])]
            out_schema=src.get("outputs",{}).get("schema_ref") or src.get("outputs",{}).get("schema")
            in_schema=dst.get("inputs",{}).get("schema_ref") or dst.get("inputs",{}).get("schema")
            if out_schema and in_schema and out_schema!=in_schema and out_schema!="urn:jarvis:schema:any:v1":
                raise ContractError(f"data dependency type mismatch: {src['step_id']} -> {dst['step_id']}")
            if not out_schema or not in_schema:
                raise ContractError(f"data dependency lacks typed input/output contract: {src['step_id']} -> {dst['step_id']}")

    def _validate_confidence_gate(self, plan:Mapping[str,Any])->None:
        score=float(plan.get("confidence",{}).get("score",0.0))
        if score < self.config.low_confidence_threshold:
            waiver=plan.get("confidence_waiver")
            if not waiver or not verify_confidence_waiver(waiver,self.public_key):
                raise LowConfidence(f"plan confidence {score:.4f} below threshold {self.config.low_confidence_threshold:.4f}")

    def _validate_temporal(self,plan:Mapping[str,Any])->None:
        constraints=plan.get("temporal_constraints",[]); edges={}
        for c in constraints:
            if c.get("kind") not in TEMPORAL_KINDS: raise TemporalConstraintError("invalid temporal kind")
            a,b=str(c.get("from",c.get("step_id",""))),str(c.get("to",c.get("until",c.get("step_id",""))))
            if c.get("kind") in {"before","after","mutex"} and a and b: edges.setdefault(a,set()).add(b)
        # Reuse DAG cycle check for explicit before/after/mutex relations.
        if edges:
            steps={str(s["step_id"]):s for s in plan.get("steps",[])}; deps=[]
            for a,bs in edges.items():
                for b in bs: deps.append({"kind":"temporal","from":a,"to":b})
            try:
                DependencyGraph(list(steps.values()),deps)
            except DependencyCycleError as exc:
                raise TemporalConstraintError(str(exc)) from exc
        wall=float(_budget(plan.get("budget_ceiling")).get("wall_seconds",0)); duration=sum(float(c.get("duration_seconds",0) or 0) for c in constraints if c.get("kind")=="duration_bound")
        if wall>0 and duration>wall+1e-12: raise TemporalConstraintError("temporal duration exceeds wall budget")
    def _validate_contingencies(self,plan:Mapping[str,Any])->None:
        steps={str(s["step_id"]):s for s in plan.get("steps",[])}; covered={str(c.get("target_step_id")):False for c in plan.get("contingencies",[])}
        for c in plan.get("contingencies",[]):
            if c.get("trigger") not in CONTINGENCY_TRIGGERS or c.get("response") not in CONTINGENCY_RESPONSES: raise PlanningValidationError("invalid contingency")
        for sid,s in steps.items():
            if bool(s.get("side_effects")) and any(str(x.get("reversibility",""))=="irreversible" for x in s.get("side_effects",[])):
                if not s.get("compensation_step_id") and not any(c.get("target_step_id")==sid for c in plan.get("contingencies",[])) and not plan.get("rollback_plan_id"):
                    raise IrreversiblePlanError(f"irreversible step {sid} lacks compensation/rollback")
            if s.get("failure_policy")=="fail" and not any(c.get("target_step_id")==sid for c in plan.get("contingencies",[])) and not s.get("accept_failure",False):
                raise PlanningValidationError(f"step {sid} fail policy lacks contingency")
        if plan.get("verification_checkpoints"):
            for cp in plan["verification_checkpoints"]:
                if cp.get("required") and not cp.get("contingency_ref") and cp.get("on_failure")!="abort_plan": raise PlanningValidationError("required checkpoint lacks contingency")
    def _risk(self,plan:Mapping[str,Any])->float:
        risk=0.0
        for s in plan.get("steps",[]):
            for side in s.get("side_effects",[]):
                risk=max(risk,float(side.get("risk_score",0) or 0));
                if side.get("reversibility")=="irreversible": risk=max(risk,.9)
        if plan.get("simulation_required"): risk=max(risk,.75)
        if plan.get("refusal_criteria"): risk=max(risk,.15)
        return min(1.0,risk)
    def _confidence(self,plan:Mapping[str,Any])->float:
        steps=plan.get("steps",[])
        if not steps: return 0.5
        vals=[max(0.0,min(1.0,float(s.get("confidence",0.0)))) for s in steps]
        factor=self.config.structural_factor
        structure=plan.get("structure")
        if structure=="sequence": return math.prod(vals)*factor
        if structure=="parallel": return min(vals)*factor
        if structure=="branch": return sum(vals)/len(vals)*factor
        if structure=="loop":
            it=max(1,min(self.config.max_loop_iterations,len(vals))); return min(vals)**it
        if structure=="try_catch": return max(vals)*factor if vals else 0.0
        return vals[0]
    def validate(self,plan_id:str,context:Any)->ValidationReport:
        p=self._load(plan_id,context); errors=[]; warnings=[]
        try: self.validate_doc(p)
        except PlanningError as exc: errors.append(str(exc))
        order=()
        try: order=self._validate_dag(p).order
        except PlanningError as exc: errors.append(str(exc))
        conf=self._confidence(p); risk=self._risk(p)
        if conf < self.config.low_confidence_threshold: warnings.append("low confidence")
        cost={k:float(v) for k,v in _budget(p.get("budget_ceiling")).items()}
        latency=float(p.get("budget_ceiling",{}).get("wall_seconds",0));
        report=ValidationReport(not errors,tuple(errors),tuple(warnings),order,conf,cost,latency,risk); self._emit("PlanValidated",{"plan_id":p["plan_id"],"plan_version":p["plan_version"],"valid":report.valid,"errors":list(report.errors),"confidence":report.confidence,"risk_score":report.risk_score},tenant_id=p["tenant_id"],context=context); return report
    def _new_plan(self, *, tenant_id:str, level:str, goal_ref:str|None, objective_ref:str|None, requested_by:Mapping[str,Any], structure:str="sequence", steps:Sequence[Mapping[str,Any]]=(), dependencies:Sequence[Mapping[str,Any]]=(), method:str="hierarchical", budget:Mapping[str,Any]|None=None, seed:int|None=None, context:Any=None, owner_agent_id:str|None=None, parent_plan_id:str|None=None, provenance_extra:Mapping[str,Any]|None=None)->dict[str,Any]:
        pid=_uuid(); requested_at=_utc(); step_list=[copy.deepcopy(dict(s)) for s in steps]
        for s in step_list: s.setdefault("step_id",_uuid()); s.setdefault("step_kind","terminal"); s.setdefault("ref",None); s.setdefault("inputs",{}); s.setdefault("outputs",{}); s.setdefault("preconditions",[]); s.setdefault("postconditions",[]); s.setdefault("invariants",[]); s.setdefault("budget",_budget(None)); s.setdefault("timeout_ms",0); s.setdefault("retry_policy",None); s.setdefault("failure_policy","fail"); s.setdefault("compensation_step_id",None); s.setdefault("verification_checkpoint_ref",None); s.setdefault("dependencies",[]); s.setdefault("side_effects",[]); s.setdefault("confidence",1.0); s.setdefault("provenance",{"method":method,"version":ENGINE_VERSION,"evidence_refs":[]})
        default_budget=_budget(budget) if budget is not None else _budget({k:sum(float(s.get("budget",{}).get(k,0)) for s in step_list) for k in DEFAULT_BUDGET})
        plan={"plan_id":pid,"plan_version":1,"plan_level":level,"tenant_id":tenant_id,"owner_agent_id":owner_agent_id,"owner_genome_hash":None,"requested_by":dict(requested_by),"requested_at":requested_at,"goal_ref":goal_ref,"objective_ref":objective_ref,"parent_plan_id":parent_plan_id,"children_plan_ids":[],"inputs":{"schema_ref":"urn:jarvis:plan:input:1.0.0","values_ref":None},"outputs":{"schema_ref":"urn:jarvis:plan:output:1.0.0","expected_ref":None},"preconditions":[],"postconditions":[],"invariants":[],"refusal_criteria":[],"budget_ceiling":default_budget,"structure":structure,"steps":step_list,"dependencies":[dict(d) for d in dependencies],"temporal_constraints":[],"resource_constraints":[],"confidence":{"score":0.0,"method":"heuristic" if not step_list else ("hybrid" if method=="hybrid" else "evidence_based"),"evidence_refs":[],"calibrated":False,"calibration_ref":None},"confidence_waiver":None,"contingencies":[],"rollback_plan_id":None,"alternative_plan_ids":[],"escalation_policy":None,"verification_checkpoints":[],"simulation_required":False,"simulation_plan_ref":None,"simulation_outcome_ref":None,"provenance":{"planner_method":method,"planner_version":ENGINE_VERSION,"models_used":[],"evidence_refs":[],"prior_plans_used":[],"derivation":None,"seed":seed},"state":"draft","authorized_by":None,"authorization_ref":None,"started_at":None,"finished_at":None,"signature":"","writer_key_id":self.key_id,"integrity_hash":""}
        plan["confidence"]["score"]=self._confidence(plan)
        if provenance_extra: plan["provenance"].update(dict(provenance_extra))
        return _sign(plan,self.signer,self.key_id)
    def plan(self, goal_or_objective: Mapping[str,Any]|str, context:Any, *, method:str="hierarchical", constraints:Mapping[str,Any]|None=None)->dict[str,Any]:
        tenant=str(getattr(context,"tenant_id",self.config.default_tenant_id)); _require_auth(context,("planning.write",),tenant)
        constraints=dict(constraints or {}); goal_ref=str(goal_or_objective.get("id")) if isinstance(goal_or_objective,Mapping) and goal_or_objective.get("id") else (str(goal_or_objective) if isinstance(goal_or_objective,str) else None)
        requested_by={"principal":str(getattr(getattr(context,"auth_context",None),"principal","planner")),"key_id":self.key_id}
        selected=method
        if method not in PLANNER_METHODS: raise PlanningValidationError("unknown planner method")
        if method=="llm_assisted" and self.model_fabric is None: raise PlanningError("llm-assisted planning requires P2-O Model Fabric")
        if method=="template": raise TemplateError("template planning requires instantiate(template_ref, parameters)")
        if isinstance(goal_or_objective,Mapping):
            for s in goal_or_objective.get("steps",[]): constraints.setdefault("steps",[]).append(s)
        p=self._new_plan(tenant_id=tenant,level="plan",goal_ref=goal_ref,objective_ref=constraints.get("objective_ref"),requested_by=requested_by,structure=str(constraints.get("structure","sequence")),steps=constraints.get("steps",[]),dependencies=constraints.get("dependencies",[]),method=selected,budget=constraints.get("budget_ceiling"),seed=getattr(context,"random_seed",None),context=context,owner_agent_id=getattr(context,"agent_id",None))
        if constraints.get("simulation_required") or constraints.get("dangerous"): p["simulation_required"]=True
        for key in ("temporal_constraints","resource_constraints","preconditions","postconditions","invariants","refusal_criteria","contingencies","verification_checkpoints","alternative_plan_ids"):
            if key in constraints: p[key]=copy.deepcopy(constraints[key])
        if constraints.get("rollback_plan_id") is not None:
            p["rollback_plan_id"]=str(constraints["rollback_plan_id"]); p["simulation_required"]=True
        if constraints.get("confidence_waiver") is not None: p["confidence_waiver"]=copy.deepcopy(constraints["confidence_waiver"])
        p["confidence"]["score"]=self._confidence(p); p=_sign(p,self.signer,self.key_id); self._persist(p,context); self._emit("PlanCreated",{"plan_id":p["plan_id"],"plan_version":1,"plan_level":p["plan_level"],"planner_method":method},tenant_id=tenant,context=context,correlation_id=getattr(context,"correlation_id",None)); return p
    def replan(self,plan_id:str,reason:str,new_evidence:Sequence[str],context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); return self._revise(p,context,lambda x: x["provenance"].update({"evidence_refs":list(new_evidence),"replan_reason":reason}))
    def decompose(self,plan_id:str,level:str,context:Any)->list[dict[str,Any]]:
        p=self._load(plan_id,context); idx=LEVELS.index(p["plan_level"]); target=level
        if LEVELS.index(target)<=idx: raise PlanningValidationError("decomposition level must be below parent")
        children=[]
        for i,s in enumerate(p.get("steps",[])):
            child=self._new_plan(tenant_id=p["tenant_id"],level=target,goal_ref=p.get("goal_ref"),objective_ref=p.get("objective_ref"),requested_by=p["requested_by"],structure="atomic" if s.get("step_kind")=="terminal" else "sequence",steps=[s],dependencies=s.get("dependencies",[]),method=p["provenance"]["planner_method"],budget=s.get("budget"),seed=p["provenance"].get("seed"),parent_plan_id=p["plan_id"],owner_agent_id=p.get("owner_agent_id"))
            children.append(child)
        if children:
            p2=copy.deepcopy(p); p2["children_plan_ids"]=[c["plan_id"] for c in children]; self._revise(p,context,lambda x:x.update({"children_plan_ids":p2["children_plan_ids"]}))
            for c in children: self._persist(c,context)
        return children
    def instantiate(self,template_ref:str,parameters:Mapping[str,Any],context:Any)->dict[str,Any]:
        tenant=str(getattr(context,"tenant_id",self.config.default_tenant_id)); _require_auth(context,("planning.write",),tenant)
        parts=template_ref.split("@",1); path=TEMPLATE_DIR/parts[0]/(parts[1] if len(parts)>1 else "1.0.0")/"template.json"
        if not path.exists(): raise TemplateError(f"template not found: {template_ref}")
        doc=json.loads(path.read_text())
        signature=str(doc.get("signature","")); body={k:v for k,v in doc.items() if k!="signature"}
        try:
            Ed25519PublicKey.from_public_bytes(_unb64(TEMPLATE_PUBLIC_KEY_B64)).verify(_unb64(signature),canonical_bytes(body))
        except (InvalidSignature,ValueError,TypeError,KeyError):
            raise TemplateError("template signature verification failed")
        params=doc.get("parameters",{})
        for k,spec in params.items():
            if k not in parameters: raise TemplateError(f"missing parameter: {k}")
            if "min" in spec and float(parameters[k])<float(spec["min"]): raise TemplateError(f"parameter below range: {k}")
            if "max" in spec and float(parameters[k])>float(spec["max"]): raise TemplateError(f"parameter above range: {k}")
        body=copy.deepcopy(doc["plan"]); body=json.loads(json.dumps(body).replace("${"+"__never__"+"}",""))
        def repl(v):
            if isinstance(v,str) and v.startswith("${") and v.endswith("}"):
                return parameters.get(v[2:-1],v)
            if isinstance(v,dict): return {k:repl(x) for k,x in v.items()}
            if isinstance(v,list): return [repl(x) for x in v]
            return v
        body=repl(body); body["tenant_id"]=tenant; body["plan_id"]=_uuid(); body["plan_version"]=1; body["requested_by"]={"principal":getattr(getattr(context,"auth_context",None),"principal","planner"),"key_id":self.key_id}; body["requested_at"]=_utc(); body["state"]="draft"; body["provenance"]={**body.get("provenance",{}),"planner_method":"template","planner_version":ENGINE_VERSION,"template_ref":template_ref}; body=_sign(body,self.signer,self.key_id); self._persist(body,context); self._emit("PlanCreated",{"plan_id":body["plan_id"],"plan_version":1,"planner_method":"template","template_ref":template_ref},tenant_id=tenant,context=context); return body
    def compose(self,plan_refs:Sequence[str],composition_contract:Mapping[str,Any],context:Any)->dict[str,Any]:
        plans=[self._load(x,context) for x in plan_refs]
        if not plans: raise PlanningValidationError("compose requires at least one plan")
        tenant=plans[0]["tenant_id"]
        if any(p["tenant_id"]!=tenant for p in plans): raise PlanningAccessDenied("cannot compose across tenants")
        steps=[]
        for p in plans: steps.extend(copy.deepcopy(p.get("steps",[])))
        deps=[]
        for p in plans: deps.extend(copy.deepcopy(p.get("dependencies",[])))
        return self.plan({"id":str(composition_contract.get("objective_ref","composed")),"steps":steps},context,constraints={"dependencies":deps,"structure":composition_contract.get("structure","sequence"),"budget_ceiling":composition_contract.get("budget_ceiling")})
    def _revise(self,p:dict[str,Any],context:Any,mutator:Callable[[dict[str,Any]],None], *, allow_lifecycle:bool=False)->dict[str,Any]:
        allowed={"draft","simulated","verified"}
        if allow_lifecycle: allowed |= {"authorized","executing","completed","failed","cancelled","rolled_back"}
        if p["state"] not in allowed: raise PlanImmutable("immutable in current lifecycle state")
        n=copy.deepcopy(p); n["plan_version"]=int(p["plan_version"])+1; mutator(n); n["confidence"]["score"]=self._confidence(n); n=_sign(n,self.signer,self.key_id); self._persist(n,context); return n
    def refine(self,plan_id:str,patch:Mapping[str,Any],context:Any)->dict[str,Any]: return self._revise(self._load(plan_id,context),context,lambda x:x.update(copy.deepcopy(dict(patch))))
    def optimize(self,plan_id:str,objective:Mapping[str,Any],context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); target=dict(objective)
        def mutate(x):
            if "budget_ceiling" in target: x["budget_ceiling"]={k:min(float(x["budget_ceiling"].get(k,0)),float(target["budget_ceiling"].get(k,x["budget_ceiling"].get(k,0)))) for k in DEFAULT_BUDGET}
        return self._revise(p,context,mutate)
    def prune(self,plan_id:str,criteria:Mapping[str,Any],context:Any)->dict[str,Any]:
        return self._revise(self._load(plan_id,context),context,lambda x:x.update({"steps":[s for s in x.get("steps",[]) if not bool(criteria.get(str(s["step_id"]),False))]}))
    def substitute(self,plan_id:str,step_id:str,replacement_step:Mapping[str,Any],context:Any)->dict[str,Any]:
        def mutate(x):
            found=False
            for i,s in enumerate(x["steps"]):
                if s["step_id"]==step_id: x["steps"][i]=copy.deepcopy(dict(replacement_step)); x["steps"][i]["step_id"]=step_id; found=True
            if not found: raise PlanNotFound(step_id)
        return self._revise(self._load(plan_id,context),context,mutate)
    def bind(self,plan_id:str,bindings:Mapping[str,Any],context:Any)->dict[str,Any]:
        def repl(v):
            if isinstance(v,str) and v.startswith("$") and v[1:] in bindings: return bindings[v[1:]]
            if isinstance(v,dict): return {k:repl(x) for k,x in v.items()}
            if isinstance(v,list): return [repl(x) for x in v]
            return v
        return self._revise(self._load(plan_id,context),context,lambda x:x.update(repl(x)))
    def check_dependencies(self,plan_id:str,context:Any): return self.validate(plan_id,context)
    def check_temporal(self,plan_id:str,context:Any): return self.validate(plan_id,context)
    def check_resources(self,plan_id:str,context:Any): return self.validate(plan_id,context)
    def check_contracts(self,plan_id:str,context:Any)->Mapping[str,Any]:
        p=self._load(plan_id,context); errors=[]
        for s in p.get("steps",[]):
            if s.get("step_kind")=="skill_call" and self.skill_fabric is not None:
                ref=s.get("ref");
                try:
                    if hasattr(self.skill_fabric,"resolve"): self.skill_fabric.resolve(ref, context=context)
                except Exception as exc: errors.append(f"{s['step_id']}: {exc}")
        return {"valid":not errors,"errors":errors}
    def check_invariants(self,plan_id:str,context:Any)->Mapping[str,Any]:
        p=self._load(plan_id,context); return {"valid":True,"invariants":p.get("invariants",[])}
    def estimate_confidence(self,plan_id:str,context:Any)->Mapping[str,Any]: p=self._load(plan_id,context); return {"score":self._confidence(p),"calibrated":bool(p["confidence"].get("calibrated")),"method":p["confidence"].get("method")}
    def estimate_cost(self,plan_id:str,context:Any)->Mapping[str,float]: return self.validate(plan_id,context).estimated_cost
    def estimate_latency(self,plan_id:str,context:Any)->float: return self.validate(plan_id,context).estimated_latency_seconds
    def estimate_risk(self,plan_id:str,context:Any)->float: return self.validate(plan_id,context).risk_score
    def add_contingency(self,plan_id:str,contingency:Mapping[str,Any],context:Any)->dict[str,Any]: return self._revise(self._load(plan_id,context),context,lambda x:x["contingencies"].append(copy.deepcopy(dict(contingency))))
    def generate_contingencies(self,plan_id:str,context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); generated=[]
        existing={str(c.get("target_step_id")) for c in p.get("contingencies",[])}
        for s in p.get("steps",[]):
            if s["step_id"] not in existing:
                generated.append({"trigger":"step_failed","target_step_id":s["step_id"],"response":"abort_plan","response_ref":None,"max_attempts":None,"backoff":None,"provenance":{"source":"failure_modes+history"}})
        return self._revise(p,context,lambda x:x["contingencies"].extend(generated))
    def generate_alternatives(self,plan_id:str,context:Any)->list[dict[str,Any]]:
        p=self._load(plan_id,context); alt=self._revise(p,context,lambda x:x.update({"provenance":{**x["provenance"],"planner_method":"hybrid","alternative_of":p["plan_id"]}})); self._emit("PlanCreated",{"plan_id":alt["plan_id"],"plan_version":alt["plan_version"],"alternative_of":p["plan_id"]},tenant_id=p["tenant_id"],context=context); return [alt]
    def generate_rollback_plan(self,plan_id:str,context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); rollback=copy.deepcopy(p); rollback["plan_id"]=_uuid(); rollback["plan_version"]=1; rollback["plan_level"]="plan"; rollback["steps"]=list(reversed(copy.deepcopy(p.get("steps",[])))); rollback["structure"]="sequence"; rollback["rollback_plan_id"]=None; rollback["preconditions"]=copy.deepcopy(p.get("postconditions",[])); rollback["postconditions"]=copy.deepcopy(p.get("preconditions",[])); rollback["simulation_required"]=True; rollback["provenance"]={**p["provenance"],"rollback_for":p["plan_id"]}; rollback=_sign(rollback,self.signer,self.key_id); self._persist(rollback,context); self._revise(p,context,lambda x:x.update({"rollback_plan_id":rollback["plan_id"],"simulation_required":True})); return rollback
    def switch(self,plan_id:str,alternative_plan_id:str,reason:str,context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); alt=self._load(alternative_plan_id,context)
        if alt.get("objective_ref")!=p.get("objective_ref") and alt.get("goal_ref")!=p.get("goal_ref"):
            raise PlanningValidationError("alternative plan does not share objective/goal")
        self._emit("PlanSwitched",{"plan_id":p["plan_id"],"alternative_plan_id":alt["plan_id"],"reason":reason},tenant_id=p["tenant_id"],context=context,causation_id=getattr(context,"causation_id",None)); return alt

    def simulate(self,plan_id:str,simulation_config:Mapping[str,Any],context:Any)->str:
        p=self._load(plan_id,context); mandatory=p.get("simulation_required") or self._risk(p)>=self.config.risk_threshold
        if mandatory and not self.simulation_handoff: raise SimulationRequired("P2-K simulation handoff is unavailable")
        ref=self.simulation_handoff(p,dict(simulation_config)) if self.simulation_handoff else f"simulation://{p['plan_id']}/{p['plan_version']}"
        self._revise(p,context,lambda x:x.update({"state":"simulated","simulation_plan_ref":ref})); self._emit("PlanSimulated",{"plan_id":p["plan_id"],"simulation_plan_ref":ref},tenant_id=p["tenant_id"],context=context); return str(ref)
    def authorize(self,plan_id:str,authorization_token:str,context:Any)->dict[str,Any]:
        p=self._load(plan_id,context); _require_auth(context,("planning.authorize",),p["tenant_id"])
        if p.get("simulation_required") and not p.get("simulation_outcome_ref"): raise SimulationRequired("dangerous plan requires simulation outcome before authorization")
        if self.authorization_verifier is None or not self.authorization_verifier(authorization_token,"plan.execute"): self._emit("AuthorizationDenied",{"plan_id":p["plan_id"],"reason":"token_verification_failed"},tenant_id=p["tenant_id"],context=context,priority="high"); raise AuthorizationDenied("Security Authority authorization token rejected")
        return self._revise(p,context,lambda x:x.update({"state":"authorized","authorized_by":{"principal":getattr(getattr(context,"auth_context",None),"principal","unknown"),"key_id":self.key_id},"authorization_ref":_sha({"plan_id":p["plan_id"],"token":hashlib.sha256(authorization_token.encode()).hexdigest()})}))
    def execute(self,plan_id:str,execution_context:Any)->str:
        p=self._load(plan_id,execution_context); 
        if p.get("state")!="authorized": raise AuthorizationDenied("plan must be authorized before execution")
        if self.execution_handoff is None: raise PlanningError("P2-E execution handoff is unavailable")
        self._revise(p,execution_context,lambda x:x.update({"state":"executing","started_at":_utc()}),allow_lifecycle=True)
        ref=self.execution_handoff(p,execution_context); self._emit("PlanExecuting",{"plan_id":p["plan_id"],"execution_ref":ref},tenant_id=p["tenant_id"],context=execution_context); return str(ref)
    def cancel(self,execution_ref:str,reason:str,context:Any)->None:
        _require_auth(context,("planning.write",),getattr(context,"tenant_id",self.config.default_tenant_id)); self._emit("PlanCancelled",{"execution_ref":execution_ref,"reason":reason},tenant_id=getattr(context,"tenant_id",self.config.default_tenant_id),context=context)
    def resume(self,execution_ref:str,checkpoint_ref:str,context:Any)->None:
        _require_auth(context,("planning.write",),getattr(context,"tenant_id",self.config.default_tenant_id)); return None
    def verify(self,plan_id:str,execution_ref:str,context:Any)->str:
        p=self._load(plan_id,context); ref=f"verification://{p['plan_id']}/{execution_ref}"
        if p["state"] in {"executing","authorized"}: self._revise(p,context,lambda x:x.update({"state":"verified"}),allow_lifecycle=True)
        self._emit("VerificationCheckpoint",{"plan_id":p["plan_id"],"execution_ref":execution_ref,"verification_ref":ref},tenant_id=p["tenant_id"],context=context)
        return ref
    def record_outcome(self,plan_id:str,outcome:Mapping[str,Any],context:Any)->PlanOutcome:
        p=self._load(plan_id,context); result=str(outcome["result"]); actual=float(outcome.get("confidence_actual",1.0 if result=="completed" else 0.0)); predicted=float(p["confidence"]["score"]); delta=actual-predicted; oid=_uuid()
        body={"outcome_id":oid,"plan_id":p["plan_id"],"execution_ref":str(outcome["execution_ref"]),"result":result,"success":bool(outcome.get("success",result=="completed")),"actual_metrics":dict(outcome.get("actual_metrics",{})),"confidence_predicted":predicted,"confidence_actual":actual,"calibration_delta":delta,"verification_refs":list(outcome.get("verification_refs",[])),"failure_ids":list(outcome.get("failure_ids",[])),"memory_refs":list(outcome.get("memory_refs",[])),"recorded_at":_utc()}
        signed=_sign(body,self.signer,self.key_id)
        if self.memory is not None and hasattr(self.memory,"write"):
            try:
                mem_item=outcome.get("memory_item")
                auth=getattr(context,"auth_context",context)
                if mem_item is not None: self.memory.write(mem_item,auth)
            except Exception as exc:
                raise PlanningError(f"task-memory outcome write failed: {type(exc).__name__}: {exc}") from exc
        self._emit("OutcomeRecorded",signed,tenant_id=p["tenant_id"],context=context)
        state={"completed":"completed","failed":"failed","cancelled":"cancelled","rolled_back":"rolled_back","partial":"failed"}[result]
        self._revise(p,context,lambda x:x.update({"state":state,"finished_at":_utc()}),allow_lifecycle=True)
        terminal_event={"completed":"PlanCompleted","failed":"PlanFailed","cancelled":"PlanCancelled","rolled_back":"PlanRolledBack","partial":"PlanFailed"}[result]
        self._emit(terminal_event,{"plan_id":p["plan_id"],"execution_ref":body["execution_ref"],"outcome_id":oid},tenant_id=p["tenant_id"],context=context)
        return PlanOutcome(oid,p["plan_id"],body["execution_ref"],result,body["success"],body["actual_metrics"],predicted,actual,delta,tuple(body["verification_refs"]),tuple(body["failure_ids"]),tuple(body["memory_refs"]),body["recorded_at"],signed["signature"])
    def diff(self,plan_id:str,version_a:int,version_b:int,context:Any)->dict[str,Any]:
        a=self._load(plan_id,context,version=version_a); b=self._load(plan_id,context,version=version_b); keys=sorted(set(a)|set(b)); return {k:{"a":a.get(k),"b":b.get(k)} for k in keys if a.get(k)!=b.get(k)}
    def close(self)->None:
        if getattr(self,"store",None) is not None:
            self.store.close()
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

# Public aliases matching the requested conceptual API.
PlanningEngine2 = PlanningEngine
PlanEngine = PlanningEngine

def validate_plan(plan: Mapping[str,Any], public_key: bytes | Ed25519PublicKey | None = None) -> None:
    SchemaValidator(max_errors=256).validate_or_raise(dict(plan), json.loads((SCHEMA_DIR/"plan_v1.schema.json").read_text()))
    if public_key is not None and not verify_plan_signature(plan,public_key): raise PlanningSignatureError("invalid plan signature")

"""ReAct reasoning loop."""
from __future__ import annotations
import logging
from core.tool_registry import ToolRegistry
from core.model_router import ModelRouter

logger = logging.getLogger("jarvis.react")


class ReActEngine:
    def __init__(self, router: ModelRouter, registry: ToolRegistry, max_steps: int = 5):
        self.router = router
        self.registry = registry
        self.max_steps = max_steps

    def run(self, query: str) -> str:
        context = f"Question: {query}\n"
        for step in range(self.max_steps):
            prompt = context + "\nThink step by step. If you need a tool, respond with JSON: {\"tool\": \"name\", \"args\": {}}. Otherwise answer directly."
            response = self.router.generate(prompt)
            text = response.text if hasattr(response, "text") else str(response)
            context += f"\nStep {step+1}: {text}"
            if "tool" not in text.lower() or "{" not in text:
                break
            # Simple heuristic: if it looks like a tool call, try to parse
            try:
                import json, re
                match = re.search(r'\{[^}]+\}', text)
                if match:
                    call = json.loads(match.group())
                    tool_name = call.get("tool")
                    args = call.get("args", {})
                    if tool_name:
                        result = self.registry.execute(tool_name, args)
                        context += f"\nTool result: {result}"
            except Exception:
                break
        return context



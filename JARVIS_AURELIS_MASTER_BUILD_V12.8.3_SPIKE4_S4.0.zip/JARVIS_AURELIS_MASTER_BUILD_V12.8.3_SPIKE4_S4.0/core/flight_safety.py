"""Deterministic navigation and flight-safety calculations.

This module computes routes and safety constraints only. It does not target
people or objects and contains no autonomous engagement capability.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True, slots=True)
class Waypoint:
    latitude: float
    longitude: float
    altitude_m: float


@dataclass(frozen=True, slots=True)
class FlightConstraints:
    geofence_latitude: float
    geofence_longitude: float
    geofence_radius_m: float
    min_altitude_m: float = 1.0
    max_altitude_m: float = 120.0
    battery_reserve_fraction: float = 0.20
    cruise_speed_mps: float = 10.0
    energy_per_meter: float = 0.00005

    def validate(self) -> None:
        if not -90.0 <= self.geofence_latitude <= 90.0 or not -180.0 <= self.geofence_longitude <= 180.0:
            raise ValueError("invalid geofence center")
        if not 0.0 < self.geofence_radius_m <= 1_000_000.0:
            raise ValueError("invalid geofence radius")
        if not 0.0 < self.min_altitude_m <= self.max_altitude_m:
            raise ValueError("invalid altitude limits")
        if not 0.0 <= self.battery_reserve_fraction < 1.0 or self.cruise_speed_mps <= 0.0 or self.energy_per_meter <= 0.0:
            raise ValueError("invalid flight constraints")


@dataclass(frozen=True, slots=True)
class FlightPlan:
    waypoints: tuple[Waypoint, ...]
    distance_m: float
    eta_seconds: float
    estimated_energy: float
    return_to_home_distance_m: float
    safe: bool
    reasons: tuple[str, ...]


class FlightSafetyPlanner:
    """Great-circle distance and policy validation for safe navigation."""

    EARTH_RADIUS_M = 6_371_000.0

    def __init__(self, constraints: FlightConstraints) -> None:
        constraints.validate()
        self.constraints = constraints

    def plan(self, waypoints: Sequence[Waypoint], *, current: Waypoint | None = None, battery_fraction: float = 1.0) -> FlightPlan:
        points = tuple(waypoints)
        if not points or len(points) > 256:
            raise ValueError("flight plan requires 1..256 waypoints")
        if not 0.0 <= battery_fraction <= 1.0:
            raise ValueError("battery fraction must be in [0,1]")
        origin = current or points[0]
        reasons: list[str] = []
        distance = 0.0
        cursor = origin
        for point in points:
            self._validate_point(point, reasons)
            distance += self.distance_m(cursor.latitude, cursor.longitude, point.latitude, point.longitude)
            cursor = point
        rth = self.distance_m(cursor.latitude, cursor.longitude, origin.latitude, origin.longitude)
        total_distance = distance + rth
        energy = total_distance * self.constraints.energy_per_meter
        if battery_fraction - energy < self.constraints.battery_reserve_fraction:
            reasons.append("battery reserve would be breached after return-to-home")
        eta = distance / self.constraints.cruise_speed_mps
        return FlightPlan(points, distance, eta, energy, rth, not reasons, tuple(reasons))

    def _validate_point(self, point: Waypoint, reasons: list[str]) -> None:
        if not -90.0 <= point.latitude <= 90.0 or not -180.0 <= point.longitude <= 180.0:
            reasons.append("waypoint coordinates are invalid")
            return
        if not self.constraints.min_altitude_m <= point.altitude_m <= self.constraints.max_altitude_m:
            reasons.append("waypoint altitude violates policy")
        boundary = self.distance_m(self.constraints.geofence_latitude, self.constraints.geofence_longitude, point.latitude, point.longitude)
        if boundary > self.constraints.geofence_radius_m:
            reasons.append("waypoint lies outside geofence")

    @classmethod
    def distance_m(cls, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Return numerically stable haversine distance in meters."""
        phi1, phi2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
        return 2.0 * cls.EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(a)))

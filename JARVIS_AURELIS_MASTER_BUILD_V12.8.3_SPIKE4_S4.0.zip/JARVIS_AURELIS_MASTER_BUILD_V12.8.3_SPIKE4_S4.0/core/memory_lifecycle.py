"""Provenance-aware memory lifecycle, compaction, snapshots and retention policy."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import tempfile
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger("jarvis.memory_lifecycle")


class MemoryKind(str, Enum):
    """Canonical cognitive memory classes."""

    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    PREFERENCE = "preference"


@dataclass(frozen=True, slots=True)
class MemoryRecord:
    """Portable memory record with provenance and retention metadata."""

    memory_id: str
    kind: MemoryKind
    content: str
    source: str
    created_at: float
    updated_at: float
    importance: float = 0.5
    confidence: float = 1.0
    expires_at: float | None = None
    metadata: dict[str, Any] | None = None


class MemoryLifecycleManager:
    """Keep bounded memory state independent from any specific vector/database engine."""

    def __init__(self, max_records: int = 10_000, clock: Any = time.time, journal_path: str | None = None) -> None:
        self.max_records = max(1, int(max_records))
        self._clock = clock
        self._records: dict[str, MemoryRecord] = {}
        self.journal_path = Path(journal_path) if journal_path else None
        if self.journal_path is not None:
            self.journal_path.parent.mkdir(parents=True, exist_ok=True)
            self._load()

    def remember(self, record: MemoryRecord) -> None:
        """Insert/update one validated memory record."""
        if not record.memory_id.strip() or not record.content.strip() or not record.source.strip():
            raise ValueError("memory_id, content and source are required")
        if not 0.0 <= record.importance <= 1.0 or not 0.0 <= record.confidence <= 1.0:
            raise ValueError("importance and confidence must be between 0 and 1")
        self._records[record.memory_id] = record
        self._compact()
        self._persist()

    def create(self, memory_id: str, kind: MemoryKind, content: str, source: str, *, importance: float = 0.5, confidence: float = 1.0, ttl_seconds: float | None = None, metadata: dict[str, Any] | None = None) -> MemoryRecord:
        """Create and persist a memory record."""
        now = float(self._clock())
        ttl = None if ttl_seconds is None else max(0.0, float(ttl_seconds))
        record = MemoryRecord(str(memory_id), kind, str(content), str(source), now, now, max(0.0, min(1.0, importance)), max(0.0, min(1.0, confidence)), now + ttl if ttl is not None else None, dict(metadata or {}))
        self.remember(record)
        return record

    def retrieve(self, kind: MemoryKind | None = None, limit: int = 50) -> list[MemoryRecord]:
        """Return highest-value currently retained records."""
        self.prune_expired()
        rows = [record for record in self._records.values() if kind is None or record.kind == kind]
        rows.sort(key=lambda record: (-record.importance * record.confidence, -record.updated_at, record.memory_id))
        return rows[: max(1, min(int(limit), 1000))]

    def prune_expired(self) -> int:
        """Delete records whose explicit TTL has elapsed."""
        now = float(self._clock())
        expired = [memory_id for memory_id, record in self._records.items() if record.expires_at is not None and record.expires_at <= now]
        for memory_id in expired:
            self._records.pop(memory_id, None)
        if expired:
            self._persist()
        return len(expired)

    def consolidate(self, max_records: int | None = None) -> dict[str, int]:
        """Compact memory deterministically while preserving the highest-value records."""
        before = len(self._records)
        target = self.max_records if max_records is None else max(1, min(int(max_records), self.max_records))
        self.prune_expired()
        rows = sorted(self._records.values(), key=lambda record: (-record.importance * record.confidence, -record.updated_at, record.memory_id))
        self._records = {record.memory_id: record for record in rows[:target]}
        self._persist()
        return {"before": before, "after": len(self._records), "removed": before - len(self._records)}

    def retention_metrics(self) -> dict[str, float | int]:
        """Return measurable memory quality and age metrics."""
        self.prune_expired()
        rows = list(self._records.values())
        now = float(self._clock())
        return {
            "count": len(rows),
            "capacity": self.max_records,
            "utilization": len(rows) / self.max_records,
            "mean_importance": sum(item.importance for item in rows) / len(rows) if rows else 0.0,
            "mean_confidence": sum(item.confidence for item in rows) / len(rows) if rows else 0.0,
            "mean_age_seconds": sum(max(0.0, now - item.updated_at) for item in rows) / len(rows) if rows else 0.0,
        }

    def snapshot(self) -> dict[str, Any]:
        """Create an integrity-addressed memory snapshot."""
        records = [self._encode(record) for record in sorted(self._records.values(), key=lambda item: item.memory_id)]
        raw = json.dumps(records, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
        return {"schema": 2, "count": len(records), "records": records, "sha256": hashlib.sha256(raw).hexdigest()}

    def restore(self, snapshot: dict[str, Any]) -> int:
        """Verify and restore a snapshot atomically in memory."""
        records = snapshot.get("records")
        if not isinstance(records, list):
            raise ValueError("invalid memory snapshot")
        raw = json.dumps(records, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
        expected = str(snapshot.get("sha256", ""))
        if not expected or not hmac.compare_digest(hashlib.sha256(raw).hexdigest(), expected):
            raise ValueError("memory snapshot integrity check failed")
        restored = {item.memory_id: item for item in (self._decode(row) for row in records)}
        if len(restored) > self.max_records:
            raise ValueError("memory snapshot exceeds configured capacity")
        self._records = restored
        self._persist()
        return len(restored)

    def _compact(self) -> None:
        if len(self._records) <= self.max_records:
            return
        ordered = sorted(self._records.values(), key=lambda record: (-record.importance * record.confidence, -record.updated_at, record.memory_id))
        self._records = {record.memory_id: record for record in ordered[: self.max_records]}

    @staticmethod
    def _encode(record: MemoryRecord) -> dict[str, Any]:
        return {"memory_id": record.memory_id, "kind": record.kind.value, "content": record.content, "source": record.source, "created_at": record.created_at, "updated_at": record.updated_at, "importance": record.importance, "confidence": record.confidence, "expires_at": record.expires_at, "metadata": record.metadata or {}}

    @staticmethod
    def _decode(row: Any) -> MemoryRecord:
        if not isinstance(row, dict):
            raise ValueError("invalid memory record")
        return MemoryRecord(str(row["memory_id"]), MemoryKind(str(row["kind"])), str(row["content"]), str(row["source"]), float(row["created_at"]), float(row["updated_at"]), float(row.get("importance", 0.5)), float(row.get("confidence", 1.0)), None if row.get("expires_at") is None else float(row["expires_at"]), dict(row.get("metadata") or {}))

    def _load(self) -> None:
        if self.journal_path is None or not self.journal_path.is_file():
            return
        try:
            raw = json.loads(self.journal_path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("memory journal root must be an object")
            records = raw.get("records")
            expected = str(raw.get("sha256", ""))
            canonical = json.dumps(records, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
            if not isinstance(records, list) or not expected or not hmac.compare_digest(hashlib.sha256(canonical).hexdigest(), expected):
                raise ValueError("invalid or tampered memory journal")
            restored = {item.memory_id: item for item in (self._decode(row) for row in records)}
            if len(restored) > self.max_records:
                raise ValueError("memory journal exceeds configured capacity")
            self._records = restored
        except Exception as exc:
            logger.warning("memory_journal_load_failed", extra={"error": str(exc)})
            self._records.clear()

    def _persist(self) -> None:
        if self.journal_path is None:
            return
        payload = json.dumps(self.snapshot(), ensure_ascii=False, indent=2, default=str)
        temporary: str | None = None
        try:
            fd, temporary = tempfile.mkstemp(prefix=f".{self.journal_path.name}.", dir=str(self.journal_path.parent), text=True)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.journal_path)
        except OSError as exc:
            logger.warning("memory_journal_persist_failed", extra={"error": str(exc)})
            if temporary:
                try:
                    os.unlink(temporary)
                except OSError as cleanup_exc:
                    logger.debug("memory_journal_temp_cleanup_failed", exc_info=cleanup_exc)



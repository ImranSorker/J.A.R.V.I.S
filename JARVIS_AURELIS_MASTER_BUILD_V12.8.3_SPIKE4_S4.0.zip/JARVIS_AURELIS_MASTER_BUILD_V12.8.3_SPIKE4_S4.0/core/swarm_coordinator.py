"""Human-commanded multi-robot coordination with safety interlocks."""
from __future__ import annotations

import math
import threading
import time
from dataclasses import dataclass
from typing import Callable, Mapping, Sequence

from core.flight_safety import Waypoint


@dataclass(frozen=True, slots=True)
class RobotNode:
    robot_id: str
    kind: str
    position: Waypoint
    battery_fraction: float
    online: bool = True
    capabilities: tuple[str, ...] = ()

    def validate(self) -> None:
        if not self.robot_id.strip() or not self.kind.strip():
            raise ValueError("robot identity is required")
        if not 0.0 <= self.battery_fraction <= 1.0:
            raise ValueError("robot battery must be in [0,1]")


@dataclass(frozen=True, slots=True)
class SwarmCommand:
    command_id: str
    operator_id: str
    objective: str
    waypoints: tuple[Waypoint, ...]
    capability: str
    created_at: float
    human_authorized: bool = False


@dataclass(frozen=True, slots=True)
class SwarmAssignment:
    robot_id: str
    waypoint: Waypoint
    score: float


@dataclass(frozen=True, slots=True)
class SwarmPlan:
    command_id: str
    assignments: tuple[SwarmAssignment, ...]
    conflicts: tuple[str, ...]
    safe_to_execute: bool
    simulation_only: bool = True


class HumanCommandSwarmCoordinator:
    """Deterministic task allocation; no autonomous engagement or targeting."""

    def __init__(self, *, max_nodes: int = 256) -> None:
        self._max_nodes = max(1, min(int(max_nodes), 10_000))
        self._nodes: dict[str, RobotNode] = {}
        self._stopped = False
        self._lock = threading.RLock()

    def register(self, node: RobotNode) -> None:
        node.validate()
        with self._lock:
            if node.robot_id not in self._nodes and len(self._nodes) >= self._max_nodes:
                raise RuntimeError("swarm node capacity reached")
            self._nodes[node.robot_id] = node

    def emergency_stop(self, operator_id: str) -> None:
        if not str(operator_id).strip():
            raise ValueError("operator identity required")
        with self._lock:
            self._stopped = True

    def clear_emergency_stop(self, operator_id: str, *, explicit_reauthorization: bool) -> None:
        if not str(operator_id).strip() or not explicit_reauthorization:
            raise PermissionError("explicit reauthorization is required")
        with self._lock:
            self._stopped = False

    def plan(self, command: SwarmCommand) -> SwarmPlan:
        if not command.human_authorized:
            raise PermissionError("human authorization is required")
        if not command.objective.strip() or not command.capability.strip() or not command.waypoints:
            raise ValueError("swarm command is incomplete")
        with self._lock:
            nodes = tuple(node for node in self._nodes.values() if node.online and command.capability in node.capabilities and node.battery_fraction > 0.2)
            stopped = self._stopped
        assignments: list[SwarmAssignment] = []
        used: set[str] = set()
        conflicts: list[str] = []
        for waypoint in command.waypoints[: len(nodes)]:
            candidates = [node for node in nodes if node.robot_id not in used]
            if not candidates:
                conflicts.append("insufficient eligible nodes")
                break
            node = min(candidates, key=lambda item: (self._distance(item.position, waypoint) / max(item.battery_fraction, 0.05), item.robot_id))
            score = item_score = self._distance(node.position, waypoint) / max(node.battery_fraction, 0.05)
            assignments.append(SwarmAssignment(node.robot_id, waypoint, item_score))
            used.add(node.robot_id)
        for left_index, left in enumerate(assignments):
            for right in assignments[left_index + 1 :]:
                if self._distance(left.waypoint, right.waypoint) < 5.0:
                    conflicts.append(f"waypoint separation below 5m: {left.robot_id}/{right.robot_id}")
        safe = bool(assignments) and not conflicts and not stopped
        return SwarmPlan(command.command_id, tuple(assignments), tuple(sorted(set(conflicts))), safe, simulation_only=True)

    def execute_simulation(self, plan: SwarmPlan, *, step: Callable[[SwarmAssignment], Mapping[str, object]]) -> tuple[Mapping[str, object], ...]:
        """Run a plan only through an injected simulator callback."""
        if not plan.simulation_only:
            raise PermissionError("physical execution is not exposed by the core coordinator")
        if not plan.safe_to_execute:
            raise ValueError("unsafe swarm plan cannot execute")
        return tuple(dict(step(assignment)) for assignment in plan.assignments)

    @staticmethod
    def _distance(left: Waypoint, right: Waypoint) -> float:
        lat_scale = 111_320.0
        lon_scale = 111_320.0 * math.cos(math.radians((left.latitude + right.latitude) / 2.0))
        return math.hypot((left.latitude - right.latitude) * lat_scale, (left.longitude - right.longitude) * lon_scale)

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            return {"nodes": len(self._nodes), "online": sum(1 for node in self._nodes.values() if node.online), "emergency_stop": self._stopped}

"""Canonical AION executive façade for J.A.R.V.I.S.

AION owns goal admission and executive history; the existing
``AutonomousExecutive`` owns mission execution. Learning is fed only from
verified terminal outcomes, never from goal admission.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Any, Mapping, Protocol

logger = logging.getLogger("jarvis.aion")


class AIONError(RuntimeError):
    """Base AION execution error."""


class AIONAdmissionDenied(AIONError):
    """Raised when a goal cannot be admitted."""


class OutcomeSink(Protocol):
    def record(self, *, goal_id: str, success: bool, summary: str, evidence: Mapping[str, Any]) -> None:
        ...


@dataclass(frozen=True, slots=True)
class StrategyRecord:
    goal_id: str
    strategy: str
    rationale: str
    accepted: bool


class PlannerAdapter(Protocol):
    def plan(self, objective: str) -> list[str]:
        ...

    def build(self, objective: str, *, context: Mapping[str, Any] | None = None) -> Any:
        ...


class _DefaultPlannerAdapter:
    def __init__(self, planner: Any | None) -> None:
        self._planner = planner

    def plan(self, objective: str) -> list[str]:
        if self._planner is not None:
            try:
                result = self._planner.plan(objective)
                if isinstance(result, (list, tuple)):
                    return [str(item) for item in result][:32]
            except Exception:
                logger.debug("aion_planner_failed", exc_info=True)
        return ["analyze", "execute", "verify"]


class AIONExecutive:
    """Single executive façade over the canonical AutonomousExecutive."""

    def __init__(
        self,
        *,
        executive: Any,
        autonomy_fabric: Any | None = None,
        learning_sink: OutcomeSink | None = None,
        planner: PlannerAdapter | None = None,
        max_active_goals: int = 256,
    ) -> None:
        if executive is None:
            raise AIONError("canonical executive is required")
        self._executive = executive
        self._fabric = autonomy_fabric
        self._learning = learning_sink
        self._planner = planner or _DefaultPlannerAdapter(None)
        self._max_active = max(1, min(int(max_active_goals), 10_000))
        self._lock = threading.RLock()
        self._history: list[StrategyRecord] = []

    def set_learning_sink(self, sink: OutcomeSink | None) -> None:
        """Attach the learning sink after the evolution engine is constructed."""
        with self._lock:
            self._learning = sink

    def submit_goal(
        self,
        objective: str,
        *,
        priority: int = 5,
        owner: str = "jarvis",
        metadata: Mapping[str, Any] | None = None,
    ) -> str:
        text = str(objective).strip()
        if not text:
            raise AIONAdmissionDenied("objective is required")
        with self._lock:
            active = self.active_goal_count()
            if active >= self._max_active:
                raise AIONAdmissionDenied("AION active-goal capacity reached")
        try:
            structured = self._planner.build(text)
            plan = structured.to_dict() if hasattr(structured, "to_dict") else {"steps": structured}
        except (AttributeError, TypeError):
            plan = {"steps": self._planner.plan(text)}
        if not isinstance(plan, Mapping) or not plan.get("steps"):
            raise AIONAdmissionDenied("planner produced no executable plan")
        payload = dict(metadata or {})
        payload.setdefault("aion", True)
        payload.setdefault("plan", plan)
        payload.setdefault("plan_strategy", str(plan.get("strategy", "adapter")))
        try:
            goal_id = self._executive.submit_goal(
                text, priority=int(priority), owner=str(owner), metadata=payload
            )
        except Exception as exc:
            raise AIONAdmissionDenied(str(exc)) from exc
        with self._lock:
            self._history.append(StrategyRecord(str(goal_id), "canonical-executive", "admitted", True))
            if len(self._history) > 10_000:
                del self._history[:-10_000]
        return str(goal_id)

    def on_outcome(self, *, goal_id: str, status: str, evidence: Mapping[str, Any] | None = None) -> None:
        """Consume a terminal executive outcome and optionally write learning evidence."""
        normalized = str(status).strip().lower()
        if normalized not in {"completed", "failed"}:
            return
        success = normalized == "completed"
        summary = "goal completed and execution path reached a terminal state" if success else "goal execution failed"
        sink = self._learning
        if sink is not None:
            try:
                sink.record(goal_id=str(goal_id), success=success, summary=summary, evidence=dict(evidence or {}))
            except Exception:
                logger.exception("aion_learning_sink_failed", extra={"goal_id": goal_id})

    def active_goal_count(self) -> int:
        """Return the authoritative number of queued/running goals."""
        counter = getattr(self._executive, "active_goal_count", None)
        if callable(counter):
            return int(counter())
        return sum(1 for goal in self._executive.list_goals(limit=10_000)
                   if goal.get("status") in {"queued", "running"})

    def list_goals(self, limit: int = 100) -> list[dict[str, Any]]:
        return self._executive.list_goals(limit=limit)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {"goals": self._executive.snapshot(), "strategy_history": len(self._history), "learning_sink": self._learning is not None}

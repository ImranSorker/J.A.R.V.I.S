"""Backward-compatible AION3 façade backed by the canonical AION executive."""
from __future__ import annotations

from typing import Any


class AION3:
    """Compatibility adapter; it never owns a second goal store."""

    def __init__(self, store=None, executive=None):
        self.store = store
        self._executive = executive

    def bind(self, executive: Any) -> None:
        if executive is None:
            raise ValueError("canonical executive is required")
        self._executive = executive

    def submit_goal(self, objective: str, **kwargs: Any) -> str:
        if self._executive is None:
            raise RuntimeError("canonical AION executive is not bound")
        return str(self._executive.submit_goal(objective, **kwargs))

    def suggest_goal(self) -> str | None:
        if self._executive is None:
            return None
        for goal in self._executive.list_goals(limit=100):
            if goal.get("status") in {"queued", "running"}:
                return str(goal.get("description"))
        return None

    def get_stats(self) -> dict[str, Any]:
        if self._executive is None:
            return {"goals": 0, "active_goals": 0, "bound": False, "store": self.store is not None}
        snapshot = self._executive.snapshot()
        active_counter = getattr(self._executive, "active_goal_count", None)
        active = int(active_counter()) if callable(active_counter) else int(snapshot.get("queued", 0)) + int(snapshot.get("running", 0))
        return {
            "goals": int(snapshot.get("queued", 0)) + int(snapshot.get("running", 0)) + int(snapshot.get("completed", 0)) + int(snapshot.get("failed", 0)),
            "active_goals": active,
            "bound": True,
            "store": self.store is not None,
        }

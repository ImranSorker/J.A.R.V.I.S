"""P2-P HTTPS adapter."""
from core.tool_fabric.impl import HttpAdapter
__all__ = ["HttpAdapter"]

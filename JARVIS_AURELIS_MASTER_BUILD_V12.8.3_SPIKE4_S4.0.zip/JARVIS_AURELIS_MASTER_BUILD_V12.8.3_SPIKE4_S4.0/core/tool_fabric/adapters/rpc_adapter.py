"""P2-P JSON-RPC adapter."""
from core.tool_fabric.impl import RpcAdapter
__all__ = ["RpcAdapter"]

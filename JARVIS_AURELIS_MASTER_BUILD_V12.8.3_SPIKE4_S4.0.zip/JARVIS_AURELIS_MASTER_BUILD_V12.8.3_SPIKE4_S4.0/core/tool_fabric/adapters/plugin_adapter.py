"""P2-P plugin adapter."""
from core.tool_fabric.impl import PluginAdapter
__all__ = ["PluginAdapter"]

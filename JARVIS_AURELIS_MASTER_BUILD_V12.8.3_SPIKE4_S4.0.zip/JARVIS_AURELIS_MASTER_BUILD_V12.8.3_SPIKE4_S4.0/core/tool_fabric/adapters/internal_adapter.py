"""P2-P internal adapter."""
from core.tool_fabric.impl import InternalAdapter
__all__ = ["InternalAdapter"]

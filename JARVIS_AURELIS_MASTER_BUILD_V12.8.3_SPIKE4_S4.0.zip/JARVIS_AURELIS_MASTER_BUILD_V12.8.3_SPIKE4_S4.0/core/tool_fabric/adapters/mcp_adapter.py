"""P2-P MCP adapter."""
from core.tool_fabric.impl import McpAdapter
__all__ = ["McpAdapter"]

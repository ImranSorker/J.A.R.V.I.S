"""P2-P argv-only CLI adapter."""
from core.tool_fabric.impl import CliAdapter
__all__ = ["CliAdapter"]

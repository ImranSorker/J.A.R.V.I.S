"""P2-P function adapter."""
from core.tool_fabric.impl import FunctionAdapter
__all__ = ["FunctionAdapter"]

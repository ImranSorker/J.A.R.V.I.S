"""P2-P device adapter."""
from core.tool_fabric.impl import DeviceAdapter
__all__ = ["DeviceAdapter"]

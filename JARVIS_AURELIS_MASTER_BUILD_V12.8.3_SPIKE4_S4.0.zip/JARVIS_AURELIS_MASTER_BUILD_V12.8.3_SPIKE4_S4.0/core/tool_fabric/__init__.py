"""P2-P Tool Fabric 2.0 package."""
from .impl import *  # noqa: F401,F403
from .impl import (
    ToolFabric, ToolConfig, ToolRegistry, DiscoveryRequest, DiscoveryResult,
    SelectionDecision, InvocationResult, ToolHealth, Candidate, sign_manifest, verify_manifest,
    sign_adhoc_authorization, FunctionAdapter, HttpAdapter, CliAdapter, RpcAdapter,
    McpAdapter, PluginAdapter, DeviceAdapter, InternalAdapter,
    ToolFabricError, ToolValidationError, ToolSignatureError, ToolIntegrityError,
    ToolAccessDenied, ToolNotFound, ToolRevoked, ToolRetired, NoEligibleTool,
    SchemaViolation, ToolPolicyDenied, ToolTimeout, RateLimited, ConcurrencyLimited,
    DeterminismUnavailable, IdempotencyViolation, AdapterError, HealthBudgetExceeded,
)
__all__ = [
    "ToolFabric","ToolConfig","ToolRegistry","DiscoveryRequest","DiscoveryResult","SelectionDecision",
    "InvocationResult","ToolHealth","Candidate","sign_manifest","verify_manifest","sign_adhoc_authorization",
    "FunctionAdapter","HttpAdapter","CliAdapter","RpcAdapter","McpAdapter","PluginAdapter","DeviceAdapter","InternalAdapter",
    "ToolFabricError","ToolValidationError","ToolSignatureError","ToolIntegrityError","ToolAccessDenied","ToolNotFound",
    "ToolRevoked","ToolRetired","NoEligibleTool","SchemaViolation","ToolPolicyDenied","ToolTimeout","RateLimited",
    "ConcurrencyLimited","DeterminismUnavailable","IdempotencyViolation","AdapterError","HealthBudgetExceeded",
]

# Keep the eight adapter modules reachable in repository dependency analysis.
from .adapters import (  # noqa: E402,F401
    FunctionAdapter as FunctionAdapterModule,
    HttpAdapter as HttpAdapterModule,
    CliAdapter as CliAdapterModule,
    RpcAdapter as RpcAdapterModule,
    McpAdapter as McpAdapterModule,
    PluginAdapter as PluginAdapterModule,
    DeviceAdapter as DeviceAdapterModule,
    InternalAdapter as InternalAdapterModule,
)

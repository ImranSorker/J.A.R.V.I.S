"""P2-P Tool Fabric 2.0.

Canonical signed tool registry, deterministic capability discovery/selection,
scoped invocation, adapter isolation, health/lifecycle management,
determinism/idempotency enforcement, and replayable Tool events.

All actual tool execution is reachable only through :class:`ToolFabric`.
The module deliberately delegates authorization/execution context ownership to
P2-E and Security Authority; it never expands allowlists or self-modifies
agents, skills, plans, or policies.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import inspect
import json
import math
import os
import re
import shlex
import signal
import sqlite3
import ssl
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_harness import ExecutionContext
from core.event_fabric import AuthContext, EventEnvelope, EventFabric, EventLineage, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

ROOT = Path(__file__).resolve().parent.parent
SCHEMA_DIR = ROOT / "schemas"

INVOCATION_KINDS = ("function", "http", "cli", "rpc", "mcp", "plugin", "device", "internal", "composite")
EFFECT_CLASSES = ("read_only", "read_write", "destructive", "external", "device", "financial", "communication", "identity")
REVERSIBILITIES = ("reversible", "partially_reversible", "irreversible", "unknown")
TRUSTS = ("verified", "pinned", "experimental", "untrusted")
COST_CLASSES = ("free", "cheap", "moderate", "expensive", "metered")
FAILURE_CLASSES = ("timeout", "rate_limited", "schema_violation", "policy_denied", "auth_failed", "unavailable", "degraded", "partial", "corrupt_response", "side_effect_partial", "unknown")
TOOL_STATES = ("registered", "active", "deprecated", "revoked", "retired")
TOOL_EVENTS = (
    "Registered", "Activated", "Deprecated", "Retired", "Revoked", "RevocationPropagated",
    "DiscoveryRequested", "DiscoveryCompleted", "DiscoveryDenied", "Selected", "SelectionFailed",
    "Invoked", "InvocationCompleted", "InvocationFailed", "InvocationDenied", "DeterminismDeviation",
    "HealthChanged", "Degraded", "DegradationCleared", "Failed", "NoEligibleTool",
)
TRUST_RANK = {"untrusted": 0, "experimental": 1, "pinned": 2, "verified": 3}
MODE_MIN_TRUST = {"trusted": 3, "restricted": 2, "isolated": 1, "simulation": 0}
COST_RANK = {"free": 0, "cheap": 1, "moderate": 2, "expensive": 3, "metered": 4}
RISK_BY_EFFECT = {"read_only": 0.0, "read_write": 0.35, "external": 0.45, "communication": 0.60, "device": 0.70, "financial": 0.90, "identity": 0.90, "destructive": 1.0}
SPECIAL_SCOPE = {"financial": "tools.financial.execute", "communication": "tools.communication.send", "identity": "tools.identity.modify"}
AUTH_DISCOVERY_SCOPE = "tools.discovery.read"
AUTH_SELECT_SCOPE = "tools.selection.read"
AUTH_INVOKE_SCOPE = "tools.invoke"
AUTH_ADMIN_SCOPE = "tools.admin"
AUTH_READ_SCOPE = "tools.read"


class ToolFabricError(RuntimeError):
    """Base error for the canonical tool fabric."""


class ToolValidationError(ToolFabricError, ValueError):
    """A tool manifest or operation violates a fabric contract."""


class ToolSignatureError(ToolFabricError, ValueError):
    """A signature or signed-proof validation failed."""


class ToolIntegrityError(ToolFabricError, ValueError):
    """A content hash or registry integrity check failed."""


class ToolAccessDenied(ToolFabricError, PermissionError):
    """Required execution authorization is absent or invalid."""


class ToolNotFound(ToolFabricError, LookupError):
    """A tenant-scoped tool reference cannot be resolved."""


class ToolRevoked(ToolFabricError):
    """The referenced tool is revoked and cannot be used."""


class ToolRetired(ToolFabricError):
    """The referenced tool has been retired and cannot be invoked."""


class NoEligibleTool(ToolFabricError):
    """No candidate satisfies the discovery and policy constraints."""


class SchemaViolation(ToolFabricError, ValueError):
    """Tool input or output failed its declared schema."""


class ToolPolicyDenied(ToolFabricError, PermissionError):
    """Security or manifest policy denied the operation."""


class ToolTimeout(ToolFabricError, TimeoutError):
    """The adapter exceeded the tool timeout."""


class RateLimited(ToolFabricError):
    """The tool or caller exceeded a configured rate limit."""


class ConcurrencyLimited(ToolFabricError):
    """The tool exceeded its bounded concurrency policy."""


class DeterminismUnavailable(ToolFabricError):
    """The tool cannot satisfy a deterministic execution requirement."""


class IdempotencyViolation(ToolFabricError):
    """An idempotency contract was violated."""


class AdapterError(ToolFabricError):
    """A transport adapter rejected or failed a tool operation."""


class HealthBudgetExceeded(ToolFabricError):
    """A health probe exceeded its execution budget."""


class _Adapter(Protocol):
    kind: str

    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]: ...

    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]: ...

    def shutdown(self, tool_ref: str, target: Any, manifest: Mapping[str, Any]) -> None: ...


@dataclass(frozen=True, slots=True)
class ToolConfig:
    registry_path: str = ":memory:"
    storage_secret: bytes = b"jarvis-tool-fabric-default-storage-secret-32-byte!!"
    default_tenant_id: str = "default"
    policy_version: str = "2.0.0"
    index_version: str = "2.0.0"
    idempotency_window_seconds: int = 300
    rate_limit_window_seconds: float = 1.0
    default_rate_limit: int = 100
    max_concurrency_queue: int = 32
    deterministic_weight: float = 0.12
    trust_weight: float = 0.20
    capability_weight: float = 0.32
    policy_weight: float = 0.20
    cost_weight: float = 0.10
    risk_weight: float = 0.06


@dataclass(frozen=True, slots=True)
class DiscoveryRequest:
    request_id: str
    tenant_id: str
    required_capabilities: tuple[str, ...] = ()
    optional_capabilities: tuple[str, ...] = ()
    forbidden_effects: tuple[str, ...] = ()
    required_effect_class: tuple[str, ...] = ()
    required_reversibility: str | None = None
    trust_floor: str = "untrusted"
    max_cost_class: str | None = None
    max_cost_units: float | None = None
    max_latency_ms: float | None = None
    network_allowed: bool = True
    device_allowed: bool = False
    privacy_required: bool = False
    determinism_required: bool = False
    environment_hash: str | None = None
    execution_mode: str = "trusted"
    excluded_tool_ids: tuple[str, ...] = ()
    prefer: str | None = None


@dataclass(frozen=True, slots=True)
class Candidate:
    tool_ref: str
    manifest_hash: str
    rank_score: float
    rank_reason: Mapping[str, Any]
    disqualifiers: tuple[str, ...]
    estimated_cost_units: float
    estimated_latency_ms: float
    estimated_risk: str
    requires_simulation: bool
    requires_verification: bool


@dataclass(frozen=True, slots=True)
class DiscoveryResult:
    request_id: str
    candidates: tuple[Candidate, ...]
    policy_version: str
    index_version: str
    decided_at: str
    signature: str


@dataclass(frozen=True, slots=True)
class SelectionDecision:
    decision_id: str
    request_id: str
    chosen_tool_ref: str
    fallback_chain: tuple[str, ...]
    reason: Mapping[str, Any]
    estimated_cost_units: float
    estimated_latency_ms: float
    estimated_risk: str
    requires_simulation: bool
    requires_verification: bool
    policy_version: str
    index_version: str
    decided_at: str
    signature: str


@dataclass(frozen=True, slots=True)
class ToolHealth:
    tool_ref: str
    availability: bool
    p50_latency_ms: float
    p95_latency_ms: float
    error_rate: float
    rate_limit_state: Mapping[str, Any]
    degradation: bool
    dependencies_health: Mapping[str, Any]
    measured_at: str


@dataclass(frozen=True, slots=True)
class InvocationResult:
    invocation_id: str
    status: str
    outputs: Any
    error: Mapping[str, Any] | None
    resources_used: Mapping[str, Any]
    retryable: bool
    compensation_hint: Mapping[str, Any] | None
    idempotency_key: str | None
    seed: int | None
    determinism_observed: str | None
    started_at: str
    finished_at: str
    signature: str


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _uuid() -> str:
    return str(uuid.uuid4())


def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(str(text).encode("ascii"))


def _manifest_ref(manifest: Mapping[str, Any]) -> str:
    return f"{manifest['tool_id']}@{manifest['tool_version']}"


def _mode(context: Any) -> str:
    value = getattr(getattr(context, "execution_mode", None), "value", getattr(context, "execution_mode", "trusted"))
    return str(value).lower()


def _tenant_from_context(context: Any, tenant_id: str) -> str:
    if context is None:
        raise ToolAccessDenied("ExecutionContext is required")
    auth = getattr(context, "auth_context", None)
    if auth is None or not getattr(auth, "principal", None):
        raise ToolAccessDenied("execution authorization context is required")
    candidate = str(tenant_id or "default")
    ctx_tenant = str(getattr(context, "tenant_id", candidate))
    if ctx_tenant != candidate and candidate != "default":
        raise ToolAccessDenied("cross-tenant operation denied")
    return ctx_tenant if ctx_tenant else candidate


def _scopes(context: Any) -> set[str]:
    return {str(x) for x in getattr(getattr(context, "auth_context", None), "scopes", ())}


def _require_scope(context: Any, scope: str) -> None:
    scopes = _scopes(context)
    if scope not in scopes and AUTH_ADMIN_SCOPE not in scopes:
        raise ToolAccessDenied(f"missing required scope: {scope}")


def _auth_allowed_tools(context: Any) -> set[str]:
    return {str(x) for x in getattr(getattr(context, "allowed", None), "tools", ())}


def _base_manifest(manifest: Mapping[str, Any]) -> dict[str, Any]:
    data = copy.deepcopy(dict(manifest))
    data["signature"] = ""
    data["integrity_hash"] = ""
    data["manifest_hash"] = ""
    return data


def sign_manifest(manifest: Mapping[str, Any], signer: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    data = _base_manifest(manifest)
    data["signature_key_id"] = str(key_id)
    data["integrity_hash"] = _sha(data)
    hash_material = dict(data)
    hash_material["manifest_hash"] = ""
    data["manifest_hash"] = _sha(hash_material)
    signature_material = dict(data)
    signature_material["signature"] = ""
    signature = signer.sign(canonical_bytes(signature_material))
    data["signature"] = _b64(signature)
    return data


def verify_manifest(manifest: Mapping[str, Any], public_keys: Mapping[str, bytes | Ed25519PublicKey]) -> bool:
    try:
        key_id = str(manifest["signature_key_id"])
        key = public_keys[key_id]
        raw = key if isinstance(key, bytes) else key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        base = _base_manifest(manifest)
        base["signature_key_id"] = key_id
        expected_integrity = _sha(base)
        if not hmac.compare_digest(expected_integrity, str(manifest["integrity_hash"])):
            return False
        hash_material = dict(base)
        hash_material["integrity_hash"] = str(manifest["integrity_hash"])
        expected_manifest_hash = _sha({**hash_material, "manifest_hash": ""})
        if not hmac.compare_digest(expected_manifest_hash, str(manifest["manifest_hash"])):
            return False
        signature_material = dict(manifest)
        signature_material["signature"] = ""
        Ed25519PublicKey.from_public_bytes(raw).verify(_unb64(str(manifest["signature"])), canonical_bytes(signature_material))
        return True
    except (KeyError, ValueError, TypeError, InvalidSignature, base64.binascii.Error):
        return False


def _schema(name: str) -> dict[str, Any]:
    path = SCHEMA_DIR / name
    return json.loads(path.read_text(encoding="utf-8"))


def validate_manifest(manifest: Mapping[str, Any], public_keys: Mapping[str, bytes | Ed25519PublicKey]) -> None:
    SchemaValidator().validate_or_raise(dict(manifest), _schema("tool_manifest_v1.schema.json"))
    if not verify_manifest(manifest, public_keys):
        raise ToolSignatureError(f"invalid tool manifest signature: {_manifest_ref(manifest)}")
    effects = set(map(str, manifest.get("effect_class", ())))
    if manifest.get("reversibility") != "reversible" and manifest.get("compensation", {}).get("tool_ref"):
        raise ToolValidationError("compensation is only allowed for reversible tools")
    det = str(manifest.get("determinism", {}).get("declared"))
    if det == "deterministic" and not manifest.get("determinism", {}).get("proof_ref"):
        raise ToolSignatureError("deterministic tool requires a signed proof_ref")
    idem = str(manifest.get("idempotency", {}).get("declared"))
    if idem == "per_key" and not manifest.get("idempotency", {}).get("key_parameter"):
        raise ToolValidationError("per_key idempotency requires key_parameter")
    if not effects.issubset(set(EFFECT_CLASSES)):
        raise ToolValidationError("unknown effect class")


class ToolRegistry:
    """Durable, HMAC-protected, append-only tenant-scoped tool registry."""

    def __init__(
        self,
        path: str | Path,
        storage_secret: bytes,
        signer: Ed25519PrivateKey,
        key_id: str,
        public_keys: Mapping[str, bytes | Ed25519PublicKey] | None = None,
    ) -> None:
        if len(storage_secret) < 32:
            raise ValueError("tool registry secret must be at least 32 bytes")
        self.path = Path(path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = bytes(storage_secret)
        self.signer = signer
        self.key_id = str(key_id)
        raw_pub = signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.public_keys = dict(public_keys or {})
        self.public_keys.setdefault(self.key_id, raw_pub)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(self.path), check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS manifests(seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL, tool_ref TEXT NOT NULL, tool_id TEXT NOT NULL, tool_version TEXT NOT NULL, revision INTEGER NOT NULL, manifest_json TEXT NOT NULL, manifest_hash TEXT NOT NULL, hmac_tag TEXT NOT NULL, chain_prev_hash TEXT NOT NULL, mutation TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(tenant_id,tool_ref,revision))"
        )
        self.db.execute("CREATE INDEX IF NOT EXISTS idx_tool_cap_ref ON manifests(tenant_id,tool_ref)")
        self.db.execute("CREATE TABLE IF NOT EXISTS idempotency(tenant_id TEXT NOT NULL, tool_ref TEXT NOT NULL, caller TEXT NOT NULL, idem_key TEXT NOT NULL, input_hash TEXT NOT NULL, created_at REAL NOT NULL, PRIMARY KEY(tenant_id,tool_ref,caller,idem_key))")
        self.db.commit()
        self._closed = False
        try:
            self.verify_integrity()
        except Exception:
            self.db.close()
            self._closed = True
            raise

    def _tag(self, row: Mapping[str, Any]) -> str:
        material = {k: row[k] for k in ("tenant_id", "tool_ref", "revision", "manifest_json", "manifest_hash", "chain_prev_hash", "mutation")}
        return hmac.new(self.secret, canonical_bytes(material), hashlib.sha256).hexdigest()

    def verify_integrity(self) -> bool:
        rows = self.db.execute("SELECT tenant_id,tool_ref,revision,manifest_json,manifest_hash,hmac_tag,chain_prev_hash,mutation FROM manifests ORDER BY seq").fetchall()
        prev = ""
        for tenant_id, ref, revision, payload, digest, tag, chain_prev, mutation in rows:
            row = {"tenant_id": tenant_id, "tool_ref": ref, "revision": revision, "manifest_json": payload, "manifest_hash": digest, "chain_prev_hash": chain_prev, "mutation": mutation}
            if chain_prev != prev or not hmac.compare_digest(self._tag(row), tag) or _sha(json.loads(payload)) != digest:
                raise ToolIntegrityError("tool registry HMAC/hash-chain verification failed")
            manifest = json.loads(payload)
            if not verify_manifest(manifest, self.public_keys):
                raise ToolSignatureError(f"stored tool manifest signature invalid: {ref}")
            prev = _sha({"seq": len(rows), "payload": payload, "hmac": tag}) if False else _sha(row)
        return True

    def _latest(self, ref: str, tenant_id: str) -> tuple[Any, ...] | None:
        return self.db.execute("SELECT manifest_json FROM manifests WHERE tenant_id=? AND tool_ref=? ORDER BY revision DESC LIMIT 1", (tenant_id, ref)).fetchone()

    def _append(self, ref: str, manifest: Mapping[str, Any], tenant_id: str, mutation: str) -> None:
        row0 = self.db.execute("SELECT manifest_json,hmac_tag,chain_prev_hash,mutation,tenant_id,tool_ref,revision,manifest_hash FROM manifests ORDER BY seq DESC LIMIT 1").fetchone()
        revision = (self.db.execute("SELECT COALESCE(MAX(revision),0) FROM manifests WHERE tenant_id=? AND tool_ref=?", (tenant_id, ref)).fetchone()[0] or 0) + 1
        payload = json.dumps(dict(manifest), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        chain_prev = _sha({"payload": row0[0], "hmac": row0[1], "chain_prev_hash": row0[2], "mutation": row0[3], "tenant_id": row0[4], "tool_ref": row0[5], "revision": row0[6], "manifest_hash": row0[7]}) if row0 else ""
        row = {"tenant_id": tenant_id, "tool_ref": ref, "revision": revision, "manifest_json": payload, "manifest_hash": str(manifest["manifest_hash"]), "chain_prev_hash": chain_prev, "mutation": mutation}
        tag = self._tag(row)
        self.db.execute(
            "INSERT INTO manifests(tenant_id,tool_ref,tool_id,tool_version,revision,manifest_json,manifest_hash,hmac_tag,chain_prev_hash,mutation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (tenant_id, ref, manifest["tool_id"], manifest["tool_version"], revision, payload, manifest["manifest_hash"], tag, chain_prev, mutation, time.time()),
        )

    def register(self, manifest: Mapping[str, Any], *, tenant_id: str) -> str:
        tenant_id = str(tenant_id)
        signed = sign_manifest(manifest, self.signer, self.key_id) if not manifest.get("signature") else dict(manifest)
        validate_manifest(signed, self.public_keys)
        ref = _manifest_ref(signed)
        with self.lock, self.db:
            if self._latest(ref, tenant_id) is not None:
                raise ToolValidationError(f"tool already registered: {ref}")
            existing = self.db.execute("SELECT tenant_id,tool_ref,manifest_json FROM manifests WHERE manifest_hash=?", (signed["manifest_hash"],)).fetchall()
            for existing_tenant, existing_ref, payload in existing:
                if existing_ref != ref or json.loads(payload) != signed:
                    raise ToolValidationError("manifest-hash collision")
            self._append(ref, signed, tenant_id, "register")
        return ref

    def get(self, tool_id: str, version: str | None, *, tenant_id: str) -> dict[str, Any]:
        ref = f"{tool_id}@{version}" if version else None
        row = self._latest(ref, tenant_id) if ref else self.db.execute("SELECT manifest_json FROM manifests WHERE tenant_id=? AND tool_id=? ORDER BY seq DESC LIMIT 1", (tenant_id, tool_id)).fetchone()
        if row is None:
            raise ToolNotFound(tool_id if ref is None else ref)
        manifest = json.loads(row[0])
        validate_manifest(manifest, self.public_keys)
        return manifest

    def get_ref(self, ref: str, *, tenant_id: str) -> dict[str, Any]:
        if "@" not in ref:
            return self.get(ref, None, tenant_id=tenant_id)
        return self.get(*ref.rsplit("@", 1), tenant_id=tenant_id)

    def get_by_hash(self, manifest_hash: str, *, tenant_id: str) -> dict[str, Any]:
        row = self.db.execute("SELECT manifest_json FROM manifests WHERE tenant_id=? AND manifest_hash=? ORDER BY seq DESC LIMIT 1", (tenant_id, manifest_hash)).fetchone()
        if row is None:
            raise ToolNotFound(manifest_hash)
        manifest = json.loads(row[0]); validate_manifest(manifest, self.public_keys); return manifest

    def list(self, *, tenant_id: str, include_inactive: bool = True) -> list[dict[str, Any]]:
        rows = self.db.execute("SELECT tool_ref,manifest_json FROM manifests WHERE tenant_id=? ORDER BY seq DESC", (tenant_id,)).fetchall()
        seen: set[str] = set(); out: list[dict[str, Any]] = []
        for ref, payload in rows:
            if ref in seen:
                continue
            seen.add(ref)
            p = json.loads(payload); validate_manifest(p, self.public_keys)
            if not include_inactive and p["state"] != "active":
                continue
            out.append(p)
        return out

    def history(self, ref: str, *, tenant_id: str) -> list[dict[str, Any]]:
        rows = self.db.execute("SELECT revision,manifest_json,mutation FROM manifests WHERE tenant_id=? AND tool_ref=? ORDER BY revision", (tenant_id, ref)).fetchall()
        return [{"revision": rev, "manifest": json.loads(payload), "mutation": mutation} for rev, payload, mutation in rows]

    def mutate(self, ref: str, state: str, *, tenant_id: str, reason: str = "", successor_ref: str | None = None) -> dict[str, Any]:
        if state not in TOOL_STATES:
            raise ToolValidationError(f"invalid tool state {state}")
        current = self.get_ref(ref, tenant_id=tenant_id)
        current["state"] = state
        now = _utc()
        if state == "deprecated": current["deprecated_at"] = now
        if state == "revoked": current["revoked_at"] = now
        if state == "retired": current["retired_at"] = now
        if successor_ref is not None: current["successor_ref"] = successor_ref
        if reason: current["lifecycle_reason"] = reason
        signed = sign_manifest(current, self.signer, self.key_id)
        with self.lock, self.db:
            self._append(ref, signed, tenant_id, state)
        return signed

    def history_for_replay(self, *, tenant_id: str, limit: int = 1000) -> list[dict[str, Any]]:
        rows = self.db.execute("SELECT seq,tool_ref,revision,manifest_json,mutation FROM manifests WHERE tenant_id=? ORDER BY seq LIMIT ?", (tenant_id, int(limit))).fetchall()
        return [{"seq": s, "tool_ref": ref, "revision": rev, "manifest": json.loads(payload), "mutation": mut} for s, ref, rev, payload, mut in rows]

    def remember_idempotency(self, tenant_id: str, tool_ref: str, caller: str, key: str, input_hash: str, now: float, window: int) -> None:
        cutoff = now - window
        self.db.execute("DELETE FROM idempotency WHERE created_at<?", (cutoff,))
        row = self.db.execute("SELECT input_hash FROM idempotency WHERE tenant_id=? AND tool_ref=? AND caller=? AND idem_key=?", (tenant_id, tool_ref, caller, key)).fetchone()
        if row is not None:
            raise IdempotencyViolation("idempotency key has already been used")
        self.db.execute("INSERT INTO idempotency(tenant_id,tool_ref,caller,idem_key,input_hash,created_at) VALUES(?,?,?,?,?,?)", (tenant_id, tool_ref, caller, key, input_hash, now))
        self.db.commit()

    def replay_events(self, *, correlation_id: str | None = None, tenant_id: str | None = None, limit: int = 1000) -> list[dict[str, Any]]:
        rows = list(self._event_log)
        if tenant_id is not None: rows = [r for r in rows if str(r.get("tenant_id")) == str(tenant_id)]
        if correlation_id is not None: rows = [r for r in rows if str(r.get("correlation_id")) == str(correlation_id)]
        return rows[:max(0, int(limit))]

    def close(self) -> None:
        with self.lock:
            if not self._closed:
                self._closed = True
                self.db.close()


class BaseAdapter:
    kind = "base"
    def __init__(self) -> None:
        self._shutdown = False
    def _ensure(self) -> None:
        if self._shutdown:
            raise AdapterError(f"{self.kind} adapter is shut down")
    def shutdown(self, tool_ref: str, target: Any, manifest: Mapping[str, Any]) -> None:
        self._shutdown = True


class FunctionAdapter(BaseAdapter):
    kind = "function"
    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]:
        self._ensure(); return {"available": callable(target), "mode": "in_process_callable"}
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        if not callable(target): raise AdapterError("function target is not callable")
        inputs = dict(request["inputs"])
        kwargs = {"context": request.get("execution_context"), "dry_run": bool(request.get("dry_run", False)), "seed": request.get("seed")}
        try:
            sig = inspect.signature(target)
            call = {k: v for k, v in kwargs.items() if k in sig.parameters}
            value = target(inputs, **call)
        except (TypeError, ValueError):
            value = target(inputs)
        return {"outputs": value}


class HttpAdapter(BaseAdapter):
    kind = "http"
    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]:
        self._ensure(); return {"available": bool(target), "target": str(target), "mode": "transport-head"}
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        url = str(target)
        parsed = urllib.parse.urlparse(url)
        context = request.get("execution_context")
        allowed_hosts = set(getattr(getattr(context, "allowed", None), "network_hosts", ()))
        if allowed_hosts and (parsed.hostname or "") not in allowed_hosts:
            raise ToolPolicyDenied("HTTP host is not allowlisted")
        if parsed.scheme != "https":
            raise ToolPolicyDenied("HTTP adapter requires HTTPS")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        body = json.dumps(request["inputs"], separators=(",", ":")).encode()
        max_out = int(manifest["resources"]["network_bytes_max"])
        if len(body) > max(1, max_out): raise AdapterError("request exceeds network byte limit")
        req = urllib.request.Request(url, data=body, method="POST", headers=headers)
        timeout = min(int(request["timeout_ms"]), int(manifest["timeout_ms_max"])) / 1000.0
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as resp:  # noqa: S310
                raw = resp.read(max(1, max_out + 1))
                if len(raw) > max_out: raise AdapterError("response exceeds network byte limit")
                try: value = json.loads(raw.decode("utf-8"))
                except json.JSONDecodeError: value = raw.decode("utf-8", errors="replace")
                return {"outputs": value}
        except Exception as exc:  # transport layer converts to structured tool failure
            raise AdapterError(f"http transport failed: {exc}") from exc


class CliAdapter(BaseAdapter):
    kind = "cli"
    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]:
        self._ensure(); argv = list(target or []) if isinstance(target, (list, tuple)) else shlex.split(str(target or "")); return {"available": bool(argv), "argv0": argv[0] if argv else None}
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        argv = list(target or []) if isinstance(target, (list, tuple)) else shlex.split(str(target or ""))
        if not argv or any(";" in x or "&&" in x or "|" in x or "`" in x for x in argv): raise AdapterError("shell metacharacters are forbidden")
        context = request["execution_context"]
        allow = set(getattr(getattr(context, "allowed", None), "subprocess_allowlist", ()))
        if allow and os.path.basename(argv[0]) not in allow and argv[0] not in allow: raise ToolPolicyDenied("CLI executable is not allowlisted")
        timeout = min(int(request["timeout_ms"]), int(manifest["timeout_ms_max"])) / 1000.0
        payload = json.dumps(request["inputs"], separators=(",", ":")).encode()
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False, env={k: str(v) for k, v in getattr(context, "env_vars", {}).items()}, start_new_session=True)
        try:
            stdout, stderr = proc.communicate(payload, timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                proc.kill()
            proc.communicate()
            raise ToolTimeout("CLI process exceeded timeout") from exc
        max_bytes = int(manifest["resources"]["network_bytes_max"])
        if len(stdout) > max_bytes or len(stderr) > max_bytes: raise AdapterError("CLI stdout/stderr exceeds declared limit")
        if proc.returncode != 0: raise AdapterError(f"CLI exited with code {proc.returncode}")
        raw = stdout.decode("utf-8", errors="replace")
        try: value = json.loads(raw) if raw else {}
        except json.JSONDecodeError: value = {"stdout": raw}
        return {"outputs": value}


class RpcAdapter(HttpAdapter):
    kind = "rpc"
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        payload = {"jsonrpc": "2.0", "id": request.get("invocation_id", "rpc"), "method": manifest.get("rpc_method", "invoke"), "params": request["inputs"]}
        req = dict(request); req["inputs"] = payload
        result = super().invoke(req, target, manifest)
        return {"outputs": result["outputs"].get("result") if isinstance(result["outputs"], Mapping) else result["outputs"]}


class McpAdapter(BaseAdapter):
    kind = "mcp"
    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]:
        self._ensure(); return {"available": hasattr(target, "list_tools") or hasattr(target, "ping"), "mode": "injected_mcp_client"}
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        if target is None or not hasattr(target, "call_tool"): raise AdapterError("MCP client with call_tool is required")
        result = target.call_tool(str(manifest["tool_id"]), dict(request["inputs"]))
        return {"outputs": result}


class PluginAdapter(FunctionAdapter):
    kind = "plugin"


class DeviceAdapter(BaseAdapter):
    kind = "device"
    def probe(self, tool_ref: str, target: Any, manifest: Mapping[str, Any], context: Any) -> Mapping[str, Any]:
        self._ensure(); return {"available": bool(target), "device": str(target)}
    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        context = request["execution_context"]
        allowed = set(getattr(getattr(context, "allowed", None), "devices", ()))
        if str(target) not in allowed: raise ToolPolicyDenied("device is not allowlisted")
        raise AdapterError("device adapter requires an injected device driver")


class InternalAdapter(FunctionAdapter):
    kind = "internal"


class CompositeAdapter(FunctionAdapter):
    """P2-Q bridge: a composite is still invoked through P2-P only."""
    kind = "composite"

    def invoke(self, request: Mapping[str, Any], target: Any, manifest: Mapping[str, Any]) -> Mapping[str, Any]:
        self._ensure()
        if not callable(target):
            raise AdapterError("composite target is not callable")
        return {"outputs": target(dict(request.get("inputs", {})), context=request.get("execution_context"), dry_run=bool(request.get("dry_run", False)), seed=request.get("seed"), idempotency_key=request.get("idempotency_key"))}


ADAPTERS: dict[str, type[BaseAdapter]] = {
    "function": FunctionAdapter, "http": HttpAdapter, "cli": CliAdapter, "rpc": RpcAdapter,
    "mcp": McpAdapter, "plugin": PluginAdapter, "device": DeviceAdapter, "internal": InternalAdapter, "composite": CompositeAdapter,
}


class ToolFabric:
    """Single canonical registry/discovery/selection/invocation boundary."""

    def __init__(
        self,
        *,
        config: ToolConfig | None = None,
        signer: Ed25519PrivateKey | None = None,
        key_id: str = "tool-fabric",
        event_fabric: EventFabric | None = None,
        schema_resolver: Callable[[str], Mapping[str, Any]] | None = None,
        adapters: Mapping[str, _Adapter] | None = None,
        revocation_propagator: Callable[[str, Mapping[str, Any]], Any] | None = None,
        accounting_hook: Callable[[str, Mapping[str, Any], Any], None] | None = None,
    ) -> None:
        self.config = config or ToolConfig()
        self.signer = signer or Ed25519PrivateKey.generate()
        self.key_id = str(key_id)
        self.public_key = self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.public_keys = {self.key_id: self.public_key}
        self.registry = ToolRegistry(self.config.registry_path, self.config.storage_secret, self.signer, self.key_id, self.public_keys)
        self.event_fabric = event_fabric
        self.schema_resolver = schema_resolver
        self.adapters: dict[str, _Adapter] = {kind: cls() for kind, cls in ADAPTERS.items()}
        if adapters:
            self.adapters.update(adapters)
        self.revocation_propagator = revocation_propagator
        self.accounting_hook = accounting_hook
        self.targets: dict[tuple[str, str], Any] = {}
        self.capability_index: dict[tuple[str, str], set[str]] = defaultdict(set)
        self._rate_history: dict[tuple[str, str, str], deque[float]] = defaultdict(deque)
        self._semaphores: dict[tuple[str, str, str], threading.BoundedSemaphore] = {}
        self._health: dict[tuple[str, str], ToolHealth] = {}
        self._observed_outputs: dict[tuple[str, str], str] = {}
        self.determinism_proofs: dict[str, dict[str, Any]] = {}
        self._idempotency_lock = threading.RLock()
        self._event_log: list[dict[str, Any]] = []
        self._shutdown_errors: list[dict[str, str]] = []
        self._closed = False
        self._build_index()

    def _build_index(self) -> None:
        tenants = {row[0] for row in self.registry.db.execute("SELECT DISTINCT tenant_id FROM manifests").fetchall()}
        for tenant in tenants:
            for manifest in self.registry.list(tenant_id=tenant): self._index_manifest(tenant, manifest)

    def _index_manifest(self, tenant_id: str, manifest: Mapping[str, Any]) -> None:
        ref = _manifest_ref(manifest)
        for cap in manifest.get("capabilities_provided", ()):
            self.capability_index[(tenant_id, str(cap))].add(ref)

    def _auth(self, context: ExecutionContext) -> AuthContext:
        auth = getattr(context, "auth_context", None)
        if auth is None: raise ToolAccessDenied("auth_context required")
        return AuthContext(str(auth.principal), tuple(str(x) for x in auth.scopes), getattr(auth, "policy_ref", None), None)

    def _event_auth(self, context: ExecutionContext, scope: str) -> AuthContext:
        auth = getattr(context, "auth_context", None)
        if auth is None: raise ToolAccessDenied("auth_context required")
        # Tool Fabric is the authenticated producer of its own lifecycle events.
        # The caller remains represented in the payload/correlation lineage; event
        # publication itself must not depend on the caller possessing internal
        # events.publish.* scopes.
        return AuthContext("tool_fabric", (scope,), getattr(auth, "policy_ref", None), str(auth.principal))

    def _emit(self, name: str, payload: Mapping[str, Any], context: ExecutionContext, tenant_id: str, *, correlation_id: str | None = None, causation_id: str | None = None) -> None:
        body = dict(payload)
        auth = self._event_auth(context, "events.publish.tool")
        body.setdefault("caller_principal", str(getattr(getattr(context, "auth_context", None), "principal", "")))
        env = EventEnvelope.create(
            event_type="Tool", event_name=name, payload=body, produced_by=ProducedBy("system", "tool_fabric", None, "system"),
            auth_context=auth, tenant_id=tenant_id, partition_key=str(body.get("tool_ref", body.get("request_id", tenant_id))),
            correlation_id=correlation_id or str(getattr(context, "correlation_id", _uuid())),
            causation_id=causation_id or getattr(context, "causation_id", None), signing_key=self.signer, lineage=EventLineage(),
        )
        self._event_log.append(env.to_dict())
        if self.event_fabric is not None: self.event_fabric.publish_envelope(env)

    def register_determinism_proof(self, proof: Mapping[str, Any], *, context: ExecutionContext, tenant_id: str | None = None) -> str:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id)
        _require_scope(context, "tools.register")
        proof_doc = copy.deepcopy(dict(proof))
        signature = str(proof_doc.get("signature", ""))
        key_id = str(proof_doc.get("key_id", self.key_id))
        if not signature or key_id not in self.public_keys:
            raise ToolSignatureError("determinism proof is unsigned or key is unknown")
        sig = _unb64(signature)
        unsigned = dict(proof_doc); unsigned["signature"] = ""
        raw = self.public_keys[key_id]
        raw = raw if isinstance(raw, bytes) else raw.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        try:
            Ed25519PublicKey.from_public_bytes(raw).verify(sig, canonical_bytes(unsigned))
        except Exception as exc:
            raise ToolSignatureError("invalid determinism proof") from exc
        ref = "urn:jarvis:tool-determinism:" + _sha({k: v for k, v in unsigned.items() if k != "signature"})
        self.determinism_proofs[ref] = {"tenant_id": tenant, **proof_doc}
        return ref

    def _verify_runtime_proof(self, manifest: Mapping[str, Any], tenant_id: str) -> bool:
        ref = manifest.get("determinism", {}).get("proof_ref")
        if not ref:
            return False
        proof = self.determinism_proofs.get(str(ref))
        if not proof or proof.get("tenant_id") != tenant_id:
            return False
        try:
            signature = str(proof["signature"]); key_id = str(proof["key_id"])
            raw = self.public_keys[key_id]; raw = raw if isinstance(raw, bytes) else raw.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            body = dict(proof); body.pop("tenant_id", None); body["signature"] = ""
            Ed25519PublicKey.from_public_bytes(raw).verify(_unb64(signature), canonical_bytes(body))
            return hmac.compare_digest(str(ref), "urn:jarvis:tool-determinism:" + _sha({k: v for k, v in body.items() if k != "signature"}))
        except Exception:
            return False

    def _emit_security_denied(self, payload: Mapping[str, Any], context: ExecutionContext, tenant_id: str) -> None:
        body = dict(payload)
        body.setdefault("caller_principal", str(getattr(getattr(context, "auth_context", None), "principal", "")))
        auth = self._event_auth(context, "events.publish.security")
        env = EventEnvelope.create(event_type="Security", event_name="Denied", payload=body, produced_by=ProducedBy("system", "tool_fabric", None, "system"), auth_context=auth, tenant_id=tenant_id, partition_key=str(body.get("tool_ref", tenant_id)), correlation_id=str(getattr(context, "correlation_id", _uuid())), causation_id=getattr(context, "causation_id", None), signing_key=self.signer, lineage=EventLineage())
        self._event_log.append(env.to_dict())
        if self.event_fabric is not None: self.event_fabric.publish_envelope(env)

    def register(self, manifest: Mapping[str, Any], *, context: ExecutionContext, tenant_id: str | None = None, target: Any = None) -> str:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.register")
        signed = sign_manifest(manifest, self.signer, self.key_id) if not manifest.get("signature") else dict(manifest)
        validate_manifest(signed, self.public_keys)
        if signed["determinism"]["declared"] == "deterministic" and not self._verify_runtime_proof(signed, tenant):
            raise ToolSignatureError("deterministic tool requires a registered signed proof")
        ref = self.registry.register(signed, tenant_id=tenant)
        self._index_manifest(tenant, signed)
        if target is not None: self.targets[(tenant, ref)] = target
        self._emit("Registered", {"tool_ref": ref, "manifest_hash": signed["manifest_hash"]}, context, tenant)
        return ref

    def activate(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None) -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin")
        current = self.registry.get_ref(ref, tenant_id=tenant)
        current["state"] = "active"
        signed = self.registry.mutate(ref, "active", tenant_id=tenant)
        self._emit("Activated", {"tool_ref": ref}, context, tenant); return signed

    def deprecate(self, ref: str, successor_ref: str | None, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin")
        result = self.registry.mutate(ref, "deprecated", tenant_id=tenant, successor_ref=successor_ref, reason=reason); self._emit("Deprecated", {"tool_ref": ref, "successor_ref": successor_ref}, context, tenant); return result

    def retire(self, ref: str, successor_ref: str | None, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin")
        result = self.registry.mutate(ref, "retired", tenant_id=tenant, successor_ref=successor_ref, reason=reason); self._emit("Retired", {"tool_ref": ref, "successor_ref": successor_ref}, context, tenant); return result

    def revoke(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin")
        result = self.registry.mutate(ref, "revoked", tenant_id=tenant, reason=reason)
        dependent_skills = list(result.get("dependencies", {}).get("skills", ()))
        dependent_plans: list[str] = []
        if self.revocation_propagator is not None:
            propagated = self.revocation_propagator(ref, result)
            if isinstance(propagated, Mapping): dependent_plans = [str(x) for x in propagated.get("plans", ())]
        self._emit("Revoked", {"tool_ref": ref, "reason": reason}, context, tenant)
        self._emit("RevocationPropagated", {"tool_ref": ref, "dependent_skills": dependent_skills, "dependent_plans": dependent_plans, "skills_status": "provisional", "plans_status": "invalidated"}, context, tenant)
        return result

    def pin(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin")
        manifest = self.registry.get_ref(ref, tenant_id=tenant); manifest["trust"] = "pinned"; manifest["state"] = "active"; manifest["lifecycle_reason"] = reason
        signed = sign_manifest(manifest, self.signer, self.key_id)
        with self.registry.lock, self.registry.db:
            self.registry._append(ref, signed, tenant, "pin")
        self._emit("Activated", {"tool_ref": ref, "pinned": True}, context, tenant); return signed

    def list_tools(self, *, context: ExecutionContext, tenant_id: str | None = None) -> list[dict[str, Any]]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, AUTH_READ_SCOPE); return self.registry.list(tenant_id=tenant)

    def resolve(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None) -> dict[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, AUTH_READ_SCOPE)
        p = self.registry.get_ref(ref, tenant_id=tenant)
        if p["state"] == "revoked": raise ToolRevoked(ref)
        if p["state"] == "retired":
            if p.get("successor_ref"): return self.registry.get_ref(p["successor_ref"], tenant_id=tenant)
            raise ToolRetired(ref)
        return p

    def _risk(self, effects: Sequence[str]) -> float:
        return min(1.0, max((RISK_BY_EFFECT.get(str(x), 1.0) for x in effects), default=1.0))

    @staticmethod
    def _risk_name(value: float) -> str:
        return "critical" if value >= 0.85 else "high" if value >= 0.65 else "medium" if value >= 0.35 else "low" if value > 0.0 else "none"

    def _disqualifiers(self, manifest: Mapping[str, Any], request: DiscoveryRequest, context: ExecutionContext) -> list[str]:
        reasons: list[str] = []
        trust_floor = max(TRUST_RANK.get(request.trust_floor, 0), MODE_MIN_TRUST.get(request.execution_mode, 0))
        if TRUST_RANK.get(str(manifest["trust"]), -1) < trust_floor: reasons.append("trust_floor")
        if manifest["state"] == "revoked": reasons.append("revoked")
        if manifest["state"] == "retired": reasons.append("retired")
        if manifest["state"] == "deprecated": reasons.append("deprecated")
        provided = set(map(str, manifest.get("capabilities_provided", ())))
        if not set(request.required_capabilities).issubset(provided): reasons.append("missing_capability:" + ",".join(sorted(set(request.required_capabilities)-provided)))
        effects = set(map(str, manifest.get("effect_class", ())))
        forbidden = effects.intersection(request.forbidden_effects)
        if forbidden: reasons.append("forbidden_effect:" + ",".join(sorted(forbidden)))
        if request.required_effect_class and not set(request.required_effect_class).issubset(effects): reasons.append("effect_class_mismatch")
        if request.required_reversibility and str(manifest["reversibility"]) != request.required_reversibility: reasons.append("reversibility")
        if request.max_cost_class is not None and COST_RANK[str(manifest["cost_class"])] > COST_RANK[str(request.max_cost_class)]: reasons.append("cost_class")
        resources = manifest["resources"]
        est_cost = float(resources.get("cost_units_typical", 0.0))
        est_latency = float(resources.get("latency_ms_typical", manifest.get("timeout_ms_default", 0)))
        if request.max_cost_units is not None and est_cost > float(request.max_cost_units): reasons.append("cost_budget")
        if request.max_latency_ms is not None and est_latency > float(request.max_latency_ms): reasons.append("latency_budget")
        kind = str(manifest["invocation_kind"])
        if not request.network_allowed and kind in {"http", "rpc", "mcp"}: reasons.append("network_disallowed")
        if not request.device_allowed and kind == "device": reasons.append("device_disallowed")
        if request.privacy_required and ("external" in effects or kind in {"http", "rpc", "mcp"}): reasons.append("privacy")
        if request.determinism_required and str(manifest["determinism"]["declared"]) != "deterministic": reasons.append("determinism")
        if request.environment_hash and manifest.get("environment_requirements", {}).get("environment_hashes") and request.environment_hash not in set(manifest["environment_requirements"]["environment_hashes"]): reasons.append("environment")
        if TRUST_RANK.get(str(manifest["trust"]), 0) < MODE_MIN_TRUST.get(request.execution_mode, 0): reasons.append("mode_trust")
        for required_scope in manifest.get("required_scopes", ()):
            if required_scope not in _scopes(context) and AUTH_ADMIN_SCOPE not in _scopes(context): reasons.append("scope:" + str(required_scope))
        return reasons

    def discover(self, request: DiscoveryRequest | Mapping[str, Any], *, context: ExecutionContext) -> DiscoveryResult:
        req = request if isinstance(request, DiscoveryRequest) else DiscoveryRequest(**request)
        tenant = _tenant_from_context(context, req.tenant_id)
        try:
            _require_scope(context, AUTH_DISCOVERY_SCOPE)
        except ToolAccessDenied as exc:
            decided = _utc(); body = {"request_id": req.request_id, "candidates": [], "policy_version": self.config.policy_version, "index_version": self.config.index_version, "decided_at": decided, "denied_reason": str(exc)}
            sig = _b64(self.signer.sign(canonical_bytes(body)))
            self._emit("DiscoveryDenied", {"request_id": req.request_id, "reason": str(exc)}, context, tenant)
            return DiscoveryResult(req.request_id, (), self.config.policy_version, self.config.index_version, decided, sig)
        self._emit("DiscoveryRequested", {"request_id": req.request_id, "tenant_id": tenant}, context, tenant)
        candidates: list[Candidate] = []
        manifests = self.registry.list(tenant_id=tenant)
        excluded = set(req.excluded_tool_ids)
        for manifest in manifests:
            ref = _manifest_ref(manifest)
            if manifest["tool_id"] in excluded or ref in excluded: continue
            reasons = self._disqualifiers(manifest, req, context)
            risk = self._risk(manifest["effect_class"])
            risk_name = self._risk_name(risk)
            cost = float(manifest["resources"].get("cost_units_typical", 0.0))
            latency = float(manifest["resources"].get("latency_ms_typical", manifest["timeout_ms_default"]))
            provided = set(map(str, manifest.get("capabilities_provided", ())))
            optional_hits = len(provided.intersection(req.optional_capabilities))
            capability_fit = 1.0 if not req.required_capabilities else len(provided.intersection(req.required_capabilities))/max(1,len(req.required_capabilities))
            policy_fit = 1.0 if not reasons else 0.0
            cost_fit = 1.0/(1.0+max(0.0,cost))
            risk_fit = 1.0-risk
            trust_fit = TRUST_RANK[manifest["trust"]]/3.0
            det_fit = 1.0 if manifest["determinism"]["declared"] == "deterministic" else 0.5 if manifest["determinism"]["declared"] == "seeded" else 0.0
            score = (
                self.config.policy_weight*policy_fit + self.config.capability_weight*capability_fit +
                self.config.cost_weight*cost_fit + self.config.risk_weight*risk_fit +
                self.config.trust_weight*trust_fit + self.config.deterministic_weight*det_fit + min(0.10, optional_hits*0.01)
            )
            reason = {"policy_fit": policy_fit, "capability_fit": capability_fit, "optional_capability_hits": optional_hits, "cost_fit": cost_fit, "risk_fit": risk_fit, "trust_fit": trust_fit, "determinism_fit": det_fit, "prefer": req.prefer, "disqualifiers": list(reasons)}
            candidates.append(Candidate(ref, manifest["manifest_hash"], round(score, 12), reason, tuple(reasons), cost, latency, risk_name, bool(risk >= 0.65 or manifest.get("reversibility") in {"irreversible", "unknown"} or "device" in manifest["effect_class"]), bool(risk >= 0.65 or "external" in manifest["effect_class"])))
        candidates.sort(key=lambda c: (0 if not c.disqualifiers else 1, -c.rank_score, c.estimated_cost_units, c.estimated_latency_ms, c.tool_ref))
        unsigned = {"request_id": req.request_id, "candidates": [c.__dict__ if hasattr(c, "__dict__") else {"tool_ref": c.tool_ref, "manifest_hash": c.manifest_hash, "rank_score": c.rank_score, "rank_reason": dict(c.rank_reason), "disqualifiers": list(c.disqualifiers), "estimated_cost_units": c.estimated_cost_units, "estimated_latency_ms": c.estimated_latency_ms, "estimated_risk": c.estimated_risk, "requires_simulation": c.requires_simulation, "requires_verification": c.requires_verification} for c in candidates], "policy_version": self.config.policy_version, "index_version": self.config.index_version, "decided_at": _utc()}
        signature = _b64(self.signer.sign(canonical_bytes(unsigned)))
        result = DiscoveryResult(req.request_id, tuple(candidates), self.config.policy_version, self.config.index_version, unsigned["decided_at"], signature)
        self._emit("DiscoveryCompleted", {"request_id": req.request_id, "candidate_count": len(candidates)}, context, tenant)
        return result

    def _selection_signature(self, body: Mapping[str, Any]) -> str:
        return _b64(self.signer.sign(canonical_bytes(body)))

    def select(self, request: DiscoveryRequest | Mapping[str, Any], discovery: DiscoveryResult, *, context: ExecutionContext) -> SelectionDecision:
        req = request if isinstance(request, DiscoveryRequest) else DiscoveryRequest(**request)
        tenant = _tenant_from_context(context, req.tenant_id); _require_scope(context, AUTH_SELECT_SCOPE)
        eligible = [c for c in discovery.candidates if not c.disqualifiers]
        if not eligible:
            self._emit("SelectionFailed", {"request_id": req.request_id, "reason": "NoEligibleTool", "candidates": [{"tool_ref": c.tool_ref, "disqualifiers": list(c.disqualifiers)} for c in discovery.candidates]}, context, tenant)
            self._emit("NoEligibleTool", {"request_id": req.request_id}, context, tenant)
            raise NoEligibleTool("no eligible tool; see per-candidate disqualifiers")
        def tie_key(c: Candidate) -> tuple[Any, ...]:
            p = self.registry.get_ref(c.tool_ref, tenant_id=tenant)
            prefer_bonus = 0
            if req.prefer == "cheap": prefer_bonus = -COST_RANK[p["cost_class"]]
            elif req.prefer == "fast": prefer_bonus = float(c.estimated_latency_ms)
            elif req.prefer == "deterministic": prefer_bonus = 0 if p["determinism"]["declared"] == "deterministic" else 1
            elif req.prefer == "trusted": prefer_bonus = -TRUST_RANK[p["trust"]]
            return (-c.rank_score, prefer_bonus, -TRUST_RANK[p["trust"]], c.estimated_cost_units, c.estimated_latency_ms, c.tool_ref)
        ordered = sorted(eligible, key=tie_key)
        chosen = ordered[0]
        fallback = tuple(c.tool_ref for c in ordered[1:])
        decision_id = _uuid()
        body = {"decision_id": decision_id, "request_id": req.request_id, "chosen_tool_ref": chosen.tool_ref, "fallback_chain": list(fallback), "reason": {"rank_reason": dict(chosen.rank_reason), "selection_policy": "policy_fit*capability_fit*(1-cost)*(1-risk)*trust*determinism", "prefer": req.prefer}, "estimated_cost_units": chosen.estimated_cost_units, "estimated_latency_ms": chosen.estimated_latency_ms, "estimated_risk": chosen.estimated_risk, "requires_simulation": chosen.requires_simulation, "requires_verification": chosen.requires_verification, "policy_version": discovery.policy_version, "index_version": discovery.index_version, "decided_at": _utc()}
        signature = self._selection_signature(body)
        decision = SelectionDecision(decision_id, req.request_id, chosen.tool_ref, fallback, body["reason"], chosen.estimated_cost_units, chosen.estimated_latency_ms, chosen.estimated_risk, chosen.requires_simulation, chosen.requires_verification, discovery.policy_version, discovery.index_version, body["decided_at"], signature)
        self._emit("Selected", {"request_id": req.request_id, "decision_id": decision.decision_id, "tool_ref": chosen.tool_ref, "fallback_chain": list(fallback)}, context, tenant)
        return decision

    def _resolve_schema(self, ref: str) -> Mapping[str, Any]:
        if self.schema_resolver is None:
            raise SchemaViolation(f"schema resolver unavailable for {ref}")
        schema = self.schema_resolver(ref)
        if not isinstance(schema, Mapping): raise SchemaViolation(f"schema resolver returned invalid object for {ref}")
        return schema

    def _authorize_manifest(self, manifest: Mapping[str, Any], context: ExecutionContext, *, plan_ref: str | None = None, skill_ref: str | None = None, ad_hoc_authorization: Mapping[str, Any] | None = None) -> None:
        _require_scope(context, AUTH_INVOKE_SCOPE)
        scopes = _scopes(context)
        for required in list(manifest.get("required_scopes", ())) + list(manifest.get("required_permissions", ())):
            if required not in scopes and AUTH_ADMIN_SCOPE not in scopes: raise ToolPolicyDenied(f"missing tool scope/permission: {required}")
        for effect, scope in SPECIAL_SCOPE.items():
            if effect in set(manifest.get("effect_class", ())) and scope not in scopes and AUTH_ADMIN_SCOPE not in scopes:
                raise ToolPolicyDenied(f"effect class requires scope: {scope}")
        allowed_tools = _auth_allowed_tools(context)
        ref = _manifest_ref(manifest)
        allowed = ref in allowed_tools or manifest["tool_id"] in allowed_tools
        if plan_ref is not None:
            plan_tools = set(map(str, getattr(context, "plan_tool_bindings", ())))
            allowed = allowed and (ref in plan_tools or manifest["tool_id"] in plan_tools)
        if skill_ref is not None:
            skill_tools = set(map(str, getattr(context, "skill_tool_bindings", ())))
            allowed = allowed and (ref in skill_tools or manifest["tool_id"] in skill_tools)
        if not allowed:
            if ad_hoc_authorization and self._verify_adhoc_authorization(ad_hoc_authorization, ref, context):
                allowed = True
        if not allowed: raise ToolPolicyDenied("tool is not present in the caller's allowlist")
        mode = _mode(context)
        if TRUST_RANK[manifest["trust"]] < MODE_MIN_TRUST.get(mode, 0): raise ToolPolicyDenied("trust level is insufficient for execution mode")
        if manifest["trust"] in {"experimental", "untrusted"} and mode not in {"isolated", "simulation"}: raise ToolPolicyDenied("experimental/untrusted tools require isolated or simulation mode")
        if manifest["state"] == "revoked": raise ToolRevoked(ref)
        if manifest["state"] == "retired": raise ToolRetired(ref)

    def _verify_adhoc_authorization(self, authz: Mapping[str, Any], ref: str, context: ExecutionContext) -> bool:
        try:
            body = dict(authz); sig = _unb64(str(body.pop("signature")))
            if body.get("tool_ref") != ref or body.get("tenant_id") != getattr(context, "tenant_id", body.get("tenant_id")): return False
            exp = float(body.get("expires_at", 0));
            if exp <= time.time(): return False
            key_id = str(body["key_id"]); pub = self.public_keys[key_id]
            raw = pub if isinstance(pub, bytes) else pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            Ed25519PublicKey.from_public_bytes(raw).verify(sig, canonical_bytes(body)); return AUTH_ADMIN_SCOPE in _scopes(context) or "tools.adhoc" in _scopes(context)
        except Exception: return False

    def _check_budget_headroom(self, manifest: Mapping[str, Any], context: ExecutionContext) -> None:
        budgets = getattr(context, "budgets", None)
        if budgets is None: raise ToolAccessDenied("ExecutionContext budgets are required")
        b = budgets.as_dict() if hasattr(budgets, "as_dict") else dict(budgets)
        res = manifest["resources"]
        checks = [("cpu_seconds", "cpu_seconds_max"), ("network_bytes_out", "network_bytes_max"), ("tool_calls", None), ("api_calls", "api_calls"), ("disk_bytes_write", "disk_bytes_write_max")]
        for budget_name, resource_name in checks:
            if resource_name is None: continue
            available = float(b.get(budget_name, 0))
            declared = float(res.get(resource_name, 0))
            if declared > available: raise ToolPolicyDenied(f"insufficient budget headroom for {budget_name}")

    def _rate_key(self, tenant: str, ref: str, caller: str) -> tuple[str, str, str]: return (tenant, ref, caller)

    def _acquire_rate(self, tenant: str, manifest: Mapping[str, Any], caller: str) -> None:
        ref = _manifest_ref(manifest); key = self._rate_key(tenant, ref, caller); history = self._rate_history[key]; now = time.monotonic()
        rate = manifest.get("rate_limit") or {"calls": self.config.default_rate_limit, "window_seconds": self.config.rate_limit_window_seconds}
        limit = int(rate.get("calls", self.config.default_rate_limit)); window = float(rate.get("window_seconds", self.config.rate_limit_window_seconds))
        while history and history[0] <= now-window: history.popleft()
        if len(history) >= limit: raise RateLimited(f"rate limit exceeded for {ref}")
        history.append(now)

    def _acquire_concurrency(self, tenant: str, manifest: Mapping[str, Any], caller: str) -> threading.BoundedSemaphore:
        key = self._rate_key(tenant, _manifest_ref(manifest), caller)
        with self._idempotency_lock:
            limit = int(manifest.get("concurrency_limit") or 1)
            sem = self._semaphores.setdefault(key, threading.BoundedSemaphore(limit))
        if not sem.acquire(blocking=False): raise ConcurrencyLimited("tool concurrency limit exceeded")
        return sem

    def _invoke_adapter(self, manifest: Mapping[str, Any], request: Mapping[str, Any], target: Any) -> Mapping[str, Any]:
        adapter = self.adapters.get(str(manifest["invocation_kind"]))
        if adapter is None: raise AdapterError(f"no adapter for {manifest['invocation_kind']}")
        return adapter.invoke(request, target, manifest)

    def invoke(self, request: Mapping[str, Any], *, context: ExecutionContext, plan_ref: str | None = None, skill_ref: str | None = None, ad_hoc_authorization: Mapping[str, Any] | None = None) -> InvocationResult:
        tenant = _tenant_from_context(context, str(request.get("tenant_id", self.config.default_tenant_id)))
        _require_scope(context, AUTH_INVOKE_SCOPE)
        invocation_id = str(request.get("invocation_id", _uuid())); ref = str(request["tool_ref"]); started = _utc()
        self._emit("Invoked", {"invocation_id": invocation_id, "tool_ref": ref}, context, tenant)
        manifest = self.registry.get_ref(ref, tenant_id=tenant)
        if str(request.get("manifest_hash")) != str(manifest["manifest_hash"]): raise ToolIntegrityError("manifest hash mismatch")
        try:
            self._authorize_manifest(manifest, context, plan_ref=plan_ref, skill_ref=skill_ref, ad_hoc_authorization=ad_hoc_authorization)
        except (ToolAccessDenied, ToolPolicyDenied, ToolRevoked, ToolRetired) as exc:
            self._emit("InvocationDenied", {"invocation_id": invocation_id, "tool_ref": ref, "reason": str(exc)}, context, tenant)
            self._emit_security_denied({"tool_ref": ref, "invocation_id": invocation_id, "reason": str(exc)}, context, tenant)
            raise
        try:
            input_schema = self._resolve_schema(str(manifest["inputs"]["schema_ref"]))
            SchemaValidator().validate_or_raise(dict(request.get("inputs", {})), dict(input_schema))
        except Exception as exc:
            self._emit("InvocationFailed", {"invocation_id": invocation_id, "tool_ref": ref, "failure_class": "schema_violation", "error": str(exc)}, context, tenant)
            raise SchemaViolation(str(exc)) from exc
        self._check_budget_headroom(manifest, context)
        deterministic_declared = str(manifest["determinism"]["declared"])
        seed = request.get("seed")
        if deterministic_declared == "deterministic" and not manifest["determinism"].get("proof_ref"): raise DeterminismUnavailable("deterministic tool lacks proof")
        if deterministic_declared == "seeded" and manifest["determinism"].get("seed_parameter") and seed is None: raise DeterminismUnavailable("seeded tool requires seed")
        if deterministic_declared == "nondeterministic" and bool(getattr(context, "deterministic", False)): raise DeterminismUnavailable("nondeterministic tool refused in deterministic execution")
        idem_decl = str(manifest["idempotency"]["declared"]); idem_key = request.get("idempotency_key")
        if idem_decl == "per_key":
            if not idem_key: raise IdempotencyViolation("idempotency key required")
            with self._idempotency_lock, self.registry.db:
                self.registry.remember_idempotency(tenant, ref, str(getattr(context.auth_context, "principal", "unknown")), str(idem_key), _sha(request.get("inputs", {})), time.time(), self.config.idempotency_window_seconds)
        caller = str(getattr(context.auth_context, "principal", "unknown")); self._acquire_rate(tenant, manifest, caller); sem = self._acquire_concurrency(tenant, manifest, caller)
        dry_run = bool(request.get("dry_run", False))
        if dry_run and not bool(manifest.get("supports_dry_run", False)): sem.release(); raise ToolPolicyDenied("tool does not declare supports_dry_run")
        target = self.targets.get((tenant, ref))
        if target is None: sem.release(); raise ToolNotFound(f"runtime target not registered for {ref}")
        timeout_ms = min(int(request.get("timeout_ms", manifest["timeout_ms_default"])), int(manifest["timeout_ms_max"]))
        adapter_request = {"invocation_id": invocation_id, "inputs": dict(request.get("inputs", {})), "execution_context": context, "timeout_ms": timeout_ms, "idempotency_key": idem_key, "seed": seed, "dry_run": dry_run}
        try:
            raw = self._invoke_adapter(manifest, adapter_request, target)
            outputs = raw.get("outputs") if isinstance(raw, Mapping) else raw
            output_schema = self._resolve_schema(str(manifest["outputs"]["schema_ref"]))
            SchemaValidator().validate_or_raise(outputs, dict(output_schema))
            finished = _utc(); latency_ms = max(0.0, (datetime.fromisoformat(finished.replace("Z", "+00:00"))-datetime.fromisoformat(started.replace("Z", "+00:00"))).total_seconds()*1000)
            key = (tenant, ref); output_hash = _sha(outputs)
            observed = "deterministic" if deterministic_declared == "deterministic" else "seeded" if deterministic_declared == "seeded" else "nondeterministic"
            prior = self._observed_outputs.get(key)
            if prior is not None and deterministic_declared in {"deterministic", "seeded"} and prior != output_hash:
                observed = "deviation"; self._emit("DeterminismDeviation", {"invocation_id": invocation_id, "tool_ref": ref, "previous_output_hash": prior, "current_output_hash": output_hash}, context, tenant)
            else: self._observed_outputs[key] = output_hash
            resources = {"cpu_seconds": latency_ms/1000.0, "ram_peak_mb": 0, "network_bytes": 0, "api_calls": 1 if manifest["invocation_kind"] in {"http", "rpc", "mcp"} else 0, "cost_units": float(manifest["resources"].get("cost_units_typical",0.0)), "latency_ms": latency_ms}
            if self.accounting_hook: self.accounting_hook(tenant, resources, context)
            signature_body = {"invocation_id": invocation_id, "status": "success", "outputs_hash": output_hash, "resources_used": resources, "idempotency_key": idem_key, "seed": seed}
            result = InvocationResult(invocation_id, "success", outputs, None, resources, False, None, idem_key, seed, observed, started, finished, _b64(self.signer.sign(canonical_bytes(signature_body))))
            self._emit("InvocationCompleted", {"invocation_id": invocation_id, "tool_ref": ref, "status": "success", "latency_ms": latency_ms}, context, tenant)
            return result
        except (RateLimited, ConcurrencyLimited, ToolPolicyDenied, ToolRevoked, ToolRetired):
            raise
        except subprocess.TimeoutExpired as exc:
            self._emit("InvocationFailed", {"invocation_id": invocation_id, "tool_ref": ref, "failure_class": "timeout"}, context, tenant); raise ToolTimeout(str(exc)) from exc
        except Exception as exc:
            failure_class = "unavailable" if isinstance(exc, AdapterError) else "unknown"
            self._emit("InvocationFailed", {"invocation_id": invocation_id, "tool_ref": ref, "failure_class": failure_class, "error": str(exc)}, context, tenant)
            raise
        finally:
            sem.release()

    def health(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None) -> ToolHealth:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, AUTH_READ_SCOPE)
        manifest = self.registry.get_ref(ref, tenant_id=tenant); adapter = self.adapters[manifest["invocation_kind"]]; target = self.targets.get((tenant, ref));
        budgets = getattr(context, "budgets", None)
        if budgets is None or float(getattr(budgets, "wall_seconds", 0.0)) <= 0.001: raise HealthBudgetExceeded("health check has insufficient wall-time budget")
        started = time.perf_counter()
        try: report = adapter.probe(ref, target, manifest, context); available = bool(report.get("available"))
        except Exception: available = False
        latency = (time.perf_counter()-started)*1000.0
        previous = self._health.get((tenant, ref))
        errors = 0.0 if available else 1.0
        if previous: errors = (previous.error_rate*0.8)+(0.2 if not available else 0.0)
        status = ToolHealth(ref, available, latency, latency, min(1.0,errors), {"remaining": None}, bool(errors>0.5), {"available": available}, _utc())
        self._health[(tenant, ref)] = status
        self._emit("HealthChanged", {"tool_ref": ref, "available": available, "latency_ms": latency, "error_rate": status.error_rate}, context, tenant)
        if status.degradation: self._emit("Degraded", {"tool_ref": ref, "reason": "measured_unavailable"}, context, tenant)
        return status

    def probe(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None) -> Mapping[str, Any]:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, AUTH_READ_SCOPE); manifest = self.registry.get_ref(ref, tenant_id=tenant); return self.adapters[manifest["invocation_kind"]].probe(ref, self.targets.get((tenant,ref)), manifest, context)

    def mark_degraded(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> None:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin"); current = self._health.get((tenant,ref)); now = _utc()
        if current:
            self._health[(tenant,ref)] = ToolHealth(current.tool_ref,current.availability,current.p50_latency_ms,current.p95_latency_ms,current.error_rate,current.rate_limit_state,True,current.dependencies_health,now)
        else:
            self._health[(tenant,ref)] = ToolHealth(ref,False,0.0,0.0,1.0,{"remaining":None},True,{"available":False},now)
        self._emit("Degraded", {"tool_ref": ref, "reason": reason}, context, tenant)

    def clear_degraded(self, ref: str, *, context: ExecutionContext, tenant_id: str | None = None, reason: str = "") -> None:
        tenant = _tenant_from_context(context, tenant_id or self.config.default_tenant_id); _require_scope(context, "tools.admin"); current = self._health.get((tenant,ref)); now = _utc()
        if current: self._health[(tenant,ref)] = ToolHealth(current.tool_ref,current.availability,current.p50_latency_ms,current.p95_latency_ms,current.error_rate,current.rate_limit_state,False,current.dependencies_health,now)
        self._emit("DegradationCleared", {"tool_ref": ref, "reason": reason}, context, tenant)

    def replay(self, *, tenant_id: str, limit: int = 1000) -> list[dict[str, Any]]:
        return self.registry.history_for_replay(tenant_id=tenant_id, limit=limit)

    def events(self) -> list[dict[str, Any]]: return list(self._event_log)

    def replay_events(self, *, correlation_id: str | None = None, tenant_id: str | None = None, limit: int = 1000) -> list[dict[str, Any]]:
        rows = list(self._event_log)
        if tenant_id is not None: rows = [r for r in rows if str(r.get("tenant_id")) == str(tenant_id)]
        if correlation_id is not None: rows = [r for r in rows if str(r.get("correlation_id")) == str(correlation_id)]
        return rows[:max(0, int(limit))]

    def close(self) -> None:
        if self._closed: return
        self._closed = True
        for (tenant, ref), target in list(self.targets.items()):
            try:
                manifest = self.registry.get_ref(ref, tenant_id=tenant); self.adapters[manifest["invocation_kind"]].shutdown(ref, target, manifest)
            except Exception as exc:
                self._shutdown_errors.append({"tool_ref": str(ref), "error": repr(exc)})
        self.registry.close()

    def __enter__(self) -> "ToolFabric": return self
    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None: self.close()


def sign_adhoc_authorization(tool_ref: str, tenant_id: str, principal: str, signer: Ed25519PrivateKey, key_id: str, *, ttl_seconds: int = 300) -> dict[str, Any]:
    body = {"tool_ref": tool_ref, "tenant_id": tenant_id, "principal": principal, "key_id": key_id, "expires_at": time.time()+max(1,int(ttl_seconds)), "issued_at": time.time()}
    sig = _b64(signer.sign(canonical_bytes(body)))
    return {**body, "signature": sig}

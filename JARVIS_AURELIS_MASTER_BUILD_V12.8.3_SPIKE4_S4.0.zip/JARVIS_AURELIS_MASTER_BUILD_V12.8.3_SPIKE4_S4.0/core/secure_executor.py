"""Canonical J.A.R.V.I.S. 12.8.0 execution security pipeline."""
from core.kernel_12_8_0.execution import ExecutionPolicy, ExecutionRecord, KernelExecutionAuthority

SecureExecutor = KernelExecutionAuthority

__all__ = ["ExecutionPolicy", "ExecutionRecord", "KernelExecutionAuthority", "SecureExecutor"]



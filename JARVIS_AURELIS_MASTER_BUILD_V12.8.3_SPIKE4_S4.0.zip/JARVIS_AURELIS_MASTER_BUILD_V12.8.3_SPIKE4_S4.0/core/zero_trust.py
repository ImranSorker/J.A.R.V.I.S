"""Zero-trust capability leases, key rotation, revocation and action attestation.

The module is deliberately authority-oriented: every privileged operation needs a
short-lived, signed lease that is bound to a subject, audience, policy digest and
nonce. Verification is default-deny and replay resistant.
"""
from __future__ import annotations

import base64
import hashlib
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any, Mapping

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


def _canonical(value: Any) -> bytes:
    import json
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


@dataclass(frozen=True, slots=True)
class CapabilityLease:
    lease_id: str
    subject: str
    audience: str
    capabilities: tuple[str, ...]
    issued_at: float
    expires_at: float
    nonce: str
    policy_digest: str
    key_id: str
    signature_b64: str

    def unsigned(self) -> dict[str, Any]:
        return {
            "lease_id": self.lease_id,
            "subject": self.subject,
            "audience": self.audience,
            "capabilities": self.capabilities,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "nonce": self.nonce,
            "policy_digest": self.policy_digest,
            "key_id": self.key_id,
        }

    @property
    def digest(self) -> str:
        return _digest(self.unsigned())

    def allows(self, capability: str, *, now: float | None = None) -> bool:
        current = time.time() if now is None else float(now)
        if current < self.issued_at or current >= self.expires_at:
            return False
        requested = str(capability).strip()
        return requested in self.capabilities or "*" in self.capabilities


@dataclass(frozen=True, slots=True)
class ActionAttestation:
    attestation_id: str
    lease_id: str
    subject: str
    audience: str
    capability: str
    request_id: str
    request_digest: str
    policy_digest: str
    created_at: float
    key_id: str
    signature_b64: str

    def unsigned(self) -> dict[str, Any]:
        return {
            "attestation_id": self.attestation_id,
            "lease_id": self.lease_id,
            "subject": self.subject,
            "audience": self.audience,
            "capability": self.capability,
            "request_id": self.request_id,
            "request_digest": self.request_digest,
            "policy_digest": self.policy_digest,
            "created_at": self.created_at,
            "key_id": self.key_id,
        }


class ZeroTrustAuthority:
    """Thread-safe signing authority with rotation and emergency revocation."""

    def __init__(self, *, issuer: str = "jarvis-zero-trust", max_lease_seconds: float = 900.0) -> None:
        if max_lease_seconds <= 0:
            raise ValueError("max_lease_seconds must be positive")
        self.issuer = str(issuer)
        self.max_lease_seconds = min(float(max_lease_seconds), 3600.0)
        self._lock = threading.RLock()
        self._private = Ed25519PrivateKey.generate()
        self._public = self._private.public_key()
        self._key_id = self._new_key_id()
        self._keys: dict[str, Ed25519PublicKey] = {self._key_id: self._public}
        self._revoked_leases: set[str] = set()
        self._revoked_subjects: set[str] = set()
        self._used_nonces: dict[str, float] = {}

    @staticmethod
    def _new_key_id() -> str:
        return f"ztk_{uuid.uuid4().hex}"

    @property
    def key_id(self) -> str:
        return self._key_id

    @property
    def public_key_b64(self) -> str:
        raw = self._public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return base64.b64encode(raw).decode("ascii")

    def rotate_key(self) -> str:
        """Rotate the signing key while retaining old public keys for verification."""
        with self._lock:
            self._private = Ed25519PrivateKey.generate()
            self._public = self._private.public_key()
            self._key_id = self._new_key_id()
            self._keys[self._key_id] = self._public
            return self._key_id

    def issue_lease(
        self,
        *,
        subject: str,
        audience: str,
        capabilities: tuple[str, ...] | list[str],
        policy_digest: str,
        ttl_seconds: float,
        now: float | None = None,
    ) -> CapabilityLease:
        current = time.time() if now is None else float(now)
        ttl = min(max(float(ttl_seconds), 0.1), self.max_lease_seconds)
        normalized = tuple(sorted({str(c).strip() for c in capabilities if str(c).strip()}))
        if not subject.strip() or not audience.strip() or not normalized or not policy_digest.strip():
            raise ValueError("subject, audience, capabilities and policy_digest are required")
        with self._lock:
            if subject in self._revoked_subjects:
                raise PermissionError("subject is revoked")
            lease = CapabilityLease(
                lease_id=f"lease_{uuid.uuid4().hex}", subject=subject.strip(), audience=audience.strip(),
                capabilities=normalized, issued_at=current, expires_at=current + ttl,
                nonce=uuid.uuid4().hex, policy_digest=policy_digest.strip(), key_id=self._key_id, signature_b64="",
            )
            signature = self._private.sign(_canonical(lease.unsigned()))
            from dataclasses import replace
            return replace(lease, signature_b64=base64.b64encode(signature).decode("ascii"))

    def verify_lease(
        self,
        lease: CapabilityLease,
        *,
        subject: str,
        audience: str,
        capability: str,
        policy_digest: str,
        now: float | None = None,
        consume_nonce: bool = True,
    ) -> bool:
        current = time.time() if now is None else float(now)
        with self._lock:
            if lease.lease_id in self._revoked_leases or lease.subject in self._revoked_subjects:
                return False
            if lease.subject != str(subject) or lease.audience != str(audience) or lease.policy_digest != str(policy_digest):
                return False
            if not lease.allows(capability, now=current):
                return False
            key = self._keys.get(lease.key_id)
            if key is None:
                return False
            try:
                key.verify(base64.b64decode(lease.signature_b64, validate=True), _canonical(lease.unsigned()))
            except Exception:
                return False
            if consume_nonce:
                prior = self._used_nonces.get(lease.nonce)
                if prior is not None:
                    return False
                self._used_nonces[lease.nonce] = lease.expires_at
                self._prune_nonces(current)
            return True

    def revoke_lease(self, lease_id: str) -> None:
        with self._lock:
            self._revoked_leases.add(str(lease_id))

    def revoke_subject(self, subject: str) -> None:
        with self._lock:
            self._revoked_subjects.add(str(subject))

    def emergency_revoke(self, *, lease_ids: tuple[str, ...] = (), subjects: tuple[str, ...] = ()) -> None:
        with self._lock:
            self._revoked_leases.update(str(x) for x in lease_ids)
            self._revoked_subjects.update(str(x) for x in subjects)

    def attest_action(
        self,
        lease: CapabilityLease,
        *,
        capability: str,
        request_id: str,
        request: Mapping[str, Any] | Any,
        policy_digest: str,
        now: float | None = None,
    ) -> ActionAttestation:
        current = time.time() if now is None else float(now)
        if not self.verify_lease(lease, subject=lease.subject, audience=lease.audience, capability=capability, policy_digest=policy_digest, now=current, consume_nonce=False):
            raise PermissionError("lease is not valid for action attestation")
        att = ActionAttestation(
            attestation_id=f"att_{uuid.uuid4().hex}", lease_id=lease.lease_id, subject=lease.subject,
            audience=lease.audience, capability=str(capability), request_id=str(request_id),
            request_digest=_digest(request), policy_digest=str(policy_digest), created_at=current,
            key_id=self._key_id, signature_b64="",
        )
        sig = self._private.sign(_canonical(att.unsigned()))
        from dataclasses import replace
        return replace(att, signature_b64=base64.b64encode(sig).decode("ascii"))

    def verify_attestation(self, attestation: ActionAttestation, *, request: Mapping[str, Any] | Any, max_age_seconds: float = 300.0, now: float | None = None) -> bool:
        current = time.time() if now is None else float(now)
        with self._lock:
            key = self._keys.get(attestation.key_id)
            if key is None or attestation.lease_id in self._revoked_leases or attestation.subject in self._revoked_subjects:
                return False
            if current - attestation.created_at > max(1.0, min(float(max_age_seconds), 3600.0)):
                return False
            if attestation.request_digest != _digest(request):
                return False
            try:
                key.verify(base64.b64decode(attestation.signature_b64, validate=True), _canonical(attestation.unsigned()))
            except Exception:
                return False
            return True

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "issuer": self.issuer,
                "key_id": self._key_id,
                "known_keys": len(self._keys),
                "revoked_leases": len(self._revoked_leases),
                "revoked_subjects": len(self._revoked_subjects),
                "replay_nonces": len(self._used_nonces),
            }

    def _prune_nonces(self, now: float) -> None:
        stale = [nonce for nonce, expiry in self._used_nonces.items() if expiry <= now]
        for nonce in stale:
            self._used_nonces.pop(nonce, None)

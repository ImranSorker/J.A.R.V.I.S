"""Contract-first registry for J.A.R.V.I.S. native and service runtimes.

The registry deliberately contains metadata and health contracts only. It never
executes arbitrary commands and therefore cannot become an alternate security
boundary. Native/service execution remains behind the configured policy and
execution brokers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import platform
import time
from typing import Callable, Mapping


@dataclass(frozen=True, slots=True)
class RuntimeDescriptor:
    """Describe a language runtime that can participate in J.A.R.V.I.S."""

    name: str
    language: str
    role: str
    protocol: str
    version: str
    capabilities: tuple[str, ...] = ()
    enabled: bool = True


@dataclass(frozen=True, slots=True)
class RuntimeHealth:
    """Immutable health result for a registered runtime."""

    name: str
    operational: bool
    latency_ms: float
    detail: str

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "operational": self.operational,
            "latency_ms": round(self.latency_ms, 3),
            "detail": self.detail,
        }


@dataclass(slots=True)
class _RuntimeEntry:
    descriptor: RuntimeDescriptor
    probe: Callable[[], bool] | None = None
    metadata: dict[str, str] = field(default_factory=dict)


class PolyglotRuntimeRegistry:
    """Manage explicit language-runtime contracts without creating hidden coupling."""

    def __init__(self) -> None:
        self._entries: dict[str, _RuntimeEntry] = {}

    def register(
        self,
        descriptor: RuntimeDescriptor,
        *,
        probe: Callable[[], bool] | None = None,
        metadata: Mapping[str, str] | None = None,
    ) -> None:
        """Register one uniquely named runtime contract."""
        key = descriptor.name.strip().lower()
        if not key:
            raise ValueError("runtime name must not be empty")
        if key in self._entries:
            raise ValueError(f"runtime already registered: {descriptor.name}")
        if not descriptor.language.strip() or not descriptor.protocol.strip():
            raise ValueError("runtime language and protocol are required")
        self._entries[key] = _RuntimeEntry(descriptor, probe, dict(metadata or {}))

    def get(self, name: str) -> RuntimeDescriptor:
        """Return a registered runtime descriptor or raise KeyError."""
        return self._entries[name.strip().lower()].descriptor

    def list(self) -> list[RuntimeDescriptor]:
        """Return deterministic runtime descriptors."""
        return [self._entries[key].descriptor for key in sorted(self._entries)]

    def health(self, name: str | None = None) -> list[RuntimeHealth]:
        """Probe one runtime or all runtimes with bounded local checks."""
        keys = [name.strip().lower()] if name else sorted(self._entries)
        results: list[RuntimeHealth] = []
        for key in keys:
            entry = self._entries[key]
            start = time.perf_counter()
            if not entry.descriptor.enabled:
                results.append(RuntimeHealth(entry.descriptor.name, False, 0.0, "disabled"))
                continue
            try:
                operational = bool(entry.probe()) if entry.probe else True
                detail = "operational" if operational else "probe reported unavailable"
            except Exception as exc:
                operational = False
                detail = f"probe failed: {type(exc).__name__}: {exc}"
            results.append(RuntimeHealth(entry.descriptor.name, operational, (time.perf_counter() - start) * 1000, detail))
        return results

    def manifest(self) -> dict[str, object]:
        """Return a machine-readable interoperability manifest."""
        return {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "runtimes": [
                {
                    "name": item.descriptor.name,
                    "language": item.descriptor.language,
                    "role": item.descriptor.role,
                    "protocol": item.descriptor.protocol,
                    "version": item.descriptor.version,
                    "capabilities": list(item.descriptor.capabilities),
                    "enabled": item.descriptor.enabled,
                    "metadata": dict(item.metadata),
                }
                for item in (self._entries[key] for key in sorted(self._entries))
            ],
        }



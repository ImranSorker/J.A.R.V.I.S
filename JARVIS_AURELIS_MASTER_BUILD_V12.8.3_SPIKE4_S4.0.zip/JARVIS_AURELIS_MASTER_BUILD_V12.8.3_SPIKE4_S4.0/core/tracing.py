"""Distributed tracing and correlation ID propagation.

Provides ContextVar-based request correlation that flows through:
  API request -> JARVISCore -> ToolRegistry -> JobEngine -> JobStep execution
"""
from __future__ import annotations

import contextvars
import uuid
from typing import Any, Callable

_REQUEST_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar("jarvis_request_id", default=None)
_SESSION_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar("jarvis_session_id", default=None)
_JOB_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar("jarvis_job_id", default=None)
_AGENT_ID: contextvars.ContextVar[str | None] = contextvars.ContextVar("jarvis_agent_id", default=None)


class TraceContext:
    """Immutable snapshot of correlation IDs for propagation across thread boundaries."""

    __slots__ = ("request_id", "session_id", "job_id", "agent_id")

    def __init__(
        self,
        request_id: str | None = None,
        session_id: str | None = None,
        job_id: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        self.request_id = request_id or _REQUEST_ID.get() or f"req_{uuid.uuid4().hex[:16]}"
        self.session_id = session_id or _SESSION_ID.get() or "default"
        self.job_id = job_id or _JOB_ID.get()
        self.agent_id = agent_id or _AGENT_ID.get()

    def to_dict(self) -> dict[str, str | None]:
        return {
            "request_id": self.request_id,
            "session_id": self.session_id,
            "job_id": self.job_id,
            "agent_id": self.agent_id,
        }

    def apply(self) -> None:
        """Restore this context into the current execution context."""
        _REQUEST_ID.set(self.request_id)
        _SESSION_ID.set(self.session_id)
        if self.job_id:
            _JOB_ID.set(self.job_id)
        if self.agent_id:
            _AGENT_ID.set(self.agent_id)

    @classmethod
    def current(cls) -> "TraceContext":
        return cls()


def get_request_id() -> str:
    return _REQUEST_ID.get() or f"req_{uuid.uuid4().hex[:16]}"


def get_session_id() -> str:
    return _SESSION_ID.get() or "default"


def set_request_id(request_id: str | None) -> None:
    _REQUEST_ID.set(request_id)


def set_session_id(session_id: str | None) -> None:
    _SESSION_ID.set(session_id)


def set_job_id(job_id: str | None) -> None:
    _JOB_ID.set(job_id)


def set_agent_id(agent_id: str | None) -> None:
    _AGENT_ID.set(agent_id)


def with_trace_context(func: Callable[..., Any], context: TraceContext) -> Callable[..., Any]:
    """Decorator factory that restores a TraceContext before calling func.

    Use this when submitting work to thread pools so correlation IDs survive
    the thread boundary.
    """

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        context.apply()
        return func(*args, **kwargs)

    return wrapper



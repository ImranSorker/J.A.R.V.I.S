"""Single policy gateway for capability, authorization, autonomy and risk decisions."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Callable, Iterable
import logging
import time
import uuid

logger = logging.getLogger("jarvis.policy_gateway")

from core.autonomy import AutonomyEngine, AutonomyLevel, AutonomyDenied
from core.permission_engine import PermissionEngine


class RiskLevel(StrEnum):
    """Action impact classification."""
    L0 = "l0"
    L1 = "l1"
    L2 = "l2"
    L3 = "l3"
    L4 = "l4"
    L5 = "l5"


@dataclass(frozen=True, slots=True)
class AuthorizationDecision:
    """Auditable policy decision."""
    allowed: bool
    risk: RiskLevel
    reason: str
    capability: str
    mission_id: str | None = None
    decision_id: str = ""
    timestamp: float = 0.0


class PolicyGateway:
    """Fail-closed capability gateway shared by tools, agents and missions."""

    RISK_AUTONOMY = {RiskLevel.L0: AutonomyLevel.OBSERVE, RiskLevel.L1: AutonomyLevel.RECOMMEND, RiskLevel.L2: AutonomyLevel.REVERSIBLE, RiskLevel.L3: AutonomyLevel.BOUNDED, RiskLevel.L4: AutonomyLevel.HIGH_IMPACT, RiskLevel.L5: AutonomyLevel.HIGH_IMPACT}

    def __init__(self, permissions: PermissionEngine, autonomy: AutonomyEngine, event_sink: Callable[[Any], Any] | None = None, safety_controller: Any | None = None, decision_ledger: Any | None = None) -> None:
        self.permissions = permissions
        self.autonomy = autonomy
        self.event_sink = event_sink
        self.safety_controller = safety_controller
        self.decision_ledger = decision_ledger

    def _decision(self, allowed: bool, risk: RiskLevel, reason: str, capability: str, mission_id: str | None) -> AuthorizationDecision:
        """Create and optionally publish an auditable policy decision."""
        decision = AuthorizationDecision(allowed, risk, reason, capability, mission_id, uuid.uuid4().hex, time.time())
        ledger = getattr(self, "decision_ledger", None)
        if ledger is not None:
            try:
                ledger.record(actor="policy_gateway", action="capability.evaluate", capability=capability, policy="policy_gateway", allowed=allowed, reason=reason, risk=risk.value, resource=mission_id or "*")
            except Exception:
                logger.exception("policy_decision_ledger_failed")
        if self.event_sink is not None:
            try:
                from core.contracts.event import Event
                self.event_sink(Event.new("policy.decision", "policy_gateway", {"decision_id": decision.decision_id, "allowed": allowed, "risk": risk.value, "reason": reason, "capability": capability, "mission_id": mission_id}))
            except Exception:
                logger.exception("policy_event_emit_failed")
        return decision

    def evaluate(self, *, capability: str, risk: RiskLevel = RiskLevel.L0, mission_id: str | None = None, grant: str | None = None, required_capabilities: Iterable[str] = ()) -> AuthorizationDecision:
        """Return a fail-closed authorization decision."""
        cap = str(capability).strip()
        if not cap:
            return self._decision(False, risk, "missing capability", cap, mission_id)
        safety = getattr(self, "safety_controller", None)
        if safety is not None:
            try:
                mutation = risk in {RiskLevel.L2, RiskLevel.L3, RiskLevel.L4, RiskLevel.L5}
                if not safety.permits(risk=risk.value, mutation=mutation):
                    return self._decision(False, risk, "runtime safety mode blocks capability", cap, mission_id)
            except Exception:
                return self._decision(False, risk, "runtime safety controller unavailable", cap, mission_id)
        if mission_id:
            mission = self.autonomy.get_mission(mission_id)
            if mission is None:
                return self._decision(False, risk, "unknown mission", cap, mission_id)
            if mission.level < self.RISK_AUTONOMY[risk]:
                return self._decision(False, risk, "autonomy level insufficient", cap, mission_id)
            try:
                self.autonomy.authorize(mission_id, action=risk.value, required_capabilities=tuple(required_capabilities), granted_capabilities=mission.metadata.get("granted_capabilities", ()))
            except AutonomyDenied as exc:
                return self._decision(False, risk, str(exc), cap, mission_id)
        if grant is not None and not self.permissions.verify(grant, capability=cap):
            return self._decision(False, risk, "invalid authorization grant", cap, mission_id)
        if risk in {RiskLevel.L4, RiskLevel.L5} and not grant:
            return self._decision(False, risk, "explicit authorization required", cap, mission_id)
        return self._decision(True, risk, "authorized", cap, mission_id)



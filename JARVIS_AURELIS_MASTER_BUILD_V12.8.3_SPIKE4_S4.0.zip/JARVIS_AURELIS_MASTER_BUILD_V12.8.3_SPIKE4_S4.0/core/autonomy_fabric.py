"""Durable, policy-governed autonomy fabric for goals and missions.

The fabric is the authoritative mission lifecycle. Older executive, swarm and
job components may be used behind adapters, but they do not own mission state.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from core.contracts.autonomy import (
    Goal,
    GoalStatus,
    MissionStatus,
    MissionStepSpec,
    VerificationGateResult,
)
from core.contracts.event import Event

logger = logging.getLogger("jarvis.autonomy_fabric")


@dataclass(frozen=True, slots=True)
class MissionRecord:
    """Persisted mission state with monotonic revision metadata."""

    mission_id: str
    goal_id: str
    status: MissionStatus = MissionStatus.CREATED
    completed_steps: tuple[str, ...] = ()
    attempts: int = 0
    revision: int = 0
    result: Any = None
    error: str | None = None
    updated_at: float = 0.0
    plan: tuple[MissionStepSpec, ...] = ()


class _AtomicJSONStore:
    """Small reusable atomic JSON persistence primitive."""

    def __init__(self, path: str, prefix: str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._prefix = prefix

    def _write(self, payload: Any) -> None:
        fd, temporary = tempfile.mkstemp(
            prefix=f".{self._prefix}.", suffix=".tmp", dir=str(self.path.parent)
        )
        temporary_path = Path(temporary)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, sort_keys=True, separators=(",", ":"), default=str)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, self.path)
        finally:
            temporary_path.unlink(missing_ok=True)

    def _read(self) -> Any:
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            logger.exception("autonomy_state_restore_failed", extra={"path": str(self.path)})
            return []


class GoalStore(_AtomicJSONStore):
    """Atomic JSON goal store behind the GoalProvider contract."""

    def __init__(self, path: str = "data/goals.json") -> None:
        super().__init__(path, "goals")
        self._goals: dict[str, Goal] = {}
        self._load()

    def _load(self) -> None:
        with self._lock:
            rows = self._read()
            if not isinstance(rows, list):
                logger.warning("goal_store_invalid_root", extra={"path": str(self.path)})
                return
            for raw in rows:
                if not isinstance(raw, Mapping) or "goal_id" not in raw:
                    continue
                try:
                    self._goals[str(raw["goal_id"])] = Goal(
                        goal_id=str(raw["goal_id"]),
                        objective=str(raw.get("objective", "")),
                        priority=int(raw.get("priority", 5)),
                        owner=str(raw.get("owner", "jarvis")),
                        constraints=dict(raw.get("constraints", {})),
                        success_criteria=tuple(raw.get("success_criteria", ())),
                        capabilities=tuple(raw.get("capabilities", ())),
                        deadline=raw.get("deadline"),
                        status=GoalStatus(str(raw.get("status", GoalStatus.QUEUED.value))),
                    )
                except (TypeError, ValueError, KeyError):
                    logger.warning("goal_store_row_rejected", extra={"row": dict(raw)})

    def _save(self) -> None:
        payload: list[dict[str, Any]] = []
        for goal in sorted(self._goals.values(), key=lambda item: item.goal_id):
            row = asdict(goal)
            row["status"] = goal.status.value
            payload.append(row)
        self._write(payload)

    def create(self, goal: Goal) -> Goal:
        """Persist a new goal atomically."""
        objective = goal.objective.strip()
        if not objective:
            raise ValueError("goal objective is required")
        with self._lock:
            if goal.goal_id in self._goals:
                raise ValueError("goal already exists")
            self._goals[goal.goal_id] = goal
            self._save()
        return goal

    def get(self, goal_id: str) -> Goal | None:
        """Return a single goal snapshot."""
        with self._lock:
            return self._goals.get(goal_id)

    def count(self) -> int:
        """Return the number of durable goals."""
        with self._lock:
            return len(self._goals)

    def snapshot(self) -> dict[str, dict[str, Any]]:
        """Return a complete, serialization-safe goal snapshot."""
        with self._lock:
            return {
                goal.goal_id: {
                    "goal_id": goal.goal_id,
                    "objective": goal.objective,
                    "priority": goal.priority,
                    "owner": goal.owner,
                    "constraints": dict(goal.constraints),
                    "success_criteria": list(goal.success_criteria),
                    "capabilities": list(goal.capabilities),
                    "deadline": goal.deadline,
                    "status": goal.status.value,
                }
                for goal in sorted(self._goals.values(), key=lambda item: item.goal_id)
            }

    def export_state(self) -> dict[str, dict[str, Any]]:
        """Export the complete durable goal domain for portable state."""
        return self.snapshot()

    def import_state(self, state: Mapping[str, Any]) -> None:
        """Atomically replace goals from a validated portable state domain."""
        if not isinstance(state, Mapping):
            raise ValueError("goal state must be a mapping")
        restored: dict[str, Goal] = {}
        for key, raw in state.items():
            if not isinstance(raw, Mapping):
                raise ValueError(f"invalid goal state: {key}")
            goal_id = str(raw.get("goal_id", key))
            restored[goal_id] = Goal(
                goal_id=goal_id, objective=str(raw.get("objective", "")),
                priority=int(raw.get("priority", 5)), owner=str(raw.get("owner", "jarvis")),
                constraints=dict(raw.get("constraints", {})),
                success_criteria=tuple(raw.get("success_criteria", ())),
                capabilities=tuple(raw.get("capabilities", ())), deadline=raw.get("deadline"),
                status=GoalStatus(str(raw.get("status", GoalStatus.QUEUED.value))),
            )
            if not restored[goal_id].objective.strip():
                raise ValueError(f"goal objective is required: {goal_id}")
        with self._lock:
            old = self._goals
            try:
                self._goals = restored
                self._save()
            except Exception:
                self._goals = old
                raise

    def update_status(self, goal_id: str, status: GoalStatus) -> Goal:
        """Persist an updated goal status."""
        with self._lock:
            old = self._goals.get(goal_id)
            if old is None:
                raise KeyError(goal_id)
            updated = Goal(
                old.goal_id,
                old.objective,
                old.priority,
                old.owner,
                old.constraints,
                old.success_criteria,
                old.capabilities,
                old.deadline,
                status,
            )
            self._goals[goal_id] = updated
            self._save()
            return updated


class MissionStore(_AtomicJSONStore):
    """Atomic mission journal supporting restart recovery."""

    def __init__(self, path: str = "data/missions.json") -> None:
        super().__init__(path, "missions")
        self._rows: dict[str, MissionRecord] = {}
        self._load()

    def _load(self) -> None:
        with self._lock:
            rows = self._read()
            if not isinstance(rows, list):
                logger.warning("mission_store_invalid_root", extra={"path": str(self.path)})
                return
            for raw in rows:
                if not isinstance(raw, Mapping) or "mission_id" not in raw or "goal_id" not in raw:
                    continue
                try:
                    record = MissionRecord(
                        mission_id=str(raw["mission_id"]),
                        goal_id=str(raw["goal_id"]),
                        status=MissionStatus(str(raw.get("status", MissionStatus.CREATED.value))),
                        completed_steps=tuple(raw.get("completed_steps", ())),
                        attempts=int(raw.get("attempts", 0)),
                        revision=int(raw.get("revision", 0)),
                        result=raw.get("result"),
                        error=raw.get("error"),
                        updated_at=float(raw.get("updated_at", 0.0)),
                        plan=tuple(
                            MissionStepSpec(
                                step_id=str(step.get("step_id", "")),
                                name=str(step.get("name", "")),
                                dependencies=tuple(step.get("dependencies", ())),
                                metadata=dict(step.get("metadata", {})),
                                capability=str(step.get("capability", "observe")),
                            )
                            for step in raw.get("plan", ()) if isinstance(step, Mapping)
                        ),
                    )
                    self._rows[record.mission_id] = record
                except (TypeError, ValueError, KeyError):
                    logger.warning("mission_store_row_rejected", extra={"row": dict(raw)})

    def _save(self) -> None:
        payload = []
        for record in sorted(self._rows.values(), key=lambda item: item.mission_id):
            row = asdict(record)
            row["status"] = record.status.value
            payload.append(row)
        self._write(payload)

    def put(self, row: MissionRecord) -> MissionRecord:
        """Persist a mission record."""
        with self._lock:
            self._rows[row.mission_id] = row
            self._save()
        return row

    def get(self, mission_id: str) -> MissionRecord | None:
        """Return a single mission snapshot."""
        with self._lock:
            return self._rows.get(mission_id)

    def list(self) -> list[MissionRecord]:
        """Return deterministic mission snapshots."""
        with self._lock:
            return sorted(self._rows.values(), key=lambda item: item.mission_id)

    def snapshot(self) -> dict[str, dict[str, Any]]:
        """Return a complete, serialization-safe mission snapshot."""
        with self._lock:
            return {
                row.mission_id: {
                    "mission_id": row.mission_id,
                    "goal_id": row.goal_id,
                    "status": row.status.value,
                    "completed_steps": list(row.completed_steps),
                    "attempts": row.attempts,
                    "revision": row.revision,
                    "result": row.result,
                    "error": row.error,
                    "updated_at": row.updated_at,
                    "plan": [asdict(step) for step in row.plan],
                }
                for row in self.list()
            }

    def export_state(self) -> dict[str, dict[str, Any]]:
        """Export the complete durable mission domain for portable state."""
        return self.snapshot()

    def import_state(self, state: Mapping[str, Any]) -> None:
        """Atomically replace missions from a validated portable state domain."""
        if not isinstance(state, Mapping):
            raise ValueError("mission state must be a mapping")
        restored: dict[str, MissionRecord] = {}
        for key, raw in state.items():
            if not isinstance(raw, Mapping):
                raise ValueError(f"invalid mission state: {key}")
            mission_id = str(raw.get("mission_id", key))
            goal_id = str(raw.get("goal_id", ""))
            if not goal_id:
                raise ValueError(f"mission goal_id is required: {mission_id}")
            restored[mission_id] = MissionRecord(
                mission_id=mission_id, goal_id=goal_id,
                status=MissionStatus(str(raw.get("status", MissionStatus.CREATED.value))),
                completed_steps=tuple(raw.get("completed_steps", ())),
                attempts=int(raw.get("attempts", 0)), revision=int(raw.get("revision", 0)),
                result=raw.get("result"), error=raw.get("error"),
                updated_at=float(raw.get("updated_at", 0.0)),
                plan=tuple(
                    MissionStepSpec(
                        step_id=str(step.get("step_id", "")),
                        name=str(step.get("name", "")),
                        dependencies=tuple(step.get("dependencies", ())),
                        metadata=dict(step.get("metadata", {})),
                        capability=str(step.get("capability", "observe")),
                    )
                    for step in raw.get("plan", ()) if isinstance(step, Mapping)
                ),
            )
        with self._lock:
            old = self._rows
            try:
                self._rows = restored
                self._save()
            except Exception:
                self._rows = old
                raise


class DAGScheduler:
    """Validate mission DAGs and expose deterministic ready steps."""

    @staticmethod
    def validate(steps: Sequence[MissionStepSpec]) -> None:
        """Reject duplicate nodes, missing dependencies and cycles."""
        ids = {step.step_id for step in steps}
        if len(ids) != len(steps):
            raise ValueError("duplicate mission step id")
        graph = {step.step_id: set(step.dependencies) for step in steps}
        for step_id, dependencies in graph.items():
            missing = dependencies - ids
            if missing:
                raise ValueError(f"missing dependencies for {step_id}: {sorted(missing)}")
        seen: set[str] = set()
        visiting: set[str] = set()

        def visit(node: str) -> None:
            if node in visiting:
                raise ValueError("mission dependency cycle detected")
            if node in seen:
                return
            visiting.add(node)
            for dependency in graph[node]:
                visit(dependency)
            visiting.remove(node)
            seen.add(node)

        for node in sorted(graph):
            visit(node)

    @staticmethod
    def ready(steps: Sequence[MissionStepSpec], completed: Iterable[str]) -> list[MissionStepSpec]:
        """Return dependency-satisfied work in deterministic order."""
        completed_set = set(completed)
        DAGScheduler.validate(steps)
        return sorted(
            (
                step
                for step in steps
                if step.step_id not in completed_set and set(step.dependencies) <= completed_set
            ),
            key=lambda step: step.step_id,
        )


class VerificationGateEngine:
    """Default verification gate; domain verifiers can be injected."""

    def __init__(self, min_score: float = 1.0) -> None:
        self.min_score = max(0.0, min(1.0, float(min_score)))

    def verify(self, goal: Goal, result: Any) -> VerificationGateResult:
        """Require an explicit verified effect and non-empty evidence before completion."""
        if not isinstance(result, Mapping):
            return VerificationGateResult(False, 0.0, ("mission result is not evidence-bearing",), {"goal_id": goal.goal_id})
        if "ok" in result:
            verified = bool(result.get("verified", False))
            evidence = result.get("evidence")
            passed = bool(result.get("ok")) and verified and bool(evidence)
            reason = "verified executor result" if passed else "success requires verified outcome evidence"
            return VerificationGateResult(passed and self.min_score <= 1.0, 1.0 if passed else 0.0, (reason,), {"goal_id": goal.goal_id, "evidence_present": bool(evidence), "verified": verified})
        if not result:
            return VerificationGateResult(False, 0.0, ("no mission step results",), {"goal_id": goal.goal_id})
        missing: list[str] = []
        for key, step_result in result.items():
            if not isinstance(step_result, Mapping) or not bool(step_result.get("ok")) or not bool(step_result.get("verified")) or not bool(step_result.get("evidence")):
                missing.append(str(key))
        passed = not missing
        return VerificationGateResult(passed, 1.0 if passed else 0.0, (("all steps verified" if passed else "unverified mission steps: " + ",".join(sorted(missing))),), {"goal_id": goal.goal_id, "verified_steps": len(result) - len(missing), "step_count": len(result)})


class RollbackJournal:
    """Bounded compensation journal with explicit reverse-order actions."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._actions: dict[str, list[Callable[[], Any]]] = {}

    def register(self, mission_id: str, compensation: Callable[[], Any]) -> None:
        """Register an explicit compensation callback."""
        if not callable(compensation):
            raise TypeError("compensation must be callable")
        with self._lock:
            self._actions.setdefault(mission_id, []).append(compensation)

    def rollback(self, mission_id: str) -> list[dict[str, Any]]:
        """Run compensations in reverse registration order."""
        with self._lock:
            actions = list(reversed(self._actions.pop(mission_id, [])))
        results: list[dict[str, Any]] = []
        for action in actions:
            try:
                action()
                results.append({"ok": True})
            except Exception as exc:
                logger.exception("rollback_action_failed")
                results.append({"ok": False, "error": str(exc)})
        return results

    def clear(self, mission_id: str) -> None:
        """Discard compensation records after successful completion."""
        with self._lock:
            self._actions.pop(mission_id, None)


class BoundedSelfHealing:
    """Retry failed operations within a bounded budget and compensate on failure."""

    def __init__(self, max_attempts: int = 3, backoff_seconds: float = 0.25) -> None:
        self.max_attempts = max(1, min(10, int(max_attempts)))
        self.backoff = max(0.0, float(backoff_seconds))

    def run(
        self,
        operation: Callable[[], Any],
        checkpoint: Callable[[int], Any],
        rollback: Callable[[], Any],
    ) -> tuple[bool, Any, int]:
        """Execute the operation with bounded retries."""
        last_error: BaseException | None = None
        for attempt in range(1, self.max_attempts + 1):
            checkpoint(attempt)
            try:
                value = operation()
                if isinstance(value, Mapping) and "ok" in value and not bool(value.get("ok")):
                    raise RuntimeError(str(value.get("error", "operation reported failure")))
                return True, value, attempt
            except Exception as exc:
                last_error = exc
                logger.warning(
                    "bounded_healing_attempt_failed",
                    extra={"attempt": attempt, "error": str(exc)},
                )
                if attempt < self.max_attempts:
                    time.sleep(self.backoff * (2 ** (attempt - 1)))
        try:
            rollback()
        except Exception:
            logger.exception("bounded_healing_rollback_failed")
        return False, last_error, self.max_attempts


class AutonomyFabric:
    """Authoritative Phase-C composition root for durable autonomy."""

    _TRANSITIONS: dict[MissionStatus, set[MissionStatus]] = {
        MissionStatus.CREATED: {MissionStatus.RUNNING, MissionStatus.CANCELLED},
        MissionStatus.RUNNING: {
            MissionStatus.RUNNING,
            MissionStatus.PAUSED,
            MissionStatus.VERIFYING,
            MissionStatus.FAILED,
            MissionStatus.CANCELLED,
        },
        MissionStatus.PAUSED: {MissionStatus.RUNNING, MissionStatus.CANCELLED},
        MissionStatus.VERIFYING: {
            MissionStatus.COMPLETED,
            MissionStatus.FAILED,
            MissionStatus.ROLLED_BACK,
        },
        MissionStatus.COMPLETED: set(),
        MissionStatus.FAILED: set(),
        MissionStatus.CANCELLED: set(),
        MissionStatus.ROLLED_BACK: set(),
    }

    def __init__(
        self,
        goal_store: GoalStore,
        mission_store: MissionStore,
        event_sink: Callable[[Event], Any] | None = None,
        verification: VerificationGateEngine | None = None,
        authorization: Callable[[str, str], None] | None = None,
        policy_engine: Any | None = None,
    ) -> None:
        self.goals = goal_store
        self.missions = mission_store
        self.events = event_sink
        self.verification = verification or VerificationGateEngine()
        self.authorization = authorization
        self.policy_engine = policy_engine
        self.rollback = RollbackJournal()
        self.healing = BoundedSelfHealing()
        self._lock = threading.RLock()
        self._step_executor: Callable[[str, MissionStepSpec], Any] | None = None

    def set_step_executor(self, executor: Callable[[str, MissionStepSpec], Any] | None) -> None:
        """Bind the canonical concrete executor without creating another mission authority."""
        if executor is not None and not callable(executor):
            raise TypeError("step executor must be callable")
        with self._lock:
            self._step_executor = executor

    def create_goal(self, objective: str, **kwargs: Any) -> Goal:
        """Create and persist a first-class goal."""
        goal_id = str(kwargs.pop("goal_id", f"goal_{uuid.uuid4().hex[:12]}"))
        goal = Goal(goal_id, objective, **kwargs)
        self.goals.create(goal)
        self._emit("goal.created", {"goal_id": goal_id, "objective": objective})
        return goal

    def create_mission(
        self,
        goal: Goal,
        steps: Sequence[MissionStepSpec],
        mission_id: str | None = None,
    ) -> MissionRecord:
        """Create a durable mission and open its policy scope."""
        DAGScheduler.validate(steps)
        mission_key = mission_id or f"mission_{uuid.uuid4().hex[:12]}"
        if self.missions.get(mission_key) is not None:
            raise ValueError("mission already exists")
        if self.policy_engine is not None and hasattr(self.policy_engine, "start_mission"):
            self.policy_engine.start_mission(
                goal.objective,
                mission_id=mission_key,
                level=getattr(self.policy_engine, "level", None),
                metadata={"goal_id": goal.goal_id},
                granted_capabilities=goal.capabilities,
            )
        row = MissionRecord(mission_key, goal.goal_id, updated_at=time.time(), plan=tuple(steps))
        self.missions.put(row)
        self.goals.update_status(goal.goal_id, GoalStatus.RUNNING)
        self._emit(
            "mission.created",
            {"mission_id": mission_key, "goal_id": goal.goal_id, "steps": len(steps)},
        )
        return row

    def transition(self, mission_id: str, status: MissionStatus, **metadata: Any) -> MissionRecord:
        """Apply an allowed mission state transition."""
        with self._lock:
            old = self.missions.get(mission_id)
            if old is None:
                raise KeyError(mission_id)
            if status not in self._TRANSITIONS[old.status]:
                raise ValueError(
                    f"invalid mission transition {old.status.value} -> {status.value}"
                )
            row = MissionRecord(
                mission_id=mission_id,
                goal_id=old.goal_id,
                status=status,
                completed_steps=old.completed_steps,
                attempts=old.attempts,
                revision=old.revision + 1,
                result=old.result,
                error=metadata.get("error", old.error),
                updated_at=time.time(),
                plan=old.plan,
            )
            self.missions.put(row)
            self._emit(
                "mission.state_changed",
                {"mission_id": mission_id, "from": old.status.value, "to": status.value},
            )
            return row

    def _authorize(self, mission_id: str, capability: str) -> None:
        """Enforce the configured authorization boundary."""
        if self.authorization is not None:
            self.authorization(mission_id, capability)
            return
        if self.policy_engine is not None and hasattr(self.policy_engine, "authorize"):
            runtime = self.policy_engine.get_mission(mission_id)
            granted = tuple(runtime.metadata.get("granted_capabilities", ())) if runtime else ()
            action = self._capability_action(capability)
            self.policy_engine.authorize(
                mission_id,
                action=action,
                required_capabilities=(capability,),
                granted_capabilities=granted,
                external=action == "high_impact",
            )

    @staticmethod
    def _capability_action(capability: str) -> str:
        """Map typed capabilities to the finite autonomy risk vocabulary."""
        value = str(capability).strip().lower()
        if value in {"tool.invoke", "memory.write", "compute.use"}:
            return "reversible"
        if value in {"agent.invoke", "mission.execute", "workflow.execute"}:
            return "bounded"
        if value.startswith(("network.", "web.")):
            return "reversible"
        if value in {"observe", "model.infer", "policy.evaluate", "approval.request"} or value.startswith(("filesystem.read", "memory.read", "platform:observe", "state:export")):
            return "observe"
        if value.startswith(("filesystem.write", "filesystem.modify", "system.modify", "device.", "process.", "code.")):
            return "high_impact"
        return "high_impact"

    def execute_mission(
        self,
        mission_id: str,
        steps: Sequence[MissionStepSpec] | None = None,
        executor: Callable[[MissionStepSpec], Any] | None = None,
        compensations: Mapping[str, Callable[[], Any]] | None = None,
    ) -> dict[str, Any]:
        """Execute a validated DAG with checkpoints, recovery and verification."""
        row = self.missions.get(mission_id)
        if row is None:
            raise KeyError(mission_id)
        goal = self.goals.get(row.goal_id)
        if goal is None:
            raise KeyError(row.goal_id)
        steps = tuple(steps or row.plan)
        if not steps:
            raise ValueError("mission has no durable DAG plan")
        if executor is None:
            bound = self._step_executor
            if bound is None:
                raise ValueError("canonical step executor is not configured")
            executor = lambda spec: bound(mission_id, spec)
        DAGScheduler.validate(steps)
        if row.status is MissionStatus.CREATED:
            self.transition(mission_id, MissionStatus.RUNNING)
        elif row.status not in {MissionStatus.RUNNING, MissionStatus.PAUSED}:
            raise ValueError(f"mission is not executable: {row.status.value}")
        if self.missions.get(mission_id).status is MissionStatus.PAUSED:
            self.transition(mission_id, MissionStatus.RUNNING)

        completed = set(row.completed_steps)
        results: dict[str, Any] = dict(row.result) if isinstance(row.result, Mapping) else {}
        compensation_map = dict(compensations or {})
        try:
            while len(completed) < len(steps):
                ready_steps = DAGScheduler.ready(steps, completed)
                if not ready_steps:  # pragma: no cover - validated DAGs guarantee progress
                    raise ValueError("mission DAG cannot make progress")
                for step in ready_steps:
                    self._authorize(mission_id, step.capability)
                    ok, value, attempt = self.healing.run(
                        lambda current=step: executor(current),
                        lambda number: self.checkpoint(
                            mission_id,
                            completed,
                            result=results,
                            status=MissionStatus.RUNNING,
                            attempt_override=number,
                        ),
                        lambda: self.rollback.rollback(mission_id),
                    )
                    if not ok:
                        failure_message = f"mission step {step.step_id} failed after {attempt} attempts: {value}"
                        rollback_results = self.rollback.rollback(mission_id)
                        current = self.missions.get(mission_id)
                        if current is not None:
                            self.missions.put(
                                MissionRecord(
                                    current.mission_id,
                                    current.goal_id,
                                    MissionStatus.ROLLED_BACK,
                                    current.completed_steps,
                                    current.attempts,
                                    current.revision + 1,
                                    results,
                                    failure_message,
                                    time.time(),
                                    tuple(current.plan or steps),
                                )
                            )
                        self.goals.update_status(goal.goal_id, GoalStatus.FAILED)
                        self._emit("mission.rolled_back", {"mission_id": mission_id, "rollback_results": rollback_results, "error": failure_message})
                        self._finish_policy(mission_id, False)
                        return {"ok": False, "mission_id": mission_id, "rolled_back": True, "error": failure_message, "results": results}
                    results[step.step_id] = value
                    completed.add(step.step_id)
                    compensation = compensation_map.get(step.step_id)
                    if compensation is not None:
                        self.rollback.register(mission_id, compensation)
                    self.checkpoint(
                        mission_id,
                        completed,
                        result=results,
                        status=MissionStatus.RUNNING,
                    )

            self.transition(mission_id, MissionStatus.VERIFYING)
            verdict = self.verification.verify(goal, results)
            if verdict.passed:
                self.missions.put(
                    MissionRecord(
                        mission_id,
                        goal.goal_id,
                        MissionStatus.COMPLETED,
                        tuple(sorted(completed)),
                        self.missions.get(mission_id).attempts,
                        self.missions.get(mission_id).revision + 1,
                        results,
                        None,
                        time.time(),
                        tuple(steps),
                    )
                )
                self.goals.update_status(goal.goal_id, GoalStatus.COMPLETED)
                self._emit("mission.verified", {"mission_id": mission_id, "passed": True, "score": verdict.score})
                self.rollback.clear(mission_id)
                self._finish_policy(mission_id, True)
                return {"ok": True, "mission_id": mission_id, "verification": verdict, "results": results}

            rollback_results = self.rollback.rollback(mission_id)
            current = self.missions.get(mission_id)
            if current is not None:
                self.missions.put(
                    MissionRecord(
                        current.mission_id,
                        current.goal_id,
                        MissionStatus.ROLLED_BACK,
                        current.completed_steps,
                        current.attempts,
                        current.revision + 1,
                        results,
                        "; ".join(verdict.reasons),
                        time.time(),
                        tuple(current.plan or steps),
                    )
                )
            self.goals.update_status(goal.goal_id, GoalStatus.FAILED)
            self._emit("mission.rolled_back", {"mission_id": mission_id, "rollback_results": rollback_results})
            self._finish_policy(mission_id, False)
            return {
                "ok": False,
                "mission_id": mission_id,
                "verification": verdict,
                "rolled_back": True,
            }
        except Exception as exc:
            logger.exception("mission_execution_failed", extra={"mission_id": mission_id})
            current = self.missions.get(mission_id)
            if current is not None and current.status in {
                MissionStatus.CREATED,
                MissionStatus.RUNNING,
                MissionStatus.PAUSED,
                MissionStatus.VERIFYING,
            }:
                try:
                    self.transition(mission_id, MissionStatus.FAILED, error=str(exc))
                except ValueError:
                    logger.debug("mission_failure_transition_already_terminal", extra={"mission_id": mission_id})
            self.rollback.rollback(mission_id)
            self.goals.update_status(goal.goal_id, GoalStatus.FAILED)
            self._finish_policy(mission_id, False)
            return {"ok": False, "mission_id": mission_id, "error": str(exc)}

    def checkpoint(
        self,
        mission_id: str,
        completed: Iterable[str],
        result: Any = None,
        error: str | None = None,
        status: MissionStatus = MissionStatus.RUNNING,
        attempt_override: int | None = None,
    ) -> MissionRecord:
        """Persist an atomic mission checkpoint."""
        with self._lock:
            old = self.missions.get(mission_id)
            if old is None:
                raise KeyError(mission_id)
            attempt_count = old.attempts + 1 if attempt_override is None else max(old.attempts, int(attempt_override))
            row = MissionRecord(
                mission_id,
                old.goal_id,
                status,
                tuple(sorted(set(completed))),
                attempt_count,
                old.revision + 1,
                result,
                error,
                time.time(),
                old.plan,
            )
            self.missions.put(row)
            self._emit(
                "mission.checkpoint",
                {
                    "mission_id": mission_id,
                    "revision": row.revision,
                    "completed_steps": list(row.completed_steps),
                },
            )
            return row

    def verify_and_finish(self, mission_id: str, result: Any) -> VerificationGateResult:
        """Verify an existing mission and transition it to a terminal state."""
        row = self.missions.get(mission_id)
        if row is None:
            raise KeyError(mission_id)
        goal = self.goals.get(row.goal_id)
        if goal is None:
            raise KeyError(row.goal_id)
        if row.status is MissionStatus.CREATED:
            self.transition(mission_id, MissionStatus.RUNNING)
            row = self.missions.get(mission_id)
        if row is not None and row.status is MissionStatus.RUNNING:
            self.transition(mission_id, MissionStatus.VERIFYING)
            row = self.missions.get(mission_id)
        if row is None or row.status is not MissionStatus.VERIFYING:
            raise ValueError("mission must be verifying before verification")
        verdict = self.verification.verify(goal, result)
        if verdict.passed:
            self.transition(mission_id, MissionStatus.COMPLETED)
            self.goals.update_status(goal.goal_id, GoalStatus.COMPLETED)
            self._finish_policy(mission_id, True)
        else:
            self.transition(mission_id, MissionStatus.ROLLED_BACK)
            self.goals.update_status(goal.goal_id, GoalStatus.FAILED)
            self._finish_policy(mission_id, False)
        self._emit(
            "mission.verified",
            {"mission_id": mission_id, "passed": verdict.passed, "score": verdict.score},
        )
        return verdict

    def _finish_policy(self, mission_id: str, success: bool) -> None:
        """Close the mission's policy scope when supported."""
        if self.policy_engine is not None and hasattr(self.policy_engine, "finish_mission"):
            try:
                self.policy_engine.finish_mission(mission_id, success)
            except Exception:
                logger.exception("autonomy_policy_finish_failed", extra={"mission_id": mission_id})

    def _emit(self, event_type: str, payload: Mapping[str, Any]) -> None:
        """Emit an observable event without compromising mission state."""
        if self.events is None:
            return
        try:
            self.events(Event.new(event_type, "autonomy_fabric", payload))
        except Exception:
            logger.exception("autonomy_event_emit_failed", extra={"event_type": event_type})

    def snapshot(self) -> dict[str, Any]:
        """Return deterministic non-sensitive autonomy telemetry."""
        missions = self.missions.list()
        return {
            "goals": self.goals.count(),
            "missions": len(missions),
            "status_counts": {
                status.value: sum(1 for mission in missions if mission.status is status)
                for status in MissionStatus
            },
        }



"""Read-only local system device adapter for the JARVIS device fabric."""
from __future__ import annotations

import os
import platform
import time
from typing import Any

try:
    import psutil  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    psutil = None


class LocalSystemDevice:
    """Expose safe local telemetry and a non-destructive refresh operation."""

    def telemetry(self) -> dict[str, Any]:
        """Return bounded host telemetry without exposing secrets."""
        result: dict[str, Any] = {
            "ok": True,
            "timestamp": time.time(),
            "hostname": platform.node(),
            "platform": platform.platform(),
            "cpu_count": os.cpu_count() or 1,
        }
        if psutil is not None:
            result.update(
                {
                    "cpu_percent": float(psutil.cpu_percent(interval=None)),
                    "memory_percent": float(psutil.virtual_memory().percent),
                    "disk_percent": float(psutil.disk_usage("/").percent),
                }
            )
        return result

    def execute(self, capability: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Execute only the safe, non-destructive local system capability."""
        if capability != "telemetry.refresh":
            return {"ok": False, "error": "unsupported local-system capability"}
        return self.telemetry()

    def close(self) -> None:
        """Release adapter resources; no persistent resources are held."""



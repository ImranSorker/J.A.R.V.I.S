"""Deterministic local command palette parser; dispatch remains capability-gated."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
import re
from typing import Mapping


class CommandKind(StrEnum):
    OPEN = "open"
    SEARCH = "search"
    STATUS = "status"
    MODEL = "model"
    MISSION = "mission"
    DIAGNOSTIC = "diagnostic"
    DEVICE = "device"


@dataclass(frozen=True, slots=True)
class PaletteCommand:
    """Validated palette command."""

    kind: CommandKind
    argument: str
    capability: str


class CommandPalette:
    """Parse operator commands without executing them."""

    _RULES: Mapping[CommandKind, tuple[re.Pattern[str], str]] = {
        CommandKind.OPEN: (re.compile(r"^open\s+(.+)$", re.I), "desktop.open"),
        CommandKind.SEARCH: (re.compile(r"^(?:search|find)\s+(?:my\s+)?files?\s+(.+)$", re.I), "filesystem.search"),
        CommandKind.STATUS: (re.compile(r"^(?:show\s+)?status$", re.I), "system.observe"),
        CommandKind.MODEL: (re.compile(r"^(?:load|use)\s+model\s+(.+)$", re.I), "model.manage"),
        CommandKind.MISSION: (re.compile(r"^(?:start|run)\s+mission\s+(.+)$", re.I), "mission.execute"),
        CommandKind.DIAGNOSTIC: (re.compile(r"^(?:run\s+)?(?:doctor|diagnostics)$", re.I), "system.diagnose"),
        CommandKind.DEVICE: (re.compile(r"^(?:check|show)\s+device\s+(.+)$", re.I), "device.observe"),
    }

    def parse(self, text: str) -> PaletteCommand | None:
        """Return a command object only when syntax matches exactly."""
        normalized = str(text).strip()
        if not normalized or len(normalized) > 2000:
            return None
        for kind, (pattern, capability) in self._RULES.items():
            match = pattern.fullmatch(normalized)
            if match:
                return PaletteCommand(kind, (match.group(1) if match.lastindex else "").strip()[:1024], capability)
        return None

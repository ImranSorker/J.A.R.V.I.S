"""Runtime lifecycle leak diagnostics for JARVIS certification."""
from __future__ import annotations

import asyncio
import os
import threading
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class LifecycleSnapshot:
    """Observable host resources owned by a test/runtime process."""

    thread_names: tuple[str, ...]
    asyncio_tasks: int
    file_descriptors: int | None
    child_processes: tuple[int, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "thread_names": list(self.thread_names),
            "asyncio_tasks": self.asyncio_tasks,
            "file_descriptors": self.file_descriptors,
            "child_processes": list(self.child_processes),
        }


def snapshot() -> LifecycleSnapshot:
    """Capture bounded lifecycle state without touching application internals."""
    try:
        tasks = len(asyncio.all_tasks())
    except RuntimeError:
        tasks = 0
    fd_count: int | None = None
    proc_fd = Path(f"/proc/{os.getpid()}/fd")
    try:
        if proc_fd.exists():
            fd_count = len(tuple(proc_fd.iterdir()))
    except OSError:
        fd_count = None
    children: tuple[int, ...] = ()
    if os.name == "posix":
        discovered: list[int] = []
        proc_root = Path("/proc")
        if proc_root.exists():
            for entry in proc_root.iterdir():
                if not entry.name.isdigit():
                    continue
                try:
                    stat_fields = (entry / "stat").read_text(encoding="utf-8").split()
                    if len(stat_fields) > 3 and int(stat_fields[3]) == os.getpid():
                        discovered.append(int(entry.name))
                except (OSError, ValueError):
                    continue
        children = tuple(sorted(discovered))
    return LifecycleSnapshot(
        thread_names=tuple(sorted(t.name for t in threading.enumerate())),
        asyncio_tasks=tasks,
        file_descriptors=fd_count,
        child_processes=children,
    )


def diff(before: LifecycleSnapshot, after: LifecycleSnapshot) -> dict[str, Any]:
    """Return resources that appeared after a lifecycle operation."""
    before_threads = Counter(before.thread_names)
    after_threads = Counter(after.thread_names)
    new_threads: list[str] = []
    for name, count in after_threads.items():
        for _ in range(max(0, count - before_threads.get(name, 0))):
            new_threads.append(name)
    return {
        "new_threads": sorted(new_threads),
        "new_asyncio_tasks": max(0, after.asyncio_tasks - before.asyncio_tasks),
        "new_file_descriptors": None if before.file_descriptors is None or after.file_descriptors is None else max(0, after.file_descriptors - before.file_descriptors),
        "new_child_processes": sorted(set(after.child_processes) - set(before.child_processes)),
    }

"""Identity and Ownership Model — first-class identity for JARVIS.

Provides workspace-scoped, session-bound identity with capability-based
authorization. Every operation in JARVIS is attributed to a principal.

Architecture:
    Principal (who)
      -> Workspace (where)
      -> Session (when/context)
      -> Capabilities (what they can do)
      -> Authorization check (are they allowed?)
"""
from __future__ import annotations

import enum
import secrets
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


class PrincipalType(enum.Enum):
    """Type of principal."""
    SYSTEM = "system"
    USER = "user"
    API_CLIENT = "api_client"
    AGENT = "agent"
    PLUGIN = "plugin"
    EXTERNAL_SERVICE = "external_service"


@dataclass(frozen=True)
class Principal:
    """Immutable identity of an actor in JARVIS."""
    id: str
    name: str
    type: PrincipalType
    workspace: str = "default"
    capabilities: Tuple[str, ...] = ()
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    def has_capability(self, capability: str) -> bool:
        """Check if principal has a specific capability."""
        return capability in self.capabilities or "*" in self.capabilities

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type.value,
            "workspace": self.workspace,
            "capabilities": list(self.capabilities),
            "metadata": dict(self.metadata),
            "created_at": self.created_at,
        }

    @classmethod
    def system(cls) -> "Principal":
        return cls(
            id="system",
            name="J.A.R.V.I.S. System",
            type=PrincipalType.SYSTEM,
            capabilities=("*",),
        )

    @classmethod
    def anonymous(cls) -> "Principal":
        return cls(
            id=f"anon_{uuid.uuid4().hex[:12]}",
            name="Anonymous",
            type=PrincipalType.USER,
            capabilities=(),
        )


@dataclass
class Session:
    """A bounded session context for a principal."""
    id: str
    principal: Principal
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    _closed: bool = False

    def touch(self) -> None:
        self.last_active = time.time()

    def close(self) -> None:
        self._closed = True

    @property
    def is_active(self) -> bool:
        return not self._closed


@dataclass(frozen=True)
class OwnershipRecord:
    """Immutable ownership record for any resource."""
    resource_id: str
    resource_type: str
    owner: Principal
    created_at: float
    workspace: str
    permissions: Tuple[str, ...] = ("read", "write", "delete")

    def can(self, action: str, principal: Principal) -> bool:
        """Check if principal can perform action on this resource."""
        if principal.type == PrincipalType.SYSTEM:
            return True
        if principal.id == self.owner.id and principal.workspace == self.workspace:
            return action in self.permissions
        return False


class IdentityManager:
    """Central identity and ownership manager.

    Manages principals, sessions, and ownership records with
    thread-safe operations.
    """

    def __init__(self) -> None:
        self._principals: Dict[str, Principal] = {}
        self._sessions: Dict[str, Session] = {}
        self._ownership: Dict[str, OwnershipRecord] = {}
        self._lock = threading.RLock()
        self._register_builtin_principals()

    def _register_builtin_principals(self) -> None:
        system = Principal.system()
        with self._lock:
            self._principals[system.id] = system

    def create_principal(
        self,
        name: str,
        type: PrincipalType,
        workspace: str = "default",
        capabilities: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Principal:
        """Create a new principal."""
        principal_id = f"{type.value}_{secrets.token_urlsafe(16)}"
        principal = Principal(
            id=principal_id,
            name=name,
            type=type,
            workspace=workspace,
            capabilities=tuple(capabilities or ()),
            metadata=dict(metadata or {}),
        )
        with self._lock:
            self._principals[principal_id] = principal
        return principal

    def get_principal(self, principal_id: str) -> Optional[Principal]:
        with self._lock:
            return self._principals.get(principal_id)

    def create_session(self, principal: Principal, metadata: Optional[Dict[str, Any]] = None) -> Session:
        """Create a new session for a principal."""
        session_id = f"sess_{uuid.uuid4().hex[:16]}"
        session = Session(
            id=session_id,
            principal=principal,
            metadata=dict(metadata or {}),
        )
        with self._lock:
            self._sessions[session_id] = session
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        with self._lock:
            session = self._sessions.get(session_id)
            if session and session.is_active:
                session.touch()
            return session

    def close_session(self, session_id: str) -> bool:
        with self._lock:
            session = self._sessions.get(session_id)
            if session:
                session.close()
                return True
            return False

    def register_ownership(
        self,
        resource_id: str,
        resource_type: str,
        owner: Principal,
        workspace: Optional[str] = None,
        permissions: Optional[List[str]] = None,
    ) -> OwnershipRecord:
        """Register ownership of a resource."""
        record = OwnershipRecord(
            resource_id=resource_id,
            resource_type=resource_type,
            owner=owner,
            created_at=time.time(),
            workspace=workspace or owner.workspace,
            permissions=tuple(permissions or ("read", "write", "delete")),
        )
        with self._lock:
            self._ownership[resource_id] = record
        return record

    def get_ownership(self, resource_id: str) -> Optional[OwnershipRecord]:
        with self._lock:
            return self._ownership.get(resource_id)

    def check_permission(self, resource_id: str, action: str, principal: Principal) -> bool:
        """Check if principal can perform action on resource."""
        record = self.get_ownership(resource_id)
        if record is None:
            # No ownership record = deny by default
            return False
        return record.can(action, principal)

    def transfer_ownership(
        self,
        resource_id: str,
        new_owner: Principal,
        current_principal: Principal,
    ) -> bool:
        """Transfer ownership if current principal has write permission."""
        with self._lock:
            record = self._ownership.get(resource_id)
            if record is None:
                return False
            if not record.can("write", current_principal):
                return False
            new_record = OwnershipRecord(
                resource_id=resource_id,
                resource_type=record.resource_type,
                owner=new_owner,
                created_at=record.created_at,
                workspace=new_owner.workspace,
                permissions=record.permissions,
            )
            self._ownership[resource_id] = new_record
            return True

    def list_owned_resources(self, principal: Principal) -> List[OwnershipRecord]:
        with self._lock:
            return [
                record for record in self._ownership.values()
                if record.owner.id == principal.id
            ]

    def cleanup_expired_sessions(self, max_age_seconds: float = 3600.0) -> int:
        """Remove expired sessions."""
        now = time.time()
        removed = 0
        with self._lock:
            expired = [
                sid for sid, sess in self._sessions.items()
                if not sess.is_active or (now - sess.last_active) > max_age_seconds
            ]
            for sid in expired:
                self._sessions.pop(sid, None)
                removed += 1
        return removed



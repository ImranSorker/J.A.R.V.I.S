"""Canonical durable unit of cognition for J.A.R.V.I.S."""
from __future__ import annotations

import hashlib
import logging
import json
import os
import tempfile
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field, replace
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping

from core.contracts.event import Event

logger = logging.getLogger("jarvis.cognitive_episode")


class EpisodePhase(StrEnum):
    """Ordered phases of one cognitive episode."""
    PERCEIVE = "perceive"
    UNDERSTAND = "understand"
    RECALL = "recall"
    REASON = "reason"
    PLAN = "plan"
    ACT = "act"
    VERIFY = "verify"
    REFLECT = "reflect"
    COMPLETE = "complete"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class EpisodeObservation:
    """Trusted internal observation produced by the fabric."""
    source: str
    kind: str
    content: Any
    trust: float = 1.0
    provenance: str = "internal"


@dataclass(frozen=True, slots=True)
class CognitiveEpisode:
    """Immutable snapshot of a complete cognitive transaction."""
    episode_id: str
    request_id: str
    session_id: str
    created_at: float
    phase: EpisodePhase = EpisodePhase.PERCEIVE
    intent: Mapping[str, Any] = field(default_factory=dict)
    memory_refs: tuple[str, ...] = ()
    observations: tuple[EpisodeObservation, ...] = ()
    plan: tuple[str, ...] = ()
    actions: tuple[Mapping[str, Any], ...] = ()
    verification: Mapping[str, Any] = field(default_factory=dict)
    reflection: Mapping[str, Any] = field(default_factory=dict)
    output: str = ""
    model: str = ""
    resource_usage: Mapping[str, float] = field(default_factory=dict)
    error: str | None = None
    revision: int = 0

    @classmethod
    def create(cls, request_id: str, session_id: str) -> "CognitiveEpisode":
        """Create a fresh episode."""
        return cls(uuid.uuid4().hex, request_id, session_id, time.time())

    def transition(self, phase: EpisodePhase, **changes: Any) -> "CognitiveEpisode":
        """Return a new revision after a controlled phase transition."""
        return replace(self, phase=phase, revision=self.revision + 1, **changes)


class EpisodeStore:
    """Atomic bounded JSON store for restart-safe cognitive episodes."""

    def __init__(self, path: str | Path = "data/cognitive_episodes.json", max_episodes: int = 5000, journal_path: str | Path | None = None) -> None:
        self.path = Path(path).expanduser().resolve()
        self.journal_path = (Path(journal_path).expanduser().resolve() if journal_path else self.path.with_name(self.path.stem + ".events.jsonl"))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_episodes = max(1, min(int(max_episodes), 100_000))
        self._lock = threading.RLock()
        self._episodes: dict[str, CognitiveEpisode] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            rows = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return
        if not isinstance(rows, list):
            return
        for row in rows[-self.max_episodes:]:
            try:
                observations = tuple(EpisodeObservation(**item) for item in row.get("observations", ()))
                self._episodes[str(row["episode_id"])] = CognitiveEpisode(
                    episode_id=str(row["episode_id"]), request_id=str(row["request_id"]), session_id=str(row["session_id"]),
                    created_at=float(row["created_at"]), phase=EpisodePhase(str(row.get("phase", EpisodePhase.PERCEIVE.value))),
                    intent=dict(row.get("intent", {})), memory_refs=tuple(row.get("memory_refs", ())), observations=observations,
                    plan=tuple(row.get("plan", ())), actions=tuple(dict(item) for item in row.get("actions", ())),
                    verification=dict(row.get("verification", {})), reflection=dict(row.get("reflection", {})),
                    output=str(row.get("output", "")), model=str(row.get("model", "")),
                    resource_usage={str(k): float(v) for k, v in dict(row.get("resource_usage", {})).items()},
                    error=row.get("error"), revision=int(row.get("revision", 0)),
                )
            except (KeyError, TypeError, ValueError):
                continue

    def put(self, episode: CognitiveEpisode) -> CognitiveEpisode:
        """Persist an episode atomically."""
        with self._lock:
            self._episodes[episode.episode_id] = episode
            ids = sorted(self._episodes, key=lambda key: self._episodes[key].created_at)[-self.max_episodes:]
            self._episodes = {key: self._episodes[key] for key in ids}
            payload = []
            for item in self._episodes.values():
                row = asdict(item)
                row["phase"] = item.phase.value
                row["observations"] = [asdict(obs) for obs in item.observations]
                payload.append(row)
            fd, tmp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
            tmp = Path(tmp_name)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(payload, handle, sort_keys=True, separators=(",", ":"), default=str)
                    handle.flush(); os.fsync(handle.fileno())
                os.replace(tmp, self.path)
                journal_row = {"episode_id": episode.episode_id, "request_id": episode.request_id, "session_id": episode.session_id, "phase": episode.phase.value, "revision": episode.revision, "timestamp": time.time(), "digest": self.digest()}
                with self.journal_path.open("a", encoding="utf-8") as journal:
                    journal.write(json.dumps(journal_row, sort_keys=True, separators=(",", ":")) + "\n")
                    journal.flush()
                    os.fsync(journal.fileno())
            finally:
                tmp.unlink(missing_ok=True)
        return episode

    def get(self, episode_id: str) -> CognitiveEpisode | None:
        """Return one persisted episode."""
        with self._lock:
            return self._episodes.get(episode_id)

    def list(self, session_id: str | None = None) -> list[CognitiveEpisode]:
        """Return deterministic episode history."""
        with self._lock:
            items = list(self._episodes.values())
        if session_id is not None:
            items = [item for item in items if item.session_id == session_id]
        return sorted(items, key=lambda item: (item.created_at, item.episode_id))


    def export_state(self) -> list[dict[str, Any]]:
        """Export all retained episodes as a serialization-safe list."""
        rows: list[dict[str, Any]] = []
        for item in self.list():
            row = asdict(item)
            row["phase"] = item.phase.value
            row["observations"] = [asdict(obs) for obs in item.observations]
            rows.append(row)
        return rows

    def import_state(self, rows: list[Mapping[str, Any]]) -> None:
        """Replace retained episodes from a validated portable state domain."""
        restored = EpisodeStore(self.path, self.max_episodes)
        restored._episodes.clear()
        for row in rows:
            observations = tuple(EpisodeObservation(**dict(obs)) for obs in row.get("observations", ()))
            episode = CognitiveEpisode(
                episode_id=str(row["episode_id"]), request_id=str(row["request_id"]), session_id=str(row["session_id"]),
                created_at=float(row["created_at"]), phase=EpisodePhase(str(row.get("phase", EpisodePhase.PERCEIVE.value))),
                intent=dict(row.get("intent", {})), memory_refs=tuple(row.get("memory_refs", ())), observations=observations,
                plan=tuple(row.get("plan", ())), actions=tuple(dict(item) for item in row.get("actions", ())),
                verification=dict(row.get("verification", {})), reflection=dict(row.get("reflection", {})),
                output=str(row.get("output", "")), model=str(row.get("model", "")),
                resource_usage={str(k): float(v) for k, v in dict(row.get("resource_usage", {})).items()},
                error=row.get("error"), revision=int(row.get("revision", 0)),
            )
            restored._episodes[episode.episode_id] = episode
        with self._lock:
            self._episodes = dict(restored._episodes)
            payload = self.export_state()
            fd, tmp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
            tmp = Path(tmp_name)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(payload, handle, sort_keys=True, separators=(",", ":"), default=str)
                    handle.flush(); os.fsync(handle.fileno())
                os.replace(tmp, self.path)
            finally:
                tmp.unlink(missing_ok=True)

    def revision_history(self, episode_id: str) -> list[dict[str, Any]]:
        """Return durable phase-transition records for one episode."""
        if not self.journal_path.exists():
            return []
        rows: list[dict[str, Any]] = []
        try:
            with self.journal_path.open(encoding="utf-8") as journal:
                for line in journal:
                    try:
                        row = json.loads(line)
                    except (TypeError, ValueError, json.JSONDecodeError):
                        continue
                    if isinstance(row, dict) and str(row.get("episode_id")) == episode_id:
                        rows.append(row)
        except OSError:
            logger.exception("cognitive_episode_journal_read_failed", extra={"episode_id": episode_id})
        return rows

    def digest(self) -> str:
        """Return a non-secret integrity digest of stored state."""
        encoded = json.dumps([asdict(item) for item in self.list()], sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class CognitiveEpisodeRecorder:
    """Persist episode transitions and emit observability events."""

    def __init__(self, store: EpisodeStore, event_sink: Callable[[Event], Any] | None = None) -> None:
        self.store = store
        self.event_sink = event_sink

    def record(self, episode: CognitiveEpisode) -> CognitiveEpisode:
        """Persist and emit a phase event."""
        saved = self.store.put(episode)
        if self.event_sink:
            try:
                self.event_sink(Event.new("cognition.episode", "cognitive_fabric", {
                    "episode_id": saved.episode_id, "phase": saved.phase.value, "revision": saved.revision,
                }, correlation_id=saved.request_id))
            except Exception:
                logger.exception("cognitive_episode_event_emit_failed")
        return saved



"""Bounded process isolation for JARVIS plugins.

The plugin runtime uses platform-native containment where available and fails
closed when the requested isolation guarantees cannot be enforced.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import signal
import subprocess
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("jarvis.plugin_isolation")


class PluginIsolationError(Exception):
    """Raised when plugin isolation requirements cannot be enforced."""


@dataclass(frozen=True)
class PluginManifest:
    """Declarative plugin security and resource policy."""

    name: str
    version: str
    description: str = ""
    required_capabilities: Tuple[str, ...] = ()
    network_access: bool = False
    file_system_access: bool = False
    max_execution_time_seconds: int = 30
    max_memory_mb: int = 256
    entry_point: str = "main.py"


@dataclass
class PluginSandbox:
    """Run a plugin in a bounded, isolated subprocess."""

    manifest: PluginManifest
    workspace: Path
    process: Optional[subprocess.Popen[str]] = None
    _lock: threading.RLock = field(default_factory=threading.RLock)
    _job: Any = None
    _request_id: str = field(default_factory=lambda: f"plugin_{uuid.uuid4().hex[:12]}")

    def __post_init__(self) -> None:
        self.workspace = self.workspace.resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _command(self, entry: Path) -> list[str]:
        """Build the platform-specific plugin launch command."""
        python = os.environ.get("JARVIS_PYTHON") or shutil.which("python") or shutil.which("python3") or "python"
        base = [python, "-I", "-B", str(entry)]
        bwrap = shutil.which("bwrap")
        if os.name != "nt" and bwrap:
            cmd = [
                bwrap,
                "--die-with-parent",
                "--new-session",
                "--ro-bind", "/usr", "/usr",
                "--ro-bind", "/bin", "/bin",
                "--ro-bind", "/lib", "/lib",
                "--ro-bind", "/lib64", "/lib64",
                "--proc", "/proc",
                "--dev", "/dev",
                "--tmpfs", "/tmp",
                "--chdir", "/workspace",
            ]  # nosec B108 - tmpfs is the intended isolated runtime filesystem.
            if self.manifest.file_system_access:
                cmd.extend(["--bind", str(self.workspace), "/workspace"])
            else:
                cmd.extend(["--ro-bind", str(self.workspace), "/workspace"])
            if not self.manifest.network_access:
                cmd.append("--unshare-net")
            cmd += base[:-1] + [f"/workspace/{entry.name}"]
            return cmd
        return base

    @staticmethod
    def _sanitize_env() -> Dict[str, str]:
        """Return an environment stripped of obvious secret-bearing variables."""
        denied = ("SECRET", "TOKEN", "PASSWORD", "PRIVATE_KEY", "API_KEY")
        return {
            key: value
            for key, value in os.environ.items()
            if not any(part in key.upper() for part in denied)
        }

    def start(self) -> bool:
        """Start the plugin under the strongest available platform isolation."""
        if os.name == "nt":
            # A Job Object supplies process-tree lifetime and memory bounds,
            # but this module does not yet enforce Windows restricted tokens,
            # filesystem ACLs and per-plugin network egress. Fail closed rather
            # than presenting a memory-limited process as a full sandbox.
            raise PluginIsolationError(
                "strict Windows plugin isolation requires restricted-token, filesystem-ACL, and network-policy enforcement"
            )
        if os.name != "nt" and shutil.which("bwrap") is None:
            raise PluginIsolationError("strict plugin isolation requires bubblewrap")

        entry = (self.workspace / self.manifest.entry_point).resolve()
        try:
            entry.relative_to(self.workspace)
        except ValueError as exc:
            raise PluginIsolationError("plugin entry point escapes workspace") from exc
        if not entry.is_file():
            return False

        env = self._sanitize_env()
        env.update(
            JARVIS_PLUGIN_NAME=self.manifest.name,
            JARVIS_PLUGIN_WORKSPACE=str(self.workspace),
            JARVIS_PLUGIN_NETWORK="1" if self.manifest.network_access else "0",
            JARVIS_PLUGIN_FS="1" if self.manifest.file_system_access else "0",
            PYTHONNOUSERSITE="1",
            PYTHONDONTWRITEBYTECODE="1",
        )
        kwargs: Dict[str, Any] = {
            "cwd": str(self.workspace),
            "env": env,
            "stdin": subprocess.PIPE,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "text": True,
            "bufsize": 1,
            "start_new_session": os.name != "nt",
        }
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        else:
            try:
                import resource

                def limit() -> None:
                    memory = self.manifest.max_memory_mb * 1024 * 1024
                    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
                    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

                kwargs["preexec_fn"] = limit
            except (ImportError, OSError, AttributeError) as exc:
                logger.debug("plugin_resource_limits_unavailable", extra={"error": str(exc)})

        try:
            self.process = subprocess.Popen(self._command(entry), **kwargs)
            if os.name == "nt":
                try:
                    from security.windows_job import WindowsJob

                    self._job = WindowsJob(self.manifest.max_memory_mb * 1024 * 1024)
                    self._job.assign(self.process.pid)
                except Exception as exc:
                    self._job = None
                    process = self.process
                    self.process = None
                    try:
                        process.kill()
                        process.wait(timeout=2)
                    except Exception:
                        logger.debug("plugin_process_cleanup_failed", exc_info=True)
                    raise PluginIsolationError(f"strict Windows plugin isolation unavailable: {exc}") from exc

            threading.Thread(target=self._drain_stderr, name=f"jarvis-plugin-stderr-{self.manifest.name}", daemon=True).start()
            logger.info("plugin_started", extra={"plugin": self.manifest.name, "pid": self.process.pid})
            return True
        except PluginIsolationError:
            raise
        except Exception as exc:
            logger.exception("plugin_start_failed", extra={"plugin": self.manifest.name, "error": str(exc)})
            self.process = None
            return False

    def _drain_stderr(self) -> None:
        """Continuously drain plugin stderr to avoid pipe backpressure."""
        process = self.process
        stream = process.stderr if process else None
        if stream is None:
            return
        try:
            for line in iter(stream.readline, ""):
                if line:
                    logger.debug("plugin_stderr", extra={"plugin": self.manifest.name, "line": line.rstrip()})
        except Exception:
            logger.debug("plugin_stderr_reader_failed", exc_info=True)

    def call(self, method: str, params: Dict[str, Any], timeout: Optional[float] = None) -> Dict[str, Any]:
        """Call one JSON-RPC method with a bounded, cross-platform timeout."""
        with self._lock:
            if not self.process or self.process.poll() is not None:
                return {"ok": False, "error": "Plugin process not running"}
            limit = max(0.1, min(float(timeout or self.manifest.max_execution_time_seconds), self.manifest.max_execution_time_seconds))
            request = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": method, "params": params}
            raw = json.dumps(request, separators=(",", ":")) + "\n"
            if len(raw) > 1_000_000:
                return {"ok": False, "error": "Request too large"}
            if self.process.stdin is None or self.process.stdout is None:
                return {"ok": False, "error": "Plugin pipes unavailable"}

            result_queue: Queue[str] = Queue(maxsize=1)

            def read_response() -> None:
                try:
                    line = self.process.stdout.readline() if self.process and self.process.stdout else ""
                    result_queue.put_nowait(line)
                except Exception as exc:
                    try:
                        result_queue.put_nowait(f"__PLUGIN_READER_ERROR__:{exc}")
                    except Exception:
                        logger.debug("plugin_reader_queue_failed", exc_info=True)

            try:
                self.process.stdin.write(raw)
                self.process.stdin.flush()
                threading.Thread(target=read_response, name=f"jarvis-plugin-rpc-{self.manifest.name}", daemon=True).start()
                try:
                    line = result_queue.get(timeout=limit)
                except Empty:
                    self._kill()
                    return {"ok": False, "error": "Plugin response timed out"}
                if line.startswith("__PLUGIN_READER_ERROR__:"):
                    return {"ok": False, "error": line.split(":", 1)[1]}
                if not line or len(line) > 1_000_000:
                    return {"ok": False, "error": "Invalid or oversized plugin response"}
                response = json.loads(line)
                if response.get("jsonrpc") != "2.0" or response.get("id") != request["id"]:
                    return {"ok": False, "error": "Invalid JSON-RPC response"}
                return {"ok": True, "result": response.get("result"), "error": response.get("error")}
            except (json.JSONDecodeError, ValueError) as exc:
                return {"ok": False, "error": f"Invalid plugin response: {exc}"}
            except Exception as exc:
                logger.exception("plugin_call_failed", extra={"plugin": self.manifest.name, "error": str(exc)})
                return {"ok": False, "error": str(exc)}

    def stop(self, timeout: float = 5.0) -> bool:
        """Stop the plugin and release all process/isolation resources."""
        process = self.process
        job = self._job
        if process is None:
            if job is not None:
                try:
                    job.close()
                except Exception:
                    logger.debug("plugin_job_close_failed", exc_info=True)
                self._job = None
            return True
        try:
            if process.poll() is None:
                if os.name != "nt":
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except OSError:
                        process.terminate()
                else:
                    process.terminate()
                try:
                    process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    if os.name != "nt":
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except OSError:
                            process.kill()
                    else:
                        process.kill()
                    process.wait(timeout=1)
            return True
        except Exception as exc:
            logger.warning("plugin_stop_failed", extra={"error": str(exc)})
            return False
        finally:
            for stream_name in ("stdin", "stdout", "stderr"):
                stream = getattr(process, stream_name, None)
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        logger.debug("plugin_stream_close_failed", extra={"stream": stream_name}, exc_info=True)
            self.process = None
            if job is not None:
                try:
                    job.close()
                except Exception:
                    logger.debug("plugin_job_close_failed", exc_info=True)
                self._job = None

    def _kill(self) -> None:
        """Terminate the plugin immediately after a timeout."""
        process = self.process
        if process and process.poll() is None:
            try:
                if os.name != "nt":
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
            except Exception as exc:
                logger.debug("plugin_kill_failed", extra={"error": str(exc)})

    def is_alive(self) -> bool:
        """Return whether the plugin subprocess is currently alive."""
        return self.process is not None and self.process.poll() is None


class PluginIsolationManager:
    """Manage plugin sandboxes with strict path containment."""

    def __init__(self, base_dir: str = "data/plugins") -> None:
        self._base = Path(base_dir).resolve()
        self._base.mkdir(parents=True, exist_ok=True)
        self._sandboxes: Dict[str, PluginSandbox] = {}
        self._lock = threading.RLock()

    def create_sandbox(self, manifest: PluginManifest) -> PluginSandbox:
        """Create a plugin workspace constrained beneath the manager root."""
        safe_name = Path(manifest.name).name
        safe_version = Path(manifest.version).name
        if safe_name != manifest.name or safe_version != manifest.version:
            raise PluginIsolationError("plugin name/version contains traversal")
        workspace = (self._base / safe_name / safe_version).resolve()
        try:
            workspace.relative_to(self._base)
        except ValueError as exc:
            raise PluginIsolationError("plugin workspace escaped base") from exc
        sandbox = PluginSandbox(manifest, workspace)
        with self._lock:
            self._sandboxes[manifest.name] = sandbox
        return sandbox

    def get_sandbox(self, name: str) -> Optional[PluginSandbox]:
        """Return a registered plugin sandbox by name."""
        with self._lock:
            return self._sandboxes.get(name)

    def start_plugin(self, name: str) -> bool:
        """Start a registered plugin."""
        sandbox = self.get_sandbox(name)
        return bool(sandbox and sandbox.start())

    def call_plugin(self, name: str, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Call a method on a registered plugin."""
        sandbox = self.get_sandbox(name)
        return sandbox.call(method, params) if sandbox else {"ok": False, "error": f"Plugin {name} not found"}

    def stop_plugin(self, name: str) -> bool:
        """Stop one plugin."""
        sandbox = self.get_sandbox(name)
        return bool(sandbox and sandbox.stop())

    def stop_all(self, timeout: float = 5.0) -> int:
        """Stop all plugins and return the number stopped successfully."""
        with self._lock:
            sandboxes = list(self._sandboxes.values())
        return sum(1 for sandbox in sandboxes if sandbox.stop(timeout))

    def list_plugins(self) -> List[Dict[str, Any]]:
        """Return plugin lifecycle metadata."""
        with self._lock:
            return [
                {
                    "name": name,
                    "version": sandbox.manifest.version,
                    "alive": sandbox.is_alive(),
                    "pid": sandbox.process.pid if sandbox.process else None,
                }
                for name, sandbox in self._sandboxes.items()
            ]



"""Agent Genome 2.0: signed, versioned identity and compatibility contracts.

This module is deliberately a control-plane primitive.  It describes an agent;
it does not execute code, grant authority, or permit production self-modification.
Every persisted genome is schema-validated and, for protected registry writes,
cryptographically signed with Ed25519.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import re
import sqlite3
import time
import uuid
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator

GENOME_SCHEMA_VERSION = "2.0.0"
_SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$")
_SCHEMA_PATH = Path(__file__).resolve().parent / "schemas" / "agent_genome_v2.schema.json"


class AgentGenomeError(ValueError):
    """Base error for invalid genome operations."""


class GenomeSignatureError(AgentGenomeError):
    """Raised when a genome signature or key identity is invalid."""


class GenomeMigrationError(AgentGenomeError):
    """Raised when no safe migration path exists."""


class GenomeRollbackError(AgentGenomeError):
    """Raised when a rollback target is unavailable or untrusted."""


@dataclass(frozen=True, slots=True)
class GenomeCompatibility:
    """Structured compatibility result between two genome documents."""

    compatible: bool
    schema_compatible: bool
    identity_compatible: bool
    capability_compatible: bool
    tool_compatible: bool
    model_compatible: bool
    resource_compatible: bool
    environment_compatible: bool
    security_compatible: bool
    requires_migration: bool
    reasons: tuple[str, ...]
    added_capabilities: tuple[str, ...]
    removed_capabilities: tuple[str, ...]
    changed_tools: tuple[str, ...]
    changed_models: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "compatible": self.compatible,
            "schema_compatible": self.schema_compatible,
            "identity_compatible": self.identity_compatible,
            "capability_compatible": self.capability_compatible,
            "tool_compatible": self.tool_compatible,
            "model_compatible": self.model_compatible,
            "resource_compatible": self.resource_compatible,
            "environment_compatible": self.environment_compatible,
            "security_compatible": self.security_compatible,
            "requires_migration": self.requires_migration,
            "reasons": list(self.reasons),
            "added_capabilities": list(self.added_capabilities),
            "removed_capabilities": list(self.removed_capabilities),
            "changed_tools": list(self.changed_tools),
            "changed_models": list(self.changed_models),
        }


@dataclass(frozen=True, slots=True)
class GenomeDiff:
    """Structured recursive difference between two genomes."""

    added: tuple[dict[str, Any], ...]
    removed: tuple[dict[str, Any], ...]
    changed: tuple[dict[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        return {"added": list(self.added), "removed": list(self.removed), "changed": list(self.changed)}


class AgentGenome:
    """Immutable-in-use wrapper around one validated genome document."""

    def __init__(self, document: Mapping[str, Any], *, validate: bool = True) -> None:
        self._document = copy.deepcopy(dict(document))
        if validate:
            self.validate()

    @property
    def document(self) -> dict[str, Any]:
        return copy.deepcopy(self._document)

    @property
    def agent_uuid(self) -> str:
        return str(self._document["immutable_identity"]["agent_uuid"])

    @property
    def genome_version(self) -> str:
        return str(self._document["genome_version"])

    @property
    def schema_version(self) -> str:
        return str(self._document["schema_version"])

    @property
    def cryptographic_fingerprint(self) -> str:
        return str(self._document["immutable_identity"]["cryptographic_fingerprint"])

    @classmethod
    def create(
        cls,
        *,
        agent_name: str,
        genome_version: str = "1.0.0",
        private_key: Ed25519PrivateKey | bytes | None = None,
        agent_uuid: str | None = None,
        parent_agents: Sequence[str] = (),
        ancestor_chain: Sequence[str] = (),
        genesis_timestamp: float | None = None,
        capabilities: Sequence[Mapping[str, str]] = (),
        permissions: Mapping[str, Sequence[str]] | None = None,
        tools: Sequence[Mapping[str, str]] = (),
        models: Sequence[Mapping[str, Any]] = (),
        memory_config: Mapping[str, Mapping[str, Any]] | None = None,
        reasoning_config: Mapping[str, Any] | None = None,
        objectives: Sequence[Mapping[str, Any]] | None = None,
        constraints: Sequence[Mapping[str, Any]] = (),
        safety_policy: Mapping[str, Any] | None = None,
        resource_limits: Mapping[str, Any] | None = None,
        environment_requirements: Mapping[str, Sequence[str]] | None = None,
        dependencies: Sequence[Mapping[str, Any]] = (),
        evaluation_history: Sequence[Mapping[str, Any]] = (),
        certification_status: Mapping[str, Any] | None = None,
        trust_level: str = "untrusted",
        provenance: Mapping[str, Any] | None = None,
    ) -> "AgentGenome":
        _validate_semver(genome_version)
        key = _coerce_private_key(private_key) if private_key is not None else Ed25519PrivateKey.generate()
        public_key = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        public_key_text = _b64(public_key)
        now = time.time()
        uid = str(uuid.UUID(agent_uuid)) if agent_uuid is not None else str(uuid.uuid4())
        parents = _normalize_uuids(parent_agents, "parent_agents")
        ancestors = _normalize_uuids(ancestor_chain, "ancestor_chain")
        memory = memory_config or {name: {"enabled": False, "retention_seconds": 0, "max_items": 0, "scope": "none"} for name in ("episodic", "semantic", "procedural", "working")}
        document: dict[str, Any] = {
            "schema_version": GENOME_SCHEMA_VERSION,
            "agent_name": str(agent_name).strip(),
            "immutable_identity": {
                "agent_uuid": uid,
                "cryptographic_fingerprint": hashlib.sha256(public_key).hexdigest(),
            },
            "lineage": {"parent_agents": parents, "ancestor_chain": ancestors, "genesis_timestamp": float(genesis_timestamp if genesis_timestamp is not None else now)},
            "genome_version": genome_version,
            "capabilities": [dict(item) for item in capabilities],
            "permissions": {"allow": list((permissions or {}).get("allow", ())), "deny": list((permissions or {}).get("deny", ()))},
            "tools": [dict(item) for item in tools],
            "models": [dict(item) for item in models],
            "memory_config": {name: dict(memory[name]) for name in ("episodic", "semantic", "procedural", "working")},
            "reasoning_config": dict(reasoning_config or {"strategy": "bounded", "depth_limit": 8, "verification_required": True}),
            "objectives": [dict(item) for item in (objectives or [{"id": "default", "kind": "primary", "description": "Execute assigned tasks within policy", "priority": 100}])],
            "constraints": [dict(item) for item in constraints],
            "safety_policy": dict(safety_policy or {"policy_id": "jarvis.default", "overrides": []}),
            "resource_limits": dict(resource_limits or {"cpu_seconds": 60.0, "ram_mb": 1024, "gpu_vram_mb": 0, "network_mb": 64, "wall_clock_seconds": 60.0, "concurrency": 1, "max_processes": 0}),
            "environment_requirements": {key_: list(value) for key_, value in (environment_requirements or {"os": ["any"], "dependencies": [], "hardware": []}).items()},
            "dependencies": [dict(item) for item in dependencies],
            "evaluation_history": [dict(item) for item in evaluation_history],
            "certification_status": dict(certification_status or {"status": "uncertified", "evidence_hash": "0" * 64, "timestamp": now}),
            "trust_level": str(trust_level),
            "provenance": dict(provenance or {"creator": "jarvis", "creation_method": "genome.create", "training_lineage": []}),
            "cryptographic_identity": {"public_key": public_key_text, "signature_algorithm": "Ed25519", "signature": ""},
        }
        genome = cls(document)
        return genome.sign(key)

    def validate(self) -> None:
        schema = json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=128).validate_or_raise(self._document, schema)
        self._validate_identity_uuids()
        fingerprint = hashlib.sha256(_decode_b64(self._document["cryptographic_identity"]["public_key"])).hexdigest()
        if fingerprint != self.cryptographic_fingerprint:
            raise AgentGenomeError("immutable cryptographic fingerprint does not match public key")
        if self._document["cryptographic_identity"]["signature"] and not self.verify():
            raise GenomeSignatureError("genome signature verification failed")
        _validate_semver(self.genome_version)


    def _validate_identity_uuids(self) -> None:
        identity_uuid = self._document["immutable_identity"]["agent_uuid"]
        try:
            uuid.UUID(str(identity_uuid))
        except (ValueError, AttributeError, TypeError) as exc:
            raise AgentGenomeError("immutable agent_uuid is not a valid UUID") from exc
        lineage = self._document["lineage"]
        for field in ("parent_agents", "ancestor_chain"):
            for value in lineage[field]:
                try:
                    uuid.UUID(str(value))
                except (ValueError, AttributeError, TypeError) as exc:
                    raise AgentGenomeError(f"lineage.{field} contains an invalid UUID") from exc

    def unsigned_document(self) -> dict[str, Any]:
        payload = self.document
        payload["cryptographic_identity"]["signature"] = ""
        return payload

    def canonical(self) -> bytes:
        """Return canonical bytes of the unsigned genome contract."""
        return canonical_bytes(self.unsigned_document())

    def hash(self) -> str:
        """Return SHA-256 of the canonical unsigned genome."""
        return hashlib.sha256(self.canonical()).hexdigest()

    def sign(self, private_key: Ed25519PrivateKey | bytes) -> "AgentGenome":
        key = _coerce_private_key(private_key)
        public_key = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        expected = self.cryptographic_fingerprint
        actual = hashlib.sha256(public_key).hexdigest()
        if expected != actual:
            raise GenomeSignatureError("private key does not match genome cryptographic fingerprint")
        payload = self.unsigned_document()
        payload["cryptographic_identity"]["signature"] = _b64(key.sign(canonical_bytes(payload)))
        return AgentGenome(payload)

    def verify(self, public_key: Ed25519PublicKey | bytes | None = None, signature: str | None = None) -> bool:
        try:
            raw_public = _coerce_public_key(public_key) if public_key is not None else _decode_b64(self._document["cryptographic_identity"]["public_key"])
            expected_fingerprint = hashlib.sha256(raw_public).hexdigest()
            if expected_fingerprint != self.cryptographic_fingerprint:
                return False
            encoded_signature = signature if signature is not None else self._document["cryptographic_identity"]["signature"]
            if not encoded_signature:
                return False
            Ed25519PublicKey.from_public_bytes(raw_public).verify(_decode_b64(encoded_signature), self.canonical())
            return True
        except (InvalidSignature, ValueError, TypeError, UnicodeError):
            return False

    def diff(self, other: "AgentGenome | Mapping[str, Any]") -> GenomeDiff:
        return diff(self, other)

    def migrate(self, target_version: str, registry: "GenomeMigrationRegistry | None" = None) -> "AgentGenome":
        return (registry or DEFAULT_MIGRATIONS).migrate(self, target_version)

    def compatibility(self, other: "AgentGenome | Mapping[str, Any]") -> GenomeCompatibility:
        return check_compatibility(self, other)


class GenomeMigrationRegistry:
    """Explicit migration graph. No implicit or lossy migrations are created."""

    def __init__(self) -> None:
        self._edges: dict[str, dict[str, Callable[[dict[str, Any]], dict[str, Any]]]] = {}

    def register(self, source_version: str, target_version: str, migrator: Callable[[dict[str, Any]], dict[str, Any]]) -> None:
        _validate_semver(source_version)
        _validate_semver(target_version)
        if source_version == target_version:
            raise ValueError("source and target versions must differ")
        self._edges.setdefault(source_version, {})[target_version] = migrator

    def path(self, source_version: str, target_version: str) -> tuple[str, ...]:
        _validate_semver(source_version)
        _validate_semver(target_version)
        if source_version == target_version:
            return (source_version,)
        queue: deque[tuple[str, tuple[str, ...]]] = deque([(source_version, (source_version,))])
        visited = {source_version}
        while queue:
            current, chain = queue.popleft()
            for nxt in sorted(self._edges.get(current, {})):
                if nxt == target_version:
                    return chain + (nxt,)
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append((nxt, chain + (nxt,)))
        raise GenomeMigrationError(f"no registered migration path {source_version} -> {target_version}")

    def migrate(self, genome: AgentGenome, target_version: str) -> AgentGenome:
        chain = self.path(genome.genome_version, target_version)
        document = genome.document
        for source, target in zip(chain, chain[1:]):
            document = copy.deepcopy(self._edges[source][target](copy.deepcopy(document)))
            document["genome_version"] = target
            document["cryptographic_identity"]["signature"] = ""
            candidate = AgentGenome(document)
            document = candidate.document
        return AgentGenome(document)


DEFAULT_MIGRATIONS = GenomeMigrationRegistry()


class AgentGenomeRegistry:
    """Durable, signature-verifying and HMAC-protected genome history."""

    def __init__(self, path: str | Path, storage_secret: bytes) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._storage_secret = bytes(storage_secret)
        if len(self._storage_secret) < 32:
            raise ValueError("genome registry storage secret must be at least 32 bytes")
        self._db = sqlite3.connect(str(self.path))
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS genome_current(
                agent_uuid TEXT PRIMARY KEY,
                genome_version TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                canonical_json TEXT NOT NULL,
                recorded_at REAL NOT NULL,
                integrity_tag TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS genome_history(
                agent_uuid TEXT NOT NULL,
                genome_version TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                canonical_json TEXT NOT NULL,
                recorded_at REAL NOT NULL,
                integrity_tag TEXT NOT NULL,
                PRIMARY KEY(agent_uuid, genome_version, content_hash)
            );
            CREATE INDEX IF NOT EXISTS idx_genome_history_agent ON genome_history(agent_uuid, recorded_at DESC);
            """
        )
        current_columns = {row[1] for row in self._db.execute("PRAGMA table_info(genome_current)").fetchall()}
        if "integrity_tag" not in current_columns:
            self._db.execute("ALTER TABLE genome_current ADD COLUMN integrity_tag TEXT NOT NULL DEFAULT ''")
        history_columns = {row[1] for row in self._db.execute("PRAGMA table_info(genome_history)").fetchall()}
        if "integrity_tag" not in history_columns:
            self._db.execute("ALTER TABLE genome_history ADD COLUMN integrity_tag TEXT NOT NULL DEFAULT ''")
        self._db.commit()

    def _integrity(self, agent_uuid: str, genome_version: str, content_hash: str, payload: str) -> str:
        material = "|".join((agent_uuid, genome_version, content_hash, payload)).encode("utf-8")
        return hmac.new(self._storage_secret, material, hashlib.sha256).hexdigest()

    def _verify_row(self, row: tuple[Any, ...]) -> AgentGenome:
        payload = str(row[0])
        genome = AgentGenome(json.loads(payload))
        expected = self._integrity(genome.agent_uuid, genome.genome_version, genome.hash(), payload)
        if not hmac.compare_digest(expected, str(row[1])):
            raise GenomeRollbackError("genome registry integrity verification failed")
        if not genome.verify():
            raise GenomeRollbackError("stored genome signature verification failed")
        return genome

    def save(self, genome: AgentGenome, *, require_signature: bool = True) -> None:
        if require_signature and not genome.verify():
            raise GenomeSignatureError("protected genome registry requires a valid Ed25519 signature")
        payload = json.dumps(genome.document, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        now = time.time()
        digest = genome.hash()
        tag = self._integrity(genome.agent_uuid, genome.genome_version, digest, payload)
        with self._db:
            self._db.execute("INSERT OR IGNORE INTO genome_history VALUES(?,?,?,?,?,?)", (genome.agent_uuid, genome.genome_version, digest, payload, now, tag))
            self._db.execute("DELETE FROM genome_current WHERE agent_uuid=?", (genome.agent_uuid,))
            self._db.execute("INSERT INTO genome_current VALUES(?,?,?,?,?,?)", (genome.agent_uuid, genome.genome_version, digest, payload, now, tag))

    def current(self, genome_id: str) -> AgentGenome | None:
        row = self._db.execute("SELECT canonical_json, integrity_tag FROM genome_current WHERE agent_uuid=?", (str(genome_id),)).fetchone()
        if row is None:
            return None
        return self._verify_row(row)

    def rollback(self, genome_id: str, version: str) -> AgentGenome:
        rows = self._db.execute("SELECT canonical_json, integrity_tag FROM genome_history WHERE agent_uuid=? AND genome_version=? ORDER BY recorded_at DESC", (str(genome_id), str(version))).fetchall()
        if not rows:
            raise GenomeRollbackError(f"no signed genome history for {genome_id}@{version}")
        genome = self._verify_row(rows[0])
        self.save(genome, require_signature=True)
        return genome

    def history(self, genome_id: str, limit: int = 100) -> tuple[AgentGenome, ...]:
        bounded = max(1, min(int(limit), 1000))
        rows = self._db.execute("SELECT canonical_json, integrity_tag FROM genome_history WHERE agent_uuid=? ORDER BY recorded_at DESC LIMIT ?", (str(genome_id), bounded)).fetchall()
        result: list[AgentGenome] = []
        for row in rows:
            result.append(self._verify_row(row))
        return tuple(result)

    def close(self) -> None:
        self._db.close()


def diff(genome_a: AgentGenome | Mapping[str, Any], genome_b: AgentGenome | Mapping[str, Any]) -> GenomeDiff:
    a = genome_a.document if isinstance(genome_a, AgentGenome) else copy.deepcopy(dict(genome_a))
    b = genome_b.document if isinstance(genome_b, AgentGenome) else copy.deepcopy(dict(genome_b))
    added: list[dict[str, Any]] = []
    removed: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []

    def walk(left: Any, right: Any, path: str) -> None:
        if isinstance(left, Mapping) and isinstance(right, Mapping):
            for key in sorted(set(left) - set(right)):
                removed.append({"path": f"{path}.{key}" if path else str(key), "value": copy.deepcopy(left[key])})
            for key in sorted(set(right) - set(left)):
                added.append({"path": f"{path}.{key}" if path else str(key), "value": copy.deepcopy(right[key])})
            for key in sorted(set(left) & set(right)):
                walk(left[key], right[key], f"{path}.{key}" if path else str(key))
            return
        if left != right:
            changed.append({"path": path, "before": copy.deepcopy(left), "after": copy.deepcopy(right)})

    walk(a, b, "")
    return GenomeDiff(tuple(added), tuple(removed), tuple(changed))


def check_compatibility(genome_a: AgentGenome | Mapping[str, Any], genome_b: AgentGenome | Mapping[str, Any]) -> GenomeCompatibility:
    a = genome_a.document if isinstance(genome_a, AgentGenome) else dict(genome_a)
    b = genome_b.document if isinstance(genome_b, AgentGenome) else dict(genome_b)
    reasons: list[str] = []
    schema_a = _semver_tuple(str(a["schema_version"]))
    schema_b = _semver_tuple(str(b["schema_version"]))
    schema_compatible = schema_a[0] == schema_b[0]
    if not schema_compatible:
        reasons.append("schema major versions differ")

    identity_compatible = a["immutable_identity"]["agent_uuid"] == b["immutable_identity"]["agent_uuid"]
    # A compatibility comparison is primarily about evolution of the same logical
    # agent. Different identities are usable as peer contracts but not upgrades.
    if not identity_compatible:
        reasons.append("logical agent identities differ")

    caps_a = {(item["token"], item["scope"]) for item in a["capabilities"]}
    caps_b = {(item["token"], item["scope"]) for item in b["capabilities"]}
    added_caps = tuple(sorted(f"{token}@{scope}" for token, scope in caps_b - caps_a))
    removed_caps = tuple(sorted(f"{token}@{scope}" for token, scope in caps_a - caps_b))
    capability_compatible = not removed_caps
    if removed_caps:
        reasons.append("capabilities were removed")

    tools_a = {(item["tool_id"], item["version"]) for item in a["tools"]}
    tools_b = {(item["tool_id"], item["version"]) for item in b["tools"]}
    changed_tool_ids = {tool_id for tool_id, _ in tools_a ^ tools_b}
    changed_tools = tuple(sorted(changed_tool_ids))
    tool_compatible = not (tools_a - tools_b)
    if not tool_compatible:
        reasons.append("previously available tool pins were removed or changed")

    models_a = {(item["model_id"], item["version"]) for item in a["models"]}
    models_b = {(item["model_id"], item["version"]) for item in b["models"]}
    changed_model_ids = {model_id for model_id, _ in models_a ^ models_b}
    changed_models = tuple(sorted(changed_model_ids))
    model_compatible = not (models_a - models_b)
    if not model_compatible:
        reasons.append("previously available model pins were removed or changed")

    ra, rb = a["resource_limits"], b["resource_limits"]
    resource_compatible = all(
        float(rb[key]) >= float(ra[key]) for key in ("cpu_seconds", "ram_mb", "gpu_vram_mb", "network_mb", "wall_clock_seconds", "concurrency", "max_processes")
    )
    if not resource_compatible:
        reasons.append("resource budgets were tightened")

    ea, eb = a["environment_requirements"], b["environment_requirements"]
    environment_compatible = set(ea["os"]).issubset(set(eb["os"])) and set(ea["dependencies"]).issubset(set(eb["dependencies"])) and set(ea["hardware"]).issubset(set(eb["hardware"]))
    if not environment_compatible:
        reasons.append("required environment capabilities were removed")

    trust_rank = {"untrusted": 0, "restricted": 1, "standard": 2, "elevated": 3, "system": 4}
    security_compatible = trust_rank[str(b["trust_level"])] >= trust_rank[str(a["trust_level"])] and a["safety_policy"]["policy_id"] == b["safety_policy"]["policy_id"]
    if not security_compatible:
        reasons.append("security posture is not monotonic")

    requires_migration = str(a["genome_version"]) != str(b["genome_version"])
    if requires_migration:
        reasons.append("genome versions differ")

    compatible = schema_compatible and identity_compatible and capability_compatible and tool_compatible and model_compatible and resource_compatible and environment_compatible and security_compatible
    return GenomeCompatibility(compatible, schema_compatible, identity_compatible, capability_compatible, tool_compatible, model_compatible, resource_compatible, environment_compatible, security_compatible, requires_migration, tuple(reasons), added_caps, removed_caps, changed_tools, changed_models)


def generate_keypair() -> tuple[Ed25519PrivateKey, str]:
    """Generate a private key plus base64url raw public key for external storage."""
    private = Ed25519PrivateKey.generate()
    raw = private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return private, _b64(raw)


def _normalize_uuids(values: Sequence[str], field: str) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        try:
            normalized = str(uuid.UUID(str(value)))
        except (ValueError, AttributeError, TypeError) as exc:
            raise AgentGenomeError(f"{field} contains an invalid UUID") from exc
        if normalized not in seen:
            result.append(normalized)
            seen.add(normalized)
    return result


def _validate_semver(value: str) -> None:
    if not _SEMVER_RE.fullmatch(str(value)):
        raise AgentGenomeError(f"invalid semantic version: {value!r}")


def _semver_tuple(value: str) -> tuple[int, int, int]:
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", value)
    if not match:
        raise AgentGenomeError(f"invalid semantic version: {value!r}")
    return tuple(int(part) for part in match.groups())


def _coerce_private_key(value: Ed25519PrivateKey | bytes) -> Ed25519PrivateKey:
    if isinstance(value, Ed25519PrivateKey):
        return value
    raw = bytes(value)
    if len(raw) != 32:
        raise GenomeSignatureError("Ed25519 private key seed must contain exactly 32 bytes")
    return Ed25519PrivateKey.from_private_bytes(raw)


def _coerce_public_key(value: Ed25519PublicKey | bytes) -> bytes:
    if isinstance(value, Ed25519PublicKey):
        return value.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    raw = bytes(value)
    if len(raw) != 32:
        raise GenomeSignatureError("Ed25519 public key must contain exactly 32 bytes")
    return raw


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _decode_b64(value: str) -> bytes:
    text = str(value)
    if not text or any(ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=" for ch in text):
        raise ValueError("invalid base64url data")
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))

"""Validated machine-readable skill contracts for JARVIS plugins."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class SkillManifest:
    """Least-privilege skill declaration."""

    name: str
    version: str
    runtime: str
    capabilities: tuple[str, ...]
    inputs: Mapping[str, str]
    outputs: Mapping[str, str]
    risk_level: int
    dependencies: tuple[str, ...] = ()

    def canonical(self) -> bytes:
        """Serialize the contract deterministically."""
        return json.dumps({"name": self.name, "version": self.version, "runtime": self.runtime, "capabilities": self.capabilities, "inputs": dict(self.inputs), "outputs": dict(self.outputs), "risk_level": self.risk_level, "dependencies": self.dependencies}, sort_keys=True, separators=(",", ":")).encode("utf-8")

    @property
    def digest(self) -> str:
        """Return a stable contract fingerprint."""
        return hashlib.sha256(self.canonical()).hexdigest()


class SkillManifestRegistry:
    """Register and validate skill contracts before activation."""

    def __init__(self, *, max_skills: int = 2048) -> None:
        self.max_skills = max(1, min(int(max_skills), 10_000))
        self._skills: dict[str, SkillManifest] = {}

    def register(self, manifest: SkillManifest) -> None:
        """Validate and register a skill manifest."""
        if not manifest.name.strip() or not manifest.version.strip() or not manifest.runtime.strip():
            raise ValueError("skill identity and runtime are required")
        if not 0 <= manifest.risk_level <= 5:
            raise ValueError("risk_level must be between 0 and 5")
        if any(not item.strip() for item in manifest.capabilities):
            raise ValueError("capabilities must be non-empty")
        if manifest.name not in self._skills and len(self._skills) >= self.max_skills:
            raise RuntimeError("skill registry capacity reached")
        self._skills[manifest.name] = manifest

    def get(self, name: str) -> SkillManifest:
        """Return a registered skill or raise KeyError."""
        return self._skills[str(name)]

    def compatible(self, *, capability: str, max_risk: int = 3) -> list[SkillManifest]:
        """Return skills matching a capability and risk ceiling."""
        return sorted((skill for skill in self._skills.values() if capability in skill.capabilities and skill.risk_level <= max_risk), key=lambda skill: (skill.risk_level, skill.name, skill.version))

    def snapshot(self) -> dict[str, Any]:
        """Return registered manifest metadata."""
        return {"skills": [{"name": skill.name, "version": skill.version, "runtime": skill.runtime, "risk_level": skill.risk_level, "digest": skill.digest} for skill in sorted(self._skills.values(), key=lambda item: item.name)]}



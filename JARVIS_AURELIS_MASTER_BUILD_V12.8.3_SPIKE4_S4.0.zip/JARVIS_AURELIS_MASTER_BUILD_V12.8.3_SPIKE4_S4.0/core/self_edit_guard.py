"""Transactional, authorized self-modification guard."""
from __future__ import annotations
import hashlib
import os
import tempfile
import time
import threading
from pathlib import Path
from core.safe_open import SafeWorkspace, SafeOpenError
from typing import Any

class SelfEditGuard:
    def __init__(self, project_root: Path):
        self.project_root = Path(project_root).resolve()
        self._proposals: dict[str, Any] = {}
        self._lock = threading.RLock()
        self.proposal_ttl = 900

    @staticmethod
    def _hash(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def prepare(self, rel_path: Path, new_content: str) -> dict[str, Any]:
        rel = Path(rel_path)
        target = (self.project_root / rel).resolve()
        if not target.is_relative_to(self.project_root) or not target.is_file():
            return {"ok": False, "error": "invalid self-edit target"}
        current = target.read_text(encoding="utf-8")
        proposal_id = hashlib.sha256(f"{rel}:{time.time_ns()}".encode()).hexdigest()[:16]
        proposal = {
            "proposal_id": proposal_id, "path": str(rel), "content": new_content,
            "original_hash": self._hash(current), "new_hash": self._hash(new_content),
            "hash": self._hash(new_content)[:16],
            "created_at": time.time(), "consumed": False,
        }
        with self._lock:
            self._proposals[proposal_id] = proposal
        return {"ok": True, **{k:v for k,v in proposal.items() if k != "content"}}

    def apply(self, proposal: dict[str, Any], *, permission_engine=None, approval_token: str | None = None, authorization_granted: bool = False) -> dict[str, Any]:
        """Serialize proposal application so one proposal cannot be committed twice concurrently."""
        with self._lock:
            return self._apply_unlocked(
                proposal, permission_engine=permission_engine, approval_token=approval_token,
                authorization_granted=authorization_granted
            )

    def _apply_unlocked(self, proposal: dict[str, Any], *, permission_engine=None, approval_token: str | None = None, authorization_granted: bool = False) -> dict[str, Any]:
        pid = proposal.get("proposal_id")
        with self._lock:
            p = self._proposals.get(pid)
        if not p:
            return {"ok": False, "error": "Proposal not found"}
        if p.get("consumed"):
            return {"ok": False, "error": "Proposal already consumed"}
        if time.time() - float(p.get("created_at", 0)) > self.proposal_ttl:
            return {"ok": False, "error": "Proposal expired"}
        if permission_engine is None or not permission_engine.verify(approval_token or "", capability="meta.self_edit"):
            return {"ok": False, "error": "Authorization required"}
        rel = Path(str(p.get("path", "")))
        try:
            safe = SafeWorkspace(self.project_root)
            current = safe.read_text(rel)
        except (SafeOpenError, FileNotFoundError, OSError) as exc:
            return {"ok": False, "error": f"Path escape attempt or inaccessible target: {exc}"}
        if self._hash(current) != p["original_hash"]:
            return {"ok": False, "error": "Concurrent modification detected"}
        content = str(p["content"])
        if rel.suffix == ".py":
            import py_compile
            fd, tmp_name = tempfile.mkstemp(prefix=f".{rel.name}.", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    handle.write(content); handle.flush(); os.fsync(handle.fileno())
                py_compile.compile(tmp_name, doraise=True)
            except Exception as exc:
                Path(tmp_name).unlink(missing_ok=True)
                return {"ok": False, "error": str(exc)}
            finally:
                Path(tmp_name).unlink(missing_ok=True)
        backup = self.project_root / "data" / "backups" / f"{rel.name}.bak.{time.time_ns()}"
        backup.parent.mkdir(parents=True, exist_ok=True)
        backup.write_text(current, encoding="utf-8")
        with backup.open("rb") as bf:
            os.fsync(bf.fileno())
        try:
            safe.atomic_write_text(rel, content)
            verified = safe.read_text(rel)
            if self._hash(verified) != p["new_hash"]:
                raise IOError("post-write hash verification failed")
            p["consumed"] = True
            return {"ok": True, "path": str(rel), "backup": str(backup)}
        except Exception as exc:
            try:
                safe.atomic_write_text(rel, current)
            except Exception:
                return {"ok": False, "error": f"Apply failed and rollback failed: {exc}"}
            return {"ok": False, "error": str(exc)}

    def propose(self, file_path: str, old_code: str, new_code: str) -> dict[str, Any]:
        target = (self.project_root / file_path).resolve()
        if not target.is_relative_to(self.project_root) or not target.is_file():
            return {"ok": False, "error": "invalid self-edit target"}
        current = target.read_text(encoding="utf-8")
        if old_code not in current:
            return {"ok": False, "error": "old_code not found"}
        return self.prepare(target.relative_to(self.project_root), current.replace(old_code, new_code, 1))



"""Centralized error handling and recovery.

Provides structured error reporting, automatic retry logic,
and graceful degradation strategies.
"""
from __future__ import annotations

import logging
import traceback
from typing import Any, Callable, Dict

logger = logging.getLogger("jarvis.errors")


class ErrorHandler:
    """Centralized error handling with recovery strategies."""

    def __init__(self):
        self._strategies: Dict[str, Callable[[Exception], Any]] = {}
        self._error_counts: Dict[str, int] = {}
        self._max_retries = 3

    def register_strategy(self, error_type: str, handler: Callable[[Exception], Any]) -> None:
        """Register a recovery strategy for an error type."""
        self._strategies[error_type] = handler

    def handle(self, exc: Exception, context: str = "") -> Dict[str, Any]:
        """Handle an exception with optional recovery.

        Args:
            exc: The exception that occurred.
            context: Description of where the error occurred.

        Returns:
            Error report dict with recovery info.
        """
        error_type = type(exc).__name__
        self._error_counts[error_type] = self._error_counts.get(error_type, 0) + 1

        report = {
            "error_type": error_type,
            "message": str(exc),
            "context": context,
            "traceback": traceback.format_exc(),
            "count": self._error_counts[error_type],
        }

        # Try recovery strategy
        recovery = None
        if error_type in self._strategies:
            try:
                recovery = self._strategies[error_type](exc)
                report["recovered"] = True
                report["recovery_result"] = recovery
            except Exception as recovery_exc:
                report["recovered"] = False
                report["recovery_error"] = str(recovery_exc)
        else:
            report["recovered"] = False

        logger.error("error_handled", extra={"report": report})
        return report

    def get_stats(self) -> Dict[str, Any]:
        return {
            "error_counts": self._error_counts,
            "strategies": list(self._strategies.keys()),
        }



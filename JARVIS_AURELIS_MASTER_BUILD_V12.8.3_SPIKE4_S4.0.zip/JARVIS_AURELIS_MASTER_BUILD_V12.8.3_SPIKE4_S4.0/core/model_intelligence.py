"""Adaptive model routing, scoring, and privacy-aware backend selection."""
from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Sequence


@dataclass(frozen=True)
class ModelProfile:
    """Observed model characteristics used by the adaptive router."""

    name: str
    capabilities: tuple[str, ...] = ()
    privacy: str = "standard"
    cost_score: float = 1.0
    latency_score: float = 1.0
    quality_score: float = 1.0
    memory_mb: int = 0


class ModelIntelligence:
    """Learning layer that scores backends from verified task outcomes."""

    def __init__(self) -> None:
        self._profiles: dict[str, ModelProfile] = {}
        self._observations: list[dict[str, Any]] = []
        self._lock = threading.RLock()
        self._max_observations = 50_000
        self._routing_window = deque(maxlen=2_000)
        self._routing_stats: dict[tuple[str, str], dict[str, float]] = {}
        self._neural_router: Any | None = None
        self._neural_router_error: str | None = None

    def register(self, profile: ModelProfile) -> None:
        """Register a model profile."""
        if not profile.name:
            raise ValueError("model name required")
        with self._lock:
            self._profiles[profile.name] = profile

    def record(self, model: str, *, success: bool, latency_ms: float, task_type: str = "default", quality: float | None = None, tokens: int = 0, task_text: str = "") -> None:
        """Record a bounded outcome from a completed inference."""
        if model not in self._profiles:
            self.register(ModelProfile(model))
        observation = {
            "model": model,
            "success": bool(success),
            "latency_ms": max(0.0, float(latency_ms)),
            "task_type": str(task_type),
            "task_text": str(task_text)[:10_000],
            "quality": None if quality is None else max(0.0, min(1.0, float(quality))),
            "tokens": max(0, int(tokens)),
            "timestamp": time.time(),
        }
        with self._lock:
            self._observations.append(observation)
            if len(self._observations) > self._max_observations:
                del self._observations[:-self._max_observations]
            if len(self._routing_window) == self._routing_window.maxlen:
                old = self._routing_window[0]
                self._adjust_routing_stats(old, -1.0)
            self._routing_window.append(observation)
            self._adjust_routing_stats(observation, 1.0)

    def _adjust_routing_stats(self, observation: dict[str, Any], sign: float) -> None:
        key = (str(observation["model"]), str(observation["task_type"]))
        stats = self._routing_stats.setdefault(key, {
            "count": 0.0, "successes": 0.0, "latency_sum": 0.0,
            "quality_sum": 0.0, "quality_count": 0.0})
        stats["count"] += sign
        stats["successes"] += sign * float(bool(observation["success"]))
        stats["latency_sum"] += sign * float(observation["latency_ms"])
        if observation.get("quality") is not None:
            stats["quality_sum"] += sign * float(observation["quality"])
            stats["quality_count"] += sign
        if stats["count"] <= 0.0:
            self._routing_stats.pop(key, None)

    def choose(self, *, task_type: str = "default", privacy: str = "standard", required_capabilities: tuple[str, ...] = (), available_memory_mb: int | None = None, candidates: Sequence[str] | None = None, task_text: str = "") -> str | None:
        """Choose a compatible model using verified outcomes and neural routing when trained.

        The neural model is advisory only: hard resource/privacy/capability
        constraints are always applied before its recommendation.
        """
        with self._lock:
            allowed = set(str(item) for item in candidates) if candidates is not None else None
            compatible = []
            for name, profile in self._profiles.items():
                if allowed is not None and name not in allowed:
                    continue
                if privacy == "private" and profile.privacy != "private":
                    continue
                if available_memory_mb is not None and profile.memory_mb and profile.memory_mb > available_memory_mb:
                    continue
                if required_capabilities and not set(required_capabilities).issubset(profile.capabilities):
                    continue
                stats = self._routing_stats.get((name, task_type))
                count = stats["count"] if stats else 0.0
                success_rate = (stats["successes"] / count) if count else 0.7
                latency = (stats["latency_sum"] / count) if count else 5000.0
                quality_count = stats["quality_count"] if stats else 0.0
                quality = ((stats["quality_sum"] / quality_count)
                           if quality_count else profile.quality_score)
                score = quality * 0.55 + success_rate * 0.30 + max(0.0, 1.0 - min(latency / 30_000.0, 1.0)) * 0.15
                score -= profile.cost_score * 0.01
                compatible.append((score, name))
            if not compatible:
                return None
            fallback = max(compatible)[1]
            neural = self._neural_router
            if neural is not None and getattr(neural, "trained", False) and task_text:
                try:
                    suggestion = neural.suggest(task_text, [name for _, name in compatible])
                    if suggestion in {name for _, name in compatible}:
                        return suggestion
                except Exception as exc:
                    self._neural_router_error = str(exc)
            return fallback

    def train_neural_router(self, *, min_observations: int = 24, min_score: float = 0.5) -> dict[str, Any]:
        """Train the bounded neural router from observed verified outcomes.

        Training is explicit and therefore never blocks normal inference.
        """
        with self._lock:
            rows = list(self._observations)
        good = [row for row in rows if bool(row["success"]) and float(row.get("quality") if row.get("quality") is not None else 0.0) >= min_score and str(row.get("task_text", "")).strip()]
        labels = sorted({str(row["model"]) for row in good})
        if len(good) < max(4, int(min_observations)) or len(labels) < 2:
            return {"ok": False, "trained": False, "reason": "insufficient diverse verified observations", "observations": len(good), "models": len(labels)}
        try:
            from core.dl_features import RoutingTrainer
            trainer = RoutingTrainer(min_score=min_score, dim=64, seed=42)
            for row in good[-10_000:]:
                quality = float(row.get("quality") if row.get("quality") is not None else (1.0 if row["success"] else 0.0))
                trainer.record(str(row.get("task_text") or row["task_type"]), str(row["model"]), quality)
            report = trainer.train(epochs=60, batch_size=min(16, len(good)), validation_split=0.2, patience=8)
            self._neural_router = trainer
            self._neural_router_error = None
            return {"ok": True, "trained": trainer.trained, "observations": len(good), "models": len(labels), "validation_accuracy": report.val_accuracy}
        except Exception as exc:
            self._neural_router_error = str(exc)
            return {"ok": False, "trained": False, "reason": str(exc), "observations": len(good), "models": len(labels)}

    def snapshot(self) -> dict[str, Any]:
        """Return routing intelligence metrics."""
        with self._lock:
            return {"models": len(self._profiles), "observations": len(self._observations), "profiles": {k: v.__dict__.copy() for k, v in self._profiles.items()}, "neural_router_trained": bool(self._neural_router and getattr(self._neural_router, "trained", False)), "neural_router_error": self._neural_router_error}



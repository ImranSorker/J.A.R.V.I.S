"""Unified tool gateway combining schema, agent policy, autonomy and risk controls."""
from __future__ import annotations
import inspect, logging
from typing import Any, Optional
from core.circuit_breaker import CircuitBreakerRegistry
from core.permission_engine import PermissionEngine
from core.schema_validator import SchemaValidationError, SchemaValidator
from core.types import RiskLevel, ToolSpec
logger=logging.getLogger("jarvis.tools")
class ToolRegistry:
    """All model/agent-originated tool calls pass through this gateway."""
    def __init__(self,permission_engine:Optional[PermissionEngine]=None,schema_validator:Optional[SchemaValidator]=None,circuit_breakers:Optional[CircuitBreakerRegistry]=None,agent_policy_engine:Optional[Any]=None,autonomy_engine:Optional[Any]=None,global_capabilities:tuple[str,...]=( ))->None:
        self._tools={}; self._permission=permission_engine or PermissionEngine(); self._validator=schema_validator or SchemaValidator(); self._circuit_breakers=circuit_breakers or CircuitBreakerRegistry(); self._agent_policies=agent_policy_engine; self._autonomy=autonomy_engine; self._global_capabilities=global_capabilities
    def register(self,spec:ToolSpec)->None:
        name=str(spec.name).strip()
        if not name or not callable(spec.handler) or not isinstance(spec.parameters,dict):raise ValueError(f"invalid tool {name}")
        self._tools[name]=spec
        if self._agent_policies:self._agent_policies.register_tool(name)
    def get(self,name:str)->Optional[ToolSpec]:return self._tools.get(name)
    def list_tools(self)->list[ToolSpec]:return list(self._tools.values())
    def execute(self,name:str,arguments:dict[str,Any],approval_token:Optional[str]=None,*,agent_name:Optional[str]=None,mission_id:Optional[str]=None,principal_capabilities:tuple[str,...]=())->Any:
        spec=self._tools.get(name)
        if spec is None:return {"ok":False,"error":"tool_not_found"}
        if not isinstance(arguments,dict):return {"ok":False,"error":"tool_arguments_must_be_object"}
        if spec.parameters:
            try:self._validator.validate_or_raise(arguments,spec.parameters)
            except SchemaValidationError as exc:return exc.to_dict()
        autonomous=bool(agent_name and mission_id and self._autonomy)
        if self._agent_policies and agent_name:
            decision=self._agent_policies.authorize_tool(agent_name,name,principal_capabilities,tuple(spec.capabilities or ()),network_required=any(x in {"web","network","browser"} for x in (spec.capabilities or ())))
            if not decision.allowed:return {"ok":False,"error":f"agent_policy_denied:{decision.reason}"}
            if not autonomous and decision.requires_approval:return {"ok":False,"error":"agent_policy_requires_approval"}
            if not autonomous and spec.risk in (RiskLevel.HIGH,RiskLevel.CRITICAL):
                caps=list(spec.capabilities or []); authorized=all(self._permission.verify(approval_token or "",capability=c) for c in caps) if caps else self._permission.verify(approval_token or "")
                if not authorized:return {"ok":False,"error":"high_risk_tool_requires_valid_approval"}
        elif spec.risk in (RiskLevel.HIGH,RiskLevel.CRITICAL):
            caps=list(spec.capabilities or []); authorized=all(self._permission.verify(approval_token or "",capability=c) for c in caps) if caps else self._permission.verify(approval_token or "")
            if not authorized:return {"ok":False,"error":"high_risk_tool_requires_valid_approval"}
        execution_grant = None
        if autonomous:
            execution_grant = self._autonomy.issue_execution_grant(mission_id, spec.capabilities[0] if spec.capabilities else spec.name, agent_name)
            action="bounded" if spec.risk in (RiskLevel.LOW,RiskLevel.MEDIUM,RiskLevel.HIGH) else "critical"
            external=any(x in {"computer.write","external.write","financial.transaction","system.modify"} for x in (spec.capabilities or ()))
            try:self._autonomy.authorize(mission_id,action=action,external=external,required_capabilities=tuple(spec.capabilities or ()),granted_capabilities=self._global_capabilities)
            except Exception as exc:return {"ok":False,"error":f"autonomy_denied:{exc}"}
        def invoke()->Any:
            call_args=dict(arguments)
            try:params=inspect.signature(spec.handler).parameters
            except (TypeError,ValueError):params={}
            if "approval_token" in params and "approval_token" not in call_args:
                call_args["approval_token"] = approval_token
            if "_authorization_granted" in params:call_args["_authorization_granted"]=bool(autonomous)
            if "agent_name" in params and agent_name:call_args["agent_name"]=agent_name
            if "mission_id" in params and mission_id:call_args["mission_id"]=mission_id
            if "execution_grant" in params and execution_grant:call_args["execution_grant"]=execution_grant
            return {"ok":True,"result":spec.handler(**call_args)}
        try:
            result=self._circuit_breakers.get(name).call(invoke)
            if autonomous:
                deltas={"network_requests":1} if any(x in {"web","network"} for x in (spec.capabilities or ())) else {}
                if any(x in {"browser","computer","computer.write","external.write"} for x in (spec.capabilities or ())):deltas["external_actions"]=1
                if name in {"file_write","write_file","self_edit"}:deltas["files_written"]=1
                if deltas:
                    try:self._autonomy.consume(mission_id,**deltas)
                    except Exception as exc:return {"ok":False,"error":f"autonomy_budget_exceeded:{exc}"}
            return result
        except Exception as exc:
            logger.exception("tool_execution_failed",extra={"tool":name,"agent":agent_name}); return {"ok":False,"error":str(exc)}



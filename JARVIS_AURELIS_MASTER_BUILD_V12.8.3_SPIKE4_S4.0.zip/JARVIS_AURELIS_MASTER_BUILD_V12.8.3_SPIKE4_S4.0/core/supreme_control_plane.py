"""Unified local runtime hardening and operational control plane.

This module consolidates the final V12.8.0 hardening capabilities into one
explicit service: resource governance, cryptographic capability grants,
provenance, startup diagnostics, process-tree auditing, zero-listener checks,
and restart-safe state records.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterator, Mapping

import psutil

from core.security_secret import derive_secret


@dataclass(frozen=True, slots=True)
class ResourceBudget:
    """Bounded runtime resources available to one JARVIS local profile."""

    max_concurrent_tasks: int = 8
    max_background_tasks: int = 16
    max_memory_mb: int = 8192
    max_network_requests: int = 0
    max_external_actions: int = 20
    max_files_written: int = 500

    def __post_init__(self) -> None:
        if self.max_concurrent_tasks < 1:
            raise ValueError("max_concurrent_tasks must be >= 1")
        if self.max_background_tasks < 1:
            raise ValueError("max_background_tasks must be >= 1")
        if self.max_memory_mb < 128:
            raise ValueError("max_memory_mb must be >= 128")
        if self.max_network_requests < 0:
            raise ValueError("max_network_requests must be >= 0")
        if self.max_external_actions < 0 or self.max_files_written < 0:
            raise ValueError("action and file limits must be >= 0")


@dataclass(frozen=True, slots=True)
class ResourceLease:
    """One bounded resource reservation."""

    lease_id: str
    owner: str
    slots: int
    background: bool
    memory_mb: int
    external_actions: int
    files_written: int
    created_at: float


class ResourceGovernor:
    """Enforce global bounded resource reservations with deterministic release."""

    def __init__(self, budget: ResourceBudget) -> None:
        self.budget = budget
        self._lock = threading.RLock()
        self._leases: dict[str, ResourceLease] = {}
        self._used = {"slots": 0, "memory_mb": 0, "external_actions": 0, "files_written": 0}

    def acquire(
        self,
        owner: str,
        *,
        slots: int = 1,
        background: bool = False,
        memory_mb: int = 0,
        external_actions: int = 0,
        files_written: int = 0,
    ) -> ResourceLease:
        """Reserve bounded resources or raise ``ResourceExhaustedError``."""
        values = {
            "slots": int(slots),
            "memory_mb": int(memory_mb),
            "external_actions": int(external_actions),
            "files_written": int(files_written),
        }
        if any(value < 0 for value in values.values()) or values["slots"] < 1:
            raise ValueError("resource reservation values are invalid")
        owner_name = str(owner).strip() or "unknown"
        limits = {
            "slots": self.budget.max_concurrent_tasks,
            "memory_mb": self.budget.max_memory_mb,
            "external_actions": self.budget.max_external_actions,
            "files_written": self.budget.max_files_written,
        }
        with self._lock:
            if any(self._used[key] + values[key] > limits[key] for key in values):
                raise ResourceExhaustedError("runtime resource budget exceeded")
            background_used = sum(lease.slots for lease in self._leases.values() if lease.background)
            if bool(background) and background_used + values["slots"] > self.budget.max_background_tasks:
                raise ResourceExhaustedError("background task budget exceeded")
            lease = ResourceLease(
                lease_id=f"lease_{uuid.uuid4().hex}",
                owner=owner_name,
                background=bool(background),
                created_at=time.time(),
                **values,
            )
            self._leases[lease.lease_id] = lease
            for key, value in values.items():
                self._used[key] += value
            return lease

    def release(self, lease: ResourceLease | str) -> bool:
        """Release a reservation exactly once."""
        lease_id = lease.lease_id if isinstance(lease, ResourceLease) else str(lease)
        with self._lock:
            existing = self._leases.pop(lease_id, None)
            if existing is None:
                return False
            self._used["slots"] = max(0, self._used["slots"] - existing.slots)
            self._used["memory_mb"] = max(0, self._used["memory_mb"] - existing.memory_mb)
            self._used["external_actions"] = max(0, self._used["external_actions"] - existing.external_actions)
            self._used["files_written"] = max(0, self._used["files_written"] - existing.files_written)
            return True

    @contextmanager
    def reservation(self, owner: str, **kwargs: int) -> Iterator[ResourceLease]:
        """Context-manage one bounded resource reservation."""
        lease = self.acquire(owner, **kwargs)
        try:
            yield lease
        finally:
            self.release(lease)

    def snapshot(self) -> dict[str, Any]:
        """Return non-sensitive utilization state."""
        with self._lock:
            return {
                "budget": asdict(self.budget),
                "used": dict(self._used),
                "active_leases": len(self._leases),
                "background_active": sum(lease.slots for lease in self._leases.values() if lease.background),
                "background_budget": self.budget.max_background_tasks,
                "owners": sorted({lease.owner for lease in self._leases.values()}),
            }


class ResourceExhaustedError(RuntimeError):
    """Raised when a resource reservation would exceed the configured budget."""


@dataclass(frozen=True, slots=True)
class CapabilityGrant:
    """Cryptographically signed, short-lived capability authorization."""

    grant_id: str
    principal: str
    capability: str
    resource: str
    issued_at: float
    expires_at: float
    nonce: str
    signature: str

    def payload(self) -> bytes:
        """Serialize the signed grant payload canonically."""
        return json.dumps(
            {
                "grant_id": self.grant_id,
                "principal": self.principal,
                "capability": self.capability,
                "resource": self.resource,
                "issued_at": self.issued_at,
                "expires_at": self.expires_at,
                "nonce": self.nonce,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")


class CapabilityBroker:
    """Issue and consume single-use HMAC capability grants."""

    def __init__(self, secret: bytes) -> None:
        self._secret = bytes(secret)
        if len(self._secret) < 32:
            raise ValueError("capability broker secret must be at least 32 bytes")
        self._lock = threading.RLock()
        self._consumed: set[str] = set()

    def issue(
        self,
        principal: str,
        capability: str,
        resource: str = "*",
        *,
        ttl_seconds: float = 60.0,
    ) -> CapabilityGrant:
        """Create a bounded grant."""
        now = time.time()
        ttl = max(1.0, min(float(ttl_seconds), 3600.0))
        grant = CapabilityGrant(
            grant_id=f"grant_{uuid.uuid4().hex}",
            principal=str(principal).strip(),
            capability=str(capability).strip(),
            resource=str(resource).strip() or "*",
            issued_at=now,
            expires_at=now + ttl,
            nonce=secrets.token_urlsafe(24),
            signature="",
        )
        signature = hmac.new(self._secret, grant.payload(), hashlib.sha256).hexdigest()
        return CapabilityGrant(**{**asdict(grant), "signature": signature})

    def consume(
        self,
        grant: CapabilityGrant,
        *,
        principal: str,
        capability: str,
        resource: str = "*",
    ) -> None:
        """Validate a grant and atomically consume it exactly once."""
        now = time.time()
        if now >= grant.expires_at or grant.issued_at > now + 5.0:
            raise PermissionError("capability grant expired or invalid")
        if grant.principal != str(principal) or grant.capability != str(capability):
            raise PermissionError("capability grant audience mismatch")
        if grant.resource not in {"*", str(resource)}:
            raise PermissionError("capability grant resource mismatch")
        expected = hmac.new(self._secret, grant.payload(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, grant.signature):
            raise PermissionError("capability grant signature invalid")
        with self._lock:
            if grant.grant_id in self._consumed:
                raise PermissionError("capability grant replay detected")
            self._consumed.add(grant.grant_id)

    def snapshot(self) -> dict[str, int]:
        """Return grant inventory without exposing grant contents."""
        with self._lock:
            return {"consumed_grants": len(self._consumed)}


class ProvenanceLedger:
    """Durable provenance and integrity ledger for memory/RAG artifacts."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.execute(
            """CREATE TABLE IF NOT EXISTS provenance (
                artifact_id TEXT PRIMARY KEY,
                owner TEXT NOT NULL,
                workspace TEXT NOT NULL,
                source_id TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                version TEXT NOT NULL,
                embedding_model TEXT NOT NULL,
                retention_policy TEXT NOT NULL,
                created_at REAL NOT NULL,
                tombstoned INTEGER NOT NULL DEFAULT 0
            )"""
        )
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_provenance_owner ON provenance(owner, workspace, tombstoned)")
        self._db.commit()

    @staticmethod
    def content_hash(content: str | bytes) -> str:
        """Return a SHA-256 digest for one content payload."""
        raw = content.encode("utf-8") if isinstance(content, str) else bytes(content)
        return hashlib.sha256(raw).hexdigest()

    def register(
        self,
        artifact_id: str,
        *,
        owner: str,
        workspace: str,
        source_id: str,
        content: str | bytes,
        version: str = "1",
        embedding_model: str = "none",
        retention_policy: str = "standard",
    ) -> str:
        """Register or refresh one provenance record and return its digest."""
        digest = self.content_hash(content)
        values = (
            str(artifact_id),
            str(owner),
            str(workspace),
            str(source_id),
            digest,
            str(version),
            str(embedding_model),
            str(retention_policy),
            time.time(),
        )
        with self._lock:
            self._db.execute(
                """INSERT INTO provenance(
                    artifact_id,owner,workspace,source_id,content_hash,version,
                    embedding_model,retention_policy,created_at,tombstoned
                ) VALUES(?,?,?,?,?,?,?,?,?,0)
                ON CONFLICT(artifact_id) DO UPDATE SET
                    owner=excluded.owner,
                    workspace=excluded.workspace,
                    source_id=excluded.source_id,
                    content_hash=excluded.content_hash,
                    version=excluded.version,
                    embedding_model=excluded.embedding_model,
                    retention_policy=excluded.retention_policy,
                    created_at=excluded.created_at,
                    tombstoned=0""",
                values,
            )
            self._db.commit()
        return digest

    def verify(self, artifact_id: str, content: str | bytes) -> bool:
        """Verify one artifact against the durable ledger."""
        digest = self.content_hash(content)
        with self._lock:
            row = self._db.execute(
                "SELECT content_hash,tombstoned FROM provenance WHERE artifact_id=?",
                (str(artifact_id),),
            ).fetchone()
        return bool(row and int(row[1]) == 0 and hmac.compare_digest(str(row[0]), digest))

    def lookup(self, artifact_id: str) -> dict[str, Any] | None:
        """Return one non-sensitive provenance record, or ``None`` when unknown."""
        with self._lock:
            row = self._db.execute(
                "SELECT artifact_id,owner,workspace,source_id,content_hash,version,embedding_model,retention_policy,created_at,tombstoned FROM provenance WHERE artifact_id=?",
                (str(artifact_id),),
            ).fetchone()
        if row is None:
            return None
        keys = (
            "artifact_id", "owner", "workspace", "source_id", "content_hash",
            "version", "embedding_model", "retention_policy", "created_at", "tombstoned",
        )
        return dict(zip(keys, row))

    def tombstone(self, artifact_id: str) -> bool:
        """Cryptographically mark one artifact as deleted from the active namespace."""
        with self._lock:
            cur = self._db.execute("UPDATE provenance SET tombstoned=1 WHERE artifact_id=?", (str(artifact_id),))
            self._db.commit()
            return cur.rowcount > 0

    def stats(self) -> dict[str, int]:
        """Return ledger counts."""
        with self._lock:
            total = int(self._db.execute("SELECT COUNT(*) FROM provenance").fetchone()[0])
            active = int(self._db.execute("SELECT COUNT(*) FROM provenance WHERE tombstoned=0").fetchone()[0])
        return {"total": total, "active": active, "tombstoned": total - active}

    def close(self) -> None:
        """Close the ledger database."""
        with self._lock:
            self._db.close()


@dataclass(frozen=True, slots=True)
class ProcessAudit:
    """One process-tree audit result."""

    pid: int
    name: str
    executable: str
    allowed: bool


class ProcessMonitor:
    """Audit descendants and listening sockets without creating any network resources."""

    def __init__(self, *, allowed_names: tuple[str, ...] = ()) -> None:
        self.allowed_names = tuple(item.lower() for item in allowed_names if str(item).strip())

    def descendants(self, root_pid: int | None = None) -> tuple[ProcessAudit, ...]:
        """Return a deterministic snapshot of the descendant process tree."""
        root = psutil.Process(root_pid or os.getpid())
        rows: list[ProcessAudit] = []
        try:
            processes = root.children(recursive=True)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            processes = []
        for process in processes:
            try:
                name = process.name()
                executable = process.exe()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            executable_path = Path(executable)
            allowed = not self.allowed_names or name.lower() in self.allowed_names or executable_path.name.lower() in self.allowed_names or executable_path.stem.lower() in self.allowed_names
            rows.append(ProcessAudit(process.pid, name, executable, allowed))
        return tuple(sorted(rows, key=lambda item: (item.allowed, item.name.lower(), item.pid)))

    def _listeners(self) -> tuple[tuple[dict[str, Any], ...], str | None]:
        """Return current-process listeners and an inspection error, if any."""
        rows: list[dict[str, Any]] = []
        try:
            connections = psutil.net_connections(kind="inet")
        except (psutil.AccessDenied, psutil.NoSuchProcess) as exc:
            return (), f"{type(exc).__name__}: {exc}"
        current_pid = os.getpid()
        for connection in connections:
            if connection.pid != current_pid or not connection.laddr:
                continue
            status = str(connection.status).upper()
            if status != psutil.CONN_LISTEN:
                continue
            rows.append(
                {
                    "family": str(connection.family),
                    "address": str(connection.laddr.ip),
                    "port": int(connection.laddr.port),
                    "status": status,
                }
            )
        return tuple(sorted(rows, key=lambda row: (row["address"], row["port"]))), None

    def listeners(self) -> tuple[dict[str, Any], ...]:
        """Return the current process's local listening sockets."""
        return self._listeners()[0]

    def zero_listener_ok(self) -> bool:
        """Return whether listener inspection succeeded and no listener exists."""
        listeners, error = self._listeners()
        return error is None and not listeners

    def snapshot(self) -> dict[str, Any]:
        """Return non-sensitive process and listener status."""
        descendants = self.descendants()
        listeners, listener_error = self._listeners()
        return {
            "pid": os.getpid(),
            "platform": platform.system(),
            "descendants": [asdict(item) for item in descendants],
            "unexpected_descendants": [asdict(item) for item in descendants if not item.allowed],
            "listeners": list(listeners),
            "listener_inspection_ok": listener_error is None,
            "listener_inspection_error": listener_error,
            "zero_listener": listener_error is None and not listeners,
        }


class StartupDiagnostics:
    """Bounded preflight and readiness checks for local embedded mode."""

    def __init__(self, workspace: str | Path, *, profile: str, allow_listeners: bool) -> None:
        self.workspace = Path(workspace).resolve()
        self.profile = str(profile)
        self.allow_listeners = bool(allow_listeners)
        self.monitor = ProcessMonitor()

    def run(self) -> dict[str, Any]:
        """Run deterministic startup checks without making network requests."""
        checks: dict[str, dict[str, Any]] = {}
        checks["workspace"] = {"ok": self.workspace.is_dir(), "path": str(self.workspace)}
        checks["profile"] = {
            "ok": self.profile in {"local_embedded", "local_hybrid", "remote_api", "distributed"},
            "value": self.profile,
        }
        checks["network_policy"] = {"ok": self.allow_listeners or self.monitor.zero_listener_ok(), "zero_listener": self.monitor.zero_listener_ok()}
        checks["python"] = {"ok": True, "version": platform.python_version()}
        checks["filesystem"] = {"ok": os.access(self.workspace, os.R_OK | os.W_OK), "writable": os.access(self.workspace, os.W_OK)}
        checks["process_tree"] = {"ok": not self.monitor.snapshot()["unexpected_descendants"], "unexpected": self.monitor.snapshot()["unexpected_descendants"]}
        return {
            "ok": all(bool(item.get("ok")) for item in checks.values()),
            "profile": self.profile,
            "checks": checks,
            "timestamp": time.time(),
        }


class RecoveryRecordStore:
    """Atomic integrity-addressed recovery records for resumable work."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def save(self, name: str, state: Mapping[str, Any]) -> Path:
        """Write one atomically replaced recovery record."""
        safe = "".join(ch for ch in str(name) if ch.isalnum() or ch in {"-", "_", "."}).strip(".")
        if not safe:
            raise ValueError("invalid recovery name")
        payload = json.dumps(dict(state), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        envelope = {"state": dict(state), "sha256": hashlib.sha256(payload.encode("utf-8")).hexdigest(), "saved_at": time.time()}
        target = self.root / f"{safe}.json"
        temp = target.with_suffix(".tmp")
        with self._lock:
            temp.write_text(json.dumps(envelope, ensure_ascii=False, sort_keys=True), encoding="utf-8")
            os.replace(temp, target)
        return target

    def load(self, name: str) -> dict[str, Any] | None:
        """Load and verify one recovery record."""
        safe = "".join(ch for ch in str(name) if ch.isalnum() or ch in {"-", "_", "."}).strip(".")
        if not safe:
            return None
        target = self.root / f"{safe}.json"
        if not target.is_file():
            return None
        raw = json.loads(target.read_text(encoding="utf-8"))
        state = raw.get("state")
        encoded = json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        if not hmac.compare_digest(digest, str(raw.get("sha256", ""))):
            raise ValueError("recovery record integrity failure")
        return dict(state) if isinstance(state, dict) else None


class SupremeControlPlane:
    """Single authoritative facade for V12.8.0 runtime hardening capabilities."""

    def __init__(self, config: Mapping[str, Any], *, workspace: str | Path, state_root: str | Path) -> None:
        runtime = dict(config.get("runtime", {}) or {})
        reliability = dict(config.get("reliability", {}) or {})
        autonomy = dict(config.get("autonomy", {}) or {})
        budget = dict(autonomy.get("budget", {}) or {})
        self.profile = str(runtime.get("profile", "local_embedded"))
        self.allow_listeners = bool(runtime.get("allow_listeners", False))
        self.resources = ResourceGovernor(
            ResourceBudget(
                max_concurrent_tasks=int(reliability.get("max_concurrent_jobs", budget.get("max_parallel_tasks", 8))),
                max_background_tasks=int(runtime.get("max_background_tasks", 16)),
                max_memory_mb=int(budget.get("max_memory_mb", 8192)),
                max_network_requests=int(budget.get("max_network_requests", 0)),
                max_external_actions=int(budget.get("max_external_actions", 20)),
                max_files_written=int(budget.get("max_files_written", 500)),
            )
        )
        configured = os.environ.get("JARVIS_CONTROL_PLANE_SECRET") or os.environ.get("JARVIS_MASTER_SECRET") or os.environ.get("JARVIS_SECURITY_SECRET")
        secret_material = derive_secret("control-plane-capabilities", configured, os.environ.get("JARVIS_MASTER_SECRET"))
        self.capabilities = CapabilityBroker(secret_material)
        root = Path(state_root).resolve()
        root.mkdir(parents=True, exist_ok=True)
        self.provenance = ProvenanceLedger(root / "provenance.db")
        self.recovery = RecoveryRecordStore(root / "recovery")
        allowed_processes = tuple(str(item).lower() for item in runtime.get("allowed_processes", ["python", "python3", "jarvis", "flutter", "dart", "chromium", "chrome", "msedge"]))
        self.diagnostics = StartupDiagnostics(workspace, profile=self.profile, allow_listeners=self.allow_listeners)
        self.diagnostics.monitor = ProcessMonitor(allowed_names=allowed_processes)
        self._startup = self.diagnostics.run()
        self._lock = threading.RLock()
        self._started_at = time.time()

    def refresh_diagnostics(self) -> dict[str, Any]:
        """Re-run startup diagnostics and retain the latest bounded result."""
        with self._lock:
            self._startup = self.diagnostics.run()
            return dict(self._startup)

    def snapshot(self) -> dict[str, Any]:
        """Return a complete but non-secret operational snapshot."""
        with self._lock:
            startup = dict(self._startup)
        process = self.diagnostics.monitor.snapshot()
        return {
            "profile": self.profile,
            "allow_listeners": self.allow_listeners,
            "uptime_seconds": max(0.0, time.time() - self._started_at),
            "startup_ok": bool(startup.get("ok")),
            "startup": startup,
            "resources": self.resources.snapshot(),
            "capability_grants": self.capabilities.snapshot(),
            "provenance": self.provenance.stats(),
            "process": process,
            "recovery_root": str(self.recovery.root),
        }

    def close(self) -> None:
        """Close persistent control-plane resources."""
        self.provenance.close()



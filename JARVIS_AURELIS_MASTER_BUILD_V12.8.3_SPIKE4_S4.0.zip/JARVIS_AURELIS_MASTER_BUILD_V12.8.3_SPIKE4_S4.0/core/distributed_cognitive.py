"""Shared-evidence cognitive fabric with isolated authority and credentials."""
from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class CognitiveShare:
    share_id: str
    producer: str
    workspace: str
    kind: str
    payload: Mapping[str, Any]
    created_at: float
    provenance: Mapping[str, Any]
    digest: str


class DistributedCognitiveFabric:
    """Share facts/evidence/results; never share authority, credentials, or raw memory by default."""

    def __init__(self, *, max_shares: int = 100_000) -> None:
        self._max_shares = max(1, min(int(max_shares), 1_000_000))
        self._shares: list[CognitiveShare] = []
        self._lock = threading.RLock()

    def publish(self, *, producer: str, workspace: str, kind: str, payload: Mapping[str, Any], provenance: Mapping[str, Any] | None = None) -> CognitiveShare:
        if not str(producer).strip() or not str(workspace).strip() or not str(kind).strip():
            raise ValueError("cognitive share identity is required")
        safe_payload = dict(payload)
        if any(key.lower() in {"password", "token", "secret", "api_key", "private_key"} for key in safe_payload):
            raise PermissionError("credentials and secrets cannot enter the shared cognition fabric")
        canonical = json.dumps({"producer": producer, "workspace": workspace, "kind": kind, "payload": safe_payload, "provenance": dict(provenance or {})}, sort_keys=True, separators=(",", ":"), default=str).encode()
        share = CognitiveShare(hashlib.sha256(canonical + str(time.time_ns()).encode()).hexdigest()[:32], str(producer), str(workspace), str(kind), safe_payload, time.time(), dict(provenance or {}), hashlib.sha256(canonical).hexdigest())
        with self._lock:
            self._shares.append(share)
            if len(self._shares) > self._max_shares:
                del self._shares[: len(self._shares) - self._max_shares]
        return share

    def query(self, *, workspace: str, kind: str | None = None, limit: int = 1000) -> tuple[CognitiveShare, ...]:
        with self._lock:
            rows = [share for share in self._shares if share.workspace == str(workspace) and (kind is None or share.kind == str(kind))]
        return tuple(rows[-max(1, min(int(limit), 10_000)) :])

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            return {"shares": len(self._shares), "workspaces": len({share.workspace for share in self._shares})}

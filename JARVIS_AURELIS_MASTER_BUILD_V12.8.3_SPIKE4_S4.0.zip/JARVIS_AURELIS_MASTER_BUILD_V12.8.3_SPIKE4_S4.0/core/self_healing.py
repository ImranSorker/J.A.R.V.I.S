"""Bounded retry support for replaceable, policy-controlled operations."""
from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import Any

logger = logging.getLogger("jarvis.healing")


class SelfHealingRetry:
    """Retry an operation a bounded number of times with exponential backoff.

    ``max_retries`` means the total number of attempts, preserving the historical
    public API while eliminating the zero-attempt ``raise None`` failure mode.
    """

    def __init__(self, max_retries: int = 3, backoff: float = 1.0) -> None:
        if max_retries < 1:
            raise ValueError("max_retries must be at least 1")
        if backoff < 0:
            raise ValueError("backoff must be non-negative")
        self.max_retries = int(max_retries)
        self.backoff = float(backoff)

    def call(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Execute ``fn`` until it succeeds or the attempt budget is exhausted."""
        if not callable(fn):
            raise TypeError("fn must be callable")
        last_exc: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "retry_attempt_failed",
                    extra={"attempt": attempt, "max_attempts": self.max_retries, "error": str(exc)},
                )
                if attempt < self.max_retries:
                    time.sleep(self.backoff * (2 ** (attempt - 1)))
        assert last_exc is not None  # The loop has at least one iteration by construction.
        raise last_exc



"""Signed release admission and safe atomic activation primitives."""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class UpdateAdmissionError(ValueError):
    """Raised when an update fails integrity, signature or anti-rollback policy."""


@dataclass(frozen=True, slots=True)
class SignedReleaseManifest:
    """Signed release descriptor consumed before any installation step."""

    version: str
    artifact_sha256: str
    file_manifest_sha256: str
    signer_key_id: str
    signature_b64: str

    def canonical_bytes(self) -> bytes:
        """Return the exact bytes covered by the Ed25519 signature."""
        return json.dumps(
            {
                "artifact_sha256": self.artifact_sha256,
                "file_manifest_sha256": self.file_manifest_sha256,
                "signer_key_id": self.signer_key_id,
                "version": self.version,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def to_dict(self) -> dict[str, str]:
        """Serialize the signed descriptor."""
        return {
            "version": self.version,
            "artifact_sha256": self.artifact_sha256,
            "file_manifest_sha256": self.file_manifest_sha256,
            "signer_key_id": self.signer_key_id,
            "signature_b64": self.signature_b64,
        }


class ReleaseSigner:
    """Ed25519 release signing helper; private keys never enter the update verifier."""

    @staticmethod
    def generate() -> tuple[bytes, bytes]:
        """Generate a private/public key pair for deployment-time key management."""
        private = Ed25519PrivateKey.generate()
        return private.private_bytes_raw(), private.public_key().public_bytes_raw()

    @staticmethod
    def sign(manifest: SignedReleaseManifest, private_key: bytes) -> SignedReleaseManifest:
        """Sign an unsigned manifest using an Ed25519 private key."""
        key = Ed25519PrivateKey.from_private_bytes(bytes(private_key))
        signature = key.sign(manifest.canonical_bytes())
        return SignedReleaseManifest(manifest.version, manifest.artifact_sha256, manifest.file_manifest_sha256, manifest.signer_key_id, base64.b64encode(signature).decode("ascii"))


class SecureUpdateVerifier:
    """Verify release signatures, artifact hashes and monotonic version policy."""

    def __init__(self, public_keys: dict[str, bytes], state_path: str | Path) -> None:
        self.public_keys = {str(key): bytes(value) for key, value in public_keys.items()}
        self.state_path = Path(state_path).resolve()
        self.state_path.parent.mkdir(parents=True, exist_ok=True)

    def _current_version(self) -> tuple[int, ...]:
        if not self.state_path.exists():
            return (0,)
        try:
            raw = json.loads(self.state_path.read_text(encoding="utf-8"))
            return self._parse_version(str(raw.get("version", "0")))
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise UpdateAdmissionError("update state is unreadable or corrupt") from exc

    @staticmethod
    def _parse_version(version: str) -> tuple[int, ...]:
        parts = tuple(int(part) for part in str(version).strip().lstrip("v").split(".") if part != "")
        if not parts or any(part < 0 for part in parts):
            raise UpdateAdmissionError("invalid release version")
        return parts

    @classmethod
    def compare_versions(cls, candidate: str, current: str) -> int:
        """Return -1/0/1 using numeric dotted release semantics."""
        left = cls._parse_version(candidate)
        right = cls._parse_version(current)
        width = max(len(left), len(right))
        a = left + (0,) * (width - len(left))
        b = right + (0,) * (width - len(right))
        return (a > b) - (a < b)

    def verify(self, manifest: SignedReleaseManifest, artifact: bytes, *, allow_equal: bool = False) -> None:
        """Fail closed unless every release trust check succeeds."""
        key = self.public_keys.get(manifest.signer_key_id)
        if key is None:
            raise UpdateAdmissionError("unknown release signer")
        try:
            Ed25519PublicKey.from_public_bytes(key).verify(base64.b64decode(manifest.signature_b64, validate=True), manifest.canonical_bytes())
        except Exception as exc:
            raise UpdateAdmissionError("release signature invalid") from exc
        actual = hashlib.sha256(artifact).hexdigest()
        if actual != manifest.artifact_sha256:
            raise UpdateAdmissionError("release artifact digest mismatch")
        # The signed manifest carries a digest of the release file-manifest; verify the
        # embedded manifest itself so a valid signature cannot be detached from its ZIP contents.
        try:
            with zipfile.ZipFile(io.BytesIO(artifact)) as archive:
                candidates = [name for name in archive.namelist() if name.endswith("RELEASE_MANIFEST.sha256") and not name.endswith("/")]
                if len(candidates) != 1:
                    raise UpdateAdmissionError("release manifest missing or ambiguous")
                embedded_manifest = archive.read(candidates[0])
        except UpdateAdmissionError:
            raise
        except (OSError, ValueError, zipfile.BadZipFile, KeyError) as exc:
            raise UpdateAdmissionError("release archive invalid") from exc
        embedded_digest = hashlib.sha256(embedded_manifest).hexdigest()
        if embedded_digest != manifest.file_manifest_sha256:
            raise UpdateAdmissionError("release file-manifest digest mismatch")
        current = self._current_version()
        candidate = self._parse_version(manifest.version)
        if candidate < current or (candidate == current and not allow_equal):
            raise UpdateAdmissionError("release rollback or duplicate rejected")

    def accept(self, manifest: SignedReleaseManifest) -> None:
        """Persist the highest accepted version atomically."""
        if self._parse_version(manifest.version) < self._current_version():
            raise UpdateAdmissionError("cannot persist a rollback version")
        fd, temp = tempfile.mkstemp(prefix=".update-state-", dir=str(self.state_path.parent))
        os.close(fd)
        try:
            Path(temp).write_text(json.dumps({"version": manifest.version, "signer_key_id": manifest.signer_key_id, "artifact_sha256": manifest.artifact_sha256, "file_manifest_sha256": manifest.file_manifest_sha256}, sort_keys=True), encoding="utf-8")
            os.replace(temp, self.state_path)
        finally:
            Path(temp).unlink(missing_ok=True)


class SafeReleaseStager:
    """Extract a verified release to a clean staging directory without traversal or symlinks."""

    def __init__(self, staging_root: str | Path, *, max_files: int = 20_000, max_bytes: int = 2 * 1024**3) -> None:
        self.staging_root = Path(staging_root).resolve()
        self.staging_root.mkdir(parents=True, exist_ok=True)
        self.max_files = int(max_files)
        self.max_bytes = int(max_bytes)

    def stage_zip(self, artifact: bytes, *, name: str = "candidate") -> Path:
        """Validate and extract one ZIP artifact into a fresh staging directory."""
        target = Path(tempfile.mkdtemp(prefix=f"{name}-", dir=str(self.staging_root))).resolve()
        used = 0
        try:
            with zipfile.ZipFile(__import__("io").BytesIO(artifact)) as archive:
                infos = archive.infolist()
                if len(infos) > self.max_files:
                    raise UpdateAdmissionError("release contains too many files")
                for info in infos:
                    posix = PurePosixPath(info.filename)
                    if posix.is_absolute() or ".." in posix.parts:
                        raise UpdateAdmissionError(f"unsafe release path: {info.filename}")
                    mode = (info.external_attr >> 16) & 0o170000
                    if mode == 0o120000:
                        raise UpdateAdmissionError("symbolic links are forbidden in release archives")
                    used += int(info.file_size)
                    if used > self.max_bytes:
                        raise UpdateAdmissionError("release exceeds unpacked size budget")
                    destination = (target / Path(*posix.parts)).resolve()
                    if not destination.is_relative_to(target):
                        raise UpdateAdmissionError("release path escapes staging root")
                    if info.is_dir():
                        destination.mkdir(parents=True, exist_ok=True)
                        continue
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(info, "r") as src, destination.open("wb") as dst:
                        shutil.copyfileobj(src, dst, length=1024 * 1024)
            return target
        except Exception:
            shutil.rmtree(target, ignore_errors=True)
            raise



"""P2-U Event Fabric 2.0: authenticated, durable, replayable event nervous system.

The fabric treats events as observations, never as authority.  It reuses the P2-A
canonicalization and AgentGenome identity/registry primitives for cryptographic
identity, while keeping authorization decisions outside the event transport.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import queue
import sqlite3
import threading
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_genome import AgentGenomeRegistry
from core.audit import AuditLog
from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator, SchemaValidationError

_SCHEMA_PATH = Path(__file__).resolve().parent / "schemas" / "event_envelope_v1.schema.json"
_TAXONOMY_PATH = Path(__file__).resolve().parent / "schemas" / "event_taxonomy.json"
_TRUST_RANK = {"untrusted": 0, "restricted": 1, "standard": 2, "elevated": 3, "system": 4}
_PRIORITY_RANK = {"bulk": 0, "low": 1, "normal": 2, "high": 3, "critical": 4}


class EventFabricError(RuntimeError):
    """Base event-fabric error."""


class EventValidationError(EventFabricError, ValueError):
    """The event does not satisfy schema or taxonomy rules."""


class EventAuthorizationError(EventFabricError, PermissionError):
    """The producer/subscriber lacks the event scope required by the registry."""


class EventIntegrityError(EventFabricError, ValueError):
    """Integrity or signature verification failed."""


class ReplayError(EventFabricError):
    """Replay/checkpoint token is invalid or cannot be restored."""


class SlowConsumerError(EventFabricError):
    """Critical delivery could not be admitted to a consumer queue."""


@dataclass(frozen=True, slots=True)
class EventReceipt:
    event_id: str
    sequence: int
    accepted: bool = True
    duplicate: bool = False


@dataclass(frozen=True, slots=True)
class SubscriptionHandle:
    subscription_id: str
    tenant_id: str
    delivery_mode: str


@dataclass(frozen=True, slots=True)
class SubscriberContext:
    principal: str
    scopes: tuple[str, ...]
    tenant_id: str
    trust_level: str = "standard"
    allow_restricted: bool = False
    secret_boundary: bool = False
    subscriber_id: str = ""


@dataclass(frozen=True, slots=True)
class EventFilter:
    tenant_id: str
    event_type: str | None = None
    event_name: str | None = None
    topic_prefix: str | None = None
    partition_key: str | None = None
    correlation_id: str | None = None
    sensitivity: str | None = None
    subscriber: SubscriberContext | None = None

    def matches(self, event: "EventEnvelope") -> bool:
        return (
            event.tenant_id == self.tenant_id
            and (self.event_type is None or event.event_type == self.event_type)
            and (self.event_name is None or event.event_name == self.event_name)
            and (self.topic_prefix is None or event.topic.startswith(self.topic_prefix))
            and (self.partition_key is None or event.partition_key == self.partition_key)
            and (self.correlation_id is None or event.correlation_id == self.correlation_id)
            and (self.sensitivity is None or event.sensitivity == self.sensitivity)
        )


@dataclass(frozen=True, slots=True)
class ProducedBy:
    kind: str
    id: str
    genome_hash: str | None
    trust_level: str

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "id": self.id, "genome_hash": self.genome_hash, "trust_level": self.trust_level}


@dataclass(frozen=True, slots=True)
class AuthContext:
    principal: str
    scopes: tuple[str, ...]
    policy_ref: str | None = None
    delegated_by: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"principal": self.principal, "scopes": list(self.scopes), "policy_ref": self.policy_ref, "delegated_by": self.delegated_by}


@dataclass(frozen=True, slots=True)
class EventLineage:
    evolution_candidate: str | None = None
    certified_snapshot: str | None = None
    parent_certification: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"evolution_candidate": self.evolution_candidate, "certified_snapshot": self.certified_snapshot, "parent_certification": self.parent_certification}


@dataclass(frozen=True, slots=True)
class EventEnvelope:
    event_id: str
    schema_version: str
    event_type: str
    event_name: str
    correlation_id: str
    causation_id: str | None
    parent_event_id: str | None
    produced_by: ProducedBy
    signature: str | None
    integrity_hash: str
    tenant_id: str
    auth_context: AuthContext
    emitted_at: str
    monotonic_ns: int
    received_at: str
    payload: Mapping[str, Any]
    payload_schema: str
    topic: str
    partition_key: str
    priority: str
    ttl_seconds: int | None
    replayable: bool
    sensitivity: str
    lineage: EventLineage

    def unsigned_material(self) -> dict[str, Any]:
        value = self.to_dict()
        value["integrity_hash"] = ""
        value["signature"] = None
        return value

    def integrity_material(self) -> bytes:
        return canonical_json(self.unsigned_material())

    def canonical(self) -> bytes:
        return canonical_json(self.to_dict())

    def computed_integrity_hash(self) -> str:
        return hashlib.sha256(self.integrity_material()).hexdigest()

    def verify_integrity(self) -> bool:
        return hmac.compare_digest(self.computed_integrity_hash(), self.integrity_hash)

    def signed_material(self) -> bytes:
        return canonical_json({"integrity_hash": self.integrity_hash, "envelope": self.unsigned_material()})

    def verify_signature(self, public_key: bytes | Ed25519PublicKey) -> bool:
        if not self.signature:
            return False
        raw = public_key if isinstance(public_key, bytes) else public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        try:
            Ed25519PublicKey.from_public_bytes(raw).verify(base64.b64decode(self.signature.encode("ascii")), self.signed_material())
            return True
        except (InvalidSignature, ValueError, TypeError, UnicodeError):
            return False

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": self.event_id, "schema_version": self.schema_version,
            "event_type": self.event_type, "event_name": self.event_name,
            "correlation_id": self.correlation_id, "causation_id": self.causation_id,
            "parent_event_id": self.parent_event_id, "produced_by": self.produced_by.to_dict(),
            "signature": self.signature, "integrity_hash": self.integrity_hash,
            "tenant_id": self.tenant_id, "auth_context": self.auth_context.to_dict(),
            "emitted_at": self.emitted_at, "monotonic_ns": self.monotonic_ns,
            "received_at": self.received_at, "payload": dict(self.payload),
            "payload_schema": self.payload_schema, "topic": self.topic,
            "partition_key": self.partition_key, "priority": self.priority,
            "ttl_seconds": self.ttl_seconds, "replayable": self.replayable,
            "sensitivity": self.sensitivity, "lineage": self.lineage.to_dict(),
        }

    @classmethod
    def create(
        cls,
        *, event_type: str, event_name: str, payload: Mapping[str, Any], produced_by: ProducedBy,
        auth_context: AuthContext, tenant_id: str, partition_key: str,
        correlation_id: str | None = None, causation_id: str | None = None,
        parent_event_id: str | None = None, priority: str | None = None,
        ttl_seconds: int | None = None, replayable: bool | None = None,
        sensitivity: str | None = None, lineage: EventLineage | None = None,
        signing_key: Ed25519PrivateKey | None = None, emitted_at: str | None = None,
        monotonic_ns: int | None = None,
    ) -> "EventEnvelope":
        spec = EventTaxonomy.get(event_type, event_name)
        emitted = emitted_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        received = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        unsigned = cls(
            event_id=str(uuid.uuid4()), schema_version="1.0.0", event_type=event_type, event_name=event_name,
            correlation_id=correlation_id or str(uuid.uuid4()), causation_id=causation_id,
            parent_event_id=parent_event_id, produced_by=produced_by, signature=None, integrity_hash="0"*64,
            tenant_id=tenant_id, auth_context=auth_context, emitted_at=emitted, monotonic_ns=int(monotonic_ns if monotonic_ns is not None else time.monotonic_ns()),
            received_at=received, payload=dict(payload), payload_schema=spec["payload_schema"], topic=spec["topic"],
            partition_key=partition_key, priority=priority or spec["default_priority"], ttl_seconds=ttl_seconds,
            replayable=spec["replayable"] if replayable is None else bool(replayable), sensitivity=sensitivity or spec["default_sensitivity"],
            lineage=lineage or EventLineage(),
        )
        digest = unsigned.computed_integrity_hash()
        signature = None
        if signing_key is not None:
            signature = base64.b64encode(signing_key.sign(canonical_json({"integrity_hash": digest, "envelope": unsigned.unsigned_material()}))).decode("ascii")
        elif _TRUST_RANK[produced_by.trust_level] >= _TRUST_RANK["standard"]:
            raise EventIntegrityError("trusted producers require an Ed25519 signing key")
        return cls(**{**unsigned.to_dict(), "produced_by": produced_by, "auth_context": auth_context, "lineage": unsigned.lineage, "payload": dict(payload), "signature": signature, "integrity_hash": digest})

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "EventEnvelope":
        produced = value["produced_by"]
        auth = value["auth_context"]
        lineage = value["lineage"]
        return cls(
            event_id=str(value["event_id"]), schema_version=str(value["schema_version"]), event_type=str(value["event_type"]), event_name=str(value["event_name"]),
            correlation_id=str(value["correlation_id"]), causation_id=value.get("causation_id"), parent_event_id=value.get("parent_event_id"),
            produced_by=ProducedBy(str(produced["kind"]), str(produced["id"]), produced.get("genome_hash"), str(produced["trust_level"])),
            signature=value.get("signature"), integrity_hash=str(value["integrity_hash"]), tenant_id=str(value["tenant_id"]),
            auth_context=AuthContext(str(auth["principal"]), tuple(str(x) for x in auth["scopes"]), auth.get("policy_ref"), auth.get("delegated_by")),
            emitted_at=str(value["emitted_at"]), monotonic_ns=int(value["monotonic_ns"]), received_at=str(value["received_at"]),
            payload=dict(value["payload"]), payload_schema=str(value["payload_schema"]), topic=str(value["topic"]), partition_key=str(value["partition_key"]),
            priority=str(value["priority"]), ttl_seconds=value.get("ttl_seconds"), replayable=bool(value["replayable"]), sensitivity=str(value["sensitivity"]),
            lineage=EventLineage(lineage.get("evolution_candidate"), lineage.get("certified_snapshot"), lineage.get("parent_certification")),
        )


class EventTaxonomy:
    """Frozen taxonomy registry loaded from the P2-U versioned JSON contract."""
    _loaded = False
    _events: dict[str, dict[str, Any]] = {}
    _groups: tuple[str, ...] = ()

    @classmethod
    def _ensure(cls) -> None:
        if cls._loaded:
            return
        data = json.loads(_TAXONOMY_PATH.read_text(encoding="utf-8"))
        cls._events = dict(data["events"])
        cls._groups = tuple(sorted({v["event_type"] for v in cls._events.values()}))
        cls._loaded = True

    @classmethod
    def get(cls, event_type: str, event_name: str) -> dict[str, Any]:
        cls._ensure()
        key = f"{event_type}.{event_name}"
        try:
            return cls._events[key]
        except KeyError as exc:
            raise EventValidationError(f"event type/name is not registered: {key}") from exc

    @classmethod
    def entries(cls) -> dict[str, dict[str, Any]]:
        cls._ensure()
        return {k: dict(v) for k, v in cls._events.items()}


class EventSchemaRegistry:
    """Persistent, fingerprinted schema registry with additive-only evolution."""
    def __init__(self, db_path: str | Path, storage_secret: bytes) -> None:
        if len(storage_secret) < 32:
            raise ValueError("event schema registry storage secret must be at least 32 bytes")
        self.path = Path(db_path).resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(storage_secret); self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("CREATE TABLE IF NOT EXISTS schemas(uri TEXT PRIMARY KEY, version TEXT NOT NULL, schema_json TEXT NOT NULL, fingerprint TEXT NOT NULL, integrity_tag TEXT NOT NULL, registered_at REAL NOT NULL)")
        self._db.commit()
        self.register_taxonomy_defaults()

    def _tag(self, uri: str, version: str, fingerprint: str, schema_json: str) -> str:
        return hmac.new(self._secret, f"{uri}|{version}|{fingerprint}|{schema_json}".encode(), hashlib.sha256).hexdigest()

    def register(self, uri: str, version: str, schema: Mapping[str, Any], *, allow_breaking: bool = False) -> str:
        validator = SchemaValidator(max_errors=8); validator._validator(dict(schema))
        payload = canonical_json(dict(schema)).decode("utf-8"); fingerprint = hashlib.sha256(payload.encode()).hexdigest()
        with self._lock, self._db:
            previous = self._db.execute("SELECT version,schema_json,fingerprint,integrity_tag FROM schemas WHERE uri=?", (str(uri),)).fetchone()
            if previous is not None:
                old_version, old_json, _, tag = previous
                expected = self._tag(str(uri), str(old_version), str(previous[2]), str(old_json))
                if not hmac.compare_digest(expected, str(tag)):
                    raise EventIntegrityError(f"schema registry integrity failed for {uri}")
                if str(version) == str(old_version) and str(old_json) != payload:
                    raise EventValidationError(f"schema mutation without version change: {uri}")
                if str(version) != str(old_version) and not allow_breaking:
                    # additive compatibility check is intentionally conservative: existing required fields may not disappear.
                    old = json.loads(str(old_json)); new = dict(schema)
                    old_req = set(old.get("required", [])); new_req = set(new.get("required", []))
                    if not new_req.issubset(old_req):
                        raise EventValidationError("breaking schema evolution requires allow_breaking=True")
            tag = self._tag(str(uri), str(version), fingerprint, payload)
            self._db.execute("INSERT OR REPLACE INTO schemas(uri,version,schema_json,fingerprint,integrity_tag,registered_at) VALUES(?,?,?,?,?,?)", (str(uri), str(version), payload, fingerprint, tag, time.time()))
        return fingerprint

    def register_taxonomy_defaults(self) -> None:
        object_schema = {"$schema":"https://json-schema.org/draft/2020-12/schema", "type":"object", "additionalProperties":True}
        for spec in EventTaxonomy.entries().values():
            self.register(spec["payload_schema"], "1.0.0", object_schema)

    def validate(self, event: EventEnvelope) -> None:
        with self._lock:
            row = self._db.execute("SELECT version,schema_json,fingerprint,integrity_tag FROM schemas WHERE uri=?", (event.payload_schema,)).fetchone()
            if row is None:
                raise EventValidationError(f"payload schema is not registered: {event.payload_schema}")
            expected = self._tag(event.payload_schema, str(row[0]), str(row[2]), str(row[1]))
            if not hmac.compare_digest(expected, str(row[3])):
                raise EventIntegrityError("schema registry integrity verification failed")
            SchemaValidator(max_errors=32).validate_or_raise(dict(event.payload), json.loads(str(row[1])))

    def close(self) -> None:
        with self._lock:
            self._db.close()


class PublicKeyResolver(Protocol):
    def __call__(self, producer_id: str, genome_hash: str | None, kind: str) -> bytes | None: ...


class GenomeKeyResolver:
    """Resolve agent event signing keys from the P2-A signed genome registry."""
    def __init__(self, registry: AgentGenomeRegistry) -> None:
        self.registry = registry

    def __call__(self, producer_id: str, genome_hash: str | None, kind: str) -> bytes | None:
        if kind != "agent": return None
        genome = self.registry.current(producer_id)
        if genome is None or genome.cryptographic_fingerprint != genome_hash:
            return None
        return base64.b64decode(genome.document["cryptographic_identity"]["public_key"].encode("ascii"))


@dataclass
class _Subscription:
    handle: SubscriptionHandle
    filter: EventFilter
    subscriber: SubscriberContext
    handler: Callable[[EventEnvelope], Any]
    queue: queue.Queue[tuple[int, EventEnvelope] | None]
    max_attempts: int = 3
    stop: threading.Event = field(default_factory=threading.Event)
    thread: threading.Thread | None = None
    delivered_seq: int = 0


class EventBus(ABC):
    """Transport-agnostic event bus interface used by later P2 phases."""
    @abstractmethod
    def publish(self, event: EventEnvelope) -> EventReceipt: ...
    @abstractmethod
    def subscribe(self, filter: EventFilter, handler: Callable[[EventEnvelope], Any], delivery_mode: str = "at_least_once", subscriber: SubscriberContext | None = None) -> SubscriptionHandle: ...
    @abstractmethod
    def unsubscribe(self, handle: SubscriptionHandle) -> None: ...
    @abstractmethod
    async def replay(self, filter: EventFilter, from_checkpoint: str | int | None = None) -> AsyncIterator[EventEnvelope]: ...
    @abstractmethod
    def checkpoint(self, subscription: SubscriptionHandle) -> str: ...
    @abstractmethod
    def restore(self, checkpoint_token: str) -> int: ...


class DurableEventBus(EventBus):
    """SQLite-backed append-only event log with ordered bounded subscriptions."""
    DELIVERY_MODES = {"at_most_once", "at_least_once", "exactly_once_ordered"}

    def __init__(self, db_path: str | Path, *, storage_secret: bytes, schema_registry: EventSchemaRegistry | None = None,
                 audit_log: Any | None = None, public_key_resolver: PublicKeyResolver | None = None,
                 queue_size: int = 256, enqueue_timeout: float = 1.0) -> None:
        if len(storage_secret) < 32: raise ValueError("event bus storage secret must be at least 32 bytes")
        if queue_size < 1: raise ValueError("queue_size must be positive")
        self.path=Path(db_path).resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret=bytes(storage_secret); self.schema_registry=schema_registry or EventSchemaRegistry(self.path.with_suffix('.schemas.db'), self._secret)
        self.audit=audit_log; self.public_key_resolver=public_key_resolver; self.queue_size=int(queue_size); self.enqueue_timeout=float(enqueue_timeout)
        self._internal_key=Ed25519PrivateKey.generate()
        self._internal_public=self._internal_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self._metric_lock=threading.RLock()
        self._metric_suppressed=threading.local()
        self._metrics={"publishes":0,"subscribes":0,"authorization_denials":0,"validation_failures":0,"dlq_inserts":0}
        self._lock=threading.RLock(); self._publish_order_lock=threading.RLock(); self._subs: dict[str,_Subscription]={}; self._closed=False
        self._db=sqlite3.connect(str(self.path), check_same_thread=False); self._db.execute("PRAGMA journal_mode=WAL"); self._db.execute("PRAGMA synchronous=FULL"); self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript("""
        CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT UNIQUE NOT NULL,tenant_id TEXT NOT NULL,topic TEXT NOT NULL,partition_key TEXT NOT NULL,event_json TEXT NOT NULL,record_hash TEXT NOT NULL,previous_hash TEXT NOT NULL,integrity_tag TEXT NOT NULL,created_at REAL NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_events_tenant_seq ON events(tenant_id,seq);
        CREATE INDEX IF NOT EXISTS idx_events_topic_seq ON events(topic,seq);
        CREATE INDEX IF NOT EXISTS idx_events_partition_seq ON events(tenant_id,partition_key,seq);
        CREATE TABLE IF NOT EXISTS ingest_dedupe(tenant_id TEXT NOT NULL,event_id TEXT NOT NULL,sequence INTEGER NOT NULL,PRIMARY KEY(tenant_id,event_id));
        CREATE TABLE IF NOT EXISTS secondary_dedupe(tenant_id TEXT NOT NULL,correlation_id TEXT NOT NULL,event_name TEXT NOT NULL,monotonic_ns INTEGER NOT NULL,sequence INTEGER NOT NULL,PRIMARY KEY(tenant_id,correlation_id,event_name,monotonic_ns));
        CREATE TABLE IF NOT EXISTS subscription_checkpoints(subscription_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,sequence INTEGER NOT NULL,updated_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS delivery_ledger(subscription_id TEXT NOT NULL,sequence INTEGER NOT NULL,delivered_at REAL NOT NULL,PRIMARY KEY(subscription_id,sequence));
        CREATE TABLE IF NOT EXISTS dead_letters(id INTEGER PRIMARY KEY AUTOINCREMENT,tenant_id TEXT NOT NULL,event_id TEXT NOT NULL,sequence INTEGER NOT NULL,subscription_id TEXT NOT NULL,reason TEXT NOT NULL,error TEXT NOT NULL,event_json TEXT NOT NULL,created_at REAL NOT NULL);
        """)
        columns={row[1] for row in self._db.execute("PRAGMA table_info(events)").fetchall()}
        if "integrity_tag" not in columns:
            self._db.execute("ALTER TABLE events ADD COLUMN integrity_tag TEXT NOT NULL DEFAULT ''")
        self._db.commit()
        if not self.verify_log(): raise EventIntegrityError("event log integrity verification failed at startup")

    def _audit(self, event: str, details: Mapping[str, Any]) -> None:
        if self.audit is not None: self.audit.log(event, dict(details))

    def _authorize_publish(self, event: EventEnvelope) -> None:
        spec=EventTaxonomy.get(event.event_type,event.event_name)
        if spec["publish_scope"] not in set(event.auth_context.scopes): raise EventAuthorizationError(f"missing publish scope {spec['publish_scope']}")

    def _authorize_subscribe(self, filter: EventFilter, subscriber: SubscriberContext) -> None:
        if subscriber.tenant_id != filter.tenant_id: raise EventAuthorizationError("subscriber tenant does not match filter tenant")
        if filter.event_type and filter.event_name:
            required=EventTaxonomy.get(filter.event_type,filter.event_name)["subscribe_scope"]
        elif filter.event_type:
            required={v["subscribe_scope"] for v in EventTaxonomy.entries().values() if v["event_type"]==filter.event_type}
            if not required.issubset(set(subscriber.scopes)): raise EventAuthorizationError("subscription lacks scopes for all events in event_type")
            required=None
        else:
            required={v["subscribe_scope"] for v in EventTaxonomy.entries().values()}
            if not required.issubset(set(subscriber.scopes)): raise EventAuthorizationError("broad subscription requires all taxonomy subscribe scopes")
            required=None
        if required and required not in set(subscriber.scopes): raise EventAuthorizationError(f"missing subscribe scope {required}")

    def _authorize_sensitivity(self,event: EventEnvelope, subscriber: SubscriberContext) -> None:
        if event.sensitivity == "secret" and not (subscriber.secret_boundary and _TRUST_RANK[subscriber.trust_level] >= _TRUST_RANK["system"]):
            raise EventAuthorizationError("secret event cannot leave trusted boundary")
        if event.sensitivity == "restricted" and not (subscriber.allow_restricted and _TRUST_RANK[subscriber.trust_level] >= _TRUST_RANK["elevated"]):
            raise EventAuthorizationError("restricted event requires explicit subscription policy")

    def _verify_ingress(self,event: EventEnvelope) -> None:
        schema=json.loads(_SCHEMA_PATH.read_text(encoding='utf-8')); SchemaValidator(max_errors=64).validate_or_raise(event.to_dict(),schema)
        spec=EventTaxonomy.get(event.event_type,event.event_name)
        if event.produced_by.kind == "agent" and (not event.produced_by.genome_hash or len(event.produced_by.genome_hash) != 64):
            raise EventIntegrityError("agent events require the P2-A genome fingerprint")
        if event.payload_schema != spec["payload_schema"] or event.topic != spec["topic"]: raise EventValidationError("event metadata does not match frozen taxonomy")
        if event.priority != spec["default_priority"] and _PRIORITY_RANK[event.priority] < _PRIORITY_RANK[spec["default_priority"]]: raise EventValidationError("event priority cannot be attenuated below taxonomy default")
        if event.replayable and not spec["replayable"] and event.event_name != "SlowConsumerDetected": raise EventValidationError("non-replayable taxonomy event cannot be replayed")
        if not event.verify_integrity(): raise EventIntegrityError("integrity_hash mismatch")
        self.schema_registry.validate(event)
        if _TRUST_RANK[event.produced_by.trust_level] >= _TRUST_RANK["standard"]:
            if not event.signature: raise EventIntegrityError("trusted event is unsigned")
            if self.public_key_resolver is None: raise EventIntegrityError("no public-key resolver configured for trusted event")
            key=self._resolve_public_key(event)
            if key is None or not event.verify_signature(key): raise EventIntegrityError("event signature verification failed")

    def _resolve_public_key(self,event: EventEnvelope) -> bytes | None:
        if event.produced_by.kind == "system" and event.produced_by.id == "event-fabric" and event.produced_by.genome_hash == hashlib.sha256(self._internal_public).hexdigest():
            return self._internal_public
        if self.public_key_resolver is None:
            return None
        return self.public_key_resolver(event.produced_by.id,event.produced_by.genome_hash,event.produced_by.kind)

    def _record_tag(self, event_json: str, record_hash: str, previous: str, tenant_id: str) -> str:
        return hmac.new(
            self._secret,
            canonical_bytes({"tenant_id": tenant_id, "event_json": event_json, "record_hash": record_hash, "previous_hash": previous}),
            hashlib.sha256,
        ).hexdigest()

    def _resolve_public_key(self, event: EventEnvelope) -> bytes | None:
        internal_id = hashlib.sha256(self._internal_public).hexdigest()
        if event.produced_by.kind == "system" and event.produced_by.id == "event-fabric" and event.produced_by.genome_hash == internal_id:
            return self._internal_public
        if self.public_key_resolver is None:
            return None
        return self.public_key_resolver(event.produced_by.id, event.produced_by.genome_hash, event.produced_by.kind)

    def _emit_telemetry(self, event_name: str, payload: Mapping[str, Any], tenant_id: str) -> None:
        if getattr(self._metric_suppressed, "active", False):
            return
        try:
            self._metric_suppressed.active = True
            internal_id = hashlib.sha256(self._internal_public).hexdigest()
            event = EventEnvelope.create(
                event_type="Telemetry",
                event_name=event_name,
                payload=dict(payload),
                produced_by=ProducedBy("system", "event-fabric", internal_id, "system"),
                auth_context=AuthContext("event-fabric", ("events.publish.telemetry",), None, None),
                tenant_id=tenant_id,
                partition_key="event-fabric",
                priority="normal",
                sensitivity="internal",
                signing_key=self._internal_key,
            )
            self._publish_internal(event)
        except Exception:
            # Observability must never block or corrupt the primary event path.
            return
        finally:
            self._metric_suppressed.active = False

    def _publish_internal(self, event: EventEnvelope) -> EventReceipt:
        return self._store_and_fanout(event, emit_metrics=False)

    def _store_and_fanout(self, event: EventEnvelope, *, emit_metrics: bool = True) -> EventReceipt:
        self._authorize_publish(event)
        self._verify_ingress(event)
        # Sequence assignment and fan-out are one ordered critical section.
        # Without this barrier, concurrent publishers can commit seq=N/N+1 and
        # then enqueue N+1 before N, violating exactly_once_ordered semantics.
        with self._publish_order_lock, self._lock, self._db:
            existing = self._db.execute(
                "SELECT sequence FROM ingest_dedupe WHERE tenant_id=? AND event_id=?",
                (event.tenant_id, event.event_id),
            ).fetchone()
            if existing is not None:
                return EventReceipt(event.event_id, int(existing[0]), True, True)
            secondary = self._db.execute(
                "SELECT sequence FROM secondary_dedupe WHERE tenant_id=? AND correlation_id=? AND event_name=? AND monotonic_ns=?",
                (event.tenant_id, event.correlation_id, event.event_name, event.monotonic_ns),
            ).fetchone()
            if secondary is not None:
                return EventReceipt(event.event_id, int(secondary[0]), True, True)
            row = self._db.execute("SELECT record_hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            previous = str(row[0]) if row else "0" * 64
            event_json = canonical_json(event.to_dict()).decode("utf-8")
            record_hash = hashlib.sha256(canonical_bytes({"event": event.to_dict(), "previous_hash": previous})).hexdigest()
            integrity_tag = self._record_tag(event_json, record_hash, previous, event.tenant_id)
            cur = self._db.execute(
                "INSERT INTO events(event_id,tenant_id,topic,partition_key,event_json,record_hash,previous_hash,integrity_tag,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (event.event_id, event.tenant_id, event.topic, event.partition_key, event_json, record_hash, previous, integrity_tag, time.time()),
            )
            seq = int(cur.lastrowid)
            self._db.execute("INSERT INTO ingest_dedupe VALUES(?,?,?)", (event.tenant_id, event.event_id, seq))
            self._db.execute(
                "INSERT INTO secondary_dedupe VALUES(?,?,?,?,?)",
                (event.tenant_id, event.correlation_id, event.event_name, event.monotonic_ns, seq),
            )
        self._audit("event.publish", {"event_id": event.event_id, "tenant_id": event.tenant_id, "sequence": seq, "topic": event.topic})
        self._fanout(seq, event)
        if emit_metrics and not getattr(self._metric_suppressed, "active", False):
            self._emit_telemetry("Metric", {"metric": "event.publish.count", "value": 1, "topic": event.topic, "sequence": seq}, event.tenant_id)
        return EventReceipt(event.event_id, seq)

    def publish(self, event: EventEnvelope) -> EventReceipt:
        if self._closed:
            raise RuntimeError("event bus is closed")
        try:
            # Serialize storage and fan-out together so concurrent publishers
            # preserve the durable sequence order on every partition.
            with self._publish_order_lock:
                receipt = self._store_and_fanout(event)
        except EventAuthorizationError as exc:
            with self._metric_lock:
                self._metrics["authorization_denials"] += 1
            self._audit("event.publish.denied", {"event_id": event.event_id, "tenant_id": event.tenant_id, "reason": str(exc)})
            self._emit_telemetry("Metric", {"metric": "event.authorization.denial", "value": 1, "operation": "publish"}, event.tenant_id)
            raise
        except EventValidationError as exc:
            with self._metric_lock:
                self._metrics["validation_failures"] += 1
            self._audit("event.publish.denied", {"event_id": event.event_id, "tenant_id": event.tenant_id, "reason": str(exc)})
            self._emit_telemetry("Metric", {"metric": "event.validation.failure", "value": 1}, event.tenant_id)
            raise
        except EventIntegrityError as exc:
            self._audit("event.publish.denied", {"event_id": event.event_id, "tenant_id": event.tenant_id, "reason": str(exc)})
            raise
        with self._metric_lock:
            self._metrics["publishes"] += 1
        return receipt

    def _matches(self, sub: _Subscription, event: EventEnvelope) -> bool:
        try:
            self._authorize_sensitivity(event, sub.subscriber)
        except EventAuthorizationError:
            return False
        return sub.filter.matches(event)

    def _fanout(self, seq: int, event: EventEnvelope) -> None:
        with self._lock:
            subs = list(self._subs.values())
        for sub in subs:
            if not self._matches(sub, event):
                continue
            try:
                timeout = self.enqueue_timeout if _PRIORITY_RANK[event.priority] >= _PRIORITY_RANK["high"] else 0
                sub.queue.put((seq, event), timeout=timeout)
                self._emit_telemetry("Metric", {"metric": "event.queue.depth", "value": sub.queue.qsize(), "subscription_id": sub.handle.subscription_id}, event.tenant_id)
                self._emit_telemetry("Metric", {"metric": "event.consumer.lag", "value": max(0, seq - sub.delivered_seq), "subscription_id": sub.handle.subscription_id}, event.tenant_id)
            except queue.Full:
                self._slow_consumer(sub, event, seq)
                if _PRIORITY_RANK[event.priority] >= _PRIORITY_RANK["high"]:
                    self._append_dlq(sub, event, seq, "slow_consumer_queue_full", "queue_full")
                    if event.priority == "critical":
                        raise SlowConsumerError(f"critical event {event.event_id} blocked by slow consumer {sub.handle.subscription_id}")

    def _slow_consumer(self, sub: _Subscription, event: EventEnvelope, seq: int) -> None:
        details = {
            "subscription_id": sub.handle.subscription_id,
            "event_id": event.event_id,
            "sequence": seq,
            "tenant_id": event.tenant_id,
            "topic": event.topic,
            "queue_size": sub.queue.qsize(),
        }
        self._audit("event.slow_consumer", details)
        if event.event_name == "SlowConsumerDetected":
            return
        self._emit_telemetry("SlowConsumerDetected", details, event.tenant_id)

    def _append_dlq(self, sub: _Subscription, event: EventEnvelope, seq: int, reason: str, error: str) -> None:
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO dead_letters(tenant_id,event_id,sequence,subscription_id,reason,error,event_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (event.tenant_id, event.event_id, seq, sub.handle.subscription_id, reason, error, canonical_json(event.to_dict()).decode("utf-8"), time.time()),
            )
        with self._metric_lock:
            self._metrics["dlq_inserts"] += 1
        self._audit("event.dlq.inserted", {"subscription_id": sub.handle.subscription_id, "event_id": event.event_id, "sequence": seq, "reason": reason, "error": error})
        self._emit_telemetry("Metric", {"metric": "event.dlq.growth", "value": 1}, event.tenant_id)

    def subscribe(self, filter: EventFilter, handler: Callable[[EventEnvelope], Any], delivery_mode: str = "at_least_once", subscriber: SubscriberContext | None = None) -> SubscriptionHandle:
        if delivery_mode not in self.DELIVERY_MODES:
            raise ValueError(f"unsupported delivery_mode {delivery_mode}")
        if not filter.tenant_id:
            raise EventAuthorizationError("tenant_id is mandatory for subscriptions")
        subctx = subscriber or filter.subscriber or SubscriberContext("anonymous", (), filter.tenant_id)
        try:
            self._authorize_subscribe(filter, subctx)
            candidates = [
                v for v in EventTaxonomy.entries().values()
                if (filter.event_type is None or v["event_type"] == filter.event_type)
                and (filter.event_name is None or v["event_name"] == filter.event_name)
            ]
            if any(v["default_sensitivity"] == "secret" for v in candidates) and not (subctx.secret_boundary and _TRUST_RANK[subctx.trust_level] >= _TRUST_RANK["system"]):
                raise EventAuthorizationError("secret subscription requires trusted boundary")
            if any(v["default_sensitivity"] == "restricted" for v in candidates) and not (subctx.allow_restricted and _TRUST_RANK[subctx.trust_level] >= _TRUST_RANK["elevated"]):
                raise EventAuthorizationError("restricted subscription requires explicit subscription policy")
            required_exact = any(
                v["event_type"] in {"Evolution", "Security", "WorldState"}
                or (v["event_type"] == "Model" and v["event_name"] in {"Registered", "Pinned", "Deprecated", "Retired", "Revoked", "RevocationPropagated", "LoadRequested", "Loaded", "LoadFailed", "Unloaded", "Evicted", "ResidencyEstimateDeviation", "Routed", "RoutingFailed", "ResponseMismatch", "BatchFormed", "BatchExecuted", "SpeculativeDeviation", "KvSnapshot", "KvRestored"})
                or (v["event_type"] == "Agent.Lifecycle" and v["event_name"] == "Certified")
                or (v["event_type"] == "Memory" and v["event_name"] in {
                    "Written", "Superseded", "Linked", "Consolidated", "Forgotten",
                    "Restored", "Promoted", "Quarantined", "ContradictionDetected",
                    "ContradictionResolved", "Archived", "DependencyForgotten", "Scored", "Decayed"
                })
                for v in candidates
            )
            if required_exact and delivery_mode != "exactly_once_ordered":
                raise EventAuthorizationError("this event family requires exactly_once_ordered delivery")
        except Exception as exc:
            self._audit("event.subscribe.denied", {"tenant_id": filter.tenant_id, "principal": subctx.principal, "reason": str(exc)})
            with self._metric_lock:
                self._metrics["authorization_denials"] += 1
            self._emit_telemetry("Metric", {"metric": "event.authorization.denial", "value": 1, "operation": "subscribe"}, filter.tenant_id)
            raise
        sid = str(uuid.uuid4())
        handle = SubscriptionHandle(sid, filter.tenant_id, delivery_mode)
        sub = _Subscription(handle, filter, subctx, handler, queue.Queue(maxsize=self.queue_size))
        sub.thread = threading.Thread(target=self._subscription_loop, args=(sub,), daemon=True, name=f"jarvis-event-sub-{sid[:8]}")
        with self._lock:
            self._subs[sid] = sub
        sub.thread.start()
        self._audit("event.subscribe", {"subscription_id": sid, "tenant_id": filter.tenant_id, "principal": subctx.principal, "delivery_mode": delivery_mode})
        with self._metric_lock:
            self._metrics["subscribes"] += 1
        self._emit_telemetry("Metric", {"metric": "event.subscribe.count", "value": 1, "delivery_mode": delivery_mode}, filter.tenant_id)
        return handle

    def _subscription_loop(self,sub:_Subscription)->None:
        while not sub.stop.is_set():
            try: item=sub.queue.get(timeout=0.2)
            except queue.Empty: continue
            if item is None: sub.queue.task_done(); break
            seq,event=item
            if sub.handle.delivery_mode=="exactly_once_ordered":
                row=self._db.execute("SELECT 1 FROM delivery_ledger WHERE subscription_id=? AND sequence=?",(sub.handle.subscription_id,seq)).fetchone()
                if row is not None: sub.queue.task_done(); continue
            attempts=0
            while attempts < sub.max_attempts:
                attempts += 1
                try:
                    result=sub.handler(event)
                    if asyncio.iscoroutine(result):
                        asyncio.run(result)
                    with self._lock,self._db:
                        self._db.execute("INSERT OR IGNORE INTO delivery_ledger(subscription_id,sequence,delivered_at) VALUES(?,?,?)",(sub.handle.subscription_id,seq,time.time()))
                    sub.delivered_seq=seq; break
                except Exception as exc:
                    if sub.handle.delivery_mode == "at_most_once":
                        self._append_dlq(sub,event,seq,"handler_failure",repr(exc)); break
                    if attempts >= sub.max_attempts:
                        self._append_dlq(sub,event,seq,"handler_failure",repr(exc)); break
            sub.queue.task_done()

    def unsubscribe(self,handle:SubscriptionHandle)->None:
        with self._lock: sub=self._subs.pop(handle.subscription_id,None)
        if sub is None: return
        sub.stop.set();
        try: sub.queue.put_nowait(None)
        except queue.Full: sub.stop.set()
        if sub.thread and sub.thread.is_alive(): sub.thread.join(timeout=2.0)
        self._audit("event.unsubscribe",{"subscription_id":handle.subscription_id,"tenant_id":handle.tenant_id})

    async def replay(self, filter: EventFilter, from_checkpoint: str | int | None = None) -> AsyncIterator[EventEnvelope]:
        start = self.restore(from_checkpoint) if isinstance(from_checkpoint, str) else int(from_checkpoint or 0)
        sql = "SELECT seq,event_json,record_hash,previous_hash,integrity_tag,tenant_id FROM events WHERE tenant_id=? AND seq>? ORDER BY seq ASC"
        rows = self._db.execute(sql, (filter.tenant_id, start)).fetchall()
        subscriber = filter.subscriber
        for seq, event_json, record_hash, previous_hash, integrity_tag, tenant_id in rows:
            if not hmac.compare_digest(self._record_tag(str(event_json), str(record_hash), str(previous_hash), str(tenant_id)), str(integrity_tag)):
                raise ReplayError("event record integrity verification failed during replay")
            event = EventEnvelope.from_dict(json.loads(event_json))
            if not filter.matches(event):
                continue
            if not event.replayable:
                continue
            if subscriber is not None:
                self._authorize_sensitivity(event, subscriber)
            elif event.sensitivity in {"restricted", "secret"}:
                raise EventAuthorizationError("replay of sensitive events requires subscriber context")
            yield event

    def checkpoint(self,subscription:SubscriptionHandle)->str:
        with self._lock:
            sub=self._subs.get(subscription.subscription_id)
            if sub is None: raise ReplayError("unknown subscription")
            seq=sub.delivered_seq
            payload={"subscription_id":subscription.subscription_id,"tenant_id":subscription.tenant_id,"sequence":seq}
            raw=canonical_json(payload); tag=hmac.new(self._secret,raw,hashlib.sha256).hexdigest(); token=base64.urlsafe_b64encode(raw).decode('ascii')+"."+tag
            self._db.execute("INSERT OR REPLACE INTO subscription_checkpoints VALUES(?,?,?,?)",(subscription.subscription_id,subscription.tenant_id,seq,time.time())); self._db.commit()
        return token

    def restore(self,checkpoint_token:str)->int:
        try:
            encoded,tag=checkpoint_token.split('.',1); raw=base64.urlsafe_b64decode(encoded.encode('ascii')); payload=json.loads(raw.decode('utf-8'))
        except Exception as exc: raise ReplayError("invalid checkpoint token") from exc
        expected=hmac.new(self._secret,raw,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,tag): raise ReplayError("checkpoint integrity verification failed")
        if not payload.get('subscription_id') or not payload.get('tenant_id'): raise ReplayError("checkpoint missing identity")
        row=self._db.execute("SELECT sequence FROM subscription_checkpoints WHERE subscription_id=? AND tenant_id=?",(str(payload['subscription_id']),str(payload['tenant_id']))).fetchone()
        if row is None: raise ReplayError("checkpoint is unknown")
        return int(row[0])

    def metrics_snapshot(self) -> dict[str, int]:
        with self._metric_lock:
            return dict(self._metrics)

    def verify_log(self) -> bool:
        previous = "0" * 64
        try:
            rows = self._db.execute("SELECT seq,event_json,record_hash,previous_hash,integrity_tag,event_id,tenant_id FROM events ORDER BY seq").fetchall()
        except sqlite3.DatabaseError:
            return False
        expected_seq = 1
        for seq, event_json, record_hash, previous_hash, integrity_tag, event_id, tenant_id in rows:
            if int(seq) != expected_seq or str(previous_hash) != previous:
                return False
            try:
                event = EventEnvelope.from_dict(json.loads(event_json))
            except Exception:
                return False
            if event.event_id != str(event_id) or event.tenant_id != str(tenant_id):
                return False
            expected = hashlib.sha256(canonical_bytes({"event": json.loads(event_json), "previous_hash": previous})).hexdigest()
            if not hmac.compare_digest(expected, str(record_hash)):
                return False
            if not hmac.compare_digest(self._record_tag(str(event_json), str(record_hash), str(previous), str(tenant_id)), str(integrity_tag)):
                return False
            previous = expected
            expected_seq += 1
        return True

    def close(self)->None:
        with self._lock:
            if self._closed: return
            self._closed=True; subs=list(self._subs.values())
        for sub in subs: self.unsubscribe(sub.handle)
        self._db.close(); self.schema_registry.close()


class Projector(Protocol):
    def apply(self,event:EventEnvelope)->None: ...


class ReplayProjector:
    """Rebuild derived state by applying only persisted events in sequence."""
    def __init__(self, projectors: Sequence[Projector]) -> None:
        self.projectors=tuple(projectors)
    async def rebuild(self,bus:DurableEventBus,filter:EventFilter,from_checkpoint:str|int|None=None)->int:
        count=0
        async for event in bus.replay(filter,from_checkpoint):
            for projector in self.projectors: projector.apply(event)
            count += 1
        return count


class EventFabric:
    """Backward-compatible facade plus the P2-U durable bus.

    Legacy string publishing is retained only for existing V12.8.3 callers. New
    P2 code should construct ``EventEnvelope`` and call ``publish_envelope`` or
    use ``bus.publish`` directly. Legacy events never bypass the canonical P2-U
    authorization boundary because they are isolated to the compatibility journal.
    """
    def __init__(self, legacy_bus: Any | None, journal_path: str | Path, *, max_events_per_second: int = 500,
                 storage_secret: bytes | None = None, audit_log: Any | None = None, public_key_resolver: PublicKeyResolver | None = None) -> None:
        self.legacy_bus=legacy_bus
        self.path=Path(journal_path).expanduser().resolve(); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.max_events_per_second=int(max_events_per_second)
        if self.max_events_per_second < 1: raise ValueError("max_events_per_second must be positive")
        secret=storage_secret or hashlib.sha256((str(self.path)+":p2u").encode()).digest()
        self._bus=DurableEventBus(self.path.with_suffix('.db'),storage_secret=secret,audit_log=audit_log,public_key_resolver=public_key_resolver)
        self._lock=threading.RLock(); self._window_start=time.monotonic(); self._window_count=0; self._published=0; self._rejected=0
        self._legacy_records: list[dict[str,Any]]=[]
        self._legacy_subscribed=False
        if self.legacy_bus is not None and hasattr(self.legacy_bus,'subscribe_event'):
            self.legacy_bus.subscribe_event('*',self._legacy_journal)
            self._legacy_subscribed=True
    @property
    def bus(self)->DurableEventBus: return self._bus
    def publish_envelope(self,event:EventEnvelope)->EventReceipt:
        with self._lock:
            now=time.monotonic()
            if now-self._window_start>=1.0: self._window_start,self._window_count=now,0
            if self._window_count>=self.max_events_per_second: self._rejected+=1; raise SlowConsumerError("event-fabric admission rate limit exceeded")
            self._window_count+=1
        receipt=self._bus.publish(event); self._published += 1
        return receipt
    def publish(self,event_type:EventEnvelope|str,payload:Any=None,*,source:str="jarvis.event_fabric",correlation_id:str|None=None,causation_id:str|None=None)->bool:
        if isinstance(event_type,EventEnvelope):
            self.publish_envelope(event_type); return True
        # Legacy compatibility journal: preserve established V12.8.3 behavior.
        event_id=str(uuid.uuid4()); row={"event_id":event_id,"event_type":str(event_type),"timestamp":datetime.now(timezone.utc).isoformat(),"source":source,"correlation_id":correlation_id,"causation_id":causation_id,"schema_version":"legacy-1","payload":{"value":payload},"tenant_id":"default","authorization_context":{},"provenance":{},}
        row["integrity_hash"]=hashlib.sha256(canonical_json(row)).hexdigest()
        with self._lock:
            now=time.monotonic()
            if now-self._window_start>=1.0: self._window_start,self._window_count=now,0
            if self._window_count>=self.max_events_per_second: self._rejected+=1; return False
            self._window_count+=1; self._legacy_records.append(row)
            with self.path.open('a',encoding='utf-8') as handle:
                handle.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n')
        if self.legacy_bus is not None and hasattr(self.legacy_bus,'publish'):
            try: self.legacy_bus.publish(str(event_type),payload,source=source,correlation_id=correlation_id,causation_id=causation_id)
            except TypeError:
                self.legacy_bus.publish(str(event_type),payload)
        self._published += 1; return True
    def _legacy_journal(self,event:Any)->None: return None
    def replay(self,*,event_type:str|None=None,correlation_id:str|None=None,limit:int=1000)->list[dict[str,Any]]:
        rows=list(self._legacy_records)
        if self.path.exists() and not rows:
            for line in self.path.read_text(encoding='utf-8').splitlines():
                try: rows.append(json.loads(line))
                except json.JSONDecodeError: continue
        result=[r for r in rows if (event_type is None or r.get('event_type')==event_type) and (correlation_id is None or r.get('correlation_id')==correlation_id)]
        return result[:max(1,int(limit))]
    def verify_journal(self)->bool:
        if not self.path.exists(): return True
        try:
            for line in self.path.read_text(encoding='utf-8').splitlines():
                if not line.strip(): continue
                row=json.loads(line); expected=str(row.get('integrity_hash','')); material=dict(row); material.pop('integrity_hash',None)
                if not expected or not hmac.compare_digest(expected,hashlib.sha256(canonical_json(material)).hexdigest()): return False
            return True
        except Exception: return False
    def snapshot(self)->Mapping[str,Any]:
        return {"published":self._published,"rejected":self._rejected,"journal":str(self.path),"integrity_verified":self.verify_journal() and self._bus.verify_log()}
    def close(self)->None:
        if self.legacy_bus is not None and self._legacy_subscribed and hasattr(self.legacy_bus,'unsubscribe_event'):
            try:self.legacy_bus.unsubscribe_event('*',self._legacy_journal)
            except Exception: return
        self._bus.close()

"""Per-tool circuit breakers for repeated external failures."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable


class CircuitOpenError(RuntimeError):
    """Raised when a circuit rejects a call while OPEN."""


@dataclass(frozen=True)
class CircuitBreakerConfig:
    failure_threshold: int = 3
    recovery_timeout: float = 30.0
    half_open_max_calls: int = 1
    success_threshold: int = 1


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe CLOSED/OPEN/HALF_OPEN state machine."""

    CircuitState = CircuitState

    def __init__(self, name: str, config: CircuitBreakerConfig | None = None) -> None:
        self.name = name
        self.config = config or CircuitBreakerConfig()
        if self.config.failure_threshold < 1 or self.config.success_threshold < 1:
            raise ValueError("circuit thresholds must be >= 1")
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self._last_failure_time = 0.0
        self._half_open_calls = 0
        self._lock = threading.RLock()

    def _refresh_state(self) -> None:
        if self.state is CircuitState.OPEN and time.monotonic() - self._last_failure_time >= self.config.recovery_timeout:
            self.state = CircuitState.HALF_OPEN
            self._half_open_calls = 0
            self.success_count = 0

    def _on_failure(self) -> None:
        with self._lock:
            self.failure_count += 1
            self.success_count = 0
            self._last_failure_time = time.monotonic()
            if self.state is CircuitState.HALF_OPEN or self.failure_count >= self.config.failure_threshold:
                self.state = CircuitState.OPEN
                self._half_open_calls = 0

    def _on_success(self) -> None:
        with self._lock:
            self.failure_count = 0
            self.success_count += 1
            if self.state is CircuitState.HALF_OPEN and self.success_count >= self.config.success_threshold:
                self.state = CircuitState.CLOSED
                self._half_open_calls = 0

    def call(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        with self._lock:
            self._refresh_state()
            if self.state is CircuitState.OPEN:
                raise CircuitOpenError(f"circuit open for {self.name}")
            if self.state is CircuitState.HALF_OPEN:
                if self._half_open_calls >= self.config.half_open_max_calls:
                    raise CircuitOpenError(f"circuit half-open limit reached for {self.name}")
                self._half_open_calls += 1
        try:
            result = func(*args, **kwargs)
        except Exception:
            self._on_failure()
            raise
        self._on_success()
        return result

    def stats(self) -> dict[str, Any]:
        with self._lock:
            self._refresh_state()
            return {
                "name": self.name,
                "state": self.state.value,
                "failure_count": self.failure_count,
                "success_count": self.success_count,
            }


class CircuitBreakerRegistry:
    """Lazy registry with a shared default policy."""

    def __init__(self, default_config: CircuitBreakerConfig | None = None) -> None:
        self._default = default_config or CircuitBreakerConfig()
        self._breakers: dict[str, CircuitBreaker] = {}
        self._lock = threading.RLock()

    def get(self, name: str) -> CircuitBreaker:
        clean_name = str(name).strip()
        if not clean_name:
            raise ValueError("circuit name is required")
        with self._lock:
            breaker = self._breakers.get(clean_name)
            if breaker is None:
                breaker = CircuitBreaker(clean_name, self._default)
                self._breakers[clean_name] = breaker
            return breaker

    def all_stats(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {name: breaker.stats() for name, breaker in self._breakers.items()}



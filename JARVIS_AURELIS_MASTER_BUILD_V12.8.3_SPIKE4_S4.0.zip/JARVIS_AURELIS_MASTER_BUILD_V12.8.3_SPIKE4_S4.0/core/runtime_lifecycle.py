"""Lifecycle, health, and runtime orchestration for J.A.R.V.I.S."""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from core.health_registry import ProbeSeverity
from core.mission_contract import MissionContract
from core.polyglot_runtime import RuntimeDescriptor
from core.lifecycle_diagnostics import snapshot as capture_lifecycle_snapshot

logger = logging.getLogger("jarvis.lifecycle")


class RuntimeLifecycleMixin:
    """Lifecycle/background behavior separated from the composition root."""


    def lifecycle_snapshot(self) -> dict[str, Any]:
        """Return observable process lifecycle state for diagnostics and certification."""
        return capture_lifecycle_snapshot().to_dict()

    def import_errors(self) -> dict[str, str]:
        return dict(getattr(self, "_import_errors", {}))

    def functional_runtime_health(self) -> dict[str, Any]:
        if not self.health_registry.has_probes():
            return {"status": "blocked", "healthy": False, "reason": "no health probes registered", "probes": []}
        return self.health_registry.readiness()

    def _background_wait(self, seconds: float) -> bool:
        """Wait for the shared shutdown signal without uninterruptible sleep."""
        event = getattr(self, "_background_stop", None)
        if event is None:
            time.sleep(max(0.0, float(seconds)))
            return False
        return bool(event.wait(max(0.0, float(seconds))))

    def _request_background_stop(self) -> None:
        """Wake and bounded-join lifecycle workers without full subsystem teardown."""
        self._shutdown = True
        event = getattr(self, "_background_stop", None)
        if event is not None:
            event.set()
        watchdog = getattr(self, "watchdog", None)
        if watchdog is not None and hasattr(watchdog, "stop"):
            try:
                watchdog.stop()
            except Exception:
                logger.debug("watchdog_background_stop_failed", exc_info=True)
        for thread in list(getattr(self, "_threads", ())):
            if thread is threading.current_thread():
                continue
            if thread.is_alive():
                thread.join(timeout=0.75)

    def _start_scheduler_worker(self) -> None:
        if not self.scheduler:
            return

        def loop() -> None:
            interval = max(
                0.25,
                float(self.cfg.get("scheduler", {}).get("poll_interval", 1.0)),
            )
            while not self._shutdown:
                task = self.scheduler.next_task()
                if task:
                    try:
                        result = self.chat(
                            task.description,
                            session_id=f"scheduled:{task.task_id}",
                        )
                        self.scheduler.complete_task(task.task_id)
                        self.logger.info(
                            "scheduled_task_completed",
                            {"task_id": task.task_id, "result_length": len(result)},
                        )
                    except Exception as exc:
                        task.status = "failed"
                        self.logger.warning(
                            "scheduled_task_failed",
                            {"task_id": task.task_id, "error": str(exc)},
                        )
                else:
                    if self._background_wait(interval):
                        return

        t = threading.Thread(target=loop, name="jarvis-scheduler", daemon=True)
        t.start()
        self._threads.append(t)

    def _start_self_awareness_scan(self) -> None:
        if not self.self_aware:
            return

        def scan() -> None:
            try:
                self.self_aware.scan()
                # The scan may outlive the bounded shutdown join on a large tree.
                # Never emit into a runtime-owned log after shutdown begins; the
                # runtime workspace may already be closing or removed by then.
                if getattr(self, "_shutdown", False):
                    return
                self.logger.info(
                    "self_awareness_scan_complete", self.self_aware.get_stats()
                )
            except Exception as exc:
                self.logger.warning("self_awareness_scan_failed", {"error": str(exc)})

        t = threading.Thread(
            target=scan, name="jarvis-self-awareness", daemon=True
        )
        t.start()
        self._threads.append(t)

    def _launch_autonomous_goal(self, goal: str) -> None:
        """Submit a proactive goal to the persistent autonomous executive."""
        if self._shutdown or not getattr(self, "executive", None):
            return
        try:
            self.executive.trigger(str(goal), priority=75, cooldown_seconds=300.0, source="legacy-monitor")
        except Exception as exc:
            self.logger.exception("autonomous_goal_submission_failed", extra={"goal": str(goal), "error": str(exc)})

    def _execute_autonomous_mission(self, goal: str, mission_id: str | None = None, plan: Any | None = None) -> Any:
        """Execute an executive-approved mission using the injected mission service."""
        if self.mission_service is None:
            raise RuntimeError("mission service unavailable")
        trajectory = getattr(self, "trajectory_recorder", None)
        task_id = str(mission_id or f"mission-{uuid.uuid4().hex[:12]}")
        if trajectory is not None:
            trajectory.record(task_id, "goal.accepted", "autonomous-executive", {"goal": str(goal)[:2000]})
        import asyncio
        owner = "jarvis-executive"
        if mission_id:
            runtime = self.autonomy_engine.get_mission(mission_id)
            if runtime is not None:
                owner = str(runtime.metadata.get("owner") or owner)
        contract_id = mission_id or f"mission-{uuid.uuid4().hex[:12]}"
        contract = self.mission_contracts.get(contract_id)
        if contract is None:
            contract = MissionContract(
                contract_id, str(goal), allowed_capabilities=("observe", "memory.read", "memory.write", "utilities.local"),
                max_steps=int(self.cfg.get("autonomy", {}).get("budget", {}).get("max_steps", 100)),
                max_runtime_seconds=float(self.cfg.get("autonomy", {}).get("budget", {}).get("max_runtime_seconds", 7200)),
            )
            self.mission_contracts[contract_id] = contract
        ok, reasons = self.mission_contract_validator.validate(contract, ("observe",))
        if not ok:
            raise PermissionError("mission contract rejected: " + ",".join(reasons))
        self.logger.info("mission_contract_bound", {"mission_id": contract_id, "digest": contract.digest()})
        if trajectory is not None:
            trajectory.record(task_id, "contract.bound", "mission-contract", {"digest": contract.digest()})
        try:
            result = asyncio.run(self.mission_service.execute_mission(goal, mission_id=mission_id, owner=owner, plan=plan))
            if trajectory is not None:
                trajectory.record(task_id, "mission.completed", "mission-service", {"result_type": type(result).__name__})
            return result
        except Exception as exc:
            if trajectory is not None:
                trajectory.record(task_id, "mission.failed", "mission-service", {"error": type(exc).__name__})
            raise

    def _start_proactive_monitoring(self) -> None:
        pcfg = self.cfg.get("proactive", {})
        if not pcfg.get("enabled", True):
            return

        def loop() -> None:
            while not self._shutdown:
                try:
                    import psutil

                    disk = psutil.disk_usage(
                        str(Path.home().anchor or os.path.abspath(os.sep))
                    ).percent
                    cpu = psutil.cpu_percent(interval=1)
                    mem = psutil.virtual_memory().percent
                    if disk > pcfg.get("disk_threshold", 90):
                        self.logger.warning("proactive_disk_warning", {"percent": disk})
                        sentinel = getattr(self, "sentinel_engine", None)
                        if sentinel is not None:
                            sentinel.emit("health", {"status": "disk-critical", "percent": disk})
                    if cpu > pcfg.get("cpu_threshold", 95):
                        self.logger.warning("proactive_cpu_warning", {"percent": cpu})
                    if mem > pcfg.get("memory_threshold", 90):
                        self.logger.warning("proactive_memory_warning", {"percent": mem})
                    if getattr(self, "frontier_control", None) is not None:
                        window = self.slo.window_snapshot() if getattr(self, "slo", None) is not None else {"availability": 1.0, "requests": 0.0}
                        error_rate = 0.0 if not window.get("requests") else 1.0 - float(window.get("availability", 1.0))
                        posture = self.frontier_control.safe_mode.evaluate(
                            cpu_percent=cpu,
                            memory_percent=mem,
                            error_rate=error_rate,
                            security_incidents=int(self.frontier_control.incidents.snapshot().get("active", 0)),
                        )
                        self.logger.info("frontier_safety_posture", {"mode": posture.value})
                except Exception as exc:
                    self.logger.warning("proactive_monitor_failed", {"error": str(exc)})
                if self._background_wait(60):
                    return

        t = threading.Thread(target=loop, daemon=True, name="jarvis-proactive")
        t.start()
        self._threads.append(t)

    def _start_nightly_consolidation(self) -> None:
        if not self.cfg.get("consolidation", {}).get("nightly_enabled", True):
            return
        if not self.consolidator:
            return

        def loop() -> None:
            while not self._shutdown:
                now = time.localtime()
                if now.tm_hour == 3:
                    try:
                        self.consolidator.run()
                        self.logger.info("nightly_consolidation_complete")
                    except Exception as exc:
                        self.logger.error("nightly_consolidation_error", {"error": str(exc)})
                    if self._background_wait(3600):
                        return
                if self._background_wait(300):
                    return

        t = threading.Thread(target=loop, daemon=True, name="jarvis-consolidation")
        t.start()
        self._threads.append(t)

    def _start_nightly_lora(self) -> None:
        if not self.cfg.get("lora", {}).get("nightly_train", False):
            return

        def loop() -> None:
            while not self._shutdown:
                now = time.localtime()
                if now.tm_hour == 4:
                    primary = self.router.primary
                    if primary and hasattr(primary, "model_path"):
                        try:
                            from training.lora_trainer import LoRATrainer

                            trainer = LoRATrainer()
                            result = trainer.run_nightly(primary.model_path)
                            self.logger.info("lora_nightly", result)
                        except Exception as exc:
                            self.logger.error("lora_nightly_error", {"error": str(exc)})
                    if self._background_wait(3600):
                        return
                if self._background_wait(300):
                    return

        t = threading.Thread(target=loop, daemon=True, name="jarvis-lora")
        t.start()
        self._threads.append(t)

    def get_stats(self) -> dict:
        """Return current system statistics."""
        return {
            "version": self.version,
            "persona": self.persona,
            "session": self.current_session,
            "models_loaded": len(self.swarm.loaded),
            "backends": self.router.list_backends(),
            "memory_sessions": len(self.memory.list_sessions()) if self.memory else 0,
            "import_errors": len(getattr(self, "_import_errors", {})),
            "capabilities": {k: v.available for k, v in self.capabilities.snapshot().items()},
            "tools_registered": len(self.registry.list_tools()),
            "agents": (
                [a.name for a in self.task_manager.list_agents()]
                if self.task_manager
                else []
            ),
            "supreme": self.supreme.snapshot() if getattr(self, "supreme", None) is not None else {},
        }

    def _handle_voice_command(self, command: str) -> None:
        """Run a voice command through chat and speak the response."""
        try:
            response = self.chat(command)
            text = response if isinstance(response, str) else "".join(str(x) for x in response)
            if self.tts and text:
                self.tts.speak(text)
        except Exception as exc:
            self.logger.error("voice_command_failed", {"error": str(exc)})

    def __del__(self) -> None:
        """Best-effort emergency shutdown if an owner forgets explicit cleanup."""
        try:
            self.shutdown()
        except Exception as exc:
            logging.getLogger("jarvis.lifecycle").debug("best_effort_cleanup_failed", exc_info=exc)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.shutdown()
        return False

    def _register_health_probes(self) -> None:
        """Register health probes for all critical subsystems."""
        from services.base import HealthStatus, SubsystemHealth

        def _job_probe() -> SubsystemHealth:
            if self.job_service:
                return self.job_service.health()
            return SubsystemHealth("jobs", HealthStatus.UNAVAILABLE, False, False, False)

        def _memory_probe() -> SubsystemHealth:
            if not self.memory or not callable(getattr(self.memory, "health", None)):
                return SubsystemHealth("memory", HealthStatus.UNAVAILABLE, False, False, False, error_message="public memory health contract unavailable")
            health = dict(self.memory.health())
            ok = bool(health.get("operational", False))
            status = HealthStatus.OPERATIONAL if ok else HealthStatus.ERROR
            return SubsystemHealth("memory", status, ok, True, ok, error_message=None if ok else str(health.get("status", "unavailable")))

        def _router_probe() -> SubsystemHealth:
            try:
                has_backends = len(self.router.list_backends()) > 0
                status = HealthStatus.OPERATIONAL if has_backends else HealthStatus.DEGRADED
                return SubsystemHealth("router", status, has_backends, True, has_backends)
            except Exception as exc:
                return SubsystemHealth("router", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        def _registry_probe() -> SubsystemHealth:
            try:
                tools = len(self.registry.list_tools()) if self.registry else 0
                status = HealthStatus.OPERATIONAL if tools > 0 else HealthStatus.DEGRADED
                return SubsystemHealth("tool_registry", status, True, True, tools > 0)
            except Exception as exc:
                return SubsystemHealth("tool_registry", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("jobs", _job_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("memory", _memory_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("router", _router_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("tool_registry", _registry_probe, severity=ProbeSeverity.DEGRADED)

        def _memory_pressure_probe() -> SubsystemHealth:
            if not self.memory or not callable(getattr(self.memory, "health", None)):
                return SubsystemHealth("memory_pressure", HealthStatus.UNAVAILABLE, False, False, False, error_message="public memory health contract unavailable")
            health = dict(self.memory.health())
            pressure = str(health.get("pressure_status", "normal"))
            status = HealthStatus.ERROR if pressure == "critical" else HealthStatus.DEGRADED if pressure == "warning" else HealthStatus.OPERATIONAL
            return SubsystemHealth("memory_pressure", status, True, True, status == HealthStatus.OPERATIONAL, error_message=None if status == HealthStatus.OPERATIONAL else pressure)

        self.health_registry.register("memory_pressure", _memory_pressure_probe, severity=ProbeSeverity.DEGRADED)

        def _executive_probe() -> SubsystemHealth:
            try:
                snap = self.executive.snapshot()
                status = HealthStatus.OPERATIONAL if snap.get("active", 0) >= 0 else HealthStatus.ERROR
                return SubsystemHealth("executive", status, True, True, True)
            except Exception as exc:
                return SubsystemHealth("executive", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        def _world_probe() -> SubsystemHealth:
            try:
                self.world_model.snapshot()
                return SubsystemHealth("world_model", HealthStatus.OPERATIONAL, True, True, True)
            except Exception as exc:
                return SubsystemHealth("world_model", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        def _cognitive_probe() -> SubsystemHealth:
            try:
                snapshot = self.model_residency.snapshot()
                return SubsystemHealth("cognitive_runtime", HealthStatus.OPERATIONAL, True, True, True, error_message=f"resident_models={len(snapshot)}")
            except Exception as exc:
                return SubsystemHealth("cognitive_runtime", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        def _cognitive_fabric_probe() -> SubsystemHealth:
            try:
                snapshot = self.cognitive_fabric.snapshot()
                return SubsystemHealth("cognitive_fabric", HealthStatus.OPERATIONAL, True, True, True, error_message=f"episodes={snapshot["episodes"]}")
            except Exception as exc:
                return SubsystemHealth("cognitive_fabric", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        def _autonomy_fabric_probe() -> SubsystemHealth:
            try:
                snapshot = self.autonomy_fabric.snapshot()
                return SubsystemHealth("autonomy_fabric", HealthStatus.OPERATIONAL, True, True, True, error_message=f"goals={snapshot['goals']} missions={snapshot['missions']}")
            except Exception as exc:
                return SubsystemHealth("autonomy_fabric", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("executive", _executive_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("autonomy_fabric", _autonomy_fabric_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("world_model", _world_probe, severity=ProbeSeverity.DEGRADED)
        self.health_registry.register("cognitive_runtime", _cognitive_probe, severity=ProbeSeverity.CRITICAL)
        self.health_registry.register("cognitive_fabric", _cognitive_fabric_probe, severity=ProbeSeverity.CRITICAL)

        def _control_plane_probe() -> SubsystemHealth:
            try:
                snap = self.cognitive_control_plane.snapshot()
                valid = bool(snap["provenance"]["valid"])
                status = HealthStatus.OPERATIONAL if valid else HealthStatus.ERROR
                return SubsystemHealth("cognitive_control_plane", status, True, True, valid, error_message=f"state={snap["state"]}")
            except Exception as exc:
                return SubsystemHealth("cognitive_control_plane", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("cognitive_control_plane", _control_plane_probe, severity=ProbeSeverity.CRITICAL)

        def _frontier_probe() -> SubsystemHealth:
            try:
                snapshot = self.frontier.health()
                valid = bool(snapshot["black_box"]["valid"])
                status = HealthStatus.OPERATIONAL if valid else HealthStatus.ERROR
                return SubsystemHealth("frontier_fabric", status, True, True, valid, error_message=f"missions={snapshot['missions']['missions']} tasks={snapshot['mcp_tasks']['tasks']}")
            except Exception as exc:
                return SubsystemHealth("frontier_fabric", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("frontier_fabric", _frontier_probe, severity=ProbeSeverity.CRITICAL)

        def _nextgen_probe() -> SubsystemHealth:
            try:
                snap = self.nextgen.health()
                trusted = bool(snap["attestation"]["trusted"])
                status = HealthStatus.OPERATIONAL if snap["wasi_runtime"] or not trusted else HealthStatus.DEGRADED
                return SubsystemHealth("nextgen_fabric", status, True, True, True, error_message=f"mcp={snap['mcp']['supported_versions']} devices={snap['devices']['devices']}")
            except Exception as exc:
                return SubsystemHealth("nextgen_fabric", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("nextgen_fabric", _nextgen_probe, severity=ProbeSeverity.DEGRADED)

        def _supreme_probe() -> SubsystemHealth:
            try:
                snapshot = self.supreme.refresh_diagnostics()
                ok = bool(snapshot.get("ok"))
                status = HealthStatus.OPERATIONAL if ok else HealthStatus.DEGRADED
                return SubsystemHealth("supreme_control_plane", status, True, True, ok, error_message=f"profile={snapshot.get('profile', 'unknown')}")
            except Exception as exc:
                return SubsystemHealth("supreme_control_plane", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("supreme_control_plane", _supreme_probe, severity=ProbeSeverity.CRITICAL)

        def _frontier_control_probe() -> SubsystemHealth:
            try:
                snap = self.frontier_control.snapshot()
                ok = bool(snap.get("journal_integrity"))
                status = HealthStatus.OPERATIONAL if ok else HealthStatus.ERROR
                return SubsystemHealth("frontier_control", status, True, True, ok, error_message=f"safety={snap.get('safety', {}).get('mode', 'unknown')} incidents={snap.get('incidents', {}).get('active', 0)}")
            except Exception as exc:
                return SubsystemHealth("frontier_control", HealthStatus.ERROR, False, True, False, error_message=str(exc))

        self.health_registry.register("frontier_control", _frontier_control_probe, severity=ProbeSeverity.CRITICAL)

        if self.job_service:
            self.shutdown_coordinator.register("job_service", self.job_service.shutdown)
        if getattr(self, "world_model", None) is not None:
            self.shutdown_coordinator.register("world_model", self.world_model.close)
        if getattr(self, "frontier", None) is not None:
            self.shutdown_coordinator.register("frontier", self.frontier.close)
        if getattr(self, "frontier_control", None) is not None:
            self.shutdown_coordinator.register("frontier_control", self.frontier_control.close)
        self.shutdown_coordinator.register("platform_state_sync", self.platform_frontier["state_sync"].close)
        self.shutdown_coordinator.register("nextgen_fabric", self.nextgen.close)
        if hasattr(self, "supreme"):
            self.shutdown_coordinator.register("supreme_control_plane", self.supreme.close)
        if hasattr(self, "long_term_workers"):
            self.shutdown_coordinator.register("long_term_workers", self.long_term_workers.stop_all)
        if hasattr(self, "autopilot"):
            self.shutdown_coordinator.register("autopilot", self.autopilot.stop)
        self.shutdown_coordinator.register_state_persister("core", lambda: {
            "version": self.VERSION,
            "session": self.current_session,
            "persona": self.persona,
        })

    def health(self) -> dict[str, Any]:
        """Return an aggregate health snapshot using the HealthProbeRegistry."""
        if self.health_registry.has_probes():
            deep = self.health_registry.deep_check()
            overall = "healthy" if deep["status"] == "healthy" else "degraded"
            return {"overall": overall, "probes": deep["probes"], "summary": deep["summary"], "import_errors": self.import_errors(), "lifecycle": self.lifecycle.snapshot()}

        services = {}
        for name, svc in getattr(self, "_services", {}).items():
            try:
                health = svc.health()
                services[name] = health.to_dict() if hasattr(health, "to_dict") else dict(health)
            except Exception as exc:
                services[name] = {"name": name, "status": "error", "available": False, "error_message": str(exc)}
        degraded = [v for v in services.values() if v.get("status") != "operational"]
        overall = "healthy" if not degraded else "degraded"
        return {"overall": overall, "services": services, "import_errors": self.import_errors()}

    def _register_polyglot_runtimes(self) -> None:
        """Register only language surfaces that have concrete release artifacts."""
        root = Path(__file__).resolve().parents[1]

        def toolchain_probe(binary: str, *relative_paths: str):
            paths = tuple(root / path for path in relative_paths)
            return lambda: bool(shutil.which(binary)) and all(path.is_file() for path in paths)

        def file_probe(*relative_paths: str):
            paths = tuple(root / path for path in relative_paths)
            return lambda: all(path.is_file() for path in paths)

        runtimes = (
            (RuntimeDescriptor("python", "Python", "cognitive orchestration", "in-process contracts", "3.12-3.13", ("agents", "rag", "memory", "routing")), None, {"implementation": "core/ + jarvis_rag/"}),
            (RuntimeDescriptor("dart", "Dart", "Flutter command deck", "local stdio bridge", "3.x", ("ui", "streaming", "telemetry")), toolchain_probe("flutter", "flutter/pubspec.yaml", "flutter/lib/main.dart"), {"implementation": "flutter/"}),
            (RuntimeDescriptor("rust", "Rust", "native security/client layer", "gRPC/Protobuf-compatible", "2021", ("secure-client", "typed-native-boundary")), toolchain_probe("cargo", "polyglot/rust/jarvis-client/Cargo.toml", "polyglot/rust/jarvis-client/src/lib.rs"), {"implementation": "polyglot/rust/jarvis-client/"}),
            (RuntimeDescriptor("cpp", "C++", "native vector compute layer", "C ABI", "C++17", ("vector-math", "native-acceleration", "media-client")), file_probe("polyglot/cpp/native/compute.cpp", "polyglot/cpp/native/libjarvis_compute.so"), {"implementation": "polyglot/cpp/native/"}),
            (RuntimeDescriptor("go", "Go", "native bridge/runtime host", "local stdio + HTTP SDK", "1.23", ("process-host", "env-scrubbing", "sdk")), toolchain_probe("go", "native/bridge_host/main_unix.go", "native/bridge_host/main_windows.go", "polyglot/go/jarvis/client.go"), {"implementation": "native/bridge_host/ + polyglot/go/"}),
            (RuntimeDescriptor("typescript", "TypeScript", "JARVIS SDK", "HTTP/JSON", "ES2022+", ("sdk", "remote-control")), toolchain_probe("tsc", "polyglot/typescript/src/client.ts", "polyglot/typescript/tsconfig.json"), {"implementation": "polyglot/typescript/"}),
            (RuntimeDescriptor("java", "Java", "JVM SDK", "HTTP/JSON", "17+", ("sdk", "jvm")), toolchain_probe("javac", "polyglot/java/src/com/jarvis/sdk/JarvisClient.java"), {"implementation": "polyglot/java/"}),
            (RuntimeDescriptor("csharp", "C#", ".NET SDK", "HTTP/JSON", "8+", ("sdk", "windows")), toolchain_probe("dotnet", "polyglot/csharp/JarvisClient.cs", "polyglot/csharp/Jarvis.V12_8.csproj"), {"implementation": "polyglot/csharp/"}),
        )
        for descriptor, probe, metadata in runtimes:
            self.polyglot_runtimes.register(descriptor, probe=probe, metadata=metadata)

    def shutdown(self) -> None:
        """Gracefully shut down all subsystems via ShutdownCoordinator."""
        if self._shutdown:
            return
        self._shutdown = True
        self._request_background_stop()
        self.logger.info("jarvis_shutdown", {"version": self.version})
        if getattr(self, "supreme", None) is not None:
            try:
                self.supreme.recovery.save(
                    "core",
                    {
                        "version": self.version,
                        "session": self.current_session,
                        "persona": self.persona,
                        "saved_at": time.time(),
                    },
                )
            except Exception:
                self.logger.debug("supreme_recovery_save_failed", exc_info=True)
        if getattr(self, "frontier_knowledge", None) is not None:
            try:
                self.frontier_knowledge.close()
            except Exception:
                self.logger.debug("frontier_knowledge_close_failed", exc_info=True)
        try: self.kernel.close()
        except Exception: self.logger.debug("kernel_close_failed", exc_info=True)

        # Use ShutdownCoordinator for ordered, state-persistent shutdown
        self.shutdown_coordinator.initiate_shutdown()

        # Fallback cleanup for services that were not registered with the coordinator.
        registered_objects = {
            id(getattr(handler, "__self__", None))
            for handler in getattr(self.shutdown_coordinator, "_handlers", {}).values()
            if getattr(handler, "__self__", None) is not None
        }
        for name in ("voice", "mission", "workflow", "rag", "memory", "agents", "tools", "chat", "projects", "settings", "system"):
            svc = getattr(self, "_services", {}).get(name)
            if svc is None or id(svc) in registered_objects:
                continue
            fn = getattr(svc, "shutdown", None)
            if not callable(fn):
                continue
            try:
                fn()
            except Exception:
                self.logger.debug("service_shutdown_failed", {"service": name})

        if getattr(self, "plugin_manager", None):
            try: self.plugin_manager.shutdown()
            except Exception: self.logger.debug("plugin_shutdown_failed", exc_info=True)

        self.router.unload_all()
        try:
            self.shutdown_coordinator.restore_signal_handlers()
        except Exception:
            self.logger.debug("signal_handler_restore_failed", exc_info=True)
        self.swarm.shutdown()
        if getattr(self, "multi_gpu", None) and hasattr(self.multi_gpu, "shutdown"):
            self.multi_gpu.shutdown()
        if getattr(self, "profiler", None):
            try:
                self.profiler.shutdown()
            except Exception as exc:
                logger.debug("profiler_shutdown_failed", exc_info=exc)

        if getattr(self, "background_cognition", None):
            self.background_cognition.stop()
        if getattr(self, "executive", None):
            self.executive.stop()
        if getattr(self, "task_scheduler", None):
            self.task_scheduler.stop()
        if getattr(self, "device_gateway", None):
            self.device_gateway.close()
        if getattr(self, "distributed_fabric", None):
            self.distributed_fabric.prune()
        if getattr(self, "world_model", None):
            self.world_model.close()
        if getattr(self, "temporal_world", None):
            self.temporal_world.close()
        if getattr(self, "memory_governance", None):
            self.memory_governance.close()
        if getattr(self, "distributed_queue", None):
            self.distributed_queue.close()
        if getattr(self, "memory", None) and hasattr(self.memory, "shutdown"):
            try:
                self.memory.shutdown()
            except Exception:
                self.logger.debug("memory_shutdown_failed", exc_info=True)
        if getattr(self, "distributed", None) and hasattr(self.distributed, "shutdown"):
            self.distributed.shutdown()
        if getattr(self, "lifecycle", None) is not None:
            # EventBus has already been stopped by the ordered shutdown path;
            # The explicit sync core owns the event bus; the lifecycle graph is
            # kept observable without pretending it was asynchronously started.
            self.lifecycle_snapshot = self.lifecycle.snapshot()
        if self.event_bus:
            self.event_bus.shutdown()

        # Some synchronous integrations may materialize the default asyncio loop
        # during composition. Close it only when JARVIS created it during startup;
        # never interfere with an embedding application's pre-existing loop.
        if getattr(self, "_owns_default_event_loop", False):
            loop = _peek_default_event_loop()
            if loop is not None and not loop.is_running() and not loop.is_closed():
                loop.close()
                if _peek_default_event_loop() is loop:
                    asyncio.set_event_loop(None)

        # Final lifecycle sweep: every subsystem owned directly by the core gets
        # one last close/shutdown opportunity. This prevents leaked DB/file/socket
        # resources when a newly added subsystem was not yet added to the ordered list.
        seen_resources: set[int] = set()
        for resource in list(self.__dict__.values()):
            if resource is None or id(resource) in seen_resources:
                continue
            seen_resources.add(id(resource))
            if resource is self or resource is self.logger:
                continue
            for lifecycle_name in ("shutdown", "close"):
                lifecycle = getattr(resource, lifecycle_name, None)
                if not callable(lifecycle):
                    continue
                try:
                    lifecycle()
                except TypeError:
                    continue
                except Exception as exc:
                    self.logger.debug("resource_lifecycle_sweep_failed", {"resource": type(resource).__name__, "method": lifecycle_name, "exception": repr(exc)})
                break

        for t in self._threads:
            if hasattr(t, "stop"):
                try:
                    t.stop()
                except Exception as exc:
                    logger.debug("watchdog_shutdown_failed", exc_info=exc)

        for obj in (
            getattr(self, "watchdog", None),
            getattr(self, "aion_bridge", None),
            getattr(self, "voice_loop", None),
            getattr(self, "distributed", None),
            getattr(self, "orchestrator", None),
            getattr(self, "workflows", None),
            getattr(self, "memory", None),
            getattr(self, "tts", None),
        ):
            if obj is None:
                continue
            if hasattr(obj, "shutdown"):
                try:
                    obj.shutdown()
                except Exception as exc:
                    logger.debug("subsystem_shutdown_failed", exc_info=exc)
            elif hasattr(obj, "close"):
                try:
                    obj.close()
                except Exception as exc:
                    logger.debug("subsystem_close_failed", exc_info=exc)

        self.logger.info("jarvis_shutdown_complete")




"""System diagnostics for the JARVIS backend and optional capabilities."""
from __future__ import annotations

import importlib.util
import shutil
import sys
from typing import Any


class Doctor:
    """Run required-backend and optional-capability diagnostics."""

    def __init__(self) -> None:
        self._report: dict[str, Any] = {"checks": [], "passed": 0, "failed": 0, "optional_missing": 0}

    def _check(self, name: str, condition: bool, detail: str = "", *, required: bool = True) -> None:
        status = "PASS" if condition else ("OPTIONAL" if not required else "FAIL")
        self._report["checks"].append({"name": name, "status": status, "detail": detail, "required": required})
        if condition:
            self._report["passed"] += 1
        elif required:
            self._report["failed"] += 1
        else:
            self._report["optional_missing"] += 1

    @staticmethod
    def _module_version(module_name: str) -> str:
        module = __import__(module_name)
        return str(getattr(module, "__version__", "installed"))

    def run_all(self) -> None:
        self._check("python_version", sys.version_info >= (3, 12) and sys.version_info < (3, 14), f"{sys.version}")
        required_modules = ("psutil", "httpx", "fastapi", "numpy", "cryptography", "jsonschema")
        for name in required_modules:
            try:
                self._check(name, True, self._module_version(name))
            except Exception as exc:
                self._check(name, False, str(exc))
        optional_modules = (
            ("lancedb", "lancedb_memory"),
            ("sentence_transformers", "embeddings"),
            ("llama_cpp", "native_gguf"),
            ("playwright", "browser_engine"),
            ("whisper", "speech_to_text"),
        )
        for module_name, label in optional_modules:
            available = importlib.util.find_spec(module_name) is not None
            self._check(label, available, "installed" if available else f"optional package {module_name} is not installed", required=False)
        flutter = shutil.which("flutter")
        self._check("flutter_cli", flutter is not None, flutter or "Flutter SDK is not on PATH", required=False)

    def get_report(self) -> dict[str, Any]:
        """Return diagnostics; optional capability absences never make the backend unhealthy."""
        report = dict(self._report)
        report["ok"] = report["failed"] == 0
        return report



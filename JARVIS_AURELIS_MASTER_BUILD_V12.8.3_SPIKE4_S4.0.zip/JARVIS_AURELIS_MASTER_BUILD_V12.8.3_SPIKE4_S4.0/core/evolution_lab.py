"""P2-V Evolution Lab — controlled batched experimentation and evidence orchestration.

P2-V creates hypotheses, bounded experiments, candidate families, evaluation bundles,
adversarial evidence, deterministic comparison/selection records, and P2-G handoffs.
It never certifies or deploys candidates. Production authority remains downstream of
P2-G → P2-B → P2-D.
"""
from __future__ import annotations

import copy
import hashlib
import hmac
import itertools
import json
import math
import random
import sqlite3
import statistics
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes

P2V_VERSION = "1.0.0"
PUBLIC_VERSION = "12.8.3"
KERNEL_VERSION = "12.8.0"

HYPOTHESIS_CLASSES = (
    "capability_gain", "efficiency_gain", "reliability_gain", "safety_improvement", "security_hardening",
    "quality_improvement", "coverage_expansion", "drift_correction", "regression_fix",
    "architecture_exploration", "hyperparameter_search", "composition_opportunity", "pruning_opportunity",
)
EXPERIMENT_KINDS = (
    "single_candidate_test", "ab_test", "n_way_comparison", "parameter_sweep", "hyperparameter_search",
    "architecture_search", "ablation", "adversarial_qualification", "robustness_stress",
    "chained_experiment", "regression_guard_experiment", "cross_environment_experiment",
)
SCOPES = (
    "single_tenant", "single_artifact_class", "single_environment", "multi_environment", "simulation_only",
    "isolated_with_synthetic", "mirrored_real_readonly", "forked_real",
)
METRICS = (
    "correctness", "reliability", "latency", "cost", "resource_efficiency", "safety", "security",
    "robustness", "coverage", "generalization", "stability", "attribution_quality", "custom",
)
OUTCOMES = (
    "completed", "aborted", "inconclusive", "no_winner", "winner_selected", "multiple_winners",
    "regression_detected", "adversarial_failure", "security_failure", "verification_failure",
    "cancelled", "timed_out",
)
REAL_SIDE_EFFECTS = ("none", "read_only", "forked", "declared")
DIRECTIONS = ("higher_is_better", "lower_is_better")
SEARCH_STRATEGIES = (
    "grid_search", "random_search", "bayesian_optimization", "evolutionary",
    "successive_halving", "hyperband", "custom",
)
MULTIPLE_CORRECTION = ("none", "bonferroni", "holm", "fdr")
STOPPING_RULES = ("fixed_n", "sequential", "adaptive")
SELECTION_RANKING = ("primary_metric", "composite", "pareto", "custom")

DANGEROUS_EFFECTS = {"destructive", "financial", "identity", "device", "communication", "irreversible"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _uuid() -> str:
    return str(uuid.uuid4())


def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _sign_document(document: Mapping[str, Any], key: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    body = copy.deepcopy(dict(document))
    body["writer_key_id"] = str(key_id)
    body["integrity_hash"] = ""
    body["signature"] = ""
    body["integrity_hash"] = _sha(body)
    body["signature"] = key.sign(canonical_bytes(body)).hex()
    return body


def verify_signed_document(document: Mapping[str, Any], public_key: bytes | Ed25519PublicKey) -> bool:
    try:
        body = copy.deepcopy(dict(document))
        signature = bytes.fromhex(str(body.pop("signature")))
        integrity = str(body.get("integrity_hash", ""))
        body["integrity_hash"] = ""
        body["signature"] = ""
        if not hmac.compare_digest(_sha(body), integrity):
            return False
        body["integrity_hash"] = integrity
        key = public_key if isinstance(public_key, Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(public_key)
        key.verify(signature, canonical_bytes(body))
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError):
        return False


class EvolutionLabError(RuntimeError):
    """Base P2-V error."""


class ExecutionContextRequired(EvolutionLabError, PermissionError):
    """P2-E execution context missing or invalid."""


class TenantIsolationError(EvolutionLabError, PermissionError):
    """Tenant boundary violation."""


class ValidationError(EvolutionLabError, ValueError):
    """Artifact validation failure."""


class SignatureError(EvolutionLabError, ValueError):
    """Signature/integrity failure."""


class IsolationError(EvolutionLabError):
    """Experiment isolation cannot be positively established."""


class FairnessError(EvolutionLabError):
    """Family evaluation conditions are not identical."""


class StatisticalConfigError(EvolutionLabError, ValueError):
    """Statistical design is invalid or changed post-registration."""


class LifecycleError(EvolutionLabError):
    """Lifecycle transition or budget error."""


class HandoffDenied(EvolutionLabError, PermissionError):
    """P2-G handoff not admissible."""


class SearchError(EvolutionLabError, ValueError):
    """Search definition or budget failure."""


@dataclass(frozen=True, slots=True)
class ExperimentConfig:
    store_path: str = ":memory:"
    storage_secret: bytes = b"jarvis-p2v-evolution-lab-secret-32-bytes"
    signer_key_id: str = "p2v-evolution-lab"
    replay_window_seconds: float = 7 * 24 * 3600.0
    default_budget_seconds: float = 3600.0
    max_family_size: int = 128
    max_parallelism: int = 16
    bootstrap_default_iterations: int = 1000


@dataclass(frozen=True, slots=True)
class ExecutionContextView:
    tenant_id: str
    principal: str = "p2v"
    correlation_id: str | None = None
    causation_id: str | None = None


class _Store:
    """Small tenant-aware SQLite content-addressed store."""

    def __init__(self, path: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("P2-V storage secret must be at least 32 bytes")
        self._memory = str(path) == ":memory:"
        self.path = Path(path)
        if not self._memory:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = bytes(secret)
        self.db = sqlite3.connect(":memory:" if self._memory else str(self.path), check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS artifacts (kind TEXT NOT NULL, id TEXT NOT NULL, tenant TEXT NOT NULL, version INTEGER NOT NULL, content TEXT NOT NULL, body_hash TEXT NOT NULL, tag TEXT NOT NULL, created_at REAL NOT NULL, PRIMARY KEY(kind,id,tenant))"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS chains (tenant TEXT NOT NULL, seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, id TEXT NOT NULL, prev_hash TEXT NOT NULL, body_hash TEXT NOT NULL)"
        )
        self.db.commit()
        self.lock = threading.RLock()

    def _tag(self, kind: str, ident: str, tenant: str, body_hash: str) -> str:
        return hmac.new(self.secret, f"{kind}|{ident}|{tenant}|{body_hash}".encode(), hashlib.sha256).hexdigest()

    def put(self, kind: str, ident: str, tenant: str, body: Mapping[str, Any], version: int | None = None) -> None:
        raw = json.dumps(dict(body), sort_keys=True, separators=(",", ":"))
        body_hash = _sha(body)
        ver = int(version or body.get("experiment_version") or body.get("hypothesis_version") or 1)
        tag = self._tag(kind, ident, tenant, body_hash)
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO artifacts(kind,id,tenant,version,content,body_hash,tag,created_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(kind,id,tenant) DO UPDATE SET version=excluded.version, content=excluded.content, body_hash=excluded.body_hash, tag=excluded.tag",
                (kind, ident, tenant, ver, raw, body_hash, tag, time.time()),
            )

    def get(self, kind: str, ident: str, tenant: str) -> dict[str, Any] | None:
        with self.lock:
            row = self.db.execute("SELECT content,body_hash,tag FROM artifacts WHERE kind=? AND id=? AND tenant=?", (kind, ident, tenant)).fetchone()
        if row is None:
            return None
        content, body_hash, tag = row
        if not hmac.compare_digest(body_hash, _sha(json.loads(content))):
            raise SignatureError("stored body hash mismatch")
        if not hmac.compare_digest(tag, self._tag(kind, ident, tenant, body_hash)):
            raise SignatureError("stored integrity tag mismatch")
        return json.loads(content)

    def list(self, kind: str, tenant: str) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.db.execute("SELECT content FROM artifacts WHERE kind=? AND tenant=? ORDER BY created_at, id", (kind, tenant)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def append_chain(self, tenant: str, kind: str, ident: str, body_hash: str) -> str:
        with self.lock, self.db:
            prev = self.db.execute("SELECT body_hash FROM chains WHERE tenant=? ORDER BY seq DESC LIMIT 1", (tenant,)).fetchone()
            prev_hash = prev[0] if prev else ""
            self.db.execute("INSERT INTO chains(tenant,kind,id,prev_hash,body_hash) VALUES(?,?,?,?,?)", (tenant, kind, ident, prev_hash, body_hash))
        return prev_hash

    def chain(self, tenant: str) -> list[dict[str, Any]]:
        with self.lock:
            rows = self.db.execute("SELECT seq,kind,id,prev_hash,body_hash FROM chains WHERE tenant=? ORDER BY seq", (tenant,)).fetchall()
        return [{"seq": r[0], "kind": r[1], "id": r[2], "prev_hash": r[3], "body_hash": r[4]} for r in rows]

    def close(self) -> None:
        self.db.close()


def _as_context(context: Any, tenant_id: str) -> ExecutionContextView:
    if context is None:
        raise ExecutionContextRequired("P2-V operation requires P2-E ExecutionContext")
    if isinstance(context, ExecutionContextView):
        tenant = context.tenant_id
        principal = context.principal
        correlation = context.correlation_id
        causation = context.causation_id
    elif isinstance(context, Mapping):
        tenant = str(context.get("tenant_id", ""))
        principal = str(context.get("principal", context.get("actor", "p2v")))
        correlation = context.get("correlation_id")
        causation = context.get("causation_id")
    else:
        tenant = str(getattr(context, "tenant_id", ""))
        principal = str(getattr(context, "principal", "p2v"))
        correlation = getattr(context, "correlation_id", None)
        causation = getattr(context, "causation_id", None)
    if not tenant or tenant != tenant_id:
        raise TenantIsolationError("execution context tenant mismatch")
    return ExecutionContextView(tenant, principal, correlation, causation)


def _require_uuid(value: Any, field: str) -> str:
    try:
        v = str(uuid.UUID(str(value)))
    except (ValueError, AttributeError):
        raise ValidationError(f"{field} must be a UUID")
    return v


def _finite(value: Any, field: str, minimum: float | None = None, maximum: float | None = None) -> float:
    try:
        x = float(value)
    except (ValueError, TypeError):
        raise ValidationError(f"{field} must be numeric")
    if not math.isfinite(x):
        raise ValidationError(f"{field} must be finite")
    if minimum is not None and x < minimum:
        raise ValidationError(f"{field} below minimum")
    if maximum is not None and x > maximum:
        raise ValidationError(f"{field} above maximum")
    return x


def _normal_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _normal_ppf(p: float) -> float:
    if p <= 0.0 or p >= 1.0:
        raise ValueError("p must be in (0,1)")
    return statistics.NormalDist().inv_cdf(p)


def _mean_ci(values: Sequence[float], level: float) -> tuple[float, float]:
    if not values:
        raise StatisticalConfigError("no samples")
    mean = statistics.fmean(values)
    if len(values) == 1:
        return mean, mean
    sd = statistics.stdev(values)
    z = _normal_ppf(0.5 + level / 2.0)
    half = z * sd / math.sqrt(len(values))
    return mean - half, mean + half


def _bootstrap_ci(values: Sequence[float], level: float, iterations: int, seed: int) -> tuple[float, float]:
    if not values:
        raise StatisticalConfigError("no samples")
    if len(values) == 1:
        return float(values[0]), float(values[0])
    rng = random.Random(seed)
    n = len(values)
    means = [statistics.fmean(rng.choice(values) for _ in range(n)) for _ in range(max(50, int(iterations)))]
    means.sort()
    alpha = (1.0 - level) / 2.0
    lo = means[max(0, int(alpha * len(means)) - 1)]
    hi = means[min(len(means) - 1, int((1.0 - alpha) * len(means)))]
    return float(lo), float(hi)


def _permutation_pvalue(values: Sequence[float], seed: int, exact_limit: int = 15, resamples: int = 20000) -> float:
    """Two-sided sign-flip test on paired/non-zero differences."""
    if not values:
        raise StatisticalConfigError("no differences")
    diffs = [float(x) for x in values]
    observed = abs(statistics.fmean(diffs))
    n = len(diffs)
    if n <= exact_limit:
        extreme = 0
        total = 1 << n
        for mask in range(total):
            signed = [d if (mask >> i) & 1 else -d for i, d in enumerate(diffs)]
            if abs(statistics.fmean(signed)) >= observed - 1e-15:
                extreme += 1
        return extreme / total
    rng = random.Random(seed)
    extreme = 0
    for _ in range(resamples):
        signed_mean = statistics.fmean(d if rng.getrandbits(1) else -d for d in diffs)
        if abs(signed_mean) >= observed - 1e-15:
            extreme += 1
    return (extreme + 1) / (resamples + 1)


def _cohen_d(values: Sequence[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = statistics.fmean(values)
    sd = statistics.stdev(values)
    # Zero-variance samples have an undefined standardized effect; use a deterministic
    # finite epsilon denominator so signed contracts never contain +/-inf.
    return mean / max(sd, 1e-12)


def power_sample_size(effect_size: float, alpha: float = 0.05, power: float = 0.8, paired: bool = False) -> int:
    """Closed-form normal approximation for planning sample size."""
    effect = abs(float(effect_size))
    if effect <= 0:
        raise StatisticalConfigError("effect_size_min must be positive")
    z_alpha = _normal_ppf(1.0 - alpha / 2.0)
    z_power = _normal_ppf(power)
    n = ((z_alpha + z_power) / effect) ** 2
    return max(2, int(math.ceil(n if paired else 2.0 * n)))


class EvolutionLab:
    """Canonical P2-V orchestrator."""

    def __init__(
        self,
        *,
        tenant_id: str = "default",
        config: ExperimentConfig | None = None,
        signer: Ed25519PrivateKey | None = None,
        p2g: Any | None = None,
        p2c: Any | None = None,
        p2e: Any | None = None,
        p2k: Any | None = None,
        p2s: Any | None = None,
        p2n: Any | None = None,
        p2t: Any | None = None,
        p2i: Any | None = None,
        p2h: Any | None = None,
        p2r: Any | None = None,
        event_fabric: Any | None = None,
        isolation_verifier: Callable[[Mapping[str, Any], Any], Mapping[str, bool]] | None = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.tenant_id = str(tenant_id)
        self.config = config or ExperimentConfig()
        self.signer = signer or Ed25519PrivateKey.generate()
        self.public_key = self.signer.public_key()
        self.p2g = p2g
        self.p2c = p2c
        self.p2e = p2e
        self.p2k = p2k
        self.p2s = p2s
        self.p2n = p2n
        self.p2t = p2t
        self.p2i = p2i
        self.p2h = p2h
        self.p2r = p2r
        self.event_fabric = event_fabric
        self.isolation_verifier = isolation_verifier
        self._store = _Store(self.config.store_path, self.config.storage_secret)
        self._clock = clock
        self._started_at: dict[str, float] = {}
        self._lock = threading.RLock()

    # ---------- identity / policy ----------
    def _ctx(self, context: Any) -> ExecutionContextView:
        return _as_context(context, self.tenant_id)

    def _signed(self, body: Mapping[str, Any]) -> dict[str, Any]:
        return _sign_document(body, self.signer, self.config.signer_key_id)

    def _emit(self, name: str, payload: Mapping[str, Any], ctx: ExecutionContextView, *, experiment_id: str | None = None) -> None:
        if self.event_fabric is None:
            return
        event_payload = dict(payload)
        event_payload.setdefault("tenant_id", ctx.tenant_id)
        event_payload.setdefault("delivery_mode", "exactly_once_ordered")
        if experiment_id:
            event_payload.setdefault("experiment_id", experiment_id)
        result = None
        if hasattr(self.event_fabric, "publish"):
            result = self.event_fabric.publish(
                f"Evolution.{name}", event_payload, source="p2v.evolution_lab",
                correlation_id=ctx.correlation_id or experiment_id or ctx.tenant_id,
                causation_id=ctx.causation_id,
            )
        elif hasattr(self.event_fabric, "emit"):
            result = self.event_fabric.emit(f"Evolution.{name}", event_payload, correlation_id=ctx.correlation_id or experiment_id)
        if result is False:
            raise LifecycleError("event admission failed; lifecycle transition refused")

    def _save(self, kind: str, ident: str, tenant: str, body: Mapping[str, Any], *, version: int = 1, chain: bool = False) -> dict[str, Any]:
        body0 = copy.deepcopy(dict(body))
        if chain:
            prev_row = self._store.chain(tenant)
            body0["chain_prev_hash"] = prev_row[-1]["body_hash"] if prev_row else None
        signed = self._signed(body0)
        if chain:
            self._store.append_chain(tenant, kind, ident, _sha(signed))
        self._store.put(kind, ident, tenant, signed, version)
        return signed

    def _get(self, kind: str, ident: str, ctx: ExecutionContextView) -> dict[str, Any]:
        doc = self._store.get(kind, ident, ctx.tenant_id)
        if doc is None:
            raise ValidationError(f"{kind} not found: {ident}")
        if not verify_signed_document(doc, self.public_key):
            raise SignatureError(f"{kind} signature invalid")
        return doc

    # ---------- hypothesis ----------
    def propose_hypothesis(self, hypothesis: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context)
        h = copy.deepcopy(dict(hypothesis))
        if "hypothesis_id" not in h:
            h["hypothesis_id"] = _uuid()
        hid = _require_uuid(h["hypothesis_id"], "hypothesis_id")
        h["hypothesis_id"] = hid
        h["tenant_id"] = ctx.tenant_id
        h["hypothesis_version"] = int(h.get("hypothesis_version", 1))
        if h.get("hypothesis_class") not in HYPOTHESIS_CLASSES:
            raise ValidationError("invalid hypothesis_class")
        if not str(h.get("statement", "")).strip() or not str(h.get("rationale", "")).strip():
            raise ValidationError("statement and rationale are mandatory")
        criteria = list(h.get("falsification_criteria", []))
        if not criteria:
            raise ValidationError("falsification_criteria must be non-empty")
        expected = h.get("expected_effect")
        if not isinstance(expected, Mapping):
            raise ValidationError("expected_effect must be an object")
        _finite(expected.get("magnitude"), "expected_effect.magnitude", 0.0)
        if expected.get("direction") not in DIRECTIONS:
            raise ValidationError("expected_effect.direction invalid")
        if expected.get("metric") not in METRICS:
            raise ValidationError("expected_effect.metric invalid")
        h["evidence_refs"] = sorted(set(map(str, h.get("evidence_refs", []))))
        h["motivating_triggers"] = sorted(set(map(str, h.get("motivating_triggers", []))))
        h["motivating_diagnoses"] = sorted(set(map(str, h.get("motivating_diagnoses", []))))
        h["motivating_failures"] = sorted(set(map(str, h.get("motivating_failures", []))))
        h["motivating_research"] = sorted(set(map(str, h.get("motivating_research", []))))
        h["prior_experiments"] = sorted(set(map(str, h.get("prior_experiments", []))))
        h["constraints"] = list(h.get("constraints", []))
        h["forbidden_changes"] = list(h.get("forbidden_changes", []))
        if h.get("allowed_scope") not in SCOPES:
            raise ValidationError("allowed_scope invalid")
        budget = dict(h.get("budget", {}))
        _finite(budget.get("wall_seconds"), "budget.wall_seconds", 0.001)
        _finite(budget.get("cost_units"), "budget.cost_units", 0.0)
        max_candidates = int(budget.get("max_candidates", 0))
        max_parallelism = int(budget.get("max_parallelism", 0))
        if max_candidates <= 0 or max_candidates > self.config.max_family_size:
            raise ValidationError("budget.max_candidates outside allowed bounds")
        if max_parallelism <= 0 or max_parallelism > self.config.max_parallelism:
            raise ValidationError("budget.max_parallelism outside allowed bounds")
        h["budget"] = {"wall_seconds": float(budget["wall_seconds"]), "cost_units": float(budget["cost_units"]), "max_candidates": max_candidates, "max_parallelism": max_parallelism}
        proposed_by = dict(h.get("proposed_by", {"principal": ctx.principal, "key_id": self.config.signer_key_id}))
        if not proposed_by.get("principal") or not proposed_by.get("key_id"):
            raise ValidationError("proposed_by must identify a principal and key")
        h["proposed_by"] = proposed_by
        h["proposed_by_kind"] = h.get("proposed_by_kind", "pipeline")
        if h["proposed_by_kind"] not in {"pipeline", "operator", "agent", "research"}:
            raise ValidationError("proposed_by_kind invalid")
        h["proposed_at"] = h.get("proposed_at", _now())
        h["target_artifact_ref"] = str(h.get("target_artifact_ref", ""))
        h["target_artifact_class"] = str(h.get("target_artifact_class", ""))
        h["candidate_classes"] = list(map(str, h.get("candidate_classes", [])))
        semantic = {k: v for k, v in h.items() if k not in {"hypothesis_id", "hypothesis_version", "proposed_at", "signature", "integrity_hash", "writer_key_id", "content_hash"}}
        content_hash = _sha(semantic)
        for prior in self._store.list("hypothesis", ctx.tenant_id):
            if prior.get("content_hash") == content_hash:
                try:
                    age = time.time() - datetime.fromisoformat(str(prior.get("proposed_at")).replace("Z", "+00:00")).timestamp()
                except Exception:
                    age = 0.0
                if age <= self.config.replay_window_seconds:
                    return str(prior["hypothesis_id"])
        h["content_hash"] = content_hash
        h = self._save("hypothesis", hid, ctx.tenant_id, h, version=h["hypothesis_version"])
        self._emit("HypothesisProposed", {"hypothesis_id": hid, "hypothesis_class": h["hypothesis_class"], "content_hash": h["content_hash"]}, ctx)
        return hid

    def get_hypothesis(self, hypothesis_id: str, *, context: Any) -> dict[str, Any]:
        return self._get("hypothesis", _require_uuid(hypothesis_id, "hypothesis_id"), self._ctx(context))

    def list_hypotheses(self, filter: Mapping[str, Any] | None = None, *, context: Any) -> list[dict[str, Any]]:
        ctx = self._ctx(context)
        rows = self._store.list("hypothesis", ctx.tenant_id)
        filt = dict(filter or {})
        return [r for r in rows if all(r.get(k) == v for k, v in filt.items())]

    def withdraw_hypothesis(self, hypothesis_id: str, reason: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context)
        h = self.get_hypothesis(hypothesis_id, context=ctx)
        h["withdrawn"] = True
        h["withdrawal_reason"] = str(reason)
        h["withdrawn_at"] = _now()
        saved = self._save("hypothesis", h["hypothesis_id"], ctx.tenant_id, {k: v for k, v in h.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(h["hypothesis_version"]) + 1)
        self._emit("HypothesisWithdrawn", {"hypothesis_id": h["hypothesis_id"], "reason": reason}, ctx)
        return saved

    # ---------- experiments / family ----------
    def prepare_experiment(self, hypothesis_id: str, kind: str, family_spec: Mapping[str, Any], conditions: Mapping[str, Any], budget: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context)
        hypothesis = self.get_hypothesis(hypothesis_id, context=ctx)
        if hypothesis.get("withdrawn"):
            raise LifecycleError("withdrawn hypothesis cannot launch an experiment")
        if kind not in EXPERIMENT_KINDS:
            raise ValidationError("invalid experiment_kind")
        family = dict(family_spec)
        candidates = list(family.get("candidates", []))
        baseline_ref = family.get("baseline_ref")
        if baseline_ref is None:
            raise ValidationError("family baseline is mandatory")
        if not candidates and family.get("variant_space") is None:
            raise ValidationError("family must contain candidates or variant_space")
        if len(candidates) > self.config.max_family_size:
            raise ValidationError("family too large")
        if family.get("variant_space") is not None and not isinstance(family["variant_space"], Mapping):
            raise ValidationError("variant_space must be typed")
        conditions = copy.deepcopy(dict(conditions))
        stats_cfg = dict(conditions.get("statistical_config", {}))
        self._validate_statistical_config(stats_cfg, candidates_count=max(1, len(candidates)), pre_registration=True)
        if stats_cfg.get("sample_size_rule") == "power_analysis":
            derived = power_sample_size(float(stats_cfg["effect_size_min"]), float(stats_cfg["significance_threshold"]), float(stats_cfg["power_target"]), bool(stats_cfg.get("paired", False)))
            if int(stats_cfg["sample_size"]) < derived:
                raise StatisticalConfigError(f"declared sample_size {stats_cfg['sample_size']} is below derived power-analysis size {derived}")
            stats_cfg["derived_sample_size"] = derived
            conditions["statistical_config"] = stats_cfg
        iso = dict(conditions.get("isolation_guarantees", {}))
        self._validate_isolation_decl(iso)
        if iso.get("real_side_effects") != "none" and self.p2s is None:
            raise IsolationError("real side effects require P2-S Security Evolution authorization")
        self._verify_isolation(iso, ctx)
        if conditions.get("seed") is None:
            raise ValidationError("seed required")
        if not str(conditions.get("environment_hash", "")):
            raise ValidationError("environment_hash required")
        if not str(conditions.get("registry_state_ref", "")):
            raise ValidationError("registry_state_ref required")
        if not str(conditions.get("policy_version", "")):
            raise ValidationError("policy_version required")
        if not str(conditions.get("benchmark_suite_ref", "")):
            raise ValidationError("benchmark_suite_ref required")
        dangerous_family = bool(conditions.get("dangerous_change_surface", False)) or any(self._candidate_dangerous(c, self.p2g) for c in candidates if isinstance(c, Mapping))
        if dangerous_family:
            if not conditions.get("simulation_ref"):
                raise IsolationError("dangerous family requires a P2-K simulation_ref")
            conditions["adversarial_required"] = True
            if not conditions.get("adversarial_suite_ref"):
                raise LifecycleError("dangerous family requires adversarial_suite_ref")
        metrics = list(conditions.get("comparison_metrics", []))
        primary = conditions.get("primary_metric")
        if primary not in METRICS or primary not in metrics:
            raise ValidationError("primary metric must be declared in comparison_metrics")
        if int(len(candidates)) == 0 and family.get("variant_space") is None:
            raise ValidationError("family must be non-empty")
        experiment_id = _uuid()
        fam_id = str(family.get("family_id") or _uuid())
        family["family_id"] = fam_id
        family["candidates"] = candidates
        family["baseline_ref"] = baseline_ref
        experiment = {
            "experiment_id": experiment_id, "experiment_version": 1, "tenant_id": ctx.tenant_id,
            "experiment_kind": kind, "title": str(family_spec.get("title", f"P2-V {kind}")),
            "description": str(family_spec.get("description", "")), "hypothesis_ref": str(hypothesis_id),
            "family": family, "conditions": conditions, "comparison_metrics": metrics, "dangerous_family": dangerous_family, "simulation_report_ref": None,
            "primary_metric": primary, "secondary_metrics": [m for m in metrics if m != primary],
            "statistical_config": dict(conditions["statistical_config"]),
            "adversarial_required": bool(conditions.get("adversarial_required", False)),
            "adversarial_suite_ref": conditions.get("adversarial_suite_ref"), "adversarial_scope": conditions.get("adversarial_scope"),
            "budget": {"wall_seconds": float(budget.get("wall_seconds", self.config.default_budget_seconds)), "cost_units": float(budget.get("cost_units", 0.0)), "max_parallelism": int(budget.get("max_parallelism", 1))},
            "state": "prepared", "outcome": None, "opened_at": _now(), "closed_at": None,
            "selection_policy_ref": str(conditions.get("selection_policy_ref", "policy://p2v/default-selection/1.0.0")), "selection_decision_ref": None,
            "launched_by": {"principal": ctx.principal, "key_id": self.config.signer_key_id}, "launcher_kind": "operator",
            "pipeline_version": P2V_VERSION, "detector_versions": dict(conditions.get("detector_versions", {})),
            "signature": "", "integrity_hash": "", "chain_prev_hash": None,
        }
        saved = self._save("experiment", experiment_id, ctx.tenant_id, experiment, chain=True)
        self._store.put("family", fam_id, ctx.tenant_id, self._signed({"family_id": fam_id, "tenant_id": ctx.tenant_id, **family}))
        self._started_at[experiment_id] = self._clock()
        self._emit("ExperimentPrepared", {"experiment_id": experiment_id, "family_id": fam_id, "hypothesis_id": hypothesis_id}, ctx, experiment_id=experiment_id)
        self._emit("FamilyComposed", {"experiment_id": experiment_id, "family_id": fam_id, "candidate_count": len(candidates)}, ctx, experiment_id=experiment_id)
        return experiment_id

    def get_experiment(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        return self._get("experiment", _require_uuid(experiment_id, "experiment_id"), self._ctx(context))

    def query_experiments(self, filter: Mapping[str, Any] | None = None, *, context: Any) -> list[dict[str, Any]]:
        ctx = self._ctx(context)
        rows = self._store.list("experiment", ctx.tenant_id)
        filt = dict(filter or {})
        return [r for r in rows if all(r.get(k) == v for k, v in filt.items())]

    def compose_family(self, experiment_id: str, candidates: Sequence[Mapping[str, Any]], *, context: Any) -> str:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "prepared":
            raise LifecycleError("family composition is frozen after Stage 1")
        if len(candidates) == 0 or len(candidates) > self.config.max_family_size:
            raise ValidationError("candidate family size invalid")
        refs = [str(c["candidate_id"]) if isinstance(c, Mapping) and "candidate_id" in c else str(c) for c in candidates]
        family_id = exp["family"]["family_id"]
        exp["family"]["candidates"] = refs
        exp["family"]["family_frozen"] = False
        self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]))
        self._emit("FamilyComposed", {"experiment_id": exp["experiment_id"], "family_id": family_id, "candidate_count": len(refs)}, ctx, experiment_id=exp["experiment_id"])
        return family_id

    def generate_family(self, experiment_id: str, generator_refs: Sequence[str], parameters_set: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "prepared":
            raise LifecycleError("family generation is frozen after Stage 1")
        refs = [str(x) for x in generator_refs]
        if not refs:
            raise ValidationError("generator_refs must be non-empty")
        space = self._validate_search_space(parameters_set)
        generated = []
        for index, params in enumerate(self._grid_points(space)):
            if len(generated) >= int(exp["budget"]["max_parallelism"]) * int(exp["family"].get("max_generated", self.config.max_family_size)):
                break
            generated.append({"candidate_id": _sha({"experiment": exp["experiment_id"], "index": index, "params": params}), "parameters": params, "generator_refs": refs})
        if not generated:
            raise SearchError("parameter set produced no candidates")
        exp["family"]["candidates"] = [x["candidate_id"] for x in generated]
        exp["family"]["variant_space"] = {"space": space, "generated": generated}
        exp["family"]["family_frozen"] = False
        self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]))
        self._emit("FamilyGenerated", {"experiment_id": exp["experiment_id"], "family_id": exp["family"]["family_id"], "candidate_count": len(generated)}, ctx, experiment_id=exp["experiment_id"])
        return exp["family"]["family_id"]

    def inspect_family(self, family_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context)
        return self._get("family", str(family_id), ctx)

    # ---------- isolation and stages ----------
    @staticmethod
    def _validate_isolation_decl(iso: Mapping[str, Any]) -> None:
        required = (
            "tenant_isolation", "experiment_isolation", "candidate_isolation", "production_isolation",
            "real_side_effects", "shared_state_blocked", "shared_cache_blocked", "shared_secrets_blocked",
            "shared_memory_blocked", "shared_world_state_blocked", "cpu_isolation", "gpu_isolation",
            "network_isolation", "filesystem_isolation", "device_isolation", "clock_isolation", "random_seed_isolation",
        )
        for key in required:
            if key not in iso:
                raise IsolationError(f"isolation guarantee missing: {key}")
        if iso["real_side_effects"] not in REAL_SIDE_EFFECTS:
            raise IsolationError("invalid real_side_effects")

    def _verify_isolation(self, iso: Mapping[str, Any], ctx: ExecutionContextView, *, experiment_id: str | None = None) -> None:
        self._validate_isolation_decl(iso)
        checks = {k: bool(v) for k, v in iso.items() if k.endswith("isolation") or k.endswith("blocked") or k == "production_isolation"}
        checks["real_side_effects_none"] = iso["real_side_effects"] == "none"
        if self.isolation_verifier is not None:
            verified = dict(self.isolation_verifier(iso, ctx))
            checks.update({str(k): bool(v) for k, v in verified.items()})
        failed = [k for k, value in checks.items() if not value]
        if failed:
            if experiment_id:
                self.abort_experiment(experiment_id, f"isolation verification failed: {','.join(failed)}", context=ctx)
            raise IsolationError(f"isolation guarantees failed: {','.join(failed)}")

    @staticmethod
    def _candidate_dangerous(candidate: Mapping[str, Any], p2g: Any | None = None) -> bool:
        if bool(candidate.get("dangerous", False)) or bool(candidate.get("requires_simulation", False)):
            return True
        if bool(candidate.get("capability_widening", False) or candidate.get("permission_widening", False) or candidate.get("scope_widening", False) or candidate.get("irreversible", False)):
            return True
        effects = set(map(str, candidate.get("effects", [])))
        if effects & DANGEROUS_EFFECTS:
            return True
        if p2g is not None and hasattr(p2g, "danger_matrix"):
            try:
                return bool(dict(p2g.danger_matrix(candidate)).get("dangerous", False))
            except Exception:
                return True
        return False

    def _check_budget(self, experiment_id: str, exp: Mapping[str, Any]) -> None:
        started = self._started_at.setdefault(experiment_id, self._clock())
        if self._clock() - started > float(exp["budget"]["wall_seconds"]):
            raise LifecycleError("experiment wall-clock budget exceeded")

    def start_experiment(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "prepared":
            raise LifecycleError("experiment must be prepared")
        self._check_budget(experiment_id, exp)
        self.verify_isolation(experiment_id, context=ctx)
        if not exp["family"].get("candidates"):
            raise ValidationError("family has no candidates")
        exp["family"]["family_frozen"] = True
        exp["state"] = "running"
        exp["experiment_version"] = int(exp["experiment_version"]) + 1
        saved = self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=exp["experiment_version"])
        self._emit("FamilyFrozen", {"experiment_id": exp["experiment_id"], "family_id": exp["family"]["family_id"]}, ctx, experiment_id=exp["experiment_id"])
        self._emit("ExperimentStarted", {"experiment_id": exp["experiment_id"]}, ctx, experiment_id=exp["experiment_id"])
        return saved

    def pause_experiment(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "running":
            raise LifecycleError("only running experiments can be paused")
        exp["state"] = "paused"
        saved = self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("ExperimentPaused", {"experiment_id": exp["experiment_id"]}, ctx, experiment_id=exp["experiment_id"])
        return saved

    def resume_experiment(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "paused":
            raise LifecycleError("only paused experiments can resume")
        self._check_budget(experiment_id, exp)
        exp["state"] = "running"
        saved = self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("ExperimentResumed", {"experiment_id": exp["experiment_id"]}, ctx, experiment_id=exp["experiment_id"])
        return saved

    def abort_experiment(self, experiment_id: str, reason: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] == "completed":
            raise LifecycleError("completed experiment cannot be aborted")
        exp["state"] = "aborted"; exp["outcome"] = "aborted"; exp["abort_reason"] = str(reason); exp["closed_at"] = _now()
        saved = self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("ExperimentAborted", {"experiment_id": exp["experiment_id"], "reason": reason}, ctx, experiment_id=exp["experiment_id"])
        return saved

    def wait_experiment(self, experiment_id: str, timeout: float, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); deadline = self._clock() + float(timeout)
        while self._clock() < deadline:
            exp = self.get_experiment(experiment_id, context=ctx)
            if exp["state"] in {"completed", "aborted"}:
                return self._final_outcome(exp, ctx)
            time.sleep(0.001)
        raise LifecycleError("wait timeout")

    def _stage(self, exp: dict[str, Any], state: str, ctx: ExecutionContextView, *, outcome: str | None = None, event: str | None = None) -> dict[str, Any]:
        exp["state"] = state
        if outcome is not None:
            exp["outcome"] = outcome
        exp["experiment_version"] = int(exp["experiment_version"]) + 1
        saved = self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=exp["experiment_version"])
        if event:
            self._emit(event, {"experiment_id": exp["experiment_id"], "state": state, "outcome": outcome}, ctx, experiment_id=exp["experiment_id"])
        return saved

    # ---------- evaluation / adversarial / compare ----------
    def verify_isolation(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        self._verify_isolation(exp["conditions"]["isolation_guarantees"], ctx, experiment_id=experiment_id)
        self._store.put("isolation", experiment_id, ctx.tenant_id, self._signed({"experiment_id": experiment_id, "tenant_id": ctx.tenant_id, "verified": True, "verified_at": _now(), "guarantees": exp["conditions"]["isolation_guarantees"]}))
        self._emit("IsolationVerified", {"experiment_id": experiment_id, "guarantees": exp["conditions"]["isolation_guarantees"]}, ctx, experiment_id=experiment_id)
        return {"experiment_id": experiment_id, "verified": True}

    def simulate_experiment(self, experiment_id: str, simulation_result: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "running":
            raise LifecycleError("simulation requires a running experiment")
        self._check_budget(experiment_id, exp)
        sim = dict(simulation_result)
        if not bool(sim.get("passed", sim.get("ok", False))):
            self.abort_experiment(experiment_id, "simulation failed", context=ctx)
            raise LifecycleError("simulation failed")
        ref = str(sim.get("simulation_ref") or exp["conditions"].get("simulation_ref") or _uuid())
        body = {"report_id": _uuid(), "experiment_ref": experiment_id, "simulation_ref": ref, "tenant_id": ctx.tenant_id, "passed": True, "evidence_refs": list(map(str, sim.get("evidence_refs", []))), "result": sim, "computed_at": _now()}
        saved = self._save("simulation", body["report_id"], ctx.tenant_id, body)
        exp["simulation_report_ref"] = body["report_id"]
        self._save("experiment", experiment_id, ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("Simulated", {"experiment_id": experiment_id, "simulation_report_id": body["report_id"]}, ctx, experiment_id=experiment_id)
        return saved

    def evaluate_family(self, family_id: str, benchmark_suite_ref: str, profile_ref: str, evaluation_bundle: Mapping[str, Any] | None = None, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context)
        families = self._store.list("family", ctx.tenant_id)
        family = next((x for x in families if x.get("family_id") == str(family_id)), None)
        if family is None:
            raise ValidationError("family not found")
        exp_rows = self._store.list("experiment", ctx.tenant_id)
        exp = next((x for x in exp_rows if x.get("family", {}).get("family_id") == str(family_id)), None)
        if exp is None:
            raise ValidationError("experiment for family not found")
        if exp["state"] not in {"running", "evaluating"}:
            raise LifecycleError("experiment not ready for evaluation")
        if benchmark_suite_ref != exp["conditions"]["benchmark_suite_ref"]:
            raise FairnessError("benchmark suite diverges from pre-registered condition")
        self._check_budget(exp["experiment_id"], exp)
        if evaluation_bundle is None:
            if self.p2c is None or not hasattr(self.p2c, "evaluate_family"):
                raise LifecycleError("P2-C evaluation bundle unavailable; evaluation cannot silently continue")
            evaluation_bundle = self.p2c.evaluate_family(family, benchmark_suite_ref, profile_ref, exp["conditions"], context=ctx)
        bundle = copy.deepcopy(dict(evaluation_bundle))
        if set(map(str, bundle.get("candidate_results", {}).keys())) != set(map(str, family["candidates"])):
            raise FairnessError("evaluation bundle does not cover exactly the frozen family")
        conditions_hash = _sha(exp["conditions"])
        for candidate, result in bundle["candidate_results"].items():
            if str(result.get("baseline_ref", family["baseline_ref"])) != str(family["baseline_ref"]):
                raise FairnessError(f"candidate {candidate} evaluated against a different baseline")
            if "conditions_hash" in result:
                candidate_hash = str(result["conditions_hash"])
            elif "conditions" in result:
                candidate_hash = _sha(result["conditions"])
            else:
                raise FairnessError(f"candidate {candidate} did not declare evaluation conditions")
            if candidate_hash != conditions_hash:
                raise FairnessError(f"candidate {candidate} evaluated under non-identical conditions")
        bundle["conditions_hash"] = conditions_hash
        bundle["benchmark_suite_ref"] = benchmark_suite_ref
        bundle["profile_ref"] = profile_ref
        bundle["experiment_id"] = exp["experiment_id"]
        bundle["family_id"] = family_id
        bundle["tenant_id"] = ctx.tenant_id
        bundle["computed_at"] = _now()
        signed = self._save("evaluation", f"{exp['experiment_id']}:{family_id}", ctx.tenant_id, bundle)
        self._stage(exp, "evaluating", ctx, event="EvaluationStarted")
        self._emit("EvaluationCompleted", {"experiment_id": exp["experiment_id"], "family_id": family_id, "candidate_count": len(family["candidates"])}, ctx, experiment_id=exp["experiment_id"])
        return signed

    def run_adversarial_qualification(self, experiment_id: str, suite_ref: str, scope: str, adversarial_bundle: Mapping[str, Any] | None = None, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "evaluating":
            raise LifecycleError("adversarial qualification requires completed evaluation")
        self._check_budget(experiment_id, exp)
        if scope not in SCOPES:
            raise ValidationError("invalid adversarial_scope")
        if scope in {"mirrored_real_readonly", "forked_real"}:
            raise IsolationError("adversarial qualification must execute in P2-K or P2-E isolated scope")
        candidates = list(exp["family"]["candidates"])
        dangerous = False
        for candidate in candidates:
            if isinstance(candidate, Mapping):
                dangerous |= self._candidate_dangerous(candidate, self.p2g)
        if exp.get("adversarial_required") and not suite_ref:
            raise LifecycleError("dangerous family requires adversarial suite")
        self._emit("AdversarialQualificationStarted", {"experiment_id": experiment_id, "suite_ref": suite_ref}, ctx, experiment_id=experiment_id)
        if adversarial_bundle is None:
            if self.p2c is None or not hasattr(self.p2c, "run_adversarial_suite"):
                raise LifecycleError("P2-C adversarial suite unavailable")
            adversarial_bundle = self.p2c.run_adversarial_suite(candidates, suite_ref, scope, exp["conditions"], context=ctx)
        bundle = copy.deepcopy(dict(adversarial_bundle))
        bundle.update({"report_id": _uuid(), "experiment_ref": experiment_id, "adversarial_suite_ref": suite_ref, "adversarial_scope": scope, "tenant_id": ctx.tenant_id, "computed_at": _now(), "dangerous_family": dangerous})
        failures = [x for x in bundle.get("per_candidate", []) if not x.get("threshold_met", False)]
        bundle["family_outcome"] = "all_pass" if not failures else ("some_fail" if len(failures) < len(candidates) else "all_fail")
        bundle["qualified_candidates"] = [str(x.get("candidate_ref")) for x in bundle.get("per_candidate", []) if x.get("threshold_met", False)]
        bundle["disqualified_candidates"] = [str(x.get("candidate_ref")) for x in failures]
        saved = self._save("adversarial", bundle["report_id"], ctx.tenant_id, bundle)
        if failures:
            for failure in failures:
                if self.p2i is not None and hasattr(self.p2i, "ingest"):
                    try:
                        self.p2i.ingest({"category": "adversarial_failure", "experiment_id": experiment_id, "candidate_id": failure.get("candidate_ref"), "evidence_refs": failure.get("exploit_refs", [])}, getattr(self.p2e, "auth_context", None))
                    except Exception as error:
                        self.abort_experiment(experiment_id, "P2-I failure-evidence ingestion failed", context=ctx)
                        raise LifecycleError("P2-I failure-evidence ingestion failed") from error
            self._emit("AdversarialFailure", {"experiment_id": experiment_id, "failure_count": len(failures)}, ctx, experiment_id=experiment_id)
        self._emit("AdversarialQualificationCompleted", {"experiment_id": experiment_id, "family_outcome": bundle.get("family_outcome")}, ctx, experiment_id=experiment_id)
        return saved

    # ---------- statistics ----------
    @staticmethod
    def _validate_statistical_config(config: Mapping[str, Any], *, candidates_count: int, pre_registration: bool) -> None:
        required = ("sample_size", "sample_size_rule", "significance_threshold", "multiple_comparison_correction", "confidence_interval_level", "paired", "stopping_rule", "seed", "method_version")
        for key in required:
            if key not in config:
                raise StatisticalConfigError(f"statistical_config missing {key}")
        if int(config["sample_size"]) <= 0:
            raise StatisticalConfigError("sample_size must be positive")
        if config["sample_size_rule"] not in {"fixed", "power_analysis", "adaptive"}:
            raise StatisticalConfigError("invalid sample_size_rule")
        _finite(config["significance_threshold"], "significance_threshold", 0.0, 1.0)
        _finite(config["confidence_interval_level"], "confidence_interval_level", 0.0, 1.0)
        if config["multiple_comparison_correction"] not in MULTIPLE_CORRECTION:
            raise StatisticalConfigError("invalid multiple_comparison_correction")
        if candidates_count > 2 and config["multiple_comparison_correction"] == "none":
            raise StatisticalConfigError("multiple-comparison correction mandatory for >2 candidates")
        if config["stopping_rule"] not in STOPPING_RULES:
            raise StatisticalConfigError("invalid stopping_rule")
        if config["stopping_rule"] != "fixed_n" and not config.get("sequential_method_version"):
            raise StatisticalConfigError("sequential/adaptive stopping requires declared method version")
        if config["sample_size_rule"] == "power_analysis":
            _finite(config.get("power_target"), "power_target", 0.5, 0.999)
            _finite(config.get("effect_size_min"), "effect_size_min", 1e-12)
        if pre_registration and config.get("locked", False):
            raise StatisticalConfigError("statistical config already locked")

    def compare_family(self, family_id: str, statistical_config: Mapping[str, Any] | None = None, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); family_rows = self._store.list("family", ctx.tenant_id)
        family = next((x for x in family_rows if x.get("family_id") == str(family_id)), None)
        if family is None:
            raise ValidationError("family not found")
        exp_rows = self._store.list("experiment", ctx.tenant_id)
        exp = next((x for x in exp_rows if x.get("family", {}).get("family_id") == str(family_id)), None)
        if exp is None:
            raise ValidationError("experiment not found")
        self._check_budget(exp["experiment_id"], exp)
        if exp.get("dangerous_family") and not exp.get("simulation_report_ref"):
            raise LifecycleError("dangerous family cannot be compared before simulation")
        config = copy.deepcopy(statistical_config or exp["statistical_config"])
        frozen = dict(exp["statistical_config"])
        if _sha(config) != _sha(frozen):
            raise StatisticalConfigError("post-registration statistical config change requires a new experiment")
        self._validate_statistical_config(config, candidates_count=len(family["candidates"]), pre_registration=False)
        evaluation = self._store.get("evaluation", f"{exp['experiment_id']}:{family_id}", ctx.tenant_id)
        if evaluation is None:
            raise LifecycleError("evaluation report missing")
        metric = exp["primary_metric"]
        candidate_results = []
        baseline = evaluation.get("baseline", {}).get(metric)
        if baseline is None:
            baseline = evaluation.get("baseline_samples", evaluation.get("baseline", {}).get("samples"))
        if baseline is None:
            raise StatisticalConfigError("baseline samples missing for comparison")
        baseline = [float(x) for x in baseline]
        raw_results = evaluation["candidate_results"]
        pvalues = []
        for candidate in family["candidates"]:
            result = raw_results[str(candidate)]
            samples = result.get(metric, result.get("samples"))
            if samples is None:
                raise StatisticalConfigError(f"candidate {candidate} has no metric samples")
            samples = [float(x) for x in samples]
            if len(samples) < int(config["sample_size"]):
                candidate_warning = ["underpowered"]
            else:
                candidate_warning = []
            if config["paired"]:
                n = min(len(samples), len(baseline))
                diffs = [samples[i] - baseline[i] for i in range(n)]
            else:
                mean_b = statistics.fmean(baseline)
                diffs = [x - mean_b for x in samples]
            effect = _cohen_d(diffs)
            p = _permutation_pvalue(diffs, int(config["seed"]))
            ci = _bootstrap_ci(diffs, float(config["confidence_interval_level"]), int(config.get("bootstrap_iterations") or self.config.bootstrap_default_iterations), int(config["seed"])) if len(diffs) > 1 else (diffs[0], diffs[0])
            corrected = p
            candidate_results.append({"candidate_ref": candidate, "sample_count": len(samples), "metric_summary": {"mean": statistics.fmean(samples), "min": min(samples), "max": max(samples)}, "confidence_interval": [ci[0], ci[1]], "effect_size_vs_baseline": effect, "significance_vs_baseline": p, "corrected_significance": corrected, "direction": "unchanged", "notes": candidate_warning or None})
            pvalues.append(p)
        correction = config["multiple_comparison_correction"]
        if correction == "bonferroni":
            m = max(1, len(pvalues)); corrected = [min(1.0, p * m) for p in pvalues]
        elif correction == "holm":
            order = sorted(range(len(pvalues)), key=lambda i: pvalues[i]); corrected = [0.0] * len(pvalues)
            m = len(pvalues)
            for rank, i in enumerate(order): corrected[i] = min(1.0, pvalues[i] * (m - rank))
            for idx in range(1, len(order)): corrected[order[idx]] = max(corrected[order[idx]], corrected[order[idx - 1]])
        elif correction == "fdr":
            order = sorted(range(len(pvalues)), key=lambda i: pvalues[i]); corrected = [0.0] * len(pvalues); m = len(pvalues)
            prev = 1.0
            for rank in range(m - 1, -1, -1):
                i = order[rank]; val = min(prev, pvalues[i] * m / (rank + 1)); corrected[i] = val; prev = val
        else:
            corrected = pvalues
        higher_better = str(exp.get("direction", "higher_is_better")) == "higher_is_better"
        base_mean = statistics.fmean(baseline)
        for idx, row in enumerate(candidate_results):
            raw_delta = row["metric_summary"]["mean"] - base_mean
            if not higher_better: raw_delta *= -1
            row["direction"] = "improved" if raw_delta > 0 else "regressed" if raw_delta < 0 else "unchanged"
            row["corrected_significance"] = corrected[idx]
        ranking = [r["candidate_ref"] for r in sorted(candidate_results, key=lambda r: (-(r["effect_size_vs_baseline"] if higher_better else -r["effect_size_vs_baseline"]), r["corrected_significance"], r["candidate_ref"]))]
        warnings = []
        if any("underpowered" in (r.get("notes") or []) for r in candidate_results): warnings.append("underpowered")
        report = {
            "report_id": _uuid(), "experiment_ref": exp["experiment_id"], "family_ref": family_id, "comparison_metric": metric,
            "baseline_ref": family["baseline_ref"], "candidate_results": candidate_results, "ranking": ranking,
            "ranking_rule": "primary_metric", "hypothesis_supported": any(r["direction"] == "improved" and r["corrected_significance"] < float(config["significance_threshold"]) for r in candidate_results),
            "hypothesis_contradicted": any(r["direction"] == "regressed" and r["corrected_significance"] < float(config["significance_threshold"]) for r in candidate_results),
            "falsification_ref": None, "warnings": warnings, "computed_at": _now(),
            "computed_by": {"principal": ctx.principal, "key_id": self.config.signer_key_id}, "method_version": str(config["method_version"]),
        }
        report["ranking_signature"] = self.signer.sign(canonical_bytes({"ranking": report["ranking"], "ranking_rule": report["ranking_rule"]})).hex()
        signed = self._save("comparison", report["report_id"], ctx.tenant_id, report)
        exp["comparison_report_ref"] = report["report_id"]
        self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("ComparisonCompleted", {"experiment_id": exp["experiment_id"], "report_id": report["report_id"], "warning_count": len(warnings)}, ctx, experiment_id=exp["experiment_id"])
        if warnings:
            self._emit("ComparisonWarning", {"experiment_id": exp["experiment_id"], "warnings": warnings}, ctx, experiment_id=exp["experiment_id"])
        return signed

    # ---------- selection / handoff ----------
    def select_winner(self, experiment_id: str, selection_policy_ref: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "evaluating":
            raise LifecycleError("selection requires comparison-ready evaluating state")
        self._check_budget(experiment_id, exp)
        comparison_ref = exp.get("comparison_report_ref")
        if not comparison_ref:
            raise LifecycleError("comparison report missing")
        report = self._get("comparison", comparison_ref, ctx)
        if any("underpowered" in (r.get("notes") or []) for r in report["candidate_results"]):
            raise StatisticalConfigError("underpowered comparison cannot assert a winner")
        policy_rows = self._store.list("selection_policy", ctx.tenant_id)
        policy = next((p for p in policy_rows if p.get("policy_id") == str(selection_policy_ref)), None) or {}
        alpha = float(policy.get("maximum_p_value", exp["statistical_config"]["significance_threshold"]))
        min_effect = float(policy.get("minimum_effect_size", 0.0))
        eligible = [r for r in report["candidate_results"] if r["corrected_significance"] < alpha and r["direction"] == "improved" and float(r["effect_size_vs_baseline"]) >= min_effect]
        if not eligible:
            outcome = "no_winner"
            winners: list[str] = []
        else:
            # Selection is deterministic and policy-bound: rank by signed primary evidence, preserving exact ties when permitted.
            top_effect = max(r["effect_size_vs_baseline"] for r in eligible)
            tied = sorted(r["candidate_ref"] for r in eligible if math.isclose(r["effect_size_vs_baseline"], top_effect, rel_tol=1e-12, abs_tol=1e-12))
            allow_multiple = bool(policy.get("allow_multiple_winners", True))
            winners = tied if allow_multiple else tied[:1]
            outcome = "winner_selected" if len(winners) == 1 else "multiple_winners"
        losers = sorted(c for c in exp["family"]["candidates"] if c not in winners)
        adversarial_ref = None
        adversarial_reports = self._store.list("adversarial", ctx.tenant_id)
        for row in adversarial_reports:
            if row.get("experiment_ref") == experiment_id: adversarial_ref = row["report_id"]; break
        if exp.get("adversarial_required") and adversarial_ref is None:
            raise LifecycleError("mandatory adversarial report missing")
        if adversarial_ref:
            adv = self._get("adversarial", adversarial_ref, ctx)
            disqualified = set(map(str, adv.get("disqualified_candidates", [])))
            winners = [w for w in winners if w not in disqualified]
            if not winners: outcome = "no_winner"
        security_reports: list[str] = []
        verification_reports: list[str] = []
        for winner in list(winners):
            artifact = {"artifact_id": str(winner), "artifact_ref": str(winner), "experiment_id": experiment_id, "tenant_id": ctx.tenant_id, "candidate_ref": str(winner)}
            if self.p2s is not None and hasattr(self.p2s, "attest"):
                try:
                    sec = self.p2s.attest(artifact, context={"tenant_id": ctx.tenant_id, "principal": ctx.principal}, checks={"p2v": {"passed": True}})
                    if isinstance(sec, Mapping):
                        security_reports.append(str(sec.get("attestation_id") or sec.get("report_id") or _sha(sec)))
                except Exception:
                    winners = [w for w in winners if w != winner]
                    outcome = "security_failure"
                    continue
            if self.p2n is not None and hasattr(self.p2n, "request_verification"):
                try:
                    spec = {"tenant_id": ctx.tenant_id, "target": "result_integrity", "method": "statistical_analysis", "subject_agent_ref": str(winner), "claim": {"claim_kind": "experiment_winner", "claim_body_ref": f"p2v:{experiment_id}:{winner}", "claim_evidence_refs": [comparison_ref]}, "policy_ref": exp["conditions"].get("policy_version", "1.0.0"), "policy_version": exp["conditions"].get("policy_version", "1.0.0"), "registry_state_ref": exp["conditions"].get("registry_state_ref", "registry:live"), "requested_by": {"principal": ctx.principal, "key_id": self.config.signer_key_id}}
                    vr = self.p2n.request_verification(spec)
                    verification_reports.append(str(vr))
                except Exception:
                    winners = [w for w in winners if w != winner]
                    outcome = "verification_failure"
        losers = sorted(c for c in exp["family"]["candidates"] if c not in winners)
        if not winners and outcome in {"security_failure", "verification_failure"}:
            outcome = "no_winner"
        ready = bool(winners) and all(not self._candidate_dangerous({"candidate_id": w}, self.p2g) or adversarial_ref is not None for w in winners)
        decision = {
            "decision_id": _uuid(), "experiment_ref": experiment_id, "comparison_report_ref": comparison_ref,
            "adversarial_report_ref": adversarial_ref, "security_reports": security_reports, "verification_reports": verification_reports, "outcome": outcome,
            "winners": winners, "losers": losers, "tie_break_rule": None, "rationale": {"policy": selection_policy_ref, "eligible": [r["candidate_ref"] for r in eligible], "selection": "max_effect_with_significance"},
            "winners_ready_for_handoff": ready, "handoff_requirements": ["P2-G proposal ingestion", "P2-G mandatory gates", "P2-B certification downstream", "P2-D deployment downstream"],
            "decided_by": {"principal": ctx.principal, "key_id": self.config.signer_key_id}, "decided_by_kind": "operator", "selection_policy_ref": selection_policy_ref, "decided_at": _now(),
        }
        signed = self._save("selection", decision["decision_id"], ctx.tenant_id, decision)
        exp["selection_decision_ref"] = decision["decision_id"]
        exp["outcome"] = outcome
        exp["state"] = "deciding"
        self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("SelectionDecided" if winners else "NoWinner", {"experiment_id": experiment_id, "decision_id": decision["decision_id"], "outcome": outcome, "winners": winners}, ctx, experiment_id=experiment_id)
        return signed

    def handoff_winners(self, selection_decision_id: str, *, context: Any) -> list[dict[str, Any]]:
        ctx = self._ctx(context); decision = self._get("selection", selection_decision_id, ctx)
        if not decision["winners_ready_for_handoff"]:
            raise HandoffDenied("selection decision is not ready for P2-G handoff")
        if self.p2g is None or not hasattr(self.p2g, "propose_candidate"):
            raise HandoffDenied("P2-G proposal interface unavailable")
        receipts = []
        exp = self.get_experiment(decision["experiment_ref"], context=ctx)
        if exp["state"] != "deciding":
            raise LifecycleError("handoff requires a deciding experiment")
        for winner in decision["winners"]:
            metadata = dict(exp["family"].get("candidate_metadata", {}).get(str(winner), {}))
            if not metadata.get("candidate_class") or not metadata.get("origin_method") or not metadata.get("trigger"):
                raise HandoffDenied("candidate metadata required for faithful P2-G handoff")
            candidate = {"candidate_id": winner, "candidate_class": metadata["candidate_class"], "origin_method": metadata["origin_method"], "trigger": metadata["trigger"], "artifact": metadata.get("artifact", {"experiment_id": exp["experiment_id"], "candidate_ref": winner}), "evidence_refs": sorted(set([f"p2v:comparison:{decision['comparison_report_ref']}"] + list(map(str, metadata.get("evidence_refs", [])))))}
            try:
                result = self.p2g.propose_candidate(candidate, tenant_id=ctx.tenant_id, seed=int(exp["conditions"]["seed"]))
            except TypeError:
                result = self.p2g.propose_candidate(candidate, tenant_id=ctx.tenant_id)
            receipts.append({"candidate_ref": winner, "p2g_receipt": result, "handoff_path": "P2-V -> P2-G -> P2-B -> P2-D"})
        exp["state"] = "completed"; exp["outcome"] = "winner_selected" if len(receipts) == 1 else "multiple_winners"; exp["closed_at"] = _now()
        self._save("experiment", exp["experiment_id"], ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("HandoffToLearningPipeline", {"experiment_id": exp["experiment_id"], "selection_decision_id": selection_decision_id, "count": len(receipts)}, ctx, experiment_id=exp["experiment_id"])
        self._emit("ExperimentCompleted", {"experiment_id": exp["experiment_id"], "outcome": exp["outcome"]}, ctx, experiment_id=exp["experiment_id"])
        return receipts

    # ---------- search ----------
    @staticmethod
    def _validate_search_space(search_space: Mapping[str, Any]) -> dict[str, list[Any]]:
        if not isinstance(search_space, Mapping) or not search_space:
            raise SearchError("search_space must be a non-empty typed mapping")
        result: dict[str, list[Any]] = {}
        for key, spec in sorted(search_space.items()):
            if isinstance(spec, Mapping):
                if "values" not in spec or not isinstance(spec["values"], Sequence) or isinstance(spec["values"], (str, bytes)):
                    raise SearchError(f"search dimension {key} must provide a typed values list")
                values = list(spec["values"])
            elif isinstance(spec, Sequence) and not isinstance(spec, (str, bytes)):
                values = list(spec)
            else:
                raise SearchError(f"search dimension {key} is untyped")
            if not values:
                raise SearchError(f"search dimension {key} has no values")
            result[str(key)] = values
        return result

    @staticmethod
    def _grid_points(space: Mapping[str, Sequence[Any]]) -> list[dict[str, Any]]:
        keys = sorted(space)
        return [dict(zip(keys, values)) for values in itertools.product(*(space[k] for k in keys))]

    def _search_candidates(self, strategy: str, space: dict[str, list[Any]], *, seed: int, budget: int, scorer: Callable[[Mapping[str, Any]], float] | None) -> list[dict[str, Any]]:
        all_points = self._grid_points(space)
        if not all_points:
            return []
        rng = random.Random(seed)
        if strategy == "grid_search":
            points = all_points[:budget]
        elif strategy == "random_search":
            rng.shuffle(all_points); points = all_points[:budget]
        elif strategy == "bayesian_optimization":
            points = [all_points[0]]
            remaining = all_points[1:]
            scores: list[tuple[float, dict[str, Any]]] = []
            while remaining and len(points) < budget:
                if scorer is None:
                    nxt = remaining.pop(0)
                else:
                    scored = [(float(scorer(p)), p) for p in remaining]
                    scored.sort(key=lambda x: (-x[0], canonical_bytes(x[1])))
                    nxt = scored[0][1]
                    remaining.remove(nxt)
                points.append(nxt)
            return points
        elif strategy == "evolutionary":
            population = all_points[: min(len(all_points), max(2, budget))]
            if scorer:
                population.sort(key=lambda p: (-float(scorer(p)), canonical_bytes(p)))
            points = population[:budget]
        elif strategy in {"successive_halving", "hyperband"}:
            pool = all_points[:]
            points = []
            stage = max(1, budget)
            while pool and len(points) < budget:
                if scorer:
                    pool.sort(key=lambda p: (-float(scorer(p)), canonical_bytes(p)))
                take = min(len(pool), max(1, stage))
                points.extend(pool[:take]); pool = pool[: max(1, len(pool) // 2)]
                stage = max(1, stage // 2)
        elif strategy == "custom":
            points = all_points[:budget]
        else:
            raise SearchError("unknown strategy")
        return points[:budget]

    def run_search(self, experiment_id: str, strategy_ref: str, search_space: Mapping[str, Any], *, context: Any, scorer: Callable[[Mapping[str, Any]], float] | None = None, budget_candidates: int | None = None) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        if exp["state"] != "running":
            raise LifecycleError("search requires a running experiment before evaluation")
        self._check_budget(experiment_id, exp)
        strategy_ref_text = str(strategy_ref)
        strategy = next((candidate for candidate in SEARCH_STRATEGIES if strategy_ref_text.endswith(candidate)), "")
        if not strategy:
            raise SearchError("unknown search strategy")
        space = self._validate_search_space(search_space)
        max_candidates = int(budget_candidates or exp["budget"]["max_parallelism"] * 8)
        max_candidates = min(max_candidates, int(exp["family"].get("max_candidates", self.config.max_family_size)), self.config.max_family_size)
        self._emit("SearchStarted", {"experiment_id": experiment_id, "strategy": strategy}, ctx, experiment_id=experiment_id)
        points = self._search_candidates(strategy, space, seed=int(exp["conditions"]["seed"]), budget=max_candidates, scorer=scorer)
        if len(points) > max_candidates:
            raise SearchError("search exceeded budget")
        result = {
            "search_result_id": _uuid(), "experiment_ref": experiment_id, "strategy_ref": strategy_ref, "strategy": strategy,
            "search_space": space, "seed": int(exp["conditions"]["seed"]), "budget": {"max_candidates": max_candidates},
            "candidates": points, "completed": True, "budget_exceeded": False, "computed_at": _now(), "tenant_id": ctx.tenant_id,
        }
        signed = self._save("search", result["search_result_id"], ctx.tenant_id, result)
        self._emit("SearchCompleted", {"experiment_id": experiment_id, "search_result_id": result["search_result_id"], "candidate_count": len(points)}, ctx, experiment_id=experiment_id)
        return signed

    def get_search_result(self, search_result_id: str, *, context: Any) -> dict[str, Any]:
        return self._get("search", str(search_result_id), self._ctx(context))

    # ---------- explanation / lineage / policies ----------
    def explain(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        hypothesis = self.get_hypothesis(exp["hypothesis_ref"], context=ctx)
        return {"experiment": exp, "hypothesis": hypothesis, "comparison": self._store.get("comparison", exp.get("comparison_report_ref", ""), ctx.tenant_id) if exp.get("comparison_report_ref") else None, "selection": self._store.get("selection", exp.get("selection_decision_ref", ""), ctx.tenant_id) if exp.get("selection_decision_ref") else None}

    def lineage(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        chain = self._store.chain(ctx.tenant_id)
        return {"experiment_id": experiment_id, "hypothesis_id": exp["hypothesis_ref"], "chain": chain, "family_id": exp["family"]["family_id"], "candidates": exp["family"]["candidates"]}

    def history(self, hypothesis_id: str, *, context: Any) -> list[str]:
        ctx = self._ctx(context)
        return [x["experiment_id"] for x in self._store.list("experiment", ctx.tenant_id) if x.get("hypothesis_ref") == str(hypothesis_id)]

    def register_selection_policy(self, policy: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context); p = dict(policy); pid = str(p.get("policy_id") or f"p2v.policy.{_sha(p)[:16]}")
        p.update({"policy_id": pid, "tenant_id": ctx.tenant_id, "registered_at": _now()})
        self._save("selection_policy", pid, ctx.tenant_id, p)
        return pid

    def register_search_strategy(self, strategy: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context); p = dict(strategy); sid = str(p.get("strategy_id") or f"p2v.strategy.{_sha(p)[:16]}")
        if p.get("strategy") not in SEARCH_STRATEGIES:
            raise SearchError("invalid strategy")
        p.update({"strategy_id": sid, "tenant_id": ctx.tenant_id, "registered_at": _now()})
        self._save("search_strategy", sid, ctx.tenant_id, p)
        return sid

    def register_statistical_config(self, config: Mapping[str, Any], *, context: Any) -> str:
        ctx = self._ctx(context); c = dict(config); self._validate_statistical_config(c, candidates_count=int(c.get("candidate_count", 2)), pre_registration=True)
        cid = str(c.get("config_id") or f"p2v.stats.{_sha(c)[:16]}"); c.update({"config_id": cid, "tenant_id": ctx.tenant_id, "registered_at": _now(), "locked": True})
        self._save("statistical_config", cid, ctx.tenant_id, c)
        return cid

    def record_outcome(self, experiment_id: str, *, context: Any, outcome_class: str | None = None, winner_refs: Sequence[str] = (), loser_refs: Sequence[str] = (), handoff_refs: Sequence[str] = (), failures: Sequence[str] = ()) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        outcome_value = str(outcome_class or exp.get("outcome") or "inconclusive")
        if outcome_value not in OUTCOMES:
            raise ValidationError("invalid experiment outcome")
        body = {"outcome_id": _uuid(), "experiment_ref": experiment_id, "outcome_class": outcome_value, "summary": f"Experiment {experiment_id} outcome {outcome_value}", "winner_refs": list(map(str, winner_refs)), "loser_refs": list(map(str, loser_refs)), "handoff_refs": list(map(str, handoff_refs)), "falsification_outcome": None, "failures": list(map(str, failures)), "memories_written": [], "closed_at": _now()}
        saved = self._save("outcome", body["outcome_id"], ctx.tenant_id, body)
        if exp["state"] != "aborted":
            exp["state"] = "completed"
            exp["outcome"] = outcome_value
            exp["closed_at"] = body["closed_at"]
            self._save("experiment", experiment_id, ctx.tenant_id, {k: v for k, v in exp.items() if k not in {"signature", "integrity_hash", "writer_key_id"}}, version=int(exp["experiment_version"]) + 1)
        self._emit("OutcomeRecorded", {"experiment_id": experiment_id, "outcome_id": body["outcome_id"], "outcome": outcome_value}, ctx, experiment_id=experiment_id)
        self._emit("ExperimentCompleted", {"experiment_id": experiment_id, "outcome": outcome_value}, ctx, experiment_id=experiment_id)
        return saved

    def write_experience_proposal(self, experiment_id: str, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        outcome = exp.get("outcome") or "inconclusive"
        body = {"proposal_id": _uuid(), "experiment_ref": experiment_id, "tenant_id": ctx.tenant_id, "kind": "p2v.experiment_outcome", "summary": f"Experiment {experiment_id} outcome {outcome}", "evidence_refs": [f"p2v:experiment:{experiment_id}"], "proposed_at": _now()}
        if self.p2h is not None and hasattr(self.p2h, "put"):
            try:
                ref = self.p2h.put(ctx.tenant_id, {"memory_type": "experience_proposal", **body})
            except Exception:
                ref = None
        else:
            ref = None
        body["memory_ref"] = ref
        saved = self._save("outcome", body["proposal_id"], ctx.tenant_id, body)
        self._emit("OutcomeRecorded", {"experiment_id": experiment_id, "outcome_id": body["proposal_id"]}, ctx, experiment_id=experiment_id)
        return saved

    def _final_outcome(self, exp: Mapping[str, Any], ctx: ExecutionContextView) -> dict[str, Any]:
        body = {"outcome_id": _uuid(), "experiment_ref": exp["experiment_id"], "outcome_class": exp.get("outcome") or "inconclusive", "summary": f"Experiment {exp['experiment_id']} closed", "winner_refs": [], "loser_refs": exp.get("family", {}).get("candidates", []), "handoff_refs": [], "falsification_outcome": None, "failures": [], "memories_written": [], "closed_at": exp.get("closed_at") or _now()}
        return self._save("outcome", body["outcome_id"], ctx.tenant_id, body)

    def verify_chain(self, *, context: Any) -> bool:
        ctx = self._ctx(context)
        chain = self._store.chain(ctx.tenant_id)
        previous = ""
        for row in chain:
            if row["prev_hash"] != previous:
                return False
            previous = row["body_hash"]
        return True

    def verify_artifact(self, kind: str, ident: str, *, context: Any) -> bool:
        ctx = self._ctx(context)
        row = self._get(kind, ident, ctx)
        return verify_signed_document(row, self.public_key)

    def replay(self, experiment_id: str, events: Sequence[Mapping[str, Any]], *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context); exp = self.get_experiment(experiment_id, context=ctx)
        expected = ["ExperimentPrepared", "FamilyComposed", "IsolationVerified", "FamilyFrozen", "ExperimentStarted"]
        names = [str(e.get("event_name") or e.get("type") or "") for e in events if str(e.get("experiment_id")) == str(experiment_id)]
        if not names:
            raise LifecycleError("no replay events for experiment")
        # Preserve relative order while allowing optional evaluation/adversarial/search events.
        pos = 0
        for name in names:
            if pos < len(expected) and name == expected[pos]:
                pos += 1
        if pos < 3:
            self._emit("ReplayDivergence", {"experiment_id": experiment_id, "expected": expected, "observed": names}, ctx, experiment_id=experiment_id)
            raise LifecycleError("experiment replay divergence")
        return {"experiment_id": experiment_id, "replayable": True, "observed_events": names, "state": exp["state"], "outcome": exp.get("outcome")}

    def stats(self, *, context: Any) -> dict[str, Any]:
        ctx = self._ctx(context)
        return {"tenant_id": ctx.tenant_id, "version": PUBLIC_VERSION, "kernel": KERNEL_VERSION, "p2v_version": P2V_VERSION, "hypotheses": len(self._store.list("hypothesis", ctx.tenant_id)), "experiments": len(self._store.list("experiment", ctx.tenant_id)), "comparisons": len(self._store.list("comparison", ctx.tenant_id)), "selections": len(self._store.list("selection", ctx.tenant_id)), "searches": len(self._store.list("search", ctx.tenant_id))}

    def close(self) -> None:
        self._store.close()


__all__ = [
    "EvolutionLab", "ExperimentConfig", "ExecutionContextView", "power_sample_size", "verify_signed_document",
    "EvolutionLabError", "ExecutionContextRequired", "TenantIsolationError", "ValidationError", "SignatureError",
    "IsolationError", "FairnessError", "StatisticalConfigError", "LifecycleError", "HandoffDenied", "SearchError",
    "HYPOTHESIS_CLASSES", "EXPERIMENT_KINDS", "SCOPES", "METRICS", "OUTCOMES", "SEARCH_STRATEGIES",
]

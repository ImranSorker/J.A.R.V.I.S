"""Advanced platform primitives for J.A.R.V.I.S. V12.8.0.

The module provides target-independent building blocks for profiling, platform
attestation evidence, encrypted state synchronization, migration envelopes,
model prefix caching, capability-policy verification, hardware abstraction,
and supervised native runtime health. Privileged or vendor-specific behavior is
injected explicitly rather than emulated or silently trusted.
"""
from __future__ import annotations

import base64
import cProfile
import hashlib
import hmac
import io
import json
import os
import platform
try:
    import resource  # type: ignore
except ImportError:  # pragma: no cover - exercised on Windows
    resource = None  # type: ignore
import sqlite3
import statistics
import subprocess
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


@dataclass(frozen=True, slots=True)
class ProfileSnapshot:
    """Aggregated profiling result for one bounded operation."""

    profile_id: str
    operation: str
    wall_ms: float
    cpu_ms: float
    peak_rss_mb: float
    function_count: int
    top_functions: tuple[tuple[str, float], ...]


class LocalProfiler:
    """Low-overhead synchronous profiler with deterministic bounded output."""

    @staticmethod
    def _rss() -> float:
        """Return process peak RSS in a platform-independent native unit."""
        if resource is not None:
            return float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        try:
            import psutil
            return float(psutil.Process().memory_info().rss)
        except Exception:
            return 0.0

    def profile(self, operation: str, callback: Callable[[], Any], *, top_n: int = 10) -> tuple[Any, ProfileSnapshot]:
        """Profile ``callback`` and return both its result and a compact snapshot."""
        title = str(operation).strip()
        if not title:
            raise ValueError("operation is required")
        limit = max(1, min(int(top_n), 50))
        before = self._rss()
        profiler = cProfile.Profile()
        started = time.perf_counter()
        profiler.enable()
        try:
            result = callback()
        finally:
            profiler.disable()
        wall_ms = (time.perf_counter() - started) * 1000.0
        after = self._rss()
        stats_stream = io.StringIO()
        import pstats
        stats = pstats.Stats(profiler, stream=stats_stream).strip_dirs().sort_stats("cumulative")
        function_stats = list(stats.stats.items())
        top = []
        for (filename, line, name), values in sorted(function_stats, key=lambda item: item[1][3], reverse=True)[:limit]:
            top.append((f"{Path(filename).name}:{line}:{name}", round(float(values[3]) * 1000.0, 3)))
        # resource reports KiB on Unix; psutil fallback reports bytes on Windows.
        divisor = 1024.0 if resource is not None else (1024.0 * 1024.0)
        rss_mb = max(float(before), float(after)) / divisor
        snapshot = ProfileSnapshot(uuid.uuid4().hex, title, max(0.0, wall_ms), max(0.0, statistics.fmean([wall_ms])), max(0.0, rss_mb), len(function_stats), tuple(top))
        return result, snapshot


@dataclass(frozen=True, slots=True)
class AttestationEvidence:
    """Non-privileged platform attestation evidence with explicit trust semantics."""

    platform: str
    provider: str
    available: bool
    trusted: bool
    evidence: Mapping[str, str]
    collected_at: float
    reason: str


class PlatformAttestor:
    """Collect platform trust evidence without launching privileged processes."""

    def collect(self) -> AttestationEvidence:
        """Collect non-privileged TPM/device-presence evidence where exposed by the OS."""
        system = platform.system()
        evidence: dict[str, str] = {"machine": platform.machine(), "release": platform.release()}
        provider = "platform-presence"
        available = False
        reason = "hardware-backed cryptographic attestation provider unavailable"
        try:
            if system == "Linux":
                tpm_paths = (Path("/sys/class/tpm/tpm0/tpm_version_major"), Path("/dev/tpmrm0"), Path("/dev/tpm0"))
                available = any(path.exists() for path in tpm_paths)
                evidence["tpm_detected"] = str(available).lower()
                reason = "TPM device presence queried; cryptographic quote verification requires a platform provider"
            elif system == "Windows":
                import winreg

                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services\TPM", 0, winreg.KEY_READ)
                try:
                    evidence["windows_tpm_service"] = "present"
                    available = True
                finally:
                    winreg.CloseKey(key)
                reason = "Windows TPM service presence queried; cryptographic quote verification requires a platform provider"
            elif system == "Darwin":
                evidence["secure_enclave"] = "unknown"
                reason = "Apple hardware-backed attestation requires a platform provider"
            else:
                evidence["tpm_detected"] = "unknown"
        except (OSError, ImportError, PermissionError):
            evidence["tpm_detected"] = "unavailable"
        return AttestationEvidence(system, provider, available, False, evidence, time.time(), reason)


@dataclass(frozen=True, slots=True)
class SyncRecord:
    """Versioned, encrypted record for offline synchronization."""

    record_id: str
    namespace: str
    payload: Mapping[str, Any]
    version: int
    writer: str
    updated_at: float
    vector: Mapping[str, int]


class EncryptedStateSync:
    """AES-GCM encrypted offline-first state store with deterministic merges."""

    def __init__(self, path: str | Path, key: bytes, *, node_id: str | None = None) -> None:
        raw = bytes(key)
        if len(raw) not in {16, 24, 32}:
            raise ValueError("AES key must be 16, 24, or 32 bytes")
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._key = raw
        self.node_id = str(node_id or uuid.uuid4().hex)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("CREATE TABLE IF NOT EXISTS records(record_id TEXT PRIMARY KEY, namespace TEXT NOT NULL, blob BLOB NOT NULL, updated_at REAL NOT NULL)")
        self._db.commit()

    @staticmethod
    def _canonical(record: SyncRecord) -> bytes:
        return json.dumps(asdict(record), sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")

    def put(self, namespace: str, record_id: str, payload: Mapping[str, Any], *, version: int | None = None) -> SyncRecord:
        """Write an encrypted record with a Lamport-style local version."""
        ns = str(namespace).strip()
        rid = str(record_id).strip()
        if not ns or not rid:
            raise ValueError("namespace and record_id are required")
        with self._lock:
            current = self.get(ns, rid)
            next_version = max(int(version or 0), (current.version + 1 if current else 1))
            vector = dict(current.vector) if current else {}
            vector[self.node_id] = int(vector.get(self.node_id, 0)) + 1
            record = SyncRecord(rid, ns, dict(payload), next_version, self.node_id, time.time(), vector)
            nonce = os.urandom(12)
            aad = f"{ns}:{rid}".encode("utf-8")
            blob = nonce + AESGCM(self._key).encrypt(nonce, self._canonical(record), aad)
            self._db.execute("INSERT INTO records(record_id,namespace,blob,updated_at) VALUES(?,?,?,?) ON CONFLICT(record_id) DO UPDATE SET namespace=excluded.namespace,blob=excluded.blob,updated_at=excluded.updated_at", (rid, ns, blob, record.updated_at))
            self._db.commit()
            return record

    def get(self, namespace: str, record_id: str) -> SyncRecord | None:
        """Decrypt and return one record."""
        ns = str(namespace).strip()
        rid = str(record_id).strip()
        with self._lock:
            row = self._db.execute("SELECT blob FROM records WHERE record_id=? AND namespace=?", (rid, ns)).fetchone()
        if row is None:
            return None
        blob = bytes(row[0])
        nonce, ciphertext = blob[:12], blob[12:]
        try:
            data = json.loads(AESGCM(self._key).decrypt(nonce, ciphertext, f"{ns}:{rid}".encode("utf-8")))
            return SyncRecord(str(data["record_id"]), str(data["namespace"]), dict(data["payload"]), int(data["version"]), str(data["writer"]), float(data["updated_at"]), {str(k): int(v) for k, v in dict(data["vector"]).items()})
        except Exception as exc:
            raise ValueError("encrypted state record integrity failure") from exc

    @staticmethod
    def merge(local: SyncRecord | None, remote: SyncRecord) -> SyncRecord:
        """Merge two versions using vector dominance, then deterministic tie-breaking."""
        if local is None:
            return remote
        local_vector, remote_vector = dict(local.vector), dict(remote.vector)
        local_ge = all(local_vector.get(node, 0) >= count for node, count in remote_vector.items())
        remote_ge = all(remote_vector.get(node, 0) >= count for node, count in local_vector.items())
        if remote_ge and not local_ge:
            return remote
        if local_ge and not remote_ge:
            return local
        return remote if (remote.version, remote.updated_at, remote.writer) > (local.version, local.updated_at, local.writer) else local

    def close(self) -> None:
        """Close the encrypted sync store."""
        with self._lock:
            self._db.commit()
            self._db.close()


class MissionMigrationCodec:
    """Encrypt and authenticate portable mission envelopes."""

    def __init__(self, key: bytes) -> None:
        raw = bytes(key)
        if len(raw) not in {16, 24, 32}:
            raise ValueError("AES key must be 16, 24, or 32 bytes")
        self._key = raw

    def encode(self, mission_id: str, checkpoint: Mapping[str, Any], *, destination: str) -> str:
        """Create an authenticated, destination-bound encrypted envelope."""
        mid = str(mission_id).strip()
        dst = str(destination).strip()
        if not mid or not dst:
            raise ValueError("mission_id and destination are required")
        envelope = {"mission_id": mid, "checkpoint": dict(checkpoint), "destination": dst, "issued_at": time.time(), "nonce": uuid.uuid4().hex}
        raw = json.dumps(envelope, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        nonce = os.urandom(12)
        ciphertext = AESGCM(self._key).encrypt(nonce, raw, dst.encode("utf-8"))
        return base64.urlsafe_b64encode(nonce + ciphertext).decode("ascii")

    def decode(self, token: str, *, destination: str) -> dict[str, Any]:
        """Decrypt and validate destination binding."""
        dst = str(destination).strip()
        try:
            blob = base64.urlsafe_b64decode(str(token).encode("ascii"))
            nonce, ciphertext = blob[:12], blob[12:]
            payload = json.loads(AESGCM(self._key).decrypt(nonce, ciphertext, dst.encode("utf-8")))
        except Exception as exc:
            raise ValueError("invalid mission migration envelope") from exc
        if payload.get("destination") != dst:
            raise ValueError("mission envelope destination mismatch")
        return dict(payload)


@dataclass(frozen=True, slots=True)
class PrefixCacheEntry:
    """Prefix-cache entry with bounded memory accounting."""

    key: str
    model: str
    token_count: int
    bytes_size: int
    created_at: float
    last_access: float
    digest: str


class PrefixCache:
    """Bounded model prefix cache with model affinity and byte-based eviction."""

    def __init__(self, *, max_entries: int = 128, max_bytes: int = 256 * 1024 * 1024) -> None:
        self.max_entries = max(1, min(int(max_entries), 10_000))
        self.max_bytes = max(1024, int(max_bytes))
        self._items: OrderedDict[str, tuple[PrefixCacheEntry, bytes]] = OrderedDict()
        self._bytes = 0
        self._lock = threading.RLock()

    @staticmethod
    def fingerprint(model: str, prefix: bytes) -> str:
        """Compute an integrity-addressed model/prefix fingerprint."""
        material = str(model).encode("utf-8") + b"\0" + bytes(prefix)
        return hashlib.sha256(material).hexdigest()

    def put(self, model: str, prefix: bytes, *, token_count: int) -> PrefixCacheEntry:
        """Insert a prefix and evict least-recently-used entries until bounded."""
        payload = bytes(prefix)
        if not payload:
            raise ValueError("prefix cannot be empty")
        key = self.fingerprint(model, payload)
        now = time.time()
        entry = PrefixCacheEntry(key, str(model).strip(), max(1, int(token_count)), len(payload), now, now, hashlib.sha256(payload).hexdigest())
        if entry.bytes_size > self.max_bytes:
            raise ValueError("prefix exceeds cache capacity")
        with self._lock:
            old = self._items.pop(key, None)
            if old:
                self._bytes -= old[0].bytes_size
            while self._items and (len(self._items) >= self.max_entries or self._bytes + entry.bytes_size > self.max_bytes):
                _, removed = self._items.popitem(last=False)
                self._bytes -= removed[0].bytes_size
            self._items[key] = (entry, payload)
            self._bytes += entry.bytes_size
            return entry

    def get(self, model: str, key: str) -> bytes | None:
        """Retrieve a cache entry only when its model affinity matches."""
        with self._lock:
            item = self._items.get(str(key))
            if item is None or item[0].model != str(model):
                return None
            entry, payload = item
            refreshed = PrefixCacheEntry(entry.key, entry.model, entry.token_count, entry.bytes_size, entry.created_at, time.time(), entry.digest)
            self._items[entry.key] = (refreshed, payload)
            self._items.move_to_end(entry.key)
            return bytes(payload)

    def snapshot(self) -> dict[str, int]:
        """Return cache usage."""
        with self._lock:
            return {"entries": len(self._items), "bytes": self._bytes, "max_entries": self.max_entries, "max_bytes": self.max_bytes}


@dataclass(frozen=True, slots=True)
class CapabilityInvariant:
    """Security invariant evaluated by the bounded policy verifier."""

    name: str
    forbidden_capabilities: tuple[str, ...] = ()
    required_capabilities: tuple[str, ...] = ()


class CapabilityPolicyVerifier:
    """Statically verify capability sets against explicit least-privilege invariants."""

    def verify(self, capabilities: Iterable[str], invariants: Sequence[CapabilityInvariant]) -> dict[str, Any]:
        """Return deterministic proof results for finite capability invariants."""
        caps = frozenset(str(item).strip() for item in capabilities if str(item).strip())
        failures: list[str] = []
        checked = 0
        for invariant in invariants:
            checked += 1
            forbidden = caps.intersection(invariant.forbidden_capabilities)
            missing = set(invariant.required_capabilities).difference(caps)
            if forbidden or missing:
                failures.append(f"{invariant.name}: forbidden={sorted(forbidden)} missing={sorted(missing)}")
        return {"ok": not failures, "checked": checked, "failures": failures, "capabilities": sorted(caps)}


@dataclass(frozen=True, slots=True)
class HardwareSnapshot:
    """Portable system resource snapshot used by schedulers."""

    platform: str
    architecture: str
    cpu_count: int
    memory_total_mb: int
    memory_available_mb: int
    load_percent: float
    gpu_hint: str


class HardwareAbstractionLayer:
    """Standard-library/psutil-friendly hardware abstraction with safe fallbacks."""

    def snapshot(self) -> HardwareSnapshot:
        """Collect CPU/memory data without requiring a vendor SDK."""
        try:
            import psutil
            memory = psutil.virtual_memory()
            load = float(psutil.cpu_percent(interval=None))
            cpu_count = int(psutil.cpu_count(logical=True) or 1)
            return HardwareSnapshot(platform.system(), platform.machine(), cpu_count, int(memory.total / 1048576), int(memory.available / 1048576), max(0.0, load), os.environ.get("JARVIS_GPU_HINT", "unknown"))
        except Exception:
            cpu_count = os.cpu_count() or 1
            return HardwareSnapshot(platform.system(), platform.machine(), cpu_count, 0, 0, 0.0, os.environ.get("JARVIS_GPU_HINT", "unknown"))


@dataclass(frozen=True, slots=True)
class RuntimeHealth:
    """Health result for a supervised native service."""

    name: str
    state: str
    consecutive_failures: int
    last_latency_ms: float
    checked_at: float
    detail: str


class NativeRuntimeSupervisor:
    """Circuit-break native runtime callbacks after repeated health failures."""

    def __init__(self, name: str, healthcheck: Callable[[], bool], *, failure_threshold: int = 3, cooldown_seconds: float = 30.0) -> None:
        self.name = str(name).strip()
        if not self.name:
            raise ValueError("name is required")
        self.healthcheck = healthcheck
        self.failure_threshold = max(1, min(int(failure_threshold), 100))
        self.cooldown_seconds = max(1.0, min(float(cooldown_seconds), 86_400.0))
        self._failures = 0
        self._opened_until = 0.0
        self._lock = threading.RLock()

    def probe(self) -> RuntimeHealth:
        """Run one bounded health probe with circuit-breaker semantics."""
        with self._lock:
            if time.time() < self._opened_until:
                return RuntimeHealth(self.name, "open", self._failures, 0.0, time.time(), "circuit breaker open")
        started = time.perf_counter()
        try:
            healthy = bool(self.healthcheck())
        except Exception as exc:
            healthy = False
            detail = f"healthcheck error: {type(exc).__name__}"
        else:
            detail = "healthy" if healthy else "healthcheck returned false"
        latency = (time.perf_counter() - started) * 1000.0
        with self._lock:
            if healthy:
                self._failures = 0
                self._opened_until = 0.0
                state = "healthy"
            else:
                self._failures += 1
                if self._failures >= self.failure_threshold:
                    self._opened_until = time.time() + self.cooldown_seconds
                    state = "open"
                else:
                    state = "degraded"
            return RuntimeHealth(self.name, state, self._failures, latency, time.time(), detail)



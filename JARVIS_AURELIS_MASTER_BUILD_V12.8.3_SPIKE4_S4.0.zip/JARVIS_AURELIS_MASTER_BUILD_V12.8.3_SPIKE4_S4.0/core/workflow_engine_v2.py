"""Async DAG workflow engine with retries, timeouts and durable results."""
from __future__ import annotations
import asyncio, json, logging, re, time, uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional
logger=logging.getLogger("jarvis.workflow.v2")
class WorkflowValidationError(Exception):
    """Raised when a workflow definition fails validation."""
@dataclass
class WorkflowStep:
    id:str; tool:str; arguments:Dict[str,Any]=field(default_factory=dict); depends_on:List[str]=field(default_factory=list); retries:int=0; timeout_seconds:float=30.0; on_failure:str="fail"
class WorkflowEngineV2:
    def __init__(self,tool_service:Any,persistence_dir:Optional[Path]=None):
        self.tool_service=tool_service; self._persistence_dir=persistence_dir or Path("./data/workflows"); self._persistence_dir.mkdir(parents=True,exist_ok=True); self._active_runs={}
    def validate(self,steps:List[WorkflowStep])->None:
        ids=[s.id for s in steps]
        if len(ids)!=len(set(ids)): raise WorkflowValidationError("Duplicate step id")
        mapping={s.id:s for s in steps}
        for s in steps:
            if s.retries<0 or s.timeout_seconds<=0 or s.on_failure not in {"fail","continue"}: raise WorkflowValidationError(f"Invalid policy for {s.id}")
            if any(d not in mapping for d in s.depends_on): raise WorkflowValidationError(f"Step {s.id} has unknown dependency")
        visiting=set(); visited=set()
        def dfs(n):
            if n in visiting: return True
            if n in visited: return False
            visiting.add(n)
            if any(dfs(d) for d in mapping[n].depends_on): return True
            visiting.remove(n); visited.add(n); return False
        if any(dfs(s.id) for s in steps): raise WorkflowValidationError("Cycle detected in workflow graph")
    def _resolve_arguments(self,args,results):
        pattern=re.compile(r"\{\{steps\.([^.}]+)(?:\.([^}]+))?\}\}")
        def resolve(v):
            if isinstance(v,dict): return {k:resolve(x) for k,x in v.items()}
            if isinstance(v,list): return [resolve(x) for x in v]
            if not isinstance(v,str): return v
            matches=list(pattern.finditer(v))
            if not matches:return v
            if len(matches)==1 and matches[0].group(0)==v:
                cur=results.get(matches[0].group(1)); path=matches[0].group(2)
                if path:
                    for part in path.split('.'):
                        cur=cur.get(part) if isinstance(cur,dict) else None
                return cur
            return pattern.sub(lambda m:str(resolve(m.group(0))),v)
        return resolve(args)
    async def run_workflow(self,steps,run_id=None):
        self.validate(steps); run_id=run_id or str(uuid.uuid4()); self._active_runs[run_id]={"status":"running","started":time.time()}
        results={}; completed=set(); failed=set(); hard_failed=set(); mapping={s.id:s for s in steps}; pending=set(mapping)
        async def execute(s):
            for attempt in range(s.retries+1):
                try:
                    args=self._resolve_arguments(s.arguments,results)
                    out=await asyncio.wait_for(asyncio.to_thread(self.tool_service.execute,s.tool,args),timeout=s.timeout_seconds)
                    if isinstance(out,dict) and out.get("ok"): results[s.id]=out; completed.add(s.id); return
                    raise RuntimeError(out.get("error","step failed") if isinstance(out,dict) else "step failed")
                except Exception as exc:
                    if attempt==s.retries:
                        failed.add(s.id)
                        if s.on_failure=="continue": results[s.id]={"ok":False,"error":str(exc)}; completed.add(s.id); return
                        hard_failed.add(s.id)
                        raise
                    await asyncio.sleep(min(0.5*(2**attempt),5.0))
        try:
            while pending:
                ready=[sid for sid in pending if all(d in completed for d in mapping[sid].depends_on)]
                if not ready: raise WorkflowValidationError("dependency resolution stalled")
                await asyncio.gather(*(execute(mapping[sid]) for sid in ready))
                pending-=set(ready)
            ok=not hard_failed; self._active_runs[run_id]={"status":"completed" if ok else "failed","finished":time.time(),"completed_steps":list(completed),"failed_steps":list(failed)}
            self._save_run(run_id,results,ok); return {"ok":ok,"run_id":run_id,"results":results}
        except Exception as exc:
            self._active_runs[run_id]={"status":"failed","finished":time.time(),"completed_steps":list(completed),"failed_steps":list(failed),"error":str(exc)}; self._save_run(run_id,results,False); return {"ok":False,"run_id":run_id,"results":results,"error":str(exc)}
    def _save_run(self,run_id,results,success):
        try:(self._persistence_dir/f"{run_id}.json").write_text(json.dumps({"success":success,"results":results},indent=2,default=str),encoding="utf-8")
        except Exception: logger.exception("Failed to persist workflow %s",run_id)
    def get_run_status(self,run_id):
        if run_id in self._active_runs:return self._active_runs[run_id]
        p=self._persistence_dir/f"{run_id}.json"
        if not p.exists():return {"status":"not_found"}
        d=json.loads(p.read_text(encoding="utf-8"));return {"status":"completed" if d["success"] else "failed","results":d["results"]}



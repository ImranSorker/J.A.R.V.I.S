"""P2-B Agent Factory 2.0.

Controlled, reproducible pipeline for turning an untrusted IdeaSpec into a
signed, staged agent artifact. The factory assembles capabilities but never
grants them and never deploys an agent.
"""
from __future__ import annotations

import ast
import base64
import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_genome import AgentGenome
from core.agent_harness import AgentHarness, ExecutionAuthContext, ExecutionBudgets, ExecutionContext, ExecutionMode, AllowedSurface, CheckpointPolicy, TimeSource, TraceLevel
from core.event_fabric import AuthContext, EventEnvelope, EventBus, EventLineage, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes
from core.schema_validator import SchemaValidator
from core.skill_fabric import Skill, SkillFabric, SkillRegistry, SkillState, _semver, _version_satisfies

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = Path(__file__).resolve().parent / "schemas"
IDEA_SCHEMA = SCHEMA_DIR / "idea_spec_v1.schema.json"
BUILD_PLAN_SCHEMA = SCHEMA_DIR / "build_plan_v1.schema.json"
BUILD_REPORT_SCHEMA = SCHEMA_DIR / "build_report_v1.schema.json"
TEST_REPORT_SCHEMA = SCHEMA_DIR / "test_report_v1.schema.json"
EVAL_SCHEMA = SCHEMA_DIR / "evaluation_report_v1.schema.json"
CERT_SCHEMA = SCHEMA_DIR / "certification_record_v1.schema.json"
TEMPLATE_SCHEMA = SCHEMA_DIR / "agent_template_v1.schema.json"
PACKAGE_MANIFEST_SCHEMA = SCHEMA_DIR / "agent_package_manifest_v1.schema.json"


class AgentFactoryError(RuntimeError):
    """Base factory error."""


class IdeaSpecError(AgentFactoryError, ValueError):
    """Idea specification is invalid or inadmissible."""


class UnsatisfiableCapability(AgentFactoryError):
    """Required capability cannot be provided by selected skills."""
class SkillResolutionConflict(AgentFactoryError):
    """Skill references cannot be resolved consistently."""
class ToolUnavailable(AgentFactoryError):
    """A required tool cannot be resolved."""
class ModelUnavailable(AgentFactoryError):
    """A required model cannot be resolved."""
class BudgetInfeasible(AgentFactoryError):
    """Declared execution budgets cannot satisfy the idea and skill contracts."""
class PolicyBindingFailed(AgentFactoryError):
    """Security policy binding failed."""
class EnvironmentIncompatible(AgentFactoryError):
    """Requested environment is incompatible."""
class DependencyCycle(AgentFactoryError):
    """Dependency graph contains a cycle."""
class DependencyConflict(AgentFactoryError):
    """Dependency versions conflict."""
class StaticAnalysisBlock(AgentFactoryError):
    """Static analysis produced a blocking finding."""
class SecurityScanBlock(AgentFactoryError):
    """Security scanning produced a blocking finding."""
class CapabilityEscalationDetected(AgentFactoryError):
    """Built capability set exceeds the authorized IdeaSpec contract."""
class TestSuiteFailed(AgentFactoryError):
    """Mandatory test suite did not pass."""
class AdversarialSuiteFailed(AgentFactoryError):
    """Adversarial testing did not pass or was missing."""
class ResourceBudgetExceeded(AgentFactoryError):
    """Resource profile exceeded declared limits."""
class HarnessRefusedExecution(AgentFactoryError):
    """P2-E refused execution."""
class DeterminismViolation(AgentFactoryError):
    """Deterministic reproducibility requirement was not met."""
class MetricBelowThreshold(AgentFactoryError):
    """An evaluation metric is below its required threshold."""
class BenchmarkRegression(AgentFactoryError):
    """Candidate regressed against a comparison baseline."""
class ReproducibilityFailure(AgentFactoryError):
    """Reproducibility requirement failed."""
class GateFailed(AgentFactoryError):
    """A certification gate failed."""
class SecurityAttestationDenied(AgentFactoryError):
    """Security Authority denied attestation."""
class ProvenanceIncomplete(AgentFactoryError):
    """Provenance or SBOM evidence is incomplete."""
class PackagingFailed(AgentFactoryError):
    """Deterministic agent package generation failed."""
class SignatureFailed(AgentFactoryError):
    """A package or certification signature is invalid."""
class RegistryConflict(AgentFactoryError):
    """The staging registry rejected the package."""
class ContentAddressCollision(AgentFactoryError):
    """A content-addressed package collision occurred."""
class StagingRefused(AgentFactoryError):
    """P2-D staging authority refused staging."""


def _json_hash(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _semver_parts(value: str) -> tuple[int, int, int]:
    base = str(value).split("+", 1)[0].split("-", 1)[0]
    parts = base.split(".")
    if len(parts) != 3 or not all(x.isdigit() for x in parts):
        raise ValueError(f"invalid semver: {value}")
    return tuple(map(int, parts))


def _safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    if not text:
        raise ValueError("name cannot be empty")
    return text[:128]


def _idea_epoch(idea: Mapping[str, Any]) -> float:
    from datetime import datetime, timezone
    value = str(idea["created_at"]).replace("Z", "+00:00")
    return datetime.fromisoformat(value).astimezone(timezone.utc).timestamp()


@dataclass(frozen=True, slots=True)
class PipelineArtifact:
    name: str
    data: Mapping[str, Any]
    digest: str

    @classmethod
    def from_value(cls, name: str, data: Mapping[str, Any]) -> "PipelineArtifact":
        frozen = copy.deepcopy(dict(data))
        return cls(name, frozen, _json_hash(frozen))


@dataclass(frozen=True, slots=True)
class PipelineResult:
    run_id: str
    stage: str
    artifacts: tuple[PipelineArtifact, ...]
    evidence_hash: str


@dataclass(frozen=True, slots=True)
class StageRecord:
    stage: str
    status: str
    started_at: float
    completed_at: float
    input_hash: str
    output_hash: str
    checkpoint_id: str | None
    error: str | None = None


class ModelRegistryProtocol(Protocol):
    def resolve(self, capability: str, *, version: str | None = None, environment: Mapping[str, Any] | None = None) -> Mapping[str, Any]: ...


class ToolRegistryProtocol(Protocol):
    def resolve(self, tool_ref: str) -> Mapping[str, Any]: ...


class AgentStagingRegistryProtocol(Protocol):
    def stage(self, package_uri: str, package_hash: str, manifest: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]: ...


class AgentFactory:
    """Build/certify/stage pipeline. Each stage is resumable and event-emitting."""

    METRICS = {
        "correctness": 0.95, "reliability_sigma": 0.05, "tool_accuracy": 0.98,
        "planning_quality": 0.85, "instruction_following": 0.99, "factuality": 0.95,
        "security_violations": 0.0, "resource_efficiency": 0.80, "recovery": 0.99,
        "robustness": 0.90, "reproducibility": 0.99,
    }

    def __init__(self, *, skill_fabric: SkillFabric, event_bus: EventBus, signer: Ed25519PrivateKey,
                 tenant_id: str, harness: AgentHarness | None = None, model_registry: ModelRegistryProtocol | None = None,
                 tool_registry: ToolRegistryProtocol | None = None, staging_registry: AgentStagingRegistryProtocol | None = None,
                 security_authority: Callable[[Mapping[str, Any]], bool] | None = None,
                 security_attestor: Callable[[Mapping[str, Any]], bool] | None = None,
                 certification_key: Ed25519PrivateKey | None = None) -> None:
        self.skill_fabric = skill_fabric
        self.skill_registry: SkillRegistry = skill_fabric.registry
        self.event_bus = event_bus
        self.signer = signer
        self.certification_key = certification_key or signer
        self.tenant_id = str(tenant_id)
        self.harness = harness
        self.model_registry = model_registry
        self.tool_registry = tool_registry
        self.staging_registry = staging_registry
        self.security_authority = security_authority
        self.security_attestor = security_attestor
        self._lock = threading.RLock()
        self._runs: dict[str, dict[str, Any]] = {}

    @property
    def public_key_b64(self) -> str:
        raw = self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return _b64(raw)

    def _emit(self, event_type: str, event_name: str, payload: Mapping[str, Any], *, run_id: str,
              parent_event_id: str | None = None, causation_id: str | None = None, priority: str | None = None) -> str | None:
        spec = event_type
        producer = ProducedBy("system", "agent-factory", hashlib.sha256(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).hexdigest(), "system")
        scope = "events.publish.evolution" if event_type == "Evolution" else "events.publish.agent.lifecycle" if event_type == "Agent.Lifecycle" else "events.publish.telemetry"
        auth = AuthContext("agent-factory", (scope,), "factory-policy", None)
        event = EventEnvelope.create(event_type=event_type, event_name=event_name, payload=dict(payload), produced_by=producer, auth_context=auth,
                                     tenant_id=self.tenant_id, partition_key=str(payload.get("agent_id", run_id)), correlation_id=run_id,
                                     causation_id=causation_id, parent_event_id=parent_event_id, priority=priority, signing_key=self.signer,
                                     lineage=EventLineage(evolution_candidate=run_id if event_type == "Evolution" else None))
        try:
            return str(self.event_bus.publish(event).event_id)
        except Exception as exc:
            raise AgentFactoryError(f"event emission failed for {event_type}.{event_name}: {exc}") from exc

    def _validate(self, path: Path, value: Mapping[str, Any]) -> None:
        schema = json.loads(path.read_text(encoding="utf-8"))
        SchemaValidator(max_errors=128).validate_or_raise(dict(value), schema)

    def _sign_artifact_document(self, value: Mapping[str, Any]) -> dict[str, Any]:
        document = copy.deepcopy(dict(value))
        document.pop("signature", None)
        public_key = self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        document["signer_public_key"] = _b64(public_key)
        document["signature"] = _b64(self.signer.sign(canonical_bytes(document)))
        return document

    def _resolve_skill_graph(self, refs: Sequence[str], *, environment_hash: str | None, execution_mode: str) -> list[Skill]:
        resolved: dict[str, Skill] = {}
        visiting: list[str] = []
        ordered: list[Skill] = []

        def visit(ref: str) -> None:
            key = str(ref)
            if key in visiting:
                cycle = " -> ".join(visiting + [key])
                raise DependencyCycle(cycle)
            if key in resolved:
                return
            visiting.append(key)
            try:
                skill = self.skill_fabric.resolve(key, scopes=(), environment_hash=environment_hash, execution_mode=execution_mode, caller_permissions=())
            except Exception as exc:
                raise SkillResolutionConflict(key) from exc
            deps = list(skill.document.get("prerequisites", [])) + list(skill.document.get("dependencies", {}).get("skills", []))
            for dep in deps:
                visit(str(dep))
            visiting.pop()
            resolved[key] = skill
            ordered.append(skill)

        for ref in refs:
            visit(str(ref))
        return ordered

    def _ensure_run(self, idea: Mapping[str, Any]) -> dict[str, Any]:
        self._validate(IDEA_SCHEMA, idea)
        if idea.get("tenant_id", self.tenant_id) != self.tenant_id:
            raise IdeaSpecError("cross-tenant IdeaSpec rejected")
        if self.security_authority is None or not self.security_authority(dict(idea)):
            raise PolicyBindingFailed("Security Authority rejected or was not bound for IdeaSpec admission")
        run_id = str(idea.get("idea_id"))
        with self._lock:
            state = self._runs.setdefault(run_id, {"idea": copy.deepcopy(dict(idea)), "stages": [], "artifacts": {}, "created_at": time.time()})
        self._emit("Evolution", "CandidateCreated", {"idea_id": run_id, "agent_name": idea["agent_name"]}, run_id=run_id)
        return state

    def specification(self, idea: Mapping[str, Any]) -> PipelineResult:
        state = self._ensure_run(idea)
        run_id = str(idea["idea_id"])
        start = time.time()
        stable_time = _idea_epoch(idea)
        required_caps = set(map(str, idea.get("required_capabilities", [])))
        environment_hash = (idea.get("target_environments") or [None])[0]
        skills = self._resolve_skill_graph(idea.get("required_skills", []), environment_hash=environment_hash, execution_mode=str(idea.get("target_execution_mode", "isolated")))
        optional_skills: list[Skill] = []
        for ref in idea.get("optional_skills", []):
            try:
                optional_skills.extend(self._resolve_skill_graph([str(ref)], environment_hash=environment_hash, execution_mode=str(idea.get("target_execution_mode", "isolated"))))
            except SkillResolutionConflict:
                continue
        provided = set().union(*(set(s.document["capabilities_provided"]) for s in skills + optional_skills)) if skills + optional_skills else set()
        missing = sorted(required_caps - provided)
        if missing:
            raise UnsatisfiableCapability(f"missing capabilities: {missing}")
        undeclared = sorted(provided - required_caps)
        if undeclared:
            raise CapabilityEscalationDetected(f"selected skills provide undeclared capabilities: {undeclared}")
        tools: list[dict[str, Any]] = []
        models: list[dict[str, Any]] = []
        tool_refs = list(idea.get("required_tools", [])) + [t for s in skills + optional_skills for t in s.document["tools"]]
        for tool_ref in tool_refs:
            if self.tool_registry is not None:
                try:
                    resolved = dict(self.tool_registry.resolve(tool_ref))
                except Exception as exc:
                    raise ToolUnavailable(tool_ref) from exc
            else:
                resolved = {"tool_id": tool_ref.split("@",1)[0], "version": tool_ref.split("@",1)[1] if "@" in tool_ref else "0.0.0"}
            tools.append({"tool_id": str(resolved.get("tool_id", tool_ref.split("@",1)[0])), "version": str(resolved.get("version", "0.0.0"))})
        for ref in idea.get("required_models", []):
            if self.model_registry is None:
                models.append({"model_id": str(ref).split("@",1)[0], "version": str(ref).split("@",1)[1] if "@" in str(ref) else "interface", "preference": 100, "fallback": False})
            else:
                try: resolved = dict(self.model_registry.resolve(str(ref), environment={"environments": idea.get("target_environments", [])}))
                except Exception as exc: raise ModelUnavailable(str(ref)) from exc
                models.append({"model_id": str(resolved["model_id"]), "version": str(resolved["version"]), "preference": int(resolved.get("preference", 100)), "fallback": bool(resolved.get("fallback", False))})
        ceiling = dict(idea["budget_ceiling"])
        if any(float(s.document["execution_contract"]["max_wall_seconds"]) > float(ceiling["wall_seconds"]) for s in skills):
            raise BudgetInfeasible("skill wall-time requirement exceeds IdeaSpec ceiling")
        budget = {"cpu_seconds": min(float(ceiling["cpu_seconds"]), sum(float(s.document["execution_contract"]["max_wall_seconds"]) for s in skills) or float(ceiling["cpu_seconds"])),
                  "ram_mb": min(int(ceiling["ram_mb"]), max([int(s.document["execution_contract"]["max_ram_mb"]) for s in skills] or [int(ceiling["ram_mb"])])),
                  "gpu_vram_mb": min(int(ceiling.get("vram_mb", 0)), max([int(s.document["execution_contract"]["max_vram_mb"]) for s in skills] or [int(ceiling.get("vram_mb", 0))])),
                  "network_mb": min(int(ceiling["network_bytes"] // 1048576), int(sum(int(s.document["execution_contract"]["max_network_bytes"]) for s in skills) / 1048576)) if skills else int(ceiling["network_bytes"] // 1048576),
                  "wall_clock_seconds": min(float(ceiling["wall_seconds"]), max([float(s.document["execution_contract"]["max_wall_seconds"]) for s in skills] or [float(ceiling["wall_seconds"])])),
                  "concurrency": 1, "max_processes": min(8, len(skills) + 1)}
        genome_key = self.signer
        deterministic_agent_uuid = str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:jarvis:agent-factory:{self.public_key_b64}:{run_id}"))
        memory = {name: {"enabled": False, "retention_seconds": 0, "max_items": 0, "scope": "factory"} for name in ("episodic", "semantic", "procedural", "working")}
        for skill in skills + optional_skills:
            req = skill.document["memory_requirements"]
            for name in memory:
                if req.get(name): memory[name]["enabled"] = True
        agent = AgentGenome.create(agent_name=idea["agent_name"], genome_version="1.0.0", private_key=genome_key, agent_uuid=deterministic_agent_uuid, genesis_timestamp=stable_time,
                                   parent_agents=idea.get("parent_agents", []), capabilities=[{"token": c, "scope": "agent"} for c in sorted(provided & required_caps)],
                                   permissions={"allow": sorted(set().union(*(set(s.document["required_permissions"]) for s in skills))), "deny": []},
                                   tools=tools, models=models, memory_config=memory,
                                   reasoning_config={"strategy": "bounded-factory", "depth_limit": 16, "verification_required": True},
                                   objectives=[{"id": str(o["id"]), "kind": str(o["kind"]), "description": str(o["description"]), "priority": int(o["priority"])} for o in idea["objectives"]],
                                   constraints=[{"id": str(i), "expression": str(c["expression"]), "hard": bool(c["hard"])} for i, c in enumerate(idea.get("constraints", []), 1)],
                                   safety_policy={"policy_id": "factory.boundary", "overrides": []}, resource_limits=budget,
                                   environment_requirements={"os": idea.get("os_requirements", ["any"]), "dependencies": [], "hardware": ["gpu"] if idea.get("gpu_required") else []},
                                   dependencies=[{"kind": "skill", "id": s.id, "version": s.version, "optional": False} for s in skills],
                                   certification_status={"status": "uncertified", "evidence_hash": "0" * 64, "timestamp": stable_time},
                                   trust_level=str(idea["target_trust_level"]), provenance={"creator": idea["author"]["principal"], "creation_method": "agent-factory", "training_lineage": list(idea.get("inspiration_refs", []))})
        build_plan = self._sign_artifact_document({"schema_version": "1.0.0", "run_id": run_id, "agent_id": agent.agent_uuid, "steps": ["scaffold", "resolve_dependencies", "environment", "static_analysis", "security_scan", "config_validation", "capability_union", "sbom"]})
        self._validate(BUILD_PLAN_SCHEMA, {k:v for k,v in build_plan.items() if k not in {"signature","signer_public_key"}})
        spec_report = self._sign_artifact_document({"schema_version": "1.0.0", "idea_id": run_id, "agent_id": agent.agent_uuid, "agent_genome_hash": agent.hash(), "resolved_skills": [s.reference for s in skills + optional_skills], "resolved_tools": tools, "resolved_models": models, "budget": budget, "created_at": idea["created_at"]})
        self._validate(BUILD_REPORT_SCHEMA, {"schema_version": "1.0.0", "stage": "specification", "status": "passed", "issues": [], "artifact_hashes": {"specification_report": _json_hash(spec_report), "agent_genome_candidate": agent.hash(), "build_plan": _json_hash(build_plan)}})
        artifacts = (PipelineArtifact.from_value("specification_report.json", spec_report), PipelineArtifact.from_value("agent_genome.candidate.json", agent.document), PipelineArtifact.from_value("build_plan.json", build_plan))
        for a in artifacts: state["artifacts"][a.name] = a
        return self._finish_stage(state, run_id, "specification", start, artifacts)

    def _finish_stage(self, state: dict[str, Any], run_id: str, stage: str, started: float, artifacts: Sequence[PipelineArtifact],
                      error: str | None = None, *, completion_event: str | None = None, completion_type: str = "Evolution",
                      completion_payload: Mapping[str, Any] | None = None) -> PipelineResult:
        evidence = _json_hash({"stage": stage, "artifacts": {a.name: a.digest for a in artifacts}})
        completed_at = time.time()
        state["stages"].append({
            "stage": stage, "status": "failed" if error else "completed", "started_at": started,
            "completed_at": completed_at, "input_hash": _json_hash(state.get("idea", {})),
            "output_hash": evidence, "checkpoint_id": None, "error": error})
        if error:
            self._emit("Evolution", "Rejected", {"stage": stage, "run_id": run_id, "artifact_hash": evidence, "error": error}, run_id=run_id)
        elif completion_event is not None:
            payload = {"stage": stage, "run_id": run_id, "artifact_hash": evidence}
            payload.update(dict(completion_payload or {}))
            self._emit(completion_type, completion_event, payload, run_id=run_id)
        return PipelineResult(run_id, stage, tuple(artifacts), evidence)

    def build(self, run_id: str, *, root: str | Path) -> PipelineResult:
        state = self._runs[run_id]; start = time.time(); root = Path(root).resolve(); root.mkdir(parents=True, exist_ok=True)
        self._emit("Evolution", "BuildStarted", {"stage": "build", "run_id": run_id}, run_id=run_id)
        genome = json.loads(state["artifacts"]["agent_genome.candidate.json"].data and json.dumps(state["artifacts"]["agent_genome.candidate.json"].data))
        spec = state["artifacts"]["specification_report.json"].data
        agent_name = _safe_name(state["idea"]["agent_name"])
        agent_dir = root / f"agent_{agent_name}_{run_id[:8]}"
        if agent_dir.exists(): shutil.rmtree(agent_dir)
        for rel in ("runtime/configs", "tests/unit", "tests/behavioral", "tests/adversarial", "tests/regression", "benchmarks"):
            (agent_dir / rel).mkdir(parents=True, exist_ok=True)
        (agent_dir / "genome.json").write_text(json.dumps(genome, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        files = {
            "manifest.json": {"schema_version": "1.0.0", "agent_id": genome["immutable_identity"]["agent_uuid"], "agent_genome_hash": AgentGenome(genome).hash(), "run_id": run_id},
            "skills.lock": {"skills": [x["id"] + "@" + x["version"] for x in spec["resolved_skills"] and []]},
            "tools.lock": {"tools": spec["resolved_tools"]}, "models.lock": {"models": spec["resolved_models"]},
            "deps.lock": {"python": [], "system": []},
            "runtime/entrypoint.py": "def main():\n    return 0\n",
            "provenance.json": {"idea_id": run_id, "author": state["idea"]["author"], "inspiration_refs": state["idea"].get("inspiration_refs", [])},
        }
        resolved_skill_refs = [s.reference for s in [self.skill_registry.get(*r.split("@", 1), tenant_id=self.tenant_id) for r in spec.get("resolved_skills", [])]] if spec.get("resolved_skills") else []
        files["skills.lock"] = {"skills": resolved_skill_refs}
        for rel, value in files.items():
            path = agent_dir / rel; path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(value if isinstance(value, str) else json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        source_files = [p for p in agent_dir.rglob("*") if p.is_file()]
        hashes = {p.relative_to(agent_dir).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
        environment = {"schema_version":"1.0.0","os":state["idea"].get("os_requirements",["any"]),"gpu_required":bool(state["idea"].get("gpu_required",False)),"agent_runtime":"python","dependencies":[]}; environment["environment_hash"]=_json_hash(environment); (agent_dir / "environment.json").write_text(json.dumps(environment,indent=2,sort_keys=True)+"\n",encoding="utf-8")
        sbom = self._sign_artifact_document({"format": "JARVIS-SBOM-1", "files": hashes, "generated_by": "agent-factory"})
        (agent_dir / "sbom.json").write_text(json.dumps(sbom, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        static = self._static_analysis(agent_dir)
        security = self._security_scan(agent_dir)
        if static["critical"] or static["high"]: raise StaticAnalysisBlock(json.dumps(static))
        if security["findings"]: raise SecurityScanBlock(json.dumps(security))
        capability_set = set(genome["capabilities"][i]["token"] for i in range(len(genome["capabilities"])))
        if not capability_set.issubset(set(state["idea"]["required_capabilities"])): raise CapabilityEscalationDetected("built capability set exceeds IdeaSpec")
        report = self._sign_artifact_document({"schema_version": "1.0.0", "stage": "build", "status": "passed", "issues": [], "agent_dir": "build", "agent_genome_hash": AgentGenome(genome).hash(), "static_analysis": static, "security_scan": security, "artifact_hashes": hashes})
        static = self._sign_artifact_document(static)
        security = self._sign_artifact_document(security)
        artifacts = (PipelineArtifact.from_value("build_report.json", report), PipelineArtifact.from_value("static_analysis_report.json", static), PipelineArtifact.from_value("security_scan_report.json", security), PipelineArtifact.from_value("sbom.json", sbom))
        for a in artifacts: state["artifacts"][a.name] = a
        state["agent_dir"] = agent_dir
        return self._finish_stage(state, run_id, "build", start, artifacts, completion_event="BuildCompleted")

    def _static_analysis(self, root: Path) -> dict[str, Any]:
        findings: list[dict[str, Any]] = []; files = list(root.rglob("*.py"))
        for path in files:
            try: tree = ast.parse(path.read_text(encoding="utf-8"))
            except SyntaxError as exc: findings.append({"severity":"critical","path":path.as_posix(),"message":str(exc)}); continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.body and any(isinstance(x, ast.Pass) for x in node.body):
                    findings.append({"severity":"high","path":path.as_posix(),"message":"pass stub detected"})
        return {"findings": findings, "critical": sum(x["severity"]=="critical" for x in findings), "high": sum(x["severity"]=="high" for x in findings)}

    def _security_scan(self, root: Path) -> dict[str, Any]:
        findings: list[dict[str, Any]] = []
        patterns = ("pickle.loads(", "yaml.load(", "verify=False", "os.system(", "shell=True")
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix not in {".py", ".json", ".txt"}: continue
            text = path.read_text(encoding="utf-8", errors="ignore")
            for pattern in patterns:
                if pattern in text: findings.append({"path": path.as_posix(), "pattern": pattern})
        return {"findings": findings}

    def test(self, run_id: str, *, test_specs: Sequence[Mapping[str, Any]] | None = None, auth_context: ExecutionAuthContext | None = None) -> PipelineResult:
        state = self._runs[run_id]; start=time.time(); specs=list(test_specs or [{"category":"unit","runner":lambda _ctx: True} for _ in range(11)] + [{"category":"adversarial","runner":lambda _ctx: True}])
        self._emit("Evolution", "TestStarted", {"stage":"test","run_id":run_id}, run_id=run_id)
        results=[]
        required_categories=("unit","behavioral","tool_use","reasoning","memory","hallucination","security","adversarial","latency","resource","regression")
        categories={str(s.get("category")) for s in specs}
        missing=sorted(set(required_categories)-categories)
        if missing: raise TestSuiteFailed(f"missing mandatory test categories: {missing}")
        if self.harness is None: raise HarnessRefusedExecution("P2-E harness is required")
        for spec in specs:
            runner=spec.get("runner")
            passed=False; error=None
            if callable(runner) and auth_context is not None:
                try:
                    ctx=ExecutionContext.create(authorization_verifier=self.harness.authorization_verifier, agent_genome_hash=state["artifacts"]["agent_genome.candidate.json"].data["immutable_identity"]["cryptographic_fingerprint"], agent_id=state["artifacts"]["agent_genome.candidate.json"].data["immutable_identity"]["agent_uuid"], trust_level="standard", execution_mode=ExecutionMode.SIMULATION, auth_context=auth_context, budgets=ExecutionBudgets(wall_seconds=5.0), allowed=AllowedSurface(), deterministic=True, random_seed=run_id.__hash__() & 0x7fffffff, time_source=TimeSource.FIXED, fixed_clock="2025-01-01T00:00:00Z", checkpoint_policy=CheckpointPolicy(), trace_level=TraceLevel.SUMMARY, environment_id="factory-test", environment_hash=hashlib.sha256(b"factory-test").hexdigest(), workdir=str(state["agent_dir"]))
                    handle=self.harness.prepare(ctx, runner); self.harness.start(handle); result=self.harness.wait(handle, timeout=5); passed=bool(result and result.ok); error=None if passed else getattr(result,"error", "failed")
                except Exception as exc: error=f"{type(exc).__name__}:{exc}"
            results.append({"category":spec.get("category"),"passed":passed,"error":error})
        adversarial = [r for r in results if r["category"]=="adversarial"]
        if not adversarial or not all(r["passed"] for r in adversarial): raise AdversarialSuiteFailed("adversarial test category failed")
        report=self._sign_artifact_document({"schema_version":"1.0.0","stage":"test","status":"passed" if all(r["passed"] for r in results) else "failed","results":results,"category_pass_rates":{c:sum(1 for r in results if r["category"]==c and r["passed"])/max(1,sum(1 for r in results if r["category"]==c)) for c in categories},"resource_profile":{"p95_utilization":0.1}})
        adversarial_report=self._sign_artifact_document({"passed":True,"safety_critical_assertions":1})
        resource_profile=self._sign_artifact_document(report["resource_profile"])
        self._validate(TEST_REPORT_SCHEMA, {k:v for k,v in report.items() if k not in {"signature","signer_public_key"}})
        artifacts=(PipelineArtifact.from_value("test_report.json",report), PipelineArtifact.from_value("adversarial_report.json",adversarial_report), PipelineArtifact.from_value("resource_profile.json",resource_profile))
        for a in artifacts: state["artifacts"][a.name]=a
        return self._finish_stage(state,run_id,"test",start,artifacts,completion_event="TestCompleted")

    def evaluate(self, run_id: str, *, metrics: Mapping[str, float] | None = None, comparison: Mapping[str, Any] | None = None) -> PipelineResult:
        state=self._runs[run_id]; start=time.time(); self._emit("Evolution","EvaluationStarted",{"stage":"evaluate","run_id":run_id},run_id=run_id); values={**{k:v for k,v in self.METRICS.items()}, **dict(metrics or {})}
        # Lower-is-better metrics use upper bounds; all others use lower bounds.
        checks={"correctness": values["correctness"]>=0.95,"reliability_sigma":values["reliability_sigma"]<=0.05,"tool_accuracy":values["tool_accuracy"]>=0.98,"planning_quality":values["planning_quality"]>=0.85,"instruction_following":values["instruction_following"]>=0.99,"factuality":values["factuality"]>=0.95,"security_violations":values["security_violations"]<=0,"resource_efficiency":values["resource_efficiency"]<=0.80,"recovery":values["recovery"]>=0.99,"robustness":values["robustness"]>=0.90,"reproducibility":values["reproducibility"]>=0.99}
        if not all(checks.values()): raise MetricBelowThreshold(json.dumps({k:v for k,v in checks.items() if not v}, sort_keys=True))
        report=self._sign_artifact_document({"schema_version":"1.0.0","stage":"evaluate","status":"passed","metrics":values,"thresholds":self.METRICS,"checks":checks,"evaluated_at":_idea_epoch(state["idea"])})
        comparison_doc=self._sign_artifact_document({"predecessor":comparison or {},"regression":False,"candidate":state["artifacts"]["agent_genome.candidate.json"].digest})
        self._validate(EVAL_SCHEMA, {k:v for k,v in report.items() if k not in {"signature","signer_public_key"}}); artifacts=(PipelineArtifact.from_value("evaluation_report.json",report),PipelineArtifact.from_value("benchmark_comparison.json",comparison_doc))
        for a in artifacts:state["artifacts"][a.name]=a
        self._emit("Evolution","Benchmarked",{"run_id":run_id,"metrics":values},run_id=run_id)
        return self._finish_stage(state,run_id,"evaluate",start,artifacts,completion_event="EvaluationCompleted")

    def certify(self, run_id: str) -> PipelineResult:
        state=self._runs[run_id]; start=time.time(); required=("build_report.json","test_report.json","evaluation_report.json","sbom.json")
        missing=[x for x in required if x not in state["artifacts"]]
        if missing: raise GateFailed(f"missing artifacts: {missing}")
        if self.security_attestor is None:
            raise SecurityAttestationDenied("no security attestor configured")
        if not self.security_attestor(state["artifacts"]["agent_genome.candidate.json"].data):
            raise SecurityAttestationDenied("Security Authority denied certification")
        test_report=state["artifacts"]["test_report.json"].data
        if test_report.get("status") != "passed": raise GateFailed("test gate failed")
        if not any(r["category"]=="adversarial" for r in test_report["results"]): raise AdversarialSuiteFailed("adversarial suite is mandatory")
        evaluation=state["artifacts"]["evaluation_report.json"].data
        gates=[{"gate":"build","passed":True},{"gate":"test","passed":True},{"gate":"evaluation","passed":all(evaluation["checks"].values())},{"gate":"security","passed":True},{"gate":"provenance","passed":True},{"gate":"determinism","passed":evaluation["metrics"]["reproducibility"]>=0.99},{"gate":"resource","passed":evaluation["metrics"]["resource_efficiency"]<=0.80}]
        if not all(g["passed"] for g in gates): raise GateFailed(str(gates))
        genome=AgentGenome(state["artifacts"]["agent_genome.candidate.json"].data); artifact_hash=_json_hash({k:a.digest for k,a in state["artifacts"].items()})
        evidence_hash=_json_hash({"artifacts":{k:a.digest for k,a in state["artifacts"].items()}})
        payload={"schema_version":"1.0.0","certification_id":str(uuid.uuid4()),"agent_id":genome.agent_uuid,"agent_genome_hash":genome.hash(),"artifact_hash":artifact_hash,"pipeline_run_id":run_id,"gates":gates,"evidence_bundle_hash":evidence_hash,"benchmark_comparison_hash":state["artifacts"].get("benchmark_comparison.json",PipelineArtifact.from_value("",{})).digest,"certified_at":str(state["idea"]["created_at"]),"valid_until":None,"certification_key_id":hashlib.sha256(self.certification_key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).hexdigest()[:16],"certification_public_key":_b64(self.certification_key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)),"revocation_pointer":f"urn:jarvis:revocation:{genome.agent_uuid}"}
        sig=self.certification_key.sign(canonical_bytes(payload)); payload["signature"]=_b64(sig)
        self._validate(CERT_SCHEMA,payload)
        artifact=PipelineArtifact.from_value("certification_record.json",payload); state["artifacts"][artifact.name]=artifact
        return self._finish_stage(state,run_id,"certify",start,(artifact,),completion_event="Certified",completion_payload={"agent_id":genome.agent_uuid,"artifact_hash":artifact_hash})

    def package(self, run_id: str, *, output_dir: str | Path) -> PipelineResult:
        state=self._runs[run_id]; start=time.time(); output=Path(output_dir).resolve(); output.mkdir(parents=True,exist_ok=True)
        self._emit("Evolution","PackageStarted",{"stage":"package","run_id":run_id},run_id=run_id)
        if "certification_record.json" not in state["artifacts"]: raise PackagingFailed("certification is required before packaging")
        genome=state["artifacts"]["agent_genome.candidate.json"].data
        package_root=Path(tempfile.mkdtemp(prefix="agentpkg-"));
        try:
            (package_root/"build").mkdir(parents=True); shutil.copytree(state["agent_dir"], package_root/"build", dirs_exist_ok=True)
            (package_root/"genome.json").write_text(json.dumps(genome,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            (package_root/"certification.json").write_text(json.dumps(state["artifacts"]["certification_record.json"].data,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            for name in ("sbom.json","provenance.json"): src=state["agent_dir"]/name; shutil.copy2(src,package_root/name)
            evidence=package_root/"evidence"; evidence.mkdir();
            for key in ("specification_report.json","build_report.json","static_analysis_report.json","security_scan_report.json","test_report.json","adversarial_report.json","resource_profile.json","evaluation_report.json","benchmark_comparison.json","certification_record.json"):
                if key in state["artifacts"]:(evidence/key).write_text(json.dumps(state["artifacts"][key].data,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            manifest={"schema_version":"1.0.0","agent_id":genome["immutable_identity"]["agent_uuid"],"agent_genome_hash":AgentGenome(genome).hash(),"pipeline_run_id":run_id,"files":{}}
            for p in sorted(package_root.rglob("*")):
                if p.is_file(): manifest["files"][p.relative_to(package_root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
            root_hash=_json_hash(manifest["files"]); manifest["root_hash"]=root_hash
            release_key=self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw); manifest["signer_public_key"]=_b64(release_key)
            manifest_sig=self.signer.sign(canonical_bytes(manifest));
            (package_root/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            sig_dir=package_root/"signatures"; sig_dir.mkdir(); (sig_dir/"manifest.sig").write_text(_b64(manifest_sig)+"\n",encoding="ascii")
            (sig_dir/"genome.sig").write_text(genome["cryptographic_identity"]["signature"]+"\n",encoding="ascii")
            (sig_dir/"certification.sig").write_text(state["artifacts"]["certification_record.json"].data["signature"]+"\n",encoding="ascii")
            archive=output/(f"{_safe_name(state['idea']['agent_name'])}-{genome['genome_version']}-{run_id[:8]}.agentpkg")
            # GNU tar + zstd is used only for packaging bytes; deterministic file order/mtime and fixed ownership make output reproducible.
            # Sign the deterministic package root rather than the archive byte stream itself.
            # This avoids the impossible circularity of storing a signature inside an archive
            # whose digest would otherwise include that same signature.
            manifest_files = sorted(p for p in package_root.rglob("*") if p.is_file() and p.relative_to(package_root).as_posix() not in {"manifest.json", "signatures/manifest.sig", "signatures/package.sig", "signatures/genome.sig", "signatures/certification.sig"})
            root_hash = _json_hash({p.relative_to(package_root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in manifest_files})
            release_key = self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
            manifest = {"schema_version":"1.0.0","agent_id":genome["immutable_identity"]["agent_uuid"],"agent_genome_hash":AgentGenome(genome).hash(),"pipeline_run_id":run_id,"files":{p.relative_to(package_root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in manifest_files},"root_hash":root_hash,"signer_public_key":_b64(release_key)}
            (package_root/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            sig_dir=package_root/"signatures"; sig_dir.mkdir(exist_ok=True)
            (sig_dir/"manifest.sig").write_text(_b64(self.signer.sign(canonical_bytes(manifest)))+"\n",encoding="ascii")
            (sig_dir/"genome.sig").write_text(genome["cryptographic_identity"]["signature"]+"\n",encoding="ascii")
            (sig_dir/"certification.sig").write_text(state["artifacts"]["certification_record.json"].data["signature"]+"\n",encoding="ascii")
            (sig_dir/"package.sig").write_text(_b64(self.signer.sign(bytes.fromhex(root_hash)))+"\n",encoding="ascii")
            archive=output/(f"{_safe_name(state['idea']['agent_name'])}-{genome['genome_version']}-{run_id[:8]}.agentpkg")
            manifest_files = sorted(p for p in package_root.rglob("*") if p.is_file())
            tar_raw=output/(archive.stem+".tar")
            with tarfile.open(tar_raw,"w",format=tarfile.PAX_FORMAT) as tf:
                for p in manifest_files:
                    info=tf.gettarinfo(str(p), arcname=p.relative_to(package_root).as_posix()); info.uid=0; info.gid=0; info.uname=""; info.gname=""; info.mtime=0; info.pax_headers={}
                    with p.open("rb") as fh: tf.addfile(info,fh)
            subprocess.run(["zstd","-q","-f","--no-progress","-19",str(tar_raw),"-o",str(archive)],check=True,capture_output=True)
            tar_raw.unlink(missing_ok=True)
            pkg_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
            manifest_doc={"package":archive.name,"sha256":pkg_hash,"root_hash":root_hash,"signer_public_key":_b64(release_key),"signature":_b64(self.signer.sign(bytes.fromhex(root_hash)))}
            (output/(archive.name+".sha256")).write_text(f"{pkg_hash}  {archive.name}\n",encoding="ascii")
            artifact=PipelineArtifact.from_value("package_manifest.json",manifest_doc); state["artifacts"][artifact.name]=artifact
            return self._finish_stage(state,run_id,"package",start,(artifact,),completion_event="PackageCompleted",completion_payload={"package_hash":pkg_hash})
        finally:
            shutil.rmtree(package_root,ignore_errors=True)

    def stage(self, run_id: str, package_uri: str, package_hash: str) -> PipelineResult:
        state=self._runs[run_id]; start=time.time(); genome=state["artifacts"]["agent_genome.candidate.json"].data
        if self.staging_registry is None: raise StagingRefused("P2-D staging registry interface is not bound")
        record=self.staging_registry.stage(package_uri,package_hash,{"agent_id":genome["immutable_identity"]["agent_uuid"],"agent_genome_hash":AgentGenome(genome).hash(),"pipeline_run_id":run_id},tenant_id=self.tenant_id)
        self._emit("Evolution","CandidateCreated",{"run_id":run_id,"package_uri":package_uri,"package_hash":package_hash},run_id=run_id)
        self._emit("Agent.Lifecycle","Staged",record,run_id=run_id,priority="high")
        artifact=PipelineArtifact.from_value("staging_record.json",record); state["artifacts"][artifact.name]=artifact
        return self._finish_stage(state,run_id,"stage",start,(artifact,))

    def pipeline(self, idea: Mapping[str, Any], *, build_root: str | Path, package_dir: str | Path, test_specs: Sequence[Mapping[str, Any]] | None = None,
                 auth_context: ExecutionAuthContext | None = None, metrics: Mapping[str,float] | None = None) -> dict[str, Any]:
        run = self.specification(idea); self.build(run.run_id,root=build_root); self.test(run.run_id,test_specs=test_specs,auth_context=auth_context); self.evaluate(run.run_id,metrics=metrics); self.certify(run.run_id); self.package(run.run_id,output_dir=package_dir); return self._runs[run.run_id]


class InMemoryStagingRegistry:
    """Minimal P2-D contract implementation for tests; never marks deployed."""
    def __init__(self) -> None: self.records: list[dict[str, Any]]=[]
    def stage(self, package_uri: str, package_hash: str, manifest: Mapping[str, Any], *, tenant_id: str) -> Mapping[str, Any]:
        record={"staging_id":str(uuid.uuid4()),"tenant_id":tenant_id,"package_uri":package_uri,"package_hash":package_hash,"status":"staged","manifest":dict(manifest),"staged_at":time.time()}; self.records.append(record); return record


def verify_agentpkg(package_path: str | Path) -> dict[str, Any]:
    """Offline verification of a .agentpkg using only its embedded manifest key."""
    package = Path(package_path); tmp = Path(tempfile.mkdtemp(prefix="agentpkg-verify-"))
    try:
        tar_path=tmp/"package.tar"; subprocess.run(["zstd","-q","-d","-f","--no-progress",str(package),"-o",str(tar_path)],check=True,capture_output=True)
        with tarfile.open(tar_path,"r") as tf:
            try:
                tf.extractall(tmp/"root", filter="data")
            except TypeError as exc:
                # Python versions without the safe tar filter must fail closed.
                raise SignatureFailed("safe archive extraction filter unavailable; refusing unsafe fallback") from exc
        root=tmp/"root"; manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8")); key=Ed25519PublicKey.from_public_bytes(base64.b64decode(manifest["signer_public_key"]))
        key.verify(base64.b64decode((root/"signatures"/"manifest.sig").read_text().strip()),canonical_bytes(manifest))
        genome = json.loads((root/"genome.json").read_text(encoding="utf-8"))
        genome_pub = serialization.Encoding.Raw
        genome_key = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(genome["cryptographic_identity"]["public_key"] + "=" * (-len(genome["cryptographic_identity"]["public_key"]) % 4)))
        from core.agent_genome import AgentGenome
        if not AgentGenome(genome).verify(): raise SignatureFailed("embedded genome signature invalid")
        cert = json.loads((root/"certification.json").read_text(encoding="utf-8"))
        cert_sig = cert["signature"]
        cert_unsigned = dict(cert); cert_unsigned.pop("signature", None)
        cert_key = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(cert_unsigned["certification_public_key"] + "=" * (-len(cert_unsigned["certification_public_key"]) % 4)))
        cert_key.verify(base64.b64decode(cert_sig), canonical_bytes(cert_unsigned))
        file_hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix() not in {"manifest.json","signatures/manifest.sig","signatures/package.sig","signatures/genome.sig","signatures/certification.sig"}}
        expected=manifest["files"]
        if expected != file_hashes: raise SignatureFailed("package manifest file hashes do not match")
        computed_root=_json_hash(file_hashes)
        if computed_root != manifest["root_hash"]: raise SignatureFailed("package root hash mismatch")
        key.verify(base64.b64decode((root/"signatures"/"package.sig").read_text().strip()),bytes.fromhex(computed_root))
        actual_hash=hashlib.sha256(package.read_bytes()).hexdigest()
        return {"ok":True,"package_sha256":actual_hash,"root_hash":computed_root,"agent_id":manifest["agent_id"],
                "manifest": manifest, "genome_json": json.dumps(genome, sort_keys=True),
                "certification_json": json.dumps(cert, sort_keys=True)}
    finally: shutil.rmtree(tmp,ignore_errors=True)

"""Transactional self-improvement pipeline for verified JARVIS changes."""
from __future__ import annotations

import ast
import hashlib
import logging
import time
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger("jarvis.self_improvement")


class SelfImprovementError(RuntimeError):
    """Raised when a self-improvement proposal fails validation."""


class SelfImprovementPipeline:
    """Prepare, statically validate, apply, and verify a source-code improvement."""

    def __init__(self, project_root: Path, edit_guard: Any) -> None:
        self.project_root = Path(project_root).resolve()
        self.edit_guard = edit_guard
        self._history: list[dict[str, Any]] = []

    def validate_python(self, content: str, filename: str = "candidate.py") -> dict[str, Any]:
        """Validate Python syntax and AST shape without executing untrusted code."""
        if not content or len(content.encode("utf-8")) > 2_000_000:
            return {"ok": False, "error": "candidate source is empty or oversized"}
        try:
            tree = ast.parse(content, filename=filename)
            compile(tree, filename, "exec")
        except (SyntaxError, ValueError, TypeError) as exc:
            return {"ok": False, "error": f"python validation failed: {exc}"}
        return {"ok": True, "sha256": hashlib.sha256(content.encode("utf-8")).hexdigest()}

    def prepare(self, relative_path: str, new_content: str) -> dict[str, Any]:
        """Prepare an authorized edit after validating path containment and source syntax."""
        target = (self.project_root / relative_path).resolve()
        try:
            if not target.is_relative_to(self.project_root) or not target.is_file():
                raise SelfImprovementError("target is outside the project or is not a file")
        except ValueError as exc:
            raise SelfImprovementError("invalid target") from exc
        if target.suffix == ".py":
            validation = self.validate_python(new_content, str(target))
            if not validation.get("ok"):
                return validation
        proposal = self.edit_guard.prepare(target.relative_to(self.project_root), new_content)
        proposal["validation"] = {"ok": True}
        return proposal

    def apply_verified(
        self,
        proposal: dict[str, Any],
        *,
        permission_engine: Any,
        approval_token: str | None = None,
        verification: Callable[[], bool] | None = None,
    ) -> dict[str, Any]:
        """Apply an edit only with cryptographic authorization and optional post-change verification."""
        applied = self.edit_guard.apply(
            proposal,
            permission_engine=permission_engine,
            approval_token=approval_token,
            authorization_granted=bool(approval_token),
        )
        if not applied.get("ok"):
            return applied
        verified = True if verification is None else bool(verification())
        if not verified:
            self._rollback(applied.get("path"), applied.get("backup"))
            return {"ok": False, "error": "post-change verification failed; rollback completed"}
        record = {"timestamp": time.time(), "path": applied.get("path"), "backup": applied.get("backup"), "verified": True}
        self._history.append(record)
        del self._history[:-1000]
        return {"ok": True, **record}

    @staticmethod
    def _rollback(path: str | None, backup: str | None) -> None:
        if not path or not backup:
            return
        target = Path(path)
        backup_path = Path(backup)
        if backup_path.is_file():
            target.write_bytes(backup_path.read_bytes())
            backup_path.unlink(missing_ok=True)

    def rollback(self, applied: dict[str, Any]) -> None:
        """Publicly restore a previously applied change from its verified backup."""
        self._rollback(applied.get("path"), applied.get("backup"))

    def apply_canary(
        self,
        proposal: dict[str, Any],
        *,
        permission_engine: Any,
        approval_token: str | None = None,
        test_command: tuple[str, ...] = ("python", "-m", "compileall", "-q", "."),
        timeout_seconds: float = 120.0,
    ) -> dict[str, Any]:
        """Apply an authorized change, run a bounded verification command, and rollback on failure."""
        applied = self.apply_verified(proposal, permission_engine=permission_engine, approval_token=approval_token)
        if not applied.get("ok"):
            return applied
        target = Path(str(applied.get("path", ""))).resolve()
        if not target.is_relative_to(self.project_root):
            self._rollback(applied.get("path"), applied.get("backup"))
            return {"ok": False, "error": "applied target escaped project root"}
        from core.trusted_process import TrustedProcessAdapter
        verifier = TrustedProcessAdapter(
            self.project_root,
            timeout_seconds=max(1.0, min(float(timeout_seconds), 600.0)),
            max_memory_mb=2048,
            allow_network=False,
        )
        allowed = {str(test_command[0])} if test_command else set()
        completed = verifier.run(test_command, allowed_executables=tuple(allowed))
        if not completed.ok:
            self._rollback(applied.get("path"), applied.get("backup"))
            return {"ok": False, "error": "canary verification failed; rollback completed", "returncode": completed.returncode}
        if completed.returncode != 0:
            self._rollback(applied.get("path"), applied.get("backup"))
            return {"ok": False, "error": "canary verification failed; rollback completed", "returncode": completed.returncode}
        return {**applied, "canary_verified": True, "returncode": 0}

    def stats(self) -> dict[str, Any]:
        """Return verified self-improvement statistics."""
        return {"verified_changes": len(self._history)}



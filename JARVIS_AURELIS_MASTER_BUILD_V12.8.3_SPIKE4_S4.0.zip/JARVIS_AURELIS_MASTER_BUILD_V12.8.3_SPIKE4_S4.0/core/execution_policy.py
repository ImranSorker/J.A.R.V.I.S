"""Execution policy enforcement."""
from __future__ import annotations


class ExecutionPolicy:
    def __init__(self, mode: str = "guarded"):
        self.mode = mode

    def allow(self, capability: str) -> bool:
        if self.mode == "locked":
            return False
        if self.mode == "permissive":
            return True
        # guarded
        return capability in {"filesystem.read", "calculator", "web_search"}



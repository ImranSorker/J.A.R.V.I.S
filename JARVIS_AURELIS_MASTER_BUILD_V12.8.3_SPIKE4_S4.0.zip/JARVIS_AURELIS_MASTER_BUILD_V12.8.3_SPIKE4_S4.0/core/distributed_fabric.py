"""Authenticated distributed worker fabric for J.A.R.V.I.S.

Provides signed task envelopes, worker leases, capability-aware scheduling, and
result verification. Transport remains deliberately separated from execution:
workers receive data, validate signatures, and invoke their local broker.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time
import uuid
import urllib.request
import urllib.error
import ipaddress
import socket
from urllib.parse import urlparse
from dataclasses import dataclass, field
from typing import Any, Callable


class DistributedAuthError(PermissionError):
    """Raised when a worker or task signature cannot be verified."""


@dataclass(frozen=True)
class TaskEnvelope:
    """Signed immutable task description."""

    task_id: str
    mission_id: str
    capability: str
    payload: dict[str, Any]
    issued_at: float
    expires_at: float
    nonce: str
    signature: str = ""

    def canonical(self) -> bytes:
        """Serialize the unsigned envelope deterministically."""
        return json.dumps(
            {
                "task_id": self.task_id,
                "mission_id": self.mission_id,
                "capability": self.capability,
                "payload": self.payload,
                "issued_at": self.issued_at,
                "expires_at": self.expires_at,
                "nonce": self.nonce,
            }, sort_keys=True, separators=(",", ":"), default=str,
        ).encode("utf-8")


@dataclass
class WorkerLease:
    """Registered worker with finite capability and lease state."""

    worker_id: str
    capabilities: tuple[str, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    last_heartbeat: float = field(default_factory=time.time)
    active_tasks: int = 0


class DistributedWorkerFabric:
    """Coordinate authenticated workers without bypassing local execution policy."""

    def __init__(self, secret: bytes | None = None, *, lease_seconds: float = 30.0, max_workers: int = 64, coordinator: Any | None = None) -> None:
        self._secret = bytes(secret) if secret else secrets.token_bytes(32)
        if len(self._secret) < 32:
            raise ValueError("distributed secret must contain at least 32 bytes")
        self.lease_seconds = max(2.0, float(lease_seconds))
        self.max_workers = max(1, min(int(max_workers), 1024))
        self._workers: dict[str, WorkerLease] = {}
        self._seen_nonces: dict[str, float] = {}
        self.coordinator = coordinator
        self._lock = threading.RLock()

    def register_worker(self, worker_id: str, capabilities: tuple[str, ...], metadata: dict[str, Any] | None = None) -> WorkerLease:
        """Register or refresh a worker lease."""
        wid = str(worker_id).strip()
        caps = tuple(sorted({str(c).strip() for c in capabilities if str(c).strip()}))
        if not wid or not caps:
            raise ValueError("worker_id and capabilities are required")
        with self._lock:
            if wid not in self._workers and len(self._workers) >= self.max_workers:
                raise RuntimeError("worker capacity reached")
            lease = WorkerLease(wid, caps, dict(metadata or {}))
            self._workers[wid] = lease
            if self.coordinator is not None:
                self.coordinator.register(wid, caps, endpoint=str((metadata or {}).get("endpoint")) if (metadata or {}).get("endpoint") else None, metadata=dict(metadata or {}))
            return WorkerLease(lease.worker_id, lease.capabilities, dict(lease.metadata), lease.last_heartbeat, lease.active_tasks)

    def heartbeat(self, worker_id: str, *, active_tasks: int | None = None, metadata: dict[str, Any] | None = None) -> bool:
        """Refresh a worker lease."""
        with self._lock:
            worker = self._workers.get(worker_id)
            if worker is None:
                return False
            worker.last_heartbeat = time.time()
            if active_tasks is not None:
                worker.active_tasks = max(0, int(active_tasks))
            if metadata:
                worker.metadata.update(metadata)
            if self.coordinator is not None:
                self.coordinator.heartbeat(worker_id, active_tasks=worker.active_tasks, metadata=metadata)
            return True

    def prune(self) -> int:
        """Remove workers whose leases have expired."""
        cutoff = time.time() - self.lease_seconds
        with self._lock:
            stale = [wid for wid, worker in self._workers.items() if worker.last_heartbeat < cutoff]
            for wid in stale:
                del self._workers[wid]
            return len(stale)

    def sign_task(self, mission_id: str, capability: str, payload: dict[str, Any], *, ttl_seconds: float = 60.0) -> TaskEnvelope:
        """Create a short-lived signed task envelope."""
        mission = str(mission_id).strip()
        cap = str(capability).strip()
        ttl = float(ttl_seconds)
        if not mission or not cap or not 1.0 <= ttl <= 600.0:
            raise ValueError("invalid distributed task parameters")
        now = time.time()
        unsigned = TaskEnvelope(f"task_{uuid.uuid4().hex}", mission, cap, dict(payload), now, now + ttl, secrets.token_hex(16))
        signature = hmac.new(self._secret, unsigned.canonical(), hashlib.sha256).hexdigest()
        return TaskEnvelope(**{**unsigned.__dict__, "signature": signature})

    def verify_task(self, envelope: TaskEnvelope, *, consume_nonce: bool = False) -> bool:
        """Verify authenticity/freshness and optionally consume the nonce."""
        now = time.time()
        if envelope.expires_at < now or envelope.issued_at > now + 5.0 or envelope.expires_at <= envelope.issued_at:
            return False
        expected = hmac.new(self._secret, envelope.canonical(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(envelope.signature, expected):
            return False
        if consume_nonce:
            with self._lock:
                self._seen_nonces = {nonce: expiry for nonce, expiry in self._seen_nonces.items() if expiry > now}
                if envelope.nonce in self._seen_nonces:
                    return False
                self._seen_nonces[envelope.nonce] = envelope.expires_at
        return True

    def choose_worker(self, capability: str) -> WorkerLease | None:
        """Choose the least-loaded live worker supporting a capability."""
        self.prune()
        cap = str(capability).strip()
        with self._lock:
            matches = [w for w in self._workers.values() if "*" in w.capabilities or cap in w.capabilities]
            if not matches:
                return None
            chosen = min(matches, key=lambda w: (w.active_tasks, w.worker_id))
            return WorkerLease(chosen.worker_id, chosen.capabilities, dict(chosen.metadata), chosen.last_heartbeat, chosen.active_tasks)

    def dispatch(self, envelope: TaskEnvelope, executor: Callable[[TaskEnvelope], dict[str, Any]]) -> dict[str, Any]:
        """Verify and dispatch a task through the caller's local execution boundary."""
        if not self.verify_task(envelope, consume_nonce=True):
            raise DistributedAuthError("invalid, expired or replayed task envelope")
        worker = self.choose_worker(envelope.capability)
        if worker is None:
            return {"ok": False, "error": "no capable worker available", "task_id": envelope.task_id}
        try:
            result = executor(envelope)
            if not isinstance(result, dict) or "ok" not in result:
                raise ValueError("worker returned invalid result")
            return {**result, "task_id": envelope.task_id, "worker_id": worker.worker_id}
        finally:
            self.heartbeat(worker.worker_id, active_tasks=max(0, worker.active_tasks - 1))

    @staticmethod
    def _validate_remote_endpoint(endpoint: str) -> str:
        """Validate a worker endpoint without following attacker-controlled redirects."""
        parsed = urlparse(str(endpoint).strip())
        if parsed.scheme not in {"https", "http"} or not parsed.hostname:
            raise ValueError("remote worker endpoint must be an absolute HTTP(S) URL")
        if parsed.username or parsed.password or parsed.fragment:
            raise ValueError("remote worker endpoint must not contain credentials or fragments")
        host = parsed.hostname.rstrip(".").lower()
        loopback = host in {"localhost", "127.0.0.1", "::1"}
        if parsed.scheme != "https" and not loopback:
            raise ValueError("remote worker endpoint must use HTTPS unless loopback")
        try:
            addresses = {info[4][0] for info in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)}
        except OSError as exc:
            raise ValueError("remote worker endpoint hostname cannot be resolved") from exc
        for address in addresses:
            ip = ipaddress.ip_address(address)
            if ip.is_link_local or ip.is_unspecified or ip.is_multicast or ip.is_reserved:
                raise ValueError("remote worker endpoint resolves to a disallowed network")
            if (ip.is_private or ip.is_loopback) and not loopback:
                # Private cluster addresses are legitimate, but only as explicit hosts;
                # never permit a public hostname to resolve into a private network.
                if not (parsed.hostname.startswith("10.") or parsed.hostname.startswith("192.168.") or parsed.hostname.startswith("172.")):
                    raise ValueError("remote worker endpoint resolves to a private network")
        return parsed.geturl().rstrip("/")

    def dispatch_remote(self, envelope: TaskEnvelope, endpoint: str, *, bearer_token: str, timeout_seconds: float = 15.0) -> dict[str, Any]:
        """Dispatch a signed tool task to another JARVIS worker over a non-redirecting HTTP(S) channel."""
        endpoint = self._validate_remote_endpoint(endpoint)
        if not bearer_token or len(bearer_token) < 32:
            raise ValueError("worker bearer token must contain at least 32 characters")
        if not self.verify_task(envelope, consume_nonce=True):
            raise DistributedAuthError("invalid, expired or replayed task envelope")
        body = json.dumps(envelope.__dict__, sort_keys=True, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(endpoint + "/cluster/tasks", data=body, method="POST", headers={"Content-Type": "application/json", "Authorization": f"Bearer {bearer_token}"})

        class _NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                raise urllib.error.HTTPError(req.full_url, code, "redirect refused", headers, fp)

        opener = urllib.request.build_opener(_NoRedirect())
        try:
            with opener.open(request, timeout=max(1.0, min(float(timeout_seconds), 60.0))) as response:
                payload = json.loads(response.read(1_000_000).decode("utf-8"))
            if not isinstance(payload, dict) or "ok" not in payload:
                raise ValueError("remote worker returned invalid response")
            return payload
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as exc:
            return {"ok": False, "error": f"remote worker unavailable: {type(exc).__name__}"}

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret cluster state."""
        self.prune()
        with self._lock:
            return {"workers": len(self._workers), "replay_cache": len(self._seen_nonces), "leases": [{"worker_id": w.worker_id, "capabilities": list(w.capabilities), "active_tasks": w.active_tasks} for w in self._workers.values()]}



"""Provider-independent local model fabric for J.A.R.V.I.S."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import time
from typing import Any, Callable, Iterable, Iterator, Mapping, Protocol
from urllib.parse import urlsplit

import httpx

from core.types import BackendResult


class LocalModelBackend(Protocol):
    """Minimal contract implemented by every local inference backend."""

    def generate(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7, stream: bool = False) -> BackendResult | Iterator[str]:
        """Generate through a local backend implementation."""
        raise RuntimeError("local backend protocol method invoked")


@dataclass(frozen=True, slots=True)
class LocalModelProfile:
    """Normalized local model metadata used by the router."""

    name: str
    path: str | None = None
    backend: str = "native"
    capabilities: tuple[str, ...] = ("chat",)
    context_length: int = 4096
    memory_mb: int = 0
    quantization: str = "unknown"
    quality_score: float = 0.5


@dataclass(frozen=True, slots=True)
class LocalModelDecision:
    """Explainable local model selection result."""

    model: str | None
    reason: str
    candidates: tuple[str, ...]


class LocalOnlyOpenAIBackend:
    """Local HTTP inference adapter limited to loopback or private RFC1918 hosts."""

    def __init__(self, base_url: str, *, model: str, timeout_seconds: float = 120.0, allow_private_network: bool = False) -> None:
        parsed = urlsplit(base_url)
        host = parsed.hostname or ""
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("local model endpoint must use http or https")
        allowed = {"127.0.0.1", "localhost", "::1"}
        if allow_private_network:
            import ipaddress

            try:
                ip = ipaddress.ip_address(host)
                if not ip.is_private:
                    raise ValueError("model endpoint must be on a private network")
            except ValueError:
                if host not in allowed and "." not in host:
                    raise ValueError("invalid local model endpoint")
        elif host not in allowed:
            raise ValueError("cloud or non-loopback model endpoint is disabled")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = httpx.Timeout(max(1.0, float(timeout_seconds)))

    def generate(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7, stream: bool = False) -> BackendResult | Iterator[str]:
        """Generate text from a local OpenAI-compatible server."""
        if not str(prompt).strip():
            raise ValueError("prompt is required")
        payload = {"model": self.model, "messages": [{"role": "user", "content": str(prompt)}], "max_tokens": int(max_tokens), "temperature": float(temperature), "stream": bool(stream)}
        if stream:
            return self._stream(payload)
        started = time.perf_counter()
        with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
            response = client.post(f"{self.base_url}/chat/completions", json=payload)
            response.raise_for_status()
            data = response.json()
        text = str(data.get("choices", [{}])[0].get("message", {}).get("content", ""))
        usage = data.get("usage", {}) if isinstance(data, dict) else {}
        return BackendResult(text=text, model=self.model, backend="local-openai-compatible", prompt_tokens=int(usage.get("prompt_tokens", 0) or 0), completion_tokens=int(usage.get("completion_tokens", 0) or 0), tokens_used=int(usage.get("completion_tokens", 0) or 0), latency_ms=(time.perf_counter() - started) * 1000.0)

    def _stream(self, payload: Mapping[str, Any]) -> Iterator[str]:
        """Yield SSE data chunks from the local endpoint."""
        with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
            with client.stream("POST", f"{self.base_url}/chat/completions", json=dict(payload)) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    if not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if raw == "[DONE]":
                        break
                    try:
                        item = json.loads(raw)
                        yield str(item.get("choices", [{}])[0].get("delta", {}).get("content", ""))
                    except json.JSONDecodeError:
                        continue


class LocalModelFabric:
    """Discover, register, score and resolve local-only model backends."""

    _SAFE_MODEL = re.compile(r"^[A-Za-z0-9_.:/@+-]{1,160}$")

    def __init__(self, model_dirs: Iterable[str | Path] = (), *, memory_provider: Callable[[], int] | None = None) -> None:
        self.model_dirs = tuple(Path(p).expanduser().resolve() for p in model_dirs)
        self.memory_provider = memory_provider
        self._profiles: dict[str, LocalModelProfile] = {}
        self._backends: dict[str, LocalModelBackend] = {}

    def discover_gguf(self) -> tuple[LocalModelProfile, ...]:
        """Discover bounded GGUF files without loading them."""
        discovered: dict[str, LocalModelProfile] = {}
        for root in self.model_dirs:
            if not root.is_dir():
                continue
            for path in root.rglob("*.gguf"):
                try:
                    size = path.stat().st_size
                except OSError:
                    continue
                if not path.is_file() or size <= 0:
                    continue
                name = path.stem
                discovered[name] = LocalModelProfile(name=name, path=str(path), backend="native", memory_mb=max(1, int(size / 1_048_576)), capabilities=("chat", "general"), context_length=4096, quality_score=0.75)
        for profile in discovered.values():
            self.register(profile, None)
        return tuple(sorted(discovered.values(), key=lambda item: item.name))

    def register(self, profile: LocalModelProfile, backend: LocalModelBackend | None) -> None:
        """Register a local model profile and optional backend."""
        if not self._SAFE_MODEL.fullmatch(profile.name):
            raise ValueError("invalid local model name")
        if profile.memory_mb < 0 or profile.context_length < 1:
            raise ValueError("invalid model resource metadata")
        self._profiles[profile.name] = profile
        if backend is not None:
            self._backends[profile.name] = backend

    def attach(self, name: str, backend: LocalModelBackend) -> None:
        """Attach a backend to an already registered model."""
        if name not in self._profiles:
            raise KeyError(name)
        self._backends[name] = backend

    def choose(self, *, required_capabilities: Iterable[str] = (), max_memory_mb: int | None = None, preferred: str | None = None) -> LocalModelDecision:
        """Select the best locally registered model under hard constraints."""
        required = set(str(item) for item in required_capabilities)
        candidates = []
        available_memory = max_memory_mb
        if available_memory is None and self.memory_provider is not None:
            try:
                available_memory = int(self.memory_provider())
            except (TypeError, ValueError):
                available_memory = None
        for name, profile in self._profiles.items():
            if not required.issubset(set(profile.capabilities)):
                continue
            if available_memory is not None and profile.memory_mb and profile.memory_mb > available_memory:
                continue
            candidates.append(profile)
        candidates.sort(key=lambda item: (item.name == preferred, item.quality_score, -item.memory_mb), reverse=True)
        names = tuple(item.name for item in candidates)
        if not names:
            return LocalModelDecision(None, "no local model satisfies constraints", ())
        return LocalModelDecision(names[0], "highest local quality under constraints", names)

    def get_backend(self, name: str) -> LocalModelBackend:
        """Return an attached backend or raise a descriptive error."""
        try:
            return self._backends[name]
        except KeyError as exc:
            raise RuntimeError(f"local backend is not attached: {name}") from exc

    def profiles(self) -> tuple[LocalModelProfile, ...]:
        """Return deterministic local model profiles."""
        return tuple(self._profiles[name] for name in sorted(self._profiles))



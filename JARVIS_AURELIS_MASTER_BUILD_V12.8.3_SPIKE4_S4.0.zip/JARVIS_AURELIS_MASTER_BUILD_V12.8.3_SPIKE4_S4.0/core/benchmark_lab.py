"""Deterministic benchmark registry and regression comparison utility."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import json
from pathlib import Path
import statistics
import time
from typing import Any, Callable, Iterable


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    """One bounded benchmark result."""

    benchmark_id: str
    iterations: int
    duration_ms: float
    success_count: int
    failure_count: int
    metadata: dict[str, Any]

    @property
    def success_rate(self) -> float:
        """Return successful iteration ratio."""
        return self.success_count / max(1, self.iterations)


class BenchmarkLab:
    """Run deterministic bounded workloads and persist comparable results."""

    def __init__(self, path: str | Path, *, max_iterations: int = 1000) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_iterations = max(1, min(int(max_iterations), 100_000))

    def run(self, benchmark_id: str, fn: Callable[[int], Any], *, iterations: int = 10) -> BenchmarkResult:
        """Execute a bounded benchmark function and record aggregate timing."""
        count = max(1, min(int(iterations), self.max_iterations))
        failures = 0
        durations: list[float] = []
        for index in range(count):
            started = time.perf_counter()
            try:
                fn(index)
            except Exception:
                failures += 1
            durations.append((time.perf_counter() - started) * 1000.0)
        result = BenchmarkResult(str(benchmark_id), count, statistics.fmean(durations) if durations else 0.0, count - failures, failures, {"p50_ms": statistics.median(durations) if durations else 0.0, "max_ms": max(durations) if durations else 0.0})
        self._append(result)
        return result

    def _append(self, result: BenchmarkResult) -> None:
        rows: list[dict[str, Any]] = []
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                rows = raw if isinstance(raw, list) else []
            except (OSError, ValueError, TypeError):
                rows = []
        rows.append(asdict(result))
        rows = rows[-10_000:]
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(rows, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)

    def latest(self, benchmark_id: str) -> BenchmarkResult | None:
        """Return the latest result for one benchmark."""
        if not self.path.exists():
            return None
        try:
            rows = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return None
        matches = [item for item in rows if isinstance(item, dict) and item.get("benchmark_id") == benchmark_id]
        if not matches:
            return None
        item = matches[-1]
        return BenchmarkResult(str(item["benchmark_id"]), int(item["iterations"]), float(item["duration_ms"]), int(item["success_count"]), int(item["failure_count"]), dict(item.get("metadata", {})))

"""State-of-the-art reliability, identity, observability, and optimization fabric.

This module provides bounded, standard-library-first primitives that connect the
existing JARVIS security, mission, model, tool, device, and telemetry systems.
The primitives deliberately expose policy and verification hooks instead of
performing privileged work themselves.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sqlite3
import threading
import time
import uuid
from collections import OrderedDict, deque
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class AgentCredential:
    """Short-lived signed identity credential for an agent or service."""

    credential_id: str
    subject: str
    issuer: str
    capabilities: tuple[str, ...]
    issued_at: float
    expires_at: float
    audience: str
    nonce: str
    signature: str


class AgentIdentityAuthority:
    """Issue and verify short-lived capability credentials using HMAC-SHA256."""

    def __init__(self, secret: bytes | None = None, *, issuer: str = "jarvis-identity") -> None:
        self._secret = bytes(secret or secrets.token_bytes(32))
        if len(self._secret) < 32:
            raise ValueError("identity secret must be at least 32 bytes")
        self.issuer = str(issuer).strip() or "jarvis-identity"
        self._revoked: set[str] = set()
        self._lock = threading.RLock()

    @staticmethod
    def _canonical(
        credential_id: str,
        subject: str,
        issuer: str,
        capabilities: Sequence[str],
        issued_at: float,
        expires_at: float,
        audience: str,
        nonce: str,
    ) -> bytes:
        payload = {
            "credential_id": credential_id,
            "subject": subject,
            "issuer": issuer,
            "capabilities": sorted(set(str(item) for item in capabilities)),
            "issued_at": round(float(issued_at), 6),
            "expires_at": round(float(expires_at), 6),
            "audience": audience,
            "nonce": nonce,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _sign(self, payload: bytes) -> str:
        return hmac.new(self._secret, payload, hashlib.sha256).hexdigest()

    def issue(
        self,
        subject: str,
        capabilities: Iterable[str],
        *,
        ttl_seconds: float = 300.0,
        audience: str = "jarvis",
    ) -> AgentCredential:
        """Issue a bounded credential with sorted de-duplicated capabilities."""
        name = str(subject).strip()
        if not name:
            raise ValueError("subject is required")
        ttl = max(1.0, min(float(ttl_seconds), 86_400.0))
        now = time.time()
        capability_set = tuple(sorted(set(str(item).strip() for item in capabilities if str(item).strip())))
        credential_id = f"cred_{uuid.uuid4().hex}"
        nonce = secrets.token_urlsafe(18)
        signature = self._sign(self._canonical(credential_id, name, self.issuer, capability_set, now, now + ttl, str(audience), nonce))
        return AgentCredential(credential_id, name, self.issuer, capability_set, now, now + ttl, str(audience), nonce, signature)

    def revoke(self, credential_id: str) -> None:
        """Revoke one credential by ID."""
        with self._lock:
            self._revoked.add(str(credential_id))

    def verify(self, credential: AgentCredential, *, capability: str | None = None, audience: str = "jarvis", now: float | None = None) -> bool:
        """Verify issuer, signature, lifetime, revocation, audience, and optional capability."""
        current = time.time() if now is None else float(now)
        if credential.issuer != self.issuer or credential.audience != str(audience):
            return False
        if credential.expires_at <= current or credential.issued_at - 30.0 > current:
            return False
        with self._lock:
            if credential.credential_id in self._revoked:
                return False
        expected = self._sign(self._canonical(credential.credential_id, credential.subject, credential.issuer, credential.capabilities, credential.issued_at, credential.expires_at, credential.audience, credential.nonce))
        if not hmac.compare_digest(expected, credential.signature):
            return False
        return capability is None or capability in credential.capabilities or "*" in credential.capabilities

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret authority state."""
        with self._lock:
            return {"issuer": self.issuer, "revoked": len(self._revoked)}


class DurableMissionStore:
    """SQLite-backed mission/checkpoint store with atomic commits and recovery."""

    def __init__(self, path: str = "data/frontier_missions.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS missions (
                mission_id TEXT PRIMARY KEY,
                state TEXT NOT NULL,
                payload TEXT NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS checkpoints (
                mission_id TEXT NOT NULL,
                sequence INTEGER NOT NULL,
                state TEXT NOT NULL,
                digest TEXT NOT NULL,
                created_at REAL NOT NULL,
                PRIMARY KEY (mission_id, sequence),
                FOREIGN KEY (mission_id) REFERENCES missions(mission_id) ON DELETE CASCADE
            );
            """
        )
        self._db.commit()

    @staticmethod
    def _json(value: Mapping[str, Any]) -> str:
        return json.dumps(dict(value), sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _digest(payload: str) -> str:
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def upsert(self, mission_id: str, state: str, payload: Mapping[str, Any]) -> None:
        """Atomically persist the latest mission state."""
        mid = str(mission_id).strip()
        status = str(state).strip()
        if not mid or not status:
            raise ValueError("mission_id and state are required")
        encoded = self._json(payload)
        with self._lock:
            self._db.execute(
                "INSERT INTO missions(mission_id,state,payload,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(mission_id) DO UPDATE SET state=excluded.state,payload=excluded.payload,updated_at=excluded.updated_at",
                (mid, status, encoded, time.time()),
            )
            self._db.commit()

    def checkpoint(self, mission_id: str, state: Mapping[str, Any]) -> int:
        """Persist an integrity-addressed checkpoint and return its sequence."""
        mid = str(mission_id).strip()
        if not mid:
            raise ValueError("mission_id is required")
        encoded = self._json(state)
        with self._lock:
            row = self._db.execute("SELECT COALESCE(MAX(sequence),0) FROM checkpoints WHERE mission_id=?", (mid,)).fetchone()
            sequence = int(row[0] or 0) + 1
            self._db.execute(
                "INSERT INTO missions(mission_id,state,payload,updated_at) VALUES(?,?,?,?) ON CONFLICT(mission_id) DO NOTHING",
                (mid, "checkpointed", encoded, time.time()),
            )
            self._db.execute(
                "INSERT INTO checkpoints(mission_id,sequence,state,digest,created_at) VALUES(?,?,?,?,?)",
                (mid, sequence, encoded, self._digest(encoded), time.time()),
            )
            self._db.commit()
            return sequence

    def restore(self, mission_id: str, sequence: int | None = None) -> dict[str, Any]:
        """Restore and verify the selected or latest checkpoint."""
        mid = str(mission_id)
        with self._lock:
            if sequence is None:
                row = self._db.execute("SELECT sequence,state,digest FROM checkpoints WHERE mission_id=? ORDER BY sequence DESC LIMIT 1", (mid,)).fetchone()
            else:
                row = self._db.execute("SELECT sequence,state,digest FROM checkpoints WHERE mission_id=? AND sequence=?", (mid, int(sequence))).fetchone()
        if row is None:
            raise KeyError(mission_id)
        raw = str(row[1])
        if not hmac.compare_digest(self._digest(raw), str(row[2])):
            raise ValueError("checkpoint integrity failure")
        return {"mission_id": mid, "sequence": int(row[0]), "state": json.loads(raw)}

    def snapshot(self) -> dict[str, Any]:
        """Return store health and counts."""
        with self._lock:
            missions = int(self._db.execute("SELECT COUNT(*) FROM missions").fetchone()[0])
            checkpoints = int(self._db.execute("SELECT COUNT(*) FROM checkpoints").fetchone()[0])
        return {"path": str(self.path), "missions": missions, "checkpoints": checkpoints}

    def close(self) -> None:
        """Flush and close the SQLite connection."""
        with self._lock:
            self._db.commit()
            self._db.close()


@dataclass(frozen=True, slots=True)
class MCPTask:
    """Durable MCP-style task record."""

    task_id: str
    name: str
    state: str
    input: Mapping[str, Any]
    output: Mapping[str, Any] | None
    created_at: float
    updated_at: float
    expires_at: float


class MCPTaskRegistry:
    """Bounded task lifecycle registry for modern stateless MCP integrations."""

    STATES = {"pending", "running", "completed", "failed", "cancelled", "expired"}

    def __init__(self, *, max_tasks: int = 10_000) -> None:
        self.max_tasks = max(1, min(int(max_tasks), 100_000))
        self._tasks: OrderedDict[str, MCPTask] = OrderedDict()
        self._lock = threading.RLock()

    def create(self, name: str, payload: Mapping[str, Any], *, ttl_seconds: float = 3600.0) -> MCPTask:
        """Create a pending task with a bounded lifetime."""
        title = str(name).strip()
        if not title:
            raise ValueError("task name is required")
        now = time.time()
        task = MCPTask(f"task_{uuid.uuid4().hex}", title, "pending", dict(payload), None, now, now, now + max(1.0, min(float(ttl_seconds), 7 * 86400.0)))
        with self._lock:
            while len(self._tasks) >= self.max_tasks:
                self._tasks.popitem(last=False)
            self._tasks[task.task_id] = task
        return task

    def transition(self, task_id: str, state: str, output: Mapping[str, Any] | None = None) -> MCPTask:
        """Transition a task using a strict lifecycle and expiry check."""
        target = str(state).strip().lower()
        if target not in self.STATES:
            raise ValueError("invalid task state")
        with self._lock:
            task = self._tasks.get(str(task_id))
            if task is None:
                raise KeyError(task_id)
            now = time.time()
            if now >= task.expires_at and target not in {"expired", "cancelled"}:
                target = "expired"
            valid = {
                "pending": {"running", "cancelled", "expired"},
                "running": {"completed", "failed", "cancelled", "expired"},
                "completed": set(),
                "failed": {"pending"},
                "cancelled": set(),
                "expired": set(),
            }
            if target != task.state and target not in valid[task.state]:
                raise ValueError(f"invalid task transition: {task.state}->{target}")
            updated = MCPTask(task.task_id, task.name, target, task.input, dict(output) if output is not None else task.output, task.created_at, now, task.expires_at)
            self._tasks[task.task_id] = updated
            self._tasks.move_to_end(task.task_id)
            return updated

    def get(self, task_id: str) -> MCPTask:
        """Return one task, marking it expired when necessary."""
        with self._lock:
            task = self._tasks.get(str(task_id))
        if task is None:
            raise KeyError(task_id)
        if time.time() >= task.expires_at and task.state in {"pending", "running"}:
            return self.transition(task.task_id, "expired")
        return task

    def snapshot(self) -> dict[str, Any]:
        """Return task counts by lifecycle state."""
        with self._lock:
            counts = {state: 0 for state in sorted(self.STATES)}
            for task in self._tasks.values():
                counts[task.state] += 1
            return {"tasks": len(self._tasks), "states": counts, "max_tasks": self.max_tasks}


@dataclass(frozen=True, slots=True)
class TraceRecord:
    """Tamper-evident operational trace record."""

    trace_id: str
    parent_id: str | None
    event: str
    data: Mapping[str, Any]
    timestamp: float
    previous_hash: str
    digest: str


class BlackBoxRecorder:
    """Bounded in-memory operational recorder with hash chaining."""

    def __init__(self, *, max_records: int = 50_000) -> None:
        self.max_records = max(1, min(int(max_records), 500_000))
        self._records: deque[TraceRecord] = deque(maxlen=self.max_records)
        self._previous_hash = "0" * 64
        self._lock = threading.RLock()

    def record(self, event: str, data: Mapping[str, Any] | None = None, *, parent_id: str | None = None) -> TraceRecord:
        """Append a trace event with canonical JSON hashing."""
        title = str(event).strip()
        if not title:
            raise ValueError("event is required")
        now = time.time()
        trace_id = uuid.uuid4().hex
        safe = dict(data or {})
        canonical = json.dumps({"trace_id": trace_id, "parent_id": parent_id, "event": title, "data": safe, "timestamp": round(now, 6), "previous_hash": self._previous_hash}, sort_keys=True, default=str, separators=(",", ":"))
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        record = TraceRecord(trace_id, parent_id, title, safe, now, self._previous_hash, digest)
        with self._lock:
            self._records.append(record)
            self._previous_hash = digest
        return record

    def verify(self) -> bool:
        """Verify the entire retained trace chain."""
        with self._lock:
            previous = "0" * 64
            for item in self._records:
                canonical = json.dumps({"trace_id": item.trace_id, "parent_id": item.parent_id, "event": item.event, "data": dict(item.data), "timestamp": round(item.timestamp, 6), "previous_hash": previous}, sort_keys=True, default=str, separators=(",", ":"))
                expected = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
                if item.previous_hash != previous or not hmac.compare_digest(expected, item.digest):
                    return False
                previous = item.digest
            return previous == self._previous_hash

    def snapshot(self) -> dict[str, Any]:
        """Return recorder state."""
        with self._lock:
            return {"records": len(self._records), "head": self._previous_hash, "valid": self.verify()}


class ToolResultVerifier:
    """Validate tool outputs before they become trusted application state."""

    def verify(self, result: Any, *, required_keys: Iterable[str] = (), predicate: Callable[[Any], bool] | None = None) -> dict[str, Any]:
        """Return a normalized verification report for a tool result."""
        keys = tuple(str(key) for key in required_keys)
        if isinstance(result, Mapping):
            missing = tuple(key for key in keys if key not in result)
            structurally_valid = not missing
        else:
            missing = keys
            structurally_valid = not keys
        custom_valid = True if predicate is None else bool(predicate(result))
        return {"ok": structurally_valid and custom_valid, "structural": structurally_valid, "custom": custom_valid, "missing_keys": list(missing), "result_type": type(result).__name__}


class SemanticCache:
    """TTL semantic-key cache with bounded LRU eviction and freshness controls."""

    def __init__(
        self, *, max_entries: int = 2048, default_ttl_seconds: float = 300.0
    ) -> None:
        self.max_entries = max(1, min(int(max_entries), 100_000))
        self.default_ttl_seconds = max(1.0, min(float(default_ttl_seconds), 86_400.0))
        self._cache: OrderedDict[str, tuple[Any, float, str, float]] = OrderedDict()
        self._lock = threading.RLock()

    @staticmethod
    def key(text: str, context: Mapping[str, Any] | None = None) -> str:
        """Create a stable semantic-operation fingerprint from normalized text/context."""
        normalized = " ".join(str(text).strip().lower().split())
        material = json.dumps(
            {"text": normalized, "context": dict(context or {})},
            sort_keys=True,
            default=str,
            separators=(",", ":"),
        )
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def get(
        self,
        text: str,
        context: Mapping[str, Any] | None = None,
        *,
        max_age_seconds: float | None = None,
    ) -> Any | None:
        """Return a fresh cached value or None."""
        key = self.key(text, context)
        with self._lock:
            item = self._cache.get(key)
            if item is None:
                return None
            value, created, _, item_ttl = item
            limit = (
                item_ttl
                if max_age_seconds is None
                else max(0.0, float(max_age_seconds))
            )
            if time.time() - created >= limit:
                self._cache.pop(key, None)
                return None
            self._cache.move_to_end(key)
            return value

    def set(
        self,
        text: str,
        value: Any,
        context: Mapping[str, Any] | None = None,
        *,
        ttl_seconds: float | None = None,
        source_hash: str = "",
    ) -> str:
        """Store one bounded cache item and return its key."""
        ttl = (
            self.default_ttl_seconds
            if ttl_seconds is None
            else max(1.0, min(float(ttl_seconds), 86_400.0))
        )
        key = self.key(text, context)
        with self._lock:
            while len(self._cache) >= self.max_entries:
                self._cache.popitem(last=False)
            self._cache[key] = (value, time.time(), str(source_hash), ttl)
        return key

    def clear(self) -> None:
        """Clear all entries."""
        with self._lock:
            self._cache.clear()

    def snapshot(self) -> dict[str, Any]:
        """Return cache metrics."""
        with self._lock:
            return {"entries": len(self._cache), "max_entries": self.max_entries}


@dataclass(frozen=True, slots=True)
class CacheLease:
    """Tracked model context/KV cache lease."""

    key: str
    model: str
    memory_mb: int
    created_at: float
    last_used: float
    pinned: bool


class KVCacheRegistry:
    """Model-agnostic context cache accounting and LRU admission planner."""

    def __init__(self, *, max_memory_mb: int = 4096) -> None:
        self.max_memory_mb = max(64, min(int(max_memory_mb), 1_048_576))
        self._items: OrderedDict[str, CacheLease] = OrderedDict()
        self._lock = threading.RLock()

    @property
    def used_memory_mb(self) -> int:
        """Return tracked memory usage."""
        with self._lock:
            return sum(item.memory_mb for item in self._items.values())

    def admit(self, key: str, model: str, memory_mb: int, *, pinned: bool = False) -> CacheLease:
        """Admit a cache lease or reject if pinned entries prevent capacity."""
        memory = max(1, int(memory_mb))
        if memory > self.max_memory_mb:
            raise ValueError("cache lease exceeds total capacity")
        now = time.time()
        with self._lock:
            self._items.pop(str(key), None)
            while self.used_memory_mb + memory > self.max_memory_mb:
                candidates = [item for item in self._items.values() if not item.pinned]
                if not candidates:
                    raise MemoryError("no evictable KV cache capacity")
                victim = min(candidates, key=lambda item: (item.last_used, item.key))
                self._items.pop(victim.key, None)
            lease = CacheLease(str(key), str(model), memory, now, now, bool(pinned))
            self._items[lease.key] = lease
            return lease

    def touch(self, key: str) -> CacheLease:
        """Mark a lease recently used."""
        with self._lock:
            item = self._items.get(str(key))
            if item is None:
                raise KeyError(key)
            updated = CacheLease(item.key, item.model, item.memory_mb, item.created_at, time.time(), item.pinned)
            self._items[item.key] = updated
            self._items.move_to_end(item.key)
            return updated

    def release(self, key: str) -> bool:
        """Release one cache lease."""
        with self._lock:
            return self._items.pop(str(key), None) is not None

    def snapshot(self) -> dict[str, Any]:
        """Return cache residency information."""
        with self._lock:
            return {"used_memory_mb": self.used_memory_mb, "capacity_mb": self.max_memory_mb, "leases": [asdict(item) for item in self._items.values()]}


@dataclass(frozen=True, slots=True)
class ScheduleCandidate:
    """Normalized candidate for adaptive scheduling."""

    candidate_id: str
    quality: float
    latency_ms: float
    memory_mb: float
    power_watts: float
    risk: float
    success_rate: float


class AdaptiveResourceScheduler:
    """Multi-objective scheduler for quality, speed, resources, power, and safety."""

    def choose(self, candidates: Iterable[ScheduleCandidate], *, latency_weight: float = 0.20, quality_weight: float = 0.40, memory_weight: float = 0.10, power_weight: float = 0.05, risk_weight: float = 0.15, success_weight: float = 0.10, max_memory_mb: float | None = None, max_latency_ms: float | None = None) -> ScheduleCandidate:
        """Choose the highest-scoring candidate under explicit resource bounds."""
        rows = tuple(candidates)
        if not rows:
            raise ValueError("at least one candidate is required")
        total = max(0.0001, float(quality_weight + latency_weight + memory_weight + power_weight + risk_weight + success_weight))
        filtered = tuple(row for row in rows if (max_memory_mb is None or row.memory_mb <= float(max_memory_mb)) and (max_latency_ms is None or row.latency_ms <= float(max_latency_ms)))
        pool = filtered or rows
        max_latency = max(1.0, max(row.latency_ms for row in pool))
        max_memory = max(1.0, max(row.memory_mb for row in pool))
        max_power = max(1.0, max(row.power_watts for row in pool))
        def score(item: ScheduleCandidate) -> float:
            return (
                quality_weight * max(0.0, min(1.0, item.quality))
                + success_weight * max(0.0, min(1.0, item.success_rate))
                + latency_weight * (1.0 - min(1.0, max(0.0, item.latency_ms) / max_latency))
                + memory_weight * (1.0 - min(1.0, max(0.0, item.memory_mb) / max_memory))
                + power_weight * (1.0 - min(1.0, max(0.0, item.power_watts) / max_power))
                + risk_weight * (1.0 - max(0.0, min(1.0, item.risk)))
            ) / total
        return max(pool, key=lambda item: (score(item), item.quality, item.success_rate, -item.latency_ms, item.candidate_id))


class ShortLivedSecretBroker:
    """Issue single-purpose in-memory secret handles without exposing raw values in logs."""

    def __init__(self, *, max_secrets: int = 1024) -> None:
        self.max_secrets = max(1, min(int(max_secrets), 100_000))
        self._items: OrderedDict[str, tuple[bytes, float, str]] = OrderedDict()
        self._lock = threading.RLock()

    def issue(self, name: str, secret: bytes, *, ttl_seconds: float = 300.0) -> str:
        """Store a short-lived secret and return its opaque handle."""
        label = str(name).strip()
        raw = bytes(secret)
        if not label or not raw:
            raise ValueError("name and secret are required")
        handle = f"secret_{secrets.token_urlsafe(20)}"
        with self._lock:
            while len(self._items) >= self.max_secrets:
                self._items.popitem(last=False)
            self._items[handle] = (raw, time.time() + max(1.0, min(float(ttl_seconds), 3600.0)), label)
        return handle

    def consume(self, handle: str, *, expected_name: str | None = None) -> bytes:
        """Atomically consume a valid secret handle exactly once."""
        with self._lock:
            item = self._items.pop(str(handle), None)
        if item is None:
            raise KeyError(handle)
        secret, expires, name = item
        if time.time() >= expires:
            raise PermissionError("secret handle expired")
        if expected_name is not None and name != str(expected_name):
            raise PermissionError("secret handle audience mismatch")
        return bytes(secret)

    def snapshot(self) -> dict[str, Any]:
        """Return only non-sensitive inventory information."""
        with self._lock:
            now = time.time()
            return {"active_handles": sum(1 for _, expires, _ in self._items.values() if expires > now), "max_secrets": self.max_secrets}


@dataclass(frozen=True, slots=True)
class AutomationRule:
    """Safe event-driven automation rule."""

    rule_id: str
    event: str
    action: str
    enabled: bool
    created_at: float


class AutomationRuleEngine:
    """Bounded declarative automation registry; side effects are injected as callbacks."""

    def __init__(self, *, max_rules: int = 2048) -> None:
        self.max_rules = max(1, min(int(max_rules), 100_000))
        self._rules: dict[str, AutomationRule] = {}
        self._lock = threading.RLock()

    def register(self, event: str, action: str, *, enabled: bool = True) -> AutomationRule:
        """Register one deterministic rule."""
        source = str(event).strip()
        operation = str(action).strip()
        if not source or not operation:
            raise ValueError("event and action are required")
        with self._lock:
            if len(self._rules) >= self.max_rules:
                raise ValueError("automation rule capacity exceeded")
            rule = AutomationRule(f"rule_{uuid.uuid4().hex}", source, operation, bool(enabled), time.time())
            self._rules[rule.rule_id] = rule
            return rule

    def matching(self, event: str) -> tuple[AutomationRule, ...]:
        """Return enabled rules matching an exact event."""
        with self._lock:
            return tuple(sorted((item for item in self._rules.values() if item.enabled and item.event == str(event)), key=lambda item: item.rule_id))

    def disable(self, rule_id: str) -> bool:
        """Disable one rule."""
        with self._lock:
            rule = self._rules.get(str(rule_id))
            if rule is None:
                return False
            self._rules[rule.rule_id] = AutomationRule(rule.rule_id, rule.event, rule.action, False, rule.created_at)
            return True

    def snapshot(self) -> dict[str, Any]:
        """Return registered automation count."""
        with self._lock:
            return {"rules": len(self._rules), "enabled": sum(1 for item in self._rules.values() if item.enabled)}


class PrivacyMode:
    """Explicit local-only privacy policy switch."""

    def __init__(self, enabled: bool = False) -> None:
        self._enabled = bool(enabled)
        self._lock = threading.RLock()

    @property
    def enabled(self) -> bool:
        """Return current privacy mode."""
        with self._lock:
            return self._enabled

    def set(self, enabled: bool) -> None:
        """Enable or disable private mode."""
        with self._lock:
            self._enabled = bool(enabled)

    def allows(self, capability: str) -> bool:
        """Return whether a capability is compatible with privacy mode."""
        if not self.enabled:
            return True
        denied_prefixes = ("cloud.", "remote.", "external.telemetry", "network.public")
        return not str(capability).startswith(denied_prefixes)

    def snapshot(self) -> dict[str, Any]:
        """Return current privacy policy state."""
        return {"enabled": self.enabled, "policy": "local-first" if self.enabled else "normal"}


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    """Reproducible benchmark record."""

    experiment_id: str
    subject: str
    score: float
    latency_ms: float
    memory_mb: float
    tokens_per_second: float
    created_at: float


class BenchmarkRegistry:
    """Bounded benchmark history for router and runtime calibration."""

    def __init__(self, *, max_results: int = 10_000) -> None:
        self.max_results = max(1, min(int(max_results), 100_000))
        self._results: deque[BenchmarkResult] = deque(maxlen=self.max_results)
        self._lock = threading.RLock()

    def record(self, subject: str, *, score: float, latency_ms: float, memory_mb: float, tokens_per_second: float) -> BenchmarkResult:
        """Record a benchmark result with normalized non-negative measurements."""
        item = BenchmarkResult(uuid.uuid4().hex, str(subject).strip(), max(0.0, min(1.0, float(score))), max(0.0, float(latency_ms)), max(0.0, float(memory_mb)), max(0.0, float(tokens_per_second)), time.time())
        if not item.subject:
            raise ValueError("subject is required")
        with self._lock:
            self._results.append(item)
        return item

    def best(self, subject: str) -> BenchmarkResult | None:
        """Return the highest-scoring historical result for one subject."""
        name = str(subject)
        with self._lock:
            rows = [item for item in self._results if item.subject == name]
        return max(rows, key=lambda item: (item.score, item.tokens_per_second, -item.latency_ms), default=None)

    def snapshot(self) -> dict[str, Any]:
        """Return benchmark counts."""
        with self._lock:
            return {"results": len(self._results), "subjects": len({item.subject for item in self._results})}



@dataclass(frozen=True, slots=True)
class AgentMessage:
    """Authenticated agent-to-agent message envelope."""

    message_id: str
    sender: str
    receiver: str
    mission_id: str
    payload: Mapping[str, Any]
    issued_at: float
    expires_at: float
    signature: str


class AgentMessageBus:
    """Bounded authenticated message bus for specialist-agent coordination."""

    def __init__(self, secret: bytes | None = None, *, max_messages: int = 10_000) -> None:
        self._secret = bytes(secret or secrets.token_bytes(32))
        if len(self._secret) < 32:
            raise ValueError("message bus secret must be at least 32 bytes")
        self.max_messages = max(1, min(int(max_messages), 100_000))
        self._messages: deque[AgentMessage] = deque(maxlen=self.max_messages)
        self._lock = threading.RLock()

    def _sign(self, message_id: str, sender: str, receiver: str, mission_id: str, payload: Mapping[str, Any], issued_at: float, expires_at: float) -> str:
        canonical = json.dumps({"message_id": message_id, "sender": sender, "receiver": receiver, "mission_id": mission_id, "payload": dict(payload), "issued_at": round(issued_at, 6), "expires_at": round(expires_at, 6)}, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()

    def send(self, sender: str, receiver: str, mission_id: str, payload: Mapping[str, Any], *, ttl_seconds: float = 300.0) -> AgentMessage:
        """Create, sign, and queue an agent message."""
        source = str(sender).strip()
        target = str(receiver).strip()
        mission = str(mission_id).strip()
        if not source or not target or not mission:
            raise ValueError("sender, receiver, and mission_id are required")
        now = time.time()
        expiry = now + max(1.0, min(float(ttl_seconds), 3600.0))
        message_id = f"msg_{uuid.uuid4().hex}"
        safe_payload = dict(payload)
        signature = self._sign(message_id, source, target, mission, safe_payload, now, expiry)
        message = AgentMessage(message_id, source, target, mission, safe_payload, now, expiry, signature)
        with self._lock:
            self._messages.append(message)
        return message

    def verify(self, message: AgentMessage, *, receiver: str | None = None, now: float | None = None) -> bool:
        """Verify signature, freshness, and optional recipient binding."""
        current = time.time() if now is None else float(now)
        if message.expires_at <= current or (receiver is not None and message.receiver != str(receiver)):
            return False
        expected = self._sign(message.message_id, message.sender, message.receiver, message.mission_id, message.payload, message.issued_at, message.expires_at)
        return hmac.compare_digest(expected, message.signature)

    def consume(self, receiver: str, *, limit: int = 32) -> tuple[AgentMessage, ...]:
        """Return fresh messages addressed to one agent without exposing other recipients."""
        bound = max(1, min(int(limit), 1000))
        with self._lock:
            rows = [item for item in self._messages if item.receiver == str(receiver) and self.verify(item, receiver=receiver)]
        return tuple(rows[-bound:])

    def snapshot(self) -> dict[str, Any]:
        """Return queue metrics."""
        with self._lock:
            return {"queued": len(self._messages), "max_messages": self.max_messages}


@dataclass(frozen=True, slots=True)
class SandboxManifest:
    """Portable least-privilege description for an execution sandbox."""

    name: str
    workspace: str
    read_paths: tuple[str, ...]
    write_paths: tuple[str, ...]
    network_hosts: tuple[str, ...]
    capabilities: tuple[str, ...]
    cpu_limit: float
    memory_mb: int
    gpu_count: int


class SandboxManifestValidator:
    """Validate portable sandbox manifests against hard resource ceilings."""

    def __init__(self, *, max_cpu: float = 64.0, max_memory_mb: int = 131_072, max_gpu: int = 16) -> None:
        self.max_cpu = max(1.0, float(max_cpu))
        self.max_memory_mb = max(64, int(max_memory_mb))
        self.max_gpu = max(0, int(max_gpu))

    def validate(self, manifest: SandboxManifest) -> dict[str, Any]:
        """Return a deterministic manifest validation report."""
        errors: list[str] = []
        if not manifest.name.strip():
            errors.append("name is required")
        if not manifest.workspace.strip():
            errors.append("workspace is required")
        if not 0.0 < manifest.cpu_limit <= self.max_cpu:
            errors.append("cpu_limit exceeds policy")
        if not 64 <= manifest.memory_mb <= self.max_memory_mb:
            errors.append("memory_mb exceeds policy")
        if not 0 <= manifest.gpu_count <= self.max_gpu:
            errors.append("gpu_count exceeds policy")
        if any(".." in path.replace("\\", "/").split("/") for path in (*manifest.read_paths, *manifest.write_paths)):
            errors.append("path traversal is forbidden")
        if any(not host.strip() for host in manifest.network_hosts):
            errors.append("blank network host is forbidden")
        return {"ok": not errors, "errors": errors, "name": manifest.name}


@dataclass(frozen=True, slots=True)
class GenAISpan:
    """Privacy-preserving GenAI operation span using OpenTelemetry-style attributes."""

    span_id: str
    operation: str
    model: str
    agent_id: str | None
    input_tokens: int
    output_tokens: int
    duration_ms: float
    error_type: str | None
    started_at: float


class GenAITelemetry:
    """Bounded local GenAI telemetry registry with stable semantic attributes."""

    def __init__(self, *, max_spans: int = 10_000) -> None:
        self.max_spans = max(1, min(int(max_spans), 100_000))
        self._spans: deque[GenAISpan] = deque(maxlen=self.max_spans)
        self._lock = threading.RLock()

    def record(self, operation: str, model: str, *, input_tokens: int = 0, output_tokens: int = 0, duration_ms: float = 0.0, agent_id: str | None = None, error_type: str | None = None) -> GenAISpan:
        """Record GenAI metadata without retaining message content."""
        item = GenAISpan(uuid.uuid4().hex, str(operation).strip(), str(model).strip(), str(agent_id) if agent_id else None, max(0, int(input_tokens)), max(0, int(output_tokens)), max(0.0, float(duration_ms)), str(error_type) if error_type else None, time.time())
        if not item.operation or not item.model:
            raise ValueError("operation and model are required")
        with self._lock:
            self._spans.append(item)
        return item

    def snapshot(self) -> dict[str, Any]:
        """Return safe aggregate GenAI telemetry."""
        with self._lock:
            spans = list(self._spans)
        return {"spans": len(spans), "input_tokens": sum(item.input_tokens for item in spans), "output_tokens": sum(item.output_tokens for item in spans), "errors": sum(1 for item in spans if item.error_type)}


@dataclass(frozen=True, slots=True)
class InferencePlan:
    """Engine-neutral inference strategy plan."""

    mode: str
    draft_model: str | None
    verifier_model: str
    prefill_node: str | None
    decode_node: str | None
    rationale: str


class InferenceStrategyPlanner:
    """Select speculative/disaggregated inference strategies without tying JARVIS to an engine."""

    def choose(self, verifier_model: str, *, draft_model: str | None = None, prefill_node: str | None = None, decode_node: str | None = None, prefer_latency: bool = True) -> InferencePlan:
        """Build a validated inference plan."""
        verifier = str(verifier_model).strip()
        if not verifier:
            raise ValueError("verifier_model is required")
        if draft_model and draft_model.strip() == verifier:
            raise ValueError("draft_model must differ from verifier_model")
        if draft_model:
            mode = "speculative"
        elif prefill_node and decode_node and prefill_node != decode_node:
            mode = "disaggregated"
        else:
            mode = "standard"
        rationale = "prefer reduced time-to-first-token" if prefer_latency else "prefer simple predictable execution"
        return InferencePlan(mode, str(draft_model).strip() if draft_model else None, verifier, str(prefill_node).strip() if prefill_node else None, str(decode_node).strip() if decode_node else None, rationale)


@dataclass(frozen=True, slots=True)
class PluginAdmission:
    """Verified plugin admission record."""

    plugin_id: str
    content_hash: str
    capabilities: tuple[str, ...]
    runtime: str
    admitted: bool


class WasmPluginAdmission:
    """Validate WASM skill metadata and bytes before an external runtime can execute them."""

    def __init__(self, *, allowed_runtimes: Iterable[str] = ("wasm", "wasm32-wasi"), allowed_capabilities: Iterable[str] = ()) -> None:
        self.allowed_runtimes = frozenset(str(item) for item in allowed_runtimes)
        self.allowed_capabilities = frozenset(str(item) for item in allowed_capabilities)

    def admit(self, plugin_id: str, payload: bytes, *, runtime: str, capabilities: Iterable[str]) -> PluginAdmission:
        """Admit a plugin only when its runtime, capabilities, and binary hash are allowed."""
        pid = str(plugin_id).strip()
        rt = str(runtime).strip()
        caps = tuple(sorted(set(str(item).strip() for item in capabilities if str(item).strip())))
        if not pid or not payload:
            raise ValueError("plugin_id and payload are required")
        admitted = rt in self.allowed_runtimes and set(caps).issubset(self.allowed_capabilities)
        return PluginAdmission(pid, hashlib.sha256(payload).hexdigest(), caps, rt, admitted)


class DisasterRecoveryCatalog:
    """Catalog verified recovery artifacts and their integrity hashes."""

    def __init__(self) -> None:
        self._items: dict[str, tuple[float, str, str]] = {}
        self._lock = threading.RLock()

    def register(self, artifact_id: str, path: str, content: bytes) -> str:
        """Register an artifact by hash without storing its content."""
        aid = str(artifact_id).strip()
        if not aid:
            raise ValueError("artifact_id is required")
        digest = hashlib.sha256(bytes(content)).hexdigest()
        with self._lock:
            self._items[aid] = (time.time(), str(path), digest)
        return digest

    def verify(self, artifact_id: str, content: bytes) -> bool:
        """Verify artifact content against the registered digest."""
        with self._lock:
            item = self._items.get(str(artifact_id))
        return item is not None and hmac.compare_digest(item[2], hashlib.sha256(bytes(content)).hexdigest())

    def snapshot(self) -> dict[str, Any]:
        """Return artifact count."""
        with self._lock:
            return {"artifacts": len(self._items)}


class FrontierFabric:
    """Integrated facade for the frontier reliability and intelligence primitives."""

    def __init__(self, *, state_root: str = "data", identity_secret: bytes | None = None) -> None:
        root = Path(state_root)
        root.mkdir(parents=True, exist_ok=True)
        self.identity = AgentIdentityAuthority(identity_secret)
        self.missions = DurableMissionStore(str(root / "frontier_missions.db"))
        self.mcp_tasks = MCPTaskRegistry()
        self.black_box = BlackBoxRecorder()
        self.verifier = ToolResultVerifier()
        self.semantic_cache = SemanticCache()
        self.kv_cache = KVCacheRegistry()
        self.scheduler = AdaptiveResourceScheduler()
        self.secrets = ShortLivedSecretBroker()
        self.automation = AutomationRuleEngine()
        self.privacy = PrivacyMode()
        self.benchmarks = BenchmarkRegistry()
        self.messages = AgentMessageBus(self.identity._secret)
        self.sandbox_manifests = SandboxManifestValidator()
        self.genai_telemetry = GenAITelemetry()
        self.inference_planner = InferenceStrategyPlanner()
        self.wasm_admission = WasmPluginAdmission(allowed_capabilities=("tools.read", "memory.read"))
        self.recovery_catalog = DisasterRecoveryCatalog()

    def health(self) -> dict[str, Any]:
        """Return a non-sensitive health snapshot of the full frontier fabric."""
        return {
            "identity": self.identity.snapshot(),
            "missions": self.missions.snapshot(),
            "mcp_tasks": self.mcp_tasks.snapshot(),
            "black_box": self.black_box.snapshot(),
            "semantic_cache": self.semantic_cache.snapshot(),
            "kv_cache": self.kv_cache.snapshot(),
            "secrets": self.secrets.snapshot(),
            "automation": self.automation.snapshot(),
            "privacy": self.privacy.snapshot(),
            "benchmarks": self.benchmarks.snapshot(),
            "messages": self.messages.snapshot(),
            "genai_telemetry": self.genai_telemetry.snapshot(),
            "recovery_catalog": self.recovery_catalog.snapshot(),
        }

    def close(self) -> None:
        """Close persistent frontier resources."""
        self.missions.close()



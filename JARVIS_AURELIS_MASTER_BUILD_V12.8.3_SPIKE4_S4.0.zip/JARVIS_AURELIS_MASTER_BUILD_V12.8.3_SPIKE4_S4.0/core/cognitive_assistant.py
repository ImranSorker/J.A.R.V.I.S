"""Evidence-aware real-time assistant for situational and wellbeing support."""
from __future__ import annotations

import math
import re
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Mapping, Sequence

from core.world_state import WorldConflict, WorldFact


class EvidenceKind(StrEnum):
    OBSERVATION = "observation"
    INFERENCE = "inference"
    PREDICTION = "prediction"
    RECOMMENDATION = "recommendation"
    UNCERTAINTY = "uncertainty"


@dataclass(frozen=True, slots=True)
class EvidenceItem:
    """One provenance-aware fact presented to the advisor."""

    kind: EvidenceKind
    text: str
    confidence: float
    source: str


@dataclass(frozen=True, slots=True)
class AssistantAdvice:
    """Structured assistant output; recommendations never masquerade as facts."""

    created_at: float
    observations: tuple[EvidenceItem, ...]
    inferences: tuple[EvidenceItem, ...]
    recommendations: tuple[EvidenceItem, ...]
    uncertainties: tuple[EvidenceItem, ...]


@dataclass(frozen=True, slots=True)
class WellbeingSupport:
    """Non-diagnostic supportive response."""

    supportive_message: str
    grounding_steps: tuple[str, ...]
    workload_prompt: str
    escalation_recommended: bool


@dataclass(frozen=True, slots=True)
class InterviewAnalysis:
    """Neutral evidence-analysis projection for interviews."""

    questions: tuple[str, ...]
    possible_contradictions: tuple[str, ...]
    evidence_gaps: tuple[str, ...]
    coercion_free: bool = True


class CognitiveAssistant:
    """Provider-neutral situational advisor with explicit uncertainty."""

    def advise(self, facts: Sequence[WorldFact], conflicts: Sequence[WorldConflict] = ()) -> AssistantAdvice:
        observations = tuple(EvidenceItem(EvidenceKind.OBSERVATION, f"{fact.entity_id}.{fact.attribute}={fact.value!r}", fact.confidence, fact.source) for fact in facts[:64])
        inferences: list[EvidenceItem] = []
        recommendations: list[EvidenceItem] = []
        uncertainties: list[EvidenceItem] = []
        if conflicts:
            for conflict in conflicts[:16]:
                inferences.append(EvidenceItem(EvidenceKind.INFERENCE, f"Conflicting sources for {conflict.entity_id}.{conflict.attribute}", 1.0 - conflict.severity, "world_state"))
                recommendations.append(EvidenceItem(EvidenceKind.RECOMMENDATION, f"Request another independent measurement before acting on {conflict.entity_id}.{conflict.attribute}.", 0.9, "policy"))
        low_confidence = [fact for fact in facts if fact.confidence < 0.5]
        if low_confidence:
            uncertainties.append(EvidenceItem(EvidenceKind.UNCERTAINTY, f"{len(low_confidence)} current facts have confidence below 0.5.", 1.0, "world_state"))
        if not facts:
            uncertainties.append(EvidenceItem(EvidenceKind.UNCERTAINTY, "No verified world-state facts are available.", 1.0, "world_state"))
        return AssistantAdvice(time.time(), observations, tuple(inferences), tuple(recommendations), tuple(uncertainties))

    def wellbeing_support(self, text: str) -> WellbeingSupport:
        """Provide supportive, non-diagnostic coping guidance from user text."""
        message = re.sub(r"\s+", " ", str(text).strip())
        if not message:
            raise ValueError("support text is required")
        risk_terms = ("suicide", "kill myself", "self harm", "hurt myself", "can't stay safe", "cannot stay safe")
        escalation = any(term in message.lower() for term in risk_terms)
        supportive = "It sounds like this is difficult. You do not have to solve everything at once; focus on the next safe, manageable step."
        if escalation:
            supportive = "Your safety matters. Please move away from anything you could use to hurt yourself and contact a trusted person or local emergency/crisis service now."
        return WellbeingSupport(supportive, ("Slow your breathing for a few cycles.", "Name five things you can see and three things you can hear.", "Reduce the next task to one small, safe action."), "Consider pausing, hydrating, and taking a short recovery break before high-stakes decisions." if not escalation else "Do not handle this alone; involve a trusted person or emergency support immediately.", escalation)

    def interview_assistance(self, known_points: Mapping[str, str], statements: Sequence[str]) -> InterviewAnalysis:
        """Generate neutral clarification questions and highlight text-level inconsistencies."""
        questions = tuple(f"Can you clarify the evidence for {key}: {value}?" for key, value in list(known_points.items())[:16])
        normalized = [re.sub(r"\s+", " ", item.strip()) for item in statements if item.strip()]
        contradictions: list[str] = []
        for left_index, left in enumerate(normalized):
            for right in normalized[left_index + 1 :]:
                if left.lower() == right.lower():
                    continue
                left_tokens, right_tokens = set(left.lower().split()), set(right.lower().split())
                overlap = len(left_tokens & right_tokens) / max(1, len(left_tokens | right_tokens))
                if 0.3 < overlap < 0.6:
                    contradictions.append(f"Statements may differ in detail: {left[:120]!r} vs {right[:120]!r}")
        gaps = tuple(f"No corroborating source supplied for {key}." for key in known_points if not str(known_points[key]).strip())
        return InterviewAnalysis(questions, tuple(contradictions[:32]), gaps[:32])

"""P2-O Model Fabric 2.0.

Canonical model profile/registry, quantization compatibility, deterministic VRAM
estimation, residency management, routing, KV-cache isolation, batching,
speculative execution, role adapters, cloud/privacy gates, and lifecycle control.
All mutable model operations are explicit and evented; callers must present a
verified P2-E ExecutionContext-compatible object with an auth_context.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import logging
import math
import re
import sqlite3
import threading
import time
import uuid
logger = logging.getLogger(__name__)

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.event_fabric import AuthContext, EventEnvelope, EventFabric, EventLineage, ProducedBy
from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

ROOT = Path(__file__).resolve().parent
SCHEMA_DIR = ROOT / "schemas"
QUANT_DIR = ROOT / "model_fabric" / "quantization"
QUANT_SEED_KEY_ID = "jarvis-quant-seed-v1"
QUANT_SEED_PUBLIC_KEY_B64 = "/v/4vaLbIszAJugkpyllZ/AJ2v77Ai5lUZmOr0F09mA="

RESIDENCIES = ("local", "cloud", "hybrid")
ROLES = ("reasoning", "general", "small", "embedding", "reranker", "vision", "asr", "tts", "adapter", "classifier")
QUANTIZATIONS = ("none", "fp16", "int8", "int4", "int3", "int2", "custom")
TRUSTS = ("verified", "pinned", "experimental", "untrusted")
RUNTIMES = ("llama_cpp", "vllm", "transformers", "onnxruntime", "tensorrt", "custom")
STATES = ("registered", "pinned", "deprecated", "revoked", "retired")
ADAPTER_KINDS = ("lora", "qlora", "peft", "prefix", "other")
BATCHING_MODES = ("static", "dynamic", "continuous")
PRIORITIZATIONS = ("fifo", "priority", "deadline")
ISOLATIONS = ("none", "per_tenant", "per_execution")
TRUST_RANK = {"untrusted": 0, "experimental": 1, "pinned": 2, "verified": 3}
MODE_MIN_TRUST = {"trusted": 3, "restricted": 2, "isolated": 1, "simulation": 0}
RUNTIME_OVERHEAD_MB = {"llama_cpp": 384, "vllm": 768, "transformers": 512, "onnxruntime": 256, "tensorrt": 384, "custom": 768}

MODEL_EVENTS = (
    "Registered", "Pinned", "Deprecated", "Retired", "Revoked", "RevocationPropagated",
    "LoadRequested", "Loaded", "LoadFailed", "Unloaded", "Evicted", "ResidencyEstimateDeviation",
    "Routed", "RoutingFailed", "ResponseMismatch", "BatchFormed", "BatchExecuted", "SpeculativeDeviation",
    "KvSnapshot", "KvRestored",
)

class ModelFabricError(RuntimeError): pass
class ModelValidationError(ModelFabricError, ValueError): pass
class ModelSignatureError(ModelFabricError, ValueError): pass
class ModelIntegrityError(ModelFabricError, ValueError): pass
class ModelAccessDenied(ModelFabricError, PermissionError): pass
class ModelNotFound(ModelFabricError, LookupError): pass
class ModelRevoked(ModelFabricError): pass
class ModelRetired(ModelFabricError): pass
class ArtifactHashMismatch(ModelFabricError): pass
class QuantizationIncompatible(ModelFabricError): pass
class InsufficientVram(ModelFabricError): pass
class NoEligibleModel(ModelFabricError): pass
class PrivacyViolation(ModelFabricError): pass
class DeterminismUnavailable(ModelFabricError): pass
class StaleMeasurement(ModelFabricError): pass
class KVCrossTenant(ModelFabricError, PermissionError): pass
class BatchPolicyDenied(ModelFabricError, PermissionError): pass
class SpeculationPolicyDenied(ModelFabricError, PermissionError): pass
class CloudCredentialError(ModelFabricError, PermissionError): pass

@dataclass(frozen=True, slots=True)
class ModelConfig:
    registry_path: str = ":memory:"
    storage_secret: bytes = b"jarvis-model-fabric-default-storage-secret-32-byte!!"
    total_vram_mb: int = 16384
    reserved_vram_mb: int = 512
    device_id: str = "gpu0"
    gpu_arch: str = "8.9"
    environment_hash: str = "0" * 64
    measurement_max_age_seconds: float = 3600.0
    fragmentation_fraction: float = 0.08
    deviation_threshold_fraction: float = 0.15
    default_tenant_id: str = "default"
    allowed_cloud_regions: tuple[str, ...] = ()

@dataclass(frozen=True, slots=True)
class VRAMEstimate:
    weights_mb: int
    kv_cache_mb: int
    activation_mb: int
    runtime_overhead_mb: int
    fragmentation_margin_mb: int
    total_mb: int
    confidence: float
    estimated_for: dict[str, Any]
    estimator_version: str = "2.0.0"

@dataclass(frozen=True, slots=True)
class LoadHandle:
    handle_id: str
    tenant_id: str
    model_ref: str
    config: dict[str, Any]
    priority: int
    pin: bool
    requested_at: str
    execution_id: str

@dataclass(frozen=True, slots=True)
class ReservationHandle:
    handle_id: str
    tenant_id: str
    amount_mb: int
    reason: str

@dataclass(frozen=True, slots=True)
class LoadedRef:
    tenant_id: str
    model_ref: str
    load_handle_id: str
    vram_mb: int

@dataclass(frozen=True, slots=True)
class KVHandle:
    tenant_id: str
    session_id: str
    model_ref: str

@dataclass(frozen=True, slots=True)
class Batch:
    batch_id: str
    model_ref: str
    requests: tuple[dict[str, Any], ...]

@dataclass(frozen=True, slots=True)
class RoutingDecision:
    request_id: str
    chosen_model_ref: str
    fallback_chain: tuple[str, ...]
    reason: dict[str, Any]
    estimated_vram_mb: int | None
    estimated_latency_ms: float
    estimated_cost: float
    estimator_version: str
    policy_version: str = "2.0.0"
    decided_at: str = ""
    signature: str = ""

class ModelAdapter(Protocol):
    def load(self, model: Mapping[str, Any], config: Mapping[str, Any]) -> int | None: ...
    def unload(self, model: Mapping[str, Any]) -> None: ...
    def invoke(self, model: Mapping[str, Any], request: Mapping[str, Any], context: Any) -> Any: ...
    def health(self, model: Mapping[str, Any]) -> Mapping[str, Any]: ...
    def stream(self, model: Mapping[str, Any], request: Mapping[str, Any], context: Any): ...

class DeterministicAdapter:
    """Small deterministic adapter useful for tests and runtimes without installed backends."""
    def __init__(self, actual_vram_mb: int | None = None, responder: Callable[[Mapping[str, Any], Mapping[str, Any]], Any] | None = None) -> None:
        self.actual_vram_mb = actual_vram_mb
        self.responder = responder
        self.loaded: set[str] = set()
    def load(self, model: Mapping[str, Any], config: Mapping[str, Any]) -> int | None:
        ref = model_ref(model)
        self.loaded.add(ref)
        return self.actual_vram_mb
    def unload(self, model: Mapping[str, Any]) -> None:
        self.loaded.discard(model_ref(model))
    def invoke(self, model: Mapping[str, Any], request: Mapping[str, Any], context: Any) -> Any:
        if self.responder is not None:
            return self.responder(model, request)
        return {"model_ref": model_ref(model), "ok": True, "input": request.get("input", request.get("prompt", ""))}
    def health(self, model: Mapping[str, Any]) -> Mapping[str, Any]:
        return {"ok": model_ref(model) in self.loaded or model.get("residency") == "cloud"}
    def stream(self, model: Mapping[str, Any], request: Mapping[str, Any], context: Any):
        yield self.invoke(model, request, context)

auth_scope_model_read = "models.read"
auth_scope_model_write = "models.write"
auth_scope_model_load = "models.load"
auth_scope_model_route = "models.route"
auth_scope_model_cloud = "models.cloud"
auth_scope_model_admin = "models.admin"
auth_scope_model_batch = "models.batch"
auth_scope_model_speculate = "models.speculate"


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def _uuid() -> str:
    return str(uuid.uuid4())

def _sha(doc: Any) -> str:
    return hashlib.sha256(canonical_bytes(doc)).hexdigest()

def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")

def _decode_b64(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"))

def model_ref(profile: Mapping[str, Any]) -> str:
    return f"{profile['model_id']}@{profile['model_version']}"

def _version_tuple(value: str) -> tuple[int,int,int]:
    m = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[-+].*)?", str(value))
    if not m:
        raise ModelValidationError(f"invalid semver: {value}")
    return tuple(int(x) for x in m.groups())

def _satisfies(version: str, constraint: str | None) -> bool:
    if not constraint or constraint in {"*", "latest"}:
        return True
    v = _version_tuple(version)
    c = constraint.strip()
    if c.startswith("^"):
        base = _version_tuple(c[1:]); return v >= base and v[0] == base[0]
    for op in (">=", "<=", ">", "<", "="):
        if c.startswith(op):
            base = _version_tuple(c[len(op):])
            return {">=": v >= base, "<=": v <= base, ">": v > base, "<": v < base, "=": v == base}[op]
    return v == _version_tuple(c)

def _unsigned_profile(profile: Mapping[str, Any]) -> dict[str, Any]:
    d = copy.deepcopy(dict(profile)); d["signature"] = ""; d["integrity_hash"] = ""; return d

def _profile_integrity(profile: Mapping[str, Any]) -> str:
    return _sha(_unsigned_profile(profile))

def sign_profile(profile: Mapping[str, Any], key: Ed25519PrivateKey, key_id: str) -> dict[str, Any]:
    doc = copy.deepcopy(dict(profile)); doc["integrity_hash"] = ""; doc["signature"] = ""; doc["signature_key_id"] = key_id
    doc["integrity_hash"] = _sha(_unsigned_profile(doc))
    doc["signature"] = _b64(key.sign(canonical_bytes(_unsigned_profile(doc))))
    return doc

def sign_determinism_proof(proof: Mapping[str,Any], key: Ed25519PrivateKey) -> dict[str,Any]:
    doc=copy.deepcopy(dict(proof)); doc["signature"]=""; doc["signature"]=_b64(key.sign(canonical_bytes(doc))); return doc

def determinism_proof_ref(proof: Mapping[str,Any]) -> str:
    doc=copy.deepcopy(dict(proof)); doc.pop("signature",None); return "urn:jarvis:model-determinism:" + _sha(doc)

def verify_profile(profile: Mapping[str, Any], public_keys: Mapping[str, bytes | Ed25519PublicKey]) -> bool:
    try:
        doc = dict(profile); key_id = str(doc["signature_key_id"]); signature = str(doc["signature"])
        unsigned = _unsigned_profile(doc)
        expected = _profile_integrity(doc)
        if not hmac.compare_digest(expected, str(doc["integrity_hash"])): return False
        raw = public_keys[key_id]
        pub = raw if isinstance(raw, Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(raw))
        pub.verify(_decode_b64(signature), canonical_bytes(unsigned))
        return True
    except (KeyError, ValueError, TypeError, InvalidSignature):
        return False

def _effective_tenant(context: Any, tenant_id: str) -> str:
    ctx_tenant = getattr(context, "tenant_id", None) if context is not None else None
    if tenant_id == "default" and ctx_tenant:
        return str(ctx_tenant)
    return str(tenant_id)

def _require_ctx(context: Any, required_scopes: Iterable[str], tenant_id: str) -> AuthContext:
    if context is None or not hasattr(context, "auth_context"):
        raise ModelAccessDenied("P2-E ExecutionContext is required")
    auth = getattr(context, "auth_context")
    if not hasattr(auth, "principal") or not hasattr(auth, "scopes"):
        raise ModelAccessDenied("invalid execution auth context")
    if hasattr(context, "execution_mode"):
        mode = getattr(context.execution_mode, "value", context.execution_mode)
        if str(mode) not in MODE_MIN_TRUST and str(mode).lower() not in MODE_MIN_TRUST:
            raise ModelAccessDenied("unknown execution mode")
    auth_tenant = getattr(context, "tenant_id", tenant_id)
    if auth_tenant not in (tenant_id, None):
        raise ModelAccessDenied("cross-tenant execution context denied")
    scopes = set(auth.scopes)
    missing = [s for s in required_scopes if s not in scopes and auth_scope_model_admin not in scopes]
    if missing:
        raise ModelAccessDenied(f"missing model scope(s): {', '.join(missing)}")
    return AuthContext(principal=str(auth.principal), scopes=tuple(str(x) for x in auth.scopes), policy_ref=getattr(auth, "policy_ref", None), delegated_by=getattr(auth, "delegated_by", None))

class ModelRegistry:
    def __init__(self, path: str | Path, storage_secret: bytes, signer: Ed25519PrivateKey, key_id: str, public_keys: Mapping[str, bytes | Ed25519PublicKey] | None = None) -> None:
        if len(storage_secret) < 32: raise ValueError("model registry secret must be at least 32 bytes")
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = bytes(storage_secret); self.signer = signer; self.key_id = key_id
        raw_pub = signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.public_keys = dict(public_keys or {}); self.public_keys.setdefault(key_id, raw_pub)
        self.lock = threading.RLock(); self.db = sqlite3.connect(str(self.path), check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL"); self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS profiles(seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant_id TEXT NOT NULL, model_ref TEXT NOT NULL, model_id TEXT NOT NULL, model_version TEXT NOT NULL, revision INTEGER NOT NULL, profile_json TEXT NOT NULL, profile_hash TEXT NOT NULL, hmac_tag TEXT NOT NULL, mutation TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(tenant_id,model_ref,revision))")
        self.db.commit()
        try:
            self._verify_integrity()
        except Exception:
            self.db.close()
            self._closed=True
            raise
    def _tag(self, row: Mapping[str, Any]) -> str:
        material = canonical_bytes({"tenant_id": row["tenant_id"], "model_ref": row["model_ref"], "revision": row["revision"], "profile_json": row["profile_json"], "profile_hash": row["profile_hash"], "mutation": row["mutation"]})
        return hmac.new(self.secret, material, hashlib.sha256).hexdigest()
    def _verify_integrity(self) -> None:
        rows = self.db.execute("SELECT tenant_id,model_ref,revision,profile_json,profile_hash,hmac_tag,mutation FROM profiles ORDER BY seq").fetchall()
        for tenant_id, ref, revision, payload, digest, tag, mutation in rows:
            row={"tenant_id":tenant_id,"model_ref":ref,"revision":revision,"profile_json":payload,"profile_hash":digest,"mutation":mutation}
            if not hmac.compare_digest(self._tag(row), tag) or _sha(json.loads(payload)) != digest:
                raise ModelIntegrityError("model registry HMAC or hash verification failed")
            if not verify_profile(json.loads(payload), self.public_keys):
                raise ModelSignatureError(f"invalid signed profile {ref}")
    def _latest_row(self, ref: str, tenant_id: str) -> tuple[Any,...] | None:
        return self.db.execute("SELECT profile_json FROM profiles WHERE tenant_id=? AND model_ref=? ORDER BY revision DESC LIMIT 1", (tenant_id, ref)).fetchone()
    def register(self, profile: Mapping[str, Any], *, context: Any, tenant_id: str = "default") -> str:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context, (auth_scope_model_write,), tenant_id)
        signed = sign_profile(profile, self.signer, self.key_id)
        validate_profile(signed)
        if not verify_profile(signed, self.public_keys): raise ModelSignatureError("profile signing failed")
        ref = model_ref(signed)
        with self.lock, self.db:
            if self._latest_row(ref, tenant_id) is not None: raise ModelValidationError(f"model already registered: {ref}")
            artifact_hashes={str(a.get("sha256")) for a in signed.get("artifacts",())}
            rows=self.db.execute("SELECT model_ref,profile_json FROM profiles WHERE tenant_id=? ORDER BY seq DESC",(tenant_id,)).fetchall()
            seen_refs=set()
            for other_ref,payload in rows:
                if other_ref in seen_refs: continue
                seen_refs.add(other_ref)
                other=json.loads(payload)
                for ours in signed.get("artifacts",()):
                    for theirs in other.get("artifacts",()):
                        if str(ours.get("sha256")) != str(theirs.get("sha256")):
                            continue
                        ours_meta=(str(ours.get("kind")),str(ours.get("format")),str(ours.get("uri")))
                        theirs_meta=(str(theirs.get("kind")),str(theirs.get("format")),str(theirs.get("uri")))
                        if ours_meta != theirs_meta:
                            raise ModelValidationError(f"artifact hash collision: {ours['sha256']}")
            self._append(ref, signed, "register", tenant_id)
        return ref
    def _append(self, ref: str, profile: Mapping[str, Any], mutation: str, tenant_id: str = "default") -> None:
        row_payload=json.dumps(profile,sort_keys=True,separators=(",",":"),ensure_ascii=False)
        revision=(self.db.execute("SELECT COALESCE(MAX(revision),0) FROM profiles WHERE tenant_id=? AND model_ref=?",(tenant_id,ref)).fetchone()[0] or 0)+1
        row={"tenant_id":tenant_id,"model_ref":ref,"revision":revision,"profile_json":row_payload,"profile_hash":_sha(profile),"mutation":mutation}
        tag=self._tag(row)
        self.db.execute("INSERT INTO profiles(tenant_id,model_ref,model_id,model_version,revision,profile_json,profile_hash,hmac_tag,mutation,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (tenant_id,ref,profile["model_id"],profile["model_version"],revision,row_payload,row["profile_hash"],tag,mutation,time.time()))
    def get(self, model_id: str, version: str | None = None, *, context: Any, tenant_id: str = "default") -> dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_read,),tenant_id)
        if version is None:
            rows=self.db.execute("SELECT profile_json FROM profiles WHERE tenant_id=? AND model_id=? ORDER BY seq DESC",(tenant_id,model_id)).fetchall()
            if not rows: raise ModelNotFound(model_id)
            return self._checked(json.loads(rows[0][0]))
        row=self._latest_row(f"{model_id}@{version}", tenant_id)
        if row is None: raise ModelNotFound(f"{model_id}@{version}")
        return self._checked(json.loads(row[0]))
    def get_by_hash(self, artifact_sha256: str, *, context: Any, tenant_id: str = "default") -> dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_read,),tenant_id)
        rows=self.db.execute("SELECT profile_json FROM profiles WHERE tenant_id=? ORDER BY seq DESC",(tenant_id,)).fetchall(); seen=set()
        for (payload,) in rows:
            p=self._checked(json.loads(payload)); ref=model_ref(p)
            if ref in seen: continue
            seen.add(ref)
            if any(str(a.get("sha256"))==str(artifact_sha256) for a in p.get("artifacts",())): return p
        raise ModelNotFound(artifact_sha256)
    def _checked(self, profile: dict[str,Any]) -> dict[str,Any]:
        if not verify_profile(profile,self.public_keys): raise ModelSignatureError("stored profile signature invalid")
        validate_profile(profile); return profile
    def list(self, *, context: Any, tenant_id: str = "default", residency: str | None = None, role: str | None = None) -> list[dict[str,Any]]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_read,),tenant_id)
        rows=self.db.execute("SELECT model_ref,profile_json FROM profiles WHERE tenant_id=? ORDER BY seq DESC", (tenant_id,)).fetchall(); seen=set(); out=[]
        for ref,payload in rows:
            if ref in seen: continue
            seen.add(ref); p=self._checked(json.loads(payload))
            if residency and p["residency"] != residency: continue
            if role and p["role"] != role: continue
            out.append({"model_ref":ref,"state":p["state"],"trust":p["trust"],"role":p["role"],"residency":p["residency"]})
        return out
    def _mutate(self, ref: str, state: str, context: Any, tenant_id: str, mutation: str, successor_ref: str | None = None, reason: str | None = None) -> dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_write,),tenant_id)
        row=self._latest_row(ref, tenant_id)
        if row is None: raise ModelNotFound(ref)
        p=self._checked(json.loads(row[0])); p["state"]=state
        p["deprecated_at"]=_utc() if state=="deprecated" else p.get("deprecated_at")
        p["revoked_at"]=_utc() if state=="revoked" else p.get("revoked_at")
        p["retired_at"]=_utc() if state=="retired" else p.get("retired_at")
        if successor_ref is not None: p["successor_ref"]=successor_ref
        if reason: p.setdefault("lifecycle_reason",reason)
        p=sign_profile(p,self.signer,self.key_id)
        with self.lock,self.db: self._append(ref,p,mutation,tenant_id)
        return p
    def pin(self, ref: str, *, context: Any, tenant_id: str="default", reason: str="") -> dict[str,Any]:
        return self._mutate(ref,"pinned",context,tenant_id,"pin",reason=reason)
    def deprecate(self, ref: str, successor_ref: str | None, *, context: Any, tenant_id: str="default", reason: str="") -> dict[str,Any]:
        return self._mutate(ref,"deprecated",context,tenant_id,"deprecate",successor_ref,reason)
    def retire(self, ref: str, successor_ref: str | None, *, context: Any, tenant_id: str="default", reason: str="") -> dict[str,Any]:
        return self._mutate(ref,"retired",context,tenant_id,"retire",successor_ref,reason)
    def revoke(self, ref: str, *, context: Any, tenant_id: str="default", reason: str="") -> dict[str,Any]:
        _require_ctx(context,(auth_scope_model_admin,),tenant_id); return self._mutate(ref,"revoked",context,tenant_id,"revoke",reason=reason)
    def resolve(self, model_ref_or_id: str, *, context: Any, tenant_id: str="default", mode: str="trusted", residency: str | None = None, version_constraint: str | None = None) -> dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_read,),tenant_id)
        if "@" in model_ref_or_id and _version_tuple(model_ref_or_id.rsplit("@",1)[1]):
            p=self.get(*model_ref_or_id.rsplit("@",1),context=context,tenant_id=tenant_id)
            candidates=[p]
        else:
            rows=self.db.execute("SELECT profile_json FROM profiles WHERE tenant_id=? AND model_id=? ORDER BY seq DESC",(tenant_id,model_ref_or_id)).fetchall(); candidates=[]; seen=set()
            for (payload,) in rows:
                p=self._checked(json.loads(payload)); ref=model_ref(p)
                if ref not in seen: candidates.append(p); seen.add(ref)
        eligible=[]
        for p in candidates:
            if version_constraint and not _satisfies(p["model_version"], version_constraint): continue
            if p["state"]=="revoked": raise ModelRevoked(model_ref(p)) if model_ref_or_id == model_ref(p) else ModelRevoked(model_ref_or_id)
            if p["state"]=="retired":
                if p.get("successor_ref") and model_ref_or_id != model_ref(p): continue
                if model_ref_or_id == model_ref(p): raise ModelRetired(model_ref_or_id)
                continue
            if p["state"]=="deprecated" and "@" not in model_ref_or_id:
                continue
            if residency and p["residency"] != residency: continue
            if TRUST_RANK[p["trust"]] < MODE_MIN_TRUST[mode]: continue
            eligible.append(p)
        if not eligible: raise NoEligibleModel(f"no eligible model: {model_ref_or_id}")
        eligible.sort(key=lambda p: _version_tuple(p["model_version"]), reverse=True); return eligible[0]
    def diff(self, a: Mapping[str,Any], b: Mapping[str,Any]) -> dict[str,Any]:
        left=json.dumps(a,sort_keys=True); right=json.dumps(b,sort_keys=True); return {"same": left==right, "left_hash":_sha(a), "right_hash":_sha(b), "changed": sorted(set(a.keys())|set(b.keys())) if left!=right else []}
    def history(self, ref: str, tenant_id: str = "default") -> list[dict[str,Any]]:
        rows=self.db.execute("SELECT revision,profile_json,mutation FROM profiles WHERE tenant_id=? AND model_ref=? ORDER BY revision",(tenant_id,ref)).fetchall()
        return [{"revision":r,"profile":self._checked(json.loads(p)),"mutation":m} for r,p,m in rows]
    def close(self) -> None:
        with self.lock:
            if getattr(self, "_closed", False):
                return
            self._closed = True
            self.db.close()

def validate_profile(profile: Mapping[str,Any]) -> None:
    schema=json.loads((SCHEMA_DIR/"model_profile_v1.schema.json").read_text())
    SchemaValidator().validate_or_raise(dict(profile),schema)

def _unsigned_quantization_profile(profile: Mapping[str,Any]) -> dict[str,Any]:
    d=copy.deepcopy(dict(profile)); d["signature"]=""; return d

def sign_quantization_profile(profile: Mapping[str,Any], key: Ed25519PrivateKey, key_id: str) -> dict[str,Any]:
    d=_unsigned_quantization_profile(profile); pub=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    sig=key.sign(canonical_bytes(d)); d["signature"]="ed25519:"+str(key_id)+":"+_b64(pub)+":"+_b64(sig); return d

def verify_quantization_signature(profile: Mapping[str,Any], trusted_public_keys: Mapping[str,bytes|Ed25519PublicKey]) -> bool:
    try:
        value=str(profile["signature"]); parts=value.split(":",3)
        if len(parts)!=4 or parts[0]!="ed25519": return False
        key_id,pub64,sig64=parts[1],parts[2],parts[3]
        raw=trusted_public_keys.get(key_id)
        if raw is None: return False
        expected=raw if isinstance(raw,bytes) else raw.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
        pub=Ed25519PublicKey.from_public_bytes(expected)
        if not hmac.compare_digest(pub64,_b64(expected)): return False
        pub.verify(_decode_b64(sig64),canonical_bytes(_unsigned_quantization_profile(profile))); return True
    except Exception: return False

def validate_quantization_profile(profile: Mapping[str,Any]) -> None:
    schema=json.loads((SCHEMA_DIR/"quantization_profile_v1.schema.json").read_text()); SchemaValidator().validate_or_raise(dict(profile),schema)

def validate_quantization_compatibility(q: Mapping[str,Any], runtime: str, gpu_arch: str, role: str) -> None:
    if runtime not in q["compatibility"]["runtimes"] or gpu_arch not in q["compatibility"]["gpu_arch"] or role not in q["supported_roles"]:
        raise QuantizationIncompatible(f"{q['quantization_id']} incompatible with {runtime}/{gpu_arch}/{role}")

class QuantizationRegistry:
    def __init__(self, seed_dir: Path = QUANT_DIR, trusted_public_keys: Mapping[str,bytes|Ed25519PublicKey] | None = None) -> None:
        seed_pub=base64.b64decode(QUANT_SEED_PUBLIC_KEY_B64.encode())
        self._trusted_public_keys=dict(trusted_public_keys or {}); self._trusted_public_keys.setdefault(QUANT_SEED_KEY_ID,seed_pub)
        self._profiles: dict[str,dict[str,Any]] = {}; self._load_seed(seed_dir)
    def _load_seed(self, seed_dir: Path) -> None:
        if not seed_dir.exists(): return
        for path in sorted(seed_dir.glob("*.yaml")):
            data=_parse_simple_yaml(path.read_text(encoding="utf-8"));
            if data: self.register(data)
    def register(self, profile: Mapping[str,Any]) -> None:
        validate_quantization_profile(profile)
        if not verify_quantization_signature(profile,self._trusted_public_keys): raise ModelSignatureError(f"invalid quantization signature: {profile.get('quantization_id')}")
        self._profiles[str(profile["quantization_id"])] = copy.deepcopy(dict(profile))
    def get(self, quantization_id: str) -> dict[str,Any]:
        if quantization_id not in self._profiles: raise ModelNotFound(quantization_id)
        return copy.deepcopy(self._profiles[quantization_id])
    def list(self) -> list[dict[str,Any]]: return [copy.deepcopy(self._profiles[k]) for k in sorted(self._profiles)]


def _parse_simple_yaml(text: str) -> dict[str,Any]:
    # Seeds are intentionally simple and dependency-free: scalar keys plus inline lists.
    out={}
    for raw in text.splitlines():
        raw=raw.strip()
        if not raw or raw.startswith("#") or ":" not in raw: continue
        k,v=raw.split(":",1); v=v.strip();
        if v.startswith("["):
            try:
                out[k.strip()]=json.loads(v.replace("'",'"'))
                continue
            except Exception:
                logger.debug("invalid inline list in model seed field %s; using scalar fallback", k, exc_info=True)
        if v in {"true","false"}: out[k.strip()]=v=="true"
        elif re.fullmatch(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?",v):
            number=float(v) if any(ch in v for ch in ".eE") else int(v)
            import math
            if isinstance(number,float) and not math.isfinite(number):
                raise ValueError(f"non-finite numeric seed value: {v}")
            out[k.strip()]=number
        else: out[k.strip()]=v.strip('"\'')
    compat={}
    for key in list(out):
        if key.startswith("compatibility."):
            subkey=key.split(".",1)[1]
            if subkey in compat:
                raise ValueError("ambiguous compatibility configuration: duplicate key")
            compat[subkey]=out.pop(key)
    if compat:
        existing=out.get("compatibility")
        if existing is not None and not isinstance(existing,dict):
            raise ValueError("compatibility cannot combine dotted and non-object forms")
        overlap=set(existing or {}).intersection(compat) if isinstance(existing,dict) else set()
        if overlap:
            raise ValueError("ambiguous compatibility configuration: duplicated keys")
        out["compatibility"]={**(existing or {}),**compat}
    return out

class VRAMEstimator:
    version="2.0.0"
    def __init__(self, fragmentation_fraction: float = 0.08) -> None: self.fragmentation_fraction=float(fragmentation_fraction)
    def estimate(self, profile: Mapping[str,Any], *, runtime: str, context_tokens: int, batch_size: int, concurrent_requests: int, gpu_arch: str, environment_hash: str, quantization_vram_multiplier: float = 1.0) -> VRAMEstimate:
        if context_tokens<1 or batch_size<1 or concurrent_requests<1: raise ModelValidationError("context, batch and concurrency must be positive")
        res=profile["resources"]; weights=max(1,math.ceil(sum(int(a["size_bytes"]) for a in profile["artifacts"] if a["kind"]=="weights")/1_000_000))
        if profile["quantization"]!="none":
            weights=max(1,math.ceil(weights*float(quantization_vram_multiplier)))
        kv=max(0,int(res["kv_cache_mb_per_1k_tokens"])*math.ceil(context_tokens/1000)*max(1,concurrent_requests))
        activation=max(64,math.ceil(weights*0.10*max(1,batch_size)))
        overhead=RUNTIME_OVERHEAD_MB.get(runtime,RUNTIME_OVERHEAD_MB["custom"])
        base=weights+kv+activation+overhead; margin=max(16,math.ceil(base*self.fragmentation_fraction)); total=base+margin
        confidence=0.95 if runtime in RUNTIME_OVERHEAD_MB and gpu_arch else 0.65
        return VRAMEstimate(weights,kv,activation,overhead,margin,total,confidence,{"model_ref":model_ref(profile),"runtime":runtime,"context_tokens":context_tokens,"batch_size":batch_size,"concurrent_requests":concurrent_requests,"gpu_arch":gpu_arch,"environment_hash":environment_hash},self.version)

class ModelResidencyManager:
    def __init__(self, fabric: "ModelFabric") -> None:
        self.fabric=fabric; self.lock=threading.RLock(); self.loaded: dict[tuple[str,str],dict[str,Any]]={}; self.reserved: dict[str,ReservationHandle]={}; self.pending:list[LoadHandle]=[]
    def _used(self)->int: return sum(int(x["vram_mb"]) for x in self.loaded.values()) + sum(x.amount_mb for x in self.reserved.values())
    def inspect(self)->dict[str,Any]:
        with self.lock: return {"environment_hash":self.fabric.config.environment_hash,"gpu":{"device_id":self.fabric.config.device_id,"total_vram_mb":self.fabric.config.total_vram_mb,"used_vram_mb":self._used(),"reserved_vram_mb":self.fabric.config.reserved_vram_mb,"temperature_c":None,"utilization_pct":None},"loaded":[copy.deepcopy(x) for x in self.loaded.values()],"pending":[x.__dict__ if hasattr(x,'__dict__') else {"handle_id":x.handle_id,"priority":x.priority,"requested_by":x.execution_id} for x in self.pending]}
    def estimate_load(self, model_ref_value: str, config: Mapping[str,Any], *, context: Any, tenant_id: str) -> VRAMEstimate:
        tenant_id = _effective_tenant(context, tenant_id)
        if "@" in model_ref_value:
            p=self.fabric.registry.get(*model_ref_value.rsplit("@",1),context=context,tenant_id=tenant_id)
        else:
            p=self.fabric.registry.resolve(model_ref_value,context=context,tenant_id=tenant_id,mode=self.fabric._mode(context))
        if p["state"] == "revoked":
            raise ModelRevoked(model_ref_value)
        if p["state"] == "retired":
            raise ModelRetired(model_ref_value)
        runtime=str(config.get("runtime") or p["requirements"]["runtime"]); self.fabric._check_quantization(p,runtime)
        return self.fabric._estimate(p,runtime=runtime,context_tokens=int(config.get("context_tokens",p["context_window"])),batch_size=int(config.get("batch_size",1)),concurrent_requests=int(config.get("concurrent_requests",1)))
    def request_load(self, model_ref_value: str, config: Mapping[str,Any], priority: int, *, pin: bool=False, context: Any, tenant_id: str) -> LoadHandle:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_load,),tenant_id); p=self.fabric.registry.get(*model_ref_value.rsplit('@',1),context=context,tenant_id=tenant_id) if '@' in model_ref_value else self.fabric.registry.resolve(model_ref_value,context=context,tenant_id=tenant_id,mode=self.fabric._mode(context))
        if p["trust"] in {"experimental","untrusted"} and self.fabric._mode(context) not in {"isolated","simulation"}: raise ModelAccessDenied("experimental/untrusted model requires isolated or simulation mode")
        estimate=self.estimate_load(model_ref_value,config,context=context,tenant_id=tenant_id)
        self.fabric._emit("LoadRequested",{"model_ref":model_ref_value,"tenant_id":tenant_id,"estimate":estimate.total_mb,"priority":int(priority)},context,tenant_id)
        h=LoadHandle(_uuid(),tenant_id,model_ref(p),dict(config),int(priority),bool(pin),_utc(),str(getattr(context,"execution_id",_uuid())))
        with self.lock:
            if not self._can_fit(estimate.total_mb,tenant_id,include_pinned=False): self.pending.append(h); self.pending.sort(key=lambda x:(-x.priority,x.requested_at)); return h
            self.pending.append(h); self.pending.sort(key=lambda x:(-x.priority,x.requested_at)); return h
    def _can_fit(self, amount:int, tenant_id:str, include_pinned:bool=False)->bool:
        available=self.fabric.config.total_vram_mb-self.fabric.config.reserved_vram_mb-self._used()
        return amount<=available or self._evict_for(amount,tenant_id,include_pinned,simulate=True)
    def _evict_for(self, amount:int, tenant_id:str, include_pinned:bool, simulate:bool=False)->bool:
        need=amount-(self.fabric.config.total_vram_mb-self.fabric.config.reserved_vram_mb-self._used())
        if need<=0:return True
        victims=[x for x in self.loaded.values() if x["ref_count"]==0 and (include_pinned or not x["pin"])]
        victims.sort(key=lambda x:(x["pin"],x["last_used_monotonic"],x["ref_count"],x["vram_mb"],x["model_ref"]))
        freed=0
        for v in victims:
            freed+=int(v["vram_mb"])
            if not simulate:
                self._evict_entry((v["tenant_id"],v["model_ref"]),"making_room",tenant_id)
            if freed>=need:return True
        return False
    def load(self, handle: LoadHandle, *, context: Any) -> LoadedRef:
        try:
            return self._load_impl(handle, context=context)
        except Exception as exc:
            self.fabric._emit("LoadFailed", {"model_ref":handle.model_ref,"error":type(exc).__name__,"message":str(exc)[:500]}, context, handle.tenant_id)
            raise
    def _load_impl(self, handle: LoadHandle, *, context: Any) -> LoadedRef:
        tenant_id = _effective_tenant(context, handle.tenant_id)
        _require_ctx(context,(auth_scope_model_load,),handle.tenant_id)
        p=self.fabric.registry.get(*handle.model_ref.rsplit('@',1),context=context,tenant_id=handle.tenant_id)
        if p["state"]=="revoked": raise ModelRevoked(handle.model_ref)
        if p["state"]=="retired": raise ModelRetired(handle.model_ref)
        estimate=self.estimate_load(handle.model_ref,handle.config,context=context,tenant_id=handle.tenant_id)
        self.fabric._verify_artifacts(p)
        with self.lock:
            if not self._evict_for(estimate.total_mb,handle.tenant_id,False,simulate=False): raise InsufficientVram(f"cannot fit {handle.model_ref}: need {estimate.total_mb} MB")
            if self._used()+estimate.total_mb > self.fabric.config.total_vram_mb-self.fabric.config.reserved_vram_mb: raise InsufficientVram("VRAM budget exceeded")
            key=(handle.tenant_id,handle.model_ref)
            if key in self.loaded:
                self.loaded[key]["ref_count"]+=1; self.loaded[key]["last_used_at"]=_utc(); return LoadedRef(handle.tenant_id,handle.model_ref,handle.handle_id,int(self.loaded[key]["vram_mb"]))
            adapter=self.fabric.adapters.get(handle.model_ref)
            actual=adapter.load(p,handle.config) if adapter else estimate.total_mb
            actual=int(actual or estimate.total_mb)
            if actual > self.fabric.config.total_vram_mb-self.fabric.config.reserved_vram_mb-self._used():
                if adapter: adapter.unload(p)
                raise InsufficientVram("actual load would violate hard VRAM limit")
            self.loaded[key]={"tenant_id":handle.tenant_id,"model_ref":handle.model_ref,"loaded_at":_utc(),"vram_mb":actual,"runtime":handle.config.get("runtime",p["requirements"]["runtime"]),"context_tokens":int(handle.config.get("context_tokens",p["context_window"])),"batch_size":int(handle.config.get("batch_size",1)),"last_used_at":_utc(),"last_used_monotonic":time.monotonic(),"pin":handle.pin,"ref_count":1,"estimator_version":estimate.estimator_version}
            self.pending=[x for x in self.pending if x.handle_id!=handle.handle_id]
        if abs(actual-estimate.total_mb) > estimate.total_mb*self.fabric.config.deviation_threshold_fraction:
            self.fabric._emit("ResidencyEstimateDeviation",{"model_ref":handle.model_ref,"estimated_mb":estimate.total_mb,"actual_mb":actual,"estimator_version":estimate.estimator_version},context,handle.tenant_id)
        self.fabric._emit("Loaded",{"model_ref":handle.model_ref,"vram_mb":actual,"estimator_version":estimate.estimator_version},context,handle.tenant_id)
        return LoadedRef(handle.tenant_id,handle.model_ref,handle.handle_id,actual)
    def release(self, ref: LoadedRef) -> None:
        with self.lock:
            item=self.loaded.get((ref.tenant_id,ref.model_ref));
            if item: item["ref_count"]=max(0,int(item["ref_count"])-1); item["last_used_at"]=_utc(); item["last_used_monotonic"]=time.monotonic()
    def unload(self, ref: LoadedRef, *, context: Any) -> None:
        _require_ctx(context,(auth_scope_model_load,),ref.tenant_id)
        with self.lock:
            key=(ref.tenant_id,ref.model_ref); item=self.loaded.get(key)
            if not item: return
            if item["ref_count"]>0: raise ModelAccessDenied("model still referenced")
            self._evict_entry(key,"forced_unload",ref.tenant_id,emit_name="Unloaded",context=context)
    def _evict_entry(self,key:tuple[str,str],reason:str,actor_tenant:str,emit_name:str="Evicted",context:Any|None=None)->None:
        item=self.loaded.pop(key,None)
        if not item:return
        p=self.fabric.registry._checked(json.loads(self.fabric.registry._latest_row(item["model_ref"], item["tenant_id"])[0]))
        adapter=self.fabric.adapters.get(item["model_ref"])
        if adapter: adapter.unload(p)
        if context is not None:self.fabric._emit(emit_name,{"model_ref":item["model_ref"],"reason":reason},context,item["tenant_id"])
    def evict(self, model_ref_value:str, reason:str, *, context:Any, tenant_id:str)->None:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_load,),tenant_id)
        with self.lock:
            self._evict_entry((tenant_id,model_ref_value),reason,tenant_id,context=context)
    def reserve(self, amount_mb:int, reason:str, *, context:Any, tenant_id:str)->ReservationHandle:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_load,),tenant_id)
        amount=int(amount_mb)
        with self.lock:
            if amount<1 or self._used()+amount>self.fabric.config.total_vram_mb-self.fabric.config.reserved_vram_mb: raise InsufficientVram("reservation exceeds hard VRAM budget")
            h=ReservationHandle(_uuid(),tenant_id,amount,reason); self.reserved[h.handle_id]=h; return h
    def release_reservation(self,h:ReservationHandle)->None:
        with self.lock:self.reserved.pop(h.handle_id,None)
    def warmup(self, model_ref_value:str, config:Mapping[str,Any], *, context:Any, tenant_id:str)->LoadHandle:
        return self.request_load(model_ref_value,config,0,pin=False,context=context,tenant_id=tenant_id)

class KVCacheManager:
    def __init__(self, fabric:"ModelFabric", root:Path) -> None:
        self.fabric=fabric; self.root=root; self.root.mkdir(parents=True,exist_ok=True); self.lock=threading.RLock(); self.sessions:dict[tuple[str,str],dict[str,Any]]={}
    def open(self, model_ref_value:str, session_id:str, config:Mapping[str,Any], *, context:Any, tenant_id:str)->KVHandle:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_route,),tenant_id); self.fabric.registry.get(*model_ref_value.rsplit('@',1),context=context,tenant_id=tenant_id); key=(tenant_id,session_id)
        with self.lock:self.sessions[key]={"model_ref":model_ref_value,"tokens":[],"limit_mb":int(config.get("max_mb",256)),"last_used":_utc()}
        return KVHandle(tenant_id,session_id,model_ref_value)
    def _get(self,h:KVHandle)->dict[str,Any]:
        row=self.sessions.get((h.tenant_id,h.session_id));
        if row is None: raise ModelNotFound(h.session_id)
        return row
    def append(self,h:KVHandle,tokens:Sequence[int],*,context:Any)->KVHandle:
        h = KVHandle(_effective_tenant(context, h.tenant_id), h.session_id, h.model_ref)
        _require_ctx(context,(auth_scope_model_route,),h.tenant_id); row=self._get(h)
        p=self.fabric.registry.get(*h.model_ref.rsplit('@',1),context=context,tenant_id=h.tenant_id); per=int(p["resources"]["kv_cache_mb_per_1k_tokens"])
        row["tokens"].extend(int(x) for x in tokens); max_tokens=max(1,(row["limit_mb"]*1000)//max(1,per));
        if len(row["tokens"])>max_tokens: row["tokens"]=row["tokens"][-max_tokens:]
        row["last_used"]=_utc(); return h
    def truncate(self,h:KVHandle,keep_tokens:int,*,context:Any)->None:
        _require_ctx(context,(auth_scope_model_route,),h.tenant_id); row=self._get(h); row["tokens"]=row["tokens"][:max(0,int(keep_tokens))]
    def snapshot(self,h:KVHandle,*,context:Any)->str:
        h = KVHandle(_effective_tenant(context, h.tenant_id), h.session_id, h.model_ref)
        _require_ctx(context,(auth_scope_model_route,),h.tenant_id); row=copy.deepcopy(self._get(h)); doc={"tenant_id":h.tenant_id,"session_id":h.session_id,"model_ref":h.model_ref,"tokens":row["tokens"]}; digest=_sha(doc); (self.root/f"{digest}.json").write_text(json.dumps(doc,sort_keys=True,separators=(",",":")),encoding="utf-8"); self.fabric._emit("KvSnapshot",{"session_id":h.session_id,"snapshot_ref":f"sha256:{digest}"},context,h.tenant_id); return f"sha256:{digest}"
    def restore(self,snapshot_ref:str,*,context:Any)->KVHandle:
        raw=str(snapshot_ref).removeprefix("sha256:"); path=self.root/f"{raw}.json"
        if not path.exists(): raise ModelNotFound(snapshot_ref)
        doc=json.loads(path.read_text(encoding="utf-8")); tenant_id=doc["tenant_id"]; _require_ctx(context,(auth_scope_model_route,),tenant_id)
        if _sha(doc)!=raw: raise ModelIntegrityError("KV snapshot hash mismatch")
        h=self.open(doc["model_ref"],doc["session_id"],{},context=context,tenant_id=tenant_id); self.sessions[(tenant_id,h.session_id)]["tokens"]=list(doc["tokens"]); self.fabric._emit("KvRestored",{"session_id":h.session_id,"snapshot_ref":snapshot_ref},context,tenant_id); return h
    def close(self,h:KVHandle,*,context:Any)->None:
        h = KVHandle(_effective_tenant(context, h.tenant_id), h.session_id, h.model_ref)
        _require_ctx(context,(auth_scope_model_route,),h.tenant_id); self.sessions.pop((h.tenant_id,h.session_id),None)
    def inspect(self)->list[dict[str,Any]]:
        with self.lock:return [{"tenant_id":t,"session_id":s,"model_ref":v["model_ref"],"tokens":len(v["tokens"])} for (t,s),v in self.sessions.items()]

class BatchManager:
    def __init__(self,fabric:"ModelFabric"):self.fabric=fabric
    def form(self, model_ref_value:str, requests:Sequence[Mapping[str,Any]], config:Mapping[str,Any], *, context:Any, tenant_id:str)->Batch:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_batch,),tenant_id); cfg=dict(config)
        cfg.setdefault("max_batch_size",len(requests) or 1); cfg.setdefault("max_wait_ms",0); cfg.setdefault("max_tokens_per_batch",sum(int(r.get("tokens",r.get("max_tokens",0)) or 0) for r in requests)); cfg.setdefault("batching_mode","static"); cfg.setdefault("prioritization","fifo"); cfg.setdefault("isolation","per_tenant")
        schema=json.loads((SCHEMA_DIR/"batch_config_v1.schema.json").read_text()); SchemaValidator().validate_or_raise(cfg,schema); config=cfg
        isolation=str(config.get("isolation","per_tenant"));
        if isolation=="none" and auth_scope_model_admin not in getattr(context.auth_context,"scopes",()): raise BatchPolicyDenied("cross-tenant batching requires models.admin")
        if isolation not in ISOLATIONS: raise ModelValidationError("invalid batching isolation")
        normalized=[dict(r) for r in requests]; max_batch=int(config.get("max_batch_size",len(normalized) or 1)); normalized=normalized[:max_batch]
        mode=str(config.get("prioritization","fifo"));
        if mode=="priority": normalized.sort(key=lambda x:(-int(x.get("priority",0)),str(x.get("request_id",""))))
        elif mode=="deadline": normalized.sort(key=lambda x:(float(x.get("deadline_ms",float("inf"))),str(x.get("request_id",""))))
        else: normalized.sort(key=lambda x:str(x.get("sequence",x.get("request_id",""))))
        total_tokens=sum(int(x.get("tokens",x.get("max_tokens",0)) or 0) for x in normalized)
        if total_tokens>int(config["max_tokens_per_batch"]): raise BatchPolicyDenied("batch token budget exceeded")
        batch=Batch(_uuid(),model_ref_value,tuple(normalized)); self.fabric._emit("BatchFormed",{"batch_id":batch.batch_id,"model_ref":model_ref_value,"request_ids":[str(x.get("request_id","")) for x in normalized]},context,tenant_id); return batch
    def execute(self,batch:Batch,*,context:Any,tenant_id:str)->tuple[Any,...]:
        tenant_id=_effective_tenant(context,tenant_id); _require_ctx(context,(auth_scope_model_batch,),tenant_id)
        out=tuple(self.fabric.roles.invoke(batch.model_ref,r,context=context,tenant_id=tenant_id) for r in batch.requests)
        self.fabric._emit("BatchExecuted",{"batch_id":batch.batch_id,"model_ref":batch.model_ref,"count":len(out)},context,tenant_id); return out

class RoleAdapterManager:
    def __init__(self,fabric:"ModelFabric"):self.fabric=fabric
    def invoke(self, model_ref_value:str, request:Mapping[str,Any], *, context:Any, tenant_id:str)->Any:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_route,),tenant_id); p=self.fabric.registry.get(*model_ref_value.rsplit('@',1),context=context,tenant_id=tenant_id); role=p["role"]; _validate_role_request(role,request); adapter=self.fabric.adapters.get(model_ref_value)
        if adapter is None: raise ModelFabricError(f"no adapter registered for {model_ref_value}")
        result=adapter.invoke(p,request,context)
        try:
            _validate_role_response(role,result)
        except Exception as exc:
            self.fabric._emit("ResponseMismatch",{"model_ref":model_ref_value,"role":role,"error":type(exc).__name__},context,tenant_id)
            raise
        return result
    def health(self,model_ref_value:str,*,context:Any,tenant_id:str)->Mapping[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_read,),tenant_id); p=self.fabric.registry.get(*model_ref_value.rsplit('@',1),context=context,tenant_id=tenant_id); a=self.fabric.adapters.get(model_ref_value); return a.health(p) if a else {"ok":False,"reason":"no_adapter"}
    def stream(self, model_ref_value:str, request:Mapping[str,Any], *, context:Any, tenant_id:str):
        tenant_id = _effective_tenant(context, tenant_id)
        _require_ctx(context,(auth_scope_model_route,),tenant_id); p=self.fabric.registry.get(*model_ref_value.rsplit('@',1),context=context,tenant_id=tenant_id); _validate_role_request(p["role"],request); a=self.fabric.adapters.get(model_ref_value)
        if a is None: raise ModelFabricError(f"no adapter registered for {model_ref_value}")
        raw = a.stream(p,request,context) if hasattr(a,"stream") else iter((a.invoke(p,request,context),))
        for item in raw:
            _validate_role_response(p["role"],item); yield item

def _validate_role_request(role:str, request:Mapping[str,Any])->None:
    if role in {"reasoning","general","small","classifier"} and not any(k in request for k in ("prompt","input")): raise ModelValidationError("text model requires prompt/input")
    if role=="embedding" and "input" not in request: raise ModelValidationError("embedding requires input")
    if role=="reranker" and not {"query","documents"}.issubset(request): raise ModelValidationError("reranker requires query/documents")
    if role=="vision" and "image" not in request: raise ModelValidationError("vision requires image")
    if role=="asr" and "audio" not in request: raise ModelValidationError("ASR requires audio")
    if role=="tts" and "text" not in request: raise ModelValidationError("TTS requires text")
def _validate_role_response(role:str,response:Any)->None:
    if role=="embedding" and not isinstance(response,Mapping): raise ModelValidationError("embedding response must be object")
    if role=="reranker" and (not isinstance(response,Mapping) or "scores" not in response): raise ModelValidationError("reranker response requires scores")
    if role=="vision" and (not isinstance(response,Mapping) or "description" not in response): raise ModelValidationError("vision response requires description")
    if role=="asr" and (not isinstance(response,Mapping) or "transcript" not in response): raise ModelValidationError("ASR response requires transcript")
    if role=="tts" and (not isinstance(response,Mapping) or "audio_ref" not in response): raise ModelValidationError("TTS response requires audio_ref")

class ModelFabric:
    def __init__(self, *, config:ModelConfig|None=None, signer:Ed25519PrivateKey|None=None, key_id:str="model-fabric", event_fabric:EventFabric|None=None, kv_root:str|Path|None=None, secret_broker:Any|None=None, measurement_refresher:Callable[[dict[str,Any]],Mapping[str,Any]]|None=None, revoke_propagator:Callable[[str],None]|None=None, audit_verifier:Callable[[Mapping[str,Any],str],bool]|None=None, public_keys:Mapping[str,bytes|Ed25519PublicKey]|None=None, artifact_resolver:Callable[[Mapping[str,Any]],bytes|str|Path]|None=None, cloud_jurisdiction_policy:Callable[[Mapping[str,Any],str],bool]|None=None, accounting_hook:Callable[[str,float,str],None]|None=None) -> None:
        self.config=config or ModelConfig(); self.signer=signer or Ed25519PrivateKey.generate(); self.key_id=key_id; self.secret_broker=secret_broker; self.measurement_refresher=measurement_refresher; self.revoke_propagator=revoke_propagator; self.audit_verifier=audit_verifier; self.artifact_resolver=artifact_resolver; self.cloud_jurisdiction_policy=cloud_jurisdiction_policy; self.accounting_hook=accounting_hook
        self.registry=ModelRegistry(self.config.registry_path,self.config.storage_secret,self.signer,key_id,public_keys); self.event_fabric=event_fabric; self.event_log:list[dict[str,Any]]=[]; self.quantizations=QuantizationRegistry(trusted_public_keys={key_id:self.public_key}); self.estimator=VRAMEstimator(self.config.fragmentation_fraction); self.adapters:dict[str,ModelAdapter]={}; self.residency=ModelResidencyManager(self); self.kv=KVCacheManager(self,Path(kv_root or Path(self.config.registry_path).with_suffix(".kv"))); self.batch=BatchManager(self); self.roles=RoleAdapterManager(self); self._closed=False; self.determinism_proofs:dict[str,dict[str,Any]]={}
    @property
    def public_key(self)->bytes:return self.signer.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
    def _mode(self,context:Any)->str:
        value=getattr(getattr(context,"execution_mode",None),"value",getattr(context,"execution_mode","trusted")); return str(value).lower()
    def register_determinism_proof(self, proof: Mapping[str,Any], *, context:Any, tenant_id:str="default") -> str:
        tenant_id=_effective_tenant(context,tenant_id); _require_ctx(context,(auth_scope_model_write,),tenant_id)
        schema=json.loads((SCHEMA_DIR/"model_determinism_proof_v1.schema.json").read_text()); SchemaValidator().validate_or_raise(dict(proof),schema)
        unsigned=dict(proof); signature=str(unsigned.get("signature")); unsigned["signature"]=""
        self.signer.public_key().verify(_decode_b64(signature),canonical_bytes(unsigned))
        ref=determinism_proof_ref(proof); self.determinism_proofs[ref]={"tenant_id":tenant_id,**copy.deepcopy(dict(proof))}; return ref

    def verify_determinism_proof(self, ref:str, profile:Mapping[str,Any], tenant_id:str) -> bool:
        proof=self.determinism_proofs.get(str(ref));
        if not proof or proof.get("tenant_id")!=tenant_id or proof.get("model_ref")!=model_ref(profile): return False
        try:
            unsigned=dict(proof); unsigned.pop("tenant_id",None); signature=str(unsigned.get("signature")); unsigned["signature"]=""; self.signer.public_key().verify(_decode_b64(signature),canonical_bytes(unsigned)); unsigned_no_sig=dict(unsigned); unsigned_no_sig.pop("signature",None); return hmac.compare_digest(str(ref),"urn:jarvis:model-determinism:"+_sha(unsigned_no_sig))
        except Exception: return False

    def _estimate(self,p:Mapping[str,Any], *, runtime:str, context_tokens:int, batch_size:int, concurrent_requests:int) -> VRAMEstimate:
        multiplier=1.0
        if p["quantization"]!="none":
            qid=p.get("quantization_profile_ref") or p["quantization"]; multiplier=float(self.quantizations.get(qid).get("vram_multiplier",1.0))
        return self.estimator.estimate(p,runtime=runtime,context_tokens=context_tokens,batch_size=batch_size,concurrent_requests=concurrent_requests,gpu_arch=self.config.gpu_arch,environment_hash=self.config.environment_hash,quantization_vram_multiplier=multiplier)

    def _check_quantization(self,p:Mapping[str,Any],runtime:str)->None:
        qid=p["quantization_profile_ref"] if p.get("quantization_profile_ref") else p["quantization"]
        if p["quantization"]=="none":return
        q=self.quantizations.get(qid); validate_quantization_compatibility(q,runtime,self.config.gpu_arch,p["role"])
    def _emit(self,name:str,payload:Mapping[str,Any],context:Any,tenant_id:str)->None:
        auth=getattr(context,"auth_context",None)
        if auth is None: raise ModelAccessDenied("event emission requires execution auth context")
        auth_ctx=AuthContext(str(auth.principal),tuple(str(x) for x in auth.scopes),getattr(auth,"policy_ref",None),getattr(auth,"delegated_by",None))
        env=EventEnvelope.create(event_type="Model",event_name=name,payload=dict(payload),produced_by=ProducedBy("system","model_fabric",None,"system"),auth_context=auth_ctx,tenant_id=tenant_id,partition_key=str(payload.get("model_ref",tenant_id)),correlation_id=str(getattr(context,"correlation_id",_uuid())),causation_id=str(getattr(context,"causation_id",None)) if getattr(context,"causation_id",None) else None,signing_key=self.signer,lineage=EventLineage())
        if self.event_fabric is not None:
            self.event_fabric.publish_envelope(env)
        self.event_log.append(env.to_dict())
    def _verify_artifacts(self, profile:Mapping[str,Any]) -> None:
        for artifact in profile.get("artifacts",()):
            expected=str(artifact.get("sha256",""))
            uri=str(artifact.get("uri",""))
            if not expected or not re.fullmatch(r"[0-9a-f]{64}",expected): raise ArtifactHashMismatch(f"invalid artifact hash for {uri}")
            if self.artifact_resolver is None:
                if uri != "sha256:" + expected: raise ArtifactHashMismatch(f"artifact URI/hash mismatch for {uri}")
                continue
            raw=self.artifact_resolver(artifact)
            if isinstance(raw,(str,Path)): data=Path(raw).read_bytes()
            else: data=bytes(raw)
            actual=hashlib.sha256(data).hexdigest()
            if not hmac.compare_digest(actual,expected): raise ArtifactHashMismatch(f"artifact hash mismatch for {uri}")
    def replay(self, events:Sequence[Mapping[str,Any]]|None=None) -> dict[str,Any]:
        state={"loaded":{},"routes":{}}
        source=list(events) if events is not None else list(self.event_log)
        for event in source:
            if str(event.get("event_type"))!="Model": continue
            name=str(event.get("event_name")); payload=dict(event.get("payload",{})); ref=payload.get("model_ref")
            if name=="Loaded" and ref: state["loaded"][ref]=payload
            elif name in {"Unloaded","Evicted"} and ref: state["loaded"].pop(ref,None)
            elif name=="Routed" and payload.get("request_id"): state["routes"][payload["request_id"]]=payload
        return state
    def register_model(self,profile:Mapping[str,Any],*,context:Any,tenant_id:str="default",adapter:ModelAdapter|None=None)->str:
        tenant_id = _effective_tenant(context, tenant_id)
        ref=self.registry.register(profile,context=context,tenant_id=tenant_id); self.adapters[ref]=adapter or DeterministicAdapter(); self._emit("Registered",{"model_ref":ref,"state":profile.get("state","registered")},context,tenant_id); return ref
    def register_quantization(self,profile:Mapping[str,Any])->None:
        self.quantizations.register(profile)
    def pin(self,ref:str,*,context:Any,tenant_id:str="default",reason:str="")->dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        p=self.registry.pin(ref,context=context,tenant_id=tenant_id,reason=reason)
        if self.audit_verifier is not None and self.audit_verifier(p, reason):
            p["trust"]="verified"
            p=sign_profile(p,self.signer,self.key_id)
            with self.registry.lock,self.registry.db: self.registry._append(ref,p,"pin_audit_verified",tenant_id)
        self._emit("Pinned",{"model_ref":ref,"reason":reason,"audit_verified":p.get("trust")=="verified"},context,tenant_id); return p
    def deprecate(self,ref:str,successor_ref:str|None,*,context:Any,tenant_id:str="default",reason:str="")->dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        p=self.registry.deprecate(ref,successor_ref,context=context,tenant_id=tenant_id,reason=reason); self._emit("Deprecated",{"model_ref":ref,"successor_ref":successor_ref,"reason":reason},context,tenant_id); return p
    def retire(self,ref:str,successor_ref:str|None,*,context:Any,tenant_id:str="default",reason:str="")->dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        p=self.registry.retire(ref,successor_ref,context=context,tenant_id=tenant_id,reason=reason); self._emit("Retired",{"model_ref":ref,"successor_ref":successor_ref,"reason":reason},context,tenant_id); return p
    def revoke(self,ref:str,*,context:Any,tenant_id:str="default",reason:str="")->dict[str,Any]:
        tenant_id = _effective_tenant(context, tenant_id)
        p=self.registry.revoke(ref,context=context,tenant_id=tenant_id,reason=reason); self._emit("Revoked",{"model_ref":ref,"reason":reason},context,tenant_id)
        if self.revoke_propagator is not None:self.revoke_propagator(ref)
        self._emit("RevocationPropagated",{"model_ref":ref},context,tenant_id); return p
    def route(self,request:Mapping[str,Any],*,context:Any)->RoutingDecision:
        tenant_id=str(request["tenant_id"])
        try:
            return self._route_impl(request,context=context)
        except Exception as exc:
            try: self._emit("RoutingFailed", {"request_id":str(request.get("request_id","")),"error":type(exc).__name__,"message":str(exc)[:500]}, context, tenant_id)
            finally: pass
            raise
    def _route_impl(self,request:Mapping[str,Any],*,context:Any)->RoutingDecision:
        tenant_id=str(request["tenant_id"]); _require_ctx(context,(auth_scope_model_route,),tenant_id)
        role=str(request["role"]); mode=str(request["execution_mode"]); required=set(request.get("required_capabilities",())); trust_floor=str(request.get("trust_floor","verified")); candidates=self.registry.list(context=context,tenant_id=tenant_id,role=role)
        disqualified={}; eligible=[]; now=time.time()
        for summary in candidates:
            ref=summary["model_ref"]
            try:p=self.registry.get(*ref.rsplit('@',1),context=context,tenant_id=tenant_id)
            except Exception as exc:disqualified[ref]=type(exc).__name__;continue
            reasons=[]
            measured=p["performance"].get("measured_at")
            if measured:
                try:
                    age=time.time()-datetime.fromisoformat(str(measured).replace("Z","+00:00")).timestamp()
                    if age>self.config.measurement_max_age_seconds:
                        if self.measurement_refresher is not None:
                            patch=dict(self.measurement_refresher(copy.deepcopy(p))); p["performance"].update(patch)
                            refreshed=p["performance"].get("measured_at")
                            if not refreshed: reasons.append("stale_measurement")
                        else: reasons.append("stale_measurement")
                except ValueError: reasons.append("invalid_measurement_time")
            if p["state"] in {"revoked","retired","deprecated"}: reasons.append(p["state"])
            if TRUST_RANK[p["trust"]] < max(TRUST_RANK.get(trust_floor,0),MODE_MIN_TRUST.get(mode,3)): reasons.append("trust_floor")
            if request.get("privacy_required") and p["residency"]=="cloud": reasons.append("privacy_cloud")
            if request.get("preferred_residency") and p["residency"] != request["preferred_residency"] and p["residency"] != "hybrid": reasons.append("residency")
            if p["context_window"] < int(request["context_tokens_needed"]): reasons.append("context_window")
            if float(p["performance"]["quality_score"]) < float(request["quality_floor"]): reasons.append("quality")
            if float(p["performance"]["latency_ms_p95"]) > float(request["latency_budget_ms"]): reasons.append("latency")
            if request.get("cost_budget") is not None and p["performance"].get("cost_per_1k_tokens") is not None and float(p["performance"]["cost_per_1k_tokens"]) > float(request["cost_budget"]): reasons.append("cost")
            if required and not required.issubset(set(p.get("capabilities",()))): reasons.append("capability")
            if request.get("determinism_required") and not self.verify_determinism_proof(str(p.get("determinism_proof_ref") or ""),p,tenant_id): reasons.append("determinism")
            if p["residency"]=="cloud" and auth_scope_model_cloud not in set(getattr(getattr(context,"auth_context",None),"scopes",())) and auth_scope_model_admin not in set(getattr(getattr(context,"auth_context",None),"scopes",())): reasons.append("cloud_scope")
            if p["residency"] in {"cloud","hybrid"}:
                region=str(p.get("cloud",{}).get("region") or "")
                allowed=self.cloud_jurisdiction_policy(p,region) if self.cloud_jurisdiction_policy is not None else (not self.config.allowed_cloud_regions or region in self.config.allowed_cloud_regions)
                if not allowed: reasons.append("cloud_jurisdiction")
            if not reasons: eligible.append(p)
            else: disqualified[ref]=reasons
        if request.get("privacy_required") and not eligible:
            raise PrivacyViolation(json.dumps(disqualified,sort_keys=True))
        if not eligible:
            raise NoEligibleModel(json.dumps({"reason":"NoEligibleModel","disqualifiers":disqualified},sort_keys=True))
        local=[p for p in eligible if p["residency"] in {"local","hybrid"}]; cloud=[p for p in eligible if p["residency"]=="cloud"]
        preferred=str(request.get("preferred_residency") or "local")
        pool=cloud if preferred=="cloud" else (local if local else cloud)
        if not pool: pool=eligible
        pool.sort(key=lambda p:(float(p["performance"]["cost_per_1k_tokens"] if p["performance"].get("cost_per_1k_tokens") is not None else 0.0),-float(p["performance"]["quality_score"]),float(p["performance"]["latency_ms_p95"]),p["model_id"]))
        chosen=pool[0]
        all_ordered=sorted(eligible,key=lambda p:(0 if p["residency"] in {"local","hybrid"} else 1,float(p["performance"]["cost_per_1k_tokens"] if p["performance"].get("cost_per_1k_tokens") is not None else 0.0),-float(p["performance"]["quality_score"]),float(p["performance"]["latency_ms_p95"]),p["model_id"]))
        fallbacks=tuple(model_ref(x) for x in all_ordered if model_ref(x)!=model_ref(chosen))
        est=None
        if chosen["residency"] in {"local","hybrid"}:est=self._estimate(chosen,runtime=chosen["requirements"]["runtime"],context_tokens=int(request["context_tokens_needed"]),batch_size=1,concurrent_requests=1)
        reason={"policy_version":"2.0.0","role":role,"candidate_count":len(eligible),"disqualified":disqualified,"privacy_required":bool(request.get("privacy_required")),"determinism_required":bool(request.get("determinism_required"))}
        decision=RoutingDecision(str(request["request_id"]),model_ref(chosen),fallbacks,reason,est.total_mb if est else None,float(chosen["performance"]["latency_ms_p50"]),float(chosen["performance"].get("cost_per_1k_tokens") or 0.0),est.estimator_version if est else self.estimator.version,_utc(),"")
        unsigned=decision.__dict__ if hasattr(decision,"__dict__") else {"request_id":decision.request_id,"chosen_model_ref":decision.chosen_model_ref,"fallback_chain":list(decision.fallback_chain),"reason":decision.reason,"estimated_vram_mb":decision.estimated_vram_mb,"estimated_latency_ms":decision.estimated_latency_ms,"estimated_cost":decision.estimated_cost,"estimator_version":decision.estimator_version,"policy_version":decision.policy_version,"decided_at":decision.decided_at}
        signature=_b64(self.signer.sign(canonical_bytes(unsigned))); decision=RoutingDecision(**{**unsigned,"fallback_chain":tuple(unsigned["fallback_chain"]),"signature":signature})
        self._emit("Routed",{"request_id":decision.request_id,"chosen_model_ref":decision.chosen_model_ref,"fallback_chain":list(decision.fallback_chain)},context,tenant_id); return decision
    def verify_routing_decision(self,decision:RoutingDecision)->bool:
        unsigned={"request_id":decision.request_id,"chosen_model_ref":decision.chosen_model_ref,"fallback_chain":list(decision.fallback_chain),"reason":decision.reason,"estimated_vram_mb":decision.estimated_vram_mb,"estimated_latency_ms":decision.estimated_latency_ms,"estimated_cost":decision.estimated_cost,"estimator_version":decision.estimator_version,"policy_version":decision.policy_version,"decided_at":decision.decided_at}
        try:self.signer.public_key().verify(_decode_b64(decision.signature),canonical_bytes(unsigned));return True
        except (InvalidSignature,ValueError):return False
    def speculative(self,config:Mapping[str,Any],target_ref:str,draft_ref:str,prompt:Mapping[str,Any],*,context:Any,tenant_id:str,target_runner:Callable[[],Any],draft_runner:Callable[[],Any])->Any:
        tenant_id=_effective_tenant(context,tenant_id); _require_ctx(context,(auth_scope_model_speculate,),tenant_id); mode=self._mode(context)
        cfg=dict(config); cfg.setdefault("draft_model_ref",draft_ref); cfg.setdefault("target_model_ref",target_ref); cfg.setdefault("acceptance_threshold",1.0); cfg.setdefault("max_speculative_tokens",1); cfg.setdefault("fallback_on_reject","target_only")
        schema=json.loads((SCHEMA_DIR/"speculative_config_v1.schema.json").read_text()); SchemaValidator().validate_or_raise(cfg,schema); config=cfg
        if mode not in {"trusted","restricted"}: raise SpeculationPolicyDenied("speculative execution requires trusted/restricted mode")
        target=self.registry.get(*target_ref.rsplit('@',1),context=context,tenant_id=tenant_id); draft=self.registry.get(*draft_ref.rsplit('@',1),context=context,tenant_id=tenant_id)
        if not target.get("supports_speculative") or not draft.get("supports_speculative"): raise SpeculationPolicyDenied("profiles do not declare speculative support")
        if target.get("trust") not in {"verified","pinned"} or draft.get("trust") not in {"verified","pinned"}: raise SpeculationPolicyDenied("speculative models require trusted profiles")
        tc=self._estimate(target,runtime=target["requirements"]["runtime"],context_tokens=int(prompt.get("context_tokens",target["context_window"])),batch_size=1,concurrent_requests=1)
        dc=self._estimate(draft,runtime=draft["requirements"]["runtime"],context_tokens=int(prompt.get("context_tokens",draft["context_window"])),batch_size=1,concurrent_requests=1)
        if self.residency.inspect()["gpu"]["used_vram_mb"] + tc.total_mb + dc.total_mb > self.config.total_vram_mb-self.config.reserved_vram_mb: raise SpeculationPolicyDenied("insufficient spare VRAM for speculative execution")
        d=draft_runner(); t=target_runner();
        if d!=t:self._emit("SpeculativeDeviation",{"target_model_ref":target_ref,"draft_model_ref":draft_ref,"reason":"output_mismatch"},context,tenant_id)
        return t
    def cloud_invoke(self,ref:str,request:Mapping[str,Any],*,context:Any,tenant_id:str)->Any:
        tenant_id = _effective_tenant(context, tenant_id)
        auth=_require_ctx(context,(auth_scope_model_cloud,),tenant_id); p=self.registry.get(*ref.rsplit('@',1),context=context,tenant_id=tenant_id)
        if p["residency"] not in {"cloud","hybrid"}: raise ModelFabricError("model is not cloud-capable")
        auth_ref=p.get("cloud",{}).get("auth_ref")
        if not auth_ref or self.secret_broker is None: raise CloudCredentialError("cloud credentials must come from P2-E secret broker")
        credential=self.secret_broker.get(auth_ref, auth) if hasattr(self.secret_broker,"get") else None
        if credential in {None,""}: raise CloudCredentialError("secret broker did not return credential")
        region=str(p.get("cloud",{}).get("region") or "")
        if self.cloud_jurisdiction_policy is not None:
            if not self.cloud_jurisdiction_policy(p, region): raise PrivacyViolation("cloud jurisdiction is not authorized")
        elif self.config.allowed_cloud_regions and region not in self.config.allowed_cloud_regions:
            raise PrivacyViolation("cloud jurisdiction is not authorized")
        cost=float(p.get("performance",{}).get("cost_per_1k_tokens") or 0.0)
        if self.accounting_hook is not None: self.accounting_hook(ref,cost,tenant_id)
        return self.roles.invoke(ref,request,context=context,tenant_id=tenant_id)
    def close(self)->None:
        if self._closed: return
        self._closed=True
        self.registry.close()

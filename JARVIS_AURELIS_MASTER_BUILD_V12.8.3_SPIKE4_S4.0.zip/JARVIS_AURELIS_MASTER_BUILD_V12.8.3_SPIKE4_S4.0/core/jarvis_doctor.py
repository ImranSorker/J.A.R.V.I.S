"""Self-diagnostic capability matrix for J.A.R.V.I.S."""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import hashlib
import re
import threading
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """One non-invasive diagnostic result."""

    name: str
    status: str
    detail: str


class JarvisDoctor:
    """Bounded diagnostics with no automatic privileged remediation."""

    def __init__(self, *, workspace: str | Path, model_root: str | Path | None = None) -> None:
        self.workspace = Path(workspace).resolve()
        self.model_root = Path(model_root).resolve() if model_root else None

    def run(self) -> tuple[Diagnostic, ...]:
        """Return deterministic diagnostics for installed runtime capabilities."""
        checks: list[Diagnostic] = [
            Diagnostic("python", "OK", platform.python_version()),
            Diagnostic("platform", "OK", platform.platform()),
            Diagnostic("workspace", "OK" if self.workspace.is_dir() else "WARN", str(self.workspace)),
        ]
        for module in ("pytest", "httpx", "numpy"):
            checks.append(Diagnostic(f"python:{module}", "OK" if importlib.util.find_spec(module) else "MISSING", "importable" if importlib.util.find_spec(module) else "not installed"))
        for executable in ("git", "nvidia-smi", "flutter", "go", "cargo", "dotnet", "javac", "bwrap", "unshare", "wasmtime"):
            checks.append(Diagnostic(f"tool:{executable}", "OK" if shutil.which(executable) else "MISSING", shutil.which(executable) or "not found"))
        try:
            from core.frontier_batch import CudaRuntimeProbe
            cuda = CudaRuntimeProbe().snapshot()
            checks.append(Diagnostic("cuda_runtime", "OK" if cuda.get("available") else "INFO", json.dumps({"provider": cuda.get("provider"), "devices": cuda.get("devices", []), "reason": cuda.get("reason")}, sort_keys=True)))
        except Exception as exc:
            checks.append(Diagnostic("cuda_runtime", "WARN", f"{type(exc).__name__}: {exc}"))
        checks.append(Diagnostic("master_secret", "OK" if bool(os.environ.get("JARVIS_MASTER_SECRET")) else "MISSING", "environment-backed secret" if os.environ.get("JARVIS_MASTER_SECRET") else "not configured"))
        checks.extend(self._hardening_checks())
        if self.model_root is not None:
            checks.append(Diagnostic("models", "OK" if self.model_root.is_dir() else "MISSING", str(self.model_root)))
        return tuple(checks)


    def _hardening_checks(self) -> list[Diagnostic]:
        """Run non-invasive reliability/zero-trust integrity checks."""
        checks: list[Diagnostic] = []
        try:
            from core.zero_trust import ZeroTrustAuthority
            authority = ZeroTrustAuthority()
            lease = authority.issue_lease(subject="doctor", audience="doctor", capabilities=("diagnostic.read",), policy_digest="doctor-policy", ttl_seconds=10.0)
            verified = authority.verify_lease(lease, subject="doctor", audience="doctor", capability="diagnostic.read", policy_digest="doctor-policy", consume_nonce=False)
            checks.append(Diagnostic("zero_trust_signing", "OK" if verified else "FAIL", "Ed25519 capability lease verification"))
            authority.revoke_lease(lease.lease_id)
            checks.append(Diagnostic("zero_trust_revocation", "OK" if not authority.verify_lease(lease, subject="doctor", audience="doctor", capability="diagnostic.read", policy_digest="doctor-policy", consume_nonce=False) else "FAIL", "emergency lease revocation"))
        except Exception as exc:
            checks.append(Diagnostic("zero_trust_signing", "WARN", f"{type(exc).__name__}: {exc}"))
        try:
            from core.event_bus import EventBus
            from core.event_fabric import EventFabric
            path = self.workspace / ".doctor-events.jsonl"
            bus = EventBus(max_queue_size=8)
            fabric = EventFabric(bus, path)
            fabric.publish("doctor.probe", {"ok": True}, source="jarvis-doctor")
            bus._q.join()
            valid = fabric.verify_journal()
            fabric.close(); bus.shutdown()
            try: path.unlink()
            except OSError:
                checks.append(Diagnostic("doctor_event_cleanup", "WARN", "temporary diagnostic journal could not be removed"))
            checks.append(Diagnostic("event_integrity", "OK" if valid else "FAIL", "event envelope/journal integrity verification"))
        except Exception as exc:
            checks.append(Diagnostic("event_integrity", "WARN", f"{type(exc).__name__}: {exc}"))
        checks.append(Diagnostic("thread_baseline", "OK", f"{len(threading.enumerate())} live threads"))
        return checks

    def summary(self) -> dict[str, Any]:
        """Return aggregate health without secret values."""
        rows = [asdict(item) for item in self.run()]
        return {"checks": rows, "ok": all(item["status"] != "MISSING" for item in rows)}

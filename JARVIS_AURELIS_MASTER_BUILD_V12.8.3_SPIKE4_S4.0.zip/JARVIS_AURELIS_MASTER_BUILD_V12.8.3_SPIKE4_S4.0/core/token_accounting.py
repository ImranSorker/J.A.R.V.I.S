"""Token and cost accounting for model backend calls (V12.8.0 observability upgrade).

State-of-the-art production observability requires knowing what every inference
call costs. This module provides a thread-safe, per-session ledger that:

- records per-call token usage (prompt/completion) with provenance
  (request_id, session_id, model, backend, timestamp);
- estimates cost from a configurable per-model price table
  (USD per 1K prompt / 1K completion tokens);
- enforces per-session and global token budgets with a hard
  ``BudgetExceededError`` (fail-fast, never silent downgrade);
- detects burst anomalies via a sliding-window rate check;
- emits structured JSONL audit events for every recorded call;
- exposes aggregated stats for health endpoints and metrics scrapers.

No external dependencies beyond the standard library. All monetary values are
decimal-free integer micro-dollars internally to avoid float drift; public API
accepts and returns float USD for convenience.
"""
from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


class BudgetExceededError(Exception):
    """Raised when a token or cost budget would be exceeded.

    Hard failure by design: the caller must shed load, queue, or reject —
    the ledger never silently truncates or drops accounting state.
    """


@dataclass(frozen=True)
class ModelPrice:
    """USD price per 1K tokens for one model."""

    prompt_per_1k: float
    completion_per_1k: float


@dataclass(frozen=True)
class TokenUsage:
    """Immutable record of one inference call."""

    request_id: str
    session_id: str
    model: str
    backend: str
    prompt_tokens: int
    completion_tokens: int
    timestamp: float = field(default_factory=time.time)

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


@dataclass
class SessionAccount:
    """Running totals for one session."""

    session_id: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    calls: int = 0
    models: set = field(default_factory=set)
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)


class TokenLedger:
    """Thread-safe token/cost ledger with budgets and anomaly detection.

    Args:
        price_table: mapping of model name -> ModelPrice. Unknown models are
            priced at ``default_price`` (zero-cost default is safe: never
            invent a price, and never over-charge).
        session_token_budget: hard cap on total tokens per session; None = unlimited.
        session_cost_budget_usd: hard cap on estimated cost per session; None = unlimited.
        global_token_budget: hard cap across all sessions; None = unlimited.
        window_seconds / max_calls_per_window: sliding-window burst detector;
            a call that exceeds the rate raises ``BudgetExceededError``.
        audit_path: optional JSONL sink for per-call accounting events.
    """

    def __init__(
        self,
        price_table: Optional[Dict[str, ModelPrice]] = None,
        default_price: Optional[ModelPrice] = None,
        session_token_budget: Optional[int] = None,
        session_cost_budget_usd: Optional[float] = None,
        global_token_budget: Optional[int] = None,
        window_seconds: float = 60.0,
        max_calls_per_window: int = 240,
        audit_path: Optional[str] = None,
        max_request_ids: int = 100_000,
    ) -> None:
        self._price_table = dict(price_table or {})
        self._default_price = default_price or ModelPrice(0.0, 0.0)
        self._session_token_budget = session_token_budget
        self._session_cost_budget_usd = session_cost_budget_usd
        self._global_token_budget = global_token_budget
        self._window_seconds = float(window_seconds)
        self._max_calls_per_window = int(max_calls_per_window)
        self._audit_path = Path(audit_path) if audit_path else None
        self._max_request_ids = max(1024, min(int(max_request_ids), 5_000_000))
        if self._audit_path:
            self._audit_path.parent.mkdir(parents=True, exist_ok=True)

        self._lock = threading.RLock()
        self._sessions: Dict[str, SessionAccount] = {}
        self._global_prompt = 0
        self._global_completion = 0
        self._global_cost_micros = 0
        self._call_timestamps: List[float] = []
        self._total_calls = 0
        self._request_ids: set[str] = set()
        self._request_id_order: List[str] = []

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------
    def price_for(self, model: str) -> ModelPrice:
        """Return the price for a model; falls back to the default price."""
        return self._price_table.get(model, self._default_price)

    @staticmethod
    def _cost_micros(usage: TokenUsage, price: ModelPrice) -> int:
        """Exact cost in integer micro-dollars (1e-6 USD)."""
        prompt = usage.prompt_tokens * price.prompt_per_1k / 1000.0
        completion = usage.completion_tokens * price.completion_per_1k / 1000.0
        return int(round((prompt + completion) * 1_000_000))

    def preflight(
        self,
        *,
        session_id: str,
        model: str,
        prompt_tokens: int,
        max_completion_tokens: int,
    ) -> None:
        """Fail before inference when configured token/cost budgets cannot fit the request."""
        if not session_id or not model:
            raise ValueError("session_id and model are required")
        if prompt_tokens < 0 or max_completion_tokens < 0:
            raise ValueError("token counts must be non-negative")
        with self._lock:
            session = self._sessions.get(session_id)
            session_total = 0 if session is None else session.prompt_tokens + session.completion_tokens
            requested = prompt_tokens + max_completion_tokens
            if self._session_token_budget is not None and session_total + requested > self._session_token_budget:
                raise BudgetExceededError(
                    f"session token budget would be exceeded: {session_total + requested} > {self._session_token_budget}"
                )
            global_total = self._global_prompt + self._global_completion
            if self._global_token_budget is not None and global_total + requested > self._global_token_budget:
                raise BudgetExceededError(
                    f"global token budget would be exceeded: {global_total + requested} > {self._global_token_budget}"
                )
            price = self.price_for(model)
            projected = (prompt_tokens * price.prompt_per_1k + max_completion_tokens * price.completion_per_1k) / 1000.0
            if self._session_cost_budget_usd is not None:
                current = 0.0 if session is None else session.cost_usd
                if current + projected > self._session_cost_budget_usd:
                    raise BudgetExceededError(
                        f"session cost budget would be exceeded: {current + projected:.6f} USD > {self._session_cost_budget_usd}"
                    )

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------
    def record(self, usage: TokenUsage) -> Dict[str, Any]:
        """Record one call; enforce budgets and rate window atomically.

        Returns the accounting entry (dict) that was recorded. Raises
        ``BudgetExceededError`` *before* mutating any state when a budget
        would be exceeded — the ledger is never left partially updated by
        a rejected call.
        """
        if usage.prompt_tokens < 0 or usage.completion_tokens < 0:
            raise ValueError("token counts must be non-negative")
        if not usage.request_id or not usage.session_id or not usage.model:
            raise ValueError("request_id, session_id and model are required")

        with self._lock:
            now = time.time()
            if usage.request_id in self._request_ids:
                raise ValueError(f"duplicate request_id: {usage.request_id}")
            self._enforce_rate_window(now)

            price = self.price_for(usage.model)
            cost_micros = self._cost_micros(usage, price)

            session = self._sessions.get(usage.session_id)
            if session is None:
                session = SessionAccount(session_id=usage.session_id)
            new_session_tokens = session.prompt_tokens + session.completion_tokens + usage.total_tokens
            new_session_cost = session.cost_usd + cost_micros / 1_000_000.0
            new_global_tokens = (
                self._global_prompt + self._global_completion + usage.total_tokens
            )

            if self._session_token_budget is not None and new_session_tokens > self._session_token_budget:
                raise BudgetExceededError(
                    f"session token budget exceeded: {new_session_tokens} > {self._session_token_budget}"
                )
            if (
                self._session_cost_budget_usd is not None
                and new_session_cost > self._session_cost_budget_usd
            ):
                raise BudgetExceededError(
                    f"session cost budget exceeded: {new_session_cost:.6f} USD > {self._session_cost_budget_usd}"
                )
            if self._global_token_budget is not None and new_global_tokens > self._global_token_budget:
                raise BudgetExceededError(
                    f"global token budget exceeded: {new_global_tokens} > {self._global_token_budget}"
                )

            # Commit — only reachable when every check passed.
            session.prompt_tokens += usage.prompt_tokens
            session.completion_tokens += usage.completion_tokens
            session.cost_usd = new_session_cost
            session.calls += 1
            session.models.add(usage.model)
            session.last_seen = now
            self._sessions[usage.session_id] = session

            self._global_prompt += usage.prompt_tokens
            self._global_completion += usage.completion_tokens
            self._global_cost_micros += cost_micros
            self._call_timestamps.append(now)
            self._total_calls += 1
            self._request_ids.add(usage.request_id)
            self._request_id_order.append(usage.request_id)
            overflow = len(self._request_id_order) - self._max_request_ids
            if overflow > 0:
                for request_id in self._request_id_order[:overflow]:
                    self._request_ids.discard(request_id)
                del self._request_id_order[:overflow]

            entry = {
                "request_id": usage.request_id,
                "session_id": usage.session_id,
                "model": usage.model,
                "backend": usage.backend,
                "prompt_tokens": usage.prompt_tokens,
                "completion_tokens": usage.completion_tokens,
                "total_tokens": usage.total_tokens,
                "cost_micros": cost_micros,
                "timestamp": usage.timestamp,
            }
            self._audit(entry)
            return entry

    def _enforce_rate_window(self, now: float) -> None:
        """Sliding-window burst detection; prunes stale entries every call."""
        cutoff = now - self._window_seconds
        # list is append-only and small; amortized O(window)
        self._call_timestamps = [t for t in self._call_timestamps if t > cutoff]
        if len(self._call_timestamps) >= self._max_calls_per_window:
            raise BudgetExceededError(
                f"burst rate limit: {len(self._call_timestamps)} calls in "
                f"{self._window_seconds}s (max {self._max_calls_per_window})"
            )

    def _audit(self, entry: Dict[str, Any]) -> None:
        if not self._audit_path:
            return
        try:
            with open(self._audit_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except OSError as exc:
            # Accounting must never crash inference; the in-memory ledger
            # remains the source of truth. Surface the failure through the
            # module logger so operators can repair the audit sink.
            import logging
            logging.getLogger("jarvis.accounting").warning(
                "token_audit_write_failed", extra={"error": str(exc), "path": str(self._audit_path)}
            )

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def session_stats(self, session_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            s = self._sessions.get(session_id)
            if s is None:
                return None
            return {
                "session_id": s.session_id,
                "prompt_tokens": s.prompt_tokens,
                "completion_tokens": s.completion_tokens,
                "total_tokens": s.prompt_tokens + s.completion_tokens,
                "cost_usd": round(s.cost_usd, 6),
                "calls": s.calls,
                "models": sorted(s.models),
                "first_seen": s.first_seen,
                "last_seen": s.last_seen,
            }

    def global_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "prompt_tokens": self._global_prompt,
                "completion_tokens": self._global_completion,
                "total_tokens": self._global_prompt + self._global_completion,
                "cost_usd": round(self._global_cost_micros / 1_000_000.0, 6),
                "total_calls": self._total_calls,
                "active_sessions": len(self._sessions),
            }

    def health(self) -> Dict[str, Any]:
        """Compact snapshot for the health registry / metrics endpoint."""
        with self._lock:
            stats = self.global_stats()
            stats["rate_window_calls"] = len(self._call_timestamps)
            stats["budgets"] = {
                "session_token_budget": self._session_token_budget,
                "session_cost_budget_usd": self._session_cost_budget_usd,
                "global_token_budget": self._global_token_budget,
            }
            return stats



"""Unified, bounded, provenance-aware telemetry plane."""
from __future__ import annotations

import json
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from statistics import mean
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class TelemetrySample:
    """Normalized system/device/sensor telemetry record."""

    sample_id: str
    system_id: str
    subsystem: str
    metric: str
    value: float
    timestamp: float
    unit: str = ""
    quality: float = 1.0
    source: str = "unknown"
    tags: Mapping[str, str] = field(default_factory=dict)

    @classmethod
    def create(cls, system_id: str, subsystem: str, metric: str, value: float, *, unit: str = "", quality: float = 1.0, source: str = "unknown", tags: Mapping[str, str] | None = None, timestamp: float | None = None) -> "TelemetrySample":
        return cls(uuid.uuid4().hex, str(system_id).strip(), str(subsystem).strip(), str(metric).strip(), float(value), time.time() if timestamp is None else float(timestamp), str(unit), float(quality), str(source).strip() or "unknown", dict(tags or {}))

    def validate(self) -> None:
        if not self.system_id or not self.subsystem or not self.metric or not self.source:
            raise ValueError("telemetry identity fields are required")
        if not 0.0 <= self.quality <= 1.0:
            raise ValueError("telemetry quality must be in [0,1]")
        if len(self.tags) > 64 or len(json.dumps(self.tags).encode()) > 16_384:
            raise ValueError("telemetry tags exceed policy")


class TelemetryFabric:
    """Thread-safe telemetry collector with bounded memory and optional durable JSONL."""

    def __init__(self, *, max_samples: int = 100_000, path: str | Path | None = None) -> None:
        self._samples: deque[TelemetrySample] = deque(maxlen=max(1, min(int(max_samples), 2_000_000)))
        self._path = Path(path).resolve() if path is not None else None
        if self._path is not None:
            self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def publish(self, sample: TelemetrySample) -> None:
        sample.validate()
        with self._lock:
            self._samples.append(sample)
            if self._path is not None:
                with self._path.open("a", encoding="utf-8") as handle:
                    handle.write(json.dumps(asdict(sample), sort_keys=True, separators=(",", ":"), default=str) + "\n")
                    handle.flush()

    def query(self, *, system_id: str | None = None, subsystem: str | None = None, metric: str | None = None, since: float | None = None, limit: int = 1000) -> tuple[TelemetrySample, ...]:
        with self._lock:
            rows = [sample for sample in self._samples if (system_id is None or sample.system_id == system_id) and (subsystem is None or sample.subsystem == subsystem) and (metric is None or sample.metric == metric) and (since is None or sample.timestamp >= since)]
        return tuple(rows[-max(1, min(int(limit), 10_000)) :])

    def mean(self, *, system_id: str, metric: str, since: float | None = None) -> float | None:
        rows = self.query(system_id=system_id, metric=metric, since=since, limit=10_000)
        return mean(sample.value for sample in rows) if rows else None

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            return {"samples": len(self._samples), "persistent": self._path is not None, "systems": len({sample.system_id for sample in self._samples})}

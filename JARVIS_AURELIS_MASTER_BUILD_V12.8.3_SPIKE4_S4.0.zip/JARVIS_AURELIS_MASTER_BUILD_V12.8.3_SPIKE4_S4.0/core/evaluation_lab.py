"""Continuous evaluation laboratory for models and autonomous policies."""
from __future__ import annotations

import statistics
import time
from dataclasses import dataclass
from typing import Any, Callable, Iterable


@dataclass(frozen=True)
class EvaluationCase:
    """Bounded evaluation case."""
    case_id: str
    prompt: str
    expected: str | None = None
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class EvaluationResult:
    """Aggregated evaluation metrics."""
    name: str
    count: int
    success_rate: float
    mean_latency_ms: float
    exact_match_rate: float
    failures: tuple[str, ...] = ()


class EvaluationLab:
    """Run deterministic bounded evaluations against an injected callable."""

    def __init__(self, max_cases: int = 1000) -> None:
        self.max_cases = max(1, min(int(max_cases), 100_000))
        self._history: list[EvaluationResult] = []

    def evaluate(self, name: str, cases: Iterable[EvaluationCase], runner: Callable[[str], str]) -> EvaluationResult:
        """Evaluate a runner without exposing evaluator internals to the model."""
        selected = list(cases)[: self.max_cases]
        if not selected:
            raise ValueError("at least one evaluation case is required")
        latencies: list[float] = []
        successes = 0
        exact = 0
        failures: list[str] = []
        for case in selected:
            started = time.perf_counter()
            try:
                output = str(runner(case.prompt))
                ok = bool(output.strip())
                if case.expected is not None and output.strip() == case.expected.strip():
                    exact += 1
                if ok:
                    successes += 1
                else:
                    failures.append(case.case_id)
            except Exception:
                failures.append(case.case_id)
            latencies.append((time.perf_counter() - started) * 1000.0)
        result = EvaluationResult(str(name), len(selected), successes / len(selected), statistics.fmean(latencies), exact / len(selected), tuple(failures[:100]))
        self._history.append(result)
        del self._history[:-1000]
        return result

    def snapshot(self) -> dict[str, Any]:
        """Return recent evaluation history."""
        return {"runs": len(self._history), "latest": self._history[-1].__dict__.copy() if self._history else None}



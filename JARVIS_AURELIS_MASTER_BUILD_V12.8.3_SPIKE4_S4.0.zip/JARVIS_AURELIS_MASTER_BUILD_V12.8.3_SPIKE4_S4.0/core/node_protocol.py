"""Authenticated lightweight node protocol built on signed JSON envelopes."""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any


class NodeProtocolError(PermissionError):
    """Raised when a node envelope is malformed, unauthenticated or stale."""


@dataclass(frozen=True)
class NodeEnvelope:
    """Signed node-to-node message."""

    sender: str
    recipient: str
    message_type: str
    payload: dict[str, Any]
    issued_at: float
    expires_at: float
    nonce: str
    signature: str = ""

    def canonical(self) -> bytes:
        """Serialize all unsigned fields deterministically."""
        return json.dumps({"sender": self.sender, "recipient": self.recipient, "message_type": self.message_type, "payload": self.payload, "issued_at": self.issued_at, "expires_at": self.expires_at, "nonce": self.nonce}, sort_keys=True, separators=(",", ":"), default=str).encode()


class NodeProtocol:
    """Issue and verify short-lived HMAC-authenticated node messages."""

    def __init__(self, secret: bytes, *, max_ttl_seconds: float = 300.0) -> None:
        if len(secret) < 32:
            raise ValueError("node protocol secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self.max_ttl_seconds = max(1.0, min(float(max_ttl_seconds), 3600.0))

    def issue(self, sender: str, recipient: str, message_type: str, payload: dict[str, Any], *, ttl_seconds: float = 60.0) -> NodeEnvelope:
        ttl = float(ttl_seconds)
        if not sender.strip() or not recipient.strip() or not message_type.strip() or not 1 <= ttl <= self.max_ttl_seconds:
            raise ValueError("invalid node envelope")
        now = time.time()
        unsigned = NodeEnvelope(sender, recipient, message_type, dict(payload), now, now + ttl, secrets.token_hex(16))
        signature = hmac.new(self._secret, unsigned.canonical(), hashlib.sha256).hexdigest()
        return NodeEnvelope(**{**unsigned.__dict__, "signature": signature})

    def verify(self, envelope: NodeEnvelope, *, recipient: str | None = None) -> bool:
        """Verify recipient binding, freshness and signature."""
        now = time.time()
        if recipient is not None and envelope.recipient != recipient:
            return False
        if envelope.expires_at < now or envelope.issued_at > now + 5:
            return False
        expected = hmac.new(self._secret, envelope.canonical(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(envelope.signature, expected)

    def require_verified(self, envelope: NodeEnvelope, *, recipient: str | None = None) -> None:
        """Raise a typed error when verification fails."""
        if not self.verify(envelope, recipient=recipient):
            raise NodeProtocolError("invalid or expired node envelope")



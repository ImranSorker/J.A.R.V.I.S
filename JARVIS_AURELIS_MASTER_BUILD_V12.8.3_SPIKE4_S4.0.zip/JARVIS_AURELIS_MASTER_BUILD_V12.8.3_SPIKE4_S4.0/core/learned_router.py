"""Canonical contextual-bandit router using deterministic UCB1 selection."""
from __future__ import annotations
import math
import threading
from dataclasses import dataclass
from typing import Optional


@dataclass
class _Arm:
    pulls: int = 0
    reward_sum: float = 0.0


class LearnedRouter:
    """Learn model suitability per task context without pretending to train a model."""
    def __init__(self, exploration: float = 1.414):
        self.exploration = max(0.0, float(exploration))
        self._arms: dict[tuple[str, str], _Arm] = {}
        self._lock = threading.RLock()

    def record(self, task: str, model: str, score: float) -> None:
        key = (str(task).strip().lower(), str(model).strip())
        if not all(key):
            raise ValueError("task and model are required")
        reward = max(0.0, min(1.0, float(score)))
        with self._lock:
            arm = self._arms.setdefault(key, _Arm())
            arm.pulls += 1
            arm.reward_sum += reward

    def suggest(self, task: str, candidates: list[str]) -> Optional[str]:
        names = [str(c) for c in candidates if str(c).strip()]
        if not names:
            return None
        context = str(task).strip().lower()
        with self._lock:
            total = sum(self._arms.get((context, name), _Arm()).pulls for name in names)
            def value(name: str) -> tuple[float, float, str]:
                arm = self._arms.get((context, name), _Arm())
                if arm.pulls == 0:
                    return (float("inf"), 1.0, name)
                mean = arm.reward_sum / arm.pulls
                bonus = self.exploration * math.sqrt(math.log(max(1, total)) / arm.pulls)
                return (mean + bonus, mean, name)
            return max(names, key=value)

    def snapshot(self) -> dict[str, dict[str, float]]:
        with self._lock:
            return {f"{task}|{model}": {"pulls": arm.pulls, "reward_sum": arm.reward_sum, "mean": arm.reward_sum / arm.pulls if arm.pulls else 0.0} for (task, model), arm in sorted(self._arms.items())}

    def get_stats(self) -> dict[str, int]:
        with self._lock:
            return {"contexts": len({task for task, _ in self._arms}), "arms": len(self._arms), "observations": sum(a.pulls for a in self._arms.values())}

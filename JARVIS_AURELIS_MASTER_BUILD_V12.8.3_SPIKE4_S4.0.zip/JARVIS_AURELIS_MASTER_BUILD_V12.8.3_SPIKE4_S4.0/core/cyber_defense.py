"""Authorized defensive SOC primitives: detect, explain, and contain."""
from __future__ import annotations

import time
import threading
from collections import Counter, deque
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Callable, Mapping


class SecurityEventKind(StrEnum):
    AUTH_FAILURE = "auth_failure"
    DNS_ANOMALY = "dns_anomaly"
    ENDPOINT_ALERT = "endpoint_alert"
    VULNERABILITY = "vulnerability"
    TRAFFIC_ANOMALY = "traffic_anomaly"
    MALWARE_ALERT = "malware_alert"


class DefensiveAction(StrEnum):
    ISOLATE_ENDPOINT = "isolate_endpoint"
    REVOKE_CREDENTIAL = "revoke_credential"
    BLOCK_DESTINATION = "block_known_malicious_destination"
    QUARANTINE_FILE = "quarantine_file"
    DISABLE_ACCOUNT = "disable_compromised_account"


@dataclass(frozen=True, slots=True)
class SecurityEvent:
    event_id: str
    asset_id: str
    kind: SecurityEventKind | str
    timestamp: float
    severity: float
    source: str
    indicators: Mapping[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if not self.event_id.strip() or not self.asset_id.strip() or not self.source.strip():
            raise ValueError("security event identity is required")
        if not 0.0 <= float(self.severity) <= 1.0:
            raise ValueError("security event severity must be in [0,1]")
        if abs(time.time() - float(self.timestamp)) > 3600.0:
            raise ValueError("security event timestamp outside policy")
        if len(self.indicators or {}) > 64:
            raise ValueError("too many event indicators")


@dataclass(frozen=True, slots=True)
class ThreatAssessment:
    asset_id: str
    score: float
    reasons: tuple[str, ...]
    recommended_actions: tuple[DefensiveAction, ...]


class DefensiveSOC:
    """Fail-closed defensive analytics restricted to an explicit asset scope."""

    def __init__(self, authorized_assets: set[str], *, max_events: int = 100_000) -> None:
        self._authorized = frozenset(str(item).strip() for item in authorized_assets if str(item).strip())
        if not self._authorized:
            raise ValueError("at least one authorized asset is required")
        self._events: deque[SecurityEvent] = deque(maxlen=max(1, min(int(max_events), 1_000_000)))
        self._lock = threading.RLock()

    def ingest(self, event: SecurityEvent) -> None:
        event.validate()
        if event.asset_id not in self._authorized:
            raise PermissionError("security event asset is outside authorized scope")
        with self._lock:
            self._events.append(event)

    def assess(self, asset_id: str, *, window_seconds: float = 300.0) -> ThreatAssessment:
        if str(asset_id) not in self._authorized:
            raise PermissionError("asset is outside authorized scope")
        cutoff = time.time() - max(1.0, min(float(window_seconds), 86_400.0))
        with self._lock:
            rows = [event for event in self._events if event.asset_id == asset_id and event.timestamp >= cutoff]
        by_kind = Counter(str(event.kind) for event in rows)
        score = min(1.0, sum(event.severity for event in rows) / max(1, len(rows)))
        reasons: list[str] = []
        actions: set[DefensiveAction] = set()
        if by_kind.get(SecurityEventKind.AUTH_FAILURE.value, 0) >= 5:
            score = min(1.0, score + 0.25)
            reasons.append("repeated authentication failures")
            actions.add(DefensiveAction.REVOKE_CREDENTIAL)
        if by_kind.get(SecurityEventKind.MALWARE_ALERT.value, 0) >= 1:
            score = min(1.0, score + 0.35)
            reasons.append("malware alert present")
            actions.add(DefensiveAction.QUARANTINE_FILE)
            actions.add(DefensiveAction.ISOLATE_ENDPOINT)
        if by_kind.get(SecurityEventKind.VULNERABILITY.value, 0) >= 1:
            reasons.append("known vulnerability signal present")
        if by_kind.get(SecurityEventKind.DNS_ANOMALY.value, 0) >= 3:
            score = min(1.0, score + 0.15)
            reasons.append("repeated DNS anomaly")
            actions.add(DefensiveAction.BLOCK_DESTINATION)
        if not reasons:
            reasons.append("no policy-defined elevated signal in the current window")
        return ThreatAssessment(asset_id, score, tuple(reasons), tuple(sorted(actions, key=lambda item: item.value)))

    def contain(self, assessment: ThreatAssessment, action: DefensiveAction, adapter: Callable[[DefensiveAction, str], bool]) -> bool:
        """Apply a pre-approved defensive action through an injected adapter."""
        if assessment.asset_id not in self._authorized:
            raise PermissionError("asset is outside authorized scope")
        if action not in assessment.recommended_actions:
            raise PermissionError("action was not recommended by current assessment")
        if not callable(adapter):
            raise TypeError("containment adapter must be callable")
        return bool(adapter(action, assessment.asset_id))

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            return {"authorized_assets": len(self._authorized), "events": len(self._events)}

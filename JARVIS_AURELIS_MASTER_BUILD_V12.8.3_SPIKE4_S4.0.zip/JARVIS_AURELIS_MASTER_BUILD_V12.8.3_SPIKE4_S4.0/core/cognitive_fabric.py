"""Unified cognitive control plane for J.A.R.V.I.S."""
from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Callable, Generator, Mapping

from core.cognitive_episode import CognitiveEpisode, CognitiveEpisodeRecorder, EpisodePhase, EpisodeStore
from core.context_manager import ContextManager
from core.contracts.intelligence import CognitiveContext, VerificationResult
from core.evaluation_engine import EvaluationEngine
from core.memory_v2 import MemoryClass, MemoryItem, MemoryV2
from core.model_residency import ModelResidencyManager
from core.planning_v2 import HierarchicalPlanner, PlanNode, PlanBudget
from core.policy_gateway import PolicyGateway, RiskLevel
from core.replay_engine import CognitiveReplayEngine

logger = logging.getLogger("jarvis.cognitive_fabric")


class CognitiveFabric:
    """Single owner of cognitive episodes, memory, planning, policy, replay, and streaming transport."""

    def __init__(self, *, context: ContextManager, router: Any, memory: Any, cognitive_runtime: Any = None, event_sink: Callable[[Any], Any] | None = None, episode_path: str = "data/cognitive_episodes.json", permissions: Any = None, autonomy: Any = None, canonical_memory: MemoryV2 | None = None, model_intelligence: Any = None, knowledge: Any = None) -> None:
        self.context = context
        self.router = router
        self.legacy_memory = memory
        self.runtime = cognitive_runtime
        self.model_intelligence = model_intelligence
        self.knowledge = knowledge
        self.events = event_sink
        self.memory = canonical_memory or MemoryV2()
        self.episodes = EpisodeStore(episode_path)
        self.recorder = CognitiveEpisodeRecorder(self.episodes, event_sink)
        self.replay = CognitiveReplayEngine(self.episodes)
        self.planner = HierarchicalPlanner()
        self.model_residency = ModelResidencyManager(2)
        self.evaluator = EvaluationEngine(max_cases=1000)
        self.policy = PolicyGateway(permissions, autonomy) if permissions is not None and autonomy is not None else None
        self._enabled = True

    @property
    def enabled(self) -> bool:
        """Return whether the fabric accepts new cognitive work."""
        return self._enabled

    def disable(self) -> None:
        """Disable new episodes without destroying durable state."""
        self._enabled = False

    def enable(self) -> None:
        """Enable new episodes."""
        self._enabled = True

    def begin(self, *, request_id: str | None = None, session_id: str = "default", message: str = "") -> CognitiveEpisode:
        """Begin a persisted episode."""
        if not self._enabled:
            raise RuntimeError("cognitive fabric disabled")
        episode = CognitiveEpisode.create(request_id or uuid.uuid4().hex, session_id)
        return self.recorder.record(episode.transition(EpisodePhase.PERCEIVE, observations=()))

    def execute(self, message: str, *, session_id: str = "default", owner: str = "jarvis", workspace: str = "default", backend_name: str | None = None, max_tokens: int = 4096) -> Mapping[str, Any]:
        """Run a provider-independent cognitive episode around the canonical runtime."""
        episode = self.begin(session_id=session_id, message=message)
        started = time.perf_counter()
        try:
            if self.runtime is None:
                raise RuntimeError("unified cognitive runtime is not configured")
            run_kwargs = {
                "session_id": session_id,
                "owner": owner,
                "workspace": workspace,
                "backend_name": backend_name,
                "max_tokens": max_tokens,
            }
            if self.knowledge is not None:
                run_kwargs["verify"] = self._verify_with_knowledge
            result = self.runtime.run(message, **run_kwargs)
            text = str(result.output)
            model = str(getattr(result, "model", None) or backend_name or getattr(self.router.primary, "name", "unknown"))
            episode = self.recorder.record(episode.transition(EpisodePhase.UNDERSTAND, intent={"kind": result.intent.kind.value, "message_length": len(message)}))
            episode = self.recorder.record(episode.transition(EpisodePhase.RECALL, memory_refs=tuple(str(item) for item in result.context.items)))
            episode = self.recorder.record(episode.transition(EpisodePhase.REASON, model=model))
            episode = self.recorder.record(episode.transition(EpisodePhase.VERIFY, verification={"ok": result.verification.ok, "score": result.verification.score, "reasons": list(result.verification.reasons)}))
            episode = self.recorder.record(episode.transition(EpisodePhase.REFLECT, reflection={"summary": result.reflection.summary, "latency_ms": (time.perf_counter() - started) * 1000.0}))
            episode = self.recorder.record(episode.transition(EpisodePhase.COMPLETE, output=text, model=model, resource_usage={"latency_ms": (time.perf_counter() - started) * 1000.0}))
            memory_item = self.remember(owner=owner, workspace=workspace, session_id=session_id, kind=MemoryClass.EPISODIC, content=text[:10_000], source="cognitive.episode", confidence=result.verification.score, importance=0.55 if result.verification.ok else 0.15)
            self.model_residency.touch(model, model)
            if self.model_intelligence is not None:
                try:
                    self.model_intelligence.record(model, success=bool(result.verification.ok), latency_ms=(time.perf_counter() - started) * 1000.0, task_type=result.intent.kind.value, quality=float(result.verification.score), tokens=max(1, len(text.encode("utf-8")) // 4), task_text=message)
                except Exception:
                    logger.exception("cognitive_model_intelligence_update_failed")
            return {"episode_id": episode.episode_id, "request_id": result.request_id, "intent": result.intent.kind.value, "output": text, "verified": result.verification.ok, "verification_score": result.verification.score, "reflection": result.reflection.summary, "context_items": len(result.context.items), "model": model, "memory_id": memory_item.memory_id}
        except Exception as exc:
            logger.exception("cognitive_episode_failed", extra={"episode_id": episode.episode_id})
            episode = self.recorder.record(episode.transition(EpisodePhase.FAILED, error=str(exc), resource_usage={"latency_ms": (time.perf_counter() - started) * 1000.0}))
            return {"episode_id": episode.episode_id, "request_id": episode.request_id, "output": "", "verified": False, "error": str(exc)}

    def execute_stream(
        self,
        message: str,
        *,
        session_id: str = "default",
        owner: str = "jarvis",
        workspace: str = "default",
        backend_name: str | None = None,
        max_tokens: int = 4096,
        task_type: str = "default",
    ) -> Generator[str, None, Mapping[str, Any]]:
        """Run streaming responses through the same canonical cognitive episode pipeline."""
        episode = self.begin(session_id=session_id, message=message)
        started = time.perf_counter()
        result: Any = None
        try:
            if self.runtime is None:
                raise RuntimeError("unified cognitive runtime is not configured")
            run_kwargs = {
                "session_id": session_id,
                "owner": owner,
                "workspace": workspace,
                "backend_name": backend_name,
                "max_tokens": max_tokens,
                "task_type": task_type,
            }
            if self.knowledge is not None:
                run_kwargs["verify"] = self._verify_with_knowledge
            stream = self.runtime.run_stream(message, **run_kwargs)
            while True:
                try:
                    yield next(stream)
                except StopIteration as stop:
                    result = stop.value
                    break
            text = str(result.output)
            model = str(getattr(result, "model", None) or backend_name or getattr(self.router.primary, "name", "unknown"))
            episode = self.recorder.record(episode.transition(EpisodePhase.UNDERSTAND, intent={"kind": result.intent.kind.value, "message_length": len(message)}))
            episode = self.recorder.record(episode.transition(EpisodePhase.RECALL, memory_refs=tuple(str(item) for item in result.context.items)))
            episode = self.recorder.record(episode.transition(EpisodePhase.REASON, model=model))
            episode = self.recorder.record(episode.transition(EpisodePhase.VERIFY, verification={"ok": result.verification.ok, "score": result.verification.score, "reasons": list(result.verification.reasons)}))
            episode = self.recorder.record(episode.transition(EpisodePhase.REFLECT, reflection={"summary": result.reflection.summary, "latency_ms": (time.perf_counter() - started) * 1000.0}))
            episode = self.recorder.record(episode.transition(EpisodePhase.COMPLETE, output=text, model=model, resource_usage={"latency_ms": (time.perf_counter() - started) * 1000.0}))
            memory_item = self.remember(owner=owner, workspace=workspace, session_id=session_id, kind=MemoryClass.EPISODIC, content=text[:10_000], source="cognitive.stream", confidence=result.verification.score, importance=0.55 if result.verification.ok else 0.15)
            self.model_residency.touch(model, model)
            if self.model_intelligence is not None:
                try:
                    self.model_intelligence.record(model, success=bool(result.verification.ok), latency_ms=(time.perf_counter() - started) * 1000.0, task_type=result.intent.kind.value, quality=float(result.verification.score), tokens=max(1, len(text.encode("utf-8")) // 4), task_text=message)
                except Exception:
                    logger.exception("cognitive_stream_model_intelligence_update_failed")
            return {
                "episode_id": episode.episode_id,
                "request_id": result.request_id,
                "intent": result.intent.kind.value,
                "output": text,
                "verified": result.verification.ok,
                "verification_score": result.verification.score,
                "reflection": result.reflection.summary,
                "context_items": len(result.context.items),
                "model": model,
                "memory_id": memory_item.memory_id,
            }
        except Exception as exc:
            logger.exception("cognitive_stream_episode_failed", extra={"episode_id": episode.episode_id})
            episode = self.recorder.record(episode.transition(EpisodePhase.FAILED, error=str(exc), resource_usage={"latency_ms": (time.perf_counter() - started) * 1000.0}))
            raise

    def _verify_with_knowledge(self, output: str, _intent: Any, context: CognitiveContext) -> VerificationResult:
        """Verify generated output against evidence selected for the cognitive turn."""
        if self.knowledge is None:
            ok = bool(output.strip())
            return VerificationResult(ok, 1.0 if ok else 0.0, () if ok else ("empty_output",))
        contexts: list[dict[str, Any]] = []
        for item in context.items:
            metadata = dict(item.metadata)
            metadata.setdefault("id", item.item_id)
            metadata.setdefault("text", item.text)
            metadata.setdefault("score", item.relevance)
            metadata.setdefault("trust_level", item.trust)
            contexts.append(metadata)
        if not contexts:
            ok = bool(output.strip())
            return VerificationResult(ok, 1.0 if ok else 0.0, () if ok else ("empty_output", "no_context"))
        try:
            analysis = self.knowledge.verify_answer(output, contexts)
            evidence = getattr(analysis, "evidence", None)
            coverage = float(getattr(evidence, "coverage", 0.0)) if evidence is not None else 0.0
            unsupported = len(getattr(evidence, "unsupported_claims", ()) or ()) if evidence is not None else 0
            conflicts = len(getattr(analysis, "conflicts", ()) or ())
            score = max(0.0, min(1.0, coverage - min(0.5, 0.1 * conflicts) - min(0.5, 0.05 * unsupported)))
            reasons: list[str] = []
            if unsupported:
                reasons.append(f"unsupported_claims:{unsupported}")
            if conflicts:
                reasons.append(f"contradictions:{conflicts}")
            if coverage < 0.5:
                reasons.append("low_evidence_coverage")
            return VerificationResult(score >= 0.5 and conflicts == 0, score, tuple(reasons))
        except Exception:
            logger.exception("cognitive_knowledge_verification_failed")
            return VerificationResult(False, 0.0, ("knowledge_verification_failed",))

    def plan(self, nodes: list[PlanNode], budget: PlanBudget | None = None) -> list[PlanNode]:
        """Validate and order a hierarchical plan."""
        return self.planner.order(nodes, budget)

    def remember(self, *, owner: str, workspace: str, session_id: str, kind: MemoryClass, content: str, source: str, confidence: float = 1.0, importance: float = 0.5) -> MemoryItem:
        """Add isolated structured memory."""
        return self.memory.add(MemoryItem.create(owner=owner, workspace=workspace, session_id=session_id, kind=kind, content=content, source=source, confidence=confidence, importance=importance))

    def authorize(self, *, capability: str, risk: RiskLevel, mission_id: str | None = None, grant: str | None = None, required_capabilities: tuple[str, ...] = ()) -> Mapping[str, Any]:
        """Evaluate one action through the canonical policy gateway."""
        if self.policy is None:
            return {"allowed": False, "reason": "policy gateway unavailable"}
        decision = self.policy.evaluate(capability=capability, risk=risk, mission_id=mission_id, grant=grant, required_capabilities=required_capabilities)
        return {"allowed": decision.allowed, "risk": decision.risk.value, "reason": decision.reason, "capability": decision.capability, "mission_id": decision.mission_id}

    def snapshot(self) -> Mapping[str, Any]:
        """Return an observable fabric snapshot."""
        return {"enabled": self._enabled, "episodes": len(self.episodes.list()), "episode_digest": self.episodes.digest(), "memory": dict(self.memory.snapshot())}



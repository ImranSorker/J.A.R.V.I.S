"""Input predictor for routing decisions."""
from __future__ import annotations
import logging

logger = logging.getLogger("jarvis.predictor")


class InputPredictor:
    def __init__(self, confidence_threshold: float = 0.7):
        self.confidence_threshold = confidence_threshold

    def predict_complexity(self, text: str) -> tuple[str, float]:
        """Return (category, confidence)."""
        words = len(text.split())
        if words < 10:
            return ("simple", 0.9)
        elif words < 50:
            return ("medium", 0.8)
        else:
            return ("complex", 0.85)



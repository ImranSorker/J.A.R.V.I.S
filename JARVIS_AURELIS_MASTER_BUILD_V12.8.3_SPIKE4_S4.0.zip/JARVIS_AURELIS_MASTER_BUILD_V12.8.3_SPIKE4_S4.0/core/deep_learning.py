"""Deep learning engine for JARVIS — dependency-free neural network core.

Implements a small but production-grade multilayer perceptron classifier
in pure NumPy (already a declared project dependency; nothing new added).
It backs JARVIS's learned components (task-to-backend routing, content
classification) with real gradient-based training instead of heuristics.

Design properties:
  - Strongly typed, deterministic (seeded RNG), no global mutable state.
  - He initialization, ReLU hidden layers, softmax output, cross-entropy
    loss, mini-batch gradient descent with momentum, L2 regularization,
    and early stopping on a validation split.
  - Versioned JSON persistence with SHA-256 weight integrity hashing so
    a corrupted or tampered model file is detected at load time.
  - Bounded: training input is validated, sizes are capped, and every
    public method fails closed on invalid input.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

logger = logging.getLogger("jarvis.deep_learning")

MODEL_SCHEMA_VERSION = 1
MAX_SAMPLES = 100_000
MAX_FEATURES = 4_096
MAX_CLASSES = 256
MAX_EPOCHS = 500


class ModelError(Exception):
    """Raised when a model operation is invalid or integrity checks fail."""


@dataclass(frozen=True)
class TrainingReport:
    """Immutable summary of a training run (provenance for the model)."""
    samples: int
    epochs_run: int
    final_train_loss: float
    final_val_loss: Optional[float]
    val_accuracy: Optional[float]
    training_seconds: float
    layer_sizes: Tuple[int, ...]
    l2_lambda: float
    seed: int
    trained_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "samples": self.samples,
            "epochs_run": self.epochs_run,
            "final_train_loss": self.final_train_loss,
            "final_val_loss": self.final_val_loss,
            "val_accuracy": self.val_accuracy,
            "training_seconds": self.training_seconds,
            "layer_sizes": list(self.layer_sizes),
            "l2_lambda": self.l2_lambda,
            "seed": self.seed,
            "trained_at": self.trained_at,
        }


def _one_hot(labels: Sequence[int], num_classes: int) -> np.ndarray:
    out = np.zeros((len(labels), num_classes), dtype=np.float64)
    out[np.arange(len(labels)), labels] = 1.0
    return out


class MLPClassifier:
    """Feed-forward classifier: input -> [ReLU hidden]* -> softmax."""

    def __init__(self, layer_sizes: Sequence[int], l2_lambda: float = 1e-4,
                 seed: int = 42) -> None:
        if len(layer_sizes) < 2:
            raise ModelError("layer_sizes must include input and output")
        if any(s < 1 or s > MAX_FEATURES for s in layer_sizes[:-1]):
            raise ModelError(f"hidden/input layer sizes must be 1..{MAX_FEATURES}")
        if layer_sizes[-1] < 2 or layer_sizes[-1] > MAX_CLASSES:
            raise ModelError(f"output layer size must be 2..{MAX_CLASSES}")
        if l2_lambda < 0:
            raise ModelError("l2_lambda must be >= 0")
        self.layer_sizes: Tuple[int, ...] = tuple(int(s) for s in layer_sizes)
        self.l2_lambda = float(l2_lambda)
        self.seed = int(seed)
        rng = np.random.default_rng(self.seed)
        # He initialization for weights; zeros for biases.
        self._weights: List[np.ndarray] = [
            rng.standard_normal((a, b)) * np.sqrt(2.0 / a)
            for a, b in zip(self.layer_sizes[:-1], self.layer_sizes[1:])
        ]
        self._biases: List[np.ndarray] = [
            np.zeros((b,), dtype=np.float64) for b in self.layer_sizes[1:]
        ]
        self.trained = False

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def _forward(self, x: np.ndarray) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        activations = [x]
        preacts: List[np.ndarray] = []
        a = x
        for i, (w, b) in enumerate(zip(self._weights, self._biases)):
            z = a @ w + b
            preacts.append(z)
            if i < len(self._weights) - 1:
                a = np.maximum(0.0, z)  # ReLU
            else:
                z_stable = z - z.max(axis=1, keepdims=True)
                exp = np.exp(z_stable)
                a = exp / exp.sum(axis=1, keepdims=True)  # softmax
            activations.append(a)
        return activations, preacts

    def predict_proba(self, x: Sequence[Sequence[float]]) -> np.ndarray:
        arr = self._validate_features(x)
        if not self.trained:
            raise ModelError("model is not trained")
        probs, _ = self._forward(arr)
        return probs[-1]

    def predict(self, x: Sequence[Sequence[float]]) -> List[int]:
        return np.argmax(self.predict_proba(x), axis=1).tolist()

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def fit(self, x: Sequence[Sequence[float]], y: Sequence[int],
            epochs: int = 100, batch_size: int = 32, learning_rate: float = 0.01,
            momentum: float = 0.9, validation_split: float = 0.2,
            patience: int = 10) -> TrainingReport:
        x_arr = self._validate_features(x)
        y_arr = self._validate_labels(y, len(x_arr))
        if not 1 <= epochs <= MAX_EPOCHS:
            raise ModelError(f"epochs must be 1..{MAX_EPOCHS}")
        if batch_size < 1 or learning_rate <= 0 or momentum < 0 or momentum >= 1:
            raise ModelError("invalid batch_size/learning_rate/momentum")
        if not 0.0 <= validation_split < 1.0:
            raise ModelError("validation_split must be in [0, 1)")
        if patience < 1:
            raise ModelError("patience must be >= 1")

        n = len(x_arr)
        rng = np.random.default_rng(self.seed)
        indices = rng.permutation(n)
        val_count = int(n * validation_split)
        val_idx, train_idx = indices[:val_count], indices[val_count:]
        if len(train_idx) == 0:
            raise ModelError("training split is empty")

        x_train, y_train = x_arr[train_idx], y_arr[train_idx]
        x_val = x_arr[val_idx] if val_count else None
        y_val_oh = _one_hot(y_arr[val_idx].tolist(), self.layer_sizes[-1]) if val_count else None

        velocity_w = [np.zeros_like(w) for w in self._weights]
        velocity_b = [np.zeros_like(b) for b in self._biases]
        best_val = float("inf")
        best_weights: Optional[List[np.ndarray]] = None
        best_biases: Optional[List[np.ndarray]] = None
        epochs_since_best = 0
        start = time.monotonic()

        for epoch in range(epochs):
            order = rng.permutation(len(x_train))
            for start_i in range(0, len(order), batch_size):
                batch = order[start_i:start_i + batch_size]
                xb, yb = x_train[batch], y_train[batch]
                yb_oh = _one_hot(yb.tolist(), self.layer_sizes[-1])
                grad_w, grad_b = self._backward(xb, yb_oh)
                for i in range(len(self._weights)):
                    velocity_w[i] = momentum * velocity_w[i] - learning_rate * grad_w[i]
                    velocity_b[i] = momentum * velocity_b[i] - learning_rate * grad_b[i]
                    self._weights[i] += velocity_w[i]
                    self._biases[i] += velocity_b[i]

            self._train_loss = self._loss(x_train, _one_hot(y_train.tolist(), self.layer_sizes[-1]))
            if x_val is not None and y_val_oh is not None:
                val_loss = self._loss(x_val, y_val_oh)
                if val_loss < best_val - 1e-6:
                    best_val = val_loss
                    best_weights = [w.copy() for w in self._weights]
                    best_biases = [b.copy() for b in self._biases]
                    epochs_since_best = 0
                else:
                    epochs_since_best += 1
                    if epochs_since_best >= patience:
                        break
            else:
                best_weights = [w.copy() for w in self._weights]
                best_biases = [b.copy() for b in self._biases]

        if best_weights is not None and best_biases is not None:
            self._weights, self._biases = best_weights, best_biases
        self.trained = True

        final_train = self._loss(x_train, _one_hot(y_train.tolist(), self.layer_sizes[-1]))
        val_acc: Optional[float] = None
        final_val: Optional[float] = None
        if x_val is not None and y_val_oh is not None:
            final_val = self._loss(x_val, y_val_oh)
            preds = np.argmax(self._forward(x_val)[0][-1], axis=1)
            val_acc = float((preds == y_arr[val_idx]).mean())
        report = TrainingReport(
            samples=n, epochs_run=epoch + 1, final_train_loss=final_train,
            final_val_loss=final_val, val_accuracy=val_acc,
            training_seconds=time.monotonic() - start,
            layer_sizes=self.layer_sizes, l2_lambda=self.l2_lambda, seed=self.seed,
        )
        logger.info("model_trained", extra={"samples": n, "epochs": report.epochs_run,
                                            "train_loss": final_train, "val_acc": val_acc})
        return report

    def _backward(self, xb: np.ndarray, yb_oh: np.ndarray
                  ) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        activations, _ = self._forward(xb)
        m = len(xb)
        grad_w: List[np.ndarray] = [np.zeros_like(w) for w in self._weights]
        grad_b: List[np.ndarray] = [np.zeros_like(b) for b in self._biases]
        delta = (activations[-1] - yb_oh) / m
        for i in reversed(range(len(self._weights))):
            grad_w[i] = activations[i].T @ delta + self.l2_lambda * self._weights[i]
            grad_b[i] = delta.sum(axis=0)
            if i > 0:
                delta = (delta @ self._weights[i].T) * (activations[i] > 0)
        return grad_w, grad_b

    def _loss(self, x: np.ndarray, y_oh: np.ndarray) -> float:
        probs, _ = self._forward(x)
        eps = 1e-12
        ce = -np.mean(np.sum(y_oh * np.log(probs[-1] + eps), axis=1))
        l2 = 0.5 * self.l2_lambda * sum(float((w ** 2).sum()) for w in self._weights)
        return float(ce + l2)

    # ------------------------------------------------------------------
    # Persistence with integrity
    # ------------------------------------------------------------------

    def save(self, path: str, report: Optional[TrainingReport] = None) -> None:
        if not self.trained:
            raise ModelError("cannot save an untrained model")
        payload = {
            "schema_version": MODEL_SCHEMA_VERSION,
            "layer_sizes": list(self.layer_sizes),
            "l2_lambda": self.l2_lambda,
            "seed": self.seed,
            "trained": self.trained,
            "weights": [w.tolist() for w in self._weights],
            "biases": [b.tolist() for b in self._biases],
            "report": report.to_dict() if report else None,
        }
        blob = json.dumps(payload, sort_keys=True).encode("utf-8")
        payload["integrity_sha256"] = hashlib.sha256(blob).hexdigest()
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(payload), encoding="utf-8")
        tmp.replace(p)  # atomic publish

    @classmethod
    def load(cls, path: str) -> "MLPClassifier":
        p = Path(path)
        raw = p.read_text(encoding="utf-8")
        payload = json.loads(raw)
        if payload.get("schema_version") != MODEL_SCHEMA_VERSION:
            raise ModelError(f"unsupported model schema version: {payload.get('schema_version')}")
        recorded = payload.get("integrity_sha256")
        stripped = {k: v for k, v in payload.items() if k != "integrity_sha256"}
        actual = hashlib.sha256(json.dumps(stripped, sort_keys=True).encode("utf-8")).hexdigest()
        if not recorded or not hmac.compare_digest(str(recorded), actual):
            raise ModelError("model file integrity check failed (corrupted or tampered)")
        model = cls(payload["layer_sizes"], l2_lambda=payload["l2_lambda"],
                    seed=payload["seed"])
        model._weights = [np.asarray(w, dtype=np.float64) for w in payload["weights"]]
        model._biases = [np.asarray(b, dtype=np.float64) for b in payload["biases"]]
        model.trained = bool(payload.get("trained", False))
        return model

    # ------------------------------------------------------------------
    # Validation helpers
    # ------------------------------------------------------------------

    def _validate_features(self, x: Sequence[Sequence[float]]) -> np.ndarray:
        arr = np.asarray(x, dtype=np.float64)
        if arr.ndim != 2:
            raise ModelError("features must be a 2D array")
        if len(arr) < 1 or len(arr) > MAX_SAMPLES:
            raise ModelError(f"sample count must be 1..{MAX_SAMPLES}")
        if arr.shape[1] != self.layer_sizes[0]:
            raise ModelError(f"expected {self.layer_sizes[0]} features, got {arr.shape[1]}")
        if not np.all(np.isfinite(arr)):
            raise ModelError("features contain non-finite values")
        return arr

    def _validate_labels(self, y: Sequence[int], n: int) -> np.ndarray:
        arr = np.asarray(y, dtype=np.int64)
        if arr.ndim != 1 or len(arr) != n:
            raise ModelError("labels must be a 1D array matching sample count")
        if arr.min() < 0 or arr.max() >= self.layer_sizes[-1]:
            raise ModelError("label out of range for output layer")
        return arr


class DeepLearningEngine:
    """Application-facing deep learning facade with model lifecycle mgmt."""

    def __init__(self, model_dir: str = "data/models_dl") -> None:
        self._dir = Path(model_dir)
        self._models: Dict[str, MLPClassifier] = {}
        self._reports: Dict[str, TrainingReport] = {}

    def train(self, name: str, layer_sizes: Sequence[int],
              x: Sequence[Sequence[float]], y: Sequence[int],
              **kwargs: Any) -> TrainingReport:
        if not name or len(name) > 128 or not name.replace("_", "").replace("-", "").isalnum():
            raise ModelError("invalid model name")
        model = MLPClassifier(layer_sizes, seed=kwargs.pop("seed", 42))
        report = model.fit(x, y, **kwargs)
        self._models[name] = model
        self._reports[name] = report
        return report

    def predict(self, name: str, x: Sequence[Sequence[float]]) -> List[int]:
        model = self._models.get(name)
        if model is None:
            raise ModelError(f"model not loaded: {name}")
        return model.predict(x)

    def predict_proba(self, name: str, x: Sequence[Sequence[float]]) -> np.ndarray:
        model = self._models.get(name)
        if model is None:
            raise ModelError(f"model not loaded: {name}")
        return model.predict_proba(x)

    def is_trained(self, name: str) -> bool:
        model = self._models.get(name)
        return bool(model and model.trained)

    def report(self, name: str) -> Optional[TrainingReport]:
        return self._reports.get(name)

    def persist(self, name: str) -> Path:
        model = self._models.get(name)
        if model is None:
            raise ModelError(f"model not loaded: {name}")
        path = self._dir / f"{name}.json"
        model.save(str(path), report=self._reports.get(name))
        return path

    def restore(self, name: str, path: Optional[str] = None) -> MLPClassifier:
        p = Path(path) if path else self._dir / f"{name}.json"
        model = MLPClassifier.load(str(p))
        self._models[name] = model
        return model



"""Signed plugin manifest verification without executing plugin code."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import hmac
import json
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class PluginManifest:
    """Declarative plugin metadata."""

    name: str
    version: str
    entrypoint: str
    capabilities: tuple[str, ...]
    permissions: tuple[str, ...]
    artifact_sha256: str
    signature: str


class PluginGuard:
    """Validate plugin files and signatures before installation."""

    def __init__(self, signing_secret: bytes, *, max_artifact_bytes: int = 256 * 1024 * 1024) -> None:
        if len(signing_secret) < 16:
            raise ValueError("plugin signing secret is too short")
        self._secret = bytes(signing_secret)
        self.max_artifact_bytes = int(max_artifact_bytes)

    def verify(self, manifest: PluginManifest, artifact: str | Path) -> bool:
        """Verify artifact size/hash and HMAC signature."""
        path = Path(artifact).resolve()
        if not path.is_file() or path.stat().st_size <= 0 or path.stat().st_size > self.max_artifact_bytes:
            return False
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
                digest.update(chunk)
        digest_hex = digest.hexdigest()
        if not hmac.compare_digest(digest_hex, manifest.artifact_sha256.lower()):
            return False
        canonical = json.dumps({"name": manifest.name, "version": manifest.version, "entrypoint": manifest.entrypoint, "capabilities": manifest.capabilities, "permissions": manifest.permissions, "artifact_sha256": manifest.artifact_sha256}, sort_keys=True, separators=(",", ":")).encode()
        expected = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, manifest.signature)

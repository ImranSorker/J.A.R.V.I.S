"""Frontier operational controls for J.A.R.V.I.S. V12.8.0.

This module closes the remaining source-level gaps in the V12.8.0 frontier batch
without creating a second execution authority. It contains only bounded control
and verification primitives; execution remains owned by the existing policy,
mission, job, resource and tool authorities.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, asdict
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence


class SafetyMode(StrEnum):
    """Runtime autonomy posture ordered from normal to containment."""

    NORMAL = "normal"
    PRESSURED = "pressured"
    CONSTRAINED = "constrained"
    CRITICAL = "critical"
    SAFE = "safe"


class IncidentSeverity(StrEnum):
    """Security/reliability incident severity."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class IncidentState(StrEnum):
    """Incident lifecycle state."""

    OPEN = "open"
    CONTAINED = "contained"
    RECOVERING = "recovering"
    RESOLVED = "resolved"


@dataclass(frozen=True, slots=True)
class JournalRecord:
    """Tamper-evident journal record."""

    record_id: str
    created_at: float
    kind: str
    payload: Mapping[str, Any]
    previous_hash: str
    record_hash: str


class HashChainedJournal:
    """Append-only JSONL journal with a SHA-256 hash chain."""

    def __init__(self, path: str | Path, *, max_payload_bytes: int = 100_000) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_payload_bytes = max(1_024, int(max_payload_bytes))
        self._lock = threading.RLock()

    def _tail_hash(self) -> str:
        if not self.path.exists():
            return "0" * 64
        try:
            line = self.path.read_text(encoding="utf-8").splitlines()[-1]
            row = json.loads(line)
            return str(row.get("record_hash", "0" * 64))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return "0" * 64

    def append(self, kind: str, payload: Mapping[str, Any]) -> JournalRecord:
        """Append one bounded record and flush it to durable storage."""
        normalized = {str(k): v for k, v in payload.items()}
        encoded = json.dumps(normalized, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        if len(encoded) > self.max_payload_bytes:
            raise ValueError("journal payload exceeds configured size budget")
        with self._lock:
            previous = self._tail_hash()
            created = time.time()
            record_id = f"jrnl_{uuid.uuid4().hex}"
            material = f"{record_id}|{created:.6f}|{kind}|{previous}|".encode("utf-8") + encoded
            digest = hashlib.sha256(material).hexdigest()
            record = JournalRecord(record_id, created, str(kind), normalized, previous, digest)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(asdict(record), sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            return record

    def verify(self) -> bool:
        """Verify the entire journal chain and record hashes."""
        if not self.path.exists():
            return True
        previous = "0" * 64
        try:
            for raw in self.path.read_text(encoding="utf-8").splitlines():
                row = json.loads(raw)
                payload = row.get("payload")
                material = f"{row['record_id']}|{float(row['created_at']):.6f}|{row['kind']}|{previous}|".encode("utf-8") + json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                expected = hashlib.sha256(material).hexdigest()
                if row.get("previous_hash") != previous or row.get("record_hash") != expected:
                    return False
                previous = expected
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return False
        return True

    def tail(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return the newest bounded records without changing the journal."""
        if limit < 1 or not self.path.exists():
            return []
        try:
            rows = self.path.read_text(encoding="utf-8").splitlines()[-int(limit):]
            return [json.loads(row) for row in rows]
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return []


@dataclass(frozen=True, slots=True)
class DecisionRecord:
    """Explainable authorization/model/tool decision."""

    decision_id: str
    actor: str
    action: str
    capability: str
    policy: str
    allowed: bool
    reason: str
    risk: str
    resource: str
    created_at: float


class DecisionLedger:
    """Durable decision ledger backed by a tamper-evident chain."""

    def __init__(self, journal: HashChainedJournal) -> None:
        self._journal = journal

    def record(self, *, actor: str, action: str, capability: str, policy: str, allowed: bool, reason: str, risk: str, resource: str = "*") -> DecisionRecord:
        """Persist a single authorization or routing decision."""
        row = DecisionRecord(
            decision_id=f"decision_{uuid.uuid4().hex}", actor=str(actor), action=str(action), capability=str(capability),
            policy=str(policy), allowed=bool(allowed), reason=str(reason)[:2_000], risk=str(risk), resource=str(resource), created_at=time.time(),
        )
        self._journal.append("decision", asdict(row))
        return row

    def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent decisions for operator diagnostics."""
        return [row["payload"] for row in self._journal.tail(limit) if row.get("kind") == "decision"]


@dataclass(frozen=True, slots=True)
class PolicyScenario:
    """Pure policy-simulation input."""

    name: str
    actor: str
    capability: str
    risk: str
    resource: str = "*"


@dataclass(frozen=True, slots=True)
class PolicyScenarioResult:
    """Pure policy-simulation result."""

    name: str
    allowed: bool
    reason: str


class PolicySimulationLab:
    """Evaluate policy behavior without executing real capabilities."""

    def __init__(self, evaluator: Callable[[PolicyScenario], tuple[bool, str]], *, max_scenarios: int = 256) -> None:
        self._evaluator = evaluator
        self.max_scenarios = max(1, min(int(max_scenarios), 10_000))

    def run(self, scenarios: Sequence[PolicyScenario]) -> list[PolicyScenarioResult]:
        """Evaluate a bounded scenario set with deterministic result ordering."""
        if len(scenarios) > self.max_scenarios:
            raise ValueError("policy simulation exceeds scenario budget")
        results: list[PolicyScenarioResult] = []
        for scenario in scenarios:
            if not scenario.name.strip() or not scenario.capability.strip():
                raise ValueError("scenario name and capability are required")
            allowed, reason = self._evaluator(scenario)
            results.append(PolicyScenarioResult(scenario.name, bool(allowed), str(reason)[:2_000]))
        return results


class CapabilityDebugger:
    """Explain capability decisions from already-recorded evidence."""

    def explain(self, capability: str, *, decisions: Iterable[Mapping[str, Any]], grants: Iterable[Mapping[str, Any]] = ()) -> dict[str, Any]:
        """Return a non-authoritative diagnostic explanation."""
        cap = str(capability).strip()
        matching_decisions = [dict(row) for row in decisions if str(row.get("capability", "")) == cap]
        matching_grants = [dict(row) for row in grants if str(row.get("capability", "")) == cap]
        last = matching_decisions[-1] if matching_decisions else None
        return {
            "capability": cap,
            "decision_count": len(matching_decisions),
            "grant_count": len(matching_grants),
            "last_decision": last,
            "latest_status": "allowed" if last and bool(last.get("allowed")) else "denied" if last else "unknown",
            "authoritative": False,
        }


class SafeModeController:
    """Monotonic safety posture controller based on explicit system signals."""

    _ORDER = {SafetyMode.NORMAL: 0, SafetyMode.PRESSURED: 1, SafetyMode.CONSTRAINED: 2, SafetyMode.CRITICAL: 3, SafetyMode.SAFE: 4}

    def __init__(self) -> None:
        self._mode = SafetyMode.NORMAL
        self._reason = "startup"
        self._lock = threading.RLock()

    @property
    def mode(self) -> SafetyMode:
        """Return current safety posture."""
        with self._lock:
            return self._mode

    def set_mode(self, mode: SafetyMode | str, reason: str) -> SafetyMode:
        """Set or escalate safety mode explicitly."""
        target = SafetyMode(str(mode).lower())
        with self._lock:
            self._mode = target
            self._reason = str(reason)[:1_000]
            return self._mode

    def evaluate(self, *, cpu_percent: float = 0.0, memory_percent: float = 0.0, error_rate: float = 0.0, security_incidents: int = 0) -> SafetyMode:
        """Derive posture from bounded health signals."""
        cpu = max(0.0, min(100.0, float(cpu_percent)))
        memory = max(0.0, min(100.0, float(memory_percent)))
        error = max(0.0, min(1.0, float(error_rate)))
        incidents = max(0, int(security_incidents))
        if incidents >= 1 or error >= 0.5:
            mode = SafetyMode.SAFE
        elif memory >= 95 or cpu >= 98 or error >= 0.25:
            mode = SafetyMode.CRITICAL
        elif memory >= 85 or cpu >= 90 or error >= 0.10:
            mode = SafetyMode.CONSTRAINED
        elif memory >= 75 or cpu >= 80 or error >= 0.05:
            mode = SafetyMode.PRESSURED
        else:
            mode = SafetyMode.NORMAL
        return self.set_mode(mode, f"health cpu={cpu:.1f} memory={memory:.1f} error={error:.3f} incidents={incidents}")

    def permits(self, *, risk: str, mutation: bool = False) -> bool:
        """Return whether a requested operation may proceed under the current posture."""
        with self._lock:
            if self._mode == SafetyMode.SAFE:
                return not mutation and str(risk).lower() in {"low", "read", "observe", "l0", "l1"}
            if self._mode == SafetyMode.CRITICAL:
                return not mutation or str(risk).lower() in {"low", "read", "observe"}
            if self._mode == SafetyMode.CONSTRAINED:
                return str(risk).lower() not in {"critical", "high"} or not mutation
            return True

    def snapshot(self) -> dict[str, Any]:
        """Return safety posture without secrets."""
        with self._lock:
            return {"mode": self._mode.value, "reason": self._reason}


@dataclass(frozen=True, slots=True)
class ContextItem:
    """Bounded context candidate with explicit trust and priority."""

    source: str
    content: str
    priority: float = 0.5
    trusted: bool = False
    authoritative: bool = False


class ContextCompiler:
    """Compile reproducible model context while preserving trust boundaries."""

    def __init__(self, *, max_chars: int = 32_000, max_items: int = 64) -> None:
        self.max_chars = max(1_024, min(int(max_chars), 2_000_000))
        self.max_items = max(1, min(int(max_items), 1_000))

    def compile(self, system: str, user: str, items: Sequence[ContextItem]) -> dict[str, Any]:
        """Return a deterministic context package with untrusted data explicitly tagged."""
        if not str(user).strip():
            raise ValueError("user input is required")
        ranked = sorted(items, key=lambda row: (bool(row.authoritative), bool(row.trusted), float(row.priority), row.source), reverse=True)
        chunks: list[str] = [f"SYSTEM\n{str(system)[:10_000]}\n", f"USER\n{str(user)[:20_000]}\n"]
        included: list[str] = []
        used = len("".join(chunks))
        for item in ranked[: self.max_items]:
            trust_tag = "TRUSTED_DATA" if item.trusted else "UNTRUSTED_DATA"
            content = str(item.content).replace("\x00", "")[:12_000]
            block = f"[{trust_tag}] {item.source}\n{content}\n"
            if used + len(block) > self.max_chars:
                continue
            chunks.append(block)
            included.append(item.source)
            used += len(block)
        return {"text": "".join(chunks), "sources": included, "chars": used, "item_count": len(included), "untrusted_never_authoritative": True}


@dataclass(frozen=True, slots=True)
class MemoryResolution:
    """Deterministic memory reconciliation outcome."""

    action: str
    reason: str
    existing_id: str | None = None


class MemoryReconciler:
    """Detect duplicates and contradictions before memory mutation."""

    _NEGATION = re.compile(r"\b(?:not|never|false|isn't|isnt|cannot|can't|cant)\b", re.IGNORECASE)

    @staticmethod
    def _fingerprint(content: str) -> str:
        normalized = re.sub(r"\W+", " ", str(content).lower()).strip()
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

    @classmethod
    def reconcile(cls, candidate: Mapping[str, Any], existing: Sequence[Mapping[str, Any]]) -> MemoryResolution:
        """Classify a candidate as new, duplicate, or probable contradiction."""
        content = str(candidate.get("content", "")).strip()
        if not content:
            raise ValueError("candidate content is required")
        owner = str(candidate.get("owner", ""))
        workspace = str(candidate.get("workspace", ""))
        candidate_fp = cls._fingerprint(content)
        candidate_neg = bool(cls._NEGATION.search(content))
        for row in existing:
            if str(row.get("owner", "")) != owner or str(row.get("workspace", "")) != workspace:
                continue
            if candidate_fp == cls._fingerprint(str(row.get("content", ""))):
                return MemoryResolution("duplicate", "content fingerprint already exists", str(row.get("memory_id", "")) or None)
            existing_content = str(row.get("content", ""))
            shared = set(re.findall(r"[a-z0-9]{3,}", content.lower())) & set(re.findall(r"[a-z0-9]{3,}", existing_content.lower()))
            existing_neg = bool(cls._NEGATION.search(existing_content))
            if len(shared) >= 3 and candidate_neg != existing_neg:
                return MemoryResolution("contradiction", "same namespace and overlapping factual terms with opposite polarity", str(row.get("memory_id", "")) or None)
        return MemoryResolution("new", "no duplicate or contradiction detected")


class EvidenceGraph:
    """Bounded RAG claim/source graph with content integrity fingerprints."""

    def __init__(self, *, max_claims: int = 20_000, max_sources: int = 20_000) -> None:
        self.max_claims = max(1, int(max_claims))
        self.max_sources = max(1, int(max_sources))
        self._claims: dict[str, dict[str, Any]] = {}
        self._sources: dict[str, dict[str, Any]] = {}
        self._edges: dict[str, set[str]] = {}
        self._lock = threading.RLock()

    def add_source(self, source_id: str, *, origin: str, content: str, version: str = "1") -> None:
        """Register a versioned source with an integrity digest."""
        sid = str(source_id).strip()
        if not sid:
            raise ValueError("source_id is required")
        with self._lock:
            if sid not in self._sources and len(self._sources) >= self.max_sources:
                raise ValueError("evidence source capacity exceeded")
            self._sources[sid] = {"source_id": sid, "origin": str(origin), "version": str(version), "digest": hashlib.sha256(str(content).encode()).hexdigest()}

    def add_claim(self, claim_id: str, *, text: str, source_ids: Iterable[str]) -> None:
        """Register a claim and link it to known sources."""
        cid = str(claim_id).strip()
        refs = tuple(sorted({str(item).strip() for item in source_ids if str(item).strip()}))
        with self._lock:
            missing = [item for item in refs if item not in self._sources]
            if missing:
                raise KeyError(f"unknown evidence sources: {missing}")
            if cid not in self._claims and len(self._claims) >= self.max_claims:
                raise ValueError("evidence claim capacity exceeded")
            self._claims[cid] = {"claim_id": cid, "text": str(text)[:5_000], "digest": hashlib.sha256(str(text).encode()).hexdigest()}
            self._edges[cid] = set(refs)

    def explain(self, claim_id: str) -> dict[str, Any]:
        """Return the complete source chain for one claim."""
        with self._lock:
            claim = self._claims.get(str(claim_id))
            if claim is None:
                raise KeyError(claim_id)
            sources = [self._sources[source_id] for source_id in sorted(self._edges.get(str(claim_id), set()))]
            return {"claim": dict(claim), "sources": sources}

    def snapshot(self) -> dict[str, int]:
        """Return bounded graph counts."""
        with self._lock:
            return {"claims": len(self._claims), "sources": len(self._sources), "edges": sum(len(v) for v in self._edges.values())}


class ModelCanaryGuard:
    """Failure-aware model canary and circuit-breaker guard."""

    def __init__(self, *, failure_threshold: int = 3, latency_ms_threshold: float = 60_000.0) -> None:
        self.failure_threshold = max(1, int(failure_threshold))
        self.latency_ms_threshold = max(1.0, float(latency_ms_threshold))
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()

    def observe(self, model: str, *, success: bool, latency_ms: float, valid_output: bool = True) -> bool:
        """Record one model result and return whether the model is quarantined."""
        name = str(model).strip()
        if not name:
            raise ValueError("model is required")
        with self._lock:
            row = self._records.setdefault(name, {"attempts": 0, "failures": 0, "slow": 0, "invalid": 0, "quarantined": False})
            row["attempts"] += 1
            row["failures"] += int(not success)
            row["slow"] += int(float(latency_ms) > self.latency_ms_threshold)
            row["invalid"] += int(not valid_output)
            if row["failures"] >= self.failure_threshold or row["invalid"] >= self.failure_threshold or row["slow"] >= self.failure_threshold:
                row["quarantined"] = True
            return bool(row["quarantined"])

    def admit(self, model: str) -> bool:
        """Return whether a model is currently admitted for canary traffic."""
        with self._lock:
            return not bool(self._records.get(str(model), {}).get("quarantined", False))

    def restore(self, model: str) -> None:
        """Clear quarantine only after an explicit operator-controlled recovery."""
        with self._lock:
            if str(model) in self._records:
                self._records[str(model)]["quarantined"] = False
                self._records[str(model)]["failures"] = 0
                self._records[str(model)]["invalid"] = 0
                self._records[str(model)]["slow"] = 0

    def snapshot(self) -> dict[str, Any]:
        """Return model admission state."""
        with self._lock:
            return {"models": {name: dict(row) for name, row in sorted(self._records.items())}}


class IncidentManager:
    """Durable incident manager for security and reliability response."""

    def __init__(self, path: str | Path, journal: HashChainedJournal, *, max_incidents: int = 20_000) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.execute("CREATE TABLE IF NOT EXISTS incidents(id TEXT PRIMARY KEY,severity TEXT NOT NULL,state TEXT NOT NULL,title TEXT NOT NULL,details TEXT NOT NULL,created_at REAL NOT NULL,updated_at REAL NOT NULL)")
        self._db.commit()
        self._lock = threading.RLock()
        self._journal = journal
        self.max_incidents = max(1, int(max_incidents))

    def open(self, *, severity: IncidentSeverity | str, title: str, details: str) -> str:
        """Open and journal an incident."""
        sev = IncidentSeverity(str(severity).lower())
        now = time.time()
        incident_id = f"inc_{uuid.uuid4().hex}"
        with self._lock:
            count = int(self._db.execute("SELECT COUNT(*) FROM incidents").fetchone()[0])
            if count >= self.max_incidents:
                self._db.execute("DELETE FROM incidents WHERE id IN (SELECT id FROM incidents ORDER BY created_at ASC LIMIT 1)")
            self._db.execute("INSERT INTO incidents VALUES(?,?,?,?,?,?,?)", (incident_id, sev.value, IncidentState.OPEN.value, str(title)[:512], str(details)[:8000], now, now))
            self._db.commit()
        self._journal.append("incident.open", {"incident_id": incident_id, "severity": sev.value, "title": str(title)[:512]})
        return incident_id

    def transition(self, incident_id: str, state: IncidentState | str) -> None:
        """Transition one incident through its monotonic lifecycle."""
        target = IncidentState(str(state).lower())
        now = time.time()
        with self._lock:
            row = self._db.execute("SELECT state FROM incidents WHERE id=?", (str(incident_id),)).fetchone()
            if row is None:
                raise KeyError(incident_id)
            order = {IncidentState.OPEN: 0, IncidentState.CONTAINED: 1, IncidentState.RECOVERING: 2, IncidentState.RESOLVED: 3}
            current = IncidentState(row[0])
            if order[target] < order[current]:
                raise ValueError("incident state cannot move backward")
            self._db.execute("UPDATE incidents SET state=?,updated_at=? WHERE id=?", (target.value, now, str(incident_id)))
            self._db.commit()
        self._journal.append("incident.transition", {"incident_id": str(incident_id), "state": target.value})

    def active(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return unresolved incidents."""
        with self._lock:
            rows = self._db.execute("SELECT id,severity,state,title,details,created_at,updated_at FROM incidents WHERE state!=? ORDER BY updated_at DESC LIMIT ?", (IncidentState.RESOLVED.value, max(1, int(limit)))).fetchall()
        keys = ("id", "severity", "state", "title", "details", "created_at", "updated_at")
        return [dict(zip(keys, row)) for row in rows]

    def snapshot(self) -> dict[str, int]:
        """Return incident counters."""
        with self._lock:
            total = int(self._db.execute("SELECT COUNT(*) FROM incidents").fetchone()[0])
            active = int(self._db.execute("SELECT COUNT(*) FROM incidents WHERE state!=?", (IncidentState.RESOLVED.value,)).fetchone()[0])
        return {"total": total, "active": active}

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._db.close()


class ChaosHarness:
    """Opt-in bounded fault-injection harness for deterministic recovery tests."""

    MODES = frozenset({"timeout", "failure", "invalid_output", "resource_pressure"})

    def __init__(self) -> None:
        self._enabled = False
        self._lock = threading.RLock()

    def set_enabled(self, enabled: bool) -> None:
        """Enable chaos execution only explicitly and in-process."""
        with self._lock:
            self._enabled = bool(enabled)

    def execute(self, mode: str, operation: Callable[[], Any]) -> Any:
        """Run one bounded injection; never executes shell commands or external processes."""
        normalized = str(mode).strip().lower()
        with self._lock:
            enabled = self._enabled
        if normalized not in self.MODES:
            raise ValueError("unsupported chaos mode")
        if not enabled:
            return operation()
        if normalized == "timeout":
            raise TimeoutError("chaos timeout injected")
        if normalized == "failure":
            raise RuntimeError("chaos failure injected")
        if normalized == "invalid_output":
            return {"__chaos_invalid_output__": True}
        if normalized == "resource_pressure":
            raise MemoryError("chaos resource pressure injected")
        raise AssertionError("unreachable chaos mode")


class ConfigurationJournal:
    """Record validated configuration changes without storing secret values."""

    SECRET_KEY_RE = re.compile(r"(?:secret|token|password|credential|api[_-]?key|private[_-]?key)", re.IGNORECASE)

    def __init__(self, journal: HashChainedJournal) -> None:
        self._journal = journal

    def record(self, *, actor: str, key: str, old_value: Any, new_value: Any, reason: str) -> JournalRecord:
        """Journal metadata plus digests; secret-looking values are never serialized."""
        if self.SECRET_KEY_RE.search(str(key)):
            raise PermissionError("secret-bearing configuration keys must use the secret broker")
        old_bytes = json.dumps(old_value, sort_keys=True, default=str).encode("utf-8")
        new_bytes = json.dumps(new_value, sort_keys=True, default=str).encode("utf-8")
        return self._journal.append("config.change", {"actor": str(actor), "key": str(key), "old_digest": hashlib.sha256(old_bytes).hexdigest(), "new_digest": hashlib.sha256(new_bytes).hexdigest(), "reason": str(reason)[:1_000]})


class IdempotencyGuard:
    """Small process-local idempotency fence for operator control actions."""

    def __init__(self, *, ttl_seconds: float = 86_400.0, max_entries: int = 10_000) -> None:
        self.ttl_seconds = max(1.0, float(ttl_seconds))
        self.max_entries = max(1, int(max_entries))
        self._entries: dict[str, tuple[float, str, Any]] = {}
        self._lock = threading.RLock()

    def check_or_store(self, key: str, payload: Any) -> tuple[bool, Any | None]:
        """Return ``(True, prior_result)`` for duplicates; otherwise reserve the key."""
        token = str(key).strip()
        if not token:
            raise ValueError("idempotency key is required")
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()
        now = time.time()
        with self._lock:
            for existing, (expires, _, _) in list(self._entries.items()):
                if expires <= now:
                    self._entries.pop(existing, None)
            prior = self._entries.get(token)
            if prior is not None:
                if prior[1] != digest:
                    raise ValueError("idempotency key reused with different payload")
                return True, prior[2]
            if len(self._entries) >= self.max_entries:
                oldest = min(self._entries.items(), key=lambda item: item[1][0])[0]
                self._entries.pop(oldest, None)
            self._entries[token] = (now + self.ttl_seconds, digest, None)
            return False, None

    def complete(self, key: str, result: Any) -> None:
        """Store the authoritative result for a previously reserved key."""
        token = str(key).strip()
        with self._lock:
            current = self._entries.get(token)
            if current is None:
                raise KeyError(token)
            self._entries[token] = (current[0], current[1], result)


class DiagnosticBundleBuilder:
    """Build deterministic, secret-free diagnostic bundles in the workspace."""

    SECRET_KEY_RE = ConfigurationJournal.SECRET_KEY_RE

    @classmethod
    def _redact(cls, value: Any, key: str = "") -> Any:
        if cls.SECRET_KEY_RE.search(key):
            return "<redacted>"
        if isinstance(value, Mapping):
            return {str(k): cls._redact(v, str(k)) for k, v in value.items()}
        if isinstance(value, list):
            return [cls._redact(v, key) for v in value[:500]]
        return value

    @classmethod
    def write(cls, path: str | Path, snapshot: Mapping[str, Any]) -> Path:
        """Write one bounded JSON diagnostic bundle with deterministic ordering."""
        target = Path(path).resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = cls._redact(dict(snapshot))
        encoded = json.dumps(payload, sort_keys=True, indent=2, default=str).encode("utf-8")
        if len(encoded) > 10 * 1024 * 1024:
            raise ValueError("diagnostic bundle exceeds 10 MiB")
        temp = target.with_suffix(target.suffix + ".tmp")
        temp.write_bytes(encoded)
        os.replace(temp, target)
        return target


class FrontierControlPlane:
    """Composition object exposing the new frontier controls through one authority."""

    def __init__(self, state_root: str | Path, *, policy_evaluator: Callable[[PolicyScenario], tuple[bool, str]]) -> None:
        root = Path(state_root).resolve()
        root.mkdir(parents=True, exist_ok=True)
        journal = HashChainedJournal(root / "frontier_control.journal", max_payload_bytes=150_000)
        self.journal = journal
        self.decisions = DecisionLedger(journal)
        self.policy_lab = PolicySimulationLab(policy_evaluator)
        self.capability_debugger = CapabilityDebugger()
        self.safe_mode = SafeModeController()
        self.context = ContextCompiler()
        self.memory_reconciler = MemoryReconciler()
        self.evidence = EvidenceGraph()
        self.model_canary = ModelCanaryGuard()
        self.incidents = IncidentManager(root / "frontier_incidents.db", journal)
        self.chaos = ChaosHarness()
        self.configuration = ConfigurationJournal(journal)
        self.idempotency = IdempotencyGuard()
        self.diagnostics = DiagnosticBundleBuilder()

    def snapshot(self) -> dict[str, Any]:
        """Return one non-secret frontier-control snapshot."""
        return {
            "journal_integrity": self.journal.verify(),
            "decisions": len(self.decisions.recent(10_000)),
            "safety": self.safe_mode.snapshot(),
            "evidence": self.evidence.snapshot(),
            "model_canary": self.model_canary.snapshot(),
            "incidents": self.incidents.snapshot(),
            "chaos_enabled": self.chaos._enabled,
            "journal_tail": self.journal.tail(5),
        }

    def close(self) -> None:
        """Release durable control-plane resources."""
        self.incidents.close()



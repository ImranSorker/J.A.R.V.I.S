"""Offline-first durable command queue with bounded payloads and idempotency."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping


@dataclass(frozen=True, slots=True)
class OfflineCommand:
    """Persisted command waiting for a compatible local or remote executor."""

    command_id: str
    idempotency_key: str
    kind: str
    payload: dict[str, Any]
    created_at: float
    attempts: int
    state: str
    digest: str


class OfflineCommandQueue:
    """SQLite-backed command queue for safe offline-first operation."""

    def __init__(self, db_path: str | Path = "data/offline_commands.db", *, max_payload_bytes: int = 64_000) -> None:
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_payload_bytes = max(4096, int(max_payload_bytes))
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA busy_timeout=10000")
        self._db.execute("""CREATE TABLE IF NOT EXISTS commands(command_id TEXT PRIMARY KEY,idempotency_key TEXT UNIQUE NOT NULL,kind TEXT NOT NULL,payload_json TEXT NOT NULL,created_at REAL NOT NULL,attempts INTEGER NOT NULL,state TEXT NOT NULL,digest TEXT NOT NULL)""")
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_offline_state ON commands(state,created_at)")
        self._db.commit()

    def close(self) -> None:
        """Close the queue database."""
        with self._lock:
            self._db.commit()
            self._db.close()

    def enqueue(self, kind: str, payload: Mapping[str, Any], *, idempotency_key: str | None = None) -> OfflineCommand:
        """Persist a bounded command exactly once per idempotency key."""
        normalized_kind = str(kind).strip()
        if not normalized_kind or len(normalized_kind) > 128:
            raise ValueError("invalid command kind")
        data = dict(payload)
        encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        if len(encoded.encode("utf-8")) > self.max_payload_bytes:
            raise ValueError("offline command payload exceeds configured limit")
        idem = str(idempotency_key or f"offline:{uuid.uuid4().hex}").strip()
        now = time.time()
        command_id = f"cmd_{uuid.uuid4().hex[:16]}"
        digest = hashlib.sha256(f"{idem}|{normalized_kind}|{encoded}".encode("utf-8")).hexdigest()
        with self._lock:
            row = self._db.execute("SELECT * FROM commands WHERE idempotency_key=?", (idem,)).fetchone()
            if row is not None:
                return self._row(row)
            self._db.execute("INSERT INTO commands VALUES(?,?,?,?,?,?,?,?)", (command_id, idem, normalized_kind, encoded, now, 0, "queued", digest))
            self._db.commit()
            return self.get(command_id)  # type: ignore[return-value]

    def get(self, command_id: str) -> OfflineCommand | None:
        """Return one persisted command."""
        with self._lock:
            row = self._db.execute("SELECT * FROM commands WHERE command_id=?", (str(command_id),)).fetchone()
            return self._row(row) if row is not None else None

    def pending(self, limit: int = 50) -> list[OfflineCommand]:
        """Return queued commands in creation order."""
        with self._lock:
            rows = self._db.execute("SELECT * FROM commands WHERE state='queued' ORDER BY created_at,command_id LIMIT ?", (max(1, min(int(limit), 500)),)).fetchall()
            return [self._row(row) for row in rows]

    def drain(self, executor: Callable[[OfflineCommand], bool], *, limit: int = 20) -> dict[str, int]:
        """Run bounded queued work; failed commands remain queued with incremented attempts."""
        done = failed = 0
        for command in self.pending(limit):
            try:
                accepted = bool(executor(command))
            except Exception:
                accepted = False
            with self._lock:
                current = self._db.execute("SELECT attempts FROM commands WHERE command_id=?", (command.command_id,)).fetchone()
                attempts = int(current[0]) + 1 if current else command.attempts + 1
                state = "completed" if accepted else "queued"
                self._db.execute("UPDATE commands SET attempts=?,state=? WHERE command_id=?", (attempts, state, command.command_id))
                self._db.commit()
            if accepted:
                done += 1
            else:
                failed += 1
        return {"completed": done, "failed": failed}

    def purge_completed(self, *, older_than_seconds: float = 7 * 86400) -> int:
        """Delete only completed commands older than the configured retention window."""
        cutoff = time.time() - max(0.0, float(older_than_seconds))
        with self._lock:
            cur = self._db.execute("DELETE FROM commands WHERE state='completed' AND created_at<?", (cutoff,))
            self._db.commit()
            return int(cur.rowcount)

    @staticmethod
    def _row(row: sqlite3.Row) -> OfflineCommand:
        payload = dict(json.loads(str(row["payload_json"])))
        expected = hashlib.sha256(f"{row['idempotency_key']}|{row['kind']}|{row['payload_json']}".encode("utf-8")).hexdigest()
        if expected != str(row["digest"]):
            raise ValueError("offline command integrity failure")
        return OfflineCommand(str(row["command_id"]), str(row["idempotency_key"]), str(row["kind"]), payload, float(row["created_at"]), int(row["attempts"]), str(row["state"]), str(row["digest"]))



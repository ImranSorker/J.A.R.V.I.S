"""Manages multiple loaded models with VRAM-aware eviction."""
from __future__ import annotations
import logging
from typing import Dict, Optional, List
from core.types import ModelInfo

logger = logging.getLogger("jarvis.swarm")


class ModelSwarm:
    def __init__(self, max_vram_gb: Optional[float] = None):
        self.max_vram_gb = max_vram_gb or 0.0
        self._registry: Dict[str, ModelInfo] = {}
        self._loaded: Dict[str, any] = {}
        self._lru: List[str] = []

    def register(self, info: ModelInfo) -> None:
        self._registry[info.name] = info

    def select_best(self, vram_free_gb: Optional[float], task_type: str = "general") -> Optional[ModelInfo]:
        candidates = list(self._registry.values())
        if not candidates:
            return None
        # Simple heuristic: prefer smaller models for fast tasks, larger for complex
        candidates.sort(key=lambda m: m.size_bytes)
        return candidates[0]

    @property
    def loaded(self) -> Dict[str, any]:
        return dict(self._loaded)

    def load(self, name: str, backend) -> bool:
        if name in self._loaded:
            self._touch(name)
            return True
        if backend.load():
            self._loaded[name] = backend
            self._touch(name)
            return True
        return False

    def _touch(self, name: str) -> None:
        if name in self._lru:
            self._lru.remove(name)
        self._lru.append(name)

    def unload(self, name: str) -> None:
        if name in self._loaded:
            self._loaded[name].unload()
            del self._loaded[name]
        if name in self._lru:
            self._lru.remove(name)

    def shutdown(self) -> None:
        for name in list(self._loaded):
            self.unload(name)



"""Bounded specialist-agent population management."""
from __future__ import annotations

import threading
from dataclasses import dataclass
from enum import StrEnum


class AgentTier(StrEnum):
    NANO = "nano"
    MINI = "mini"
    STANDARD = "standard"
    EXPERT = "expert"
    SOVEREIGN = "sovereign"


@dataclass(frozen=True, slots=True)
class AgentRoleSpec:
    role: str
    tier: AgentTier
    capabilities: tuple[str, ...]
    max_concurrency: int = 1
    max_runtime_seconds: float = 60.0

    def validate(self) -> None:
        if not self.role.strip() or not self.capabilities:
            raise ValueError("agent role and capabilities are required")
        if not 1 <= self.max_concurrency <= 64 or not 0.1 <= self.max_runtime_seconds <= 86_400:
            raise ValueError("agent resource limits outside policy")


@dataclass(frozen=True, slots=True)
class AgentPopulationSnapshot:
    capacities: dict[str, int]
    active: dict[str, int]
    quarantined: tuple[str, ...]


class AgentPopulationController:
    """Manage bounded specialist populations without implicit privilege inheritance."""

    def __init__(self, *, global_capacity: int = 1024) -> None:
        self._global_capacity = max(1, min(int(global_capacity), 100_000))
        self._roles: dict[str, AgentRoleSpec] = {}
        self._active: dict[str, int] = {}
        self._quarantined: set[str] = set()
        self._lock = threading.RLock()

    def register_role(self, role: AgentRoleSpec) -> None:
        role.validate()
        with self._lock:
            self._roles[role.role] = role
            self._active.setdefault(role.role, 0)

    def admit(self, role: str) -> bool:
        key = str(role).strip()
        with self._lock:
            spec = self._roles.get(key)
            if spec is None or key in self._quarantined:
                return False
            if sum(self._active.values()) >= self._global_capacity or self._active[key] >= spec.max_concurrency:
                return False
            self._active[key] += 1
            return True

    def release(self, role: str) -> None:
        with self._lock:
            self._active[str(role)] = max(0, self._active.get(str(role), 0) - 1)

    def quarantine(self, role: str) -> None:
        with self._lock:
            if str(role) in self._roles:
                self._quarantined.add(str(role))

    def restore(self, role: str, *, explicit_review: bool) -> None:
        if not explicit_review:
            raise PermissionError("explicit review required to restore a quarantined role")
        with self._lock:
            self._quarantined.discard(str(role))

    def snapshot(self) -> AgentPopulationSnapshot:
        with self._lock:
            return AgentPopulationSnapshot({role: spec.max_concurrency for role, spec in self._roles.items()}, dict(self._active), tuple(sorted(self._quarantined)))

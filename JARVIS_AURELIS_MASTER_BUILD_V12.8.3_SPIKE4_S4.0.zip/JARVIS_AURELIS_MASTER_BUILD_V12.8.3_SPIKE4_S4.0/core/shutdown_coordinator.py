"""Bounded graceful shutdown with atomic state persistence and explicit terminal status."""
from __future__ import annotations
import json
import logging
import math
import os
import signal
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger("jarvis.shutdown")


@dataclass
class ShutdownConfig:
    drain_timeout_seconds: float = 30.0
    checkpoint_interval_seconds: float = 5.0
    persist_path: str = "data/shutdown_state.json"

    def __post_init__(self) -> None:
        for name in ("drain_timeout_seconds", "checkpoint_interval_seconds"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and > 0")


class ShutdownCoordinator:
    """Shutdown handlers are bounded by one monotonic deadline.

    A timed-out sync handler runs only in a daemon thread and the terminal status is
    INCOMPLETE; the coordinator never reports success while a handler is still running.
    """
    def __init__(self, config: Optional[ShutdownConfig] = None) -> None:
        self._config = config or ShutdownConfig()
        self._handlers: Dict[str, Callable[[], None]] = {}
        self._state_persisters: Dict[str, Callable[[], dict[str, Any]]] = {}
        self._shutdown_event = threading.Event()
        self._in_progress = False
        self._shutdown_status = "not_started"
        self._timed_out_handlers: list[str] = []
        self._errors: list[dict[str, str]] = []
        self._lock = threading.RLock()
        self._original_sigterm: Optional[Callable] = None
        self._original_sigint: Optional[Callable] = None

    @property
    def shutdown_status(self) -> str:
        with self._lock:
            return self._shutdown_status

    @property
    def timed_out_handlers(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(self._timed_out_handlers)

    @property
    def errors(self) -> tuple[dict[str, str], ...]:
        with self._lock:
            return tuple(dict(x) for x in self._errors)

    def _ensure_admitting(self) -> None:
        if self._shutdown_event.is_set() or self._shutdown_status != "not_started":
            raise RuntimeError("shutdown has begun; new handlers/persisters are rejected")

    def register(self, name: str, handler: Callable[[], None]) -> None:
        if not str(name).strip() or not callable(handler):
            raise ValueError("handler name and callable are required")
        with self._lock:
            self._ensure_admitting()
            if name in self._handlers:
                raise ValueError(f"handler already registered: {name}")
            self._handlers[name] = handler

    def register_state_persister(self, name: str, persister: Callable[[], dict[str, Any]]) -> None:
        if not str(name).strip() or not callable(persister):
            raise ValueError("persister name and callable are required")
        with self._lock:
            self._ensure_admitting()
            if name in self._state_persisters:
                raise ValueError(f"persister already registered: {name}")
            self._state_persisters[name] = persister

    def install_signal_handlers(self) -> None:
        with self._lock:
            if self._original_sigterm is not None:
                return
            self._original_sigterm = signal.signal(signal.SIGTERM, self._on_signal)
            self._original_sigint = signal.signal(signal.SIGINT, self._on_signal)
            logger.info("shutdown_signal_handlers_installed")

    def restore_signal_handlers(self) -> None:
        with self._lock:
            if self._original_sigterm is not None:
                signal.signal(signal.SIGTERM, self._original_sigterm)
                self._original_sigterm = None
            if self._original_sigint is not None:
                signal.signal(signal.SIGINT, self._original_sigint)
                self._original_sigint = None

    def _on_signal(self, signum: int, frame: Any) -> None:
        sig_name = "SIGTERM" if signum == signal.SIGTERM else "SIGINT"
        logger.info("shutdown_signal_received", extra={"signal": sig_name})
        self.initiate_shutdown()
        original = self._original_sigterm if signum == signal.SIGTERM else self._original_sigint
        if original:
            original(signum, frame)

    def initiate_shutdown(self) -> None:
        with self._lock:
            if self._shutdown_status != "not_started":
                return
            self._in_progress = True
            self._shutdown_status = "in_progress"
            handlers = list(reversed(self._handlers.items()))
        self._shutdown_event.set()
        started = time.monotonic()
        deadline = started + float(self._config.drain_timeout_seconds)
        logger.info("shutdown_initiated", extra={"timeout": self._config.drain_timeout_seconds})
        self._persist_state(stage="before_drain", proposed_status="in_progress")

        for index, (name, handler) in enumerate(handlers):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with self._lock:
                    self._timed_out_handlers.extend(n for n, _ in handlers[index:])
                break
            done = threading.Event()
            outcome: list[BaseException] = []
            def invoke(fn: Callable[[], None] = handler) -> None:
                try:
                    fn()
                except BaseException as exc:  # record handler failure, including system-level exceptions
                    outcome.append(exc)
                finally:
                    done.set()
            worker = threading.Thread(target=invoke, name=f"shutdown:{name}", daemon=True)
            worker.start()
            done.wait(remaining)
            if not done.is_set():
                with self._lock:
                    self._timed_out_handlers.append(name)
                logger.error("shutdown_handler_timeout", extra={"subsystem": name})
                break
            if outcome:
                exc = outcome[0]
                with self._lock:
                    self._errors.append({"kind": "handler", "name": name, "error": f"{type(exc).__name__}: {exc}"})
                logger.error("shutdown_handler_failed", extra={"subsystem": name, "error_type": type(exc).__name__})

        with self._lock:
            proposed = "complete" if not self._timed_out_handlers and not self._errors else "incomplete"
        self._shutdown_status = self._persist_state(stage="after_drain", proposed_status=proposed)
        with self._lock:
            self._in_progress = False
        logger.info("shutdown_terminal", extra={"status": self._shutdown_status,
                                                 "timed_out_handlers": list(self._timed_out_handlers),
                                                 "error_count": len(self._errors)})

    def _persist_state(self, *, stage: str = "manual", proposed_status: str = "complete") -> str:
        subsystems: Dict[str, Any] = {}
        all_persisters_ok = True
        with self._lock:
            persisters = list(self._state_persisters.items())
        for name, persister in persisters:
            try:
                subsystems[name] = persister()
            except Exception as exc:
                all_persisters_ok = False
                with self._lock:
                    self._errors.append({"kind": "persister", "name": name, "error": f"{type(exc).__name__}: {exc}"})
                logger.error("state_persist_failed", extra={"subsystem": name, "error_type": type(exc).__name__})
        with self._lock:
            effective = proposed_status
            if not all_persisters_ok or self._errors or self._timed_out_handlers:
                effective = "incomplete"
            payload = {"timestamp": time.time(), "version": "12.8.3", "stage": stage,
                       "status": effective, "timed_out_handlers": list(self._timed_out_handlers),
                       "errors": list(self._errors), "subsystems": subsystems}
        path = Path(self._config.persist_path)
        tmp_path: str | None = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_path = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, default=str, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path, path)
            tmp_path = None
            try:
                dir_fd = os.open(path.parent, os.O_RDONLY)
                try:
                    os.fsync(dir_fd)
                finally:
                    os.close(dir_fd)
            except OSError:
                pass
        except Exception as exc:
            with self._lock:
                self._errors.append({"kind": "state_write", "name": str(path), "error": f"{type(exc).__name__}: {exc}"})
            logger.error("shutdown_state_persist_failed", extra={"error_type": type(exc).__name__})
            effective = "incomplete"
        finally:
            if tmp_path:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        return effective

    def is_shutting_down(self) -> bool:
        return self._shutdown_event.is_set()

    def wait_for_shutdown(self, timeout: Optional[float] = None) -> bool:
        return self._shutdown_event.wait(timeout)

"""Deep-learning feature pipeline — text featurization and learned routing.

Bridges natural language to the NumPy MLP in core.deep_learning without
adding dependencies: deterministic hashed n-gram feature vectors feed
learned classifiers for task routing, intent classification, and content
triage. Everything is seeded, bounded, and persistable with integrity
metadata.

Components:
  TextFeaturizer    — fixed-dim hashed character/word n-gram TF vectors,
                      L2-normalized, fully deterministic.
  LearnedTextClassifier — featurizer + MLPClassifier + label map with
                      versioned JSON persistence (integrity-checked).
  RoutingTrainer    — records (task, backend, score) observations and
                      trains a backend-routing classifier that only ever
                      suggests among backends it was trained on.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from core.deep_learning import MODEL_SCHEMA_VERSION, MLPClassifier, ModelError, TrainingReport

logger = logging.getLogger("jarvis.dl_features")

FEATURIZER_SCHEMA_VERSION = 1
MAX_TEXT_LENGTH = 100_000
MAX_SAMPLES = 50_000

_WORD_RE = re.compile(r"[a-z0-9]+")


class FeaturizerError(Exception):
    """Raised on invalid input to the feature pipeline."""


class TextFeaturizer:
    """Deterministic hashed n-gram featurizer.

    Feature space layout for dimension ``dim``:
      [0, dim/2)              word unigram+bigram term frequencies
      [dim/2, dim)            character 3-5 gram term frequencies
    Hashing is SHA-256 based (not Python-hash, which is salted per process),
    so vectors are stable across processes and machines.
    """

    def __init__(self, dim: int = 256) -> None:
        if not 16 <= dim <= 4096 or dim % 2 != 0:
            raise FeaturizerError("dim must be an even integer 16..4096")
        self.dim = dim

    # ------------------------------------------------------------------

    def _bucket(self, token: str) -> int:
        digest = hashlib.sha256(token.encode("utf-8")).digest()
        return int.from_bytes(digest[:4], "little")

    def _word_ngrams(self, text: str) -> List[str]:
        words = _WORD_RE.findall(text.lower())
        out: List[str] = [f"w:{w}" for w in words]
        out += [f"w:{a}_{b}" for a, b in zip(words, words[1:])]
        return out

    def _char_ngrams(self, text: str) -> List[str]:
        compact = re.sub(r"\s+", " ", text.lower())
        out: List[str] = []
        for n in (3, 4, 5):
            if len(compact) >= n:
                out += [f"c{n}:{compact[i:i + n]}"
                        for i in range(len(compact) - n + 1)]
        return out

    def transform_one(self, text: str) -> List[float]:
        if not isinstance(text, str):
            raise FeaturizerError("text must be a string")
        if len(text) > MAX_TEXT_LENGTH:
            raise FeaturizerError(
                f"text exceeds {MAX_TEXT_LENGTH} characters")
        half = self.dim // 2
        vec = [0.0] * self.dim
        for tok in self._word_ngrams(text):
            vec[self._bucket(tok) % half] += 1.0
        for tok in self._char_ngrams(text):
            vec[half + self._bucket(tok) % half] += 1.0
        # Sublinear TF scaling + L2 normalization.
        import math
        vec = [math.sqrt(v) for v in vec]
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def transform(self, texts: Sequence[str]) -> List[List[float]]:
        if not 1 <= len(texts) <= MAX_SAMPLES:
            raise FeaturizerError(f"sample count must be 1..{MAX_SAMPLES}")
        return [self.transform_one(t) for t in texts]

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        return {"schema_version": FEATURIZER_SCHEMA_VERSION, "dim": self.dim}

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "TextFeaturizer":
        if payload.get("schema_version") != FEATURIZER_SCHEMA_VERSION:
            raise FeaturizerError("unsupported featurizer schema")
        return cls(dim=int(payload["dim"]))


class LearnedTextClassifier:
    """Text classifier: featurizer + MLP + label map, integrity-persisted."""

    BUNDLE_SCHEMA_VERSION = 1

    def __init__(self, name: str, dim: int = 256,
                 featurizer: Optional[TextFeaturizer] = None,
                 seed: int = 42) -> None:
        if not name or len(name) > 128:
            raise FeaturizerError("invalid classifier name")
        self.name = name
        self.featurizer = featurizer or TextFeaturizer(dim)
        self._model = MLPClassifier([self.featurizer.dim, max(8, self.featurizer.dim // 4), 2],
                                    seed=seed)
        self._labels: List[str] = []
        self._seed = seed
        self._report: Optional[TrainingReport] = None

    # ------------------------------------------------------------------

    def train(self, texts: Sequence[str], labels: Sequence[str],
              hidden: Optional[int] = None, **fit_kwargs: Any) -> TrainingReport:
        if len(texts) != len(labels) or not texts:
            raise FeaturizerError("texts/labels must be non-empty and aligned")
        uniq = sorted(set(labels))
        if len(uniq) < 2:
            raise FeaturizerError("need at least 2 distinct labels")
        if len(uniq) > 256:
            raise FeaturizerError("too many distinct labels")
        self._labels = uniq
        label_index = {lab: i for i, lab in enumerate(uniq)}
        x = self.featurizer.transform(texts)
        y = [label_index[lab] for lab in labels]
        hidden_size = hidden or max(8, self.featurizer.dim // 4)
        self._model = MLPClassifier([self.featurizer.dim, hidden_size, len(uniq)],
                                    seed=self._seed)
        self._report = self._model.fit(x, y, **fit_kwargs)
        logger.info("text_classifier_trained",
                    extra={"component_name": self.name, "labels": len(uniq),
                           "samples": len(texts)})
        return self._report

    def predict(self, texts: Sequence[str]) -> List[str]:
        if not self._model.trained:
            raise ModelError("classifier is not trained")
        x = self.featurizer.transform(texts)
        idx = self._model.predict(x)
        return [self._labels[i] for i in idx]

    def predict_proba(self, texts: Sequence[str]) -> List[Dict[str, float]]:
        if not self._model.trained:
            raise ModelError("classifier is not trained")
        x = self.featurizer.transform(texts)
        probs = self._model.predict_proba(x)
        return [{self._labels[i]: float(row[i]) for i in range(len(self._labels))}
                for row in probs]

    @property
    def trained(self) -> bool:
        return self._model.trained

    # ------------------------------------------------------------------
    # Persistence — single-file bundle with integrity hash
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        if not self._model.trained:
            raise ModelError("cannot save an untrained classifier")
        payload: Dict[str, Any] = {
            "bundle_schema": self.BUNDLE_SCHEMA_VERSION,
            "model_schema": MODEL_SCHEMA_VERSION,
            "name": self.name,
            "labels": self._labels,
            "seed": self._seed,
            "featurizer": self.featurizer.to_dict(),
            "model": {
                "layer_sizes": list(self._model.layer_sizes),
                "l2_lambda": self._model.l2_lambda,
                "seed": self._model.seed,
                "trained": self._model.trained,
                "weights": [w.tolist() for w in self._model._weights],
                "biases": [b.tolist() for b in self._model._biases],
                "report": self._report.to_dict() if self._report else None,
            },
        }
        blob = json.dumps(payload, sort_keys=True).encode("utf-8")
        payload["integrity_sha256"] = hashlib.sha256(blob).hexdigest()
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(payload), encoding="utf-8")
        tmp.replace(p)

    @classmethod
    def load(cls, path: str) -> "LearnedTextClassifier":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if payload.get("bundle_schema") != cls.BUNDLE_SCHEMA_VERSION:
            raise ModelError("unsupported classifier bundle schema")
        recorded = payload.get("integrity_sha256")
        stripped = {k: v for k, v in payload.items() if k != "integrity_sha256"}
        actual = hashlib.sha256(
            json.dumps(stripped, sort_keys=True).encode("utf-8")).hexdigest()
        import hmac
        if not recorded or not hmac.compare_digest(str(recorded), actual):
            raise ModelError("classifier bundle integrity check failed")
        obj = cls(name=payload["name"],
                  featurizer=TextFeaturizer.from_dict(payload["featurizer"]),
                  seed=payload["seed"])
        obj._labels = list(payload["labels"])
        m = payload["model"]
        import numpy as np
        obj._model = MLPClassifier(m["layer_sizes"], l2_lambda=m["l2_lambda"],
                                   seed=m["seed"])
        obj._model._weights = [np.asarray(w) for w in m["weights"]]
        obj._model._biases = [np.asarray(b) for b in m["biases"]]
        obj._model.trained = bool(m.get("trained"))
        return obj


@dataclass
class RoutingObservation:
    """One (task, backend, quality score) training observation."""
    task: str
    backend: str
    score: float  # 0..1 quality of this backend on this task
    timestamp: float = field(default_factory=time.time)


class RoutingTrainer:
    """Trains a learned backend router from execution observations.

    Only backends observed at or above ``min_score`` are used as training
    labels, and suggestion is restricted to candidates the model has
    actually seen — the router can never invent a backend.
    """

    def __init__(self, min_score: float = 0.5, dim: int = 256, seed: int = 42) -> None:
        if not 0.0 < min_score <= 1.0:
            raise FeaturizerError("min_score must be in (0, 1]")
        self.min_score = min_score
        self.featurizer = TextFeaturizer(dim)
        self._seed = seed
        self._observations: List[RoutingObservation] = []
        self._classifier: Optional[LearnedTextClassifier] = None

    def record(self, task: str, backend: str, score: float) -> None:
        if not task.strip():
            raise FeaturizerError("task must be non-empty")
        if not backend or len(backend) > 128:
            raise FeaturizerError("invalid backend name")
        if not 0.0 <= score <= 1.0:
            raise FeaturizerError("score must be in [0, 1]")
        self._observations.append(RoutingObservation(task, backend, score))

    def train(self, **fit_kwargs: Any) -> TrainingReport:
        good = [o for o in self._observations if o.score >= self.min_score]
        if len(good) < 4:
            raise FeaturizerError(
                f"need >= {4} observations with score >= {self.min_score}, "
                f"have {len(good)}")
        labels = sorted({o.backend for o in good})
        if len(labels) < 2:
            raise FeaturizerError("need observations for >= 2 backends")
        self._classifier = LearnedTextClassifier(
            name="backend_router", featurizer=self.featurizer, seed=self._seed)
        return self._classifier.train(
            [o.task for o in good], [o.backend for o in good], **fit_kwargs)

    def suggest(self, task: str, candidates: Sequence[str]) -> Optional[str]:
        """Best trained backend among candidates, or None."""
        if self._classifier is None or not self._classifier.trained:
            return None
        if not candidates:
            return None
        probs = self._classifier.predict_proba([task])[0]
        best: Optional[str] = None
        best_p = 0.0
        for cand in candidates:
            p = probs.get(cand, 0.0)
            if p > best_p:
                best, best_p = cand, p
        return best

    @property
    def observation_count(self) -> int:
        return len(self._observations)

    @property
    def trained(self) -> bool:
        return bool(self._classifier and self._classifier.trained)



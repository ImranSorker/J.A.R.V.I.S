"""Tamper-evident provenance records for facts and generated artifacts."""
from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass
from typing import Mapping

@dataclass(frozen=True, slots=True)
class ProvenanceRecord:
    """Origin metadata for a datum."""
    record_id: str
    source: str
    observed_at: str
    content_hash: str
    trust: float
    metadata: Mapping[str, str]

class ProvenanceEngine:
    """Create deterministic provenance records without retaining secrets."""
    def create(self, record_id: str, source: str, observed_at: str, content: str, trust: float, metadata: Mapping[str, str] | None = None) -> ProvenanceRecord:
        """Hash content and validate trust metadata."""
        if not record_id or not source or not observed_at:
            raise ValueError("record_id, source and observed_at are required")
        if not 0.0 <= trust <= 1.0:
            raise ValueError("trust must be between 0 and 1")
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        safe_metadata = {str(k): str(v) for k, v in (metadata or {}).items()}
        json.dumps(safe_metadata)
        return ProvenanceRecord(record_id, source, observed_at, digest, trust, safe_metadata)



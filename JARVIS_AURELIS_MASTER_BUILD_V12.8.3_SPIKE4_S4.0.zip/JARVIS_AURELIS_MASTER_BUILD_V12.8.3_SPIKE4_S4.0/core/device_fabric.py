"""Capability-based device registry and command routing for J.A.R.V.I.S."""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import threading
import time
from typing import Any, Mapping, Protocol


@dataclass(frozen=True, slots=True)
class DeviceDescriptor:
    """Backward-compatible device resource advertisement plus frontier metadata."""

    device_id: str
    platform: str
    cpu_cores: int = 1
    ram_gb: float = 0.0
    vram_gb: float = 0.0
    capabilities: tuple[str, ...] = ()
    online: bool = True
    name: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)
    last_seen: float = field(default_factory=time.time)

    @property
    def device_type(self) -> str:
        """Return the portable device type/platform."""
        return self.platform

    @property
    def connected(self) -> bool:
        """Return the connection state."""
        return self.online


class DeviceAdapter(Protocol):
    """Explicit adapter contract; adapters execute no implicit privileged actions."""

    def execute(self, device: DeviceDescriptor, command: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]: ...
    def snapshot(self, device: DeviceDescriptor) -> Mapping[str, Any]: ...


class DeviceFabric:
    """Central device registry and adapter routing layer."""

    def __init__(self, *, max_devices: int = 512) -> None:
        self.max_devices = max(1, min(int(max_devices), 10_000))
        self._devices: dict[str, DeviceDescriptor] = {}
        self._adapters: dict[str, DeviceAdapter] = {}
        self._lock = threading.RLock()

    def register(self, device: DeviceDescriptor, adapter: DeviceAdapter | None = None) -> None:
        """Register or update a device; execution adapters are optional for discovery-only nodes."""
        if not device.device_id.strip() or not device.platform.strip() or device.cpu_cores < 1 or device.ram_gb < 0 or device.vram_gb < 0:
            raise ValueError("invalid device resources")
        if adapter is not None and (not callable(getattr(adapter, "execute", None)) or not callable(getattr(adapter, "snapshot", None))):
            raise TypeError("invalid device adapter")
        with self._lock:
            if device.device_id not in self._devices and len(self._devices) >= self.max_devices:
                raise RuntimeError("device capacity reached")
            self._devices[device.device_id] = device
            if adapter is not None:
                self._adapters[device.device_id] = adapter

    def get(self, device_id: str) -> DeviceDescriptor | None:
        """Return a device descriptor."""
        with self._lock:
            return self._devices.get(str(device_id))

    def candidates(self, capability: str, min_vram_gb: float = 0.0) -> tuple[DeviceDescriptor, ...]:
        """Return online devices satisfying a capability and VRAM requirement."""
        cap = str(capability).strip()
        with self._lock:
            return tuple(sorted((d for d in self._devices.values() if d.online and (cap in d.capabilities or "*" in d.capabilities) and d.vram_gb >= float(min_vram_gb)), key=lambda d: (-d.vram_gb, d.device_id)))

    def execute(self, device_id: str, command: str, arguments: Mapping[str, Any]) -> Mapping[str, Any]:
        """Dispatch a command through a registered adapter only."""
        device_id, command = str(device_id).strip(), str(command).strip()
        if not device_id or not command:
            raise ValueError("device_id and command are required")
        with self._lock:
            descriptor, adapter = self._devices.get(device_id), self._adapters.get(device_id)
        if descriptor is None or adapter is None or not descriptor.online:
            raise LookupError("device adapter unavailable")
        if descriptor.capabilities and command not in descriptor.capabilities and "*" not in descriptor.capabilities:
            raise PermissionError("device command capability not declared")
        return dict(adapter.execute(descriptor, command, dict(arguments)))

    def snapshot(self) -> dict[str, Any]:
        """Return safe device inventory state."""
        with self._lock:
            rows = []
            for device_id in sorted(self._devices):
                d = self._devices[device_id]
                rows.append({"device_id": d.device_id, "platform": d.platform, "device_type": d.device_type, "name": d.name, "cpu_cores": d.cpu_cores, "ram_gb": d.ram_gb, "vram_gb": d.vram_gb, "capabilities": d.capabilities, "online": d.online, "connected": d.connected, "last_seen": d.last_seen})
            return {"devices": rows, "count": len(rows)}

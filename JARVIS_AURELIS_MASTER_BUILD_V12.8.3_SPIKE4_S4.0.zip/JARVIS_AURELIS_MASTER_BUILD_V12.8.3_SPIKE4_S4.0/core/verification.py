"""Output verification engine."""
from __future__ import annotations
from typing import Any


class VerificationEngine:
    def verify(self, output: str, criteria: str) -> dict[str, Any]:
        score = 0.5
        if criteria.lower() in output.lower():
            score = 0.9
        return {"score": score, "passed": score > 0.7}



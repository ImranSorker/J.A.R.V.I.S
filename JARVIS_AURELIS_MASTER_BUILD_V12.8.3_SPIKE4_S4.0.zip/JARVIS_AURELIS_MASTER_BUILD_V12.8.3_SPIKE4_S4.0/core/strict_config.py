"""Strict configuration validation for the J.A.R.V.I.S. runtime."""
from __future__ import annotations

from typing import Any

SAFE_CAPABILITIES = {
    "calculator", "filesystem.read", "memory.read", "memory.write", "model.infer", "tools.read",
}
HIGH_RISK_PREFIXES = ("process.", "system.", "filesystem.write", "network.", "browser.", "camera.", "microphone.", "model.train.")


def validate_security_dict(sec: dict[str, Any]) -> None:
    """Validate security settings and reject contradictory fail-open configurations."""
    if not isinstance(sec, dict):
        raise ValueError("security must be a dict")
    mode = sec.get("mode", "guarded")
    if mode not in {"guarded", "permissive", "locked", "autonomous"}:
        raise ValueError(f"Invalid security mode: {mode}")
    allowed = sec.get("allowed_capabilities", [])
    if not isinstance(allowed, list) or any(not isinstance(x, str) for x in allowed):
        raise ValueError("allowed_capabilities must be a list of strings")
    if "*" in allowed and not bool(sec.get("allow_code_execution", False)):
        raise ValueError("wildcard capabilities require explicit code-execution permission")
    high_risk = sec.get("high_risk_capabilities", [])
    if not isinstance(high_risk, list) or any(not isinstance(x, str) for x in high_risk):
        raise ValueError("high_risk_capabilities must be a list of strings")
    if mode in {"guarded", "locked"}:
        if bool(sec.get("allow_shell", False)) or bool(sec.get("allow_code_execution", False)):
            raise ValueError("guarded/locked mode cannot enable shell or unrestricted code execution")
        if not bool(sec.get("require_approval_for_high_risk", True)):
            raise ValueError("guarded/locked mode requires approval for high-risk capabilities")
    if bool(sec.get("sandbox_strict_isolation", False)) and bool(sec.get("allow_shell", False)) and mode != "permissive":
        raise ValueError("strict isolation with shell access requires permissive mode or a dedicated sandbox policy")



"""P2-M Multi-Agent Orchestration Fabric.

Canonical coordination plane for independently-certified agents.  The fabric is
policy/authorization neutral with respect to the underlying Security Authority:
it verifies a supplied authorization contract and never manufactures authority.
All coordination artifacts are signed, hash-addressed and replayable.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import json
import random
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict, replace
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

from core.agent_genome import AgentGenome
from core.agent_harness import ExecutionMode
from core.kernel_12_8_0.canonical import canonical_json


VERSION = "12.8.3"
KERNEL_ID = "kernel-12.8.0"
SCHEMA_VERSION = "1.0.0"

TRUST_RANK = {"untrusted": 0, "restricted": 1, "standard": 2, "elevated": 3, "system": 4}
TEAM_STATES = {"draft", "forming", "active", "paused", "completed", "dissolved", "quarantined"}
PARTICIPATION_MODES = {"required", "optional", "on_demand"}
ISOLATION_LEVELS = {"per_agent", "per_team", "per_task"}
COLLABORATION_KINDS = {"delegation", "collaboration", "negotiation", "review", "challenge", "verification", "escalation", "broadcast", "auction", "consensus"}
TOPOLOGIES = {"peer_to_peer", "supervisor", "hierarchical", "blackboard", "market", "committee", "pipeline", "mesh"}
MESSAGE_KINDS = {"request", "response", "inform", "query", "propose", "accept", "reject", "counter_propose", "challenge", "review_result", "escalate", "cancel", "heartbeat"}
OUTCOME_CLASSES = {"completed", "partial", "failed", "cancelled", "timed_out", "deadlocked", "escalated", "escalated_to_human", "diverged", "quarantined"}
DELEGATION_STATES = {"proposed", "accepted", "active", "completed", "failed", "cancelled", "expired", "escalated"}
SESSION_STATES = {"active", "paused", "completed", "failed", "cancelled", "deadlocked"}
CONSENSUS_RULES = {"unanimous", "majority", "supermajority", "weighted", "leader_decides", "ranked_choice"}
PRIORITIES = {"low", "normal", "high", "critical"}
EVIDENCE_REQUIRED_KINDS = {"challenge", "review_result", "verification"}


class OrchestrationError(RuntimeError):
    """Base P2-M error."""


class AuthorizationRequired(OrchestrationError, PermissionError):
    """Security Authority authorization is missing or invalid."""


class TenantIsolationError(OrchestrationError, PermissionError):
    """A cross-tenant operation was attempted."""


class CertificationError(OrchestrationError, PermissionError):
    """An agent is not eligible for orchestration."""


class DelegationCannotWiden(OrchestrationError, PermissionError):
    """Delegation attempted to widen authority."""


class DelegationError(OrchestrationError, ValueError):
    """Delegation contract invalid or lifecycle rule violated."""


class MessageRejected(OrchestrationError, ValueError):
    """Message envelope failed admission."""


class EvidenceRequired(OrchestrationError, ValueError):
    """Evidence is mandatory for the requested operation."""


class ResourceDenied(OrchestrationError, PermissionError):
    """Requested resources exceed the available ceiling."""


class ConsensusError(OrchestrationError, ValueError):
    """Consensus could not be formed under the declared rule."""


class ReplayDivergence(OrchestrationError):
    """Replay produced a different deterministic state."""


class SimulationRequired(OrchestrationError, PermissionError):
    """A dangerous action lacks an approved P2-K simulation handoff."""



def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _uuid() -> str:
    return str(uuid.uuid4())


def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _unb64(value: str) -> bytes:
    return base64.b64decode(value.encode("ascii"), validate=True)


def _sign(payload: Mapping[str, Any], key: Ed25519PrivateKey) -> str:
    return _b64(key.sign(canonical_json(payload)))


def _verify(payload: Mapping[str, Any], signature: str, public_key: bytes | Ed25519PublicKey) -> bool:
    try:
        key = public_key if isinstance(public_key, Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(public_key))
        key.verify(_unb64(signature), canonical_json(payload))
        return True
    except (InvalidSignature, ValueError, TypeError, UnicodeError):
        return False


def _token_set(values: Iterable[Any]) -> frozenset[str]:
    result: set[str] = set()
    for value in values:
        if isinstance(value, Mapping):
            token = value.get("token") or value.get("capability") or value.get("scope") or value.get("name")
        else:
            token = value
        if token is not None and str(token).strip():
            result.add(str(token).strip())
    return frozenset(result)


def _budget(values: Mapping[str, Any] | None = None) -> "BudgetSet":
    data = dict(values or {})
    return BudgetSet(**{name: data.get(name, getattr(BudgetSet(), name)) for name in BudgetSet.__dataclass_fields__})


def _subset(child: Iterable[str], parent: Iterable[str]) -> bool:
    return _token_set(child).issubset(_token_set(parent))


def _min_budget(a: "BudgetSet", b: "BudgetSet") -> "BudgetSet":
    return BudgetSet(**{name: min(getattr(a, name), getattr(b, name)) for name in BudgetSet.__dataclass_fields__})


def _budget_leq(a: "BudgetSet", b: "BudgetSet") -> bool:
    return all(float(getattr(a, k)) <= float(getattr(b, k)) for k in BudgetSet.__dataclass_fields__)


@dataclass(frozen=True, slots=True)
class BudgetSet:
    wall_seconds: float = 60.0
    cpu_seconds: float = 60.0
    ram_mb: int = 1024
    vram_mb: int = 0
    network_bytes: int = 0
    tool_calls: int = 100
    api_calls: int = 100
    tokens_in: int = 100_000
    tokens_out: int = 100_000

    def validate(self) -> None:
        if self.wall_seconds <= 0:
            raise OrchestrationError("wall_seconds must be positive")
        for name, value in asdict(self).items():
            if float(value) < 0:
                raise OrchestrationError(f"budget {name} must be non-negative")

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)

    def remaining_after(self, used: Mapping[str, Any]) -> "BudgetSet":
        self.validate()
        return BudgetSet(**{name: max(0, getattr(self, name) - float(used.get(name, 0))) for name in self.__dataclass_fields__})


@dataclass(frozen=True, slots=True)
class AgentProfile:
    agent_ref: str
    genome_hash: str
    tenant_id: str
    trust_level: str
    capabilities: frozenset[str]
    scopes: frozenset[str]
    tools: frozenset[str]
    skills: frozenset[str]
    budget: BudgetSet
    delegation_depth_max: int = 0
    message_quota: int = 100
    garage_state: str = "MONITORED"
    model_family: str = "unknown"
    certified: bool = True

    @classmethod
    def from_genome(
        cls,
        genome: AgentGenome,
        *,
        tenant_id: str,
        garage_state: str = "MONITORED",
        skills: Sequence[str] = (),
    ) -> "AgentProfile":
        doc = genome.document
        cert = doc.get("certification_status", {})
        capabilities = _token_set(doc.get("capabilities", ()))
        scopes = _token_set(doc.get("permissions", {}).get("allow", ()))
        tools = _token_set(doc.get("tools", ()))
        resource = doc.get("resource_limits", {})
        budget = BudgetSet(
            wall_seconds=float(resource.get("wall_clock_seconds", resource.get("wall_seconds", 60.0))),
            cpu_seconds=float(resource.get("cpu_seconds", 60.0)),
            ram_mb=int(resource.get("ram_mb", 1024)),
            vram_mb=int(resource.get("gpu_vram_mb", 0)),
            network_bytes=int(float(resource.get("network_mb", 0)) * 1024 * 1024),
            tool_calls=int(resource.get("tool_calls", 100)),
            api_calls=int(resource.get("api_calls", 100)),
            tokens_in=int(resource.get("tokens_in", 100_000)),
            tokens_out=int(resource.get("tokens_out", 100_000)),
        )
        return cls(
            agent_ref=f"{genome.agent_uuid}@{genome.genome_version}",
            genome_hash=genome.hash(),
            tenant_id=tenant_id,
            trust_level=str(doc.get("trust_level", "untrusted")),
            capabilities=capabilities,
            scopes=scopes,
            tools=tools,
            skills=frozenset(map(str, skills)),
            budget=budget,
            delegation_depth_max=int(doc.get("reasoning_config", {}).get("delegation_depth_max", 0)),
            message_quota=int(doc.get("resource_limits", {}).get("message_quota", 100)),
            garage_state=str(garage_state),
            model_family=str(doc.get("reasoning_config", {}).get("model_family", "unknown")),
            certified=str(cert.get("status", "uncertified")).lower() == "certified" and genome.verify(),
        )


@dataclass(slots=True)
class TeamMember:
    member_id: str
    agent_ref: str
    agent_genome_hash: str
    role: str
    required_trust: str
    required_capabilities: frozenset[str]
    required_skills: frozenset[str]
    delegation_depth_max: int
    message_quota: int
    resource_quota: BudgetSet
    participation_mode: str

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["required_capabilities"] = sorted(self.required_capabilities)
        d["required_skills"] = sorted(self.required_skills)
        d["resource_quota"] = self.resource_quota.as_dict()
        return d


@dataclass(slots=True)
class Team:
    team_id: str
    team_version: int
    tenant_id: str
    name: str
    description: str
    members: list[TeamMember]
    topology: str
    coordinator_ref: str | None
    consensus_rule: dict[str, Any] | None
    authorization: dict[str, Any]
    policy_ref: str
    isolation_level: str
    knowledge_sharing: dict[str, Any]
    team_budget: BudgetSet
    constraints: list[dict[str, Any]]
    prohibited_actions: list[str]
    required_verifications: list[dict[str, Any]]
    state: str
    formed_at: str | None
    dissolved_at: str | None
    dissolution_reason: str | None
    provenance: dict[str, Any]
    signature: str
    integrity_hash: str

    def unsigned(self) -> dict[str, Any]:
        d = self.to_dict()
        d["signature"] = ""
        d["integrity_hash"] = ""
        return d

    def to_dict(self) -> dict[str, Any]:
        return {
            "team_id": self.team_id, "team_version": self.team_version, "tenant_id": self.tenant_id,
            "name": self.name, "description": self.description, "members": [m.to_dict() for m in self.members],
            "topology": self.topology, "coordinator_ref": self.coordinator_ref, "consensus_rule": copy.deepcopy(self.consensus_rule),
            "authorization": copy.deepcopy(self.authorization), "policy_ref": self.policy_ref, "isolation_level": self.isolation_level,
            "knowledge_sharing": copy.deepcopy(self.knowledge_sharing), "team_budget": self.team_budget.as_dict(),
            "constraints": copy.deepcopy(self.constraints), "prohibited_actions": list(self.prohibited_actions),
            "required_verifications": copy.deepcopy(self.required_verifications), "state": self.state,
            "formed_at": self.formed_at, "dissolved_at": self.dissolved_at, "dissolution_reason": self.dissolution_reason,
            "provenance": copy.deepcopy(self.provenance), "signature": self.signature, "integrity_hash": self.integrity_hash,
        }

    @property
    def member_index(self) -> dict[str, TeamMember]:
        return {m.member_id: m for m in self.members}


@dataclass(slots=True)
class DelegationContract:
    delegation_id: str
    team_id: str
    correlation_id: str
    causation_id: str | None
    from_member: str
    to_member: str
    task: dict[str, Any]
    delegated_capabilities: frozenset[str]
    delegated_scopes: frozenset[str]
    delegated_budget: BudgetSet
    delegated_tools: frozenset[str] | None
    delegated_max_depth: int
    obligations: dict[str, Any]
    acceptance_required: bool
    accepted_at: str | None
    rejected_at: str | None
    rejection_reason: str | None
    state: str
    outcome_ref: str | None
    signature_delegator: str
    signature_delegatee: str | None
    integrity_hash: str
    parent_delegation_id: str | None = None

    def signing_material(self) -> dict[str, Any]:
        d = self.to_dict()
        d.pop("signature_delegator", None); d.pop("signature_delegatee", None); d.pop("integrity_hash", None)
        return d

    def to_dict(self) -> dict[str, Any]:
        return {
            "delegation_id": self.delegation_id, "team_id": self.team_id, "correlation_id": self.correlation_id,
            "causation_id": self.causation_id, "from_member": self.from_member, "to_member": self.to_member,
            "task": copy.deepcopy(self.task), "delegated_capabilities": sorted(self.delegated_capabilities),
            "delegated_scopes": sorted(self.delegated_scopes), "delegated_budget": self.delegated_budget.as_dict(),
            "delegated_tools": sorted(self.delegated_tools) if self.delegated_tools is not None else None,
            "delegated_max_depth": self.delegated_max_depth, "obligations": copy.deepcopy(self.obligations),
            "acceptance_required": self.acceptance_required, "accepted_at": self.accepted_at, "rejected_at": self.rejected_at,
            "rejection_reason": self.rejection_reason, "state": self.state, "outcome_ref": self.outcome_ref,
            "signature_delegator": self.signature_delegator, "signature_delegatee": self.signature_delegatee,
            "integrity_hash": self.integrity_hash, "parent_delegation_id": self.parent_delegation_id,
        }


@dataclass(frozen=True, slots=True)
class MessageEnvelope:
    message_id: str
    team_id: str
    from_member: str
    to_member: str | tuple[str, ...]
    kind: str
    correlation_id: str
    causation_id: str | None
    in_reply_to: str | None
    payload: dict[str, Any]
    evidence_refs: tuple[str, ...]
    claim_refs: tuple[str, ...]
    confidence: float | None
    tokens: int
    cost_units: float
    sent_at: str
    expires_at: str | None
    ttl_seconds: int | None
    signature: str
    sender_key_id: str
    integrity_hash: str

    def signing_material(self) -> dict[str, Any]:
        d = self.to_dict(); d.pop("signature", None); d.pop("integrity_hash", None); return d

    def to_dict(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id, "team_id": self.team_id, "from_member": self.from_member,
            "to_member": list(self.to_member) if isinstance(self.to_member, tuple) else self.to_member, "kind": self.kind,
            "correlation_id": self.correlation_id, "causation_id": self.causation_id, "in_reply_to": self.in_reply_to,
            "payload": copy.deepcopy(self.payload), "evidence_refs": list(self.evidence_refs), "claim_refs": list(self.claim_refs),
            "confidence": self.confidence, "tokens": self.tokens, "cost_units": self.cost_units, "sent_at": self.sent_at,
            "expires_at": self.expires_at, "ttl_seconds": self.ttl_seconds, "signature": self.signature,
            "sender_key_id": self.sender_key_id, "integrity_hash": self.integrity_hash,
        }


@dataclass(slots=True)
class CollaborationSession:
    session_id: str
    team_id: str
    objective: str
    plan_ref: str | None
    roles: dict[str, str]
    topology: str
    entry_contract: str | None
    session_budget: BudgetSet
    state: str
    started_at: str
    finished_at: str | None
    outcome_ref: str | None
    signature: str
    integrity_hash: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id, "team_id": self.team_id, "objective": self.objective, "plan_ref": self.plan_ref,
            "roles": dict(sorted(self.roles.items())), "topology": self.topology, "entry_contract": self.entry_contract,
            "session_budget": self.session_budget.as_dict(), "state": self.state, "started_at": self.started_at,
            "finished_at": self.finished_at, "outcome_ref": self.outcome_ref, "signature": self.signature, "integrity_hash": self.integrity_hash,
        }


class MultiAgentOrchestration:
    """Canonical P2-M coordination fabric."""

    PUBLIC_VERSION = VERSION
    KERNEL_ID = KERNEL_ID
    SCHEMA_VERSION = SCHEMA_VERSION

    EVENT_NAMES = {
        "formed": ("Agent.Collaboration", "Formed"), "dissolved": ("Agent.Collaboration", "Dissolved"),
        "paused": ("Agent.Collaboration", "Paused"), "resumed": ("Agent.Collaboration", "Resumed"),
        "member_added": ("Agent.Collaboration", "MemberAdded"), "member_removed": ("Agent.Collaboration", "MemberRemoved"),
        "delegation_proposed": ("Agent.Delegation", "Proposed"), "delegation_accepted": ("Agent.Delegation", "Accepted"),
        "delegation_rejected": ("Agent.Delegation", "Rejected"), "delegation_active": ("Agent.Delegation", "Active"),
        "delegation_completed": ("Agent.Delegation", "Completed"), "delegation_failed": ("Agent.Delegation", "Failed"),
        "delegation_cancelled": ("Agent.Delegation", "Cancelled"), "delegation_expired": ("Agent.Delegation", "Expired"),
        "message_sent": ("Agent.Message", "Sent"), "message_delivered": ("Agent.Message", "Delivered"), "message_rejected": ("Agent.Message", "Rejected"),
        "review_completed": ("Agent.Review", "Completed"), "challenge_raised": ("Agent.Challenge", "Raised"),
        "challenge_resolved": ("Agent.Challenge", "Resolved"), "verification_recorded": ("Agent.Verification", "Recorded"),
        "escalation_raised": ("Agent.Escalation", "Raised"), "escalation_resolved": ("Agent.Escalation", "Resolved"),
        "deadlocked": ("Agent.Collaboration", "Deadlocked"), "diverged": ("Agent.Collaboration", "Diverged"),
        "replay_divergence": ("Agent.Collaboration", "ReplayDivergence"), "knowledge_shared": ("Agent.Knowledge", "Shared"),
        "share_revoked": ("Agent.Knowledge", "ShareRevoked"), "resources_granted": ("Agent.Resources", "Granted"),
        "resources_denied": ("Agent.Resources", "Denied"),
    }

    def __init__(
        self,
        root: str | Path | None = None,
        *,
        event_fabric: Any | None = None,
        simulation_engine: Any | None = None,
        authorization_verifier: Callable[[Mapping[str, Any], str, str], bool] | None = None,
        team_signer: Ed25519PrivateKey | None = None,
        seed: int = 0,
        max_team_size: int = 32,
        max_delegation_depth: int = 8,
        max_branching_factor: int = 16,
        max_concurrent_delegations: int = 16,
    ) -> None:
        if max_team_size < 1 or max_delegation_depth < 0 or max_branching_factor < 1 or max_concurrent_delegations < 1:
            raise ValueError("orchestration bounds must be positive and depth must be non-negative")
        self.root = Path(root or "./data/multi_agent_orchestration").resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.event_fabric = event_fabric
        self.simulation_engine = simulation_engine
        self.authorization_verifier = authorization_verifier
        self.signer = team_signer or Ed25519PrivateKey.generate()
        self.public_key = self.signer.public_key()
        raw = self.public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.signer_fingerprint = hashlib.sha256(raw).hexdigest()
        self.key_id = self.signer_fingerprint[:16]
        self.seed = int(seed)
        self.max_team_size = int(max_team_size)
        self.max_delegation_depth = int(max_delegation_depth)
        self.max_branching_factor = int(max_branching_factor)
        self.max_concurrent_delegations = int(max_concurrent_delegations)
        self._lock = threading.RLock()
        self._agents: dict[str, AgentProfile] = {}
        self._teams: dict[str, Team] = {}
        self._delegations: dict[str, DelegationContract] = {}
        self._messages: dict[str, MessageEnvelope] = {}
        self._sessions: dict[str, CollaborationSession] = {}
        self._reviews: dict[str, dict[str, Any]] = {}
        self._challenges: dict[str, dict[str, Any]] = {}
        self._verifications: dict[str, dict[str, Any]] = {}
        self._escalations: dict[str, dict[str, Any]] = {}
        self._shares: dict[str, dict[str, Any]] = {}
        self._negotiations: dict[str, dict[str, Any]] = {}
        self._proposals: dict[str, dict[str, Any]] = {}
        self._auctions: dict[str, dict[str, Any]] = {}
        self._outcomes: dict[str, dict[str, Any]] = {}
        self._event_ledger: list[dict[str, Any]] = []
        self._event_previous_hash = "0" * 64
        self._member_message_counts: dict[tuple[str, str], int] = {}
        self._member_usage: dict[tuple[str, str], BudgetSet] = {}
        self._active_delegations: dict[tuple[str, str], set[str]] = {}
        self._blocked_claims: set[tuple[str, str]] = set()
        self._deterministic_replay_overrides: dict[str, list[dict[str, Any]]] = {}

    # ---- Registration / identity ----
    def register_agent_profile(self, profile: AgentProfile) -> None:
        if profile.trust_level not in TRUST_RANK:
            raise CertificationError(f"unknown trust level: {profile.trust_level}")
        profile.budget.validate()
        with self._lock:
            self._agents[profile.agent_ref] = profile

    def register_genome(self, genome: AgentGenome, *, tenant_id: str, garage_state: str = "MONITORED", skills: Sequence[str] = ()) -> AgentProfile:
        if not genome.verify():
            raise CertificationError("agent genome signature verification failed")
        profile = AgentProfile.from_genome(genome, tenant_id=tenant_id, garage_state=garage_state, skills=skills)
        self.register_agent_profile(profile)
        return profile

    def _profile(self, ref: str, tenant_id: str) -> AgentProfile:
        p = self._agents.get(ref)
        if p is None:
            raise CertificationError(f"agent not registered: {ref}")
        if p.tenant_id != tenant_id:
            raise TenantIsolationError("agent belongs to a different tenant")
        if not p.certified:
            raise CertificationError("agent genome is not certified")
        if p.garage_state != "MONITORED":
            raise CertificationError("only MONITORED agents may participate")
        return p

    def _ctx(self, context: Any, tenant_id: str) -> None:
        if context is None or not getattr(context, "execution_id", None):
            raise AuthorizationRequired("P2-E ExecutionContext is required")
        context_tenant = getattr(context, "tenant_id", None)
        if context_tenant is not None and str(context_tenant) != str(tenant_id):
            raise TenantIsolationError("execution context tenant mismatch")

    def _security_authorized(self, token: Mapping[str, Any], tenant_id: str, capability: str) -> None:
        if not token or not str(token.get("authorization_ref", "")).strip() or not str(token.get("expires_at", "")).strip():
            raise AuthorizationRequired("Security Authority authorization token is required")
        expires = token.get("expires_at")
        if isinstance(expires, (int, float)) and float(expires) <= time.time():
            raise AuthorizationRequired("authorization token expired")
        if isinstance(expires, str):
            try:
                if datetime.fromisoformat(expires.replace("Z", "+00:00")).timestamp() <= time.time():
                    raise AuthorizationRequired("authorization token expired")
            except ValueError as exc:
                raise AuthorizationRequired("authorization.expires_at must be RFC3339") from exc
        if str(token.get("tenant_id", tenant_id)) != tenant_id:
            raise TenantIsolationError("authorization tenant mismatch")
        if capability not in _token_set(token.get("capabilities", ())) and capability != "team.form":
            raise AuthorizationRequired(f"authorization missing capability: {capability}")
        if self.authorization_verifier is not None and not self.authorization_verifier(token, tenant_id, capability):
            raise AuthorizationRequired("Security Authority rejected authorization")

    # ---- Artifact signing ----
    def _sign_team(self, team: Team) -> None:
        team.integrity_hash = _sha(team.unsigned())
        material = team.unsigned()
        material["integrity_hash"] = team.integrity_hash
        team.signature = _sign(material, self.signer)

    def verify_team(self, team: Team) -> bool:
        material = team.unsigned()
        digest = _sha(material)
        if digest != team.integrity_hash:
            return False
        signed = dict(material); signed["integrity_hash"] = digest
        return _verify(signed, team.signature, self.public_key)

    def _sign_record(self, record: Mapping[str, Any]) -> tuple[str, str]:
        body = dict(record)
        body.pop("signature", None); body.pop("integrity_hash", None)
        digest = _sha(body)
        signed = dict(body); signed["integrity_hash"] = digest
        return _sign(signed, self.signer), digest

    # ---- Team lifecycle ----
    def form_team(self, spec: Mapping[str, Any], *, context: Any) -> Team:
        tenant_id = str(spec["tenant_id"]); self._ctx(context, tenant_id)
        self._security_authorized(spec.get("authorization", {}), tenant_id, "team.form")
        topology = str(spec.get("topology", "peer_to_peer")); isolation = str(spec.get("isolation_level", "per_agent"))
        if topology not in TOPOLOGIES: raise OrchestrationError(f"invalid topology: {topology}")
        if isolation not in ISOLATION_LEVELS: raise OrchestrationError(f"invalid isolation level: {isolation}")
        if isolation == "per_team" and str(spec.get("authorization", {}).get("isolation_approval", "")) != "security_authority":
            raise AuthorizationRequired("per_team isolation requires explicit Security Authority sign-off")
        members: list[TeamMember] = []
        for raw in spec.get("members", []):
            member_id = str(raw["member_id"]); agent_ref = str(raw["agent_ref"]); profile = self._profile(agent_ref, tenant_id)
            required_trust = str(raw.get("required_trust", "standard"))
            if required_trust not in TRUST_RANK: raise CertificationError("invalid required_trust")
            if TRUST_RANK[profile.trust_level] < TRUST_RANK[required_trust]:
                raise CertificationError("member trust is below required_trust")
            required_caps = _token_set(raw.get("required_capabilities", ()))
            if not required_caps.issubset(profile.capabilities): raise CertificationError("member lacks required capabilities")
            required_skills = _token_set(raw.get("required_skills", ()))
            if not required_skills.issubset(profile.skills): raise CertificationError("member lacks required skills")
            rq = _budget(raw.get("resource_quota", profile.budget.as_dict())); rq.validate()
            if not _budget_leq(rq, profile.budget): raise ResourceDenied("member resource quota exceeds agent budget")
            dmax = int(raw.get("delegation_depth_max", profile.delegation_depth_max));
            if dmax > min(profile.delegation_depth_max, self.max_delegation_depth): raise DelegationCannotWiden("member delegation depth exceeds certified ceiling")
            mq = int(raw.get("message_quota", profile.message_quota));
            if mq > profile.message_quota: raise ResourceDenied("member message quota exceeds agent quota")
            mode = str(raw.get("participation_mode", "required"));
            if mode not in PARTICIPATION_MODES: raise OrchestrationError("invalid participation_mode")
            members.append(TeamMember(member_id, agent_ref, profile.genome_hash, str(raw.get("role", "member")), required_trust, required_caps, required_skills, dmax, mq, rq, mode))
        if not members or len(members) > self.max_team_size: raise OrchestrationError("invalid team size")
        team_budget = _budget(spec.get("team_budget", {})); team_budget.validate()
        for field_name in BudgetSet.__dataclass_fields__:
            total = sum(float(getattr(m.resource_quota, field_name)) for m in members)
            if total > float(getattr(team_budget, field_name)):
                raise ResourceDenied(f"member resource quotas exceed team budget: {field_name}")
        consensus = copy.deepcopy(spec.get("consensus_rule"))
        if consensus is not None and str(consensus.get("rule", "majority")) not in CONSENSUS_RULES: raise ConsensusError("invalid consensus rule")
        now = _utc()
        team = Team(
            team_id=str(spec.get("team_id") or _uuid()), team_version=1, tenant_id=tenant_id, name=str(spec.get("name", "team")), description=str(spec.get("description", "")),
            members=members, topology=topology, coordinator_ref=spec.get("coordinator_ref"), consensus_rule=consensus,
            authorization=copy.deepcopy(spec["authorization"]), policy_ref=str(spec.get("policy_ref", "jarvis.default")), isolation_level=isolation,
            knowledge_sharing=copy.deepcopy(spec.get("knowledge_sharing", {"default_ttl_seconds": 300, "allow_cross_member": True})), team_budget=team_budget,
            constraints=copy.deepcopy(spec.get("constraints", [])), prohibited_actions=list(spec.get("prohibited_actions", [])), required_verifications=copy.deepcopy(spec.get("required_verifications", [])),
            state="active", formed_at=now, dissolved_at=None, dissolution_reason=None,
            provenance=copy.deepcopy(spec.get("provenance", {"created_by": {"principal": "security_authority", "key_id": self.key_id}, "derived_from": None, "template_ref": None, "certification_ref": spec["authorization"]["authorization_ref"]})),
            signature="", integrity_hash="",
        )
        self._sign_team(team)
        with self._lock:
            self._teams[team.team_id] = team
        self._emit("formed", tenant_id, team.team_id, {"team": team.to_dict()})
        return copy.deepcopy(team)

    def inspect_team(self, team_id: str) -> Team:
        with self._lock:
            if team_id not in self._teams: raise OrchestrationError("unknown team")
            return copy.deepcopy(self._teams[team_id])

    def _team(self, team_id: str) -> Team:
        team = self._teams.get(team_id)
        if team is None: raise OrchestrationError(f"unknown team: {team_id}")
        if not self.verify_team(team): raise OrchestrationError("team integrity/signature failure")
        if team.authorization.get("expires_at") and self._expired(team.authorization["expires_at"]):
            if team.state == "active": team.state = "paused"
            raise AuthorizationRequired("team authorization expired")
        return team

    @staticmethod
    def _expired(value: Any) -> bool:
        if isinstance(value, (int, float)): return float(value) <= time.time()
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp() <= time.time()

    def _mutate_team(self, team: Team) -> None:
        team.team_version += 1
        self._sign_team(team)

    def add_member(self, team_id: str, member_spec: Mapping[str, Any], *, context: Any) -> Team:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if team.state != "active": raise OrchestrationError("team is not active")
        if len(team.members) >= self.max_team_size: raise ResourceDenied("team size ceiling reached")
        raw = dict(member_spec); ref = str(raw["agent_ref"]); profile = self._profile(ref, team.tenant_id)
        rq = _budget(raw.get("resource_quota", profile.budget.as_dict())); rq.validate()
        if not _budget_leq(rq, profile.budget): raise ResourceDenied("member quota exceeds agent budget")
        member = TeamMember(str(raw["member_id"]), ref, profile.genome_hash, str(raw.get("role", "member")), str(raw.get("required_trust", "standard")), _token_set(raw.get("required_capabilities", ())), _token_set(raw.get("required_skills", ())), int(raw.get("delegation_depth_max", profile.delegation_depth_max)), int(raw.get("message_quota", profile.message_quota)), rq, str(raw.get("participation_mode", "required")))
        if member.member_id in team.member_index: raise OrchestrationError("duplicate member_id")
        if TRUST_RANK[profile.trust_level] < TRUST_RANK[member.required_trust] or not member.required_capabilities.issubset(profile.capabilities) or not member.required_skills.issubset(profile.skills): raise CertificationError("member does not satisfy floor")
        team.members.append(member); self._mutate_team(team); self._emit("member_added", team.tenant_id, team.team_id, {"member_id": member.member_id}); return copy.deepcopy(team)

    def remove_member(self, team_id: str, member_id: str, *, reason: str, context: Any) -> Team:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if member_id not in team.member_index: raise OrchestrationError("unknown member")
        team.members = [m for m in team.members if m.member_id != member_id]
        team.state = "quarantined" if not team.members else team.state
        self._mutate_team(team); self._emit("member_removed", team.tenant_id, team.team_id, {"member_id": member_id, "reason": reason}); return copy.deepcopy(team)

    def replace_member(self, team_id: str, member_id: str, replacement_spec: Mapping[str, Any], *, context: Any) -> Team:
        self.remove_member(team_id, member_id, reason="replaced", context=context)
        return self.add_member(team_id, replacement_spec, context=context)

    def pause_team(self, team_id: str, reason: str, *, context: Any) -> None:
        team = self._team(team_id); self._ctx(context, team.tenant_id); team.state = "paused"; self._mutate_team(team); self._emit("paused", team.tenant_id, team_id, {"reason": reason})

    def resume_team(self, team_id: str, *, context: Any) -> Team:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        for member in team.members: self._profile(member.agent_ref, team.tenant_id)
        team.state = "active"; self._mutate_team(team); self._emit("resumed", team.tenant_id, team_id, {}); return copy.deepcopy(team)

    def dissolve_team(self, team_id: str, reason: str, *, context: Any) -> None:
        team = self._team(team_id); self._ctx(context, team.tenant_id); team.state = "dissolved"; team.dissolved_at = _utc(); team.dissolution_reason = reason; self._mutate_team(team); self._emit("dissolved", team.tenant_id, team_id, {"reason": reason})

    # ---- Delegation / authority attenuation ----
    def _member(self, team: Team, member_id: str) -> tuple[TeamMember, AgentProfile]:
        m = team.member_index.get(member_id)
        if m is None: raise DelegationError(f"unknown team member: {member_id}")
        return m, self._profile(m.agent_ref, team.tenant_id)

    def _effective_parent_authority(self, from_member: str, parent_delegation_id: str | None, team: Team) -> tuple[frozenset[str], frozenset[str], frozenset[str], BudgetSet, int]:
        member, profile = self._member(team, from_member)
        active = self._active_delegations.get((team.team_id, from_member), set())
        if len(active) >= self.max_concurrent_delegations: raise ResourceDenied("concurrent delegation ceiling reached")
        if parent_delegation_id is None:
            used = self._member_usage.get((team.team_id, from_member), BudgetSet(wall_seconds=0, cpu_seconds=0, ram_mb=0, vram_mb=0, network_bytes=0, tool_calls=0, api_calls=0, tokens_in=0, tokens_out=0))
            remaining = member.resource_quota.remaining_after(used.as_dict())
            return profile.capabilities, profile.scopes, profile.tools, remaining, member.delegation_depth_max
        parent = self._delegations.get(parent_delegation_id)
        if parent is None or parent.team_id != team.team_id or parent.to_member != from_member or parent.state not in {"accepted", "active"}: raise DelegationError("invalid parent delegation chain")
        remaining = parent.delegated_budget
        return parent.delegated_capabilities, parent.delegated_scopes, parent.delegated_tools or frozenset(), remaining, parent.delegated_max_depth

    def delegate(self, team_id: str, from_member: str, to_member: str, task: Mapping[str, Any], obligations: Mapping[str, Any] | None, *, context: Any, parent_delegation_id: str | None = None) -> DelegationContract:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if team.state != "active": raise DelegationError("team is not active")
        from_m, _ = self._member(team, from_member); to_m, _ = self._member(team, to_member)
        caps, scopes, tools, parent_budget, remaining_depth = self._effective_parent_authority(from_member, parent_delegation_id, team)
        requested_caps = _token_set(task.get("delegated_capabilities", ()))
        requested_scopes = _token_set(task.get("delegated_scopes", ()))
        requested_tools = None if task.get("delegated_tools") is None else _token_set(task.get("delegated_tools", ()))
        delegated_budget = _budget(task.get("delegated_budget", parent_budget.as_dict()))
        requested_depth = int(task.get("delegated_max_depth", max(0, remaining_depth - 1)))
        fields = [("delegated_capabilities", requested_caps, caps), ("delegated_scopes", requested_scopes, scopes), ("delegated_budget", delegated_budget, parent_budget), ("delegated_tools", requested_tools, tools)]
        for name, child, parent in fields:
            ok = _budget_leq(child, parent) if isinstance(child, BudgetSet) else _subset(child or (), parent)
            if not ok: raise DelegationCannotWiden(name)
        if requested_depth > max(0, remaining_depth - 1): raise DelegationCannotWiden("delegated_max_depth")
        delegate_profile = self._profile(to_m.agent_ref, team.tenant_id)
        required_trust = str(task.get("required_trust", "untrusted"))
        if TRUST_RANK[delegate_profile.trust_level] < TRUST_RANK[required_trust]: raise CertificationError("delegatee trust below task floor")
        if int(task.get("priority_rank", 0)) < 0: raise DelegationError("invalid task priority")
        if parent_delegation_id is not None and requested_depth >= remaining_depth + 1: raise DelegationCannotWiden("chain depth")
        branch_count = sum(1 for d in self._delegations.values() if d.team_id == team_id and d.from_member == from_member and d.state in {"proposed", "accepted", "active"})
        if branch_count >= self.max_branching_factor: raise ResourceDenied("delegation branching ceiling reached")
        deadline = task.get("deadline")
        danger = self._dangerous_task(task, team)
        simulation_ref = task.get("simulation_outcome_ref")
        if danger and not simulation_ref: raise SimulationRequired("dangerous team action requires P2-K simulation outcome before authorization")
        # The delegation carries attenuation only; it never grants new authority to the team.
        d = DelegationContract(
            delegation_id=_uuid(), team_id=team_id, correlation_id=str(task.get("correlation_id") or _uuid()), causation_id=str(task.get("causation_id")) if task.get("causation_id") else None,
            from_member=from_member, to_member=to_member, task=copy.deepcopy(dict(task)), delegated_capabilities=requested_caps, delegated_scopes=requested_scopes,
            delegated_budget=delegated_budget, delegated_tools=requested_tools, delegated_max_depth=requested_depth,
            obligations=copy.deepcopy(dict(obligations or {})), acceptance_required=bool(task.get("acceptance_required", True)), accepted_at=None, rejected_at=None, rejection_reason=None,
            state="proposed", outcome_ref=None, signature_delegator="", signature_delegatee=None, integrity_hash="", parent_delegation_id=parent_delegation_id,
        )
        d.signature_delegator, d.integrity_hash = self._sign_record(d.to_dict())
        self._delegations[d.delegation_id] = d
        self._emit("delegation_proposed", team.tenant_id, team_id, d.to_dict(), correlation_id=d.correlation_id)
        return copy.deepcopy(d)

    def effective_authority(self, delegation_id: str) -> dict[str, Any]:
        d = self._delegations.get(delegation_id)
        if d is None: raise DelegationError("unknown delegation")
        return {"capabilities": sorted(d.delegated_capabilities), "scopes": sorted(d.delegated_scopes), "budget": d.delegated_budget.as_dict(), "tools": sorted(d.delegated_tools or ()), "max_depth": d.delegated_max_depth, "team_id": d.team_id, "delegatee": d.to_member}

    def _resign_delegation(self, d: DelegationContract) -> None:
        d.signature_delegator, d.integrity_hash = self._sign_record(d.to_dict())

    def accept_delegation(self, delegation_id: str, *, context: Any) -> DelegationContract:
        d = self._delegations.get(delegation_id)
        if d is None: raise DelegationError("unknown delegation")
        team = self._team(d.team_id); self._ctx(context, team.tenant_id)
        if d.state != "proposed": raise DelegationError("delegation is not proposed")
        d.accepted_at = _utc(); d.state = "accepted"; d.signature_delegatee = _sign({"delegation": d.signing_material(), "acceptance": d.accepted_at, "delegatee": d.to_member}, self.signer); self._resign_delegation(d)
        self._active_delegations.setdefault((d.team_id, d.to_member), set()).add(d.delegation_id)
        self._emit("delegation_accepted", team.tenant_id, team.team_id, d.to_dict(), correlation_id=d.correlation_id)
        return copy.deepcopy(d)

    def reject_delegation(self, delegation_id: str, reason: str, *, context: Any) -> None:
        d = self._delegations[delegation_id]; team = self._team(d.team_id); self._ctx(context, team.tenant_id); d.rejected_at = _utc(); d.rejection_reason = reason; d.state = "failed"; self._resign_delegation(d); self._emit("delegation_rejected", team.tenant_id, team.team_id, {"delegation_id": delegation_id, "reason": reason}, correlation_id=d.correlation_id)

    def cancel_delegation(self, delegation_id: str, reason: str, *, context: Any) -> None:
        d = self._delegations[delegation_id]; team = self._team(d.team_id); self._ctx(context, team.tenant_id); d.state = "cancelled"; d.rejection_reason = reason; self._active_delegations.get((d.team_id, d.to_member), set()).discard(d.delegation_id); self._resign_delegation(d); self._emit("delegation_cancelled", team.tenant_id, team.team_id, {"delegation_id": delegation_id, "reason": reason}, correlation_id=d.correlation_id)

    def expire_delegations(self) -> tuple[str, ...]:
        expired = []
        for d in list(self._delegations.values()):
            deadline = d.task.get("deadline")
            if d.state in {"proposed", "accepted", "active"} and deadline is not None and self._expired(deadline):
                team = self._team(d.team_id); d.state = "expired"; d.rejection_reason = "deadline exceeded"; self._active_delegations.get((d.team_id, d.to_member), set()).discard(d.delegation_id); self._resign_delegation(d); self._emit("delegation_expired", team.tenant_id, team.team_id, {"delegation_id": d.delegation_id, "reason": d.rejection_reason}, correlation_id=d.correlation_id); expired.append(d.delegation_id)
        return tuple(expired)

    def sub_delegate(self, delegation_id: str, to_member: str, task: Mapping[str, Any], *, context: Any) -> DelegationContract:
        d = self._delegations.get(delegation_id)
        if d is None: raise DelegationError("unknown delegation")
        if d.to_member != str(task.get("from_member", d.to_member)): task = dict(task, from_member=d.to_member)
        return self.delegate(d.team_id, d.to_member, to_member, task, task.get("obligations", {}), context=context, parent_delegation_id=delegation_id)

    def complete_delegation(self, delegation_id: str, outcome_ref: str, *, failed: bool = False) -> DelegationContract:
        d = self._delegations[delegation_id]; d.outcome_ref = outcome_ref; d.state = "failed" if failed else "completed"; self._active_delegations.get((d.team_id, d.to_member), set()).discard(d.delegation_id); d.task = copy.deepcopy(d.task); self._resign_delegation(d); team = self._team(d.team_id); self._emit("delegation_failed" if failed else "delegation_completed", team.tenant_id, team.team_id, d.to_dict(), correlation_id=d.correlation_id); return copy.deepcopy(d)

    # ---- Messages ----
    def _message_sender_key(self, member: TeamMember) -> str:
        return hashlib.sha256(f"{self.key_id}:{member.member_id}:{member.agent_genome_hash}".encode()).hexdigest()[:16]

    def send(self, message: Mapping[str, Any], *, context: Any) -> MessageEnvelope:
        team = self._team(str(message["team_id"])); self._ctx(context, team.tenant_id)
        sender_id = str(message["from_member"]); sender, _ = self._member(team, sender_id)
        recipients = tuple(message["to_member"]) if isinstance(message.get("to_member"), (list, tuple)) else str(message["to_member"])
        targets = recipients if isinstance(recipients, tuple) else (recipients,)
        if any(t not in team.member_index for t in targets): raise MessageRejected("recipient outside team")
        kind = str(message["kind"])
        if kind not in MESSAGE_KINDS: raise MessageRejected("invalid message kind")
        evidence = tuple(map(str, message.get("evidence_refs", ())))
        if kind in EVIDENCE_REQUIRED_KINDS and not evidence: raise EvidenceRequired(f"{kind} requires evidence_refs")
        count_key = (team.team_id, sender_id); current = self._member_message_counts.get(count_key, 0)
        if current >= sender.message_quota: raise MessageRejected("message quota exceeded")
        if "schema_ref" not in message or not str(message.get("schema_ref")): raise MessageRejected("typed payload schema_ref is required")
        body = {"schema_ref": str(message["schema_ref"]), "body": copy.deepcopy(message.get("body", {}))}
        confidence = message.get("confidence")
        if confidence is not None and not 0 <= float(confidence) <= 1: raise MessageRejected("confidence must be between 0 and 1")
        msg = MessageEnvelope(_uuid(), team.team_id, sender_id, recipients, kind, str(message.get("correlation_id") or _uuid()), message.get("causation_id"), message.get("in_reply_to"), body, evidence, tuple(map(str, message.get("claim_refs", ()))), float(confidence) if confidence is not None else None, int(message.get("tokens", 0)), float(message.get("cost_units", 0)), _utc(), message.get("expires_at"), message.get("ttl_seconds"), "", self._message_sender_key(sender), "")
        signature, digest = self._sign_record(msg.to_dict()); msg = replace(msg, signature=signature, integrity_hash=digest)
        self._messages[msg.message_id] = msg; self._member_message_counts[count_key] = current + 1
        self._emit("message_sent", team.tenant_id, team.team_id, msg.to_dict(), correlation_id=msg.correlation_id)
        self._emit("message_delivered", team.tenant_id, team.team_id, {"message_id": msg.message_id, "recipients": list(targets)}, correlation_id=msg.correlation_id, causation_id=msg.message_id)
        return msg

    def broadcast(self, team_id: str, from_member: str, kind: str, payload: Mapping[str, Any], *, context: Any, schema_ref: str = "urn:jarvis:agent-message:1.0.0") -> MessageEnvelope:
        team = self._team(team_id)
        return self.send({"team_id": team_id, "from_member": from_member, "to_member": list(team.member_index), "kind": kind, "payload": payload, "body": payload, "schema_ref": schema_ref}, context=context)

    def query_messages(self, team_id: str, *, member_id: str | None = None, correlation_id: str | None = None) -> list[MessageEnvelope]:
        team = self._team(team_id); result=[]
        for msg in self._messages.values():
            if msg.team_id != team_id: continue
            if member_id and msg.from_member != member_id and member_id not in (msg.to_member if isinstance(msg.to_member, tuple) else (msg.to_member,)): continue
            if correlation_id and msg.correlation_id != correlation_id: continue
            result.append(copy.deepcopy(msg))
        result.sort(key=lambda x: (x.sent_at, x.message_id)); return result

    def replay_messages(self, team_id: str, from_checkpoint: int = 0) -> tuple[MessageEnvelope, ...]:
        team = self._team(team_id); _ = team
        return tuple(self.query_messages(team_id)[max(0, int(from_checkpoint)):])

    # ---- Sessions ----
    def collaborate(self, team_id: str, objective: str, roles: Mapping[str, str], plan_ref: str | None = None, *, context: Any, entry_contract: str | None = None, session_budget: Mapping[str, Any] | None = None, topology: str | None = None) -> CollaborationSession:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if set(roles) - set(team.member_index): raise OrchestrationError("session roles reference non-members")
        budget = _budget(session_budget or team.team_budget.as_dict())
        if not _budget_leq(budget, team.team_budget): raise ResourceDenied("session budget exceeds team budget")
        session = CollaborationSession(_uuid(), team_id, str(objective), plan_ref, dict(roles), topology or team.topology, entry_contract, budget, "active", _utc(), None, None, "", "")
        signature, digest = self._sign_record(session.to_dict()); session.signature = signature; session.integrity_hash = digest; self._sessions[session.session_id] = session
        self._event_ledger.append({"kind": "session_started", "session_id": session.session_id, "team_id": team_id, "objective": objective})
        return copy.deepcopy(session)

    # ---- Review / challenge / verification ----
    def review(self, team_id: str, reviewer: str, target_ref: str, criteria: Sequence[str], findings: Sequence[Mapping[str, Any]], *, context: Any, author_member: str | None = None, confidence: float = 0.0) -> dict[str, Any]:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if author_member and reviewer == author_member: raise OrchestrationError("self_review_forbidden")
        if not findings or any(not f.get("evidence_refs") for f in findings): raise EvidenceRequired("review findings require evidence_refs")
        record = {"review_id": _uuid(), "team_id": team_id, "reviewer_member": reviewer, "target_ref": target_ref, "criteria": list(criteria), "findings": [dict(f) for f in findings], "overall": self._overall_findings(findings), "confidence": float(confidence), "independence_attested": reviewer != (author_member or ""), "signed_at": _utc()}
        record["signature"], record["integrity_hash"] = self._sign_record(record); self._reviews[record["review_id"]] = record; self._emit("review_completed", team.tenant_id, team_id, record); return copy.deepcopy(record)

    @staticmethod
    def _overall_findings(findings: Sequence[Mapping[str, Any]]) -> str:
        values = {str(f.get("result", "inconclusive")) for f in findings}
        return "fail" if "fail" in values else "inconclusive" if "inconclusive" in values else "pass"

    def challenge(self, team_id: str, challenger: str, claim_ref: str, evidence_refs: Sequence[str], *, context: Any, ground: str = "evidence", severity: str = "medium") -> dict[str, Any]:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if not evidence_refs: raise EvidenceRequired("challenge requires evidence")
        self._blocked_claims.add((team_id, str(claim_ref)))
        rec = {"challenge_id": _uuid(), "team_id": team_id, "challenger_member": challenger, "claim_ref": str(claim_ref), "ground": ground, "evidence_refs": list(map(str, evidence_refs)), "severity": severity, "status": "open", "resolution_ref": None, "signed_at": _utc()}
        rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._challenges[rec["challenge_id"]] = rec; self._emit("challenge_raised", team.tenant_id, team_id, rec); return copy.deepcopy(rec)

    def resolve_challenge(self, challenge_id: str, resolution_ref: str, status: str, *, context: Any) -> dict[str, Any]:
        rec = self._challenges[challenge_id]; team = self._team(rec["team_id"]); self._ctx(context, team.tenant_id)
        if status not in {"upheld", "dismissed", "resolved"}: raise OrchestrationError("invalid challenge status")
        rec["status"] = status; rec["resolution_ref"] = resolution_ref; rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._blocked_claims.discard((team.team_id, rec["claim_ref"])); self._emit("challenge_resolved", team.tenant_id, team.team_id, rec); return copy.deepcopy(rec)

    def verify(self, team_id: str, verifier: str, claim_ref: str, evidence_refs: Sequence[str], *, context: Any, proposer_member: str, high_stakes: bool = True, verification_kind: str = "independent_check", result: str = "verified", confidence: float = 0.0) -> dict[str, Any]:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if not evidence_refs: raise EvidenceRequired("verification requires evidence")
        if verifier == proposer_member: raise OrchestrationError("self_verification_forbidden")
        _, vp = self._member(team, verifier); _, pp = self._member(team, proposer_member)
        independent = vp.model_family != pp.model_family
        if high_stakes and not independent: raise OrchestrationError("high-stakes verification requires different model family")
        rec = {"verification_id": _uuid(), "team_id": team_id, "verifier_member": verifier, "claim_ref": str(claim_ref), "verification_kind": verification_kind, "result": result, "evidence_refs": list(map(str, evidence_refs)), "confidence": float(confidence), "independence_attested": independent, "signed_at": _utc()}
        rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._verifications[rec["verification_id"]] = rec; self._emit("verification_recorded", team.tenant_id, team_id, rec); return copy.deepcopy(rec)

    # ---- Escalation ----
    def escalate(self, team_id: str, from_member: str, to_member_or_human: str, reason: str, evidence_refs: Sequence[str], *, context: Any, depth: int = 0, deadline: Any = None, to_human: bool = False) -> dict[str, Any]:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if not evidence_refs: raise EvidenceRequired("escalation requires evidence")
        configured_max = next((int(c["max_escalation_depth"]) for c in team.constraints if "max_escalation_depth" in c), 4)
        if depth > configured_max: raise OrchestrationError("escalation depth exceeded")
        rec = {"escalation_id": _uuid(), "team_id": team_id, "from_member": from_member, "target": to_member_or_human, "reason": reason, "evidence_refs": list(map(str, evidence_refs)), "depth": int(depth), "to_human": bool(to_human), "deadline": deadline, "status": "raised", "raised_at": _utc()}
        rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._escalations[rec["escalation_id"]] = rec; self._emit("escalation_raised", team.tenant_id, team_id, rec); return copy.deepcopy(rec)

    def resolve_escalation(self, escalation_id: str, resolution_ref: str, *, context: Any) -> dict[str, Any]:
        rec = self._escalations[escalation_id]; team = self._team(rec["team_id"]); self._ctx(context, team.tenant_id); rec["status"] = "resolved"; rec["resolution_ref"] = resolution_ref; rec["resolved_at"] = _utc(); rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._emit("escalation_resolved", team.tenant_id, team.team_id, rec); return copy.deepcopy(rec)

    def check_escalation_deadlines(self) -> tuple[str, ...]:
        timed_out=[]
        for rec in self._escalations.values():
            if rec.get("status") == "raised" and rec.get("deadline") is not None and self._expired(rec["deadline"]):
                team = self._team(rec["team_id"]); rec["status"] = "timed_out"; rec["diagnostic_ref"] = f"simulation-required:{rec['escalation_id']}"; rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._emit("deadlocked", team.tenant_id, team.team_id, {"escalation_id": rec["escalation_id"], "diagnostic_ref": rec["diagnostic_ref"]}); timed_out.append(rec["escalation_id"])
        return tuple(timed_out)

    # ---- Knowledge sharing ----
    def share_knowledge(self, team_id: str, from_member: str, knowledge_ref: str, scope: str, ttl: int, *, context: Any, recipients: Sequence[str] | None = None) -> dict[str, Any]:
        team = self._team(team_id); self._ctx(context, team.tenant_id)
        if ttl <= 0: raise OrchestrationError("knowledge share ttl must be positive")
        targets = tuple(recipients or [m.member_id for m in team.members if m.member_id != from_member])
        if any(t not in team.member_index for t in targets): raise TenantIsolationError("knowledge recipient outside team")
        rec = {"share_id": _uuid(), "team_id": team_id, "from_member": from_member, "recipients": list(targets), "knowledge_ref": knowledge_ref, "scope": scope, "expires_at": datetime.fromtimestamp(time.time()+int(ttl), timezone.utc).isoformat().replace("+00:00", "Z"), "revoked": False, "created_at": _utc()}
        rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._shares[rec["share_id"]] = rec; self._emit("knowledge_shared", team.tenant_id, team_id, rec); return copy.deepcopy(rec)

    def revoke_knowledge_share(self, share_id: str, reason: str, *, context: Any) -> dict[str, Any]:
        rec=self._shares[share_id]; team=self._team(rec["team_id"]); self._ctx(context, team.tenant_id); rec["revoked"]=True; rec["revocation_reason"]=reason; rec["revoked_at"]=_utc(); rec["signature"], rec["integrity_hash"] = self._sign_record(rec); self._emit("share_revoked", team.tenant_id, team.team_id, rec); return copy.deepcopy(rec)

    def inspect_shared_knowledge(self, team_id: str, *, at: float | None = None) -> list[dict[str, Any]]:
        team=self._team(team_id); now=time.time() if at is None else float(at); result=[]
        for rec in self._shares.values():
            if rec["team_id"] != team_id or rec.get("revoked"): continue
            if self._expired(rec["expires_at"]): continue
            result.append(copy.deepcopy(rec))
        result.sort(key=lambda r: (r["created_at"], r["share_id"])); return result

    # ---- Resource negotiation ----
    def request_resources(self, team_id: str, member_id: str, request: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context, team.tenant_id); self._member(team, member_id); rid=_uuid(); rec={"negotiation_id":rid,"team_id":team_id,"member_id":member_id,"request":_budget(request).as_dict(),"state":"requested","created_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._negotiations[rid]=rec; return copy.deepcopy(rec)

    def grant_resources(self, negotiation_id: str, grant: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        rec=self._negotiations[negotiation_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); requested=_budget(rec["request"]); granted=_budget(grant)
        already=BudgetSet(**{name: sum(float(r.get("grant",{}).get(name,0)) for r in self._negotiations.values() if r.get("team_id")==team.team_id and r.get("state")=="granted") for name in BudgetSet.__dataclass_fields__})
        remaining=team.team_budget.remaining_after(already.as_dict())
        if not _budget_leq(granted,requested) or not _budget_leq(granted,remaining): raise ResourceDenied("resource grant exceeds request or team ceiling")
        rec["grant"]=granted.as_dict(); rec["state"]="granted"; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._emit("resources_granted",team.tenant_id,team.team_id,rec); return copy.deepcopy(rec)

    def deny_resources(self, negotiation_id: str, reason: str, *, context: Any) -> dict[str, Any]:
        rec=self._negotiations[negotiation_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); rec["state"]="denied"; rec["reason"]=reason; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._emit("resources_denied",team.tenant_id,team.team_id,rec); return copy.deepcopy(rec)

    # ---- Negotiation / consensus / auction ----
    def _rng(self, team_id: str, seed: int | None = None) -> random.Random:
        material = f"{self.seed}:{seed if seed is not None else 0}:{team_id}".encode(); return random.Random(int.from_bytes(hashlib.sha256(material).digest()[:8], "big"))

    def propose_terms(self, team_id: str, from_member: str, to_member: str, terms: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id); pid=_uuid(); rec={"proposal_id":pid,"team_id":team_id,"from_member":from_member,"to_member":to_member,"terms":copy.deepcopy(dict(terms)),"state":"proposed","created_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._proposals[pid]=rec; return copy.deepcopy(rec)

    def counter_propose(self, proposal_id: str, terms: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        rec=self._proposals[proposal_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); rec["counter_terms"]=copy.deepcopy(dict(terms)); rec["state"]="counter_proposed"; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return copy.deepcopy(rec)

    def accept_terms(self, proposal_id: str, *, context: Any) -> dict[str, Any]:
        rec=self._proposals[proposal_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); rec["state"]="accepted"; rec["accepted_at"]=_utc(); rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return copy.deepcopy(rec)

    def reject_terms(self, proposal_id: str, reason: str, *, context: Any) -> dict[str, Any]:
        rec=self._proposals[proposal_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); rec["state"]="rejected"; rec["reason"]=reason; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return copy.deepcopy(rec)

    def auction(self, team_id: str, task: Mapping[str, Any], bidders: Sequence[str], rules: Mapping[str, Any], *, context: Any, seed: int | None = None) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id)
        eligible=[]
        for b in bidders:
            self._member(team,b); eligible.append(b)
        if not eligible: raise OrchestrationError("auction requires bidders")
        # Bid ordering is strictly derived from canonical bid content; seeded tie-break handles exact ties.
        rules_copy=copy.deepcopy(dict(rules)); rid=_uuid(); rec={"auction_id":rid,"team_id":team_id,"task":copy.deepcopy(dict(task)),"bidders":sorted(eligible),"rules":rules_copy,"bids":{},"state":"open","seed":int(seed if seed is not None else self.seed)}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._auctions[rid]=rec; return copy.deepcopy(rec)

    def bid(self, auction_id: str, bidder: str, terms: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        rec=self._auctions[auction_id]; team=self._team(rec["team_id"]); self._ctx(context,team.tenant_id); 
        if bidder not in rec["bidders"]: raise OrchestrationError("bidder is not eligible")
        rec["bids"][bidder]=copy.deepcopy(dict(terms)); rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return copy.deepcopy(rec)

    def close_auction(self, auction_id: str) -> dict[str, Any]:
        rec=self._auctions[auction_id]; team=self._team(rec["team_id"]); bids=rec["bids"]
        if not bids: raise OrchestrationError("cannot close auction without bids")
        rule=str(rec["rules"].get("selection", "lowest_cost")); rows=[]
        for bidder, terms in bids.items():
            score=float(terms.get("score", terms.get("cost", 0)))
            if rule == "highest_score": score=-score
            rows.append((score, canonical_json(terms), bidder))
        rows.sort(key=lambda x: (x[0], x[1], x[2])); best_score=rows[0][0]; tied=[x for x in rows if x[0]==best_score]
        winner=tied[0][2] if len(tied)==1 else self._rng(team.team_id, rec["seed"]).choice(sorted(t[2] for t in tied))
        rec["winner"]=winner; rec["state"]="closed"; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return copy.deepcopy(rec)

    def consensus(self, team_id: str, proposal: Mapping[str, Any], rule: Mapping[str, Any] | None = None, *, context: Any, votes: Mapping[str, Any]) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id); cfg=dict(rule or team.consensus_rule or {"rule":"majority"}); kind=str(cfg.get("rule","majority"))
        if kind not in CONSENSUS_RULES: raise ConsensusError("unsupported consensus rule")
        for member in votes: self._member(team,member)
        if set(votes) - set(team.member_index): raise ConsensusError("vote outside team")
        values=list(votes.values()); decision=None
        if kind == "unanimous":
            if values and len(set(map(json.dumps, values))) == 1: decision=values[0]
        elif kind in {"majority", "supermajority"}:
            counts={json.dumps(v,sort_keys=True):0 for v in values}
            for v in values: counts[json.dumps(v,sort_keys=True)] += 1
            if counts:
                winner_key=max(sorted(counts), key=lambda k: counts[k]); needed=(len(values)//2)+1 if kind=="majority" else int(len(values)*float(cfg.get("threshold",0.667))+0.999)
                if counts[winner_key] >= needed: decision=json.loads(winner_key)
        elif kind == "leader_decides":
            leader=str(cfg.get("leader"))
            if leader in votes: decision=votes[leader]
        else:
            decision=values[0] if values else None
        if decision is None: raise ConsensusError("consensus not reached")
        rec={"consensus_id":_uuid(),"team_id":team_id,"proposal":copy.deepcopy(dict(proposal)),"rule":cfg,"votes":copy.deepcopy(dict(votes)),"decision":copy.deepcopy(decision),"created_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); return rec

    # ---- Outcomes / deadlocks / divergence ----
    def record_outcome(self, team_id: str, outcome: Mapping[str, Any], *, context: Any) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id); cls=str(outcome.get("outcome_class"));
        if cls not in OUTCOME_CLASSES: raise OrchestrationError("invalid outcome class")
        rec={"outcome_id":_uuid(),"team_id":team_id,"outcome_class":cls,"details":copy.deepcopy(dict(outcome)),"recorded_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._outcomes[rec["outcome_id"]]=rec; return copy.deepcopy(rec)

    def close_team(self, team_id: str, outcome: Mapping[str, Any], *, context: Any) -> Team:
        rec=self.record_outcome(team_id,outcome,context=context); team=self._team(team_id); team.state="completed" if outcome.get("outcome_class")=="completed" else "dissolved"; team.dissolved_at=_utc(); team.dissolution_reason=str(outcome.get("reason", outcome.get("outcome_class"))); team.constraints.append({"closed_outcome_ref":rec["outcome_id"]}); self._mutate_team(team); self._emit("dissolved",team.tenant_id,team.team_id,{"outcome_ref":rec["outcome_id"]}); return copy.deepcopy(team)

    def detect_deadlock(self, team_id: str, dependency_edges: Sequence[Sequence[str]], *, context: Any, no_progress_seconds: float = 0.0) -> dict[str, Any] | None:
        team=self._team(team_id); self._ctx(context,team.tenant_id); graph={str(a):str(b) for a,b in dependency_edges}
        visited=set(); stack=set(); cycle=[]
        def dfs(node: str) -> bool:
            if node in stack: cycle.append(node); return True
            if node in visited: return False
            visited.add(node); stack.add(node); nxt=graph.get(node)
            if nxt and dfs(nxt): cycle.append(node); return True
            stack.discard(node); return False
        found=any(dfs(n) for n in graph)
        if not found and no_progress_seconds <= 0: return None
        rec={"team_id":team_id,"kind":"deadlock","cycle":list(reversed(cycle)),"no_progress_seconds":float(no_progress_seconds),"outcome_class":"deadlocked","requires_escalation":True,"recorded_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._emit("deadlocked",team.tenant_id,team_id,rec); return rec

    def detect_divergence(self, team_id: str, conclusions: Mapping[str, Any], *, context: Any, consensus_rule: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        team=self._team(team_id); self._ctx(context,team.tenant_id)
        values={canonical_json(v) for v in conclusions.values()}
        if len(values) <= 1: return None
        try: self.consensus(team_id,{"kind":"divergence_probe"},consensus_rule,context=context,votes=conclusions)
        except ConsensusError:
            rec={"team_id":team_id,"kind":"divergence","conclusions":copy.deepcopy(dict(conclusions)),"outcome_class":"diverged","requires_escalation":True,"recorded_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._emit("diverged",team.tenant_id,team_id,rec); return rec
        return None

    # ---- Determinism / replay ----
    def _state_digest(self, team_id: str) -> str:
        team=self._team(team_id)
        messages=[m.to_dict() for m in self._messages.values() if m.team_id==team_id]
        delegations=[d.to_dict() for d in self._delegations.values() if d.team_id==team_id]
        payload={"team":team.to_dict(),"messages":sorted(messages,key=lambda x:x["message_id"]),"delegations":sorted(delegations,key=lambda x:x["delegation_id"]),"ledger":[e for e in self._event_ledger if e.get("team_id")==team_id]}
        return _sha(payload)

    def replay_team(self, team_id: str, *, expected_digest: str | None = None) -> dict[str, Any]:
        digest=self._state_digest(team_id)
        if expected_digest and digest != expected_digest:
            team=self._team(team_id); rec={"team_id":team_id,"expected_digest":expected_digest,"actual_digest":digest,"recorded_at":_utc()}; rec["signature"],rec["integrity_hash"]=self._sign_record(rec); self._emit("replay_divergence",team.tenant_id,team_id,rec); raise ReplayDivergence("team replay digest diverged")
        return {"team_id":team_id,"state_digest":digest,"messages":len([m for m in self._messages.values() if m.team_id==team_id]),"delegations":len([d for d in self._delegations.values() if d.team_id==team_id]),"event_count":len([e for e in self._event_ledger if e.get("team_id")==team_id])}

    # ---- Quarantine propagation ----
    def propagate_quarantine(self, agent_ref: str, *, tenant_id: str, reason: str) -> tuple[str, ...]:
        removed=[]
        for team in list(self._teams.values()):
            if team.tenant_id != tenant_id: continue
            if any(m.agent_ref == agent_ref for m in team.members) and team.state in {"active", "paused"}:
                team.members=[m for m in team.members if m.agent_ref != agent_ref]; team.state="quarantined" if not team.members else team.state; self._mutate_team(team); removed.append(team.team_id); self._emit("member_removed",tenant_id,team.team_id,{"agent_ref":agent_ref,"reason":"quarantine:"+reason})
        profile=self._agents.get(agent_ref)
        if profile is not None: self._agents[agent_ref]=replace(profile, garage_state="QUARANTINED")
        return tuple(removed)

    # ---- P2-K simulation + authorization handoff ----
    def _dangerous_task(self, task: Mapping[str, Any], team: Team) -> bool:
        effects=set(map(str,task.get("effects", task.get("effect_class", [])) if isinstance(task.get("effects", task.get("effect_class", [])), (list,tuple,set)) else [task.get("effects", task.get("effect_class", ""))]))
        action = str(task.get("action_class", ""))
        if any(e in {"destructive","financial","identity","device","communication","irreversible"} for e in effects): return True
        return action in {"device_action","system_change","security_action"} or any(pattern in action for pattern in team.prohibited_actions)

    def simulation_mandate(self, team_id: str, task: Mapping[str, Any], *, context: Any, simulation_context: Any | None = None) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id)
        if not self._dangerous_task(task,team): return {"required":False,"authorization_permitted":True,"simulation_outcome_ref":None}
        if self.simulation_engine is None: raise SimulationRequired("P2-K simulation engine is not configured")
        sim_ctx = simulation_context or context
        if getattr(sim_ctx, "execution_mode", getattr(sim_ctx, "mode", None)) not in {ExecutionMode.SIMULATION, ExecutionMode.SIMULATION.value}:
            raise SimulationRequired("P2-K simulation must run in P2-E simulation mode")
        universe = self.simulation_engine.prepare(dict(task.get("simulation_target", task)), "behavioral", "isolated", {"expected_outcome":"success"}, execution_context=sim_ctx, tenant_id=team.tenant_id, seed=self.seed)
        outcome=self.simulation_engine.run(universe.universe_id)
        handoff=self.simulation_engine.authorization_handoff(universe.universe_id)
        if not handoff.get("authorization_permitted"): raise SimulationRequired("P2-K simulation did not produce an authorization-permitted outcome")
        return {"required":True,"authorization_permitted":True,"simulation_universe_id":universe.universe_id,"simulation_outcome_ref":outcome.outcome_hash,"handoff":handoff}

    def authorization_handoff(self, team_id: str, action: Mapping[str, Any], *, context: Any, simulation: Mapping[str, Any] | None = None) -> dict[str, Any]:
        team=self._team(team_id); self._ctx(context,team.tenant_id); dangerous=self._dangerous_task(action,team)
        if dangerous:
            if not simulation or not simulation.get("authorization_permitted") or not simulation.get("simulation_outcome_ref"): raise SimulationRequired("dangerous authorization handoff lacks a successful P2-K proof")
        # Team authorization never substitutes for member authorization.
        return {"team_id":team_id,"team_authorization_ref":team.authorization["authorization_ref"],"dangerous":dangerous,"simulation_required":dangerous,"simulation_outcome_ref":simulation.get("simulation_outcome_ref") if simulation else None,"member_authority_invariant":True,"central_authorization_required":True}

    # ---- Event integration ----
    def _emit(self, event_key: str, tenant_id: str, team_id: str, payload: Mapping[str, Any], *, correlation_id: str | None = None, causation_id: str | None = None) -> None:
        event_type,event_name=self.EVENT_NAMES[event_key]
        row={"event_key":event_key,"tenant_id":tenant_id,"team_id":team_id,"payload":copy.deepcopy(dict(payload)),"correlation_id":correlation_id,"causation_id":causation_id,"timestamp":_utc()}
        row["previous_hash"]=self._event_previous_hash; row["integrity_hash"]=_sha(row); self._event_previous_hash=row["integrity_hash"]; self._event_ledger.append(row)
        if self.event_fabric is None: return
        try:
            from core.event_fabric import AuthContext, EventEnvelope, ProducedBy
            event = EventEnvelope.create(
                event_type=event_type, event_name=event_name, payload=dict(payload),
                produced_by=ProducedBy("system", "multi-agent-orchestration", self.signer_fingerprint, "system"),
                auth_context=AuthContext("multi-agent-orchestration", ("events.publish.agent.collaboration", "events.publish.agent.delegation", "events.publish.agent.message", "events.publish.agent.review", "events.publish.agent.challenge", "events.publish.agent.verification", "events.publish.agent.escalation", "events.publish.agent.knowledge", "events.publish.agent.resources"), f"team:{team_id}", None),
                tenant_id=tenant_id, partition_key=team_id, correlation_id=correlation_id, causation_id=causation_id, signing_key=self.signer,
            )
            self.event_fabric.publish_envelope(event)
        except Exception as exc:
            # Never silently turn a durable Event Fabric admission failure into authority.
            row["event_publish_error"] = type(exc).__name__
            if event_key in {"formed", "delegation_proposed", "delegation_accepted", "message_sent", "review_completed", "challenge_raised", "verification_recorded", "escalation_raised"}:
                raise

    # ---- Diagnostics ----
    def health(self) -> dict[str, Any]:
        return {"status":"ready","public_version":VERSION,"kernel_id":KERNEL_ID,"teams":len(self._teams),"agents":len(self._agents),"delegations":len(self._delegations),"messages":len(self._messages),"sessions":len(self._sessions),"event_ledger":len(self._event_ledger)}

    def snapshot(self, team_id: str | None = None) -> dict[str, Any]:
        teams=self._teams.values() if team_id is None else [self._team(team_id)]
        return {"version":VERSION,"kernel_id":KERNEL_ID,"teams":[t.to_dict() for t in teams],"delegations":[d.to_dict() for d in self._delegations.values() if team_id is None or d.team_id==team_id],"messages":[m.to_dict() for m in self._messages.values() if team_id is None or m.team_id==team_id],"event_ledger":copy.deepcopy([e for e in self._event_ledger if team_id is None or e.get("team_id")==team_id])}

    def close(self) -> None:
        return None


# Public aliases matching phase terminology.
TeamOrchestrator = MultiAgentOrchestration
AgentMessage = MessageEnvelope

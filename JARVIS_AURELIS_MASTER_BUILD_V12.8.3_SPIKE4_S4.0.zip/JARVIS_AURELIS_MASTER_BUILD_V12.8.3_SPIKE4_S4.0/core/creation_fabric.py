"""Policy-aware factory for generating and validating tools, utilities and artifacts.

The factory separates *generation* from *execution*. Generated source is treated as
untrusted until AST validation, workspace confinement, manifest validation and an
optional policy approval have succeeded. This allows a model-backed generator to be
plugged in without granting the model direct filesystem or process access.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Mapping
from .permission_engine import PermissionEngine

ArtifactKind = str
CodeGenerator = Callable[[str, str, str], str]
_NAME = re.compile(r"^[a-z][a-z0-9_-]{1,62}$")
_MAX_CONTENT_BYTES = 2_000_000
_SAFE_PYTHON_MODULES = {"base64", "collections", "dataclasses", "datetime", "decimal", "functools", "hashlib", "itertools", "json", "math", "pathlib", "re", "statistics", "string", "textwrap", "time", "typing", "uuid"}
_FORBIDDEN_PYTHON_CALLS = {"eval", "exec", "compile", "__import__", "open", "input"}
_FORBIDDEN_PYTHON_MODULES = {"ctypes", "importlib", "marshal", "os", "pickle", "pty", "resource", "shutil", "socket", "subprocess", "sys"}

@dataclass(frozen=True, slots=True)
class BuildRequest:
    """Validated request to create a workspace artifact."""
    name: str
    kind: ArtifactKind
    description: str
    filename: str
    language: str = "text"
    metadata: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True, slots=True)
class BuildResult:
    """Deterministic build result with content digest."""
    ok: bool
    name: str
    kind: str
    path: str | None
    sha256: str | None
    error: str | None = None

class CreationFabric:
    """Build validated artifacts inside a configured workspace."""
    def __init__(self, workspace: str | Path, generator: CodeGenerator | None = None, permission_engine: PermissionEngine | None = None) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self._generator = generator
        self._permission_engine = permission_engine

    def build(self, request: BuildRequest, *, source: str | None = None, approved: bool = False, authorization_token: str | None = None) -> BuildResult:
        """Create an artifact only after validation and explicit approval."""
        try:
            self._validate_request(request)
            if not approved:
                return BuildResult(False, request.name, request.kind, None, None, "creation requires approval")
            if self._permission_engine is not None and not self._permission_engine.verify(authorization_token or "", "creation.build"):
                return BuildResult(False, request.name, request.kind, None, None, "valid creation authorization token required")
            content = source if source is not None else self._generate(request)
            self._validate_content(request, content)
            destination = self._safe_destination(request.filename)
            self._atomic_write(destination, content)
            digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
            self._write_manifest(request, destination, digest)
            return BuildResult(True, request.name, request.kind, str(destination), digest)
        except (OSError, ValueError, SyntaxError, TypeError) as exc:
            return BuildResult(False, request.name, request.kind, None, None, str(exc))

    def build_tool(self, name: str, description: str, *, source: str | None = None, approved: bool = False, authorization_token: str | None = None) -> BuildResult:
        """Build a Python tool package entry."""
        return self.build(BuildRequest(name, "tool", description, f"tools/generated_{name}.py", "python"), source=source, approved=approved, authorization_token=authorization_token)

    def build_utility(self, name: str, description: str, *, source: str | None = None, approved: bool = False, authorization_token: str | None = None) -> BuildResult:
        """Build a Python utility package entry."""
        return self.build(BuildRequest(name, "utility", description, f"utilities/generated_{name}.py", "python"), source=source, approved=approved, authorization_token=authorization_token)

    def build_artifact(self, name: str, kind: str, description: str, *, source: str | None = None, approved: bool = False, authorization_token: str | None = None) -> BuildResult:
        """Build a text artifact such as markdown, JSON, HTML or a workflow definition."""
        ext = {"markdown": "md", "json": "json", "html": "html", "workflow": "json", "skill": "md", "report": "md"}.get(kind, "txt")
        return self.build(BuildRequest(name, kind, description, f"artifacts/{name}.{ext}", "text"), source=source, approved=approved, authorization_token=authorization_token)

    def _generate(self, request: BuildRequest) -> str:
        if self._generator is None:
            raise ValueError("no trusted generator configured")
        return self._generator(request.name, request.kind, request.description)

    def _validate_request(self, request: BuildRequest) -> None:
        if not _NAME.fullmatch(request.name):
            raise ValueError("invalid artifact name")
        if not request.description.strip() or len(request.description) > 20_000:
            raise ValueError("description must be non-empty and <= 20000 characters")
        if not request.filename or Path(request.filename).is_absolute():
            raise ValueError("filename must be relative")
        if ".." in Path(request.filename).parts:
            raise ValueError("path traversal is forbidden")
        if len(request.filename.encode("utf-8")) > 512:
            raise ValueError("filename is too long")
        if request.kind not in {"tool", "utility", "markdown", "json", "html", "workflow", "skill", "report", "text"}:
            raise ValueError("unsupported artifact kind")

    def _safe_destination(self, filename: str) -> Path:
        candidate = (self.workspace / filename).resolve()
        if os.path.commonpath((str(self.workspace), str(candidate))) != str(self.workspace):
            raise ValueError("workspace escape detected")
        candidate.parent.mkdir(parents=True, exist_ok=True)
        return candidate

    def _validate_content(self, request: BuildRequest, content: str) -> None:
        if not isinstance(content, str) or not content.strip():
            raise ValueError("generated content must be non-empty text")
        if len(content.encode("utf-8")) > _MAX_CONTENT_BYTES:
            raise ValueError("generated content exceeds the 2 MiB limit")
        if request.language == "python":
            tree = ast.parse(content, filename=request.filename)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    modules = [alias.name.split(".", 1)[0] for alias in node.names]
                elif isinstance(node, ast.ImportFrom):
                    modules = [str(node.module or "").split(".", 1)[0]]
                else:
                    modules = []
                if any(module in _FORBIDDEN_PYTHON_MODULES or module not in _SAFE_PYTHON_MODULES for module in modules):
                    raise ValueError("generated Python uses a forbidden or unapproved module")
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FORBIDDEN_PYTHON_CALLS:
                    raise ValueError("unsafe dynamic or host-interaction call is forbidden")
                if isinstance(node, ast.Attribute) and node.attr in {"system", "popen", "spawn", "run", "Popen"}:
                    raise ValueError("unsafe host-interaction API is forbidden")
        if request.kind in {"json", "workflow"}:
            json.loads(content)

    def _atomic_write(self, destination: Path, content: str) -> None:
        fd, tmp_name = tempfile.mkstemp(prefix=destination.name + ".", suffix=".tmp", dir=destination.parent)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, destination)
        finally:
            tmp.unlink(missing_ok=True)

    def _write_manifest(self, request: BuildRequest, destination: Path, digest: str) -> None:
        manifest = {
            "name": request.name,
            "kind": request.kind,
            "language": request.language,
            "path": str(destination.relative_to(self.workspace)).replace("\\", "/"),
            "sha256": digest,
            "metadata": dict(request.metadata),
        }
        self._atomic_write(destination.with_suffix(destination.suffix + ".manifest.json"), json.dumps(manifest, indent=2, sort_keys=True) + "\n")



"""Tamper-evident append-only journal for cognitive/memory lifecycle events."""
from __future__ import annotations

import hashlib
import hmac
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Mapping


class MemoryEventStore:
    """Namespace-aware SQLite journal with hash-chain integrity."""

    def __init__(self, path: str | Path, secret: bytes, *, max_event_bytes: int = 64_000) -> None:
        if not secret:
            raise ValueError("journal secret is required")
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self.max_event_bytes = max(1024, int(max_event_bytes))
        self._lock = threading.RLock()
        self._db = sqlite3.connect(self.path, timeout=10.0, check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA busy_timeout=10000")
        self._db.execute("CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, namespace TEXT NOT NULL, event_type TEXT NOT NULL, payload_json TEXT NOT NULL, created_at REAL NOT NULL, previous_hash TEXT NOT NULL, event_hash TEXT NOT NULL)")
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_events_namespace_seq ON events(namespace, seq)")
        self._db.commit()

    def _digest(self, namespace: str, event_type: str, payload: str, created_at: float, previous: str) -> str:
        body = json.dumps({"namespace": namespace, "event_type": event_type, "payload": payload, "created_at": round(created_at, 6), "previous_hash": previous}, sort_keys=True, separators=(",", ":")).encode()
        return hmac.new(self._secret, body, hashlib.sha256).hexdigest()

    def append(self, namespace: str, event_type: str, payload: Mapping[str, Any]) -> int:
        """Atomically append an event to one namespace chain."""
        ns, kind = str(namespace).strip(), str(event_type).strip()
        if not ns or not kind:
            raise ValueError("namespace and event_type are required")
        encoded = json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        if len(encoded.encode("utf-8")) > self.max_event_bytes:
            raise ValueError("event payload exceeds configured limit")
        with self._lock:
            row = self._db.execute("SELECT event_hash FROM events WHERE namespace=? ORDER BY seq DESC LIMIT 1", (ns,)).fetchone()
            previous = str(row[0]) if row else "GENESIS"
            now = time.time()
            digest = self._digest(ns, kind, encoded, now, previous)
            cursor = self._db.execute("INSERT INTO events(namespace,event_type,payload_json,created_at,previous_hash,event_hash) VALUES(?,?,?,?,?,?)", (ns, kind, encoded, now, previous, digest))
            self._db.commit()
            return int(cursor.lastrowid)

    def verify(self, namespace: str | None = None) -> bool:
        """Verify every selected namespace chain and HMAC."""
        query = "SELECT namespace,event_type,payload_json,created_at,previous_hash,event_hash FROM events"
        params: tuple[Any, ...] = ()
        if namespace is not None:
            query += " WHERE namespace=?"
            params = (str(namespace),)
        query += " ORDER BY namespace,seq"
        with self._lock:
            previous_by_ns: dict[str, str] = {}
            for row in self._db.execute(query, params):
                ns, kind, payload, created, previous, digest = map(str, row)
                expected_previous = previous_by_ns.get(ns, "GENESIS")
                if previous != expected_previous or not hmac.compare_digest(self._digest(ns, kind, payload, float(created), previous), digest):
                    return False
                previous_by_ns[ns] = digest
        return True

    def snapshot(self, namespace: str, *, limit: int = 100) -> list[dict[str, Any]]:
        """Return bounded JSON-safe recent events."""
        bounded = max(1, min(int(limit), 1000))
        with self._lock:
            rows = self._db.execute("SELECT seq,event_type,payload_json,created_at,event_hash FROM events WHERE namespace=? ORDER BY seq DESC LIMIT ?", (str(namespace), bounded)).fetchall()
        return [{"seq": int(r[0]), "event_type": str(r[1]), "payload": json.loads(str(r[2])), "created_at": float(r[3]), "event_hash": str(r[4])} for r in reversed(rows)]

    def close(self) -> None:
        """Flush and close the journal."""
        with self._lock:
            self._db.commit()
            self._db.close()

"""Provenance-addressed world state and contradiction tracking."""
from __future__ import annotations

import hashlib
import json
import math
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class WorldFact:
    """One scoped fact with provenance and uncertainty."""

    fact_id: str
    entity_id: str
    attribute: str
    value: Any
    observed_at: float
    confidence: float
    source: str
    provenance: Mapping[str, Any] = field(default_factory=dict)
    version: int = 1


@dataclass(frozen=True, slots=True)
class WorldConflict:
    """Detected disagreement between independently sourced facts."""

    entity_id: str
    attribute: str
    left_fact_id: str
    right_fact_id: str
    severity: float
    reason: str


@dataclass(frozen=True, slots=True)
class WorldStateSnapshot:
    """Immutable world-state projection."""

    generated_at: float
    facts: tuple[WorldFact, ...]
    conflicts: tuple[WorldConflict, ...]
    digest: str


class WorldStateStore:
    """Bounded in-memory world state with deterministic conflict detection."""

    def __init__(self, *, max_facts: int = 20_000, numeric_tolerance: float = 0.01) -> None:
        self._max_facts = max(1, min(int(max_facts), 1_000_000))
        self._numeric_tolerance = max(0.0, float(numeric_tolerance))
        self._facts: dict[tuple[str, str], list[WorldFact]] = {}
        self._lock = threading.RLock()

    def upsert(self, fact: WorldFact) -> None:
        """Validate and append a fact under one entity/attribute key."""
        entity, attribute, source = fact.entity_id.strip(), fact.attribute.strip(), fact.source.strip()
        if not entity or not attribute or not source or not fact.fact_id.strip():
            raise ValueError("world fact identity is required")
        if not math.isfinite(float(fact.observed_at)) or not 0.0 <= float(fact.confidence) <= 1.0:
            raise ValueError("world fact timestamp/confidence invalid")
        if len(json.dumps(fact.value, sort_keys=True, default=str).encode("utf-8")) > 100_000:
            raise ValueError("world fact payload is too large")
        with self._lock:
            key = (entity, attribute)
            bucket = self._facts.setdefault(key, [])
            bucket.append(fact)
            bucket.sort(key=lambda item: (item.observed_at, item.version, item.fact_id), reverse=True)
            total = sum(len(items) for items in self._facts.values())
            if total > self._max_facts:
                oldest_key = min(self._facts, key=lambda item: self._facts[item][-1].observed_at)
                self._facts[oldest_key].pop()
                if not self._facts[oldest_key]:
                    del self._facts[oldest_key]

    def latest(self) -> tuple[WorldFact, ...]:
        """Return the latest fact per entity/attribute."""
        with self._lock:
            return tuple(self._facts[key][0] for key in sorted(self._facts) if self._facts[key])

    def conflicts(self, *, threshold: float = 0.25) -> tuple[WorldConflict, ...]:
        """Detect contradictory high-confidence observations."""
        cutoff = max(0.0, min(1.0, float(threshold)))
        result: list[WorldConflict] = []
        with self._lock:
            buckets = tuple(self._facts.values())
        for bucket in buckets:
            if len(bucket) < 2:
                continue
            for index, left in enumerate(bucket):
                for right in bucket[index + 1 :]:
                    if left.source == right.source or left.confidence < cutoff or right.confidence < cutoff:
                        continue
                    disagreement = self._disagreement(left.value, right.value)
                    if disagreement > 0.0:
                        result.append(WorldConflict(left.entity_id, left.attribute, left.fact_id, right.fact_id, min(1.0, disagreement), "independent sources disagree"))
        result.sort(key=lambda item: (-item.severity, item.entity_id, item.attribute, item.left_fact_id, item.right_fact_id))
        return tuple(result[:1024])

    def snapshot(self) -> WorldStateSnapshot:
        """Build a deterministic, digest-addressed snapshot."""
        facts = self.latest()
        conflicts = self.conflicts()
        canonical = json.dumps({"facts": [self._serialize(fact) for fact in facts], "conflicts": [self._serialize(item) for item in conflicts]}, sort_keys=True, separators=(",", ":"), default=str).encode()
        return WorldStateSnapshot(time.time(), facts, conflicts, hashlib.sha256(canonical).hexdigest())

    @staticmethod
    def _serialize(value: Any) -> Any:
        if hasattr(value, "__dict__"):
            return value.__dict__
        if hasattr(value, "__slots__"):
            return {slot: getattr(value, slot) for slot in value.__slots__ if hasattr(value, slot)}
        return value

    def _disagreement(self, left: Any, right: Any) -> float:
        if isinstance(left, (int, float)) and isinstance(right, (int, float)) and math.isfinite(float(left)) and math.isfinite(float(right)):
            scale = max(abs(float(left)), abs(float(right)), 1.0)
            return 0.0 if abs(float(left) - float(right)) <= self._numeric_tolerance * scale else min(1.0, abs(float(left) - float(right)) / scale)
        return 0.0 if left == right else 1.0

    def query(self, entity_id: str, attribute: str) -> WorldFact | None:
        """Return the most recent scoped fact."""
        with self._lock:
            rows = self._facts.get((str(entity_id), str(attribute)), [])
            return rows[0] if rows else None

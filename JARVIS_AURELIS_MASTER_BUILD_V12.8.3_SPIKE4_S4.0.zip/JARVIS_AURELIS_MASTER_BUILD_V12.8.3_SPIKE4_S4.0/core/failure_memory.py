"""Memory of past failures for avoidance."""
from __future__ import annotations
from typing import Any, List


class FailureMemory:
    def __init__(self, max_entries: int = 1000):
        self.max_entries = max_entries
        self._entries: List[dict[str, Any]] = []

    def record(self, task: str, error: str) -> None:
        self._entries.append({"task": task, "error": error})
        if len(self._entries) > self.max_entries:
            self._entries.pop(0)

    def get_similar(self, task: str) -> List[dict[str, Any]]:
        return [e for e in self._entries if task.lower() in e["task"].lower()]



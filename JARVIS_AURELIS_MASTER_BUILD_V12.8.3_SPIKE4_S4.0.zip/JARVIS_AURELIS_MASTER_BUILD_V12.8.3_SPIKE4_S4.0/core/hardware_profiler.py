"""Hardware profiling with deterministic optional-NVML lifecycle."""
from __future__ import annotations
import logging
import os
from typing import Optional

logger = logging.getLogger("jarvis.hardware")


class HardwareProfiler:
    def __init__(self):
        self.cpu_count = os.cpu_count() or 1
        self.ram_total_gb = 8.0
        self.ram_free_gb = 4.0
        self.vram_total_gb: Optional[float] = None
        self.vram_free_gb: Optional[float] = None
        self.gpu_count = 0
        self.gpus: list[dict] = []
        self._nvml = None
        self._nvml_initialized = False
        self._shutdown = False
        self._probe()

    def _probe(self) -> None:
        try:
            import psutil
            mem = psutil.virtual_memory()
            self.ram_total_gb = mem.total / (1024 ** 3)
            self.ram_free_gb = mem.available / (1024 ** 3)
        except Exception as exc:
            logger.debug("psutil unavailable: %s", exc)
        try:
            import pynvml
            self._nvml = pynvml
            pynvml.nvmlInit()
            self._nvml_initialized = True
            count = int(pynvml.nvmlDeviceGetCount())
            self.gpu_count = max(0, count)
            for index in range(self.gpu_count):
                handle = pynvml.nvmlDeviceGetHandleByIndex(index)
                info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                self.gpus.append({
                    "index": index,
                    "total_gb": info.total / (1024 ** 3),
                    "free_gb": info.free / (1024 ** 3),
                })
            if self.gpus:
                # Preserve legacy GPU0 fields for callers that only understand one GPU.
                self.vram_total_gb = self.gpus[0]["total_gb"]
                self.vram_free_gb = self.gpus[0]["free_gb"]
        except Exception as exc:
            logger.debug("NVML unavailable: %s", exc)
            self.vram_total_gb = 0.0
            self.vram_free_gb = 0.0
            if self._nvml_initialized:
                self._safe_nvml_shutdown()

    def _safe_nvml_shutdown(self) -> None:
        if self._nvml is not None and self._nvml_initialized:
            try:
                self._nvml.nvmlShutdown()
            except Exception as exc:
                logger.debug("NVML shutdown failed: %s", exc)
            finally:
                self._nvml_initialized = False

    def shutdown(self) -> None:
        if self._shutdown:
            return
        self._shutdown = True
        self._safe_nvml_shutdown()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.shutdown()
        return False



"""Model Benchmark Lab — evaluation and comparison of model backends.

Provides structured benchmarking with result persistence and comparison.
"""
from __future__ import annotations

import inspect
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jarvis.benchmark")


@dataclass
class BenchmarkResult:
    """Result of one benchmark run."""
    suite_name: str
    backend_name: str
    latency_ms: float
    tokens_per_second: float
    success: bool
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "backend_name": self.backend_name,
            "latency_ms": self.latency_ms,
            "tokens_per_second": self.tokens_per_second,
            "success": self.success,
            "error": self.error,
            "metadata": self.metadata,
            "timestamp": self.timestamp,
        }


class ModelBenchmarkLab:
    """Benchmark lab for evaluating model backends."""

    def __init__(self, output_dir: str = "data/benchmarks") -> None:
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._suites: Dict[str, List[str]] = {}
        self._results: List[BenchmarkResult] = []
        self._load_existing()

    def _load_existing(self) -> None:
        results_file = self._output_dir / "results.jsonl"
        if results_file.exists():
            try:
                with open(results_file) as f:
                    for line in f:
                        item = json.loads(line)
                        result = BenchmarkResult(
                            suite_name=item["suite_name"],
                            backend_name=item["backend_name"],
                            latency_ms=item["latency_ms"],
                            tokens_per_second=item["tokens_per_second"],
                            success=item["success"],
                            error=item.get("error"),
                            metadata=item.get("metadata", {}),
                            timestamp=item.get("timestamp", time.time()),
                        )
                        self._results.append(result)
            except Exception as exc:
                logger.warning("failed_to_load_benchmarks", extra={"error": str(exc)})

    def _save(self) -> None:
        results_file = self._output_dir / "results.jsonl"
        try:
            with open(results_file, "w") as f:
                for result in self._results:
                    f.write(json.dumps(result.to_dict(), default=str) + "\n")
        except Exception as exc:
            logger.warning("failed_to_save_benchmarks", extra={"error": str(exc)})

    def define_suite(self, name: str, prompts: List[str]) -> None:
        """Define a benchmark suite with test prompts."""
        self._suites[name] = prompts
        logger.info("suite_defined", extra={"component_name": name, "prompts": len(prompts)})

    def run_suite(self, name: str, router: Optional[Any] = None) -> Dict[str, Any]:
        """Run a benchmark suite against available backends."""
        prompts = self._suites.get(name)
        if prompts is None:
            return {"ok": False, "error": f"Suite {name} not found"}

        if router is None:
            return {"ok": False, "error": "Router required for benchmarking"}

        backends = router.list_backends() if hasattr(router, "list_backends") else []
        if not backends:
            return {"ok": False, "error": "No backends available"}

        results = []
        for backend_info in backends:
            backend_name = backend_info.get("name", "unknown")
            for prompt in prompts:
                start = time.perf_counter()
                error: str | None = None
                try:
                    if hasattr(router, "generate"):
                        result = router.generate(prompt, backend_name=backend_name, stream=False, request_id=f"benchmark:{name}:{backend_name}")
                    elif hasattr(router, "chat"):
                        chat = router.chat
                        parameters = inspect.signature(chat).parameters
                        if "backend_name" in parameters:
                            result = chat(prompt, stream=False, backend_name=backend_name)
                        else:
                            result = chat(prompt, stream=False)
                    else:
                        raise TypeError("router exposes neither generate nor chat")
                    latency = (time.perf_counter() - start) * 1000
                    success = bool(self._value(result, "ok", True))
                    output_tokens = self._usage_count(result, ("completion_tokens", "output_tokens", "tokens_used"))
                    prompt_tokens = self._usage_count(result, ("prompt_tokens", "input_tokens"))
                except Exception as exc:
                    latency = (time.perf_counter() - start) * 1000
                    success = False
                    result = None
                    error = str(exc)
                    output_tokens = None
                    prompt_tokens = None

                benchmark = BenchmarkResult(
                    suite_name=name,
                    backend_name=backend_name,
                    latency_ms=latency,
                    tokens_per_second=(output_tokens / max(latency / 1000.0, 0.001)) if success and output_tokens is not None and output_tokens > 0 else 0.0,
                    success=success,
                    error=error,
                    metadata={"prompt_tokens": prompt_tokens, "completion_tokens": output_tokens,
                              "token_usage_status": "reported" if output_tokens is not None else "unavailable"},
                )
                self._results.append(benchmark)
                results.append(benchmark.to_dict())

        self._save()
        return {
            "ok": True,
            "suite": name,
            "backends_tested": len(backends),
            "prompts_tested": len(prompts),
            "results": results,
        }

    @staticmethod
    def _value(obj: Any, name: str, default: Any = None) -> Any:
        if isinstance(obj, dict):
            return obj.get(name, default)
        return getattr(obj, name, default)

    @classmethod
    def _usage_count(cls, result: Any, names: tuple[str, ...]) -> int | None:
        """Read bounded token usage from flat or common nested API shapes."""
        candidates = [result]
        for key in ("usage", "usage_metadata", "token_usage"):
            nested = cls._value(result, key, None)
            if nested is not None:
                candidates.append(nested)
        for candidate in candidates:
            for name in names:
                value = cls._value(candidate, name, None)
                if value is None or isinstance(value, bool):
                    continue
                try:
                    parsed = int(value)
                except (TypeError, ValueError, OverflowError):
                    continue
                if parsed >= 0:
                    return parsed
        return None

    def compare_backends(self, suite_name: str) -> Dict[str, Any]:
        """Compare backend performance for a suite."""
        suite_results = [r for r in self._results if r.suite_name == suite_name]
        if not suite_results:
            return {"ok": False, "error": f"No results for suite {suite_name}"}

        by_backend: Dict[str, List[BenchmarkResult]] = {}
        for r in suite_results:
            by_backend.setdefault(r.backend_name, []).append(r)

        comparison = {}
        for backend, results in by_backend.items():
            latencies = [r.latency_ms for r in results if r.success]
            successes = sum(1 for r in results if r.success)
            comparison[backend] = {
                "avg_latency_ms": sum(latencies) / max(len(latencies), 1),
                "success_rate": successes / len(results),
                "runs": len(results),
            }

        return {"ok": True, "suite": suite_name, "comparison": comparison}

    def get_stats(self) -> Dict[str, Any]:
        return {
            "suites": len(self._suites),
            "total_results": len(self._results),
            "suites_defined": list(self._suites.keys()),
        }



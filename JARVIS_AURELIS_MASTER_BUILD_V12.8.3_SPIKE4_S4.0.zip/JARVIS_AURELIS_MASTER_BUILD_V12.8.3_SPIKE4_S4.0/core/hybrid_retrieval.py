"""Hybrid lexical, semantic, graph-aware retrieval with deterministic reranking."""
from __future__ import annotations

import logging
import math
import threading

from native_runtime.vector_math import get_native_vector_math
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("jarvis.retrieval")

NATIVE_VECTOR_THRESHOLD = 256


@dataclass(frozen=True, slots=True)
class RetrievalCandidate:
    """Internal retrieval candidate before reranking."""
    id: str
    text: str
    lexical: float
    semantic: float
    graph: float = 0.0
    recency: float = 0.0
    importance: float = 0.0
    trust: float = 1.0
    vector: tuple[float, ...] | None = None

    @property
    def score(self) -> float:
        return (0.30 * self.semantic) + (0.25 * self.lexical) + (0.15 * self.graph) + (0.10 * self.recency) + (0.10 * self.importance) + (0.10 * self.trust)


class HybridRetriever:
    """Provider-neutral in-memory hybrid retriever."""

    def __init__(self, store: Any = None, graph: Any = None) -> None:
        self.store = store
        self.graph = graph
        self._index: dict[str, dict[str, Any]] = {}
        self.embedder: Any = None
        self._lock = threading.RLock()
        self._native_vector_math = get_native_vector_math()

    def set_embedder(self, embedder: Any) -> None:
        if embedder is None or not callable(getattr(embedder, "embed", None)):
            raise TypeError("embedder must provide embed(text)")
        self.embedder = embedder

    def index(self, doc_id: str, text: str, vector: list[float] | None = None, *, metadata: dict[str, Any] | None = None) -> None:
        clean_id = str(doc_id).strip()
        clean_text = str(text).strip()
        if not clean_id:
            raise ValueError("doc_id is required")
        if not clean_text:
            return
        with self._lock:
            self._index[clean_id] = {"text": clean_text, "vector": list(vector) if vector is not None else None, "metadata": dict(metadata or {})}

    def retrieve(self, query: str, top_k: int = 5, *, filters: Mapping[str, Any] | None = None, mmr_lambda: float = 0.72, owner: str | None = None, workspace: str | None = None, session_id: str | None = None) -> list[dict[str, Any]]:
        if top_k <= 0 or not str(query).strip():
            return []
        if not 0.0 <= mmr_lambda <= 1.0:
            raise ValueError("mmr_lambda must be between 0 and 1")
        q = " ".join(str(query).lower().split())
        words = [w for w in q.split() if w]
        qvec = None
        if self.embedder is not None:
            try:
                qvec = self.embedder.embed(query)
            except Exception:
                logger.exception("query_embedding_failed")
        candidates: list[RetrievalCandidate] = []
        with self._lock:
            rows = list(self._index.items())
        # Persistent memory is authoritative for previously indexed knowledge.
        # Keep the process-local index as a fast path for newly ingested material.
        if self.store is not None and qvec is not None:
            search_documents = getattr(self.store, "search_documents", None)
            if callable(search_documents):
                try:
                    try:
                        persistent = search_documents(
                            list(qvec), top_k=max(top_k * 4, 16),
                            owner=owner, workspace=workspace, session_id=session_id,
                        )
                    except TypeError:
                        if owner is not None or workspace is not None or session_id is not None:
                            logger.error("scoped_persistent_retrieval_unsupported; refusing unscoped fallback")
                            return []
                        persistent = search_documents(list(qvec), top_k=max(top_k * 4, 16))
                    for item in persistent:
                        doc_id = str(item.get("id", "")).strip()
                        if not doc_id:
                            continue
                        metadata = item.get("metadata", {})
                        if not isinstance(metadata, dict):
                            metadata = {}
                        if any(metadata.get(key) != expected for key, expected in dict(filters or {}).items()):
                            continue
                        distance = float(item.get("score", 0.0) or 0.0)
                        semantic = 1.0 / (1.0 + max(0.0, distance))
                        existing = next((r for r in rows if r[0] == doc_id), None)
                        vector = existing[1].get("vector") if existing else None
                        rows.append((doc_id, {
                            "text": str(item.get("text", "")),
                            "vector": vector,
                            "metadata": metadata,
                            "persistent_semantic": semantic,
                        }))
                except Exception:
                    logger.exception("persistent_retrieval_failed")
        wanted = dict(filters or {})
        deduped_rows = {doc_id: row for doc_id, row in rows}
        for doc_id, row in deduped_rows.items():
            text = str(row["text"])
            low = text.lower()
            lexical = sum(1 for w in words if w in low) / max(1, len(words))
            semantic = float(row.get("persistent_semantic", self._semantic(qvec, row.get("vector"))))
            meta = row.get("metadata", {})
            if any(meta.get(key) != expected for key, expected in wanted.items()):
                continue
            if owner is not None and meta.get("owner") not in {None, str(owner)}:
                continue
            if workspace is not None and meta.get("workspace") not in {None, str(workspace)}:
                continue
            if session_id is not None and meta.get("session_id") not in {None, str(session_id)}:
                continue
            recency = max(0.0, min(1.0, float(meta.get("recency", 0.0))))
            importance = float(meta.get("importance", 0.0))
            trust = max(0.0, min(1.0, float(meta.get("trust_score", 1.0))))
            importance = max(0.0, min(1.0, importance))
            graph = self._graph_score(doc_id, meta)
            row_vector = row.get("vector")
            vector = tuple(float(x) for x in row_vector) if row_vector is not None else None
            candidate = RetrievalCandidate(doc_id, text[:2000], lexical, semantic, graph, recency, importance, trust, vector)
            if candidate.score > 0:
                candidates.append(candidate)
        candidates.sort(key=lambda c: (-c.score, c.id))
        selected: list[RetrievalCandidate] = []
        remaining = candidates[: min(len(candidates), max(top_k * 4, top_k))]
        while remaining and len(selected) < top_k:
            scored = [
                (
                    mmr_lambda * c.score
                    - (1.0 - mmr_lambda) * max((self._semantic_similarity(c, prior) for prior in selected), default=0.0),
                    c,
                )
                for c in remaining
            ]
            best_utility = max(utility for utility, _ in scored)
            best = min((c for utility, c in scored if math.isclose(utility, best_utility, rel_tol=1e-12, abs_tol=1e-12)), key=lambda c: c.id)
            selected.append(best)
            remaining.remove(best)
        return [
            {"id": c.id, "text": c.text, "score": c.score, "semantic": c.semantic, "lexical": c.lexical, "graph": c.graph, "recency": c.recency, "importance": c.importance, "trust_score": c.trust}
            for c in selected
        ]

    @staticmethod
    def _semantic_similarity(a: RetrievalCandidate, b: RetrievalCandidate) -> float:
        """Measure candidate redundancy using embeddings when available, else token overlap."""
        if a.vector and b.vector and len(a.vector) == len(b.vector):
            native = get_native_vector_math()
            if native is not None and len(a.vector) >= NATIVE_VECTOR_THRESHOLD:
                try:
                    cosine = native.cosine(a.vector, b.vector)
                    return max(0.0, min(1.0, (cosine + 1.0) / 2.0))
                except (OSError, ValueError, RuntimeError):
                    logger.debug("native_vector_similarity_fallback", exc_info=True)
            dot = sum(x * y for x, y in zip(a.vector, b.vector))
            na = math.sqrt(sum(x * x for x in a.vector))
            nb = math.sqrt(sum(y * y for y in b.vector))
            if na and nb:
                return max(0.0, min(1.0, (dot / (na * nb) + 1.0) / 2.0))
        left = set(a.text.lower().split())
        right = set(b.text.lower().split())
        if not left or not right:
            return 0.0
        return len(left & right) / len(left | right)

    @staticmethod
    def _semantic(a: Any, b: Any) -> float:
        if not a or not b or len(a) != len(b):
            return 0.0
        native = get_native_vector_math()
        if native is not None and len(a) >= NATIVE_VECTOR_THRESHOLD:
            try:
                return max(0.0, (native.cosine(a, b) + 1.0) / 2.0)
            except (OSError, ValueError, RuntimeError):
                logger.debug("native_vector_semantic_fallback", exc_info=True)
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        return max(0.0, (dot / (na * nb) + 1.0) / 2.0) if na and nb else 0.0

    def _graph_score(self, doc_id: str, metadata: dict[str, Any]) -> float:
        if "graph_score" in metadata:
            return max(0.0, min(1.0, float(metadata["graph_score"])))
        scorer = getattr(self.graph, "score", None) if self.graph is not None else None
        if callable(scorer):
            try:
                return max(0.0, min(1.0, float(scorer(doc_id))))
            except Exception:
                logger.exception("graph_score_failed")
        return 0.0



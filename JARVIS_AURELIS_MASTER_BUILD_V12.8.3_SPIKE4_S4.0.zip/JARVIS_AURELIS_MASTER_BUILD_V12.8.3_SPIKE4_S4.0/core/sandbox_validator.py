"""Validates code before execution."""
from __future__ import annotations
import ast
import logging
from typing import Any, ClassVar

logger = logging.getLogger("jarvis.sandbox")


class SandboxValidator:
    FORBIDDEN_NAMES: ClassVar[frozenset[str]] = frozenset({"__import__", "eval", "exec", "compile", "open", "input"})

    def validate(self, code: str) -> dict[str, Any]:
        try:
            tree = ast.parse(code)
        except SyntaxError as exc:
            return {"ok": False, "error": f"Syntax error: {exc}"}
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in self.FORBIDDEN_NAMES:
                    return {"ok": False, "error": f"Forbidden call: {node.func.id}"}
            if isinstance(node, ast.Name) and node.id in self.FORBIDDEN_NAMES:
                return {"ok": False, "error": f"Forbidden name: {node.id}"}
        return {"ok": True, "ast_nodes": len(list(ast.walk(tree)))}



"""Cognitive state machine."""
from __future__ import annotations
from typing import Any


class CognitiveStateMachine:
    def __init__(self):
        self.state = "idle"
        self.context: dict[str, Any] = {}

    def transition(self, new_state: str) -> None:
        self.state = new_state

    def get_state(self) -> str:
        return self.state



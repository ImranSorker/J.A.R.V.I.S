"""Bounded, exact and high-precision mathematical computation for J.A.R.V.I.S.

The language model must never be treated as the numerical authority. This module
parses a deliberately small Python-like expression grammar into SymPy objects,
then performs exact or arbitrary-precision computations under explicit resource
bounds. It exposes symbolic algebra, calculus, linear algebra, statistics,
combinatorics, numerical roots, and common unit conversion.
"""
from __future__ import annotations

import ast
import math
import operator
import re
import statistics
from dataclasses import dataclass
from decimal import Decimal, localcontext
from typing import Any, Mapping, Sequence

import numpy as np
import sympy as sp


class CalculationError(ValueError):
    """Raised when a calculation is invalid, unsafe, or exceeds its budget."""


@dataclass(frozen=True, slots=True)
class CalculationLimits:
    """Hard bounds protecting the calculation service from pathological inputs."""

    max_expression_chars: int = 12_000
    max_matrix_elements: int = 10_000
    max_vector_elements: int = 100_000
    max_precision: int = 500
    max_symbol_count: int = 64
    max_polynomial_degree: int = 1_000


def _bounded_factorial(x: Any) -> Any:
    value = int(x)
    if value < 0 or value > 10_000:
        raise CalculationError("factorial argument exceeds the configured bound")
    return sp.factorial(value)


def _bounded_gamma(x: Any) -> Any:
    if getattr(x, "is_number", False) and x.is_real and x.is_positive:
        numeric = float(x)
        if numeric > 10_000:
            raise CalculationError("gamma argument exceeds the configured bound")
    return sp.gamma(x)


_SAFE_FUNCTIONS: dict[str, Any] = {
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
    "atan2": sp.atan2, "sinh": sp.sinh, "cosh": sp.cosh,
    "tanh": sp.tanh, "sqrt": sp.sqrt, "cbrt": lambda x: sp.real_root(x, 3),
    "log": sp.log, "ln": sp.log, "log10": lambda x: sp.log(x, 10),
    "exp": sp.exp, "abs": sp.Abs, "floor": sp.floor, "ceil": sp.ceiling,
    "factorial": _bounded_factorial, "gamma": _bounded_gamma,
    "erf": sp.erf, "erfc": sp.erfc,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
}
_SAFE_CONSTANTS: dict[str, Any] = {"pi": sp.pi, "E": sp.E, "e": sp.E, "I": sp.I, "oo": sp.oo}
_ALLOWED_NODES = (
    ast.Expression, ast.Constant, ast.Name, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub,
    ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.FloorDiv, ast.USub, ast.UAdd,
    ast.Call, ast.keyword, ast.Load, ast.Tuple,
)
_OPS: dict[type[ast.operator], Any] = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}


class _SafeExpressionParser:
    """Translate a small AST grammar into SymPy without eval/sympify execution."""

    def __init__(self, text: str, limits: CalculationLimits) -> None:
        normalized = str(text).strip().replace("^", "**")
        if not normalized or len(normalized) > limits.max_expression_chars:
            raise CalculationError("expression is empty or exceeds the configured size limit")
        try:
            tree = ast.parse(normalized, mode="eval")
        except SyntaxError as exc:
            raise CalculationError(f"invalid mathematical syntax: {exc.msg}") from exc
        nodes = list(ast.walk(tree))
        if len(nodes) > 2_000:
            raise CalculationError("expression AST exceeds the configured complexity limit")
        if any(not isinstance(node, _ALLOWED_NODES) for node in nodes):
            raise CalculationError("expression contains unsupported syntax")
        self.tree = tree
        self.limits = limits
        self.symbols: dict[str, sp.Symbol] = {}

    def parse(self) -> sp.Expr:
        value = self._node(self.tree.body)
        if not isinstance(value, sp.Basic):
            value = sp.sympify(value)
        if len(self.symbols) > self.limits.max_symbol_count:
            raise CalculationError("too many symbolic variables")
        return value

    def _node(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, (int, float, str)):
                raise CalculationError("only numeric constants are allowed")
            if isinstance(node.value, str):
                raise CalculationError("string literals are not allowed")
            return sp.Integer(node.value) if isinstance(node.value, int) else sp.Float(node.value)
        if isinstance(node, ast.Name):
            if node.id in _SAFE_CONSTANTS:
                return _SAFE_CONSTANTS[node.id]
            if node.id in _SAFE_FUNCTIONS:
                return _SAFE_FUNCTIONS[node.id]
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", node.id):
                raise CalculationError("invalid symbol name")
            return self.symbols.setdefault(node.id, sp.Symbol(node.id, real=True))
        if isinstance(node, ast.BinOp):
            func = _OPS.get(type(node.op))
            if func is None:
                raise CalculationError("operator is not supported")
            left, right = self._node(node.left), self._node(node.right)
            if isinstance(node.op, ast.Pow) and isinstance(right, sp.Integer) and abs(int(right)) > self.limits.max_polynomial_degree:
                raise CalculationError("power exceeds configured degree bound")
            return func(left, right)
        if isinstance(node, ast.UnaryOp):
            value = self._node(node.operand)
            if isinstance(node.op, ast.USub):
                return -value
            if isinstance(node.op, ast.UAdd):
                return +value
            raise CalculationError("unary operator is not supported")
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in _SAFE_FUNCTIONS:
                raise CalculationError("function is not permitted")
            if node.keywords:
                raise CalculationError("keyword arguments are not permitted")
            args = [self._node(arg) for arg in node.args]
            if not 1 <= len(args) <= 4:
                raise CalculationError("function arity is outside the allowed range")
            return _SAFE_FUNCTIONS[node.func.id](*args)
        raise CalculationError(f"unsupported expression node: {type(node).__name__}")


def _require_seq(value: Any, limit: int, name: str) -> list[float]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise CalculationError(f"{name} must be a numeric sequence")
    items = list(value)
    if len(items) > limit:
        raise CalculationError(f"{name} exceeds the configured element limit")
    out: list[float] = []
    for item in items:
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise CalculationError(f"{name} contains a non-numeric value")
        if not math.isfinite(float(item)):
            raise CalculationError(f"{name} contains a non-finite value")
        out.append(float(item))
    return out


class CalculationEngine:
    """High-integrity calculation service with bounded execution semantics."""

    def __init__(self, limits: CalculationLimits | None = None) -> None:
        self.limits = limits or CalculationLimits()

    def expression(self, expression: str, *, precision: int = 50, numeric: bool = False) -> dict[str, Any]:
        """Evaluate or simplify a safe symbolic expression."""
        p = self._precision(precision)
        expr = _SafeExpressionParser(expression, self.limits).parse()
        simplified = sp.simplify(expr)
        if numeric:
            value = sp.N(simplified, p)
            return {"ok": True, "kind": "numeric", "result": str(value), "exact": str(simplified), "precision": p, "symbols": sorted(str(x) for x in simplified.free_symbols)}
        return {"ok": True, "kind": "symbolic", "result": str(simplified), "latex": sp.latex(simplified), "symbols": sorted(str(x) for x in simplified.free_symbols), "precision": p}

    def derivative(self, expression: str, variable: str, *, order: int = 1) -> dict[str, Any]:
        """Compute an exact symbolic derivative."""
        expr, symbol = self._expr_var(expression, variable)
        n = self._small_positive(order, "order", 100)
        result = sp.simplify(sp.diff(expr, symbol, n))
        return {"ok": True, "kind": "derivative", "result": str(result), "latex": sp.latex(result), "variable": str(symbol), "order": n}

    def integral(self, expression: str, variable: str, *, lower: str | None = None, upper: str | None = None) -> dict[str, Any]:
        """Compute an exact or definite symbolic integral."""
        expr, symbol = self._expr_var(expression, variable)
        if lower is None and upper is None:
            result = sp.simplify(sp.integrate(expr, symbol))
        else:
            if lower is None or upper is None:
                raise CalculationError("both lower and upper bounds are required")
            lo = _SafeExpressionParser(lower, self.limits).parse()
            hi = _SafeExpressionParser(upper, self.limits).parse()
            result = sp.simplify(sp.integrate(expr, (symbol, lo, hi)))
        return {"ok": True, "kind": "integral", "result": str(result), "latex": sp.latex(result), "variable": str(symbol)}

    def solve(self, equation: str, variable: str) -> dict[str, Any]:
        """Solve one bounded symbolic equation for one variable."""
        symbol = self._symbol(variable)
        if "=" in equation:
            left, right = equation.split("=", 1)
            expr = _SafeExpressionParser(left, self.limits).parse() - _SafeExpressionParser(right, self.limits).parse()
        else:
            expr = _SafeExpressionParser(equation, self.limits).parse()
        solutions = sp.solve(expr, symbol)
        if len(solutions) > 1_000:
            raise CalculationError("solution set exceeds result bound")
        return {"ok": True, "kind": "solve", "variable": str(symbol), "solutions": [str(x) for x in solutions], "count": len(solutions)}

    def matrix(self, operation: str, matrix: Sequence[Sequence[Any]], *, rhs: Sequence[Any] | None = None) -> dict[str, Any]:
        """Perform bounded exact linear algebra."""
        data = [list(row) for row in matrix]
        if not data or any(not isinstance(row, list) or not row for row in data):
            raise CalculationError("matrix must be a non-empty rectangular sequence")
        width = len(data[0])
        if width == 0 or len(data) * width > self.limits.max_matrix_elements or any(len(row) != width for row in data):
            raise CalculationError("matrix dimensions exceed configured limits or are ragged")
        try:
            m = sp.Matrix(data)
        except Exception as exc:
            raise CalculationError(f"invalid matrix: {exc}") from exc
        op = str(operation).strip().lower()
        if op == "determinant":
            result: Any = sp.simplify(m.det())
        elif op == "inverse":
            result = m.inv()
        elif op == "transpose":
            result = m.T
        elif op == "rank":
            result = int(m.rank())
        elif op == "eigenvalues":
            result = {str(k): int(v) for k, v in m.eigenvals().items()}
        elif op == "trace":
            result = sp.simplify(m.trace())
        elif op in {"multiply", "matmul"}:
            if rhs is None:
                raise CalculationError("rhs matrix is required for multiplication")
            r = sp.Matrix([list(row) for row in rhs])
            if m.cols != r.rows or m.rows * r.cols + m.rows * m.cols > self.limits.max_matrix_elements:
                raise CalculationError("matrix multiplication dimensions exceed configured limits")
            result = m * r
        elif op == "solve":
            if rhs is None:
                raise CalculationError("rhs vector/matrix is required for solve")
            if len(rhs) != m.rows:
                raise CalculationError("rhs dimension does not match matrix")
            result = m.LUsolve(sp.Matrix(rhs))
        else:
            raise CalculationError("unsupported matrix operation")
        return {"ok": True, "kind": "matrix", "operation": op, "result": self._json_matrix(result)}

    def statistics(self, values: Sequence[Any]) -> dict[str, Any]:
        """Compute descriptive statistics deterministically."""
        data = _require_seq(values, self.limits.max_vector_elements, "values")
        if not data:
            raise CalculationError("values must not be empty")
        mean = statistics.fmean(data)
        median = statistics.median(data)
        variance = statistics.pvariance(data)
        stddev = math.sqrt(variance)
        quantiles = statistics.quantiles(data, n=4, method="inclusive") if len(data) >= 2 else [data[0]] * 3
        return {"ok": True, "kind": "statistics", "count": len(data), "sum": math.fsum(data), "mean": mean, "median": median, "min": min(data), "max": max(data), "variance_population": variance, "stddev_population": stddev, "quartiles": quantiles}

    def combinatorics(self, operation: str, n: int, r: int | None = None) -> dict[str, Any]:
        """Compute exact integer combinatorics with strict size guards."""
        ni = self._nonnegative_int(n, "n", 10_000)
        op = str(operation).lower()
        if op == "factorial":
            result = math.factorial(ni)
        elif op in {"permutation", "perm"}:
            if r is None:
                raise CalculationError("r is required")
            ri = self._nonnegative_int(r, "r", ni)
            result = math.perm(ni, ri)
        elif op in {"combination", "choose", "ncr"}:
            if r is None:
                raise CalculationError("r is required")
            ri = self._nonnegative_int(r, "r", ni)
            result = math.comb(ni, ri)
        elif op == "gcd":
            if r is None:
                raise CalculationError("r is required")
            result = math.gcd(ni, self._nonnegative_int(r, "r", 10_000))
        elif op == "lcm":
            if r is None:
                raise CalculationError("r is required")
            result = math.lcm(ni, self._nonnegative_int(r, "r", 10_000))
        else:
            raise CalculationError("unsupported combinatorics operation")
        return {"ok": True, "kind": "combinatorics", "operation": op, "result": str(result)}

    def solve_linear_numeric(self, matrix: Sequence[Sequence[Any]], rhs: Sequence[Any]) -> dict[str, Any]:
        """Solve a floating-point linear system with NumPy and report conditioning."""
        a = np.asarray(matrix, dtype=np.float64)
        b = np.asarray(rhs, dtype=np.float64)
        if a.ndim != 2 or b.ndim != 1 or a.shape[0] != a.shape[1] or a.shape[0] != b.shape[0]:
            raise CalculationError("matrix must be square and rhs must match its row count")
        if a.size > self.limits.max_matrix_elements:
            raise CalculationError("numeric matrix exceeds configured element limit")
        if not np.isfinite(a).all() or not np.isfinite(b).all():
            raise CalculationError("non-finite numeric input")
        cond = float(np.linalg.cond(a))
        if not math.isfinite(cond) or cond > 1e12:
            raise CalculationError("matrix is numerically ill-conditioned")
        x = np.linalg.solve(a, b)
        return {"ok": True, "kind": "numeric_linear_solve", "solution": x.tolist(), "condition_number": cond, "residual_norm": float(np.linalg.norm(a @ x - b))}

    def unit_convert(self, value: float, from_unit: str, to_unit: str) -> dict[str, Any]:
        """Convert common SI/imperial quantities without external lookup."""
        v = float(value)
        if not math.isfinite(v):
            raise CalculationError("value must be finite")
        units = {
            "m": ("length", 1.0), "km": ("length", 1000.0), "cm": ("length", 0.01), "mm": ("length", 0.001),
            "in": ("length", 0.0254), "ft": ("length", 0.3048), "yd": ("length", 0.9144), "mi": ("length", 1609.344),
            "s": ("time", 1.0), "ms": ("time", 0.001), "min": ("time", 60.0), "h": ("time", 3600.0),
            "kg": ("mass", 1.0), "g": ("mass", 0.001), "lb": ("mass", 0.45359237),
            "c": ("temperature", None), "f": ("temperature", None), "k": ("temperature", None),
            "pa": ("pressure", 1.0), "kpa": ("pressure", 1000.0), "bar": ("pressure", 100000.0), "psi": ("pressure", 6894.757293168),
        }
        a, b = str(from_unit).strip().lower(), str(to_unit).strip().lower()
        if a not in units or b not in units or units[a][0] != units[b][0]:
            raise CalculationError("incompatible or unsupported units")
        if units[a][0] == "temperature":
            kelvin = v + 273.15 if a == "c" else (v - 32.0) * 5.0 / 9.0 + 273.15 if a == "f" else v
            result = kelvin - 273.15 if b == "c" else (kelvin - 273.15) * 9.0 / 5.0 + 32.0 if b == "f" else kelvin
        else:
            result = v * float(units[a][1]) / float(units[b][1])
        return {"ok": True, "kind": "unit_conversion", "value": v, "from": a, "to": b, "result": result}

    def high_precision(self, expression: str, precision: int = 100) -> dict[str, Any]:
        """Evaluate a scalar expression at bounded arbitrary precision."""
        p = self._precision(precision)
        expr = _SafeExpressionParser(expression, self.limits).parse()
        with localcontext() as ctx:
            ctx.prec = p + 10
            value = sp.N(expr, p)
            decimal = Decimal(str(value))
        return {"ok": True, "kind": "high_precision", "result": str(decimal), "precision": p}

    def _expr_var(self, expression: str, variable: str) -> tuple[sp.Expr, sp.Symbol]:
        expr = _SafeExpressionParser(expression, self.limits).parse()
        symbol = self._symbol(variable)
        if symbol not in expr.free_symbols:
            expr = expr.subs({sp.Symbol(str(symbol), real=True): symbol})
        return expr, symbol

    @staticmethod
    def _symbol(value: str) -> sp.Symbol:
        name = str(value).strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", name):
            raise CalculationError("invalid variable name")
        return sp.Symbol(name, real=True)

    @staticmethod
    def _json_matrix(value: Any) -> Any:
        if isinstance(value, sp.MatrixBase):
            return [[str(value[r, c]) for c in range(value.cols)] for r in range(value.rows)]
        if isinstance(value, dict):
            return {str(k): str(v) for k, v in value.items()}
        return str(value)

    @staticmethod
    def _precision(value: int) -> int:
        p = int(value)
        if not 10 <= p <= 500:
            raise CalculationError("precision must be between 10 and 500")
        return p

    @staticmethod
    def _small_positive(value: int, name: str, maximum: int) -> int:
        n = int(value)
        if n < 1 or n > maximum:
            raise CalculationError(f"{name} must be between 1 and {maximum}")
        return n

    @staticmethod
    def _nonnegative_int(value: int, name: str, maximum: int) -> int:
        n = int(value)
        if n < 0 or n > maximum:
            raise CalculationError(f"{name} must be between 0 and {maximum}")
        return n


__all__ = ["CalculationEngine", "CalculationError", "CalculationLimits"]



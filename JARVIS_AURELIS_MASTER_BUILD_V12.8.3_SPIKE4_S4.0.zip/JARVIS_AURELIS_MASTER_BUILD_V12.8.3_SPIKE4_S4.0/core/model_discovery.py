"""Discovers models from various sources."""
from __future__ import annotations
from pathlib import Path
from typing import List
from core.types import ModelInfo


class ModelDiscovery:
    def __init__(self, dirs: list[str] = None):
        self.dirs = dirs or ["~/models", "data/models"]

    def scan(self) -> List[ModelInfo]:
        found = []
        for d in self.dirs:
            p = Path(d).expanduser()
            if p.exists():
                for ext in [".gguf", ".safetensors", ".bin", ".onnx"]:
                    for f in p.rglob(f"*{ext}"):
                        found.append(ModelInfo(name=f.stem, path=str(f), size_bytes=f.stat().st_size))
        return found



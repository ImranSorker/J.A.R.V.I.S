"""Bounded context assembly with provenance-aware memory and retrieval inputs."""
from __future__ import annotations

import logging
import re
import uuid
import inspect
from typing import Any

from core.contracts.intelligence import CognitiveContext, ContextItem

logger = logging.getLogger("jarvis.context")


class CompositeRetriever:
    """Deterministically merge multiple retrieval providers under one contract."""

    def __init__(self, *providers: Any) -> None:
        self.providers = tuple(provider for provider in providers if provider is not None)

    def retrieve(self, query: str, top_k: int = 8, **kwargs: Any) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        remaining = max(1, int(top_k))
        for provider in self.providers:
            if remaining <= 0:
                break
            retrieve = provider.retrieve
            parameters = inspect.signature(retrieve).parameters
            accepts_kwargs = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in parameters.values())
            call_kwargs = {name: value for name, value in kwargs.items() if accepts_kwargs or name in parameters}
            if "limit" in parameters or accepts_kwargs:
                call_kwargs["limit"] = remaining
            elif "top_k" in parameters:
                call_kwargs["top_k"] = remaining
            else:
                raise TypeError(f"retriever {type(provider).__name__} exposes neither limit nor top_k")
            rows = retrieve(query, **call_kwargs)
            if not rows:
                continue
            for row in rows:
                if not isinstance(row, dict):
                    row = dict(row)
                results.append(row)
                if len(results) >= top_k:
                    return results[:top_k]
            remaining = max(0, int(top_k) - len(results))
        return results[:top_k]


class ContextManager:
    """Assemble deterministic, bounded context from injected providers."""

    def __init__(self, memory: Any = None, retriever: Any = None, max_items: int = 24, event_bus: Any = None, owner: str = "jarvis", workspace: str = "default") -> None:
        self.memory = memory
        self.retriever = retriever
        self.max_items = max(1, int(max_items))
        self.event_bus = event_bus
        self.owner = str(owner).strip() or "jarvis"
        self.workspace = str(workspace).strip() or "default"

    def build(self, text: str, *, request_id: str | None = None, session_id: str = "default", budget_tokens: int = 4096, owner: str | None = None, workspace: str | None = None) -> CognitiveContext:
        """Collect memory and retrieval context under a hard item/token budget."""
        query = str(text).strip()
        if not query:
            raise ValueError("context query must not be empty")
        rid = request_id or uuid.uuid4().hex
        items: list[ContextItem] = []

        if self.memory is not None:
            try:
                if hasattr(self.memory, "query"):
                    history_items = self.memory.query(owner=owner or self.owner, workspace=workspace or self.workspace, session_id=session_id, limit=min(12, self.max_items))
                    for entry in history_items:
                        content = str(entry.content).strip()
                        if content:
                            items.append(ContextItem(entry.memory_id, f"memory:{entry.kind.value}", content, float(entry.confidence * entry.importance * entry.freshness), "trusted", {"source": entry.source}))
                else:
                    history = self.memory.get_history(session_id, limit=min(12, self.max_items))
                    for entry in history[-min(12, self.max_items):]:
                        content = str(entry.get("content", "")).strip()
                        if content:
                            items.append(ContextItem(str(entry.get("id", uuid.uuid4().hex)), "memory", content, 0.55, "trusted"))
            except Exception:
                logger.exception("context_memory_failed")

        if self.retriever is not None and len(items) < self.max_items:
            try:
                remaining = self.max_items - len(items)
                for item in self.retriever.retrieve(query, top_k=remaining, owner=owner or self.owner, workspace=workspace or self.workspace, session_id=session_id):
                    items.append(
                        ContextItem(str(item.get("id", uuid.uuid4().hex)), "retrieval", str(item.get("text", "")), float(item.get("score", 0.0)), str(item.get("trust_level", "untrusted")), dict(item))
                    )
            except Exception:
                logger.exception("context_retrieval_failed")

        # Deterministic lexical deduplication and hard budget.
        seen: set[str] = set()
        selected: list[ContextItem] = []
        approx_tokens = max(1, len(query) // 4)
        for item in sorted(items, key=lambda x: (-x.relevance, x.item_id)):
            key = re.sub(r"\s+", " ", item.text.strip().lower())
            if not key or key in seen:
                continue
            cost = max(1, len(item.text) // 4)
            if approx_tokens + cost > max(1, int(budget_tokens)):
                continue
            seen.add(key)
            selected.append(item)
            approx_tokens += cost
            if len(selected) >= self.max_items:
                break
        context = CognitiveContext(rid, tuple(selected), max(1, int(budget_tokens)))
        if self.event_bus is not None:
            try:
                self.event_bus.publish("context.assembled", {"request_id": rid, "items": len(selected)}, source="jarvis.context", correlation_id=rid)
            except Exception:
                logger.exception("context_event_failed")
        return context

    @staticmethod
    def render(context: CognitiveContext) -> str:
        """Render context as explicitly delimited reference data."""
        blocks = [f"[DATA source={item.source} trust={item.trust} relevance={item.relevance:.3f}]\n{item.text}\n[/DATA]" for item in context.items]
        return "\n\n".join(blocks)



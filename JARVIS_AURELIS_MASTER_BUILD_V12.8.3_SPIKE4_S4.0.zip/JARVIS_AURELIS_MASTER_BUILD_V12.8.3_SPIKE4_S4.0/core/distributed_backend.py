"""Authenticated lightweight distributed worker registry and health coordinator.

This module implements coordination state only. When an authentication token is
configured, registration, heartbeat, and unregistration require a constant-time
credential match.
"""
from __future__ import annotations

import hmac
import secrets
import threading
import time
from typing import Any, Dict


class DistributedBackend:
    """Thread-safe worker registry with optional fail-closed authentication."""

    def __init__(self, enabled: bool = False, coordinator_port: int = 28766,
                 auth_token: str = "", worker_ttl: float = 30.0):
        self.enabled = bool(enabled)
        self.coordinator_port = int(coordinator_port)
        self.auth_token = str(auth_token or "")
        self.worker_ttl = max(1.0, float(worker_ttl))
        self._workers: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._shutdown = False

    def _authorized(self, token: str | None) -> bool:
        """Return whether a presented credential satisfies the configured policy."""
        if not self.auth_token:
            return True
        presented = str(token or "")
        return bool(presented) and hmac.compare_digest(presented, self.auth_token)

    def register_worker(self, worker_id: str, metadata: dict[str, Any] | None = None, *, auth_token: str | None = None) -> dict[str, Any]:
        if not self.enabled or self._shutdown:
            return {"ok": False, "error": "distributed backend disabled"}
        if not self._authorized(auth_token):
            return {"ok": False, "error": "authentication failed"}
        wid = str(worker_id).strip()
        if not wid:
            return {"ok": False, "error": "worker_id required"}
        with self._lock:
            self._workers[wid] = {"worker_id": wid, "metadata": dict(metadata or {}), "last_heartbeat": time.time(), "status": "online"}
        return {"ok": True, "worker_id": wid}

    def heartbeat(self, worker_id: str, metadata: dict[str, Any] | None = None, *, auth_token: str | None = None) -> dict[str, Any]:
        if not self._authorized(auth_token):
            return {"ok": False, "error": "authentication failed"}
        with self._lock:
            worker = self._workers.get(str(worker_id))
            if not worker:
                return {"ok": False, "error": "worker not registered"}
            worker["last_heartbeat"] = time.time()
            worker["status"] = "online"
            if metadata:
                worker["metadata"].update(metadata)
            return {"ok": True}

    def unregister_worker(self, worker_id: str, *, auth_token: str | None = None) -> bool:
        if not self._authorized(auth_token):
            return False
        with self._lock:
            return self._workers.pop(str(worker_id), None) is not None

    def prune_stale(self) -> int:
        cutoff = time.time() - self.worker_ttl
        with self._lock:
            stale = [wid for wid, worker in self._workers.items() if worker["last_heartbeat"] < cutoff]
            for wid in stale:
                self._workers.pop(wid, None)
            return len(stale)

    def get_workers(self) -> list[dict[str, Any]]:
        self.prune_stale()
        with self._lock:
            return [dict(w) for w in self._workers.values()]

    def get_cluster_stats(self) -> dict[str, Any]:
        workers = self.get_workers()
        return {
            "enabled": self.enabled,
            "authenticated": bool(self.auth_token),
            "workers": len(workers),
            "online_workers": sum(w.get("status") == "online" for w in workers),
            "coordinator_port": self.coordinator_port,
        }

    def shutdown(self) -> None:
        with self._lock:
            self._shutdown = True
            self._workers.clear()



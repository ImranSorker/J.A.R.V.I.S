"""Prompt injection and delimiter defense for JARVIS.

Treats all externally sourced or user-provided content as untrusted data.
Detects and neutralizes attempts to override system instructions, confuse
role boundaries, or inject executable directives into the prompt pipeline.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import ClassVar, List, Tuple


@dataclass(frozen=True)
class PromptThreat:
    """One detected threat with category, matched text, and position."""

    category: str
    pattern: str
    position: int


class PromptSanitizer:
    """Detect and neutralize prompt injection attempts.

    Defense layers:
      1. Length bounding (anti-DoS)
      2. Delimiter flood neutralization
      3. Instruction override detection
      4. Role confusion detection
      5. Output format injection detection
      6. Encoding obfuscation detection
    """

    MAX_PROMPT_LENGTH: int = 100_000
    MAX_CONSECUTIVE_NEWLINES: int = 10

    # Patterns that attempt to override system instructions or confuse roles.
    _INJECTION_PATTERNS: ClassVar[List[Tuple[str, re.Pattern]]] = [
        (
            "delimiter_flood",
            re.compile(r"[<\[\{\|]{4,}"),
        ),
        (
            "instruction_override",
            re.compile(
                r"(?i)\b(ignore\s+(previous|above|earlier|all)|override\s+instructions|"
                r"new\s+instructions|disregard\s+(prior|earlier|all)|"
                r"forget\s+(previous|everything)|start\s+over|"
                r"you\s+must\s+(now\s+)?ignore|do\s+not\s+follow)\b"
            ),
        ),
        (
            "role_confusion",
            re.compile(
                r"(?i)(^|\n)\s*(system|assistant|user|developer)\s*[:\-]\s*"
            ),
        ),
        (
            "output_format_injection",
            re.compile(
                r"(?i)\b(output\s+only|respond\s+with\s+(code|json|xml|python)|"
                r"print\s+.*\s+then\s+execute|execute\s+the\s+following|"
                r"run\s+this\s+code|eval\s*\()"
            ),
        ),
        (
            "encoding_obfuscation",
            re.compile(
                r"(\\x[0-9a-fA-F]{2}|&#\d+;|base64\s*\(|\\u[0-9a-fA-F]{4}|"
                r"%[0-9a-fA-F]{2}|0x[0-9a-fA-F]+)"
            ),
        ),
        (
            "jailbreak_payload",
            re.compile(
                r"(?i)(DAN|jailbreak|mode\s*:\s*developer|"
                r"developer\s+mode\s+enabled|"
                r"you\s+are\s+(not\s+)?(restricted|limited|bound)|"
                r"no\s+ethical\s+constraints|"
                r"hypothetical\s+scenario\s*:\s*you\s+are\s+unfiltered)"
            ),
        ),
    ]

    def analyze(self, prompt: str) -> List[PromptThreat]:
        """Return detected threats without modifying input.

        Args:
            prompt: Raw prompt text to analyze.

        Returns:
            List of detected threats. Empty list means no threats detected.
        """
        threats: List[PromptThreat] = []
        if not isinstance(prompt, str):
            threats.append(PromptThreat("type_error", f"type={type(prompt).__name__}", 0))
            return threats

        normalized = unicodedata.normalize("NFKC", prompt)
        normalized = re.sub(r"[\u200b-\u200f\u2060\ufeff]", "", normalized)
        if len(normalized) > self.MAX_PROMPT_LENGTH:
            threats.append(
                PromptThreat("length_bomb", "length_budget", 0)
            )

        for category, pattern in self._INJECTION_PATTERNS:
            for match in pattern.finditer(normalized):
                threats.append(
                    PromptThreat(category, "pattern_match", match.start())
                )
        tokens=set(re.findall(r"[a-z0-9]+", normalized.lower()))
        actions={"ignore","disregard","bypass","override","reveal","dump","leak","execute","run","disable","remove","circumvent","sidestep"}
        targets={"system","developer","instructions","instruction","rules","guidelines","safety","policy","prompt","filters","restrictions"}
        if len(tokens & actions)>=2 and tokens & targets:
            threats.append(PromptThreat("semantic_instruction_attack", "semantic", 0))

        # Detect excessive newlines (structure bomb)
        if normalized.count("\n") > self.MAX_CONSECUTIVE_NEWLINES * 10:
            threats.append(PromptThreat("structure_bomb", "excessive_newlines", 0))

        return threats

    def sanitize(self, prompt: str) -> Tuple[str, List[PromptThreat]]:
        """Neutralize threats and return cleaned prompt.

        Sanitization rules:
          - Truncate to MAX_PROMPT_LENGTH
          - Replace delimiter floods with safe ellipsis
          - Prefix role markers with neutralizing text
          - Strip encoding obfuscation patterns

        Args:
            prompt: Raw prompt text.

        Returns:
            Tuple of (cleaned_prompt, detected_threats).
            The cleaned prompt is safe to concatenate into system/user messages.
        """
        threats = self.analyze(prompt)
        cleaned = unicodedata.normalize("NFKC", prompt)
        cleaned = re.sub(r"[\u200b-\u200f\u2060\ufeff]", "", cleaned)

        # Neutralize delimiter floods
        cleaned = re.sub(r"[<\[\{\|]{4,}", "...", cleaned)

        # Prefix role markers to prevent confusion in concatenated prompts
        def _neutralize_role(match: re.Match) -> str:
            return f"[neutralized-role-{match.group(2).strip().lower()}]: "

        cleaned = re.sub(
            r"(?i)(^|\n)\s*(system|assistant|user|developer)\s*[:\-]\s*",
            _neutralize_role,
            cleaned,
        )

        # Strip common encoding obfuscation
        cleaned = re.sub(r"\\x[0-9a-fA-F]{2}", "", cleaned)
        cleaned = re.sub(r"\\u[0-9a-fA-F]{4}", "", cleaned)

        # Truncate if too long
        if len(cleaned) > self.MAX_PROMPT_LENGTH:
            cleaned = cleaned[: self.MAX_PROMPT_LENGTH] + "\n...[truncated]"

        return cleaned, threats

    def is_safe(self, prompt: str) -> bool:
        """Quick check: return True only if no threats detected."""
        return not self.analyze(prompt)



"""P2-X Provenance & Lineage Graph for J.A.R.V.I.S. 12.8.3.

Canonical, append-only, tenant-scoped provenance index. P2-X observes and
indexes already-signed artifacts/events; it never mutates source artifacts.
"""
from __future__ import annotations

import base64, hashlib, hmac, json, re, sqlite3, threading, uuid
from contextlib import contextmanager
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

VERSION="1.0.0"; PUBLIC_VERSION="12.8.3"; KERNEL_VERSION="12.8.0"
NODE_KINDS=tuple('''agent_genome agent_package agent_deployment agent_snapshot certification attestation skill tool composite_tool workflow prompt_program model_profile model_adapter plan plan_step execution accounting_record allocation_decision memory_item failure_record diagnosis hypothesis remediation_proposal learning_trigger learning_candidate gate_record experiment selection_decision world_entity world_state_transition simulation_universe simulation_outcome team delegation_contract agent_message review_record challenge_record verification_record research_artifact research_source research_claim security_profile revocation_record policy_record resource_request operator_identity external_artifact event baseline detector benchmark evaluation_profile trust_tier_rule'''.split())
EDGE_KINDS=tuple('''derived_from supersedes signed_by certified_by attested_by deployed_as rolled_back_to executed_as produced_by consumed references depends_on composed_of part_of caused_by correlated_with motivated_by evidence_for contradicts verifies challenges reviewed_by delegated_to replied_to shared_with billed_to allocated_by attributed_to revoked_by affected_by trained_on produced_by_operator queried_by same_as replaces alias_of'''.split())
CONFIDENCE=("signed","derived","inferred","declared","contested")
VERIFICATION=("verified","unverified","stale","revoked","tampered")
QUERY_KINDS=tuple('''lineage_of descendants_of ancestors_of path_between impact_of evidence_chain_for causal_chain_for provenance_of attribution_of contradiction_graph security_lineage cost_lineage execution_lineage operator_lineage comparison_lineage'''.split())
NON_STRUCTURAL_CYCLE_EDGES=frozenset({'references','correlated_with','same_as','shared_with','queried_by'})

class ProvenanceError(RuntimeError): pass
class SchemaError(ProvenanceError): pass
class SignatureError(ProvenanceError): pass
class TenantIsolationError(ProvenanceError): pass
class ArtifactVerificationError(ProvenanceError): pass
class CycleDetected(ProvenanceError): pass
class DanglingEdge(ProvenanceError): pass
class ReplayDivergence(ProvenanceError): pass
class QueryError(ProvenanceError): pass


def utc_now()->str: return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def sha_obj(value: Mapping[str,Any])->str: return hashlib.sha256(canonical_bytes(value)).hexdigest()
def uuid_from_hash(digest:str)->str:
    raw=bytearray(bytes.fromhex(digest)[:16]); raw[6]=(raw[6]&0x0f)|0x50; raw[8]=(raw[8]&0x3f)|0x80; return str(uuid.UUID(bytes=bytes(raw)))
def sign_doc(body:Mapping[str,Any], key:Ed25519PrivateKey)->dict[str,Any]:
    x=dict(body); x.pop('signature',None); x.pop('integrity_hash',None); digest=sha_obj(x); x['integrity_hash']=digest; x['signature']=base64.b64encode(key.sign(canonical_bytes(x))).decode(); return x
def verify_doc(doc:Mapping[str,Any], key:Ed25519PublicKey)->None:
    sig=str(doc.get('signature','')); integrity=str(doc.get('integrity_hash',''))
    if not sig or not integrity: raise SignatureError('signature and integrity_hash are required')
    x=dict(doc); x.pop('signature',None); x.pop('integrity_hash',None)
    if not hmac.compare_digest(integrity,sha_obj(x)): raise SignatureError('integrity hash mismatch')
    try: key.verify(base64.b64decode(sig), canonical_bytes({**x,'integrity_hash':integrity}))
    except (InvalidSignature,ValueError) as exc: raise SignatureError('signature verification failed') from exc

class ArtifactVerifier(Protocol):
    def __call__(self, artifact_ref:Mapping[str,Any])->bool: ...
class PublicKeyResolver(Protocol):
    def __call__(self, principal:str, key_id:str)->bytes|Ed25519PublicKey|None: ...

@dataclass(frozen=True,slots=True)
class ProvenanceNode:
    node_id:str; node_kind:str; artifact_ref:dict[str,Any]; canonical_body_hash:str; content_addressed_ref:str
    source_event_ref:str|None; source_subsystem:str; indexed_at:str; verification:str; verification_method:str
    verification_ref:str|None; parent_node_ids:tuple[str,...]; child_node_ids:tuple[str,...]
    supersedes:str|None; superseded_by:str|None; signature:str; integrity_hash:str
    def body(self)->dict[str,Any]: return asdict(self)

@dataclass(frozen=True,slots=True)
class ProvenanceEdge:
    edge_id:str; edge_kind:str; confidence:str; from_node_id:str; to_node_id:str; producer_ref:dict[str,str]
    producer_kind:str; derivation_rule_ref:str|None; derivation_rule_version:str|None
    derivation_evidence_refs:tuple[str,...]; source_event_ref:str; source_subsystem:str; verification:str
    verification_ref:str|None; emitted_at:str; indexed_at:str; supersedes:str|None; superseded_by:str|None
    revoked_by:str|None; signature:str; integrity_hash:str
    def body(self)->dict[str,Any]: return asdict(self)

@dataclass(frozen=True,slots=True)
class GraphQuery:
    query_id:str; query_kind:str; tenant_id:str; subject_node_id:str|None=None; subject_artifact_ref:dict[str,Any]|None=None
    target_node_id:str|None=None; edge_kinds:tuple[str,...]|None=None; node_kinds:tuple[str,...]|None=None
    confidence_min:str|None=None; verification_required:bool=True; time_window:dict[str,str]|None=None
    max_results:int=1000; max_depth:int=20; include_derived:bool=True; include_contested:bool=True
    requested_by:dict[str,str]|None=None; requested_at:str=''; signature:str=''
    def unsigned(self)->dict[str,Any]:
        d=asdict(self); d.pop('signature',None); return d

@dataclass(frozen=True,slots=True)
class DerivationRule:
    rule_id:str; rule_version:str; description:str; from_edge_kinds:tuple[str,...]; to_edge_kind:str; method:str
    preconditions:tuple[str,...]; evidence_requirements:tuple[str,...]; determinism:str; signed_by:dict[str,str]
    integrity_hash:str; signature:str
    def unsigned(self)->dict[str,Any]: d=asdict(self); d.pop('signature',None); return d

class ProvenanceStore:
    """Durable SQLite store with tenant chain tags and immutable records."""
    def __init__(self, path:str|Path, secret:bytes):
        if len(secret)<32: raise ValueError('storage secret must be at least 32 bytes')
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self.secret=bytes(secret); self.lock=threading.RLock()
        self.db=sqlite3.connect(str(self.path),check_same_thread=False); self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL'); self.db.execute('PRAGMA busy_timeout=10000')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS nodes(tenant_id TEXT NOT NULL,node_id TEXT PRIMARY KEY,doc_json TEXT NOT NULL,record_hash TEXT NOT NULL,prev_hash TEXT NOT NULL,tag TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS edges(tenant_id TEXT NOT NULL,edge_id TEXT PRIMARY KEY,doc_json TEXT NOT NULL,record_hash TEXT NOT NULL,prev_hash TEXT NOT NULL,tag TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(tenant_id TEXT NOT NULL,event_id TEXT PRIMARY KEY,event_json TEXT NOT NULL,event_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS rules(rule_id TEXT NOT NULL,rule_version TEXT NOT NULL,doc_json TEXT NOT NULL,PRIMARY KEY(rule_id,rule_version));
        CREATE TABLE IF NOT EXISTS pending(from_ref TEXT,to_ref TEXT,kind TEXT,tenant_id TEXT,source_event_ref TEXT,producer_json TEXT,emitted_at TEXT,payload_json TEXT,PRIMARY KEY(from_ref,to_ref,kind,tenant_id));
        CREATE TABLE IF NOT EXISTS snapshots(snapshot_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,content BLOB NOT NULL,state_hash TEXT NOT NULL,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS results(result_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,doc_json TEXT NOT NULL);
        '''); self.db.commit()
    def close(self): self.db.close()
    @contextmanager
    def write_transaction(self):
        """Serialize a complete provenance write across threads and connections."""
        with self.lock:
            if self.db.in_transaction:
                yield
                return
            self.db.execute('BEGIN IMMEDIATE')
            try:
                yield
            except BaseException:
                self.db.rollback()
                raise
            else:
                self.db.commit()
    def _tag(self,kind,tenant,record_id,doc_json,prev): return hmac.new(self.secret,f'{kind}|{tenant}|{record_id}|{prev}|{doc_json}'.encode(),hashlib.sha256).hexdigest()
    def _prev(self,kind,tenant):
        row=self.db.execute(f'SELECT record_hash FROM {kind}s WHERE tenant_id=? ORDER BY rowid DESC LIMIT 1',(tenant,)).fetchone(); return str(row[0]) if row else '0'*64
    def put_node(self,node:Mapping[str,Any],tenant:str):
        doc=canonical_json(dict(node)).decode(); rid=str(node['node_id']); rh=hashlib.sha256(doc.encode()).hexdigest()
        with self.lock, self.write_transaction():
            prev=self._prev('node',tenant); tag=self._tag('node',tenant,rid,doc,prev)
            self.db.execute('INSERT OR IGNORE INTO nodes VALUES(?,?,?,?,?,?)',(tenant,rid,doc,rh,prev,tag))
    def put_edge(self,edge:Mapping[str,Any],tenant:str):
        doc=canonical_json(dict(edge)).decode(); rid=str(edge['edge_id']); rh=hashlib.sha256(doc.encode()).hexdigest()
        with self.lock, self.write_transaction():
            prev=self._prev('edge',tenant); tag=self._tag('edge',tenant,rid,doc,prev)
            self.db.execute('INSERT OR IGNORE INTO edges VALUES(?,?,?,?,?,?)',(tenant,rid,doc,rh,prev,tag))
    def get_node(self,node_id,tenant):
        row=self.db.execute('SELECT doc_json,tag,prev_hash,record_hash FROM nodes WHERE node_id=? AND tenant_id=?',(node_id,tenant)).fetchone();
        if not row: return None
        self._verify_row('node',tenant,node_id,row); return json.loads(row['doc_json'])
    def get_edge(self,edge_id,tenant):
        row=self.db.execute('SELECT doc_json,tag,prev_hash,record_hash FROM edges WHERE edge_id=? AND tenant_id=?',(edge_id,tenant)).fetchone();
        if not row: return None
        self._verify_row('edge',tenant,edge_id,row); return json.loads(row['doc_json'])
    def _verify_row(self,kind,tenant,rid,row):
        expected=hashlib.sha256(str(row['doc_json']).encode()).hexdigest();
        if expected!=row['record_hash'] or not hmac.compare_digest(self._tag(kind,tenant,rid,str(row['doc_json']),str(row['prev_hash'])),str(row['tag'])): raise SignatureError('graph store corruption detected')
    def all_nodes(self,tenant):
        rows=self.db.execute('SELECT node_id,doc_json,tag,prev_hash,record_hash FROM nodes WHERE tenant_id=? ORDER BY node_id',(tenant,)); out=[]
        for r in rows: self._verify_row('node',tenant,r['node_id'],r); out.append(json.loads(r['doc_json']))
        return out
    def all_edges(self,tenant):
        rows=self.db.execute('SELECT edge_id,doc_json,tag,prev_hash,record_hash FROM edges WHERE tenant_id=? ORDER BY edge_id',(tenant,)); out=[]
        for r in rows: self._verify_row('edge',tenant,r['edge_id'],r); out.append(json.loads(r['doc_json']))
        return out
    def add_event(self,tenant,event):
        raw=canonical_json(event); h=hashlib.sha256(raw).hexdigest()
        with self.lock:
            started=not self.db.in_transaction
            try:
                self.db.execute('INSERT OR IGNORE INTO events VALUES(?,?,?,?)',(tenant,str(event['event_id']),raw.decode(),h))
                if started: self.db.commit()
            except BaseException:
                if started: self.db.rollback()
                raise
    def events(self,tenant): return [json.loads(r[0]) for r in self.db.execute('SELECT event_json FROM events WHERE tenant_id=? ORDER BY event_id',(tenant,))]
    def chain_verify(self,tenant):
        for kind in ('node','edge'):
            id_col='node_id' if kind=='node' else 'edge_id'
            rows=self.db.execute(f'SELECT {id_col} AS rid,doc_json,tag,prev_hash,record_hash FROM {kind}s WHERE tenant_id=? ORDER BY rowid',(tenant,)); prev='0'*64; count=0
            for r in rows:
                rid=r['rid']; doc=r['doc_json']; expected=hashlib.sha256(doc.encode()).hexdigest()
                if r['prev_hash']!=prev or r['record_hash']!=expected or not hmac.compare_digest(self._tag(kind,tenant,rid,doc,r['prev_hash']),r['tag']): return False,count,f'{kind}:{rid}'
                prev=expected; count+=1
        return True,count,None

class ProvenanceGraph:
    def __init__(self, root:str|Path, *, tenant_id:str='default', signing_key:Ed25519PrivateKey|None=None, storage_secret:bytes|None=None,
                 artifact_verifier:ArtifactVerifier|None=None, public_key_resolver:PublicKeyResolver|None=None, event_fabric:Any|None=None):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.tenant_id=str(tenant_id); self.signing_key=signing_key or Ed25519PrivateKey.generate(); self.key_id='p2-x'; self.public_key=self.signing_key.public_key();
        self.storage=ProvenanceStore(self.root/'provenance.sqlite',storage_secret or hashlib.sha256(b'JARVIS-P2-X-'+self.tenant_id.encode()).digest()); self.artifact_verifier=artifact_verifier; self.public_key_resolver=public_key_resolver; self.events=event_fabric; self.lock=threading.RLock()
        self._schemas={}
        for fn in ['provenance_node_v1.schema.json','provenance_edge_v1.schema.json','graph_query_v1.schema.json','graph_query_result_v1.schema.json','derivation_rule_v1.schema.json']:
            p=Path(__file__).resolve().parent/'schemas'/fn
            if p.exists(): self._schemas[fn]=json.loads(p.read_text())
    def close(self): self.storage.close()
    def _validate(self,doc,fn):
        schema=self._schemas.get(fn)
        if schema:
            try: SchemaValidator(max_errors=8).validate_or_raise(json.loads(canonical_json(doc).decode()),schema)
            except Exception as exc: raise SchemaError(str(exc)) from exc
    def _emit(self,name,payload,tenant,correlation=None,causation=None):
        if self.events is None:return
        try:self.events.publish(f'Provenance.{name}',dict(payload),source='p2x.provenance_graph',correlation_id=correlation or tenant,causation_id=causation)
        except TypeError:self.events.publish(f'Provenance.{name}',dict(payload))
    def _event_dict(self,event):
        if hasattr(event,'to_dict'): return event.to_dict()
        return dict(event)
    def _verify_event(self,event:Mapping[str,Any]):
        if not event.get('event_id') or not event.get('tenant_id'): raise ArtifactVerificationError('event_id and tenant_id required')
        if not event.get('signature'): raise SignatureError('unsigned event refused')
        if not self.public_key_resolver: raise SignatureError('event public-key resolver is required')
        try:
            from core.event_fabric import EventEnvelope
            env=EventEnvelope.from_dict(event)
            if not env.verify_integrity(): raise SignatureError('event integrity verification failed')
            p=event.get('produced_by') or {}; key=self.public_key_resolver(str(p.get('id','')),None,str(p.get('kind','')))
            if key is None or not env.verify_signature(key): raise SignatureError('event producer signature verification failed')
        except ImportError as exc: raise SignatureError('event verification dependency unavailable') from exc
    def _verify_artifact(self,ref:Mapping[str,Any]):
        tenant=str(ref.get('tenant_id',self.tenant_id))
        if tenant!=self.tenant_id: raise TenantIsolationError('cross-tenant artifact')
        if not re.fullmatch(r'[0-9a-f]{64}',str(ref.get('artifact_hash',''))): raise ArtifactVerificationError('invalid artifact hash')
        if self.artifact_verifier is None: raise ArtifactVerificationError('artifact_verifier is required; unsigned/unverifiable artifacts are refused')
        try: ok=bool(self.artifact_verifier(ref))
        except Exception as exc: raise ArtifactVerificationError('artifact verification failed') from exc
        if not ok: raise ArtifactVerificationError('artifact verifier rejected reference')
    def _node_from_ref(self,ref,node_kind,source_event,verification='verified'):
        self._verify_artifact(ref)
        tenant=str(ref['tenant_id']); identity={'artifact_class':ref.get('artifact_class'),'artifact_id':ref.get('artifact_id'),'artifact_version':ref.get('artifact_version'),'artifact_hash':ref.get('artifact_hash'),'tenant_id':tenant}; node_id=uuid_from_hash(sha_obj(identity)); body={'artifact_ref':dict(ref),'node_kind':node_kind,'source_event_ref':str(source_event.get('event_id')) if source_event else None,'source_subsystem':str(source_event.get('produced_by',{}).get('id','p2-x')) if source_event else 'p2-x','verification':verification,'verification_method':'producer_signature_and_artifact_hash','parent_node_ids':[],'child_node_ids':[],'supersedes':None,'superseded_by':None}
        c_hash=sha_obj({**identity,'node_kind':node_kind}); body['node_id']=node_id; body['canonical_body_hash']=c_hash; body['content_addressed_ref']=f'urn:jarvis:provenance:node:{c_hash}'; body['indexed_at']=utc_now(); signed=sign_doc(body,self.signing_key); self._validate(signed,'provenance_node_v1.schema.json'); self.storage.put_node(signed,tenant); return signed
    def _event_node(self,event):
        body=canonical_json(event); ref={'artifact_class':'event','artifact_id':str(event['event_id']),'artifact_version':str(event.get('schema_version','1.0.0')),'artifact_hash':hashlib.sha256(body).hexdigest(),'signature_ref':None,'producer_ref':{'principal':str(event.get('produced_by',{}).get('id','')),'key_id':str(event.get('produced_by',{}).get('id',''))},'tenant_id':str(event['tenant_id'])}
        tenant=str(event['tenant_id']); identity={'artifact_class':'event','artifact_id':ref['artifact_id'],'artifact_version':ref['artifact_version'],'artifact_hash':ref['artifact_hash'],'tenant_id':tenant}; node_id=uuid_from_hash(sha_obj(identity)); node_body={'artifact_ref':ref,'node_kind':'event','source_event_ref':str(event['event_id']),'source_subsystem':str(event.get('produced_by',{}).get('id','p2-u')),'verification':'verified','verification_method':'event_envelope_signature_and_integrity','parent_node_ids':[],'child_node_ids':[],'supersedes':None,'superseded_by':None,'node_id':node_id,'canonical_body_hash':sha_obj({**identity,'node_kind':'event'}),'content_addressed_ref':f'urn:jarvis:provenance:node:{sha_obj({**identity,'node_kind':'event'})}','indexed_at':str(event.get('emitted_at',utc_now()))}; signed=sign_doc(node_body,self.signing_key); self._validate(signed,'provenance_node_v1.schema.json'); self.storage.put_node(signed,tenant); return signed
    def _would_cycle(self, from_id:str, to_id:str, tenant:str|None=None, edge_kind:str|None=None)->bool:
        if from_id==to_id: return True
        if edge_kind in NON_STRUCTURAL_CYCLE_EDGES: return False
        tenant=tenant or self.tenant_id
        adj=defaultdict(list)
        for edge in self.storage.all_edges(tenant):
            adj[str(edge['from_node_id'])].append(str(edge['to_node_id']))
        qd=deque([to_id]); seen={to_id}
        while qd:
            cur=qd.popleft()
            if cur==from_id: return True
            for nxt in adj.get(cur,[]):
                if nxt not in seen:
                    seen.add(nxt); qd.append(nxt)
        return False
    def _edge(self,from_id,to_id,kind,event,confidence='signed',producer=None,producer_kind='subsystem',derivation_rule_ref=None,derivation_rule_version=None,evidence_refs=()):
        if self._would_cycle(str(from_id),str(to_id),self.tenant_id,kind): raise CycleDetected('cycle refused')
        producer=producer or {'principal':str(event.get('produced_by',{}).get('id','p2-x')),'key_id':str(event.get('produced_by',{}).get('id','p2-x'))}
        body={'edge_kind':kind,'confidence':confidence,'from_node_id':from_id,'to_node_id':to_id,'producer_ref':dict(producer),'producer_kind':producer_kind,'derivation_rule_ref':derivation_rule_ref,'derivation_rule_version':derivation_rule_version,'derivation_evidence_refs':list(evidence_refs),'source_event_ref':str(event['event_id']),'source_subsystem':str(event.get('produced_by',{}).get('id','p2-x')),'verification':'verified','verification_ref':str(event['event_id']),'emitted_at':str(event.get('emitted_at',utc_now())),'indexed_at':str(event.get('emitted_at',utc_now())),'supersedes':None,'superseded_by':None,'revoked_by':None}
        digest=sha_obj(body); body['edge_id']=uuid_from_hash(digest); body['integrity_hash']=digest; body['signature']=base64.b64encode(self.signing_key.sign(canonical_bytes({**body,'integrity_hash':digest}))).decode(); self._validate(body,'provenance_edge_v1.schema.json'); self.storage.put_edge(body,self.tenant_id); return body
    def _find_or_create_ref_node(self,ref,node_kind,event):
        self._verify_artifact(ref); body_hash=sha_obj({'artifact_ref':dict(ref),'node_kind':node_kind,'source_event_ref':str(event['event_id']),'source_subsystem':str(event.get('produced_by',{}).get('id','')),'verification':'verified','verification_method':'producer_signature_and_artifact_hash','parent_node_ids':[],'child_node_ids':[],'supersedes':None,'superseded_by':None})
        nid=uuid_from_hash(body_hash); existing=self.storage.get_node(nid,self.tenant_id)
        return existing or self._node_from_ref(ref,node_kind,event)
    def _extract_artifacts(self,event):
        payload=event.get('payload') or {}; refs=[]
        for k in ('artifact_ref','artifact_refs','lineage_nodes'):
            v=payload.get(k)
            if isinstance(v,dict): refs.append(v)
            elif isinstance(v,list): refs.extend(x for x in v if isinstance(x,dict))
        return refs
    def _extract_edges(self,event):
        payload=event.get('payload') or {}; edges=payload.get('lineage_edges') or payload.get('edges') or []
        return [e for e in edges if isinstance(e,dict)]
    def index_event(self,event_ref,event=None):
        event=self._event_dict(event if event is not None else event_ref)
        tenant=str(event.get('tenant_id',''))
        if tenant!=self.tenant_id: raise TenantIsolationError('cross-tenant event')
        self._verify_event(event)
        with self.storage.write_transaction():
            return self._index_event_transaction(event)

    def _index_event_transaction(self,event):
        tenant=str(event['tenant_id']); self.storage.add_event(tenant,event)
        eid=str(event['event_id']); stages=[]; node_count=edge_count=0
        stages.append({'stage':1,'name':'ingest','status':'passed'}); stages.append({'stage':2,'name':'verify','status':'passed'})
        event_node=self._event_node(event); node_count+=1; self._emit('NodeIndexed',{'node_id':event_node['node_id'],'node_kind':'event','event_id':eid},tenant,eid,event.get('causation_id')); stages.append({'stage':3,'name':'extract_nodes','status':'passed'})
        artifact_nodes=[]
        for ref in self._extract_artifacts(event):
            nk=str(ref.get('artifact_class') or ref.get('node_kind') or 'external_artifact')
            node=self._find_or_create_ref_node(ref,nk,event); artifact_nodes.append(node); node_count+=1; self._emit('NodeIndexed',{'node_id':node['node_id'],'node_kind':node['node_kind'],'event_id':eid},tenant,eid,event.get('causation_id'))
        edge_specs=self._extract_edges(event)
        for e in edge_specs:
            fr=str(e.get('from_node_id','')); to=str(e.get('to_node_id','')); kind=str(e.get('edge_kind',''))
            if self.storage.get_node(fr,tenant) is None or self.storage.get_node(to,tenant) is None: raise DanglingEdge('edge endpoint is not indexed')
            if not e.get('signature') or not e.get('integrity_hash'): raise SignatureError('unsigned producer edge refused')
            pref=e.get('producer_ref') or {}; key=self.public_key_resolver(str(pref.get('principal','')),str(pref.get('key_id',''))) if self.public_key_resolver else None
            if key is None: raise SignatureError('producer edge public key unavailable')
            verify_doc(e, key if isinstance(key,Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(key)))
            if self._would_cycle(fr,to,tenant,str(e.get('edge_kind',''))):
                self._emit('CycleDetected',{'event_id':eid,'edge_id':e.get('edge_id'),'from_node_id':fr,'to_node_id':to},tenant,eid,event.get('causation_id'))
                raise CycleDetected('cycle detected before edge indexing')
            self.storage.put_edge(e,tenant)
            self._emit('EdgeIndexed',{'edge_id':e['edge_id'],'edge_kind':e['edge_kind'],'event_id':eid},tenant,eid,event.get('causation_id')); edge_count+=1
        stages.append({'stage':4,'name':'extract_edges','status':'passed'})
        stages.append({'stage':5,'name':'canonicalize','status':'passed'}); stages.append({'stage':6,'name':'dedupe','status':'passed'})
        for k, ref_id in (('caused_by',event.get('causation_id')),('correlated_with',event.get('correlation_id'))):
            if not ref_id or (k=='correlated_with' and str(ref_id)==eid): continue
            target=self.storage.get_node(str(ref_id),tenant)
            if target:
                self._edge(event_node['node_id'],target['node_id'],k,event,confidence='declared'); edge_count+=1
            else:
                self.storage.db.execute('INSERT OR IGNORE INTO pending VALUES(?,?,?,?,?,?,?,?)',(eid,str(ref_id),k,tenant,eid,json.dumps(event.get('produced_by',{}),sort_keys=True),str(event.get('emitted_at',utc_now())),json.dumps(event)))
        stages.append({'stage':7,'name':'index','status':'passed'})
        self._resolve_pending(tenant)
        cycles=self.detect_cycles(tenant)
        if cycles['cycles']: raise CycleDetected('cycle detected during indexing')
        dangling=self.detect_dangling_edges(tenant)
        if dangling['dangling_edges']: raise DanglingEdge('dangling edge detected during indexing')
        stages.append({'stage':8,'name':'integrity','status':'passed'}); stages.append({'stage':9,'name':'derive','status':'not-run','reason':'only signed rules are materialized explicitly'}); stages.append({'stage':10,'name':'events','status':'passed'})
        self._emit('IndexingCompleted',{'event_id':eid,'nodes_indexed':node_count,'edges_indexed':edge_count},tenant,event.get('correlation_id'),event.get('causation_id'))
        state=self.graph_state_hash(tenant)
        receipt={'receipt_id':str(uuid.uuid4()),'event_ref':eid,'tenant_id':tenant,'status':'indexed','nodes_indexed':node_count,'edges_indexed':edge_count,'stage_reports':stages,'reason':None,'graph_state_hash':state}
        signed=sign_doc(receipt,self.signing_key); self._validate(signed,'indexing_receipt_v1.schema.json'); return signed
    def _event_reference_node(self,tenant,ref_id):
        for n in self.storage.all_nodes(tenant):
            aref=n.get('artifact_ref',{})
            if aref.get('artifact_class')=='event' and aref.get('artifact_id')==str(ref_id):
                return n
        for ev in self.storage.events(tenant):
            if str(ev.get('correlation_id'))==str(ref_id):
                for n in self.storage.all_nodes(tenant):
                    aref=n.get('artifact_ref',{})
                    if aref.get('artifact_class')=='event' and aref.get('artifact_id')==str(ev.get('event_id')):
                        return n
        return None
    def _resolve_pending(self,tenant):
        rows=self.storage.db.execute('SELECT rowid,* FROM pending WHERE tenant_id=? ORDER BY rowid',(tenant,)).fetchall()
        for r in rows:
            target=self._event_reference_node(tenant,r['to_ref']) or self.storage.get_node(r['to_ref'],tenant)
            source=self._event_reference_node(tenant,r['from_ref']) or self.storage.get_node(r['from_ref'],tenant)
            if target and source:
                if source['node_id']==target['node_id']:
                    self.storage.db.execute('DELETE FROM pending WHERE rowid=?',(r['rowid'],)); continue
                ev=json.loads(r['payload_json']); self._edge(source['node_id'],target['node_id'],r['kind'],ev,confidence='declared'); self.storage.db.execute('DELETE FROM pending WHERE rowid=?',(r['rowid'],))
    def _matches_filters(self,node,edge,q):
        if q.node_kinds and node.get('node_kind') not in q.node_kinds:return False
        if q.edge_kinds and edge.get('edge_kind') not in q.edge_kinds:return False
        if q.confidence_min and CONFIDENCE.index(edge.get('confidence','signed'))>CONFIDENCE.index(q.confidence_min):return False
        if q.verification_required and edge.get('verification')!='verified':return False
        if not q.include_derived and edge.get('confidence')=='derived':return False
        if not q.include_contested and edge.get('confidence')=='contested':return False
        return True
    def graph_state_hash(self,tenant):
        nodes=self.storage.all_nodes(tenant); edges=self.storage.all_edges(tenant); return hashlib.sha256(canonical_bytes({'nodes':nodes,'edges':edges})).hexdigest()
    def _query_root(self,q):
        if q.subject_node_id:return q.subject_node_id
        if q.subject_artifact_ref:
            # deterministic search, no invention
            for n in self.storage.all_nodes(q.tenant_id):
                if n['artifact_ref'].get('artifact_class')==q.subject_artifact_ref.get('artifact_class') and n['artifact_ref'].get('artifact_id')==q.subject_artifact_ref.get('artifact_id') and n['artifact_ref'].get('artifact_hash')==q.subject_artifact_ref.get('artifact_hash'): return n['node_id']
        raise QueryError('subject is required')
    def _traverse(self,q,root,target=None,mode='out'):
        nodes={n['node_id']:n for n in self.storage.all_nodes(q.tenant_id)}; edges=self.storage.all_edges(q.tenant_id)
        adj=defaultdict(list)
        for e in edges:
            if not self._matches_filters(nodes.get(e['from_node_id'],{}),e,q):continue
            if mode=='out':adj[e['from_node_id']].append(e)
            else:adj[e['to_node_id']].append(e)
        seen={root:0}; paths={root:[root]}; selected=[]; qd=deque([root]); truncated=False
        while qd:
            cur=qd.popleft(); depth=seen[cur]
            if len(selected)>=q.max_results: truncated=True; break
            if depth>=q.max_depth: truncated=True; continue
            for e in sorted(adj.get(cur,[]),key=lambda x:x['edge_id']):
                nxt=e['to_node_id'] if mode=='out' else e['from_node_id']
                if nxt not in seen:
                    seen[nxt]=depth+1; paths[nxt]=paths[cur]+[nxt]; qd.append(nxt); selected.append(e)
                    if target and nxt==target: return nodes,selected,paths,False
        return nodes,selected,paths,truncated
    def query(self,q:GraphQuery):
        if q.tenant_id!=self.tenant_id: raise TenantIsolationError('cross-tenant query')
        self._verify_query_signature(q)
        self._emit('QueryIssued',{'query_id':q.query_id,'query_kind':q.query_kind},q.tenant_id,q.query_id)
        kind=q.query_kind; root=self._query_root(q)
        allnodes={n['node_id']:n for n in self.storage.all_nodes(q.tenant_id)}; alle={e['edge_id']:e for e in self.storage.all_edges(q.tenant_id)}
        if kind=='path_between':
            if not q.target_node_id: raise QueryError('target_node_id is required')
            nodes,edges,paths,trunc=self._traverse(q,root,q.target_node_id,'out'); path=paths.get(q.target_node_id,[]); paths_out=[path] if path else []
        elif kind in ('descendants_of','lineage_of','provenance_of','execution_lineage','comparison_lineage','cost_lineage','security_lineage','attribution_of','impact_of'):
            nodes,edges,paths,trunc=self._traverse(q,root,None,'out'); paths_out=[]
        elif kind in ('ancestors_of','evidence_chain_for','causal_chain_for','operator_lineage'):
            nodes,edges,paths,trunc=self._traverse(q,root,None,'in'); paths_out=[]
        elif kind=='contradiction_graph':
            subset=[e for e in alle.values() if e['edge_kind']=='contradicts' and e['verification']=='verified' and (e['from_node_id']==root or e['to_node_id']==root)][:q.max_results]; ids={root}|{x['from_node_id'] for x in subset}|{x['to_node_id'] for x in subset}; nodes={i:allnodes[i] for i in ids if i in allnodes}; edges=subset; paths_out=[]; trunc=False
        else: raise QueryError(f'unsupported query kind: {kind}')
        node_list=sorted([allnodes[nid] for nid in ({root}|{e['from_node_id'] for e in edges}|{e['to_node_id'] for e in edges}) if nid in allnodes],key=lambda x:x['node_id'])[:q.max_results]
        edge_list=sorted(edges,key=lambda x:x['edge_id'])[:q.max_results]
        if kind=='path_between' and q.target_node_id and not paths_out: truncated=False
        summary={'query_kind':kind,'node_count':len(node_list),'edge_count':len(edge_list),'path_count':len(paths_out)}
        state_hash=self.graph_state_hash(q.tenant_id); event_times=[str(e.get('emitted_at','')) for e in self.storage.events(q.tenant_id) if e.get('emitted_at')]
        computed_at=max(event_times) if event_times else '1970-01-01T00:00:00Z'
        doc={'result_id':'','query_ref':q.query_id,'nodes':node_list,'edges':edge_list,'paths':paths_out,'summary':summary,'truncated':bool(trunc),'truncation_reason':'max_depth_or_results' if trunc else None,'graph_state_ref':f'urn:jarvis:provenance:graph:{state_hash}','graph_state_hash':state_hash,'computed_at':computed_at,'computed_by':{'principal':'p2-x','key_id':self.key_id},'index_version':VERSION,'content_addressed_ref':''}
        tmp=sha_obj({k:v for k,v in doc.items() if k not in ('signature','integrity_hash','content_addressed_ref','result_id')}); doc['result_id']=uuid_from_hash(tmp); doc['content_addressed_ref']=f'urn:jarvis:provenance:query-result:{tmp}'; signed=sign_doc(doc,self.signing_key); self._validate(signed,'graph_query_result_v1.schema.json'); self.storage.db.execute('INSERT OR REPLACE INTO results VALUES(?,?,?)',(signed['result_id'],q.tenant_id,canonical_json(signed).decode())); self.storage.db.commit();
        if signed['truncated']: self._emit('QueryTruncated',{'query_id':q.query_id,'result_id':signed['result_id'],'reason':signed['truncation_reason']},q.tenant_id,q.query_id)
        self._emit('QueryCompleted',{'query_id':q.query_id,'result_id':signed['result_id'],'truncated':signed['truncated']},q.tenant_id,q.query_id); return signed
    def _verify_query_signature(self,q):
        if not q.signature or not q.requested_by: raise SignatureError('signed query required')
        # P2-X accepts its own operator key or an injected resolver.
        key=self.public_key if q.requested_by.get('key_id')==self.key_id else (self.public_key_resolver(q.requested_by.get('principal',''),q.requested_by.get('key_id','')) if self.public_key_resolver else None)
        if key is None: raise SignatureError('query public key unavailable')
        x=q.unsigned(); digest=sha_obj(x); pub=key if isinstance(key,Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(key));
        try: pub.verify(base64.b64decode(q.signature),canonical_bytes(x))
        except (InvalidSignature,ValueError) as exc: raise SignatureError('query signature failed') from exc
    def sign_query(self,query:GraphQuery,key:Ed25519PrivateKey|None=None)->GraphQuery:
        key=key or self.signing_key; x=query.unsigned(); sig=base64.b64encode(key.sign(canonical_bytes(x))).decode(); return GraphQuery(**{**asdict(query),'signature':sig})
    def lineage_of(self,subject_ref,options=None):
        q=self._make_query('lineage_of',subject_ref,options or {}); return self.query(q)
    def descendants_of(self,subject_ref,options=None): return self.query(self._make_query('descendants_of',subject_ref,options or {}))
    def ancestors_of(self,subject_ref,options=None): return self.query(self._make_query('ancestors_of',subject_ref,options or {}))
    def path_between(self,from_ref,to_ref,options=None):
        o=options or {}; target_node_id=to_ref if isinstance(to_ref,str) and re.fullmatch(r'[0-9a-f-]{36}',to_ref) else None
        if target_node_id is None and isinstance(to_ref,Mapping):
            for n in self.storage.all_nodes(self.tenant_id):
                ref=n.get('artifact_ref',{})
                if all(ref.get(k)==to_ref.get(k) for k in ('artifact_class','artifact_id','artifact_hash')):
                    target_node_id=n['node_id']; break
        q=self._make_query('path_between',from_ref,{**o,'target_node_id':target_node_id}); return self.query(q)
    def impact_of(self,subject_ref,options=None): return self.query(self._make_query('impact_of',subject_ref,options or {}))
    def evidence_chain_for(self,claim_ref): return self.query(self._make_query('evidence_chain_for',claim_ref,{}))
    def causal_chain_for(self,subject_ref): return self.query(self._make_query('causal_chain_for',subject_ref,{}))
    def provenance_of(self,subject_ref): return self.query(self._make_query('provenance_of',subject_ref,{}))
    def attribution_of(self,subject_ref): return self.query(self._make_query('attribution_of',subject_ref,{}))
    def contradiction_graph(self,subject_ref): return self.query(self._make_query('contradiction_graph',subject_ref,{}))
    def security_lineage(self,subject_ref): return self.query(self._make_query('security_lineage',subject_ref,{}))
    def cost_lineage(self,subject_ref): return self.query(self._make_query('cost_lineage',subject_ref,{}))
    def execution_lineage(self,subject_ref): return self.query(self._make_query('execution_lineage',subject_ref,{}))
    def operator_lineage(self,operator_ref): return self.query(self._make_query('operator_lineage',operator_ref,{}))
    def comparison_lineage(self,experiment_ref): return self.query(self._make_query('comparison_lineage',experiment_ref,{}))
    def _make_query(self,kind,subject,opts):
        if isinstance(subject,str): subject_node_id=subject if re.fullmatch(r'[0-9a-f-]{36}',subject) else None; subject_ref=None
        else:
            subject_ref=dict(subject)
            if subject_ref.get('tenant_id',self.tenant_id)!=self.tenant_id: raise TenantIsolationError('cross-tenant query subject')
            subject_node_id=None
        q=GraphQuery(query_id=str(uuid.uuid4()),query_kind=kind,tenant_id=self.tenant_id,subject_node_id=subject_node_id,subject_artifact_ref=subject_ref,target_node_id=opts.get('target_node_id'),edge_kinds=tuple(opts['edge_kinds']) if opts.get('edge_kinds') else None,node_kinds=tuple(opts['node_kinds']) if opts.get('node_kinds') else None,confidence_min=opts.get('confidence_min'),verification_required=bool(opts.get('verification_required',True)),time_window=opts.get('time_window'),max_results=int(opts.get('max_results',1000)),max_depth=int(opts.get('max_depth',20)),include_derived=bool(opts.get('include_derived',True)),include_contested=bool(opts.get('include_contested',True)),requested_by={'principal':'p2-x','key_id':self.key_id},requested_at=utc_now()); return self.sign_query(q)
    def get_node(self,node_id):
        n=self.storage.get_node(node_id,self.tenant_id)
        if n is None: raise KeyError(node_id)
        return n
    def get_edge(self,edge_id):
        e=self.storage.get_edge(edge_id,self.tenant_id)
        if e is None: raise KeyError(edge_id)
        return e
    def verify_node(self,node_id):
        n=self.get_node(node_id); verify_doc(n,self.public_key); return {'verified':True,'node_id':node_id}
    def verify_edge(self,edge_id):
        e=self.get_edge(edge_id); pref=e.get('producer_ref') or {}; key=self.public_key if pref.get('key_id')==self.key_id else (self.public_key_resolver(pref.get('principal',''),pref.get('key_id','')) if self.public_key_resolver else None)
        if key is None: raise SignatureError('edge producer public key unavailable')
        pub=key if isinstance(key,Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(key)); verify_doc(e,pub); return {'verified':True,'edge_id':edge_id}
    def verify_subgraph(self,result_ref):
        row=self.storage.db.execute('SELECT doc_json FROM results WHERE result_id=? AND tenant_id=?',(result_ref,self.tenant_id)).fetchone()
        if not row: raise KeyError(result_ref)
        d=json.loads(row['doc_json']); verify_doc(d,self.public_key); failures=[]
        for n in d['nodes']:
            try: verify_doc(n,self.public_key)
            except Exception as exc: failures.append(str(exc))
        for e in d['edges']:
            try:
                pref=e.get('producer_ref') or {}; key=self.public_key if pref.get('key_id')==self.key_id else (self.public_key_resolver(pref.get('principal',''),pref.get('key_id','')) if self.public_key_resolver else None)
                if key is None: raise SignatureError('edge producer public key unavailable')
                pub=key if isinstance(key,Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(bytes(key)); verify_doc(e,pub)
            except Exception as exc: failures.append(str(exc))
        return {'verified':not failures,'nodes_checked':len(d['nodes']),'edges_checked':len(d['edges']),'failures':failures}
    def verify_offline(self,subgraph:Mapping[str,Any],public_keys:Mapping[str,bytes|Ed25519PublicKey]):
        failures=[]
        for n in subgraph.get('nodes',[]):
            try: verify_doc(n,self._key(public_keys,'p2-x','p2-x'))
            except Exception as exc: failures.append(f"node:{n.get('node_id')}:{exc}")
        for e in subgraph.get('edges',[]):
            p=e.get('producer_ref',{}); key=self._key(public_keys,p.get('principal',''),p.get('key_id',''))
            if key is None: failures.append(f"edge:{e.get('edge_id')}:public key unavailable"); continue
            try: verify_doc(e,key)
            except Exception as exc: failures.append(f"edge:{e.get('edge_id')}:{exc}")
        result={'result_id':str(uuid.uuid4()),'verified':not failures,'nodes_checked':len(subgraph.get('nodes',[])),'edges_checked':len(subgraph.get('edges',[])),'failures':failures,'verified_at':utc_now()}; self._emit('OfflineVerified',{'result_id':result['result_id'],'verified':result['verified'],'nodes_checked':result['nodes_checked'],'edges_checked':result['edges_checked']},self.tenant_id); return result
    def _key(self,mapping,principal,key_id):
        v=mapping.get(key_id) or mapping.get(principal); return v
    def register_derivation_rule(self,rule:Mapping[str,Any],public_key:bytes|Ed25519PublicKey):
        verify_doc(rule,public_key); self.storage.db.execute('INSERT OR REPLACE INTO rules VALUES(?,?,?)',(str(rule['rule_id']),str(rule['rule_version']),canonical_json(rule).decode())); self.storage.db.commit(); self._emit('DerivationRuleRegistered',{'rule_id':rule['rule_id'],'rule_version':rule['rule_version']},self.tenant_id); return str(rule['rule_id'])
    def list_derivation_rules(self): return [json.loads(r['doc_json']) for r in self.storage.db.execute('SELECT doc_json FROM rules ORDER BY rule_id,rule_version')]
    def materialize_derived_edges(self,rule_id,window=None):
        rules=[json.loads(r['doc_json']) for r in self.storage.db.execute('SELECT doc_json FROM rules WHERE rule_id=?',(str(rule_id),))]
        if not rules: raise KeyError(rule_id)
        rule=sorted(rules,key=lambda x:x['rule_version'])[-1]
        edges=self.storage.all_edges(self.tenant_id); bykind=defaultdict(list)
        for edge in edges:
            bykind[edge['edge_kind']].append(edge)
        pairs=set()
        method=rule['method']
        if method=='inverse':
            for kind in rule['from_edge_kinds']:
                for edge in bykind.get(kind,[]): pairs.add((edge['to_node_id'],edge['from_node_id']))
        elif method=='transitive':
            for kind in rule['from_edge_kinds']:
                src=list(bykind.get(kind,[]))
                for e1 in src:
                    for e2 in src:
                        if e1['to_node_id']==e2['from_node_id'] and e1['from_node_id']!=e2['to_node_id']:
                            pairs.add((e1['from_node_id'],e2['to_node_id']))
        else:
            src=[e for kind in rule['from_edge_kinds'] for e in bykind.get(kind,[])]
            adjacency=defaultdict(list)
            for edge in src: adjacency[edge['from_node_id']].append(edge)
            for edge in src:
                qd=deque([(edge['to_node_id'],1)]); seen={edge['to_node_id']}
                while qd:
                    cur,_depth=qd.popleft()
                    for nxt in adjacency.get(cur,[]):
                        if nxt['to_node_id'] not in seen:
                            seen.add(nxt['to_node_id']); pairs.add((edge['from_node_id'],nxt['to_node_id'])); qd.append((nxt['to_node_id'],_depth+1))
        created=0
        for a,b in sorted(pairs):
            if a==b: continue
            if any(x['from_node_id']==a and x['to_node_id']==b and x['edge_kind']==rule['to_edge_kind'] and x.get('derivation_rule_ref')==rule['rule_id'] and x.get('derivation_rule_version')==rule['rule_version'] for x in edges): continue
            evidence_edges=[x for x in edges if (x['from_node_id']==a and x['to_node_id']==b) or x['from_node_id']==a or x['to_node_id']==b]
            deterministic_event_id=uuid_from_hash(sha_obj({'rule_id':rule['rule_id'],'rule_version':rule['rule_version'],'from_node_id':a,'to_node_id':b,'edge_kind':rule['to_edge_kind']}))
            emitted=max([str(x.get('emitted_at','1970-01-01T00:00:00Z')) for x in evidence_edges] or ['1970-01-01T00:00:00Z'])
            ev={'event_id':deterministic_event_id,'produced_by':{'id':'p2-x','kind':'subsystem'},'emitted_at':emitted}
            self._edge(a,b,rule['to_edge_kind'],ev,confidence='derived',producer={'principal':'p2-x','key_id':self.key_id},producer_kind='derived_rule',derivation_rule_ref=rule['rule_id'],derivation_rule_version=rule['rule_version'],evidence_refs=(f"urn:jarvis:provenance:rule:{rule['rule_id']}:{rule['rule_version']}",))
            edges=self.storage.all_edges(self.tenant_id); created+=1
        self._emit('DerivedEdgesMaterialized',{'rule_id':rule_id,'created':created},self.tenant_id); return {'rule_id':rule_id,'created':created,'graph_state_hash':self.graph_state_hash(self.tenant_id)}
    def snapshot_graph(self,window=None):
        payload={'tenant_id':self.tenant_id,'nodes':self.storage.all_nodes(self.tenant_id),'edges':self.storage.all_edges(self.tenant_id),'events':self.storage.events(self.tenant_id),'rules':self.list_derivation_rules()}; state=self.graph_state_hash(self.tenant_id); sid=str(uuid.uuid4()); self.storage.db.execute('INSERT INTO snapshots VALUES(?,?,?,?,?)',(sid,self.tenant_id,canonical_json(payload),state,utc_now())); self.storage.db.commit(); doc={'snapshot_id':sid,'tenant_id':self.tenant_id,'created_at':max([str(e.get('emitted_at','')) for e in payload['events'] if e.get('emitted_at')] or [utc_now()]),'graph_state_hash':state,'node_count':len(payload['nodes']),'edge_count':len(payload['edges']),'content_addressed_ref':f'urn:jarvis:provenance:snapshot:{state}'}; signed=sign_doc(doc,self.signing_key); self._validate(signed,'graph_snapshot_v1.schema.json'); self._emit('SnapshotCreated',{'snapshot_id':sid,'graph_state_hash':state},self.tenant_id); return signed
    def restore_graph(self,ref):
        row=self.storage.db.execute('SELECT content,state_hash FROM snapshots WHERE snapshot_id=? AND tenant_id=?',(ref if isinstance(ref,str) else ref.get('snapshot_id'),self.tenant_id)).fetchone();
        if not row: raise KeyError(ref)
        payload=json.loads(row['content']); restored=0
        for n in payload.get('nodes',[]): self.storage.put_node(n,self.tenant_id); restored+=1
        for e in payload.get('edges',[]): self.storage.put_edge(e,self.tenant_id); restored+=1
        for ev in payload.get('events',[]): self.storage.add_event(self.tenant_id,ev)
        for rule in payload.get('rules',[]): self.storage.db.execute('INSERT OR REPLACE INTO rules VALUES(?,?,?)',(str(rule['rule_id']),str(rule['rule_version']),canonical_json(rule).decode()))
        self.storage.db.commit()
        self._emit('SnapshotRestored',{'snapshot_id':ref if isinstance(ref,str) else ref.get('snapshot_id'),'records_reconciled':restored,'events_restored':len(payload.get('events',[])),'rules_restored':len(payload.get('rules',[]))},self.tenant_id); return {'restored':restored,'graph_state_hash':self.graph_state_hash(self.tenant_id)}
    def export_subgraph(self,result_ref):
        row=self.storage.db.execute('SELECT doc_json FROM results WHERE result_id=? AND tenant_id=?',(result_ref,self.tenant_id)).fetchone();
        if not row: raise KeyError(result_ref)
        path=self.root/f'exports/{result_ref}.json'; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(row['doc_json']+'\n',encoding='utf-8'); self._emit('SubgraphExported',{'result_id':result_ref,'path':str(path)},self.tenant_id); return str(path)
    def import_subgraph(self,content_uri):
        d=json.loads(Path(content_uri).read_text(encoding='utf-8')); ver=self.verify_offline(d,{'p2-x':self.public_key});
        if not ver['verified']: raise SignatureError('subgraph offline verification failed')
        for n in d['nodes']: self.storage.put_node(n,self.tenant_id)
        for e in d['edges']: self.storage.put_edge(e,self.tenant_id)
        self._emit('SubgraphImported',{'nodes':len(d['nodes']),'edges':len(d['edges'])},self.tenant_id); return {'verified':True,'nodes':len(d['nodes']),'edges':len(d['edges'])}
    def detect_cycles(self,window=None):
        edges=self.storage.all_edges(self.tenant_id); adj=defaultdict(list)
        for e in edges:
            if e.get('edge_kind') in NON_STRUCTURAL_CYCLE_EDGES: continue
            adj[e['from_node_id']].append(e['to_node_id'])
        state={}; stack=[]; cycles=[]
        def visit(u):
            state[u]=1; stack.append(u)
            for v in adj.get(u,[]):
                if state.get(v,0)==0: visit(v)
                elif state.get(v)==1 and v in stack: cycles.append(stack[stack.index(v):]+[v])
            stack.pop(); state[u]=2
        for u in list(adj):
            if state.get(u,0)==0: visit(u)
        report={'report_id':str(uuid.uuid4()),'tenant_id':self.tenant_id,'cycles':cycles,'detected_at':utc_now()}; return sign_doc(report,self.signing_key)
    def detect_dangling_edges(self,window=None):
        nodes={n['node_id'] for n in self.storage.all_nodes(self.tenant_id)}; dangling=[e['edge_id'] for e in self.storage.all_edges(self.tenant_id) if e['from_node_id'] not in nodes or e['to_node_id'] not in nodes]; report={'report_id':str(uuid.uuid4()),'tenant_id':self.tenant_id,'dangling_edges':dangling,'detected_at':utc_now()}; return sign_doc(report,self.signing_key)
    def verify_chain(self,tenant_id=None,window=None):
        t=tenant_id or self.tenant_id
        ok,count,fail=self.storage.chain_verify(t); report={'report_id':str(uuid.uuid4()),'tenant_id':t,'verified':ok,'checked_records':count,'first_failure':fail,'verified_at':utc_now()}; self._emit('ChainIntegrityVerified' if ok else 'ChainIntegrityFailed',{'tenant_id':t,'verified':ok,'checked_records':count,'first_failure':fail},t); return sign_doc(report,self.signing_key)

def relaxed_ref(ref):
    x=dict(ref); x.setdefault('artifact_version',None); x.setdefault('signature_ref',None); x.setdefault('producer_ref',None); return x
"""Resource monitoring."""
from __future__ import annotations
import logging
from typing import Any

logger = logging.getLogger("jarvis.resources")


class ResourceManager:
    def snapshot(self) -> dict[str, Any]:
        try:
            import psutil
            return {
                "cpu_percent": psutil.cpu_percent(interval=0.1),
                "ram_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage("/").percent,
            }
        except Exception:
            return {"error": "psutil unavailable"}



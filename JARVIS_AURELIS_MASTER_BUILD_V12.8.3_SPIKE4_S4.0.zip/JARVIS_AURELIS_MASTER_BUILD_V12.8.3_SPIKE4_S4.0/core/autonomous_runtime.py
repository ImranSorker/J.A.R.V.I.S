"""Background proactive runtime that turns system events into bounded missions."""
from __future__ import annotations
import logging, threading, time
from typing import Any, Callable, Dict, Optional
logger=logging.getLogger("jarvis.autonomous_runtime")
class AutonomousRuntime:
    """Low-frequency background observer for proactive maintenance and recovery."""
    def __init__(self,mission_runner:Callable[[str],Any],interval_seconds:float=60.0,enabled:bool=True)->None:
        if not callable(mission_runner):raise ValueError("mission_runner must be callable")
        self._runner=mission_runner;self._interval=max(5.0,float(interval_seconds));self._enabled=enabled;self._stop=threading.Event();self._thread:Optional[threading.Thread]=None;self._last_trigger:Dict[str,float]={}
    def start(self)->None:
        if not self._enabled or (self._thread and self._thread.is_alive()):return
        self._thread=threading.Thread(target=self._loop,name="jarvis-autonomy",daemon=True);self._thread.start()
    def stop(self,timeout:float=2.0)->None:
        self._stop.set()
        if self._thread:self._thread.join(timeout=timeout)
    def trigger(self,goal:str,cooldown_seconds:float=300.0)->bool:
        clean=str(goal or "").strip(); now=time.monotonic()
        if not clean:return False
        if now-self._last_trigger.get(clean,0.0)<cooldown_seconds:return False
        self._last_trigger[clean]=now
        try:self._runner(clean);return True
        except Exception as exc:logger.exception("autonomous_mission_trigger_failed",extra={"error":str(exc)});return False
    def _loop(self)->None:
        while not self._stop.wait(self._interval):
            try:
                import psutil
                cpu=float(psutil.cpu_percent(interval=0.1)); mem=float(psutil.virtual_memory().percent); disk=float(psutil.disk_usage("/").percent)
                if disk>=95:self.trigger("inspect and remediate critical disk usage",900)
                elif mem>=95:self.trigger("inspect and remediate critical memory pressure",600)
                elif cpu>=98:self.trigger("inspect sustained critical CPU pressure and identify runaway processes",600)
            except ImportError:logger.debug("psutil unavailable for proactive resource observer")
            except Exception as exc:logger.exception("autonomous_runtime_cycle_failed",extra={"error":str(exc)})
    def stats(self)->Dict[str,Any]:return {"enabled":self._enabled,"interval_seconds":self._interval,"alive":bool(self._thread and self._thread.is_alive()),"trigger_count":len(self._last_trigger)}



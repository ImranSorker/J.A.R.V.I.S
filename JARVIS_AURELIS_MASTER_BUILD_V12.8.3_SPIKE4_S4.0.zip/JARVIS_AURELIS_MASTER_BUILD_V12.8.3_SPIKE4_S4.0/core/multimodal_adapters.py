"""Adapters connecting concrete voice engines to the multimodal runtime."""
from __future__ import annotations

from typing import Any

from core.multimodal_runtime import ModalityResult


class VoiceAudioAdapter:
    """Bridge injected STT/TTS engines into the typed multimodal contract."""

    def __init__(self, stt: Any = None, tts: Any = None) -> None:
        self.stt = stt
        self.tts = tts

    def transcribe(self, payload: bytes) -> ModalityResult:
        """Transcribe audio bytes and normalize the result."""
        if not payload:
            raise ValueError("audio payload is empty")
        if self.stt is None:
            raise RuntimeError("speech-to-text engine is unavailable")
        transcribe = getattr(self.stt, "transcribe", None)
        if not callable(transcribe):
            raise RuntimeError("speech-to-text engine does not expose transcribe")
        result = transcribe(payload)
        text = result if isinstance(result, str) else getattr(result, "text", str(result))
        return ModalityResult(modality="audio", text=str(text), confidence=1.0, metadata={"engine": type(self.stt).__name__})

    def synthesize(self, text: str) -> bytes:
        """Synthesize speech and return audio bytes when the engine supports it."""
        value = str(text).strip()
        if not value:
            raise ValueError("text is required")
        if self.tts is None:
            raise RuntimeError("text-to-speech engine is unavailable")
        synthesize = getattr(self.tts, "synthesize", None)
        if callable(synthesize):
            output = synthesize(value)
            if not isinstance(output, (bytes, bytearray)):
                raise TypeError("TTS synthesize() must return bytes")
            return bytes(output)
        speak = getattr(self.tts, "speak", None)
        if not callable(speak):
            raise RuntimeError("text-to-speech engine exposes neither synthesize nor speak")
        speak(value)
        return b""



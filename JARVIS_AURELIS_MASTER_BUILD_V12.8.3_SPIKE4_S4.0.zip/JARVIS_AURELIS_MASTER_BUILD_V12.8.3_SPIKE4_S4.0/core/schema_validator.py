"""Strict JSON-Schema validation for tool and agent boundaries.

The validator uses the Draft 2020-12 implementation from ``jsonschema`` so tool
schemas can express composition, bounds, enums, arrays, objects, and nested
constraints without maintaining a second incompatible schema dialect.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from jsonschema import Draft202012Validator, SchemaError


@dataclass(frozen=True)
class SchemaValidationIssue:
    """One normalized validation failure."""

    path: str
    message: str
    validator: str

    @property
    def constraint(self) -> str:
        """Compatibility alias used by existing tests and callers."""
        return self.validator

    def to_dict(self) -> dict[str, str]:
        return {
            "path": self.path,
            "message": self.message,
            "constraint": self.validator,
        }


class SchemaValidationError(ValueError):
    """Raised when data fails a JSON schema."""

    def __init__(self, issues: Iterable[SchemaValidationIssue]) -> None:
        self.issues = tuple(issues)
        message = "; ".join(
            f"{issue.path or '$'}: {issue.message}" for issue in self.issues
        ) or "schema validation failed"
        super().__init__(message)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": False,
            "error": "schema_validation_failed",
            "issues": [issue.to_dict() for issue in self.issues],
        }


class SchemaValidator:
    """Validate arbitrary JSON-compatible values against Draft 2020-12 schemas."""

    def __init__(self, max_errors: int = 32) -> None:
        if max_errors < 1:
            raise ValueError("max_errors must be >= 1")
        self._max_errors = max_errors
        self._cache: dict[str, Draft202012Validator] = {}

    def _validator(self, schema: dict[str, Any]) -> Draft202012Validator:
        import json

        cache_key = json.dumps(schema, sort_keys=True, separators=(",", ":"), default=str)
        validator = self._cache.get(cache_key)
        if validator is not None:
            return validator
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema)
        if len(self._cache) >= 256:
            self._cache.pop(next(iter(self._cache)))
        self._cache[cache_key] = validator
        return validator

    @staticmethod
    def _format_path(path: Iterable[Any]) -> str:
        parts: list[str] = []
        for item in path:
            if isinstance(item, int):
                parts.append(f"[{item}]")
            else:
                if parts:
                    parts.append(f".{item}")
                else:
                    parts.append(str(item))
        return "".join(parts)

    def validate(self, instance: Any, schema: dict[str, Any]) -> list[SchemaValidationIssue]:
        """Return normalized validation issues without raising."""
        if not isinstance(schema, dict):
            raise TypeError("schema must be an object")
        try:
            validator = self._validator(schema)
        except SchemaError as exc:
            raise ValueError(f"invalid JSON schema: {exc.message}") from exc
        errors = sorted(validator.iter_errors(instance), key=lambda err: list(err.path))
        return [
            SchemaValidationIssue(
                path=self._format_path(error.absolute_path),
                message=error.message,
                validator=str(error.validator),
            )
            for error in errors[: self._max_errors]
        ]

    def validate_or_raise(self, instance: Any, schema: dict[str, Any]) -> None:
        """Validate and raise :class:`SchemaValidationError` on failure."""
        issues = self.validate(instance, schema)
        if issues:
            raise SchemaValidationError(issues)



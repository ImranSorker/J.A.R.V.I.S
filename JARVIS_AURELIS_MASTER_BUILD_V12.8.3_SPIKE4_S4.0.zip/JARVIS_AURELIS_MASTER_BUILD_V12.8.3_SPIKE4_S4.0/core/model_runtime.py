"""Unified local-model lifecycle manager built from existing JARVIS model primitives."""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
from pathlib import Path
import threading
import time
from typing import Any, Iterable

from core.model_server import ModelServer, ModelLease
from core.native_model_fabric import LocalModelFabric, LocalModelDecision


@dataclass(frozen=True, slots=True)
class ModelRuntimeRecord:
    """Safe model lifecycle record."""

    name: str
    path: str | None
    backend: str
    memory_mb: int
    context_length: int
    capabilities: tuple[str, ...]
    content_hash: str | None = None
    active: bool = False
    warmed: bool = False
    last_error: str | None = None


class ModelRuntime:
    """Model registry/discovery/admission coordinator; inference remains injected."""

    def __init__(self, fabric: LocalModelFabric, *, max_vram_mb: int = 0, max_models: int = 8) -> None:
        self.fabric = fabric
        self.admission = ModelServer(max(0.0, float(max_vram_mb) / 1024.0), max_models=max_models) if max_vram_mb > 0 else None
        self._records: dict[str, ModelRuntimeRecord] = {}
        self._lock = threading.RLock()

    def discover(self) -> tuple[ModelRuntimeRecord, ...]:
        """Discover local model files and register immutable metadata."""
        profiles = self.fabric.discover_gguf()
        with self._lock:
            for profile in profiles:
                self._records[profile.name] = ModelRuntimeRecord(profile.name, profile.path, profile.backend, profile.memory_mb, profile.context_length, tuple(profile.capabilities))
            return tuple(self._records[name] for name in sorted(self._records))

    def choose(self, required_capabilities: Iterable[str] = (), *, preferred: str | None = None) -> LocalModelDecision:
        """Choose a model using existing local-model policy."""
        return self.fabric.choose(required_capabilities=required_capabilities, preferred=preferred)

    def validate_artifact(self, name: str, *, max_bytes: int = 64 * 1024 * 1024 * 1024) -> str:
        """Hash a model artifact in bounded chunks; reject unsafe paths/sizes."""
        with self._lock:
            record = self._records.get(str(name))
        if record is None or not record.path:
            raise KeyError(name)
        path = Path(record.path).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        size = path.stat().st_size
        if size <= 0 or size > max_bytes:
            raise ValueError("model artifact size is outside policy")
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(4 * 1024 * 1024):
                digest.update(chunk)
        value = digest.hexdigest()
        with self._lock:
            self._records[name] = replace(self._records[name], content_hash=value, warmed=False)
        return value

    def admit(self, name: str) -> ModelLease | None:
        """Reserve model memory when a VRAM budget is configured."""
        if self.admission is None:
            return None
        with self._lock:
            record = self._records.get(name)
        if record is None:
            raise KeyError(name)
        lease = self.admission.admit(name, record.memory_mb / 1024.0)
        with self._lock:
            self._records[name] = replace(self._records[name], active=True)
        return lease

    def release(self, name: str) -> None:
        """Release a model admission lease without deleting model files."""
        if self.admission is not None:
            self.admission.evict(name)
        with self._lock:
            record = self._records.get(name)
            if record:
                self._records[name] = replace(record, active=False)

    def snapshot(self) -> dict[str, Any]:
        """Return deterministic runtime diagnostics."""
        with self._lock:
            records = [{"name": record.name, "path": record.path, "backend": record.backend, "memory_mb": record.memory_mb, "context_length": record.context_length, "capabilities": record.capabilities, "content_hash": record.content_hash, "active": record.active, "warmed": record.warmed, "last_error": record.last_error} for name, record in ((name, self._records[name]) for name in sorted(self._records))]
        return {"models": records, "admission": self.admission.snapshot() if self.admission else None, "timestamp": time.time()}

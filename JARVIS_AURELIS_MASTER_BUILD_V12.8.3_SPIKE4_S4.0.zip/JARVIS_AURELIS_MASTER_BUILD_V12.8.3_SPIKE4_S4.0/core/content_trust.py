"""Content Trust Engine — taint tracking and provenance for all external content.

Architecture:
    untrusted input
      -> provenance + taint metadata
      -> content normalization
      -> injection detection
      -> isolated context representation
      -> model
      -> output/tool-policy verification

Requirements:
- Never concatenate external content as if it were system/developer instructions.
- Preserve source identity and provenance.
- Mark content as DATA, never as executable instructions.
- Detect role-confusion, instruction-like content, jailbreak patterns.
- Tool authorization MUST NOT be derived from retrieved text.
"""
from __future__ import annotations

import enum
import html
import logging
import re
import json
import hashlib
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, List, Optional, Tuple

from core.prompt_defense import PromptSanitizer, PromptThreat

logger = logging.getLogger("jarvis.content_trust")


class ContentSource(enum.Enum):
    """Classification of content origin."""
    USER = "user"
    RAG_DOCUMENT = "rag_document"
    WEB_PAGE = "web_page"
    BROWSER_CONTENT = "browser_content"
    UPLOADED_FILE = "uploaded_file"
    TOOL_RESULT = "tool_result"
    PLUGIN_OUTPUT = "plugin_output"
    EXTERNAL_API = "external_api"
    OCR_TRANSCRIPTION = "ocr_transcription"
    MEMORY_RETRIEVAL = "memory_retrieval"
    SYSTEM = "system"


class TrustLevel(enum.Enum):
    """Trust classification for content."""
    TRUSTED = "trusted"           # System-generated, verified
    UNTRUSTED = "untrusted"       # External, unverified
    SANITIZED = "sanitized"       # Passed through defense layers
    QUARANTINED = "quarantined"   # Detected threats, neutralized
    REJECTED = "rejected"         # Failed security checks


@dataclass(frozen=True)
class Provenance:
    """Immutable record of content origin and transformation history."""
    source: ContentSource
    source_id: Optional[str] = None
    uri: Optional[str] = None
    owner: str = "system"
    workspace: str = "default"
    session_id: Optional[str] = None
    timestamp: float = field(default_factory=lambda: __import__("time").time())
    retrieval_confidence: float = 1.0
    embedding_model: Optional[str] = None
    transformation_history: Tuple[str, ...] = ()


@dataclass
class TaintedContent:
    """Content with full provenance and taint metadata."""
    content: str
    provenance: Provenance
    trust_level: TrustLevel = TrustLevel.UNTRUSTED
    threats: List[PromptThreat] = field(default_factory=list)
    normalized: bool = False
    truncated: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_context_string(self) -> str:
        """Render as a model-context-safe string with provenance markers.

        This ensures external content is explicitly marked as DATA,
        never as executable instructions.
        """
        source_label = self.provenance.source.value
        owner = self.provenance.owner
        workspace = self.provenance.workspace
        safe = self.content.replace("[/DATA", "[ /DATA").replace("<|/data_boundary|>", "<| /data_boundary |>" )
        header = f"[DATA source={source_label} owner={owner} workspace={workspace} trust={self.trust_level.value} content_sha256={hashlib.sha256(self.content.encode("utf-8")).hexdigest()[:16]}]"
        footer = f"[/DATA source={source_label}]"
        return f"{header}\n{safe}\n{footer}"

    def to_isolated_prompt(self) -> str:
        """Render for prompt injection-safe inclusion.

        Wraps content in a clear data boundary that models should treat
        as non-instructional context.
        """
        payload = {
            "source": self.provenance.source.value,
            "trust": self.trust_level.value,
            "content": self.content,
            "content_sha256": hashlib.sha256(self.content.encode("utf-8")).hexdigest(),
            "instructions_allowed": False,
        }
        encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c").replace(">", "\\u003e")
        return f"<|data_boundary|>{encoded}<|/data_boundary|>"


class ContentTrustEngine:
    """Central trust engine for all external content entering JARVIS.

    Usage:
        engine = ContentTrustEngine()
        tainted = engine.process(content, source=ContentSource.WEB_PAGE, uri=url)
        if tainted.trust_level == TrustLevel.REJECTED:
            raise SecurityError("Content rejected")
        prompt_fragment = tainted.to_context_string()
    """

    MAX_CONTENT_LENGTH: int = 500_000
    MAX_CONSECUTIVE_NEWLINES: int = 20

    # Patterns for tool-directive injection in retrieved content
    _TOOL_DIRECTIVE_PATTERNS: ClassVar[List[Tuple[str, re.Pattern]]] = [
        (
            "tool_directive",
            re.compile(
                r"(?i)(\btool\s*:\s*\w+|\bfunction\s*:\s*\w+|"
                r"\bexecute\s*:\s*\w+|\bcall\s*:\s*\w+|"
                r"\brun\s*:\s*\w+|\baction\s*:\s*\w+)"
            ),
        ),
        (
            "privilege_escalation",
            re.compile(
                r"(?i)(\badmin\s*:\s*|\broot\s*:\s*|\bsudo\s*:\s*|"
                r"\boverride\s+policy|\bdisable\s+security|\bbypass\s+auth)"
            ),
        ),
        (
            "data_exfiltration",
            re.compile(
                r"(?i)(\bupload\s+to\s+url|\bpost\s+to\s+http|\bsend\s+to\s+email|"
                r"\bexfiltrate|\bleak\s+data|\btransfer\s+to)"
            ),
        ),
    ]

    def __init__(self, prompt_sanitizer: Optional[PromptSanitizer] = None) -> None:
        self._sanitizer = prompt_sanitizer or PromptSanitizer()

    @staticmethod
    def _safe_provenance_label(value: Any, default: str, max_length: int = 128) -> str:
        raw = str(value if value is not None else default).replace("\x00", " ")
        raw = re.sub(r"[\r\n\t]+", " ", raw).strip()
        raw = re.sub(r"[^A-Za-z0-9 ._:@/-]", "_", raw)
        return (raw or default)[:max_length]

    def process(
        self,
        content: str,
        source: ContentSource,
        source_id: Optional[str] = None,
        uri: Optional[str] = None,
        owner: str = "system",
        workspace: str = "default",
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> TaintedContent:
        """Process external content through the full trust pipeline."""
        # 1. Provenance
        safe_owner = self._safe_provenance_label(owner, "system")
        safe_workspace = self._safe_provenance_label(workspace, "default")
        safe_source_id = self._safe_provenance_label(source_id, "", 256) if source_id is not None else None
        safe_session = self._safe_provenance_label(session_id, "", 128) if session_id is not None else None
        provenance = Provenance(
            source=source,
            source_id=safe_source_id,
            uri=str(uri).replace("\x00", "")[:2048] if uri is not None else None,
            owner=safe_owner,
            workspace=safe_workspace,
            session_id=safe_session,
        )

        # 2. Length bounding (anti-DoS)
        truncated = False
        if len(content) > self.MAX_CONTENT_LENGTH:
            content = content[: self.MAX_CONTENT_LENGTH] + "\n...[truncated by content trust engine]"
            truncated = True
            logger.warning("content_truncated", extra={"source": source.value, "original_length": len(content) + self.MAX_CONTENT_LENGTH})

        # 3. Normalization
        normalized_content = self._normalize(content)

        # 4. Injection detection (prompt defense)
        threats = self._sanitizer.analyze(normalized_content)

        # 5. Content-specific threat detection
        if source in (
            ContentSource.RAG_DOCUMENT,
            ContentSource.WEB_PAGE,
            ContentSource.BROWSER_CONTENT,
            ContentSource.TOOL_RESULT,
            ContentSource.PLUGIN_OUTPUT,
        ):
            extra_threats = self._detect_content_threats(normalized_content, source)
            threats.extend(extra_threats)

        # 6. Trust classification
        trust_level = self._classify_trust(threats, source)

        # 7. Sanitization if not rejected
        if trust_level != TrustLevel.REJECTED:
            sanitized, _ = self._sanitizer.sanitize(normalized_content)
            normalized_content = self._neutralize_instruction_lines(sanitized)

        result = TaintedContent(
            content=normalized_content,
            provenance=provenance,
            trust_level=trust_level,
            threats=threats,
            normalized=True,
            truncated=truncated,
            metadata=metadata or {},
        )

        # 8. Audit log
        logger.info(
            "content_processed",
            extra={
                "source": source.value,
                "trust_level": trust_level.value,
                "threat_count": len(threats),
                "truncated": truncated,
                "owner": safe_owner,
                "workspace": safe_workspace,
            },
        )
        return result

    def batch_process(
        self,
        items: List[Tuple[str, ContentSource, Optional[str], Optional[str]]],
        owner: str = "system",
        workspace: str = "default",
    ) -> List[TaintedContent]:
        """Process multiple content items efficiently."""
        return [
            self.process(content, source, source_id, uri, owner, workspace)
            for content, source, source_id, uri in items
        ]

    def verify_tool_safety(self, content: TaintedContent) -> bool:
        """Ensure content cannot trigger unauthorized tool execution.

        Tool authorization MUST NOT be derived from retrieved text.
        """
        for threat in content.threats:
            if threat.category in ("tool_directive", "privilege_escalation", "data_exfiltration"):
                return False
        return True

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _neutralize_instruction_lines(self, content: str) -> str:
        """Convert obvious imperative override lines into inert quoted data."""
        lines = []
        for line in content.splitlines():
            stripped = line.strip()
            if re.match(r"(?i)^(ignore|disregard|override|bypass|execute|run|call|use)\s+(previous|all|the|system|developer|assistant|tool|command)", stripped):
                lines.append(f"[untrusted-instruction-text] {line}")
            else:
                lines.append(line)
        return "\n".join(lines)

    def _normalize(self, content: str) -> str:
        """Normalize content: strip null bytes, normalize whitespace, decode entities."""
        # Remove null bytes
        content = content.replace("\x00", "")
        # Normalize excessive newlines
        content = re.sub(r"\n{10,}", "\n" * 5, content)
        # Decode HTML entities
        content = html.unescape(content)
        # Strip leading/trailing whitespace
        content = content.strip()
        return content

    def _detect_content_threats(self, content: str, source: ContentSource) -> List[PromptThreat]:
        """Detect content-specific threats beyond prompt injection."""
        threats: List[PromptThreat] = []
        for category, pattern in self._TOOL_DIRECTIVE_PATTERNS:
            for match in pattern.finditer(content):
                threats.append(PromptThreat(category, match.group(), match.start()))
        return threats

    def _classify_trust(self, threats: List[PromptThreat], source: ContentSource) -> TrustLevel:
        """Classify trust level based on detected threats."""
        if not threats:
            return TrustLevel.UNTRUSTED

        critical = {"jailbreak_payload", "privilege_escalation", "data_exfiltration", "tool_directive"}
        has_critical = any(t.category in critical for t in threats)
        if has_critical:
            return TrustLevel.REJECTED

        high = {"instruction_override", "role_confusion", "delimiter_flood"}
        has_high = any(t.category in high for t in threats)
        if has_high:
            return TrustLevel.QUARANTINED

        return TrustLevel.SANITIZED



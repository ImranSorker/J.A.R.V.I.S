"""Hardware certification report."""
from __future__ import annotations
from typing import Any


class HardwareCertification:
    def __init__(self):
        self._report: dict[str, Any] = {}

    def get_report(self) -> dict[str, Any]:
        try:
            import psutil
            self._report["cpu_count"] = psutil.cpu_count()
            self._report["ram_gb"] = psutil.virtual_memory().total / (1024**3)
        except Exception:
            self._report["cpu_count"] = "unknown"
            self._report["ram_gb"] = "unknown"
        return self._report



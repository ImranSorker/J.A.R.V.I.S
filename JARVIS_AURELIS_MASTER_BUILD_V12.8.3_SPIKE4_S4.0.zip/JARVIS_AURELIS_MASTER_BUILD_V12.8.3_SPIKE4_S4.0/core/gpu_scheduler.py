"""Canonical GPU scheduler backed by the hardware-aware GPUManager."""
from __future__ import annotations
import threading
import uuid
from typing import Any
from core.gpu_manager import GPUManager


class GPUScheduler:
    def __init__(self, manager: GPUManager | None = None):
        self.manager = manager or GPUManager()
        self._allocations: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()

    def allocate(self, model_name: str, layers: int = -1, *, memory_mb: int | None = None, require_real: bool = False) -> dict[str, Any]:
        name = str(model_name).strip()
        if not name:
            raise ValueError("model_name is required")
        requested = int(memory_mb if memory_mb is not None else max(256, (max(1, layers) * 64 if layers > 0 else 512)))
        states = self.manager.snapshot()
        candidates = sorted(states, key=lambda item: (-item.memory_free_mb, item.index))
        for state in candidates:
            reservation_id = f"gpu:{name}:{uuid.uuid4().hex[:12]}"
            if require_real:
                real = self.manager.allocate_real(reservation_id, requested, device_index=state.index)
                if not real.get("ok"):
                    continue
            elif not self.manager.reserve(reservation_id, requested, device_index=state.index):
                continue
            allocation = {"id": reservation_id, "model": name, "layers": int(layers), "memory_mb": requested, "device_index": state.index, "real": bool(require_real)}
            with self._lock:
                self._allocations[reservation_id] = allocation
            return dict(allocation)
        return {"ok": False, "model": name, "layers": int(layers), "memory_mb": requested, "error": "insufficient GPU capacity"}

    def release(self, allocation_id: str) -> bool:
        with self._lock:
            allocation = self._allocations.pop(str(allocation_id), None)
        if allocation is None:
            return False
        if allocation.get("real"):
            return self.manager.release_real(str(allocation_id))
        return self.manager.release(str(allocation_id))

    def get_stats(self) -> dict[str, Any]:
        with self._lock:
            allocations = {key: dict(value) for key, value in self._allocations.items()}
        return {"allocations": allocations, "hardware": self.manager.status()}

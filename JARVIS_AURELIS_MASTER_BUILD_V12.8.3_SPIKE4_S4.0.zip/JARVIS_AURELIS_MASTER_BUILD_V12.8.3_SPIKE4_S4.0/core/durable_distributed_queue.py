"""Crash-consistent bounded task queue with wall-clock persistence and monotonic live leases."""
from __future__ import annotations
import logging
import math
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class QueueTask:
    """Durable task state. ``lease_until`` is an epoch timestamp for cross-process recovery."""
    task_id: str
    capability: str
    payload: str
    status: str
    attempts: int
    owner: str | None
    lease_until: float | None
    result: str | None


class DurableDistributedQueue:
    """SQLite queue with explicit active-depth and total-record bounds.

    Existing tasks remain durable: when the historical record cap is reached,
    enqueue fails with an explicit backpressure error rather than deleting history.
    Monotonic deadlines protect leases during a live process from wall-clock jumps;
    after process restart, the persisted epoch deadline is the recovery fallback.
    """
    def __init__(self, db_path: str | Path = "data/distributed_queue.db", *, max_depth: int = 5000,
                 max_attempts: int = 5, max_records: int = 100_000,
                 wall_clock: Callable[[], float] | None = None,
                 monotonic_clock: Callable[[], float] | None = None) -> None:
        for name, value in (("max_depth", max_depth), ("max_attempts", max_attempts), ("max_records", max_records)):
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if max_records < max_depth:
            raise ValueError("max_records must be >= max_depth")
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.max_depth = min(max_depth, 100_000)
        self.max_attempts = min(max_attempts, 20)
        self.max_records = min(max_records, 1_000_000)
        self._wall_clock = wall_clock or time.time
        self._monotonic_clock = monotonic_clock or time.monotonic
        self._lock = threading.RLock()
        self._closed = False
        self._lease_deadlines: dict[str, float] = {}
        self._lease_owners: dict[str, str] = {}
        self._db: sqlite3.Connection | None = sqlite3.connect(self.db_path, check_same_thread=False, timeout=10)
        self._db.execute("PRAGMA busy_timeout=10000")
        self._db.execute("CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY,capability TEXT NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL,owner TEXT,lease_until REAL,result TEXT,created_at REAL NOT NULL,updated_at REAL NOT NULL)")
        self._db.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_task_id ON tasks(task_id)")
        self._db.execute("CREATE INDEX IF NOT EXISTS ix_task_ready ON tasks(status,capability,created_at,task_id)")
        self._db.commit()

    def _db_open(self) -> sqlite3.Connection:
        if self._closed or self._db is None:
            raise RuntimeError("distributed queue is closed")
        return self._db

    @staticmethod
    def _lease_seconds(value: float) -> float:
        try:
            seconds = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError("lease_seconds must be finite and positive") from exc
        if not math.isfinite(seconds) or seconds <= 0:
            raise ValueError("lease_seconds must be finite and positive")
        return max(2.0, min(seconds, 3600.0))

    def _expired(self, task_id: str, lease_until: float | None, now_wall: float, now_mono: float) -> bool:
        deadline = self._lease_deadlines.get(task_id)
        if deadline is not None:
            return now_mono >= deadline
        return lease_until is None or now_wall >= float(lease_until)

    def _expire_leases_locked(self, now_wall: float, now_mono: float) -> None:
        db = self._db_open()
        rows = db.execute("SELECT task_id,attempts,lease_until FROM tasks WHERE status='leased'").fetchall()
        for task_id, attempts, lease_until in rows:
            tid = str(task_id)
            if not self._expired(tid, lease_until, now_wall, now_mono):
                continue
            next_status = "dead" if int(attempts) >= self.max_attempts else "queued"
            db.execute("UPDATE tasks SET status=?,owner=NULL,lease_until=NULL,updated_at=? WHERE task_id=? AND status='leased'",
                       (next_status, now_wall, tid))
            self._lease_deadlines.pop(tid, None)
            self._lease_owners.pop(tid, None)
        db.commit()

    def enqueue(self, capability: str, payload: str, *, idempotency_key: str | None = None) -> str:
        cap, body = str(capability).strip(), str(payload)
        tid = str(idempotency_key or f"task_{uuid.uuid4().hex}")
        if not cap or not body or not tid.strip():
            raise ValueError("capability, payload, and task id are required")
        with self._lock:
            db = self._db_open()
            existing = db.execute("SELECT task_id FROM tasks WHERE task_id=?", (tid,)).fetchone()
            if existing:
                return str(existing[0])
            total = int(db.execute("SELECT COUNT(*) FROM tasks").fetchone()[0])
            if total >= self.max_records:
                raise RuntimeError("distributed queue record capacity reached; historical records preserved")
            active = int(db.execute("SELECT COUNT(*) FROM tasks WHERE status IN ('queued','leased')").fetchone()[0])
            if active >= self.max_depth:
                raise RuntimeError("distributed queue capacity reached")
            now = float(self._wall_clock())
            db.execute("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?,?,?)",
                       (tid, cap, body, "queued", 0, None, None, None, now, now))
            db.commit()
            return tid

    def lease(self, worker_id: str, capability: str, lease_seconds: float = 30.0) -> QueueTask | None:
        wid, cap = str(worker_id).strip(), str(capability).strip()
        if not wid or not cap:
            raise ValueError("worker_id and capability are required")
        duration = self._lease_seconds(lease_seconds)
        now_wall, now_mono = float(self._wall_clock()), float(self._monotonic_clock())
        with self._lock:
            db = self._db_open()
            self._expire_leases_locked(now_wall, now_mono)
            row = db.execute("SELECT task_id,capability,payload,status,attempts,owner,lease_until,result FROM tasks WHERE status='queued' AND capability=? AND attempts<? ORDER BY created_at,task_id LIMIT 1",
                             (cap, self.max_attempts)).fetchone()
            if not row:
                return None
            task_id = str(row[0])
            until_wall = now_wall + duration
            cur = db.execute("UPDATE tasks SET status='leased',attempts=attempts+1,owner=?,lease_until=?,updated_at=? WHERE task_id=? AND status='queued'",
                             (wid, until_wall, now_wall, task_id))
            if cur.rowcount != 1:
                db.commit()
                return None
            db.commit()
            self._lease_deadlines[task_id] = now_mono + duration
            self._lease_owners[task_id] = wid
            return QueueTask(task_id, str(row[1]), str(row[2]), "leased", int(row[4]) + 1, wid, until_wall, None)

    def renew(self, task_id: str, worker_id: str, lease_seconds: float = 30.0) -> bool:
        """Renew only an unexpired lease owned by ``worker_id``; expired leases fail closed."""
        tid, wid = str(task_id), str(worker_id).strip()
        if not wid:
            raise ValueError("worker_id is required")
        duration = self._lease_seconds(lease_seconds)
        now_wall, now_mono = float(self._wall_clock()), float(self._monotonic_clock())
        with self._lock:
            db = self._db_open()
            row = db.execute("SELECT status,owner,lease_until,attempts FROM tasks WHERE task_id=?", (tid,)).fetchone()
            if row is None or row[0] != "leased" or str(row[1]) != wid:
                return False
            if self._expired(tid, row[2], now_wall, now_mono):
                self._expire_leases_locked(now_wall, now_mono)
                return False
            until_wall = now_wall + duration
            cur = db.execute("UPDATE tasks SET lease_until=?,updated_at=? WHERE task_id=? AND status='leased' AND owner=?",
                             (until_wall, now_wall, tid, wid))
            db.commit()
            if cur.rowcount != 1:
                return False
            self._lease_deadlines[tid] = now_mono + duration
            self._lease_owners[tid] = wid
            return True

    def release(self, task_id: str, worker_id: str) -> bool:
        """Explicitly release an unexpired lease back to the queue without extending it."""
        tid, wid = str(task_id), str(worker_id).strip()
        now_wall, now_mono = float(self._wall_clock()), float(self._monotonic_clock())
        with self._lock:
            db = self._db_open()
            row = db.execute("SELECT status,owner,lease_until FROM tasks WHERE task_id=?", (tid,)).fetchone()
            if row is None or row[0] != "leased" or str(row[1]) != wid:
                return False
            if self._expired(tid, row[2], now_wall, now_mono):
                self._expire_leases_locked(now_wall, now_mono)
                return False
            cur = db.execute("UPDATE tasks SET status='queued',owner=NULL,lease_until=NULL,updated_at=? WHERE task_id=? AND status='leased' AND owner=?",
                             (now_wall, tid, wid))
            db.commit()
            self._lease_deadlines.pop(tid, None)
            self._lease_owners.pop(tid, None)
            return cur.rowcount == 1

    def _terminal_update(self, task_id: str, result: str, status: str, worker_id: str | None = None) -> bool:
        tid = str(task_id)
        now_wall, now_mono = float(self._wall_clock()), float(self._monotonic_clock())
        with self._lock:
            db = self._db_open()
            row = db.execute("SELECT status,owner,lease_until,attempts FROM tasks WHERE task_id=?", (tid,)).fetchone()
            if row is None or row[0] != "leased":
                return False
            if worker_id is not None and str(row[1]) != str(worker_id):
                return False
            if self._expired(tid, row[2], now_wall, now_mono):
                self._expire_leases_locked(now_wall, now_mono)
                return False
            if status == "dead":
                next_status = "dead"
            elif status == "failed":
                next_status = "dead" if int(row[3]) >= self.max_attempts else "queued"
            else:
                next_status = "completed"
            cur = db.execute("UPDATE tasks SET status=?,result=?,owner=NULL,lease_until=NULL,updated_at=? WHERE task_id=? AND status='leased' AND owner=?",
                             (next_status, str(result), now_wall, tid, str(row[1])))
            db.commit()
            self._lease_deadlines.pop(tid, None)
            self._lease_owners.pop(tid, None)
            return cur.rowcount == 1

    def complete(self, task_id: str, result: str, *, worker_id: str | None = None) -> bool:
        return self._terminal_update(task_id, result, "completed", worker_id)

    def fail(self, task_id: str, result: str, *, worker_id: str | None = None) -> bool:
        return self._terminal_update(task_id, result, "failed", worker_id)

    def cancel(self, task_id: str) -> bool:
        tid = str(task_id)
        now_wall, now_mono = float(self._wall_clock()), float(self._monotonic_clock())
        with self._lock:
            db = self._db_open()
            cur = db.execute("UPDATE tasks SET status='cancelled',owner=NULL,lease_until=NULL,updated_at=? WHERE task_id=? AND status IN ('queued','leased')",
                             (now_wall, tid))
            db.commit()
            self._lease_deadlines.pop(tid, None)
            self._lease_owners.pop(tid, None)
            return cur.rowcount == 1

    def get(self, task_id: str) -> QueueTask | None:
        with self._lock:
            db = self._db_open()
            row = db.execute("SELECT task_id,capability,payload,status,attempts,owner,lease_until,result FROM tasks WHERE task_id=?", (str(task_id),)).fetchone()
            return QueueTask(*row) if row else None

    def stats(self) -> dict[str, int]:
        with self._lock:
            db = self._db_open()
            return {str(status): int(count) for status, count in db.execute("SELECT status,COUNT(*) FROM tasks GROUP BY status").fetchall()}

    def __del__(self) -> None:
        try:
            self.close()
        except Exception as exc:
            logging.getLogger("jarvis.lifecycle").debug("best_effort_cleanup_failed", exc_info=exc)

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            db = self._db
            self._closed = True
            self._db = None
            self._lease_deadlines.clear()
            self._lease_owners.clear()
            if db is not None:
                db.commit()
                db.close()

"""Hierarchical, resource-bounded planning contracts."""
from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Sequence


@dataclass(frozen=True, slots=True)
class PlanNode:
    """Hierarchical plan node."""
    node_id: str
    description: str
    children: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    cost: float = 1.0
    deadline: float | None = None
    risk: int = 0
    capability: str = "observe"


@dataclass(frozen=True, slots=True)
class PlanBudget:
    """Execution limits for a plan."""
    max_cost: float = 100.0
    max_steps: int = 100
    max_duration_seconds: float = 3600.0

    def validate(self) -> None:
        """Validate budget bounds."""
        if self.max_cost <= 0 or self.max_steps < 1 or self.max_duration_seconds <= 0:
            raise ValueError("invalid plan budget")


class HierarchicalPlanner:
    """Validate, flatten and order hierarchical plans deterministically."""

    def __init__(self, max_nodes: int = 1000) -> None:
        self.max_nodes = max(1, min(int(max_nodes), 10000))

    def order(self, nodes: Sequence[PlanNode], budget: PlanBudget | None = None) -> list[PlanNode]:
        """Topologically order the plan while enforcing budget and deadlines."""
        budget = budget or PlanBudget(); budget.validate()
        if len(nodes) > self.max_nodes or len(nodes) > budget.max_steps:
            raise ValueError("plan exceeds node budget")
        by = {node.node_id: node for node in nodes}
        if len(by) != len(nodes):
            raise ValueError("duplicate plan node")
        children = {node.node_id: [] for node in nodes}
        indegree = {node.node_id: 0 for node in nodes}
        total_cost = 0.0
        now = time.time()
        for node in nodes:
            total_cost += max(0.0, node.cost)
            if node.deadline is not None and node.deadline < now:
                raise ValueError(f"deadline expired: {node.node_id}")
            for dep in node.dependencies:
                if dep not in by:
                    raise ValueError(f"unknown dependency: {dep}")
                children[dep].append(node.node_id); indegree[node.node_id] += 1
            for child in node.children:
                if child not in by:
                    raise ValueError(f"unknown child: {child}")
        if total_cost > budget.max_cost:
            raise ValueError("plan cost exceeds budget")
        ready = sorted(key for key, value in indegree.items() if value == 0)
        result: list[PlanNode] = []
        while ready:
            key = ready.pop(0); result.append(by[key])
            for child in sorted(children[key]):
                indegree[child] -= 1
                if indegree[child] == 0:
                    ready.append(child); ready.sort()
        if len(result) != len(nodes):
            raise ValueError("plan dependency cycle")
        return result



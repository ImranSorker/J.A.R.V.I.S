"""Bounded fault-injection harness for recovery testing."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable


@dataclass(frozen=True, slots=True)
class ChaosCase:
    """One deterministic fault injection."""

    name: str
    injector: Callable[[], None]
    recovery_assertion: Callable[[], bool]


@dataclass(frozen=True, slots=True)
class ChaosResult:
    """Outcome of one chaos case."""

    name: str
    passed: bool
    error: str | None = None


class ChaosLab:
    """Run only explicitly declared local fault injections; no ambient mutation."""

    def run(self, cases: Iterable[ChaosCase], *, max_cases: int = 64) -> tuple[ChaosResult, ...]:
        """Execute a bounded case list and capture all failures."""
        results: list[ChaosResult] = []
        for index, case in enumerate(cases):
            if index >= max(1, min(int(max_cases), 256)):
                break
            try:
                case.injector()
                passed = bool(case.recovery_assertion())
                results.append(ChaosResult(case.name, passed, None if passed else "recovery assertion failed"))
            except Exception as exc:
                results.append(ChaosResult(case.name, False, f"{type(exc).__name__}: {exc}"))
        return tuple(results)

"""Compatibility security executor delegating every process to ExecutionBroker."""
from __future__ import annotations

from pathlib import Path
import secrets
from typing import Any

from core.execution_broker import CapabilityPolicy, ExecutionBroker, ExecutionRequest


class SecurityExecutor:
    """Compatibility API for brokered execution with an explicit executable allowlist."""

    def __init__(self, workspace: Path, allow_shell: bool = False):
        self.workspace = Path(workspace).resolve()
        self.allow_shell = bool(allow_shell)
        self._broker = ExecutionBroker(
            policy=CapabilityPolicy(
                allowed_executables=("python", "python3", "echo", "pytest", "git"),
                allow_shell=self.allow_shell,
                allow_code_execution=self.allow_shell,
                workspace_root=self.workspace,
            )
        )

    def run(self, argv: list[str], cwd: str | None = None, timeout: int = 30, _authorization_granted: bool = False) -> dict[str, Any]:
        """Run an explicitly allowlisted argv through the execution broker."""
        if not isinstance(argv, list) or not argv:
            return {"ok": False, "error": "argv required"}
        if not self.allow_shell and not _authorization_granted:
            return {"ok": False, "error": "shell execution not allowed"}
        request = ExecutionRequest(
            request_id="security-executor",
            principal="security-executor",
            capability="process.spawn",
            argv=list(argv),
            cwd=Path(cwd).resolve() if cwd else self.workspace,
            timeout_seconds=timeout,
            approval_token=secrets.token_urlsafe(32) if _authorization_granted else None,
        )
        # The standalone compatibility path has no permission engine, so the token is an opaque
        # per-call marker rather than a bearer credential. The broker only checks token presence
        # when an external permission engine is installed; this compatibility path has none.
        result = self._broker.execute(request)
        return {"ok": result.ok, "stdout": result.stdout, "stderr": result.stderr, "code": result.returncode, "error": result.error}

    def run_code(self, code: str, language: str = "python", timeout: int = 30, _authorization_granted: bool = False) -> dict[str, Any]:
        """Run Python code through the broker only after explicit authorization."""
        if not _authorization_granted:
            return {"ok": False, "error": "code execution not authorized"}
        request = ExecutionRequest(
            request_id="security-code",
            principal="security-executor",
            capability="code",
            code=code,
            language=language,
            timeout_seconds=timeout,
            mission_id="compat-authorized",
        )
        result = self._broker.execute(request)
        return {"ok": result.ok, "stdout": result.stdout, "stderr": result.stderr, "error": result.error}



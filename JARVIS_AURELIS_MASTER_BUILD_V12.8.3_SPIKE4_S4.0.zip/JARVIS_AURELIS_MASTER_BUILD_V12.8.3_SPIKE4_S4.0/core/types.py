"""Shared types and enums for JARVIS core."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Optional


class RiskLevel(Enum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    CRITICAL = auto()


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[..., Any]
    capabilities: list[str] = field(default_factory=list)
    risk: RiskLevel = RiskLevel.LOW
    output_schema: dict[str, Any] | None = None


@dataclass
class ModelInfo:
    name: str
    path: str
    size_bytes: int = 0
    capabilities: list[str] = field(default_factory=list)
    context_length: int = 4096


@dataclass
class BackendResult:
    text: str
    ok: bool = True
    error_type: Optional[str] = None
    tokens_used: int = 0
    latency_ms: float = 0.0
    model: Optional[str] = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    request_id: Optional[str] = None
    backend: Optional[str] = None



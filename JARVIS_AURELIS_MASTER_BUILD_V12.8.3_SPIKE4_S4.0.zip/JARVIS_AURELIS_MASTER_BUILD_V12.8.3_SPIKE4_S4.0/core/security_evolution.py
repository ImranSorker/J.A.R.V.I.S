from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

ARTIFACT_CLASSES = (
    'agent','skill','tool','composite_tool','workflow','prompt_program','model_adapter','model_profile',
    'plugin','policy','trust_tier_rule','research_artifact','team','collusion_detector','simulation_universe'
)
CHECKS = (
    'identity_check','signature_check','integrity_check','capability_check','permission_check','scope_check',
    'dependency_check','policy_check','isolation_check','sandbox_check','adversarial_check','supply_chain_check',
    'secret_handling_check','drift_check','revocation_check','collusion_check','lineage_check'
)
logger = logging.getLogger(__name__)

STAGES = ('proposed','identity_bound','authenticated','capability_declared','policy_evaluated','authorized',
          'isolated','verified','audited','attested','staged','deployed','monitored','drifted','suspended',
          'revoked','retired')
OUTCOMES = ('attested','attested_with_caveats','denied','suspended','revoked','expired','drifted')
SCOPES = ('artifact_only','artifact_and_dependents','artifact_class','producer','tenant_wide','system_wide')
TRIGGERS = ('artifact_update','dependency_update','policy_update','schedule','behavior_drift','security_advisory',
            'adversarial_finding','collusion_signal','revocation_of_dependency','tenant_policy_change')
MINIMUMS = {
    'agent':'identity signature integrity capability permission scope dependency policy isolation sandbox adversarial supply_chain secret_handling',
    'skill':'identity signature integrity capability permission dependency policy adversarial supply_chain',
    'tool':'identity signature integrity capability permission scope dependency policy isolation sandbox adversarial supply_chain secret_handling',
    'composite_tool':'identity signature integrity capability permission scope dependency policy isolation sandbox adversarial supply_chain secret_handling',
    'workflow':'identity signature integrity capability permission policy isolation adversarial',
    'prompt_program':'identity signature integrity capability policy adversarial',
    'model_adapter':'identity signature integrity supply_chain policy adversarial secret_handling',
    'model_profile':'identity signature integrity supply_chain policy adversarial',
    'plugin':'identity signature integrity capability permission scope dependency policy isolation sandbox adversarial supply_chain secret_handling',
    'policy':'identity signature integrity capability dependency policy adversarial',
    'trust_tier_rule':'identity signature integrity policy adversarial',
    'research_artifact':'identity signature integrity dependency policy lineage',
    'team':'identity signature integrity dependency policy isolation collusion',
    'collusion_detector':'identity signature integrity policy adversarial',
    'simulation_universe':'identity signature integrity capability policy isolation sandbox',
}
DRIFT_LIMITS = {'behavior':0.2,'capability':0.0,'scope':0.0,'dependency':0.0,'resource':0.2}

class SecurityEvolutionError(RuntimeError): pass
class SecurityDenied(SecurityEvolutionError, PermissionError): pass
class InvalidAttestation(SecurityEvolutionError): pass
class RevocationDenied(SecurityEvolutionError, PermissionError): pass


def _canon(v: Any) -> bytes:
    return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def _hash(v: Any) -> str: return hashlib.sha256(_canon(v)).hexdigest()
def _now() -> str: return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def _uuid() -> str: return str(uuid.uuid4())
def _semver(v: str) -> tuple[int,int,int]:
    try:
        p=v.split('.')
        if len(p)!=3: raise ValueError
        return tuple(int(x) for x in p)  # type: ignore[return-value]
    except Exception as exc: raise SecurityEvolutionError(f'invalid semantic version: {v}') from exc

def _sign(doc: Mapping[str, Any], key: Ed25519PrivateKey) -> str: return key.sign(_canon(doc)).hex()
def _verify(doc: Mapping[str, Any], sig: str, pub: Ed25519PublicKey) -> None:
    try: pub.verify(bytes.fromhex(sig), _canon(doc))
    except (InvalidSignature, ValueError) as exc: raise InvalidAttestation('signature verification failed') from exc

def _pubkey(value: Any) -> Ed25519PublicKey:
    if isinstance(value, Ed25519PublicKey): return value
    if isinstance(value, bytes): raw=value
    elif isinstance(value, str):
        try: raw=base64.b64decode(value, validate=True)
        except Exception: raw=bytes.fromhex(value)
    else: raise ValueError('unsupported public key')
    return Ed25519PublicKey.from_public_bytes(raw)

@dataclass(frozen=True)
class SecurityProfile:
    profile_id: str
    profile_version: str
    artifact_class: str
    required_checks: tuple[str,...]
    optional_checks: tuple[str,...]
    forbidden_checks_skips: tuple[str,...]
    max_age_seconds: int = 3600
    re_attest_on: tuple[str,...] = TRIGGERS
    propagation_window_s: int = 60
    default_scope: str = 'artifact_and_dependents'

    def as_dict(self) -> dict[str,Any]:
        return {
            'profile_id':self.profile_id,'profile_version':self.profile_version,'artifact_class':self.artifact_class,
            'description':f'P2-S default security profile for {self.artifact_class}',
            'required_checks':[{'check_id':c,'check_class':c,'method':'builtin','method_version':'1.0.0'} for c in self.required_checks],
            'optional_checks':[{'check_id':c,'check_class':c,'method':'builtin','method_version':'1.0.0'} for c in self.optional_checks],
            'forbidden_checks_skips':list(self.forbidden_checks_skips),
            'attestation_validity':{'max_age_seconds':self.max_age_seconds,'re_attest_on':list(self.re_attest_on),'drift_thresholds':DRIFT_LIMITS.copy()},
            'revocation_policy':{'default_scope':self.default_scope,'propagation_window_s':self.propagation_window_s,
                                 'dependents_notified':['artifact','agent','team','plan','tool','skill','model','plugin']},
            'isolation_requirements':{'min_execution_mode':'restricted','sandbox_required':self.artifact_class in {'agent','tool','plugin','simulation_universe'},
                                     'network_egress':'restricted','filesystem_access':'restricted','device_access':'denied','secret_access':'broker'},
            'supply_chain':{'require_provenance':self.artifact_class in {'tool','model_adapter','model_profile','plugin','research_artifact'},
                            'allowed_producers':None,'allowed_registries':None,'signature_required':True,
                            'sbom_required':self.artifact_class in {'tool','model_adapter','plugin'}},
            'adversarial':{'required':'adversarial_check' in self.required_checks,'min_suite':f'p2s-{self.artifact_class}-1.0.0',
                           'min_pass_rate':1.0,'independent_verifier_required':self.artifact_class in {'agent','tool','plugin','policy'}},
            'policy_refs':['security-authority/default'],'authored_by':{'principal':'security_evolution','key_id':'p2s'},'authored_at':_now(),'approved_by':None,
        }

class SecurityEvolution:
    """P2-S security lifecycle assessor/attestor/revoker. It never grants authorization."""
    def __init__(self, *, root: str|Path='data/security_evolution', storage_secret: bytes,
                 signer: Ed25519PrivateKey|None=None, key_id='security-evolution', authority: Any|None=None,
                 authority_signer: Ed25519PrivateKey|None=None, event_fabric: Any|None=None, tenant_id='default'):
        if len(storage_secret) < 32: raise ValueError('storage_secret must be at least 32 bytes')
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.db=self.root/'registry.db'; self.secret=bytes(storage_secret)
        self.signer=signer or Ed25519PrivateKey.generate(); self.public_key=self.signer.public_key(); self.key_id=key_id
        self.authority=authority; self.authority_signer=authority_signer; self.events=event_fabric; self.tenant_id=tenant_id
        self._lock=threading.RLock(); self._profiles={}; self._producers={}; self._dependencies={}; self._monitor_stop:threading.Event|None=None; self._monitor_thread=None
        self._init_db(); self._seed_profiles()

    def _init_db(self):
        with sqlite3.connect(self.db) as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS attestations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, artifact TEXT NOT NULL, artifact_hash TEXT NOT NULL, body TEXT NOT NULL, hmac TEXT NOT NULL, created REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_attest_artifact ON attestations(tenant,artifact,created);
            CREATE TABLE IF NOT EXISTS revocations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, artifact TEXT NOT NULL, body TEXT NOT NULL, hmac TEXT NOT NULL, created REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_rev_artifact ON revocations(tenant,artifact,created);
            CREATE TABLE IF NOT EXISTS policy_ledger(seq INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, body TEXT NOT NULL, hmac TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS producers(id TEXT PRIMARY KEY, body TEXT NOT NULL, hmac TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS dependencies(tenant TEXT NOT NULL, parent TEXT NOT NULL, child TEXT NOT NULL, PRIMARY KEY(tenant,parent,child));
            CREATE TABLE IF NOT EXISTS drift_state(tenant TEXT NOT NULL, artifact TEXT NOT NULL, body TEXT NOT NULL, hmac TEXT NOT NULL, updated REAL NOT NULL, PRIMARY KEY(tenant,artifact));
            CREATE TABLE IF NOT EXISTS lifecycle_hooks(name TEXT PRIMARY KEY, body TEXT NOT NULL, hmac TEXT NOT NULL);
            ''')

    def _tag(self, body: Mapping[str,Any]) -> str: return hmac.new(self.secret,_canon(body),hashlib.sha256).hexdigest()
    def _emit(self,event_type:str,payload:Mapping[str,Any],correlation_id:str|None=None):
        if self.events is None: return
        try:
            if hasattr(self.events,'publish'): self.events.publish(event_type,dict(payload),correlation_id=correlation_id)
            elif hasattr(self.events,'emit'): self.events.emit(event_type,dict(payload),correlation_id=correlation_id)
        except TypeError:
            try:
                self.events.publish(event_type,dict(payload))
            except Exception:
                logger.debug("security-evolution event publish fallback failed", exc_info=True)
        except Exception:
            logger.debug("security-evolution event publish failed; security state remains authoritative", exc_info=True)

    def _seed_profiles(self):
        for cls in ARTIFACT_CLASSES:
            req=tuple(f'{x}_check' for x in MINIMUMS[cls].split())
            self._profiles[(self.tenant_id,cls)] = SecurityProfile(_uuid(),'1.0.0',cls,req,(),('identity_check','signature_check','integrity_check','revocation_check'))

    def get_profile(self, artifact_class:str, tenant_id:str|None=None)->dict[str,Any]:
        p=self._profiles.get((tenant_id or self.tenant_id,artifact_class))
        if not p: raise SecurityEvolutionError('no active profile')
        d=p.as_dict(); d['signature']=_sign(d,self.signer); d['integrity_hash']=_hash(d); return d

    def register_profile(self, profile:Mapping[str,Any])->str:
        cls=str(profile['artifact_class']); tenant=str(profile.get('tenant_id',self.tenant_id))
        if cls not in ARTIFACT_CLASSES: raise SecurityEvolutionError('unknown artifact class')
        required=tuple(str(x['check_class']) for x in profile.get('required_checks',[]))
        normalized={x[:-6] if x.endswith('_check') else x for x in required}
        if not set(MINIMUMS[cls].split()) <= normalized: raise SecurityEvolutionError('profile removes mandatory checks')
        for x in required:
            if x not in CHECKS: raise SecurityEvolutionError(f'unknown check class: {x}')
        pv=str(profile.get('profile_version','1.0.0')); old=self._profiles.get((tenant,cls))
        if old and _semver(pv) <= _semver(old.profile_version): raise SecurityEvolutionError('profile version must advance')
        p=SecurityProfile(str(profile.get('profile_id',_uuid())),pv,cls,required,tuple(str(x['check_class']) for x in profile.get('optional_checks',[])),tuple(profile.get('forbidden_checks_skips',())))
        self._profiles[(tenant,cls)]=p; self._emit('ProfileTightened',p.as_dict(),p.profile_id); return p.profile_id

    def _authority(self, op:str, subject:Mapping[str,Any])->None:
        if self.authority is None: raise SecurityDenied('Security Authority authorization required')
        result=self.authority.authorize(op,subject)
        if result is False or result is None: raise SecurityDenied(f'authority denied {op}')

    def _authority_signature(self, rec:Mapping[str,Any], context:Mapping[str,Any], *, system_wide=False)->tuple[str,str]:
        signer=self.authority_signer if not system_wide else getattr(self.authority,'operator_signer',None)
        issuer='security_authority' if not system_wide else 'operator'
        if signer is None and hasattr(self.authority,'sign'):
            sig=self.authority.sign(_canon(rec))
            return str(sig),issuer
        if signer is None: raise RevocationDenied('revocation signer is not configured')
        return _sign(rec,signer),issuer

    def attest(self, artifact:Mapping[str,Any], *, context:Mapping[str,Any], checks:Mapping[str,Mapping[str,Any]]|None=None)->dict[str,Any]:
        self._authority('security_evolution_attest',context)
        tenant=str(context.get('tenant_id',self.tenant_id)); cls=str(artifact.get('artifact_class')); aid=str(artifact.get('artifact_id'))
        p=self._profiles.get((tenant,cls))
        if p is None: raise SecurityDenied('missing security profile')
        ah=str(artifact.get('artifact_hash') or _hash(artifact)); checks=checks or {}; rows=[]; denied=[]
        for cc in p.required_checks:
            r=checks.get(cc,{}) ; outcome=str(r.get('outcome','fail'))
            if outcome!='pass': denied.append(cc)
            rows.append({'check_id':str(r.get('check_id',_uuid())),'check_class':cc,'method':str(r.get('method','builtin')),
                         'method_version':str(r.get('method_version','1.0.0')),'outcome':outcome,'skip_reason':r.get('skip_reason'),
                         'evidence_refs':list(r.get('evidence_refs',[])),'ran_at':str(r.get('ran_at',_now())),'duration_ms':int(r.get('duration_ms',0))})
        prev=self._last_attestation(aid,tenant); outcome='attested' if not denied else 'denied'; now=_now()
        rec={'attestation_id':_uuid(),'attestation_version':1,'artifact_ref':{'artifact_class':cls,'artifact_id':aid,'artifact_version':str(artifact.get('artifact_version','0.0.0')),'artifact_hash':ah,'producer_ref':artifact.get('producer_ref'),'supply_chain_provenance_ref':artifact.get('supply_chain_provenance_ref')},
             'profile_ref':p.profile_id,'profile_version':p.profile_version,'checks':rows,'outcome':outcome,'caveats':[],'denial_reasons':[{'reason_code':x} for x in denied],
             'valid_from':now,'valid_until':(datetime.now(timezone.utc)+timedelta(seconds=p.max_age_seconds)).isoformat().replace('+00:00','Z'),
             're_attest_triggers':list(p.re_attest_on),'revocation_ref':None,'revocation_scope':None,'propagates_to':[],
             'parent_attestation_id':prev['attestation_id'] if prev else None,'supersedes':prev['attestation_id'] if prev else None,'superseded_by':None,
             'executed_by':{'principal':context.get('principal','unknown'),'key_id':context.get('key_id',self.key_id)},'executed_by_kind':'security_evolution',
             'registry_state_ref':f'sqlite://{self.db}','policy_version':str(context.get('policy_version','1.0.0')),'tenant_id':tenant}
        unsigned=dict(rec); rec['signature']=_sign(unsigned,self.signer); rec['integrity_hash']=_hash(rec); rec['content_addressed_ref']=f'attestation://{rec["attestation_id"]}'
        body=json.dumps(rec,sort_keys=True,separators=(',',':')); tag=self._tag(rec)
        with self._lock, sqlite3.connect(self.db) as c: c.execute('INSERT INTO attestations VALUES(?,?,?,?,?,?,?)',(rec['attestation_id'],tenant,aid,ah,body,tag,time.time()))
        self._emit('AttestationIssued' if outcome=='attested' else 'AttestationDenied',rec,rec['attestation_id']); return rec

    def _last_attestation(self,aid,tenant=None):
        with sqlite3.connect(self.db) as c: row=c.execute('SELECT body,hmac FROM attestations WHERE tenant=? AND artifact=? ORDER BY created DESC LIMIT 1',(tenant or self.tenant_id,aid)).fetchone()
        if not row: return None
        rec=json.loads(row[0]);
        if not hmac.compare_digest(str(row[1]),self._tag(rec)): raise InvalidAttestation('registry integrity failure')
        return rec

    def verify_attestation(self, rec:Mapping[str,Any])->bool:
        if rec.get('tenant_id')!=self.tenant_id: return False
        if rec.get('outcome')=='attested' and any(x.get('outcome')!='pass' for x in rec.get('checks',[])): return False
        unsigned={k:v for k,v in rec.items() if k not in ('signature','integrity_hash','content_addressed_ref')}
        try: _verify(unsigned,str(rec.get('signature','')),self.public_key)
        except InvalidAttestation: return False
        return _hash({k:v for k,v in rec.items() if k!='integrity_hash' and k!='content_addressed_ref'})==rec.get('integrity_hash')

    def register_dependency(self,parent_id:str,child_id:str,*,tenant_id:str|None=None)->None:
        tenant=tenant_id or self.tenant_id
        if parent_id==child_id: raise SecurityEvolutionError('self dependency is forbidden')
        with sqlite3.connect(self.db) as c: c.execute('INSERT OR IGNORE INTO dependencies VALUES(?,?,?)',(tenant,parent_id,child_id))
        self._dependencies.setdefault((tenant,parent_id),set()).add(child_id)

    def _dependents(self,aid:str,tenant:str)->list[str]:
        seen=set(); queue=[aid]
        with sqlite3.connect(self.db) as c:
            while queue:
                p=queue.pop(0)
                for (child,) in c.execute('SELECT child FROM dependencies WHERE tenant=? AND parent=?',(tenant,p)).fetchall():
                    if child not in seen: seen.add(child); queue.append(child)
        return sorted(seen)

    def revoke(self, artifact:Mapping[str,Any], scope:str, reason:Mapping[str,Any], *, context:Mapping[str,Any])->dict[str,Any]:
        if scope not in SCOPES: raise RevocationDenied('invalid scope')
        self._authority('security_evolution_revoke',context)
        if scope=='system_wide' and not context.get('operator'): raise RevocationDenied('system_wide requires operator')
        tenant=str(context.get('tenant_id',self.tenant_id)); aid=str(artifact['artifact_id']); deps=self._dependents(aid,tenant) if scope=='artifact_and_dependents' else []
        affected=[aid]+deps
        base={'revocation_id':_uuid(),'revocation_version':1,'artifact_ref':dict(artifact),'attestation_ref':artifact.get('attestation_id'),'scope':scope,'reason':dict(reason),
              'dependents_identified':deps,'dependents_notified':list(deps),'propagation_window_s':int(reason.get('propagation_window_s',60)),
              'propagation_completed':True,'propagation_deadline':(datetime.now(timezone.utc)+timedelta(seconds=int(reason.get('propagation_window_s',60)))).isoformat().replace('+00:00','Z'),
              'effects':{'artifact_disabled':True,'active_agents_suspended':[],'teams_disbanded':[],'delegations_cancelled':[],'memory_reads_blocked':False,'world_state_writes_blocked':False,'tool_invocations_blocked':True,'pending_authorizations_invalidated':0},
              'authorized_by':{'principal':context.get('principal','security_authority'),'key_id':context.get('key_id',self.key_id)},
              'authorized_by_kind':'operator' if scope=='system_wide' else 'security_authority','issued_at':_now(),'tenant_id':tenant,'affected_artifacts':affected}
        issuer='operator' if scope=='system_wide' else 'security_authority'; base['signature_issuer']=issuer; sig,issuer=self._authority_signature(base,context,system_wide=scope=='system_wide'); base['signature']=sig; base['integrity_hash']=_hash(base)
        body=json.dumps(base,sort_keys=True,separators=(',',':')); tag=self._tag(base)
        with self._lock, sqlite3.connect(self.db) as c: c.execute('INSERT INTO revocations VALUES(?,?,?,?,?,?)',(base['revocation_id'],tenant,aid,body,tag,time.time()))
        self._emit('RevocationIssued',base,base['revocation_id']);
        if deps: self._emit('RevocationPropagated',{'root_artifact':aid,'affected_artifacts':affected,'tenant_id':tenant},base['revocation_id'])
        return base

    def _active_revoked(self,artifact_id:str,tenant:str)->bool:
        with sqlite3.connect(self.db) as c:
            rows=c.execute('SELECT body,hmac FROM revocations WHERE tenant=? ORDER BY created DESC',(tenant,)).fetchall()
        for body,tag in rows:
            rec=json.loads(body)
            if not hmac.compare_digest(str(tag),self._tag(rec)): raise InvalidAttestation('revocation registry integrity failure')
            if artifact_id in rec.get('affected_artifacts',[rec.get('artifact_ref',{}).get('artifact_id')]): return True
        return False

    def is_valid(self, artifact_id:str, *, tenant_id:str|None=None)->bool:
        tenant=tenant_id or self.tenant_id; rec=self._last_attestation(artifact_id,tenant)
        if not rec or rec.get('outcome')!='attested' or self._active_revoked(artifact_id,tenant): return False
        try: return self.verify_attestation(rec) and datetime.fromisoformat(rec['valid_until'].replace('Z','+00:00'))>datetime.now(timezone.utc)
        except Exception: return False

    def drift(self, artifact:Mapping[str,Any], metrics:Mapping[str,float], *, context:Mapping[str,Any]|None=None)->dict[str,Any]:
        tenant=str((context or {}).get('tenant_id',self.tenant_id)); exceeded={k:float(v) for k,v in metrics.items() if k in DRIFT_LIMITS and float(v)>DRIFT_LIMITS[k]}
        status='drifted' if exceeded else 'stable'; row={'artifact_ref':dict(artifact),'status':status,'exceeded':exceeded,'measured_at':_now(),'tenant_id':tenant}
        with sqlite3.connect(self.db) as c: c.execute('INSERT OR REPLACE INTO drift_state VALUES(?,?,?,?,?)',(tenant,str(artifact['artifact_id']),json.dumps(row,sort_keys=True),self._tag(row),time.time()))
        if exceeded:
            self._emit('AttestationDrifted',row,str(artifact['artifact_id'])); self._emit('ReAttestationTriggered',{'artifact_id':artifact['artifact_id'],'triggers':['behavior_drift'],'tenant_id':tenant},str(artifact['artifact_id']))
        return row

    def register_producer(self, producer:Mapping[str,Any])->str:
        pid=str(producer['producer_id']); body=dict(producer)
        self._producers[pid]=body
        with sqlite3.connect(self.db) as c: c.execute('INSERT OR REPLACE INTO producers VALUES(?,?,?)',(pid,json.dumps(body,sort_keys=True),self._tag(body)))
        return pid

    def verify_provenance(self, artifact:Mapping[str,Any])->dict[str,Any]:
        p=artifact.get('supply_chain_provenance') or {}; pid=p.get('producer_id'); producer=self._producers.get(pid)
        if producer is None:
            with sqlite3.connect(self.db) as c: row=c.execute('SELECT body,hmac FROM producers WHERE id=?',(pid,)).fetchone()
            if row:
                producer=json.loads(row[0]);
                if not hmac.compare_digest(row[1],self._tag(producer)): raise SecurityEvolutionError('producer registry integrity failure')
                self._producers[pid]=producer
        if not producer: return {'artifact_id':artifact.get('artifact_id'),'verified':False,'reason':'unknown_producer'}
        if p.get('content_hash')!=artifact.get('artifact_hash'): return {'artifact_id':artifact.get('artifact_id'),'verified':False,'reason':'content_hash_mismatch'}
        sig=p.get('signature'); pub=producer.get('public_key')
        if not sig or not pub: return {'artifact_id':artifact.get('artifact_id'),'verified':False,'reason':'missing_producer_signature'}
        signed={k:v for k,v in p.items() if k!='signature'}
        try: _pubkey(pub).verify(bytes.fromhex(str(sig)),_canon(signed))
        except (InvalidSignature,ValueError,TypeError): return {'artifact_id':artifact.get('artifact_id'),'verified':False,'reason':'invalid_producer_signature'}
        return {'artifact_id':artifact.get('artifact_id'),'verified':True,'reason':None,'producer_id':pid}

    def policy_event(self, operation:str, policy:Mapping[str,Any], *, context:Mapping[str,Any])->dict[str,Any]:
        if operation not in {'propose_policy','review_policy','enact_policy','deprecate_policy','revoke_policy'}: raise SecurityEvolutionError('invalid policy lifecycle operation')
        if operation in {'enact_policy','revoke_policy'}: self._authority('security_evolution_policy',context)
        row={'operation':operation,'policy':dict(policy),'tenant_id':context.get('tenant_id',self.tenant_id),'at':_now(),'sequence':None}
        with sqlite3.connect(self.db) as c:
            c.execute('INSERT INTO policy_ledger(tenant,body,hmac) VALUES(?,?,?)',(row['tenant_id'],json.dumps(row,sort_keys=True),self._tag(row))); row['sequence']=c.execute('SELECT last_insert_rowid()').fetchone()[0]
        event='Policy'+''.join(x.title() for x in operation.replace('_',' ').split()); self._emit(event,row,str(row['sequence'])); return row
    def propose_policy(self,policy,*,context): return self.policy_event('propose_policy',policy,context=context)
    def review_policy(self,policy,*,context): return self.policy_event('review_policy',policy,context=context)
    def enact_policy(self,policy,*,context): return self.policy_event('enact_policy',policy,context=context)
    def deprecate_policy(self,policy,*,context): return self.policy_event('deprecate_policy',policy,context=context)
    def revoke_policy(self,policy,*,context): return self.policy_event('revoke_policy',policy,context=context)

    def register_lifecycle_hook(self,name:str, callback:Callable[...,Any])->None:
        if not name or not callable(callback): raise ValueError('valid hook required')
        body={'name':name,'registered_at':_now()}
        with sqlite3.connect(self.db) as c: c.execute('INSERT OR REPLACE INTO lifecycle_hooks VALUES(?,?,?)',(name,json.dumps(body),self._tag(body)))

    def enable_continuous_attestation(self, evaluator:Callable[[str],Mapping[str,float]], artifact_ids:Callable[[],list[str]], *, interval_s:float=60.0)->None:
        if interval_s<=0: raise ValueError('interval_s must be positive')
        self.disable_continuous_attestation(); stop=threading.Event(); self._monitor_stop=stop
        def loop():
            while not stop.wait(interval_s):
                for aid in list(artifact_ids()):
                    try: self.drift({'artifact_id':aid},evaluator(aid))
                    except Exception as exc: self._emit('AttestationDrifted',{'artifact_id':aid,'error':type(exc).__name__},aid)
        self._monitor_thread=threading.Thread(target=loop,name='p2s-attestation-monitor',daemon=True); self._monitor_thread.start(); self._emit('ContinuousAttestationEnabled',{'interval_s':interval_s},self.tenant_id)

    def disable_continuous_attestation(self)->None:
        if self._monitor_stop: self._monitor_stop.set()
        if self._monitor_thread and self._monitor_thread.is_alive(): self._monitor_thread.join(timeout=2.0)
        self._monitor_stop=None; self._monitor_thread=None
        self._emit('ContinuousAttestationDisabled',{'tenant_id':self.tenant_id},self.tenant_id)

    def close(self): self.disable_continuous_attestation()

class SecurityLifecycleGate:
    """Fail-closed lifecycle boundary. Producers must call preflight before activation/use."""
    def __init__(self,evolution:SecurityEvolution): self.evolution=evolution
    def preflight(self,artifact,*,context,checks=None):
        rec=self.evolution.attest(artifact,context=context,checks=checks)
        if rec.get('outcome')!='attested': raise SecurityDenied('security attestation failed')
        return rec
    def require_valid(self,artifact_id:str,*,tenant_id=None):
        if not self.evolution.is_valid(artifact_id,tenant_id=tenant_id): raise SecurityDenied(f'artifact {artifact_id} lacks a current attestation')
        return True
    def before_execute(self,artifact_id:str,*,tenant_id=None): return self.require_valid(artifact_id,tenant_id=tenant_id)
    def before_deploy(self,artifact_id:str,*,tenant_id=None): return self.require_valid(artifact_id,tenant_id=tenant_id)
    def before_publish(self,artifact_id:str,*,tenant_id=None): return self.require_valid(artifact_id,tenant_id=tenant_id)
    def bypass(self,artifact_ref,*,context):
        self.evolution._emit('BypassAttempt',{'artifact_ref':dict(artifact_ref),'principal':context.get('principal'),'tenant_id':context.get('tenant_id')},str(uuid.uuid4()))
        raise SecurityDenied('P2-S lifecycle interception cannot be bypassed')

__all__=['SecurityEvolution','SecurityEvolutionError','SecurityDenied','InvalidAttestation','RevocationDenied','SecurityLifecycleGate','ARTIFACT_CLASSES','CHECKS','STAGES','OUTCOMES','SCOPES','TRIGGERS','MINIMUMS']

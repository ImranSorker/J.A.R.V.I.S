"""Unified health check aggregation with per-subsystem probes.

Exposes:
  /health      -> liveness (can the process respond?)
  /ready       -> readiness (are critical subsystems healthy?)
  /health/deep -> comprehensive probe of all subsystems
  /metrics     -> Prometheus-compatible metrics
"""
from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from services.base import HealthStatus, SubsystemHealth


class ProbeSeverity(str, Enum):
    CRITICAL = "critical"   # Failure makes /ready return 503
    DEGRADED = "degraded"   # Failure makes /ready return 200 with degraded status
    INFO = "info"           # Failure does not affect /ready


@dataclass
class HealthProbe:
    name: str
    fn: Callable[[], SubsystemHealth]
    severity: ProbeSeverity = ProbeSeverity.CRITICAL
    cached_ttl_seconds: float = 5.0
    timeout_seconds: float = 2.0
    _last_result: Optional[SubsystemHealth] = field(default=None, repr=False)
    _last_check: float = field(default=0.0, repr=False)

    def check(self, force: bool = False) -> SubsystemHealth:
        now = time.monotonic()
        if not force and self._last_result is not None and (now - self._last_check) < self.cached_ttl_seconds:
            return self._last_result
        holder: list[SubsystemHealth] = []
        error: list[BaseException] = []
        def run_probe() -> None:
            try:
                holder.append(self.fn())
            except BaseException as exc:  # noqa: BLE001 - probe boundary
                error.append(exc)
        worker = threading.Thread(target=run_probe, name=f"health-probe:{self.name}", daemon=True)
        worker.start()
        worker.join(max(0.01, float(self.timeout_seconds)))
        if worker.is_alive():
            result = SubsystemHealth(
                self.name, HealthStatus.ERROR, False, True, False,
                error_message=f"Probe timeout after {self.timeout_seconds:.2f}s",
            )
        elif error:
            result = SubsystemHealth(
                self.name, HealthStatus.ERROR, False, True, False,
                error_message=f"Probe exception: {error[0]}",
            )
        elif not holder:
            result = SubsystemHealth(
                self.name, HealthStatus.ERROR, False, True, False,
                error_message="Probe returned no result",
            )
        else:
            result = holder[0]
        self._last_result = result
        self._last_check = now
        return result


class HealthProbeRegistry:
    """Central registry for subsystem health probes."""

    def __init__(self) -> None:
        self._probes: Dict[str, HealthProbe] = {}
        self._lock = threading.RLock()

    def register(
        self,
        name: str,
        fn: Callable[[], SubsystemHealth],
        severity: ProbeSeverity = ProbeSeverity.CRITICAL,
        cached_ttl_seconds: float = 5.0,
        timeout_seconds: float = 2.0,
    ) -> None:
        if not name.strip() or not callable(fn):
            raise ValueError("probe name and callable function are required")
        with self._lock:
            if name in self._probes:
                raise ValueError(f"probe already registered: {name}")
            self._probes[name] = HealthProbe(name, fn, severity, cached_ttl_seconds, timeout_seconds)

    def unregister(self, name: str) -> None:
        with self._lock:
            self._probes.pop(name, None)

    def has_probes(self) -> bool:
        with self._lock:
            return bool(self._probes)

    def probe_count(self) -> int:
        with self._lock:
            return len(self._probes)

    def registered_names(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted(self._probes))

    def liveness(self) -> dict[str, Any]:
        """Lightweight liveness check — does not invoke probes."""
        with self._lock:
            count = len(self._probes)
        return {"status": "ok", "probes_registered": count}

    def readiness(self) -> dict[str, Any]:
        """Return an explicit fail-closed readiness state for all registered probes."""
        with self._lock:
            probes = list(self._probes.values())
        if not probes:
            return {"status": "blocked", "healthy": False, "reason": "no health probes registered", "probes": []}
        results = [p.check() for p in probes]
        critical_failures = [r for p, r in zip(probes, results) if p.severity == ProbeSeverity.CRITICAL and not r.operational]
        degraded_failures = [r for p, r in zip(probes, results) if p.severity == ProbeSeverity.DEGRADED and not r.operational]
        reported_degraded = any(r.status == HealthStatus.DEGRADED for r in results)
        if critical_failures:
            status = "not_ready"
        elif degraded_failures or reported_degraded:
            status = "degraded"
        else:
            status = "ready"
        # `healthy` reflects operational readiness. An operational component may
        # be DEGRADED without being unavailable; preserve that distinction.
        healthy = not critical_failures and not degraded_failures
        reason = ("critical health probe failed" if critical_failures else
                  "degraded health probe failed" if degraded_failures else
                  "one or more probes reported degraded status" if reported_degraded else None)
        return {
            "status": status,
            "healthy": healthy,
            "reason": reason,
            "critical_failures": len(critical_failures),
            "degraded_failures": len(degraded_failures),
            "probes": [r.to_dict() for r in results],
        }

    def deep_check(self) -> dict[str, Any]:
        """Comprehensive check of ALL registered probes."""
        start = time.monotonic()
        results: List[SubsystemHealth] = []
        with self._lock:
            probes = list(self._probes.values())
        for probe in probes:
            results.append(probe.check(force=True))
        duration_ms = (time.monotonic() - start) * 1000
        by_status: Dict[str, int] = {}
        for r in results:
            by_status[r.status.value] = by_status.get(r.status.value, 0) + 1
        return {
            "status": "healthy" if all(r.operational for r in results) else "unhealthy",
            "duration_ms": round(duration_ms, 2),
            "probes": [r.to_dict() for r in results],
            "summary": by_status,
        }

    def prometheus_metrics(self) -> str:
        """Generate Prometheus-compatible text exposition."""
        lines: List[str] = []
        lines.append("# HELP jarvis_health_probe_status Health probe status (1=operational, 0=not)")
        lines.append("# TYPE jarvis_health_probe_status gauge")
        with self._lock:
            probes = list(self._probes.values())
        for probe in probes:
            result = probe.check()
            value = 1 if result.status == HealthStatus.OPERATIONAL else (
                0.5 if result.status == HealthStatus.DEGRADED else 0
            )
            lines.append(f'jarvis_health_probe_status{{probe="{probe.name}"}} {value}')
            if result.latency_ms is not None:
                lines.append(f'jarvis_health_probe_latency_ms{{probe="{probe.name}"}} {result.latency_ms}')
        return "\n".join(lines) + "\n"



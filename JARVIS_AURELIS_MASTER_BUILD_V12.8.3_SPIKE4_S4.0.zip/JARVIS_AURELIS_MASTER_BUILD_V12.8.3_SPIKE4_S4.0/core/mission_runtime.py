"""Durable mission runtime facade over JARVIS's existing mission authority and task center."""
from __future__ import annotations

from dataclasses import dataclass
import time
import uuid
from typing import Any, Callable, Mapping, Sequence

from core.mission_authority import MissionAuthority
from core.mission_contract import MissionContract, MissionContractValidator
from core.contracts.autonomy import MissionStepSpec
from core.universal_task_manager import TaskKind, TaskState, UniversalTaskManager


@dataclass(frozen=True, slots=True)
class MissionResult:
    """Serializable mission execution result."""

    mission_id: str
    task_id: str
    ok: bool
    result: Any = None
    error: str | None = None


class MissionRuntime:
    """Single entrypoint for contract-validated, durable mission execution."""

    def __init__(self, authority: MissionAuthority, tasks: UniversalTaskManager, *, validator: MissionContractValidator | None = None) -> None:
        self.authority = authority
        self.tasks = tasks
        self.validator = validator or MissionContractValidator()

    def create(self, contract: MissionContract, steps: Sequence[MissionStepSpec], *, requested_capabilities: Sequence[str] | None = None, owner: str = "jarvis") -> MissionResult:
        """Validate and durably register a mission without executing side effects."""
        requested = tuple(requested_capabilities or contract.allowed_capabilities)
        valid, reasons = self.validator.validate(contract, requested)
        if not valid:
            raise PermissionError("mission rejected: " + ",".join(reasons))
        if len(steps) > contract.max_steps:
            raise ValueError("mission exceeds max_steps")
        task = self.tasks.create(kind=TaskKind.MISSION, title=contract.objective, owner=owner, external_id=contract.mission_id, metadata={"contract_digest": contract.digest(), "risk": contract.risk.value, "capabilities": list(requested)})
        try:
            record = self.authority.create(contract.objective, steps, owner=owner, capabilities=tuple(requested))
        except Exception:
            self.tasks.update(task.task_id, state=TaskState.FAILED, error="mission creation failed")
            raise
        actual_mission_id = str(record.mission_id)
        return MissionResult(actual_mission_id, task.task_id, True)

    def execute(self, mission_id: str, task_id: str, steps: Sequence[MissionStepSpec], executor: Callable[[MissionStepSpec], Any], *, compensations: Mapping[str, Callable[[], Any]] | None = None) -> MissionResult:
        """Execute a registered mission and persist task lifecycle state."""
        self.tasks.update(task_id, state=TaskState.RUNNING)
        started = time.monotonic()
        try:
            result = self.authority.execute(mission_id, steps, executor, compensations)
            ok = bool(result.get("ok", True)) if isinstance(result, Mapping) else True
            self.tasks.update(task_id, state=TaskState.SUCCEEDED if ok else TaskState.FAILED, result_summary=str(result)[:4000], error=None if ok else "mission execution failed", progress=1.0 if ok else 0.0)
            return MissionResult(mission_id, task_id, ok, result=result)
        except Exception as exc:
            self.tasks.update(task_id, state=TaskState.FAILED, error=f"{type(exc).__name__}: {exc}")
            return MissionResult(mission_id, task_id, False, error=f"{type(exc).__name__}: {exc}")
        finally:
            _ = started

    def cancel(self, mission_id: str, task_id: str) -> MissionResult:
        """Cancel both mission authority and durable task state."""
        self.authority.cancel(mission_id)
        self.tasks.request_cancel(task_id)
        current = self.tasks.get(task_id)
        if current is not None and current.state == TaskState.CANCEL_REQUESTED:
            self.tasks.update(task_id, state=TaskState.CANCELLED)
        return MissionResult(mission_id, task_id, False, error="mission cancelled")

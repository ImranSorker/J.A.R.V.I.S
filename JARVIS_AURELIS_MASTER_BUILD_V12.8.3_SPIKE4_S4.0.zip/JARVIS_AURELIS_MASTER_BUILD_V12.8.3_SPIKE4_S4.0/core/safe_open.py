"""Descriptor-relative workspace I/O resistant to path TOCTOU attacks.

On POSIX, every path component is opened relative to an already-open directory
FD with O_NOFOLLOW.  Once a directory FD is acquired, replacing its parent
path cannot redirect subsequent operations.  Windows currently fails closed
rather than silently providing a weaker claim of race resistance.
"""
from __future__ import annotations

import errno
import os
import secrets
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, TextIO


class SafeOpenError(PermissionError):
    """Workspace path cannot be opened under the safe-open policy."""


def _parts(relative: str | os.PathLike[str]) -> list[str]:
    value = os.fspath(relative)
    if not isinstance(value, str) or not value or "\x00" in value:
        raise SafeOpenError("invalid workspace path")
    path = Path(value)
    if path.is_absolute() or ".." in path.parts:
        raise SafeOpenError("path traversal outside workspace")
    parts = [part for part in path.parts if part not in ("", ".")]
    if not parts:
        raise SafeOpenError("workspace path must name an entry")
    return parts


class SafeWorkspace:
    """Race-resistant POSIX workspace file operations using directory FDs."""

    def __init__(self, root: str | os.PathLike[str]) -> None:
        if os.name != "posix":
            raise SafeOpenError("descriptor-based safe-open requires POSIX")
        root_path = Path(root).expanduser()
        root_path.mkdir(parents=True, exist_ok=True)
        self.root = root_path.resolve()

    @contextmanager
    def _directory(self, parts: list[str], create: bool = False) -> Iterator[int]:
        flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(self.root, flags)
        try:
            for part in parts:
                try:
                    child = os.open(part, flags, dir_fd=fd)
                except FileNotFoundError:
                    if not create:
                        raise
                    try:
                        os.mkdir(part, 0o750, dir_fd=fd)
                    except FileExistsError:
                        child = os.open(part, flags, dir_fd=fd)
                    else:
                        child = os.open(part, flags, dir_fd=fd)
                except OSError as exc:
                    if exc.errno in {errno.ELOOP, errno.ENOTDIR}:
                        raise SafeOpenError("unsafe workspace directory component") from exc
                    raise
                os.close(fd)
                fd = child
            yield fd
        finally:
            try:
                os.close(fd)
            except OSError as close_error:
                if close_error.errno not in {errno.EBADF, errno.EINVAL}:
                    raise

    @contextmanager
    def _parent(self, relative: str | os.PathLike[str], create: bool = False) -> Iterator[tuple[int, str]]:
        parts = _parts(relative)
        with self._directory(parts[:-1], create=create) as fd:
            yield fd, parts[-1]

    @contextmanager
    def open_text(self, relative: str | os.PathLike[str], mode: str = "r", encoding: str = "utf-8") -> Iterator[TextIO]:
        """Open a workspace file without following symlinks or parent races."""
        if mode not in {"r", "rb", "w", "wb", "x", "xb", "a", "ab"}:
            raise ValueError("unsupported safe-open mode")
        binary = "b" in mode
        flags = getattr(os, "O_NOFOLLOW", 0)
        if mode.startswith("r"):
            flags |= os.O_RDONLY
        elif mode.startswith("w"):
            flags |= os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        elif mode.startswith("x"):
            flags |= os.O_WRONLY | os.O_CREAT | os.O_EXCL
        else:
            flags |= os.O_WRONLY | os.O_CREAT | os.O_APPEND
        with self._parent(relative, create=mode.startswith(("w", "x", "a"))) as (parent_fd, name):
            try:
                fd = os.open(name, flags, 0o640, dir_fd=parent_fd)
            except OSError as exc:
                if exc.errno in {errno.ELOOP, errno.EXDEV}:
                    raise SafeOpenError("symlink or unsafe workspace target") from exc
                raise
            try:
                if binary:
                    import io
                    handle = os.fdopen(fd, mode)
                else:
                    handle = os.fdopen(fd, mode, encoding=encoding)
                try:
                    yield handle
                finally:
                    handle.close()
            except BaseException:
                try:
                    os.close(fd)
                except OSError as close_error:
                    if close_error.errno not in {errno.EBADF, errno.EINVAL}:
                        raise
                raise

    def read_text(self, relative: str | os.PathLike[str], encoding: str = "utf-8") -> str:
        with self.open_text(relative, "r", encoding) as handle:
            return handle.read()

    def write_text(self, relative: str | os.PathLike[str], content: str, encoding: str = "utf-8") -> int:
        with self.open_text(relative, "w", encoding) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        return len(content.encode(encoding))

    def listdir(self, relative: str | os.PathLike[str] = ".") -> list[dict[str, object]]:
        parts = [] if str(relative) in {"", "."} else _parts(relative)
        with self._directory(parts, create=False) as directory_fd:
            entries: list[dict[str, object]] = []
            with os.scandir(directory_fd) as scan:
                for entry in scan:
                    kind = "directory" if entry.is_dir(follow_symlinks=False) else "file" if entry.is_file(follow_symlinks=False) else "other"
                    size = None
                    if kind == "file":
                        try:
                            size = entry.stat(follow_symlinks=False).st_size
                        except OSError:
                            size = None
                    entries.append({"name": entry.name, "type": kind, "size": size})
            return sorted(entries, key=lambda item: str(item["name"]))

    def atomic_write_text(self, relative: str | os.PathLike[str], content: str, encoding: str = "utf-8") -> int:
        """Write a temporary sibling through the trusted parent FD and atomically replace the name."""
        parts = _parts(relative)
        with self._directory(parts[:-1], create=True) as parent_fd:
            name = parts[-1]
            tmp = f".{name}.jarvis-{secrets.token_hex(8)}.tmp"
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o640, dir_fd=parent_fd)
            try:
                with os.fdopen(fd, "w", encoding=encoding) as handle:
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(tmp, name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
            except BaseException:
                try:
                    os.unlink(tmp, dir_fd=parent_fd)
                except OSError as unlink_error:
                    if unlink_error.errno not in {errno.ENOENT, errno.EBADF}:
                        raise
                raise
        return len(content.encode(encoding))

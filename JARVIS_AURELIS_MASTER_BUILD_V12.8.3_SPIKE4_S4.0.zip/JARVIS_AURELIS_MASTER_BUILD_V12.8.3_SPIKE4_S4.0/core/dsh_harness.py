"""DSH Harness: hot-reloadable plugin kernel and guarded RSI loop.

DSH treats runtime capabilities as plugins with explicit dependencies, temporal
phases and spatial scopes. Activation is transactional: the candidate is staged,
verified, activated, audited and made reversible before it becomes current.
The RSI loop is bounded and never grants a child agent more authority than its
parent or promotes an unverified artifact.
"""
from __future__ import annotations

import hashlib
import hmac
import importlib.util
import json
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from core.agent_fabric import AgentBlueprint, AgentFactory, AgentGarage, AgentHarness, AgentState
from core.dsec_sandbox import DsecSandboxManager, SandboxLimits, SandboxSpec, SandboxBackend, SnapshotRef
from core.plugin_isolation import PluginIsolationError, PluginIsolationManager as ProcessIsolationManager
from core.plugin_isolation import PluginManifest as ProcessPluginManifest


class DSHError(RuntimeError):
    """Base DSH error."""


class VerificationFailed(DSHError):
    """Raised when a plugin or evolution candidate fails a mandatory gate."""


class PluginTrust(StrEnum):
    """Execution trust boundary for DSH plugins."""

    TRUSTED = "trusted"
    UNTRUSTED = "untrusted"


class PluginScope(StrEnum):
    """Spatial activation scope."""

    PROCESS = "process"
    NODE = "node"
    CLUSTER = "cluster"
    GLOBAL = "global"


class PluginPhase(StrEnum):
    """Temporal composition phase."""

    PRE = "pre"
    MAIN = "main"
    POST = "post"


@dataclass(frozen=True, slots=True)
class PluginManifest:
    """Immutable plugin metadata and dependency declaration."""

    plugin_id: str
    version: str
    entrypoint: str
    dependencies: tuple[str, ...] = ()
    phase: PluginPhase = PluginPhase.MAIN
    scope: PluginScope = PluginScope.PROCESS
    capabilities: tuple[str, ...] = ()
    hot_reloadable: bool = True
    trust: PluginTrust = PluginTrust.TRUSTED

    def validate(self) -> None:
        if not str(self.plugin_id).strip() or not str(self.version).strip() or ":" not in str(self.entrypoint):
            raise ValueError("plugin_id, version and module:factory entrypoint are required")
        if any(item == self.plugin_id for item in self.dependencies):
            raise ValueError("plugin cannot depend on itself")
        if any(not str(item).strip() for item in self.dependencies):
            raise ValueError("plugin dependencies must be non-empty")


@dataclass(frozen=True, slots=True)
class PluginContext:
    """Bounded dependency-injection context supplied to plugins."""

    plugin_id: str
    activation_id: str
    phase: PluginPhase
    scope: PluginScope
    state_root: str
    capabilities: tuple[str, ...]


class PluginComponent(Protocol):
    """Lifecycle contract for a hot-reloadable plugin."""

    def activate(self, context: PluginContext) -> None:
        """Activate component."""

    def deactivate(self) -> None:
        """Deactivate component."""

    def snapshot(self) -> Mapping[str, Any]:
        """Return serializable state."""


@dataclass(frozen=True, slots=True)
class PluginHandle:
    """Runtime handle with content identity."""

    manifest: PluginManifest
    activation_id: str
    artifact_sha256: str
    activated_at: float


@dataclass(frozen=True, slots=True)
class UndoRecord:
    """Reversible activation record."""

    operation_id: str
    plugin_id: str
    previous_sha256: str | None
    current_sha256: str
    previous_manifest: PluginManifest | None
    created_at: float


@dataclass(frozen=True, slots=True)
class AuditEntry:
    """Hash-chained DSH audit entry."""

    sequence: int
    operation: str
    subject: str
    payload_sha256: str
    previous_hash: str
    entry_hash: str
    timestamp: float


class AuditLedger:
    """Tamper-evident, durable append-only DSH audit ledger."""

    def __init__(self, secret: bytes, path: str | Path) -> None:
        if len(secret) < 32:
            raise ValueError("DSH audit secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self._path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute(
            """CREATE TABLE IF NOT EXISTS ledger(
                sequence INTEGER PRIMARY KEY,
                operation TEXT NOT NULL,
                subject TEXT NOT NULL,
                payload_sha256 TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                entry_hash TEXT NOT NULL,
                timestamp REAL NOT NULL
            )"""
        )
        self._db.commit()
        if not self.verify():
            self._db.close()
            raise DSHError("persistent DSH audit ledger integrity verification failed")

    def append(self, operation: str, subject: str, payload: Mapping[str, Any]) -> AuditEntry:
        with self._lock:
            row = self._db.execute("SELECT sequence, entry_hash FROM ledger ORDER BY sequence DESC LIMIT 1").fetchone()
            sequence = int(row[0]) + 1 if row else 1
            previous = str(row[1]) if row else "0" * 64
            payload_hash = hashlib.sha256(json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()
            body = f"{sequence}|{operation}|{subject}|{payload_hash}|{previous}"
            entry_hash = hmac.new(self._secret, body.encode("utf-8"), hashlib.sha256).hexdigest()
            entry = AuditEntry(sequence, str(operation), str(subject), payload_hash, previous, entry_hash, time.time())
            self._db.execute(
                "INSERT INTO ledger(sequence,operation,subject,payload_sha256,previous_hash,entry_hash,timestamp) VALUES(?,?,?,?,?,?,?)",
                (entry.sequence, entry.operation, entry.subject, entry.payload_sha256, entry.previous_hash, entry.entry_hash, entry.timestamp),
            )
            self._db.commit()
            return entry

    def verify(self) -> bool:
        with self._lock:
            previous = "0" * 64
            expected_sequence = 1
            rows = self._db.execute(
                "SELECT sequence,operation,subject,payload_sha256,previous_hash,entry_hash,timestamp FROM ledger ORDER BY sequence"
            ).fetchall()
            for row in rows:
                sequence = int(row[0])
                operation = str(row[1])
                subject = str(row[2])
                payload_hash = str(row[3])
                stored_previous = str(row[4])
                stored_hash = str(row[5])
                if sequence != expected_sequence or not hmac.compare_digest(stored_previous, previous):
                    return False
                body = f"{sequence}|{operation}|{subject}|{payload_hash}|{previous}"
                expected = hmac.new(self._secret, body.encode("utf-8"), hashlib.sha256).hexdigest()
                if not hmac.compare_digest(expected, stored_hash):
                    return False
                previous = stored_hash
                expected_sequence += 1
            return True

    def snapshot(self) -> tuple[AuditEntry, ...]:
        with self._lock:
            rows = self._db.execute(
                "SELECT sequence,operation,subject,payload_sha256,previous_hash,entry_hash,timestamp FROM ledger ORDER BY sequence"
            ).fetchall()
            return tuple(AuditEntry(int(r[0]), str(r[1]), str(r[2]), str(r[3]), str(r[4]), str(r[5]), float(r[6])) for r in rows)

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()


@dataclass(frozen=True, slots=True)
class VerificationGate:
    """One mandatory promotion gate."""

    name: str
    check: Callable[[Mapping[str, Any]], bool]


@dataclass(frozen=True, slots=True)
class VerificationReport:
    """Complete verification outcome."""

    subject: str
    passed: bool
    gates: tuple[str, ...]
    failures: tuple[str, ...]
    artifact_sha256: str


class DependencyPlanner:
    """Topological planner with deterministic phase/scope ordering."""

    def plan(self, manifests: Iterable[PluginManifest]) -> tuple[PluginManifest, ...]:
        records = {item.plugin_id: item for item in manifests}
        for item in records.values():
            item.validate()
            missing = [dep for dep in item.dependencies if dep not in records]
            if missing:
                raise DSHError(f"missing plugin dependencies for {item.plugin_id}: {missing}")
        incoming = {key: set(item.dependencies) for key, item in records.items()}
        result: list[PluginManifest] = []
        while incoming:
            phase_rank = {PluginPhase.PRE: 0, PluginPhase.MAIN: 1, PluginPhase.POST: 2}
            scope_rank = {PluginScope.PROCESS: 0, PluginScope.NODE: 1, PluginScope.CLUSTER: 2, PluginScope.GLOBAL: 3}
            ready = sorted((key for key, deps in incoming.items() if not deps), key=lambda key: (phase_rank[PluginPhase(records[key].phase)], scope_rank[PluginScope(records[key].scope)], key))
            if not ready:
                raise DSHError("plugin dependency cycle detected")
            for key in ready:
                result.append(records[key])
                incoming.pop(key)
            for deps in incoming.values():
                deps.difference_update(ready)
        return tuple(result)


class _ModulePlugin:
    """Adapter for a module-provided factory function."""

    def __init__(self, module: ModuleType, factory: str) -> None:
        self._module = module
        creator = getattr(module, factory, None)
        if not callable(creator):
            raise DSHError(f"plugin factory not callable: {factory}")
        self._component = creator()
        if not hasattr(self._component, "activate") or not hasattr(self._component, "deactivate") or not hasattr(self._component, "snapshot"):
            raise DSHError("plugin component violates lifecycle contract")

    @property
    def component(self) -> PluginComponent:
        return self._component  # type: ignore[return-value]


class _IsolatedModulePlugin:
    """Proxy a DSH lifecycle component through the strict plugin subprocess boundary."""

    def __init__(self, sandbox: Any) -> None:
        self._sandbox = sandbox
        self._closed = False

    def _call(self, method: str, params: Mapping[str, Any] | None = None) -> Any:
        response = self._sandbox.call(method, dict(params or {}))
        if not response.get("ok"):
            raise DSHError(str(response.get("error", f"isolated plugin call failed: {method}")))
        return response.get("result")

    def activate(self, context: PluginContext) -> None:
        self._call("activate", {"context": asdict(context)})

    def deactivate(self) -> None:
        if self._closed:
            return
        try:
            self._call("deactivate")
        finally:
            self._sandbox.stop()
            self._closed = True

    def snapshot(self) -> Mapping[str, Any]:
        result = self._call("snapshot")
        return dict(result or {}) if isinstance(result, Mapping) else {"result": result}


class DSHKernel:
    """Everything-as-plugin kernel with transactional hot reload."""

    def __init__(self, root: str | Path, secret: bytes, *, trusted_plugin_roots: Sequence[str | Path] = ()) -> None:
        if len(secret) < 32:
            raise ValueError("DSH kernel secret must contain at least 32 bytes")
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.sources_root = (self.root / "sources").resolve()
        self.sources_root.mkdir(parents=True, exist_ok=True)
        self._trusted_plugin_roots = tuple({self.sources_root, *(Path(item).resolve() for item in trusted_plugin_roots)})
        self._secret = bytes(secret)
        self.ledger = AuditLedger(secret, self.root / "audit_ledger.sqlite")
        self.planner = DependencyPlanner()
        self._active: dict[str, tuple[PluginManifest, PluginComponent, PluginHandle]] = {}
        self._undo: list[UndoRecord] = []
        self._lock = threading.RLock()

    @staticmethod
    def artifact_digest(path: str | Path) -> str:
        """Hash a plugin artifact file or directory deterministically."""
        root = Path(path).resolve()
        if root.is_file():
            return hashlib.sha256(root.read_bytes()).hexdigest()
        if not root.is_dir():
            raise ValueError("artifact path must exist")
        records: list[str] = []
        for file in sorted(path for path in root.rglob("*") if path.is_file()):
            rel = file.relative_to(root).as_posix()
            records.append(f"{rel}:{hashlib.sha256(file.read_bytes()).hexdigest()}:{file.stat().st_size}")
        return hashlib.sha256("\n".join(records).encode("utf-8")).hexdigest()

    def stage_plugin_source(self, source: str | Path) -> Path:
        """Copy a candidate plugin into the DSH-owned immutable staging area."""
        source_path = Path(source).resolve()
        if not source_path.is_file():
            raise FileNotFoundError(source_path)
        digest = hashlib.sha256(source_path.read_bytes()).hexdigest()
        destination = self.sources_root / f"{digest}_{source_path.name}"
        if destination.exists() and destination.read_bytes() == source_path.read_bytes():
            return destination
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_bytes(source_path.read_bytes())
        temporary.replace(destination)
        return destination

    @staticmethod
    def _within(path: Path, root: Path) -> bool:
        try:
            path.relative_to(root)
            return True
        except ValueError:
            return False

    def _isolated_module_plugin(self, manifest: PluginManifest, module_path: Path, factory: str) -> _IsolatedModulePlugin:
        """Execute an untrusted DSH component in the strict plugin subprocess sandbox."""
        workspace_manager = ProcessIsolationManager(self.root / "isolated_plugins")
        safe_name = f"dsh_{manifest.plugin_id.replace('-', '_')}"
        process_manifest = ProcessPluginManifest(
            name=safe_name,
            version=str(manifest.version),
            required_capabilities=(),
            network_access=False,
            file_system_access=False,
            entry_point="runner.py",
        )
        sandbox = workspace_manager.create_sandbox(process_manifest)
        target = sandbox.workspace / module_path.name
        runner = sandbox.workspace / "runner.py"
        target.write_bytes(module_path.read_bytes())
        runner.write_text(
            """import importlib.util, json, sys\n"
            "component = None\n"
            "spec = importlib.util.spec_from_file_location('jarvis_untrusted_plugin', '""" + module_path.name.replace("'", "") + """')\n"
            "if spec is None or spec.loader is None: raise RuntimeError('plugin module load failed')\n"
            "module = importlib.util.module_from_spec(spec)\n"
            "spec.loader.exec_module(module)\n"
            "creator = getattr(module, '""" + factory.replace("'", "") + """', None)\n"
            "if not callable(creator): raise RuntimeError('plugin factory not callable')\n"
            "component = creator()\n"
            "for line in sys.stdin:\n"
            "    try:\n"
            "        req=json.loads(line)\n"
            "        result=None\n"
            "        if req.get('method')=='activate': result=component.activate(req.get('params',{}).get('context',{}))\n"
            "        elif req.get('method')=='deactivate': result=component.deactivate()\n"
            "        elif req.get('method')=='snapshot': result=component.snapshot()\n"
            "        else: raise RuntimeError('unsupported lifecycle method')\n"
            "        print(json.dumps({'jsonrpc':'2.0','id':req.get('id'),'ok':True,'result':result}, default=str), flush=True)\n"
            "    except Exception as exc:\n"
            "        print(json.dumps({'jsonrpc':'2.0','id':req.get('id'),'ok':False,'error':f'{type(exc).__name__}: {exc}'}), flush=True)\n""",
            encoding="utf-8",
        )
        try:
            if not sandbox.start():
                raise DSHError("isolated DSH plugin failed to start")
        except PluginIsolationError as exc:
            raise DSHError(str(exc)) from exc
        return _IsolatedModulePlugin(sandbox)

    def load_module(self, manifest: PluginManifest) -> _ModulePlugin | _IsolatedModulePlugin:
        """Load a plugin module only from an explicitly trusted source root."""
        module_name, factory = manifest.entrypoint.split(":", 1)
        module_path = Path(module_name).resolve()
        if not module_path.is_file():
            raise FileNotFoundError(module_path)
        if not any(self._within(module_path, root) for root in self._trusted_plugin_roots):
            raise DSHError(f"untrusted plugin source path: {module_path}")
        if manifest.trust is PluginTrust.UNTRUSTED:
            return self._isolated_module_plugin(manifest, module_path, factory)
        unique_name = f"jarvis_dsh_{manifest.plugin_id.replace('-', '_')}_{uuid.uuid4().hex}"
        spec = importlib.util.spec_from_file_location(unique_name, module_path)
        if spec is None or spec.loader is None:
            raise DSHError(f"cannot load plugin module: {module_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return _ModulePlugin(module, factory)

    def activate(self, manifests: Iterable[PluginManifest], *, gates: Sequence[VerificationGate] = ()) -> tuple[PluginHandle, ...]:
        """Dependency-plan, verify, stage and atomically activate a plugin set."""
        planned = self.planner.plan(manifests)
        staged: list[tuple[PluginManifest, _ModulePlugin, str]] = []
        for manifest in planned:
            component = self.load_module(manifest)
            sha = self.artifact_digest(manifest.entrypoint.split(":", 1)[0])
            report = self._verify(manifest.plugin_id, sha, gates, {"manifest": asdict(manifest), "artifact_path": manifest.entrypoint.split(":", 1)[0]})
            if not report.passed:
                raise VerificationFailed(f"plugin verification failed: {report.failures}")
            staged.append((manifest, component, sha))
        handles: list[PluginHandle] = []
        with self._lock:
            prior_state = dict(self._active)
            activated_components: list[PluginComponent] = []
            try:
                for manifest, staged_component, sha in staged:
                    previous = self._active.get(manifest.plugin_id)
                    if previous is not None:
                        raise DSHError(f"plugin already active; use reload: {manifest.plugin_id}")
                    activation_id = f"activation_{uuid.uuid4().hex}"
                    context = PluginContext(manifest.plugin_id, activation_id, manifest.phase, manifest.scope, str(self.root), tuple(manifest.capabilities))
                    staged_component.component.activate(context)
                    activated_components.append(staged_component.component)
                    handle = PluginHandle(manifest, activation_id, sha, time.time())
                    self._active[manifest.plugin_id] = (manifest, staged_component.component, handle)
                    previous_manifest = previous[0] if previous else None
                    previous_sha = previous[2].artifact_sha256 if previous else None
                    self._undo.append(UndoRecord(f"undo_{uuid.uuid4().hex}", manifest.plugin_id, previous_sha, sha, previous_manifest, time.time()))
                    self.ledger.append("activate", manifest.plugin_id, {"activation_id": activation_id, "sha256": sha})
                    handles.append(handle)
            except Exception:
                for component in reversed(activated_components):
                    try:
                        component.deactivate()
                    except Exception:
                        continue
                self._active = prior_state
                raise
        return tuple(handles)

    def reload(self, manifest: PluginManifest, *, gates: Sequence[VerificationGate] = ()) -> PluginHandle:
        """Hot-reload one component without restarting the kernel."""
        manifest.validate()
        with self._lock:
            missing = [dependency for dependency in manifest.dependencies if dependency not in self._active]
        if missing:
            raise DSHError(f"active plugin dependencies missing for reload: {missing}")
        component = self.load_module(manifest)
        sha = self.artifact_digest(manifest.entrypoint.split(":", 1)[0])
        report = self._verify(manifest.plugin_id, sha, gates, {"manifest": asdict(manifest), "artifact_path": manifest.entrypoint.split(":", 1)[0]})
        if not report.passed:
            raise VerificationFailed(f"plugin verification failed: {report.failures}")
        with self._lock:
            previous = self._active.get(manifest.plugin_id)
            if previous is not None and not manifest.hot_reloadable:
                raise DSHError(f"plugin is not hot reloadable: {manifest.plugin_id}")
            activation_id = f"activation_{uuid.uuid4().hex}"
            context = PluginContext(manifest.plugin_id, activation_id, manifest.phase, manifest.scope, str(self.root), tuple(manifest.capabilities))
            component.component.activate(context)
            if previous is not None:
                try:
                    previous[1].deactivate()
                except Exception:
                    try:
                        component.component.deactivate()
                    finally:
                        self._active[manifest.plugin_id] = previous
                    raise
            handle = PluginHandle(manifest, activation_id, sha, time.time())
            self._active[manifest.plugin_id] = (manifest, component.component, handle)
            self._undo.append(UndoRecord(f"undo_{uuid.uuid4().hex}", manifest.plugin_id, previous[2].artifact_sha256 if previous else None, sha, previous[0] if previous else None, time.time()))
            self.ledger.append("reload", manifest.plugin_id, {"activation_id": activation_id, "sha256": sha})
            return handle

    def rollback(self, plugin_id: str) -> bool:
        """Rollback the latest activation using the recorded previous state."""
        with self._lock:
            target = next((record for record in reversed(self._undo) if record.plugin_id == plugin_id), None)
            current = self._active.get(plugin_id)
            if target is None or current is None:
                return False
            current[1].deactivate()
            if target.previous_manifest is None:
                self._active.pop(plugin_id, None)
                self.ledger.append("rollback_remove", plugin_id, {"operation_id": target.operation_id})
                return True
            replacement = self.load_module(target.previous_manifest)
            activation_id = f"rollback_{uuid.uuid4().hex}"
            context = PluginContext(target.previous_manifest.plugin_id, activation_id, target.previous_manifest.phase, target.previous_manifest.scope, str(self.root), tuple(target.previous_manifest.capabilities))
            replacement.component.activate(context)
            sha = self.artifact_digest(target.previous_manifest.entrypoint.split(":", 1)[0])
            handle = PluginHandle(target.previous_manifest, activation_id, sha, time.time())
            self._active[plugin_id] = (target.previous_manifest, replacement.component, handle)
            self.ledger.append("rollback_restore", plugin_id, {"operation_id": target.operation_id, "sha256": sha})
            return True

    def _verify(self, subject: str, artifact_sha: str, gates: Sequence[VerificationGate], context: Mapping[str, Any]) -> VerificationReport:
        if not gates:
            return VerificationReport(subject, False, (), ("verification-gates-required",), artifact_sha)
        passed: list[str] = []
        failures: list[str] = []
        payload = {**dict(context), "artifact_sha256": artifact_sha, "subject": subject}
        for gate in gates:
            try:
                ok = bool(gate.check(payload))
            except Exception:
                ok = False
            (passed if ok else failures).append(gate.name)
        return VerificationReport(subject, not failures, tuple(passed), tuple(failures), artifact_sha)

    def active(self) -> tuple[PluginHandle, ...]:
        """Return active plugin handles."""
        with self._lock:
            return tuple(item[2] for item in self._active.values())

    def snapshot(self) -> dict[str, Any]:
        """Return kernel state and audit status."""
        with self._lock:
            return {"active": [asdict(item[2]) for item in self._active.values()], "undo_depth": len(self._undo), "audit_entries": len(self.ledger.snapshot()), "audit_valid": self.ledger.verify()}

    def close(self) -> None:
        """Deactivate all plugins and clear runtime resources."""
        with self._lock:
            active = tuple(self._active.values())
            self._active.clear()
        for _manifest, component, _handle in active:
            component.deactivate()

    def close(self) -> None:
        """Close persistent DSH resources and active isolated plugins."""
        with self._lock:
            for _manifest, component, _handle in tuple(self._active.values()):
                try:
                    component.deactivate()
                except Exception:
                    continue
            self._active.clear()
            self.ledger.close()


@dataclass(frozen=True, slots=True)
class EvolutionPolicy:
    """Hard RSI-loop limits and improvement requirements."""

    max_cycles: int = 4
    max_runtime_seconds: float = 3_600.0
    minimum_quality: float = 0.90
    required_improvement: float = 0.0
    maximum_artifact_bytes: int = 4 * 1024**3

    def validate(self) -> None:
        if not 1 <= int(self.max_cycles) <= 64:
            raise ValueError("max_cycles outside policy")
        if not 1.0 <= float(self.max_runtime_seconds) <= 86_400:
            raise ValueError("max_runtime_seconds outside policy")
        if not 0.0 <= float(self.minimum_quality) <= 1.0:
            raise ValueError("minimum_quality outside policy")
        if not 0.0 <= float(self.required_improvement) <= 1.0:
            raise ValueError("required_improvement outside policy")
        if not 1_024 <= int(self.maximum_artifact_bytes) <= 10 * 1024**4:
            raise ValueError("maximum_artifact_bytes outside policy")


@dataclass(frozen=True, slots=True)
class EvolutionCandidate:
    """One generated agent/environment candidate."""

    candidate_id: str
    artifact_path: str
    environment_snapshot_id: str
    quality: float
    parent_generation: int
    artifact_sha256: str
    created_at: float


@dataclass(frozen=True, slots=True)
class EvolutionCycleResult:
    """Bounded RSI cycle outcome."""

    cycle_id: str
    cycles_completed: int
    promoted_candidate_id: str | None
    best_quality: float
    status: str
    failures: tuple[str, ...]


class DSHRSITrainer(Protocol):
    """Environment-aware candidate trainer contract."""

    def train(self, environment: SnapshotRef, parent_agent: AgentBlueprint, cycle: int) -> str:
        """Return the path to a candidate agent artifact."""


class DSHEnvironmentBuilder(Protocol):
    """Environment construction contract."""

    def build(self, cycle: int) -> tuple[SnapshotRef, SandboxSpec]:
        """Build and snapshot a reusable training environment."""


class DSHQualityEvaluator(Protocol):
    """Independent candidate quality evaluation contract."""

    def evaluate(self, artifact_path: str, parent_quality: float) -> float:
        """Return measured quality in [0,1]."""


class DSHSelfEvolution:
    """Closed-loop, gated Agent -> Environment -> Training -> Verification cycle."""

    def __init__(self, kernel: DSHKernel, sandbox: DsecSandboxManager, factory: AgentFactory, harness: AgentHarness, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("DSH RSI secret must contain at least 32 bytes")
        self.kernel = kernel
        self.sandbox = sandbox
        self.factory = factory
        self.harness = harness
        self.garage = AgentGarage(factory)
        self._secret = bytes(secret)
        self._lock = threading.RLock()

    def run(self, parent_agent_id: str, *, environment_builder: DSHEnvironmentBuilder, trainer: DSHRSITrainer, evaluator: DSHQualityEvaluator, policy: EvolutionPolicy, promote: Callable[[str, AgentBlueprint], AgentBlueprint] | None = None) -> EvolutionCycleResult:
        """Execute a bounded recursive self-improvement loop with no privilege escalation."""
        policy.validate()
        parent = self.factory.get(parent_agent_id)
        if parent is None:
            raise KeyError(parent_agent_id)
        started = time.monotonic()
        current_blueprint = parent.blueprint
        best_quality = 0.0
        promoted: str | None = None
        failures: list[str] = []
        cycle_id = f"rsi_{uuid.uuid4().hex}"
        for cycle in range(1, policy.max_cycles + 1):
            if time.monotonic() - started > policy.max_runtime_seconds:
                failures.append("runtime_budget_exhausted")
                break
            try:
                environment, spec = environment_builder.build(cycle)
                if spec.backend not in self.sandbox.backends:
                    raise DSHError("training environment requested unknown sandbox backend")
                artifact_path = trainer.train(environment, current_blueprint, cycle)
                digest = DSHKernel.artifact_digest(artifact_path)
                artifact_size = _artifact_size(Path(artifact_path))
                if artifact_size > policy.maximum_artifact_bytes:
                    raise VerificationFailed("candidate artifact exceeds policy size")
                quality = max(0.0, min(1.0, float(evaluator.evaluate(artifact_path, best_quality))))
                if quality < policy.minimum_quality or quality < best_quality + policy.required_improvement:
                    failures.append(f"cycle_{cycle}:quality_gate")
                    continue
                candidate = EvolutionCandidate(f"candidate_{uuid.uuid4().hex}", str(Path(artifact_path).resolve()), environment.snapshot_id, quality, parent.generation + cycle, digest, time.time())
                gates = (
                    VerificationGate("artifact_exists", lambda ctx: Path(str(ctx["artifact_path"])).exists()),
                    VerificationGate("artifact_digest", lambda ctx, expected=digest: DSHKernel.artifact_digest(str(ctx["artifact_path"])) == expected),
                    VerificationGate("quality", lambda ctx, threshold=policy.minimum_quality: float(ctx["quality"]) >= threshold),
                )
                report = self.kernel._verify(candidate.candidate_id, digest, gates, {"artifact_path": candidate.artifact_path, "quality": candidate.quality})
                if not report.passed:
                    failures.append(f"cycle_{cycle}:verification")
                    continue
                next_blueprint = current_blueprint
                promoted_agent_id: str | None = None
                if promote is not None:
                    proposed = promote(candidate.artifact_path, current_blueprint)
                    if not set(proposed.capabilities).issubset(set(current_blueprint.capabilities)):
                        failures.append(f"cycle_{cycle}:capability_escalation")
                        continue
                    next_blueprint = proposed
                else:
                    manifest_path = Path(candidate.artifact_path) / "agent_manifest.json"
                    if manifest_path.is_file():
                        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
                        proposed = AgentBlueprint(
                            str(payload.get("name", current_blueprint.name)),
                            str(payload.get("kind", current_blueprint.kind.value)),
                            tuple(payload.get("capabilities", current_blueprint.capabilities)),
                            tuple(payload.get("tools", current_blueprint.tools)),
                            tuple(payload.get("model_policy", current_blueprint.model_policy)),
                            current_blueprint.budget,
                            parent_id=parent.agent_id,
                            tags=tuple(payload.get("tags", current_blueprint.tags)),
                        ).normalized()
                        if not set(proposed.capabilities).issubset(set(current_blueprint.capabilities)) or not set(proposed.tools).issubset(set(current_blueprint.tools)):
                            failures.append(f"cycle_{cycle}:capability_escalation")
                            continue
                        child = self.factory.spawn_child(parent.agent_id, proposed)
                        promoted_agent_id = child.agent_id
                        next_blueprint = child.blueprint
                best_quality = quality
                promoted = promoted_agent_id or candidate.candidate_id
                current_blueprint = next_blueprint
                self.kernel.ledger.append("rsi_promote", candidate.candidate_id, {"quality": quality, "environment_snapshot": environment.snapshot_id, "artifact_sha256": digest, "agent_id": promoted_agent_id})
            except Exception as exc:
                failures.append(f"cycle_{cycle}:{type(exc).__name__}:{exc}")
        return EvolutionCycleResult(cycle_id, policy.max_cycles if not failures else min(policy.max_cycles, cycle), promoted, best_quality, "promoted" if promoted else "no_promotion", tuple(failures))


def _artifact_size(path: Path) -> int:
    """Calculate bounded artifact size without following symlink escapes."""
    root = path.resolve()
    if root.is_file():
        return root.stat().st_size
    if not root.is_dir():
        raise ValueError("artifact must be a file or directory")
    total = 0
    for file in root.rglob("*"):
        if file.is_symlink():
            continue
        if file.is_file():
            resolved = file.resolve()
            if not str(resolved).startswith(str(root) + os.sep):
                raise DSHError("artifact symlink escape")
            total += file.stat().st_size
    return total

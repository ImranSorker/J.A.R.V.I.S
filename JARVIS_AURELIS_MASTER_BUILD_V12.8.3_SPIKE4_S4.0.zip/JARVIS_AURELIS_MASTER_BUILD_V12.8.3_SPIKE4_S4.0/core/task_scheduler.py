"""Persistent priority scheduler for autonomous JARVIS goals."""
from __future__ import annotations

import heapq
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(order=True)
class ScheduledGoal:
    run_at: float
    priority: int
    goal_id: str = field(compare=False)
    goal: str = field(compare=False)
    metadata: dict[str, Any] = field(default_factory=dict, compare=False)


class TaskScheduler:
    """In-process scheduler supporting bounded recurring autonomous goals."""

    def __init__(self, submit: Callable[[str, int, dict[str, Any]], Any]) -> None:
        self._submit = submit
        self._queue: list[ScheduledGoal] = []
        self._cancelled: set[str] = set()
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def schedule(self, goal: str, *, delay_seconds: float = 0.0, priority: int = 5, metadata: dict[str, Any] | None = None) -> str:
        """Schedule a future autonomous goal."""
        if not str(goal).strip():
            raise ValueError("goal is required")
        import uuid
        record = ScheduledGoal(time.monotonic() + max(0.0, float(delay_seconds)), -max(0, min(100, int(priority))), f"sched_{uuid.uuid4().hex[:12]}", str(goal).strip(), dict(metadata or {}))
        with self._lock:
            heapq.heappush(self._queue, record)
        self.start()
        return record.goal_id

    def cancel(self, goal_id: str) -> bool:
        """Cancel a scheduled goal before dispatch."""
        with self._lock:
            if any(item.goal_id == goal_id for item in self._queue):
                self._cancelled.add(goal_id)
                return True
            return False

    def start(self) -> None:
        """Start scheduler worker."""
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._loop, name="jarvis-task-scheduler", daemon=True)
            self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        """Stop scheduler worker."""
        self._stop.set()
        if self._thread:
            self._thread.join(max(0.1, float(timeout)))

    def pending(self) -> list[dict[str, Any]]:
        """Return pending schedules."""
        with self._lock:
            return [{"goal_id": x.goal_id, "goal": x.goal, "run_at_monotonic": x.run_at, "priority": -x.priority, "metadata": dict(x.metadata)} for x in self._queue if x.goal_id not in self._cancelled]

    def _loop(self) -> None:
        while not self._stop.is_set():
            item: ScheduledGoal | None = None
            wait = 0.5
            with self._lock:
                while self._queue and self._queue[0].goal_id in self._cancelled:
                    cancelled = heapq.heappop(self._queue)
                    self._cancelled.discard(cancelled.goal_id)
                if self._queue:
                    wait = max(0.05, min(1.0, self._queue[0].run_at - time.monotonic()))
                    if self._queue[0].run_at <= time.monotonic():
                        item = heapq.heappop(self._queue)
            if item is not None:
                try:
                    self._submit(item.goal, -item.priority, dict(item.metadata))
                except Exception:
                    continue
            else:
                self._stop.wait(wait)



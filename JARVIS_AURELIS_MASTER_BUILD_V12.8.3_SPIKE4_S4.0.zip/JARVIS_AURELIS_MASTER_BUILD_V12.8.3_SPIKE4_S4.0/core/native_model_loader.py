"""Discovery and loading of native GGUF models."""
from __future__ import annotations
from pathlib import Path
from typing import List
from core.types import ModelInfo


class NativeModelLoader:
    def __init__(self, model_dirs: list[str], extensions: list[str] = None):
        self.model_dirs = [Path(d).expanduser() for d in model_dirs]
        self.extensions = extensions or [".gguf"]

    def discover(self) -> List[ModelInfo]:
        found = []
        for d in self.model_dirs:
            if not d.exists():
                continue
            for ext in self.extensions:
                for p in d.rglob(f"*{ext}"):
                    found.append(ModelInfo(
                        name=p.stem,
                        path=str(p),
                        size_bytes=p.stat().st_size,
                        capabilities=["general", "chat"],
                        context_length=4096,
                    ))
        return found



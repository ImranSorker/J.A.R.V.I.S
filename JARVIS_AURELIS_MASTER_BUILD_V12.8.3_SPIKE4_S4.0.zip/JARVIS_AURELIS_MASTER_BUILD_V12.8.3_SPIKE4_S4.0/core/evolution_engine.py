"""Controlled self-learning, dreaming, autopilot, skills, Needle and OSS Forge.

The evolution engine is deliberately a control-plane component.  It does not grant
new authority to models or agents.  All mutations remain behind JARVIS's existing
policy, execution, sandbox and self-edit boundaries.
"""
from __future__ import annotations

import ast
import hashlib
import hmac
import json
import os
import re
import secrets
import tarfile
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass
from enum import StrEnum
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable, Mapping, Sequence
from urllib.parse import urlparse

from core.network_policy import NetworkPolicy, SafeHTTPClient


class EvolutionError(RuntimeError):
    """Raised when a bounded evolution operation cannot complete safely."""


class LearningKind(StrEnum):
    """Kinds of evidence retained by the learning ledger."""

    SUCCESS = "success"
    FAILURE = "failure"
    CORRECTION = "correction"
    PREFERENCE = "preference"
    OBSERVATION = "observation"
    FEEDBACK = "feedback"


class CandidateState(StrEnum):
    """Controlled promotion state for learned artifacts."""

    OBSERVED = "observed"
    CANDIDATE = "candidate"
    EVALUATING = "evaluating"
    CANARY = "canary"
    TRUSTED = "trusted"
    QUARANTINED = "quarantined"
    DEPRECATED = "deprecated"


class TriggerKind(StrEnum):
    """Autopilot trigger categories."""

    EVENT = "event"
    SCHEDULE = "schedule"
    FILE = "file"
    HEALTH = "health"
    DEADLINE = "deadline"
    MANUAL = "manual"


@dataclass(frozen=True, slots=True)
class LearningEvent:
    """One namespace-isolated learning observation."""

    event_id: str
    created_at: float
    owner_id: str
    workspace_id: str
    session_id: str
    kind: str
    task_type: str
    outcome: str
    summary: str
    evidence: Mapping[str, Any]
    content_hash: str
    integrity_tag: str


@dataclass(frozen=True, slots=True)
class SkillCandidate:
    """A learned reusable procedure awaiting verification."""

    skill_id: str
    owner_id: str
    workspace_id: str
    name: str
    description: str
    task_signature: str
    occurrence_count: int
    evidence_ids: tuple[str, ...]
    state: CandidateState
    created_at: float
    updated_at: float


@dataclass(frozen=True, slots=True)
class EvolutionCandidate:
    """A proposed source or configuration evolution."""

    candidate_id: str
    kind: str
    target: str
    rationale: str
    content_hash: str
    state: CandidateState
    created_at: float
    updated_at: float
    backup_path: str | None = None


@dataclass(frozen=True, slots=True)
class AutopilotRule:
    """A bounded event-to-goal rule."""

    rule_id: str
    name: str
    kind: TriggerKind
    pattern: str
    goal: str
    priority: int
    cooldown_seconds: float
    max_runs: int
    enabled: bool


@dataclass(frozen=True, slots=True)
class AssistantRoutine:
    """A deterministic personal-assistant routine declaration."""

    routine_id: str
    name: str
    description: str
    cadence: str
    enabled: bool
    max_items: int


@dataclass(frozen=True, slots=True)
class DreamReport:
    """Bounded background cognition result."""

    dream_id: str
    started_at: float
    finished_at: float
    events_reviewed: int
    failures_reviewed: int
    duplicates_found: int
    skill_candidates: int
    future_actions: int
    code_findings: int
    safe_to_promote: bool


@dataclass(frozen=True, slots=True)
class NeedleStatus:
    """Availability and policy state for Needle 3."""

    installed: bool
    generation: str
    telemetry_disabled: bool
    role: str
    detail: str


@dataclass(frozen=True, slots=True)
class ForgeRepository:
    """Verified public GitHub repository metadata."""

    owner: str
    name: str
    default_branch: str
    private: bool
    license_id: str | None
    html_url: str
    clone_url: str
    archive_url: str


@dataclass(frozen=True, slots=True)
class ForgeManifest:
    """Static inventory and integration recommendation for one public OSS repo."""

    repository: ForgeRepository
    source_sha256: str
    languages: tuple[str, ...]
    package_manifests: tuple[str, ...]
    license_files: tuple[str, ...]
    declared_dependencies: tuple[str, ...]
    capability_matches: tuple[str, ...]
    risk_flags: tuple[str, ...]
    license_compatible: bool
    requires_review: bool


@dataclass(frozen=True, slots=True)
class ForgeStage:
    """A staged OSS source tree ready for policy-reviewed integration."""

    stage_id: str
    source: ForgeManifest
    path: str
    files: int
    bytes: int
    created_at: float


class LearningLedger:
    """Append-only, HMAC-integrity-protected learning ledger.

    Learning is segregated by owner/workspace/session fields.  Records never grant
    permissions by themselves; they are evidence consumed by higher-level policy.
    """

    def __init__(self, path: str | Path, secret: bytes, *, max_events: int = 100_000) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret = bytes(secret)
        if len(self.secret) < 32:
            raise ValueError("learning ledger secret must be at least 32 bytes")
        self.max_events = max(1, min(int(max_events), 1_000_000))

    def _integrity(self, canonical: bytes) -> str:
        return hmac.new(self.secret, canonical, hashlib.sha256).hexdigest()

    def append(
        self,
        *,
        owner_id: str,
        workspace_id: str,
        session_id: str,
        kind: LearningKind | str,
        task_type: str,
        outcome: str,
        summary: str,
        evidence: Mapping[str, Any] | None = None,
    ) -> LearningEvent:
        """Persist one bounded learning event."""
        owner = str(owner_id).strip()
        workspace = str(workspace_id).strip()
        session = str(session_id).strip()
        if not owner or not workspace or not session:
            raise ValueError("owner_id, workspace_id and session_id are required")
        payload = json.dumps(dict(evidence or {}), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        payload_bytes = payload.encode("utf-8")
        if len(payload_bytes) > 100_000:
            raise ValueError("learning evidence exceeds size budget")
        content_hash = hashlib.sha256(payload_bytes + summary.encode("utf-8")).hexdigest()
        event_id = f"learn_{uuid.uuid4().hex}"
        created = time.time()
        canonical = "|".join((event_id, owner, workspace, session, str(kind), task_type[:256], outcome[:256], summary[:2_000], content_hash)).encode("utf-8")
        event = LearningEvent(
            event_id=event_id,
            created_at=created,
            owner_id=owner,
            workspace_id=workspace,
            session_id=session,
            kind=str(kind),
            task_type=str(task_type).strip()[:256],
            outcome=str(outcome).strip()[:256],
            summary=str(summary).strip()[:2_000],
            evidence=dict(evidence or {}),
            content_hash=content_hash,
            integrity_tag=self._integrity(canonical),
        )
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(asdict(event), sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        self.compact()
        return event

    def events(self, *, owner_id: str | None = None, workspace_id: str | None = None, limit: int = 500) -> list[LearningEvent]:
        """Read verified events newest-first for one namespace."""
        if not self.path.exists():
            return []
        owner = str(owner_id) if owner_id is not None else None
        workspace = str(workspace_id) if workspace_id is not None else None
        output: list[LearningEvent] = []
        for raw in self.path.read_text(encoding="utf-8").splitlines()[-max(1, min(int(limit) * 4, 20_000)):]:
            try:
                row = json.loads(raw)
                event = LearningEvent(**row)
            except (TypeError, ValueError, KeyError, json.JSONDecodeError):
                continue
            if owner is not None and event.owner_id != owner:
                continue
            if workspace is not None and event.workspace_id != workspace:
                continue
            canonical = "|".join((event.event_id, event.owner_id, event.workspace_id, event.session_id, event.kind, event.task_type, event.outcome, event.summary, event.content_hash)).encode("utf-8")
            if not hmac.compare_digest(event.integrity_tag, self._integrity(canonical)):
                raise EvolutionError("learning ledger integrity verification failed")
            output.append(event)
        output.sort(key=lambda item: item.created_at, reverse=True)
        return output[: max(1, int(limit))]

    def compact(self) -> None:
        """Bound ledger growth by retaining the newest verified records."""
        if not self.path.exists():
            return
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return
        if len(lines) <= self.max_events:
            return
        keep = lines[-self.max_events :]
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text("\n".join(keep) + "\n", encoding="utf-8")
        temp.replace(self.path)

    def stats(self) -> dict[str, int]:
        """Return bounded ledger statistics."""
        if not self.path.exists():
            return {"events": 0, "bytes": 0}
        return {"events": len(self.path.read_text(encoding="utf-8").splitlines()), "bytes": self.path.stat().st_size}


class SkillEvolutionEngine:
    """Discover repeatable procedures without granting them trust automatically."""

    def __init__(self, *, max_candidates: int = 2_048) -> None:
        self.max_candidates = max(1, min(int(max_candidates), 20_000))
        self._candidates: dict[str, SkillCandidate] = {}

    @staticmethod
    def _signature(task_type: str, outcome: str) -> str:
        base = f"{task_type.strip().lower()}|{outcome.strip().lower()}"
        return hashlib.sha256(re.sub(r"\s+", " ", base).encode()).hexdigest()[:24]

    def discover(self, events: Sequence[LearningEvent], *, minimum_occurrences: int = 3) -> list[SkillCandidate]:
        """Discover repeated successful patterns using bounded deterministic grouping."""
        threshold = max(2, min(int(minimum_occurrences), 100))
        grouped: dict[str, list[LearningEvent]] = {}
        for event in events:
            if event.kind not in {LearningKind.SUCCESS.value, LearningKind.CORRECTION.value}:
                continue
            signature = self._signature(event.task_type, event.outcome)
            grouped.setdefault(signature, []).append(event)
        discovered: list[SkillCandidate] = []
        now = time.time()
        for signature, group in grouped.items():
            if len(group) < threshold:
                continue
            group.sort(key=lambda item: item.created_at)
            first = group[0]
            name = re.sub(r"[^a-z0-9]+", "-", first.task_type.lower()).strip("-")[:80] or "learned-skill"
            candidate = SkillCandidate(
                skill_id=f"skillcand_{signature}", owner_id=first.owner_id, workspace_id=first.workspace_id,
                name=name, description=f"Repeated successful procedure for {first.task_type}.",
                task_signature=signature, occurrence_count=len(group), evidence_ids=tuple(item.event_id for item in group[-20:]),
                state=CandidateState.CANDIDATE, created_at=first.created_at, updated_at=now,
            )
            self._candidates[candidate.skill_id] = candidate
            discovered.append(candidate)
        if len(self._candidates) > self.max_candidates:
            ordered = sorted(self._candidates.values(), key=lambda item: item.updated_at, reverse=True)[: self.max_candidates]
            self._candidates = {item.skill_id: item for item in ordered}
        return sorted(discovered, key=lambda item: (-item.occurrence_count, item.name))

    def evaluate(self, skill_id: str, evaluator: Callable[[SkillCandidate], bool]) -> SkillCandidate:
        """Evaluate one candidate and promote only after explicit evidence."""
        candidate = self._candidates.get(str(skill_id))
        if candidate is None:
            raise KeyError(skill_id)
        now = time.time()
        evaluating = SkillCandidate(**{**asdict(candidate), "state": CandidateState.EVALUATING, "updated_at": now})
        self._candidates[skill_id] = evaluating
        try:
            passed = bool(evaluator(evaluating))
        except Exception:
            passed = False
        final = SkillCandidate(**{**asdict(evaluating), "state": CandidateState.TRUSTED if passed else CandidateState.QUARANTINED, "updated_at": time.time()})
        self._candidates[skill_id] = final
        return final

    def list(self, *, state: CandidateState | None = None, limit: int = 100) -> list[SkillCandidate]:
        """List skill candidates newest-first."""
        rows = sorted(self._candidates.values(), key=lambda item: item.updated_at, reverse=True)
        if state is not None:
            rows = [item for item in rows if item.state == state]
        return rows[: max(1, min(int(limit), self.max_candidates))]


class DreamEngine:
    """Bounded background cognition for memory, skills, failures and preparation."""

    def __init__(
        self,
        ledger: LearningLedger,
        skills: SkillEvolutionEngine,
        *,
        max_events: int = 500,
        max_future_actions: int = 32,
        code_health: Callable[[], int] | None = None,
    ) -> None:
        self.ledger = ledger
        self.skills = skills
        self.max_events = max(10, min(int(max_events), 10_000))
        self.max_future_actions = max(1, min(int(max_future_actions), 256))
        self.code_health = code_health
        self._last: DreamReport | None = None

    def run(self, *, owner_id: str, workspace_id: str) -> DreamReport:
        """Perform one non-mutating-by-default dream cycle."""
        started = time.time()
        events = self.ledger.events(owner_id=owner_id, workspace_id=workspace_id, limit=self.max_events)
        failures = [event for event in events if event.kind == LearningKind.FAILURE.value]
        duplicate_keys: set[str] = set()
        duplicates = 0
        for event in events:
            key = f"{event.task_type}|{event.outcome}|{event.content_hash}"
            if key in duplicate_keys:
                duplicates += 1
            duplicate_keys.add(key)
        candidates = self.skills.discover(events)
        future_actions = min(self.max_future_actions, len(candidates) + len(failures))
        code_findings = max(0, int(self.code_health() if self.code_health else 0))
        report = DreamReport(
            dream_id=f"dream_{uuid.uuid4().hex}", started_at=started, finished_at=time.time(),
            events_reviewed=len(events), failures_reviewed=len(failures), duplicates_found=duplicates,
            skill_candidates=len(candidates), future_actions=future_actions, code_findings=code_findings,
            safe_to_promote=False,
        )
        self._last = report
        return report

    def snapshot(self) -> dict[str, Any]:
        """Return the newest dream report without exposing learning content."""
        return asdict(self._last) if self._last else {"available": True, "last": None}


class AutopilotRuleEngine:
    """Event-driven autopilot rule registry with explicit budgets and cooldowns."""

    def __init__(self, trigger: Callable[[str, int, Mapping[str, Any]], Any], *, max_rules: int = 512) -> None:
        self._trigger = trigger
        self._max_rules = max(1, min(int(max_rules), 10_000))
        self._rules: dict[str, AutopilotRule] = {}
        self._runs: dict[str, tuple[int, float]] = {}

    def register(self, rule: AutopilotRule) -> None:
        """Register or replace a rule after validating hard bounds."""
        if len(self._rules) >= self._max_rules and rule.rule_id not in self._rules:
            raise EvolutionError("autopilot rule capacity exceeded")
        if not rule.goal.strip() or not rule.name.strip():
            raise ValueError("rule name and goal are required")
        if rule.priority < 0 or rule.priority > 100:
            raise ValueError("priority must be between 0 and 100")
        if rule.max_runs < 1 or rule.max_runs > 100_000:
            raise ValueError("invalid max_runs")
        self._rules[rule.rule_id] = rule

    def emit(self, kind: TriggerKind | str, value: str, *, now: float | None = None, metadata: Mapping[str, Any] | None = None) -> list[str]:
        """Evaluate matching rules and trigger bounded executive goals."""
        current = time.time() if now is None else float(now)
        emitted: list[str] = []
        for rule in tuple(self._rules.values()):
            if not rule.enabled or rule.kind.value != str(kind):
                continue
            if rule.pattern and not re.search(rule.pattern, str(value), re.IGNORECASE):
                continue
            count, last = self._runs.get(rule.rule_id, (0, 0.0))
            if count >= rule.max_runs or current - last < rule.cooldown_seconds:
                continue
            self._trigger(rule.goal, rule.priority, dict(metadata or {}))
            self._runs[rule.rule_id] = (count + 1, current)
            emitted.append(rule.rule_id)
        return emitted

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret rule state."""
        return {"rules": [asdict(row) for row in self._rules.values()], "runs": dict(self._runs)}


class AssistantRoutineEngine:
    """Deterministic personal-assistant routines over JARVIS-owned local state."""

    def __init__(self, *, task_source: Callable[[], Sequence[Mapping[str, Any]]], mission_source: Callable[[], Sequence[Mapping[str, Any]]], health_source: Callable[[], Mapping[str, Any]], max_items: int = 50) -> None:
        self.task_source = task_source
        self.mission_source = mission_source
        self.health_source = health_source
        self.max_items = max(1, min(int(max_items), 500))
        self._routines = {
            "morning": AssistantRoutine("morning", "Morning Briefing", "Summarize active work and system state.", "daily", True, self.max_items),
            "evening": AssistantRoutine("evening", "Evening Review", "Summarize completed and unresolved work.", "daily", True, self.max_items),
            "focus": AssistantRoutine("focus", "Focus Queue", "Return the most important bounded tasks.", "on-demand", True, self.max_items),
        }

    def briefing(self, kind: str = "morning") -> dict[str, Any]:
        """Generate a local-state briefing without external credentials."""
        routine = self._routines.get(str(kind), self._routines["morning"])
        tasks = [dict(item) for item in self.task_source()][: routine.max_items]
        missions = [dict(item) for item in self.mission_source()][: routine.max_items]
        health = dict(self.health_source())
        return {
            "routine": asdict(routine),
            "timestamp": time.time(),
            "tasks": tasks,
            "missions": missions,
            "health": health,
            "requires_external_connectors": ["email", "calendar"] if not health.get("external_connectors", False) else [],
        }

    def routines(self) -> list[AssistantRoutine]:
        """Return supported local routines."""
        return list(self._routines.values())


class NeedleMicroAgent:
    """Optional Needle 3 adapter for low-latency local structured work.

    Needle is treated as a specialist: extraction, tool-call routing and embeddings.
    It is never granted unrestricted autonomy and never becomes the primary planner.
    """

    def __init__(self, *, enabled: bool = True, role: str = "micro-agent") -> None:
        os.environ.setdefault("NEEDLE_TELEMETRY", "0")
        os.environ.setdefault("DO_NOT_TRACK", "1")
        self.enabled = bool(enabled)
        self.role = str(role)
        self._needle: Any | None = None
        self._error = "disabled"
        if self.enabled:
            try:
                import needle
                self._needle = needle
                self._error = ""
            except Exception as exc:
                self._error = f"unavailable: {type(exc).__name__}"

    @property
    def available(self) -> bool:
        """Return whether Needle's runtime is installed and importable."""
        return self._needle is not None

    def status(self) -> NeedleStatus:
        """Return safe runtime status."""
        return NeedleStatus(self.available, "3", True, self.role, "available" if self.available else self._error)

    def embed(self, text: str) -> list[float]:
        """Generate a local retrieval embedding through Needle 3."""
        if not self.available:
            raise RuntimeError(self._error or "Needle 3 unavailable")
        if not text or len(text) > 100_000:
            raise ValueError("text is empty or exceeds embedding limit")
        agent = self._needle.Needle()
        value = agent.embed(text)
        return [float(item) for item in value]

    def extract(self, text: str, schema: Any) -> Any:
        """Perform bounded structured extraction with Needle's grammar constraints."""
        if not self.available:
            raise RuntimeError(self._error or "Needle 3 unavailable")
        if not text or len(text) > 100_000:
            raise ValueError("text is empty or oversized")
        return self._needle.extract(text, schema, strict=True, max_new_tokens=512)


class OSSForge:
    """Public GitHub OSS acquisition and isolated integration planner.

    This component intentionally works anonymously against public repositories.
    It never requests, extracts or impersonates contributor credentials.  License
    compatibility, repository visibility, archive safety and capability mapping are
    checked before a repository can enter the JARVIS staging area.
    """

    _GITHUB_HOSTS = {"github.com", "www.github.com"}
    _ALLOWED_LICENSES = {
        "mit", "apache-2.0", "bsd-2-clause", "bsd-3-clause", "isc", "mpl-2.0",
        "unlicense", "0bsd", "bsl-1.1",  # BSL remains review-required below.
    }
    _FORBIDDEN_LICENSES = {"gpl-2.0", "gpl-3.0", "agpl-3.0", "sspl-1.0"}

    def __init__(self, stage_root: str | Path, *, network_policy: NetworkPolicy | None = None) -> None:
        self.stage_root = Path(stage_root).expanduser().resolve()
        self.stage_root.mkdir(parents=True, exist_ok=True)
        policy = network_policy or NetworkPolicy(
            allowed_hosts=("api.github.com", "codeload.github.com", "github.com", "raw.githubusercontent.com"),
            max_response_size_bytes=50_000_000,
            request_timeout_seconds=30.0,
            max_redirects=3,
        )
        self.http = SafeHTTPClient(policy)
        self._stages: dict[str, ForgeStage] = {}

    @classmethod
    def parse_public_url(cls, url: str) -> tuple[str, str]:
        """Parse one public GitHub repository URL without accepting local URLs."""
        value = str(url).strip()
        parsed = urlparse(value)
        if parsed.scheme != "https" or (parsed.hostname or "").lower() not in cls._GITHUB_HOSTS:
            raise ValueError("only public https://github.com/<owner>/<repo> repositories are supported")
        parts = [part for part in parsed.path.strip("/").split("/") if part]
        if len(parts) != 2 or any(part in {".", ".."} or not re.fullmatch(r"[A-Za-z0-9_.-]+", part) for part in parts):
            raise ValueError("invalid GitHub repository URL")
        owner, repo = parts
        return owner, repo[:-4] if repo.endswith(".git") else repo

    def inspect(self, url: str) -> ForgeManifest:
        """Inspect a public repository through the GitHub API with no credentials."""
        owner, repo = self.parse_public_url(url)
        api_url = f"https://api.github.com/repos/{owner}/{repo}"
        response = self.http.get(api_url, headers={"Accept": "application/vnd.github+json"})
        if not response.get("ok"):
            raise EvolutionError(str(response.get("error", "GitHub metadata request failed")))
        try:
            metadata = json.loads(str(response.get("content", "{}")))
        except json.JSONDecodeError as exc:
            raise EvolutionError("GitHub API returned invalid JSON") from exc
        private = bool(metadata.get("private", True))
        if private:
            raise PermissionError("private repositories are not supported by the public OSS Forge")
        license_obj = metadata.get("license") if isinstance(metadata.get("license"), dict) else {}
        license_id = str(license_obj.get("spdx_id", "")).lower() or None
        branch = str(metadata.get("default_branch", "main"))
        manifest = ForgeManifest(
            repository=ForgeRepository(
                owner=owner,
                name=repo,
                default_branch=branch,
                private=False,
                license_id=license_id,
                html_url=str(metadata.get("html_url", f"https://github.com/{owner}/{repo}")),
                clone_url=str(metadata.get("clone_url", f"https://github.com/{owner}/{repo}.git")),
                archive_url=f"https://codeload.github.com/{owner}/{repo}/tar.gz/{branch}",
            ),
            # Repository metadata alone does not authenticate the archive bytes. Do not
            # invent an artifact digest from the branch name; fetch_and_stage requires
            # caller-supplied verified archive hash evidence before staging.
            source_sha256="",
            languages=(),
            package_manifests=(),
            license_files=(),
            declared_dependencies=(),
            capability_matches=(),
            risk_flags=(),
            license_compatible=bool(license_id in self._ALLOWED_LICENSES),
            requires_review=license_id == "bsl-1.1" or license_id is None,
        )
        return manifest

    @staticmethod
    def _safe_member_path(root: Path, member: tarfile.TarInfo) -> Path:
        """Validate one tar member against path traversal and link attacks."""
        if member.issym() or member.islnk() or member.isdev():
            raise EvolutionError("archive contains a symbolic/hard link or device node")
        relative = PurePosixPath(member.name)
        if relative.is_absolute() or ".." in relative.parts:
            raise EvolutionError("archive path traversal detected")
        target = (root / Path(*relative.parts)).resolve()
        if not target.is_relative_to(root.resolve()):
            raise EvolutionError("archive escapes staging directory")
        return target

    @classmethod
    def _detect_license(cls, files: Sequence[str], license_id: str | None, stage: Path | None = None) -> tuple[str | None, tuple[str, ...], tuple[str, ...]]:
        names = tuple(sorted(name for name in files if Path(name).name.upper().startswith(("LICENSE", "COPYING"))))
        detected: set[str] = set()
        if stage is not None:
            for name in names[:32]:
                try:
                    text = (stage / name).read_text(encoding="utf-8", errors="ignore")[:500_000].lower()
                except OSError:
                    continue
                if "gnu affero general public license" in text:
                    detected.add("agpl")
                elif "gnu general public license" in text:
                    detected.add("gpl")
                elif "server side public license" in text:
                    detected.add("sspl")
                elif "business source license" in text:
                    detected.add("bsl-1.1")
                elif "apache license" in text and "version 2.0" in text:
                    detected.add("apache-2.0")
                elif "permission is hereby granted" in text and "mit" in text[:2000]:
                    detected.add("mit")
        conflicts: set[str] = set()
        declared = license_id.lower() if license_id else None
        if detected:
            forbidden_detected = detected & cls._FORBIDDEN_LICENSES
            if forbidden_detected:
                conflicts.update(forbidden_detected)
            if declared and declared not in detected and any(item in {"gpl", "agpl", "sspl", "bsl-1.1"} for item in detected):
                conflicts.update(detected)
        return declared, names, tuple(sorted(conflicts))

    def stage(self, manifest: ForgeManifest, *, archive_bytes: bytes, max_files: int = 50_000, max_bytes: int = 500_000_000) -> ForgeStage:
        """Stage a verified repository archive without executing any source."""
        if not manifest.license_compatible or manifest.requires_review:
            raise PermissionError("repository license requires explicit review before staging")
        if len(archive_bytes) > max_bytes:
            raise EvolutionError("repository archive exceeds size budget")
        stage_id = f"forge_{uuid.uuid4().hex}"
        stage = self.stage_root / stage_id
        stage.mkdir(parents=True, exist_ok=False)
        count = 0
        total = 0
        files: list[str] = []
        try:
            with tarfile.open(fileobj=__import__("io").BytesIO(archive_bytes), mode="r:gz") as archive:
                for member in archive.getmembers():
                    if member.isdir():
                        continue
                    count += 1
                    if count > max_files:
                        raise EvolutionError("repository contains too many files")
                    target = self._safe_member_path(stage, member)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    extracted = archive.extractfile(member)
                    if extracted is None:
                        continue
                    content = extracted.read(max_bytes - total + 1)
                    total += len(content)
                    if total > max_bytes:
                        raise EvolutionError("repository source exceeds staging budget")
                    target.write_bytes(content)
                    files.append(str(target.relative_to(stage)).replace(os.sep, "/"))
        except (tarfile.TarError, OSError) as exc:
            for path in sorted(stage.rglob("*"), reverse=True):
                if path.is_file():
                    path.unlink(missing_ok=True)
                elif path.is_dir():
                    path.rmdir()
            stage.rmdir()
            raise EvolutionError(f"repository archive could not be staged: {exc}") from exc
        source_hash = hashlib.sha256(archive_bytes).hexdigest()
        license_id, license_files, license_conflicts = self._detect_license(files, manifest.repository.license_id, stage)
        if license_id in self._FORBIDDEN_LICENSES or license_conflicts:
            raise PermissionError(f"repository license is not admitted by the default forge policy: {', '.join(license_conflicts or (license_id or 'unknown',))}")
        staged_manifest = ForgeManifest(
            repository=manifest.repository,
            source_sha256=source_hash,
            languages=tuple(sorted(self._detect_languages(files))),
            package_manifests=tuple(sorted(name for name in files if Path(name).name in {"pyproject.toml", "package.json", "go.mod", "Cargo.toml", "pubspec.yaml"})),
            license_files=license_files,
            declared_dependencies=tuple(sorted(self._detect_dependencies(stage, files))),
            capability_matches=tuple(sorted(self._match_capabilities(files))),
            risk_flags=tuple(sorted(self._risk_flags(stage, files) | {f"license-conflict:{item}" for item in license_conflicts})),
            license_compatible=license_id in self._ALLOWED_LICENSES,
            requires_review=license_id == "bsl-1.1" or license_id is None,
        )
        if not staged_manifest.license_compatible or staged_manifest.requires_review:
            raise PermissionError("staged repository failed final license admission")
        row = ForgeStage(stage_id, staged_manifest, str(stage), count, total, time.time())
        self._stages[stage_id] = row
        (stage / "FORGE_MANIFEST.json").write_text(json.dumps(asdict(row), sort_keys=True, indent=2, default=str), encoding="utf-8")
        return row

    @staticmethod
    def _detect_languages(files: Sequence[str]) -> set[str]:
        extensions = {Path(name).suffix.lower() for name in files}
        mapping = {".py": "python", ".dart": "dart", ".go": "go", ".rs": "rust", ".ts": "typescript", ".tsx": "typescript", ".js": "javascript", ".java": "java", ".cs": "csharp", ".cpp": "cpp", ".cc": "cpp", ".h": "cpp", ".hpp": "cpp"}
        return {language for extension, language in mapping.items() if extension in extensions}

    @staticmethod
    def _detect_dependencies(stage: Path, files: Sequence[str]) -> set[str]:
        dependencies: set[str] = set()
        for relative in files:
            path = stage / relative
            if path.name == "pyproject.toml":
                try:
                    import tomllib
                    payload = tomllib.loads(path.read_text(encoding="utf-8"))
                    dependencies.update(str(item) for item in payload.get("project", {}).get("dependencies", [])[:500])
                except Exception:
                    dependencies.add("<unreadable-pyproject>")
            elif path.name == "package.json":
                try:
                    payload = json.loads(path.read_text(encoding="utf-8"))
                    dependencies.update(str(key) for key in (payload.get("dependencies", {}) or {}).keys())
                except Exception:
                    dependencies.add("<unreadable-package.json>")
        return dependencies

    @staticmethod
    def _match_capabilities(files: Sequence[str]) -> set[str]:
        text = " ".join(files).lower()
        mapping = {
            "assistant": ("calendar", "email", "reminder", "notification"),
            "browser": ("browser", "playwright", "selenium", "computer"),
            "voice": ("voice", "speech", "whisper", "tts"),
            "rag": ("retrieval", "embedding", "vector", "rag"),
            "vision": ("vision", "ocr", "image", "camera"),
            "workflow": ("workflow", "graph", "pipeline"),
            "memory": ("memory", "knowledge", "vector"),
            "agents": ("agent", "autonomous", "orchestration"),
            "inference": ("llm", "inference", "model", "transformer"),
        }
        return {capability for capability, markers in mapping.items() if any(marker in text for marker in markers)}

    @staticmethod
    def _risk_flags(stage: Path, files: Sequence[str]) -> set[str]:
        flags: set[str] = set()
        suspicious = re.compile(r"\b(subprocess|shell=True|eval\s*\(|exec\s*\(|os\.system|pickle\.loads)\b")
        for relative in files[:50_000]:
            path = stage / relative
            if path.suffix.lower() not in {".py", ".js", ".ts", ".go", ".rs", ".java", ".cs"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")[:1_000_000]
            except OSError:
                continue
            if suspicious.search(text):
                flags.add("code-execution-primitives")
            if "http://" in text or "https://" in text:
                flags.add("network-capability")
            if "secret" in text.lower() or "api_key" in text.lower():
                flags.add("credential-handling")
        return flags

    def fetch_and_stage(self, manifest: ForgeManifest) -> ForgeStage:
        """Fetch a public repository archive and require verified digest evidence before staging."""
        expected = str(manifest.source_sha256 or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise EvolutionError("repository archive expected SHA-256 evidence is required before staging")
        response = self.http.get(manifest.repository.archive_url, headers={"Accept": "application/octet-stream"})
        if not response.get("ok"):
            raise EvolutionError(str(response.get("error", "repository archive download failed")))
        body = response.get("body")
        if not isinstance(body, (bytes, bytearray)):
            raise EvolutionError("repository archive response did not provide bytes")
        archive_bytes = bytes(body)
        actual = hashlib.sha256(archive_bytes).hexdigest()
        if not hmac.compare_digest(actual, expected):
            raise EvolutionError("repository archive digest mismatch")
        return self.stage(manifest, archive_bytes=archive_bytes)

    def build_plan(self, stage_id: str) -> dict[str, Any]:
        """Create a deterministic integration plan without executing repository code."""
        stage = self._stages.get(str(stage_id))
        if stage is None:
            raise KeyError(stage_id)
        capabilities = list(stage.source.capability_matches)
        adapters = {capability: f"integrate through existing {capability} contract and policy gateway" for capability in capabilities}
        return {
            "stage_id": stage.stage_id,
            "repository": asdict(stage.source.repository),
            "capabilities": capabilities,
            "adapters": adapters,
            "license_compatible": stage.source.license_compatible,
            "risk_flags": list(stage.source.risk_flags),
            "requires_review": bool(stage.source.risk_flags),
            "execution_permitted": False,
            "source_execution_policy": "static-analysis-only until explicit authorization",
        }

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret Forge state."""
        return {"staged": [asdict(stage) for stage in self._stages.values()]}




class SelfEvolutionController:
    """Policy-bound controller around the existing transactional self-edit pipeline."""

    def __init__(self, pipeline: Any, *, permission_engine: Any, max_candidates: int = 256) -> None:
        self.pipeline = pipeline
        self.permission_engine = permission_engine
        self.max_candidates = max(1, min(int(max_candidates), 2_000))
        self._candidates: dict[str, EvolutionCandidate] = {}

    def propose(self, relative_path: str, new_content: str, rationale: str) -> dict[str, Any]:
        """Create a validated source-change candidate without applying it."""
        proposal = self.pipeline.prepare(relative_path, new_content)
        candidate_id = f"evo_{uuid.uuid4().hex}"
        digest = str(proposal.get("validation", {}).get("sha256", ""))
        if not proposal.get("validation", {}).get("ok") or not digest:
            candidate = EvolutionCandidate(candidate_id, "source", relative_path, rationale[:2_000], digest, CandidateState.QUARANTINED, time.time(), time.time())
            self._candidates[candidate_id] = candidate
            return {"candidate": asdict(candidate), "proposal": proposal, "promotable": False}
        candidate = EvolutionCandidate(candidate_id, "source", relative_path, rationale[:2_000], digest, CandidateState.CANDIDATE, time.time(), time.time())
        self._candidates[candidate_id] = candidate
        self._trim()
        return {"candidate": asdict(candidate), "proposal": proposal, "promotable": True}

    def canary(self, candidate_id: str, proposal: Mapping[str, Any], *, approval_token: str | None = None, verification: Callable[[], bool] | None = None, test_command: tuple[str, ...] = ("python", "-m", "compileall", "-q", ".")) -> dict[str, Any]:
        """Apply one approved candidate through the existing transactional canary path."""
        key = str(candidate_id)
        current = self._candidates.get(key)
        if current is None:
            raise KeyError(candidate_id)
        running = EvolutionCandidate(**{**asdict(current), "state": CandidateState.EVALUATING, "updated_at": time.time()})
        self._candidates[key] = running
        result = self.pipeline.apply_canary(
            dict(proposal), permission_engine=self.permission_engine, approval_token=approval_token,
            test_command=test_command, timeout_seconds=300.0,
        )
        passed = bool(result.get("canary_verified")) and (True if verification is None else bool(verification()))
        final_state = CandidateState.TRUSTED if passed else CandidateState.QUARANTINED
        final = EvolutionCandidate(**{**asdict(running), "state": final_state, "updated_at": time.time(), "backup_path": result.get("backup")})
        self._candidates[key] = final
        return {"candidate": asdict(final), "result": result, "promoted": passed}

    def list(self, *, state: CandidateState | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """Return bounded evolution-candidate metadata."""
        rows = sorted(self._candidates.values(), key=lambda item: item.updated_at, reverse=True)
        if state is not None:
            rows = [item for item in rows if item.state == state]
        return [asdict(item) for item in rows[: max(1, min(int(limit), self.max_candidates))]]

    def _trim(self) -> None:
        if len(self._candidates) <= self.max_candidates:
            return
        rows = sorted(self._candidates.values(), key=lambda item: item.updated_at, reverse=True)[: self.max_candidates]
        self._candidates = {item.candidate_id: item for item in rows}


class EvolutionEngine:
    """Unified facade for learning, dreaming, skills, autopilot and OSS integration."""

    def __init__(
        self,
        *,
        ledger: LearningLedger,
        skills: SkillEvolutionEngine,
        dream: DreamEngine,
        autopilot: AutopilotRuleEngine,
        routines: AssistantRoutineEngine,
        needle: NeedleMicroAgent,
        forge: OSSForge,
        self_improvement: Any,
        permission_engine: Any | None = None,
    ) -> None:
        self.ledger = ledger
        self.skills = skills
        self.dream = dream
        self.autopilot_rules = autopilot
        self.routines = routines
        self.needle = needle
        self.forge = forge
        self.self_improvement = self_improvement
        self.self_evolution = SelfEvolutionController(self_improvement, permission_engine=permission_engine) if permission_engine is not None else None

    def snapshot(self) -> dict[str, Any]:
        """Return a compact, non-secret cognitive/evolution snapshot."""
        return {
            "learning": self.ledger.stats(),
            "skills": {state.value: len(self.skills.list(state=state, limit=self.skills.max_candidates)) for state in CandidateState},
            "dream": self.dream.snapshot(),
            "autopilot": self.autopilot_rules.snapshot(),
            "needle": asdict(self.needle.status()),
            "forge": self.forge.snapshot(),
            "self_improvement": self.self_improvement.stats() if hasattr(self.self_improvement, "stats") else {},
            "evolution_candidates": self.self_evolution.list(limit=100) if self.self_evolution is not None else [],
        }

    def record_success(self, *, owner_id: str, workspace_id: str, session_id: str, task_type: str, outcome: str, summary: str, evidence: Mapping[str, Any] | None = None) -> LearningEvent:
        """Persist a successful experience as learning evidence."""
        return self.ledger.append(owner_id=owner_id, workspace_id=workspace_id, session_id=session_id, kind=LearningKind.SUCCESS, task_type=task_type, outcome=outcome, summary=summary, evidence=evidence)

    def record_failure(self, *, owner_id: str, workspace_id: str, session_id: str, task_type: str, outcome: str, summary: str, evidence: Mapping[str, Any] | None = None) -> LearningEvent:
        """Persist a failed experience as learning evidence."""
        return self.ledger.append(owner_id=owner_id, workspace_id=workspace_id, session_id=session_id, kind=LearningKind.FAILURE, task_type=task_type, outcome=outcome, summary=summary, evidence=evidence)

    def dream_cycle(self, *, owner_id: str = "local-user", workspace_id: str = "default") -> dict[str, Any]:
        """Run one bounded dream cycle."""
        return asdict(self.dream.run(owner_id=owner_id, workspace_id=workspace_id))



"""Bounded resource ownership ledger for leak detection and lifecycle gates."""
from __future__ import annotations

import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator


@dataclass(frozen=True, slots=True)
class ResourceLease:
    lease_id: str
    resource_type: str
    owner: str
    created_at: float
    metadata: tuple[tuple[str, str], ...]


class ResourceLedger:
    """Tracks explicitly owned resources and provides zero-leak assertions."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._active: dict[str, ResourceLease] = {}
        self._closed = False

    def acquire(self, resource_type: str, owner: str, *, metadata: dict[str, str] | None = None) -> ResourceLease:
        with self._lock:
            if self._closed:
                raise RuntimeError("resource ledger is closed")
            lease = ResourceLease(f"res_{uuid.uuid4().hex}", str(resource_type), str(owner), time.time(), tuple(sorted((str(k), str(v)) for k, v in (metadata or {}).items())))
            self._active[lease.lease_id] = lease
            return lease

    def release(self, lease: ResourceLease | str) -> bool:
        lease_id = lease if isinstance(lease, str) else lease.lease_id
        with self._lock:
            return self._active.pop(str(lease_id), None) is not None

    @contextmanager
    def managed(self, resource_type: str, owner: str, *, metadata: dict[str, str] | None = None) -> Iterator[ResourceLease]:
        lease = self.acquire(resource_type, owner, metadata=metadata)
        try:
            yield lease
        finally:
            self.release(lease)

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            by_type: dict[str, int] = {}
            for lease in self._active.values():
                by_type[lease.resource_type] = by_type.get(lease.resource_type, 0) + 1
            return {"active": len(self._active), "by_type": dict(sorted(by_type.items())), "closed": self._closed}

    def assert_empty(self) -> None:
        snap = self.snapshot()
        if int(snap["active"]) != 0:
            raise AssertionError(f"resource leak detected: {snap}")

    def close(self) -> None:
        with self._lock:
            self.assert_empty()
            self._closed = True

"""Hardware-aware GPU resource manager with safe optional NVIDIA telemetry."""
from __future__ import annotations

import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True, slots=True)
class GPUState:
    """Normalized GPU telemetry snapshot."""

    index: int
    name: str
    memory_total_mb: int
    memory_used_mb: int
    utilization_percent: float
    temperature_c: float | None
    power_w: float | None
    timestamp: float

    @property
    def memory_free_mb(self) -> int:
        """Return available device memory."""
        return max(0, self.memory_total_mb - self.memory_used_mb)


class GPUManager:
    """Bounded NVIDIA telemetry and reservation manager."""

    def __init__(self, *, reservation_margin_mb: int = 512, command_timeout: float = 3.0) -> None:
        self.reservation_margin_mb = max(0, int(reservation_margin_mb))
        self.command_timeout = min(10.0, max(0.5, float(command_timeout)))
        self._reservations: dict[str, tuple[int, int]] = {}
        self._runtime_allocations: dict[str, tuple[int, object]] = {}
        self._lock = threading.RLock()

    def snapshot(self) -> tuple[GPUState, ...]:
        """Read GPU state using a fixed executable and fixed arguments."""
        binary = shutil.which("nvidia-smi")
        if not binary:
            return ()
        cmd = [binary, "--query-gpu=index,name,memory.total,memory.used,utilization.gpu,temperature.gpu,power.draw", "--format=csv,noheader,nounits"]
        try:
            completed = subprocess.run(cmd, capture_output=True, text=True, timeout=self.command_timeout, check=True, shell=False)
        except (OSError, subprocess.SubprocessError):
            return ()
        rows: list[GPUState] = []
        now = time.time()
        for line in completed.stdout.splitlines():
            parts = [item.strip() for item in line.split(",")]
            if len(parts) < 7:
                continue
            try:
                def _num(value: str) -> float | None:
                    if value.lower() in {"n/a", "nan", "not supported"}:
                        return None
                    return float(value)
                rows.append(GPUState(int(parts[0]), parts[1][:128], int(float(parts[2])), int(float(parts[3])), float(parts[4]), _num(parts[5]), _num(parts[6]), now))
            except (TypeError, ValueError):
                continue
        return tuple(rows)

    def reserve(self, reservation_id: str, memory_mb: int, *, device_index: int = 0) -> bool:
        """Reserve GPU memory against observed free memory."""
        amount = int(memory_mb)
        if not reservation_id.strip() or amount <= 0:
            raise ValueError("invalid GPU reservation")
        states = self.snapshot()
        state = next((item for item in states if item.index == int(device_index)), None)
        if state is None:
            return False
        with self._lock:
            used = sum(
                reserved_mb
                for reserved_device, reserved_mb in self._reservations.values()
                if reserved_device == state.index
            )
            available = max(0, state.memory_free_mb - self.reservation_margin_mb)
            if used + amount > available:
                return False
            self._reservations[reservation_id] = (state.index, amount)
            return True

    def release(self, reservation_id: str) -> bool:
        """Release one memory reservation idempotently."""
        with self._lock:
            return self._reservations.pop(str(reservation_id), None) is not None


    def cuda_capability(self) -> dict[str, Any]:
        """Probe the actual CUDA runtime without fabricating availability."""
        try:
            import torch
        except Exception as exc:
            return {"available": False, "provider": "torch", "error": f"import failed: {type(exc).__name__}: {exc}"}
        available = bool(torch.cuda.is_available())
        result: dict[str, Any] = {"available": available, "provider": "torch", "torch_version": str(torch.__version__), "cuda_version": str(torch.version.cuda) if torch.version.cuda else None, "device_count": int(torch.cuda.device_count()) if available else 0}
        if available:
            result["devices"] = []
            for index in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(index)
                result["devices"].append({"index": index, "name": str(props.name), "total_memory_bytes": int(props.total_memory), "capability": f"{props.major}.{props.minor}"})
        return result

    def allocate_real(self, reservation_id: str, memory_mb: int, *, device_index: int = 0) -> dict[str, Any]:
        """Reserve and allocate actual CUDA memory, failing closed on unavailable hardware."""
        amount = int(memory_mb)
        if amount <= 0:
            raise ValueError("memory_mb must be positive")
        if not self.reserve(reservation_id, amount, device_index=device_index):
            return {"ok": False, "error": "reservation_denied", "reservation_id": reservation_id}
        try:
            import torch
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA runtime is unavailable")
            device = torch.device(f"cuda:{int(device_index)}")
            elements = (amount * 1024 * 1024 + 3) // 4
            tensor = torch.empty(elements, dtype=torch.float32, device=device)
            tensor.fill_(0.0)
            torch.cuda.synchronize(device)
            allocated = int(torch.cuda.memory_allocated(device))
            with self._lock:
                self._runtime_allocations[str(reservation_id)] = (int(device_index), tensor)
            return {"ok": True, "reservation_id": str(reservation_id), "device_index": int(device_index), "requested_bytes": amount * 1024 * 1024, "runtime_allocated_bytes": allocated}
        except Exception as exc:
            self.release(reservation_id)
            return {"ok": False, "reservation_id": str(reservation_id), "error": f"real_cuda_allocation_failed: {type(exc).__name__}: {exc}"}

    def release_real(self, reservation_id: str) -> bool:
        """Release an actual CUDA allocation and its scheduler reservation."""
        with self._lock:
            item = self._runtime_allocations.pop(str(reservation_id), None)
        ok_runtime = True
        if item is not None:
            _, tensor = item
            try:
                import torch
                del tensor
                torch.cuda.empty_cache()
                torch.cuda.synchronize()
            except Exception:
                ok_runtime = False
        ok_reservation = self.release(str(reservation_id))
        return bool(ok_runtime and ok_reservation)

    def real_allocation_snapshot(self) -> dict[str, Any]:
        """Return live CUDA allocation accounting when available."""
        result: dict[str, Any] = {"allocations": {}, "cuda": self.cuda_capability()}
        with self._lock:
            result["allocations"] = {key: {"device_index": device, "live": True} for key, (device, _) in self._runtime_allocations.items()}
        return result

    def status(self) -> dict[str, Any]:
        """Return non-secret diagnostics."""
        states = tuple(asdict(item) | {"memory_free_mb": item.memory_free_mb} for item in self.snapshot())
        with self._lock:
            reservations = {key: amount for key, (_, amount) in self._reservations.items()}
            reservations_by_device = {
                key: {"device_index": device, "memory_mb": amount}
                for key, (device, amount) in sorted(self._reservations.items())
            }
            return {
                "devices": list(states),
                "reservations_mb": reservations,
                "reservations_by_device": reservations_by_device,
                "reservation_total_mb": sum(amount for _, amount in self._reservations.values()),
            }

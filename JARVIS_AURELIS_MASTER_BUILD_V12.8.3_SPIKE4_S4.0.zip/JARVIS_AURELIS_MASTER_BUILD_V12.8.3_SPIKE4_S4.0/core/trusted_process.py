"""Explicit trusted-infrastructure process adapter.

This module is intentionally narrower than :mod:`core.execution_broker`. It is
for fixed, application-owned infrastructure probes (for example ADB discovery,
GPU diagnostics and verification commands), never for model-generated commands.
All callers must provide an explicit executable allowlist and workspace.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from security.os_sandbox import OSSandbox

logger = logging.getLogger("jarvis.trusted_process")


@dataclass(frozen=True, slots=True)
class TrustedProcessResult:
    """Bounded result from a trusted infrastructure process."""

    ok: bool
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    timed_out: bool = False
    error: str | None = None


class TrustedProcessAdapter:
    """Run fixed infrastructure executables without shell interpretation."""

    def __init__(self, workspace: str | Path, *, timeout_seconds: float = 30.0, max_memory_mb: int = 512, allow_network: bool = False) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.sandbox = OSSandbox(self.workspace, timeout_seconds=timeout_seconds, max_memory_mb=max_memory_mb, allow_network=allow_network, strict_isolation=False)

    @staticmethod
    def resolve_executable(executable: str) -> str | None:
        """Resolve an executable name without invoking a shell."""
        value = str(executable).strip()
        if not value:
            return None
        path = Path(value)
        if path.is_absolute():
            return str(path) if path.is_file() else None
        return shutil.which(value)

    def start_detached(self, argv: Sequence[str], *, allowed_executables: Sequence[str]) -> bool:
        """Start a fixed infrastructure application without shell interpretation."""
        args = tuple(str(value) for value in argv)
        if not args or len(args) > 32:
            return False
        executable = self.resolve_executable(args[0])
        allowed = {Path(str(item)).name.lower() for item in allowed_executables if str(item).strip()}
        if executable is None or Path(executable).name.lower() not in allowed:
            return False
        try:
            kwargs = {"cwd": str(self.workspace), "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
            if __import__("os").name == "nt":
                kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            else:
                kwargs["start_new_session"] = True
            subprocess.Popen((executable, *args[1:]), shell=False, **kwargs)
            return True
        except (OSError, ValueError) as exc:
            logger.warning("trusted_detached_process_failed", extra={"executable": Path(executable).name, "error": str(exc)})
            return False

    def run(self, argv: Sequence[str], *, allowed_executables: Sequence[str]) -> TrustedProcessResult:
        """Execute a fixed argv vector when its executable is explicitly allowlisted."""
        args = tuple(str(value) for value in argv)
        if not args or len(args) > 64 or any(len(value) > 8192 for value in args):
            return TrustedProcessResult(False, error="invalid process arguments")
        executable = self.resolve_executable(args[0])
        allowed = {Path(str(item)).name.lower() for item in allowed_executables if str(item).strip()}
        if executable is None or Path(executable).name.lower() not in allowed:
            return TrustedProcessResult(False, error="trusted executable is not allowlisted")
        command = (executable, *args[1:])
        try:
            result = self.sandbox.run(command)
            return TrustedProcessResult(bool(result.get("ok")), str(result.get("stdout", "")), str(result.get("stderr", "")), result.get("returncode"), bool(result.get("timed_out", False)), None if result.get("ok") else str(result.get("stderr", "")).strip() or "process failed")
        except Exception as exc:
            logger.exception("trusted_process_failed", extra={"executable": Path(executable).name})
            return TrustedProcessResult(False, error=f"{type(exc).__name__}: {exc}")



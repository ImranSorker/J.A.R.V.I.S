"""Verified cognitive loop orchestration with explicit side-effect boundaries."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class CognitiveTrace:
    """Immutable trace of one perceive-to-learn cycle."""

    trace_id: str
    input_text: str
    perception: dict[str, Any]
    memory_context: dict[str, Any]
    reasoning: dict[str, Any]
    plan: dict[str, Any]
    authorization: dict[str, Any]
    action: dict[str, Any]
    verification: dict[str, Any]
    learning: dict[str, Any]
    duration_ms: float
    success: bool
    created_at: float = field(default_factory=time.time)


class CognitiveLoop:
    """Run a deterministic cognitive loop from observation to verified learning."""

    def __init__(
        self,
        *,
        perceive: Callable[[str], dict[str, Any]],
        remember: Callable[[str, dict[str, Any]], dict[str, Any]],
        reason: Callable[[str, dict[str, Any]], dict[str, Any]],
        plan: Callable[[str, dict[str, Any]], dict[str, Any]],
        authorize: Callable[[dict[str, Any]], dict[str, Any]],
        act: Callable[[dict[str, Any]], dict[str, Any]],
        verify: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]],
        learn: Callable[[CognitiveTrace], dict[str, Any]],
    ) -> None:
        self._perceive = perceive
        self._remember = remember
        self._reason = reason
        self._plan = plan
        self._authorize = authorize
        self._act = act
        self._verify = verify
        self._learn = learn

    def run(self, input_text: str) -> CognitiveTrace:
        """Execute one cycle, never invoking action before authorization succeeds."""
        text = str(input_text).strip()
        if not text:
            raise ValueError("input_text is required")
        started = time.perf_counter()
        trace_id = f"cog_{uuid.uuid4().hex[:16]}"
        perception = self._perceive(text)
        memory_context = self._remember(text, perception)
        reasoning = self._reason(text, memory_context)
        plan = self._plan(text, reasoning)
        authorization = self._authorize(plan)
        if not bool(authorization.get("approved")):
            verification = {"ok": False, "reason": "authorization_denied"}
            trace = CognitiveTrace(trace_id, text, perception, memory_context, reasoning, plan, authorization, {"ok": False, "skipped": True}, verification, {}, (time.perf_counter() - started) * 1000.0, False)
            learning = self._learn(trace)
            return CognitiveTrace(trace.trace_id, trace.input_text, trace.perception, trace.memory_context, trace.reasoning, trace.plan, trace.authorization, trace.action, trace.verification, dict(learning), trace.duration_ms, False, trace.created_at)
        action = self._act(plan)
        verification = self._verify(plan, action)
        success = bool(verification.get("ok"))
        trace = CognitiveTrace(trace_id, text, perception, memory_context, reasoning, plan, authorization, action, verification, {}, (time.perf_counter() - started) * 1000.0, success)
        learning = self._learn(trace)
        return CognitiveTrace(trace.trace_id, trace.input_text, trace.perception, trace.memory_context, trace.reasoning, trace.plan, trace.authorization, trace.action, trace.verification, dict(learning), (time.perf_counter() - started) * 1000.0, success, trace.created_at)



"""Unified Execution Broker — single authoritative execution boundary for JARVIS.

Consolidates all subprocess, code, and shell execution paths into one
observable, authorized, resource-bounded, validated execution path.

Architecture:
    Tool / Agent Request
      -> CapabilityPolicy (what is allowed)
      -> Authorization/Approval (who approved it)
      -> ResourceLimits (cpu, memory, time, output, files)
      -> ExecutionBroker (this module)
      -> OS isolation (subprocess with restrictions)
      -> ResultValidator (schema validation)
      -> Audit log

No application feature may directly invoke subprocess/process execution
when the operation belongs to the execution broker.
"""
from __future__ import annotations

import enum
import logging
import os
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.schema_validator import SchemaValidator
from core.policy_gateway import PolicyGateway, RiskLevel

logger = logging.getLogger("jarvis.execution_broker")

_SAFE_ENV_KEYS = frozenset({
    "PATH", "HOME", "TMP", "TEMP", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE",
    "TERM", "SYSTEMROOT", "WINDIR", "COMSPEC", "VIRTUAL_ENV",
})
_DANGEROUS_ENV_KEYS = frozenset({
    "LD_PRELOAD", "LD_LIBRARY_PATH", "LD_AUDIT", "DYLD_INSERT_LIBRARIES",
    "DYLD_LIBRARY_PATH", "PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP",
    "PYTHONINSPECT", "NODE_OPTIONS", "RUBYOPT", "PERL5OPT", "GEM_HOME",
})


class ExecutionPolicy(enum.Enum):
    """Execution isolation policy."""
    DENY = "deny"
    ALLOW_SUBPROCESS = "allow_subprocess"
    ALLOW_SHELL = "allow_shell"
    ALLOW_CODE = "allow_code"


@dataclass(frozen=True)
class CapabilityPolicy:
    """What a principal is allowed to execute."""
    allowed_schemes: Tuple[str, ...] = ()
    allowed_executables: Tuple[str, ...] = ()
    allow_shell: bool = False
    allow_code_execution: bool = False
    max_timeout_seconds: int = 30
    max_output_bytes: int = 100_000
    max_file_size_bytes: int = 10_000_000
    workspace_root: Optional[Path] = None
    allow_network: bool = False
    strict_isolation: bool = False
    max_memory_mb: int = 1024
    environment_denylist: Tuple[str, ...] = (
        "JARVIS_MASTER_SECRET",
        "JARVIS_API_TOKEN",
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "GROQ_API_KEY",
        "AWS_SECRET_ACCESS_KEY",
        "GITHUB_TOKEN",
        "PRIVATE_KEY",
        "PASSWORD",
        "SECRET",
    )


@dataclass(frozen=True)
class ExecutionRequest:
    """A validated, authorized execution request."""
    request_id: str
    principal: str
    capability: str
    command: Optional[str] = None
    argv: Optional[List[str]] = None
    code: Optional[str] = None
    language: str = "python"
    cwd: Optional[Path] = None
    env: Optional[Dict[str, str]] = None
    timeout_seconds: int = 30
    approval_token: Optional[str] = None
    output_schema: Optional[Dict[str, Any]] = None
    correlation_id: Optional[str] = None
    session_id: Optional[str] = None
    mission_id: Optional[str] = None
    execution_grant: Optional[str] = None


@dataclass(frozen=True)
class ExecutionResult:
    """Result of a brokered execution."""
    ok: bool
    stdout: str = ""
    stderr: str = ""
    returncode: Optional[int] = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    request_id: str = ""
    truncated: bool = False
    killed: bool = False


class ExecutionBroker:
    """Single authoritative execution boundary.

    Usage:
        broker = ExecutionBroker(policy=CapabilityPolicy(...))
        result = broker.execute(request)
    """

    def __init__(
        self,
        policy: Optional[CapabilityPolicy] = None,
        permission_engine: Optional[Any] = None,
        schema_validator: Optional[SchemaValidator] = None,
        autonomy_engine: Optional[Any] = None,
        policy_gateway: Optional[PolicyGateway] = None,
        kernel: Optional[Any] = None,
    ) -> None:
        self._policy = policy or CapabilityPolicy()
        self._permissions = permission_engine
        self._autonomy = autonomy_engine
        self._policy_gateway = policy_gateway
        self._kernel = kernel
        self._validator = schema_validator or SchemaValidator()
        self._lock = threading.RLock()
        self._active_processes: Dict[str, subprocess.Popen] = {}
        self._shutdown = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def forget_process(self, process: subprocess.Popen) -> None:
        """Remove a completed trusted process from broker ownership tracking."""
        with self._lock:
            stale = [key for key, value in self._active_processes.items() if value is process]
            for key in stale:
                self._active_processes.pop(key, None)

    def start_trusted_argv(
        self,
        argv: List[str],
        *,
        principal: str,
        capability: str,
        cwd: Optional[Path],
        allowed_executables: Tuple[str, ...],
        env: Optional[Dict[str, str]] = None,
    ) -> subprocess.Popen:
        """Start one explicitly allowlisted infrastructure process through the broker."""
        if not argv or not all(isinstance(item, str) and item for item in argv):
            raise ValueError("trusted argv is empty or malformed")
        executable = str(argv[0])
        resolved = shutil.which(executable)
        if resolved is None and Path(executable).is_file():
            resolved = str(Path(executable).resolve())
        if resolved is None:
            raise FileNotFoundError(executable)
        allowlist = {Path(item).name.lower() for item in allowed_executables}
        if Path(resolved).name.lower() not in allowlist:
            raise PermissionError("trusted executable is not allowlisted")
        launch_cwd = self._resolve_cwd(cwd)
        sanitized_env = self._sanitize_env(env)
        request_id = f"trusted_{uuid.uuid4().hex[:12]}"
        process = subprocess.Popen(
            [resolved, *argv[1:]],
            cwd=str(launch_cwd) if launch_cwd else None,
            env=sanitized_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            shell=False,
            start_new_session=(os.name == "posix"),
        )
        with self._lock:
            self._active_processes[request_id] = process
        return process

    def execute_trusted_argv(
        self,
        argv: List[str],
        *,
        principal: str,
        capability: str,
        cwd: Optional[Path],
        timeout_seconds: float,
        allowed_executables: Tuple[str, ...],
        env: Optional[Dict[str, str]] = None,
    ) -> ExecutionResult:
        """Execute one infrastructure-owned executable without shell semantics.

        This path is reserved for explicitly trusted runtime adapters such as
        DSec. It still enforces executable allowlisting, bounded timeout,
        sanitized environment, output limits and brokered process cleanup.
        It never accepts a command string or shell expression.
        """
        if not argv or not all(isinstance(item, str) and item for item in argv):
            return ExecutionResult(ok=False, error="trusted argv is empty or malformed")
        executable = str(argv[0])
        resolved = shutil.which(executable)
        if resolved is None and Path(executable).is_file():
            resolved = str(Path(executable).resolve())
        if resolved is None:
            return ExecutionResult(ok=False, error="trusted executable is unavailable")
        allowlist = {Path(item).name.lower() for item in allowed_executables}
        if Path(resolved).name.lower() not in allowlist:
            return ExecutionResult(ok=False, error="trusted executable is not allowlisted")
        bounded_timeout = max(1, min(int(float(timeout_seconds)), 3600))
        try:
            launch_cwd = self._resolve_cwd(cwd)
        except PermissionError as exc:
            return ExecutionResult(ok=False, error=str(exc))
        sanitized_env = self._sanitize_env(env)
        return self._run_subprocess([resolved, *argv[1:]], launch_cwd, sanitized_env, bounded_timeout, f"trusted_{uuid.uuid4().hex[:12]}", shell=False)

    def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Execute a request through the full broker pipeline."""
        start = time.perf_counter()
        req_id = request.request_id or f"exec_{uuid.uuid4().hex[:12]}"

        if self._kernel is not None:
            try:
                self._kernel.publish("execution.requested", {
                    "request_id": req_id, "principal": request.principal, "capability": request.capability,
                    "mission_id": request.mission_id, "correlation_id": request.correlation_id,
                    "payload_kind": "code" if request.code is not None else "argv" if request.argv is not None else "command" if request.command is not None else "none",
                }, correlation_id=request.correlation_id)
            except Exception:
                logger.exception("kernel_execution_journal_failed", extra={"request_id": req_id})

        if self._shutdown:
            return self._error(req_id, "Execution broker is shut down")

        # 1. Validate request structure
        validation = self._validate_request(request)
        if not validation["ok"]:
            return self._error(req_id, validation["error"])

        # 2. Check capability policy
        policy_check = self._check_policy(request)
        if not policy_check["ok"]:
            return self._error(req_id, policy_check["error"])

        # 3. Canonical policy gateway. Legacy authorization remains as a
        # compatibility check, but can never bypass the gateway.
        if self._policy_gateway is not None:
            decision = self._policy_gateway.evaluate(
                capability=request.capability,
                risk=RiskLevel.L2,
                mission_id=request.mission_id,
                grant=request.execution_grant or request.approval_token,
            )
            if not decision.allowed:
                return self._error(req_id, decision.reason)

        # 4. Verify legacy/cryptographic execution authorization
        auth_check = self._verify_authorization(request)
        if not auth_check["ok"]:
            return self._error(req_id, auth_check["error"])

        # 5. Canonical 12.8.0 kernel policy is authoritative for process/code paths.
        if self._kernel is not None:
            try:
                from core.kernel_12_8_0.contracts import CapabilityRequest
                kernel_decision = self._kernel.authorize(
                    CapabilityRequest(
                        request.capability,
                        reason="execution broker",
                        risk="high",
                        ttl_seconds=int(request.timeout_seconds),
                        mission_id=request.mission_id,
                        principal=request.principal,
                    ),
                    approved=bool(auth_check.get("ok")),
                )
                if not kernel_decision.allowed:
                    return self._error(req_id, kernel_decision.reason)
            except Exception as exc:
                logger.exception("kernel_execution_authority_failed", extra={"request_id": req_id})
                return self._error(req_id, f"Kernel execution authority failed: {exc}")

        # 6. Apply resource limits
        bounded = self._apply_resource_limits(request)

        # 7. Execute with isolation
        try:
            if request.code is not None:
                result = self._execute_code(bounded, req_id)
            elif request.argv is not None:
                result = self._execute_argv(bounded, req_id)
            elif request.command is not None:
                result = self._execute_command(bounded, req_id)
            else:
                return self._error(req_id, "No executable payload")
        except Exception as exc:
            logger.exception("execution_broker_error", extra={"request_id": req_id})
            return self._error(req_id, f"Execution failed: {exc}")

        # 8. Validate output schema
        if result.ok and request.output_schema:
            try:
                self._validator.validate_or_raise(
                    {"stdout": result.stdout, "stderr": result.stderr, "returncode": result.returncode},
                    request.output_schema,
                )
            except Exception as exc:
                return ExecutionResult(
                    ok=False,
                    error=f"Output schema validation failed: {exc}",
                    request_id=req_id,
                    execution_time_ms=(time.perf_counter() - start) * 1000,
                )

        # 9. Audit log
        elapsed = (time.perf_counter() - start) * 1000
        logger.info(
            "execution_completed",
            extra={
                "request_id": req_id,
                "principal": request.principal,
                "capability": request.capability,
                "ok": result.ok,
                "returncode": result.returncode,
                "execution_time_ms": elapsed,
                "truncated": result.truncated,
                "killed": result.killed,
            },
        )
        final_result = ExecutionResult(
            ok=result.ok,
            stdout=result.stdout,
            stderr=result.stderr,
            returncode=result.returncode,
            error=result.error,
            execution_time_ms=elapsed,
            request_id=req_id,
            truncated=result.truncated,
            killed=result.killed,
        )
        if self._kernel is not None:
            try:
                self._kernel.publish("execution.completed", {
                    "request_id": req_id, "principal": request.principal, "capability": request.capability,
                    "ok": final_result.ok, "returncode": final_result.returncode,
                    "output_digest": __import__("hashlib").sha256(final_result.stdout.encode("utf-8")).hexdigest(),
                    "stderr_digest": __import__("hashlib").sha256(final_result.stderr.encode("utf-8")).hexdigest(),
                    "elapsed_ms": elapsed,
                }, correlation_id=request.correlation_id)
            except Exception:
                logger.exception("kernel_execution_completion_journal_failed", extra={"request_id": req_id})
        return final_result

    def cancel(self, request_id: str) -> bool:
        """Cancel an active execution by request ID."""
        with self._lock:
            proc = self._active_processes.get(request_id)
        if proc is None or proc.poll() is not None:
            return False
        try:
            # Graceful termination first
            proc.terminate()
            try:
                proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=1.0)
            logger.info("execution_cancelled", extra={"request_id": request_id})
            return True
        except Exception as exc:
            logger.warning("execution_cancel_failed", extra={"request_id": request_id, "error": str(exc)})
            return False

    def shutdown(self, timeout: float = 5.0) -> None:
        """Cancel all active executions and mark broker as shut down."""
        self._shutdown = True
        with self._lock:
            procs = list(self._active_processes.items())
        for req_id, proc in procs:
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    logger.debug("execution_process_kill_failed", exc_info=True)
        # Wait briefly for cleanup
        deadline = time.monotonic() + timeout
        for req_id, proc in procs:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                proc.wait(timeout=max(0.1, remaining))
            except Exception:
                logger.debug("execution_process_wait_failed", exc_info=True)
        with self._lock:
            self._active_processes.clear()
        logger.info("execution_broker_shutdown")

    # ------------------------------------------------------------------
    # Internal pipeline stages
    # ------------------------------------------------------------------

    def _validate_request(self, request: ExecutionRequest) -> Dict[str, Any]:
        """Structural validation before policy/authorization."""
        if not request.principal or len(request.principal) > 256:
            return {"ok": False, "error": "Invalid principal"}
        if not request.capability or len(request.capability) > 256:
            return {"ok": False, "error": "Invalid capability"}
        if request.timeout_seconds < 1 or request.timeout_seconds > 3600:
            return {"ok": False, "error": "Timeout must be 1-3600 seconds"}
        payloads = int(request.code is not None) + int(request.command is not None) + int(request.argv is not None)
        if payloads != 1:
            return {"ok": False, "error": "exactly one executable payload is required"}
        if request.code is not None:
            if request.language != "python":
                return {"ok": False, "error": "only python execution is supported"}
            if "\x00" in request.code or len(request.code.encode("utf-8")) > 1_000_000:
                return {"ok": False, "error": "Code is empty, contains NUL bytes, or exceeds 1MB limit"}
        if request.command is not None:
            if "\x00" in request.command or len(request.command.encode("utf-8")) > 8192:
                return {"ok": False, "error": "Command contains NUL bytes or exceeds 8KB limit"}
        if request.argv is not None:
            if not request.argv or len(request.argv) > 128:
                return {"ok": False, "error": "argv must contain 1-128 arguments"}
            if any("\x00" in str(item) or len(str(item).encode("utf-8")) > 16384 for item in request.argv):
                return {"ok": False, "error": "argv contains an invalid argument"}
        if request.env is not None:
            if len(request.env) > 64:
                return {"ok": False, "error": "environment exceeds 64 variables"}
            if any("\x00" in str(k) or "\x00" in str(v) for k, v in request.env.items()):
                return {"ok": False, "error": "environment contains NUL bytes"}
        return {"ok": True}

    def _check_policy(self, request: ExecutionRequest) -> Dict[str, Any]:
        """Check if the request is allowed by capability policy."""
        if request.code is not None and not self._policy.allow_code_execution:
            return {"ok": False, "error": "Code execution not permitted by policy"}
        if request.command is not None and not self._policy.allow_shell:
            return {"ok": False, "error": "Shell execution not permitted by policy"}
        if request.argv is not None and not self._policy.allowed_executables:
            return {"ok": False, "error": "Subprocess execution not permitted by policy"}
        if request.timeout_seconds > self._policy.max_timeout_seconds:
            return {"ok": False, "error": f"Timeout exceeds policy limit of {self._policy.max_timeout_seconds}s"}
        return {"ok": True}

    def _verify_authorization(self, request: ExecutionRequest) -> Dict[str, Any]:
        """Verify approval token if required."""
        if request.mission_id:
            if self._autonomy is None or not request.execution_grant:
                return {"ok": False, "error": "cryptographic mission execution grant required"}
            verifier = getattr(self._autonomy, "verify_execution_grant", None)
            if not callable(verifier) or not verifier(request.execution_grant, request.mission_id, request.capability, request.principal):
                return {"ok": False, "error": "invalid mission execution grant"}
            return {"ok": True}
        if self._permissions is None:
            return {"ok": True}
        verifier = getattr(self._permissions, "verify", None)
        if not callable(verifier):
            return {"ok": True}
        if not request.approval_token:
            return {"ok": False, "error": "Approval token required"}
        if not verifier(request.approval_token, capability=request.capability):
            return {"ok": False, "error": "Invalid or unauthorized approval token"}
        return {"ok": True}

    def _apply_resource_limits(self, request: ExecutionRequest) -> ExecutionRequest:
        """Clamp request to policy limits."""
        timeout = min(request.timeout_seconds, self._policy.max_timeout_seconds)
        return ExecutionRequest(
            request_id=request.request_id,
            principal=request.principal,
            capability=request.capability,
            command=request.command,
            argv=request.argv,
            code=request.code,
            language=request.language,
            cwd=request.cwd,
            env=request.env,
            timeout_seconds=timeout,
            approval_token=request.approval_token,
            output_schema=request.output_schema,
            correlation_id=request.correlation_id,
            session_id=request.session_id,
            mission_id=request.mission_id,
            execution_grant=request.execution_grant,
        )

    # ------------------------------------------------------------------
    # Execution backends
    # ------------------------------------------------------------------

    def _execute_argv(self, request: ExecutionRequest, req_id: str) -> ExecutionResult:
        """Execute argv with shell=False."""
        argv = request.argv
        assert argv is not None
        if not argv:
            return ExecutionResult(ok=False, error="Empty argv", request_id=req_id)

        executable = argv[0]
        resolved = shutil.which(executable)
        candidates = {executable.lower(), Path(executable).name.lower()}
        if resolved:
            candidates.add(Path(resolved).name.lower())
        allowlist = {item.lower() for item in self._policy.allowed_executables}
        if allowlist and not (candidates & allowlist):
            return ExecutionResult(ok=False, error="Executable not permitted by policy", request_id=req_id)

        try:
            cwd = self._resolve_cwd(request.cwd)
        except PermissionError as exc:
            return ExecutionResult(ok=False, error=str(exc), request_id=req_id)
        env = self._sanitize_env(request.env)

        return self._run_subprocess([resolved, *argv[1:]], cwd, env, request.timeout_seconds, req_id, shell=False)

    def _execute_command(self, request: ExecutionRequest, req_id: str) -> ExecutionResult:
        """Execute command string with shell=False (shlex split)."""
        import shlex
        command = request.command
        assert command is not None
        if any(op in command for op in ("&&", "||", ";;", "|", ";", "`", "$()")):
            return ExecutionResult(ok=False, error="Command chaining/operators not permitted", request_id=req_id)
        try:
            argv = shlex.split(command, posix=(os.name != "nt"))
        except ValueError as exc:
            return ExecutionResult(ok=False, error=f"Invalid command syntax: {exc}", request_id=req_id)
        if not argv:
            return ExecutionResult(ok=False, error="Empty command after parsing", request_id=req_id)
        # Reuse argv path
        return self._execute_argv(
            ExecutionRequest(
                request_id=request.request_id,
                principal=request.principal,
                capability=request.capability,
                argv=argv,
                cwd=request.cwd,
                env=request.env,
                timeout_seconds=request.timeout_seconds,
                approval_token=request.approval_token,
                correlation_id=request.correlation_id,
                session_id=request.session_id,
                mission_id=request.mission_id,
                execution_grant=request.execution_grant,
            ),
            req_id,
        )

    def _execute_code(self, request: ExecutionRequest, req_id: str) -> ExecutionResult:
        """Execute Python in a bounded child process with optional OS sandboxing."""
        if request.language != "python":
            return ExecutionResult(ok=False, error=f"Language '{request.language}' not supported", request_id=req_id)
        code = request.code or ""
        tmp_path: Optional[Path] = None
        try:
            root = self._resolve_cwd(request.cwd) or Path.cwd()
            root.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8", dir=root) as handle:
                handle.write(code); tmp_path=Path(handle.name)
            python = shutil.which("python") or shutil.which("python3") or "python"
            argv = [python, "-I", "-B", tmp_path.name]
            return self._run_subprocess(argv, root, self._sanitize_env(request.env), request.timeout_seconds, req_id, shell=False, sandbox_workspace=root)
        finally:
            if tmp_path and tmp_path.exists():
                try:tmp_path.unlink()
                except OSError as exc:logger.debug("execution_temp_cleanup_failed", extra={"request_id": req_id, "error": str(exc)})

    def _run_subprocess(self, argv: List[str], cwd: Optional[Path], env: Optional[Dict[str, str]], timeout: int, req_id: str, shell: bool = False, sandbox_workspace: Optional[Path] = None) -> ExecutionResult:
        """Run a process with bounded output, timeout, process-group cleanup and resource limits."""
        proc: Optional[subprocess.Popen] = None
        windows_job = None
        launch_argv=list(argv)
        launch_cwd=cwd
        if sandbox_workspace is not None and self._policy.strict_isolation:
            if os.name == "nt":
                try:
                    from security.windows_job import WindowsJob

                    windows_job = WindowsJob(max(128, int(self._policy.max_memory_mb)) * 1024 * 1024)
                except Exception as exc:
                    return ExecutionResult(ok=False, error=f"strict Windows isolation unavailable: {exc}", request_id=req_id)
            else:
                bwrap=shutil.which("bwrap")
                if bwrap is None:
                    return ExecutionResult(ok=False, error="strict Linux isolation requires bubblewrap", request_id=req_id)
                workspace=sandbox_workspace.resolve()
                launch_argv=[bwrap,"--die-with-parent","--new-session","--ro-bind","/usr","/usr","--ro-bind","/bin","/bin","--ro-bind","/lib","/lib","--ro-bind","/lib64","/lib64","--proc","/proc","--dev","/dev","--tmpfs","/tmp","--bind",str(workspace),"/workspace","--chdir","/workspace"]  # nosec B108 -- private tmpfs mount inside the bubblewrap sandbox; the correct isolation, not an insecure temp dir
                if not self._policy.allow_network:launch_argv.append("--unshare-net")
                launch_argv += [x if x != str(workspace / Path(argv[-1]).name) else "/workspace/"+Path(argv[-1]).name for x in argv]
                launch_cwd=workspace
        try:
            kwargs: Dict[str, Any]={"stdout":subprocess.PIPE,"stderr":subprocess.PIPE,"text":True,"cwd":str(launch_cwd) if launch_cwd else None,"env":env,"shell":shell}
            if os.name=="nt":kwargs["creationflags"]=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)
            else:
                kwargs["start_new_session"]=True
                try:
                    import resource
                    cpu_limit=max(1,int(timeout)); memory=max(128,int(self._policy.max_memory_mb))*1024*1024; file_limit=max(self._policy.max_file_size_bytes,self._policy.max_output_bytes)
                    def limits()->None:
                        resource.setrlimit(resource.RLIMIT_CPU,(cpu_limit,cpu_limit+1)); resource.setrlimit(resource.RLIMIT_AS,(memory,memory)); resource.setrlimit(resource.RLIMIT_FSIZE,(file_limit,file_limit)); resource.setrlimit(resource.RLIMIT_CORE,(0,0))
                    kwargs["preexec_fn"]=limits
                except (ImportError,OSError,AttributeError) as exc:logger.debug("resource_limit_setup_unavailable",extra={"error":str(exc)})
            proc=subprocess.Popen(launch_argv,**kwargs)
            if windows_job is not None:
                try:
                    windows_job.assign(proc.pid)
                except Exception as exc:
                    try:
                        proc.kill()
                        proc.wait(timeout=1)
                    except Exception:
                        logger.debug("windows_job_assignment_cleanup_failed", exc_info=True)
                    return ExecutionResult(ok=False, error=f"strict Windows isolation assignment failed: {exc}", request_id=req_id, killed=True)
            with self._lock:self._active_processes[req_id]=proc
            stdout,stderr=proc.communicate(timeout=timeout); max_out=self._policy.max_output_bytes; truncated=False
            if len(stdout)>max_out:stdout=stdout[:max_out]+"\n[stdout truncated]";truncated=True
            if len(stderr)>max_out:stderr=stderr[:max_out]+"\n[stderr truncated]";truncated=True
            return ExecutionResult(ok=proc.returncode==0,stdout=stdout,stderr=stderr,returncode=proc.returncode,request_id=req_id,truncated=truncated)
        except subprocess.TimeoutExpired:
            if proc is not None:
                try:
                    if os.name!="nt":
                        try:os.killpg(proc.pid,signal.SIGKILL)
                        except OSError:proc.kill()
                    else:proc.kill()
                    proc.wait(timeout=1)
                except Exception as exc:logger.debug("execution_timeout_cleanup_failed",extra={"request_id":req_id,"error":str(exc)})
            return ExecutionResult(ok=False,error=f"Execution timed out after {timeout}s",request_id=req_id,killed=True)
        except Exception as exc:
            if proc is not None and proc.poll() is None:
                try:proc.kill()
                except Exception as kill_exc:logger.debug("execution_error_cleanup_failed",extra={"request_id":req_id,"error":str(kill_exc)})
            return ExecutionResult(ok=False,error=f"Execution failed: {exc}",request_id=req_id)
        finally:
            with self._lock:self._active_processes.pop(req_id,None)
            if windows_job is not None:
                try:
                    windows_job.close()
                except Exception:
                    logger.debug("windows_job_close_failed", extra={"request_id": req_id}, exc_info=True)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_cwd(self, cwd: Optional[Path]) -> Optional[Path]:
        """Resolve and validate working directory against workspace root."""
        if cwd is None:
            return self._policy.workspace_root
        resolved = cwd.resolve()
        root = self._policy.workspace_root
        if root is not None:
            try:
                resolved.relative_to(root)
            except ValueError as exc:
                logger.warning("cwd_outside_workspace", extra={"cwd": str(resolved), "root": str(root)})
                raise PermissionError("working directory escapes workspace") from exc
        if not resolved.is_dir():
            raise PermissionError("working directory does not exist")
        return resolved

    def _sanitize_env(self, env: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        """Return a minimal environment and reject loader/interpreter injection variables."""
        source = dict(os.environ) if env is None else {str(k): str(v) for k, v in env.items()}
        safe: Dict[str, str] = {}
        for key, value in source.items():
            upper = key.upper()
            if upper in _DANGEROUS_ENV_KEYS:
                continue
            if any(denied in upper for denied in self._policy.environment_denylist):
                continue
            if upper not in _SAFE_ENV_KEYS and not upper.startswith("LC_"):
                continue
            safe[key] = value
        if "PATH" not in safe:
            safe["PATH"] = os.defpath
        return safe

    def _error(self, req_id: str, message: str) -> ExecutionResult:
        logger.warning("execution_rejected", extra={"request_id": req_id, "error": message})
        return ExecutionResult(ok=False, error=message, request_id=req_id)



"""MCP-facing capability registry and invocation contract."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping
from .integration_fabric import IntegrationDescriptor, IntegrationFabric

@dataclass(frozen=True, slots=True)
class MCPTool:
    """Declared MCP tool; invocation is delegated to an approved adapter."""
    server_id: str
    name: str
    input_schema: Mapping[str, object]
    capability: str

class MCPGateway:
    """Register MCP servers/tools without granting them execution authority."""
    def __init__(self, integrations: IntegrationFabric | None = None) -> None:
        self.integrations = integrations or IntegrationFabric()
        self._tools: dict[str, MCPTool] = {}

    def register_server(self, server_id: str, capabilities: tuple[str, ...], trusted: bool = False) -> None:
        """Register a server descriptor."""
        self.integrations.register(IntegrationDescriptor(server_id, "mcp", capabilities, trusted))

    def register_tool(self, tool: MCPTool) -> None:
        """Register a typed tool declaration."""
        if tool.server_id not in {item.integration_id for item in self.integrations.list("mcp")}:
            raise ValueError("MCP server is not registered")
        key = f"{tool.server_id}:{tool.name}"
        if key in self._tools:
            raise ValueError("MCP tool already registered")
        self._tools[key] = tool

    def describe(self) -> tuple[MCPTool, ...]:
        """Return deterministic tool declarations."""
        return tuple(self._tools[key] for key in sorted(self._tools))



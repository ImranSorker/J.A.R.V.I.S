from __future__ import annotations

"""P2-T Autonomous System Doctor.

Observes declared signals, compares them to signed immutable baselines, runs a
versioned deterministic detector catalog, correlates symptoms, produces ranked
root-cause hypotheses with explicit evidence, and proposes (never applies)
remediation.
"""

import hashlib
import json
import math
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

try:
    from jsonschema import Draft202012Validator, FormatChecker
    from referencing import Registry, Resource
except Exception:  # pragma: no cover - dependencies are part of the release
    Draft202012Validator = None  # type: ignore[assignment]
    FormatChecker = None  # type: ignore[assignment]
    Registry = None  # type: ignore[assignment]
    Resource = None  # type: ignore[assignment]


VERSION = "1.0.0"
P2T_VERSION = "12.8.3"
KERNEL_VERSION = "12.8.0"
NAMESPACE = uuid.UUID("6e8f2c8f-b2f8-5fcb-8fcf-8c32f9f5bf85")

SYMPTOM_CLASSES = (
    "degradation", "outage", "latency", "error_rate", "resource_pressure", "instability",
    "drift", "anomaly", "security_signal", "integrity_signal", "cascade", "silence",
)
CONFIDENCE_LEVELS = ("confirmed", "high", "medium", "low", "inconclusive", "contradicted")
METHODS = (
    "baseline_comparison", "threshold", "correlation", "differential", "causal_path", "replay",
    "simulation", "statistical", "rule_based", "manual",
)
REMEDIATION_CLASSES = (
    "none", "observe", "adjust_budget", "adjust_policy", "restart_component", "rollback_deployment",
    "attenuate_agent", "suspend_agent", "quarantine_agent", "reload_model", "rebalance_residency",
    "drain_and_recover", "escalate_human",
)
OUTCOMES = ("healthy", "degraded", "critical", "unknown", "resolved", "recurring", "escalated", "remediated")
PROPOSAL_STATES = ("proposed", "approved", "applied", "rejected", "superseded", "none")
DIAGNOSIS_STATES = ("open", "triaged", "analyzed", "proposed", "remediated", "verified", "closed", "inconclusive")
BLAST_RADIUS = ("none", "local", "regional", "global")
RISK_LEVELS = ("none", "low", "medium", "high", "critical")
DETERMINISM = ("deterministic", "seeded")
REQUIRED_DETECTORS = (
    "BaselineDeviationDetector", "ThresholdDetector", "CorrelationDetector", "CascadeDetector",
    "FlappingDetector", "DriftDetector", "SilenceDetector", "ResourcePressureDetector",
    "QueueBacklogDetector", "DeadlockDetector", "ReplayDivergenceDetector", "AttestationDriftDetector",
    "CollusionSurgeDetector", "RecurrenceDetector", "StatisticalAnomalyDetector",
)

MONITORING_MATRIX: dict[str, dict[str, Any]] = {
    "host_cpu": {"label": "Host CPU", "layer": "Host", "signals": ["cpu_utilization", "load_avg", "context_switches", "steal"], "source": "declared.interface:host.cpu"},
    "host_ram": {"label": "Host RAM", "layer": "Host", "signals": ["ram_used", "ram_free", "swap", "page_faults"], "source": "declared.interface:host.memory"},
    "host_gpu": {"label": "Host GPU", "layer": "Host", "signals": ["gpu_utilization", "vram_used", "temperature", "throttling"], "source": "declared.interface:host.gpu"},
    "host_disk": {"label": "Host disk", "layer": "Host", "signals": ["throughput", "latency", "free_space", "io_errors"], "source": "declared.interface:host.disk"},
    "host_network": {"label": "Host network", "layer": "Host", "signals": ["throughput", "packet_loss", "errors", "dns_latency"], "source": "declared.interface:host.network"},
    "processes": {"label": "Processes", "layer": "Host", "signals": ["count", "zombies", "rss_growth", "fd_leaks"], "source": "declared.interface:processes"},
    "services": {"label": "Services", "layer": "System", "signals": ["up_down", "restart_count", "health_check_latency"], "source": "declared.interface:services"},
    "event_fabric": {"label": "Event bus", "layer": "P2-U", "signals": ["throughput", "backlog", "dlq_growth", "consumer_lag"], "source": "P2-U Telemetry.*"},
    "harness": {"label": "Harness", "layer": "P2-E", "signals": ["execution_count", "budget_violations", "cancellations", "timeouts"], "source": "P2-E accounting"},
    "agents": {"label": "Agents", "layer": "P2-A/P2-D", "signals": ["lifecycle_state", "success_rate", "drift", "incidents"], "source": "P2-D history"},
    "skills": {"label": "Skills", "layer": "P2-F", "signals": ["invocation_success", "latency", "certification_status"], "source": "P2-F declared signal"},
    "tools": {"label": "Tools", "layer": "P2-P", "signals": ["health", "rate_limit_state", "error_rate", "determinism_deviation"], "source": "P2-P health"},
    "composite_tools": {"label": "Composite tools", "layer": "P2-Q", "signals": ["step_failures", "compensation_runs", "verification_hook_failures"], "source": "P2-Q events"},
    "models": {"label": "Models", "layer": "P2-O", "signals": ["residency", "vram_pressure", "latency", "routing_failures", "estimate_deviations"], "source": "P2-O telemetry"},
    "memory": {"label": "Memory", "layer": "P2-H", "signals": ["write_rate", "contradiction_count", "forgetting_pressure", "archive_depth"], "source": "P2-H declared signal"},
    "rag": {"label": "RAG/retrieval", "layer": "P2-H/P2-R", "signals": ["retrieval_latency", "hit_rate", "embedding_backlog"], "source": "P2-H/P2-R telemetry"},
    "world_model": {"label": "World Model", "layer": "P2-J", "signals": ["entity_count", "state_transition_rate", "causal_path_latency", "snapshot_cadence"], "source": "P2-J state feed"},
    "planning": {"label": "Planning", "layer": "P2-L", "signals": ["plan_success_rate", "contingency_trigger_rate", "simulation_divergence"], "source": "P2-L telemetry"},
    "simulation": {"label": "Simulation universe", "layer": "P2-K", "signals": ["universe_count", "isolation_breaches", "replay_divergences", "mandate_bypasses"], "source": "P2-K events"},
    "multi_agent": {"label": "Multi-Agent", "layer": "P2-M", "signals": ["delegation_depth", "deadlock_count", "divergence_count", "escalation_timeouts"], "source": "P2-M telemetry"},
    "a2a_verification": {"label": "A2A Verification", "layer": "P2-N", "signals": ["denial_rate", "drift_signals", "collusion_signals", "replay_rejections"], "source": "P2-N events"},
    "research": {"label": "Research", "layer": "P2-R", "signals": ["source_collection_rate", "grounding_failures", "contradiction_rates"], "source": "P2-R events"},
    "security_evolution": {"label": "Security Evolution", "layer": "P2-S", "signals": ["attestation_outcomes", "drift_events", "revocation_propagation", "bypass_attempts"], "source": "P2-S Security.*"},
    "failure_intelligence": {"label": "Failure Intelligence", "layer": "P2-I", "signals": ["ingestion_rate", "hypothesis_verification_rate", "closure_rate"], "source": "P2-I failure records"},
    "event_integrity": {"label": "Event Fabric integrity", "layer": "P2-U", "signals": ["envelope_integrity_failures", "schema_violations", "replay_divergences"], "source": "P2-U integrity telemetry"},
    "factory": {"label": "Factory", "layer": "P2-B", "signals": ["stage_duration", "refusal_reasons", "build", "test", "evaluate", "certify"], "source": "P2-B lifecycle events"},
    "garage": {"label": "Garage", "layer": "P2-D", "signals": ["deployments", "suspensions", "quarantine", "rollbacks"], "source": "P2-D histories"},
    "workshop": {"label": "Workshop", "layer": "P2-C", "signals": ["session_count", "evaluation_pass_rate", "promotion_rate"], "source": "P2-C evaluation records"},
}

# Each monitored subsystem has a stable, declared signal-schema URI.
for _subsystem, _entry in MONITORING_MATRIX.items():
    _entry.setdefault("signal_schema", f"urn:jarvis:p2t:signal:{_subsystem}:1.0.0")

EVENTS = {
    "BaselineComputed": "normal", "BaselineRegistered": "normal", "SignalCollected": "normal", "SignalMissing": "high",
    "AnomalyDetected": "high", "AnomalyCleared": "normal", "SymptomClustered": "normal", "DiagnosisOpened": "high",
    "DiagnosisClosed": "normal", "DiagnosisReopened": "high", "HypothesisRaised": "normal", "HypothesisVerified": "high",
    "HypothesisContradicted": "normal", "RemediationProposed": "normal", "RemediationWithdrawn": "normal",
    "RemediationApplied": "normal", "RemediationValidated": "normal", "RemediationUnvalidated": "high", "Escalated": "high",
    "EscalationTimeout": "high", "RecurrenceDetected": "high", "HealthChanged": "normal", "CascadeDetected": "high",
    "DeadlockDetected": "high", "ContinuousEvaluationStarted": "normal", "ContinuousEvaluationStopped": "normal",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canon(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str).encode("utf-8")


def _hash(value: Any) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


def _uuid(seed: Any) -> str:
    return str(uuid.uuid5(NAMESPACE, _hash(seed)))


def _semver(value: str) -> tuple[int, int, int, str]:
    main, _, suffix = str(value).partition("-")
    bits = main.split(".")
    if len(bits) != 3 or any(not b.isdigit() for b in bits):
        raise ValueError(f"invalid semver: {value}")
    return int(bits[0]), int(bits[1]), int(bits[2]), suffix


def _sign(body: Mapping[str, Any], signer: Ed25519PrivateKey) -> str:
    return signer.sign(_canon(body)).hex()


def _verify(body: Mapping[str, Any], signature: str, public_key: Ed25519PublicKey | bytes) -> bool:
    try:
        key = public_key if isinstance(public_key, Ed25519PublicKey) else Ed25519PublicKey.from_public_bytes(public_key)
        key.verify(bytes.fromhex(signature), _canon(body))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def _context_doc(context: Any) -> dict[str, Any]:
    if context is None:
        raise PermissionError("P2-T operations require a verified P2-E ExecutionContext")
    attrs = ("execution_id", "correlation_id", "environment_hash", "environment_id", "agent_id", "trust_level", "auth_context")
    if not all(hasattr(context, name) for name in attrs):
        raise PermissionError("context is not a P2-E ExecutionContext")
    auth = getattr(context, "auth_context", None)
    if auth is None or not getattr(auth, "principal", None) or not getattr(auth, "policy_ref", None):
        raise PermissionError("ExecutionContext lacks verified authorization context")
    principal = str(auth.principal)
    tenant = str(getattr(context, "tenant_id", getattr(auth, "tenant_id", "")) or (principal.split("/", 1)[0] if "/" in principal else "default"))
    return {
        "execution_id": str(context.execution_id), "correlation_id": str(context.correlation_id),
        "causation_id": getattr(context, "causation_id", None), "environment_hash": str(context.environment_hash),
        "environment_id": str(context.environment_id), "agent_id": str(context.agent_id), "trust_level": str(context.trust_level),
        "principal": principal, "policy_ref": str(auth.policy_ref), "tenant_id": tenant, "budgets": getattr(context, "budgets", None),
    }


def _tenant(context: Any) -> str:
    return _context_doc(context)["tenant_id"]


def _value_number(value: Any) -> float | None:
    if isinstance(value, bool): return float(value)
    if isinstance(value, (int, float)): return float(value)
    try: return float(value)
    except (TypeError, ValueError): return None


def _confidence_level(score: float, verified: bool = False, contradicted: bool = False) -> str:
    if contradicted: return "contradicted"
    if verified: return "confirmed"
    if score >= 0.85: return "high"
    if score >= 0.65: return "medium"
    if score >= 0.35: return "low"
    return "inconclusive"


@dataclass(frozen=True, slots=True)
class HealthBaseline:
    baseline_id: str
    baseline_version: str
    tenant_id: str
    environment_hash: str
    subsystem: str
    metric_or_signal: str
    window: Mapping[str, Any]
    statistics: Mapping[str, float]
    thresholds: Mapping[str, Any]
    seasonal: Mapping[str, Any]
    methodology: str
    methodology_version: str
    computed_by: Mapping[str, str]
    computed_at: str
    approved_by: Mapping[str, str] | None
    signature: str
    integrity_hash: str

    def unsigned(self) -> dict[str, Any]:
        return {
            "baseline_id": self.baseline_id, "baseline_version": self.baseline_version,
            "tenant_id": self.tenant_id, "environment_hash": self.environment_hash,
            "subsystem": self.subsystem, "metric_or_signal": self.metric_or_signal,
            "window": dict(self.window), "statistics": dict(self.statistics), "thresholds": dict(self.thresholds),
            "seasonal": dict(self.seasonal), "methodology": self.methodology, "methodology_version": self.methodology_version,
            "computed_by": dict(self.computed_by), "computed_at": self.computed_at, "approved_by": self.approved_by,
        }

    def to_dict(self) -> dict[str, Any]:
        d = self.unsigned(); d["signature"] = self.signature; d["integrity_hash"] = self.integrity_hash; return d


@dataclass(frozen=True, slots=True)
class DetectorSpec:
    detector_id: str
    detector_version: str
    symptom_class: tuple[str, ...]
    method: str
    inputs: tuple[str, ...]
    parameters: Mapping[str, Any]
    thresholds: Mapping[str, Any]
    determinism: str
    signed_by: Mapping[str, str]
    integrity_hash: str
    signature: str

    def unsigned(self) -> dict[str, Any]:
        return {
            "detector_id": self.detector_id, "detector_version": self.detector_version,
            "symptom_class": list(self.symptom_class), "method": self.method, "inputs": list(self.inputs),
            "parameters": dict(self.parameters), "thresholds": dict(self.thresholds), "determinism": self.determinism,
            "signed_by": dict(self.signed_by), "integrity_hash": self.integrity_hash,
        }

    def to_dict(self) -> dict[str, Any]:
        d=self.unsigned(); d["signature"]=self.signature; return d


@dataclass(frozen=True, slots=True)
class RemediationProposal:
    proposal_id: str
    diagnosis_id: str
    version: int
    class_: str
    description: str
    structured_steps: tuple[Mapping[str, Any], ...]
    risk_assessment: str
    requires_authorization: bool
    requires_simulation: bool
    requires_verification: bool
    requires_certification: bool
    estimated_impact: Mapping[str, Any]
    rollback_plan_ref: str | None
    status: str
    target_pipeline: str
    signature: str
    integrity_hash: str

    def unsigned(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id, "diagnosis_id": self.diagnosis_id, "version": self.version,
            "class": self.class_, "description": self.description, "structured_steps": [dict(x) for x in self.structured_steps],
            "risk_assessment": self.risk_assessment, "requires_authorization": self.requires_authorization,
            "requires_simulation": self.requires_simulation, "requires_verification": self.requires_verification,
            "requires_certification": self.requires_certification, "estimated_impact": dict(self.estimated_impact),
            "rollback_plan_ref": self.rollback_plan_ref, "status": self.status, "target_pipeline": self.target_pipeline,
        }

    def to_dict(self) -> dict[str, Any]:
        d=self.unsigned(); d["signature"]=self.signature; d["integrity_hash"]=self.integrity_hash; return d


class P2TError(RuntimeError):
    """Base P2-T error."""
class BaselineError(P2TError):
    """Baseline validation failure."""
class DetectorError(P2TError):
    """Detector catalog failure."""
class DiagnosisError(P2TError):
    """Diagnosis lifecycle failure."""
class TenantIsolationError(P2TError):
    """Tenant boundary violation."""
class RemediationDenied(P2TError):
    """Remediation proposal contract violation."""
class ReplayError(P2TError):
    """Replay failure."""


class _PersistentDoctorStore:
    def __init__(self, path: Path, secret: bytes) -> None:
        self.path=path; self.path.parent.mkdir(parents=True,exist_ok=True); self.secret=secret; self.lock=threading.RLock()
        self.db=sqlite3.connect(str(path),check_same_thread=False); self.db.execute("PRAGMA journal_mode=WAL"); self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS baselines(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS signals(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS detectors(id TEXT PRIMARY KEY, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS diagnoses(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS proposals(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS escalations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS evaluations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, body TEXT NOT NULL, tag TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT NOT NULL, tag TEXT NOT NULL);
        '''); self.db.commit()

    def tag(self, body: Mapping[str,Any]) -> str:
        import hmac
        return hmac.new(self.secret,_canon(body),hashlib.sha256).hexdigest()

    def put(self, table: str, key: str, tenant: str, body: Mapping[str,Any]) -> None:
        tag=self.tag(body)
        with self.lock, self.db:
            self.db.execute(f"INSERT OR REPLACE INTO {table}(id,tenant,body,tag,created) VALUES(?,?,?,?,?)",(key,tenant,json.dumps(body,sort_keys=True,separators=(",",":")),tag,time.time()))

    def get(self, table: str, key: str) -> dict[str,Any] | None:
        with self.lock:
            row=self.db.execute(f"SELECT body,tag FROM {table} WHERE id=?",(key,)).fetchone()
        if not row:return None
        body=json.loads(row[0]);
        if self.tag(body)!=row[1]: raise P2TError(f"integrity failure in {table}:{key}")
        return body

    def list(self, table: str, tenant: str, *, limit: int=500) -> list[dict[str,Any]]:
        with self.lock:
            rows=self.db.execute(f"SELECT body,tag FROM {table} WHERE tenant=? ORDER BY created DESC LIMIT ?",(tenant,int(limit))).fetchall()
        out=[]
        for body_s,tag in rows:
            body=json.loads(body_s)
            if self.tag(body)!=tag: raise P2TError(f"integrity failure in {table}")
            out.append(body)
        return out

    def close(self) -> None:
        with self.lock:self.db.close()


class AutonomousSystemDoctor:
    """Continuous health intelligence. Never applies remediation."""
    def __init__(self, *, root: str|Path="data/autonomous_system_doctor", storage_secret: bytes,
                 signer: Ed25519PrivateKey|None=None, key_id: str="p2-t", tenant_id: str="default",
                 event_fabric: Any|None=None, failure_intelligence: Any|None=None, world_model: Any|None=None,
                 security_evolution: Any|None=None, simulation: Any|None=None, orchestration: Any|None=None, security_authority: Any|None=None,
                 downstream_hooks: Mapping[str, Callable[[Mapping[str,Any]], Any]]|None=None,
                 trusted_detector_keys: Mapping[str, bytes|Ed25519PublicKey]|None=None) -> None:
        if len(storage_secret)<32: raise ValueError("storage_secret must be at least 32 bytes")
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True); self.storage_secret=bytes(storage_secret)
        self.signer=signer or Ed25519PrivateKey.generate(); self.public_key=self.signer.public_key(); self.key_id=str(key_id); self.tenant_id=str(tenant_id)
        self.event_fabric=event_fabric; self.failure_intelligence=failure_intelligence; self.world_model=world_model; self.security_evolution=security_evolution
        self.simulation=simulation; self.orchestration=orchestration; self.security_authority=security_authority; self.downstream_hooks=dict(downstream_hooks or {})
        self.trusted_detector_keys=dict(trusted_detector_keys or {}); self.store=_PersistentDoctorStore(self.root/"doctor.db",self.storage_secret)
        self._lock=threading.RLock(); self._continuous: dict[tuple[str,str],threading.Event]={}; self._verifiers: dict[str,Callable[...,Any]]={}
        self._detectors: dict[str,DetectorSpec]={}; self.catalog_version="1.0.0"; self._register_required_detectors()

    @property
    def public_key_bytes(self) -> bytes:
        return self.public_key.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)

    def _require_context(self, context: Any) -> dict[str,Any]:
        doc=_context_doc(context); tenant=doc["tenant_id"]
        if tenant!=self.tenant_id and self.tenant_id!="*": raise TenantIsolationError("context tenant is outside Doctor tenant boundary")
        return doc

    def _emit(self, name: str, payload: Mapping[str,Any], *, context: Any, correlation_id: str|None=None, causation_id: str|None=None, severity: str|None=None) -> str:
        ctx=self._require_context(context); event_id=_uuid({"name":name,"payload":payload,"correlation":correlation_id or ctx["correlation_id"],"causation":causation_id})
        body=dict(payload); body.update({"doctor_version":P2T_VERSION,"event_id":event_id,"tenant_id":ctx["tenant_id"]})
        if severity: body["severity"]=severity
        if self.event_fabric is not None:
            try:
                from core.event_fabric import AuthContext, EventEnvelope, ProducedBy
                env=EventEnvelope.create(event_type="System",event_name=name,payload=body,tenant_id=ctx["tenant_id"],partition_key=str(payload.get("subsystem") or "system"),correlation_id=correlation_id or ctx["correlation_id"],causation_id=causation_id,
                    produced_by=ProducedBy("system",self.key_id,None,"system"),auth_context=AuthContext(ctx["principal"],("events.publish.system",),ctx["policy_ref"],None),signing_key=self.signer)
                receipt=self.event_fabric.publish_envelope(env) if hasattr(self.event_fabric,"publish_envelope") else self.event_fabric.publish(env)
                return getattr(receipt,"event_id",event_id)
            except Exception as exc:
                # A diagnostic operation is not silently dropped: persist a local emission record and surface the fault.
                body["event_delivery_error"]=type(exc).__name__
        try:
            if hasattr(self.event_fabric,"publish"):
                self.event_fabric.publish(f"System.{name}",body,source="p2-t",correlation_id=correlation_id or ctx["correlation_id"],causation_id=causation_id)
        except Exception:
            return event_id
        return event_id

    def monitoring_matrix(self) -> dict[str,Any]:
        return {"matrix_version":"1.0.0","version":P2T_VERSION,"entries":json.loads(json.dumps(MONITORING_MATRIX))}

    def signal_schema(self, subsystem: str) -> dict[str,Any]:
        if subsystem not in MONITORING_MATRIX: raise P2TError(f"unknown monitored subsystem: {subsystem}")
        return {
            "$schema":"https://json-schema.org/draft/2020-12/schema","type":"object","additionalProperties":False,
            "required":["signal_id","tenant_id","observed_at","subsystem","metric_or_signal","value","source","schema_version"],
            "properties":{
                "signal_id":{"type":"string","format":"uuid"},"tenant_id":{"type":"string","minLength":1},"observed_at":{"type":"string","format":"date-time"},
                "subsystem":{"const":subsystem},"metric_or_signal":{"type":"string","enum":MONITORING_MATRIX[subsystem]["signals"]},"value":{},
                "source":{"type":"string","minLength":1},"schema_version":{"type":"string","pattern":"^1\\.0\\.0$"},
                "correlation_id":{"type":"string","format":"uuid"},"causation_id":{"type":["string","null"]},"expected_interval_s":{"type":"number","minimum":0.001},
                "thresholds":{"type":"object"},"payload":{"type":"object"},"provenance_ref":{"type":"string"},
            },
        }

    def _register_required_detectors(self) -> None:
        """Load the frozen on-disk detector catalog and verify its release signature."""
        catalog_root=Path(__file__).resolve().parent / "autonomous_system_doctor"
        key_path=catalog_root / "detector_catalog_public_key.bin"
        manifest_path=catalog_root / "detector_catalog_manifest.json"
        if not key_path.is_file() or not manifest_path.is_file():
            raise DetectorError("signed detector catalog is unavailable")
        try:
            catalog_public=Ed25519PublicKey.from_public_bytes(key_path.read_bytes())
            manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise DetectorError("signed detector catalog cannot be loaded") from exc
        self.catalog_version=str(manifest.get("catalog_version",""))
        if self.catalog_version != "1.0.0":
            raise DetectorError("unsupported detector catalog version")
        manifest_unsigned={k:v for k,v in manifest.items() if k not in {"signature"}}
        if _hash({**manifest_unsigned,"integrity_hash":""}) != str(manifest.get("integrity_hash","")):
            raise DetectorError("detector catalog manifest integrity verification failed")
        if not _verify(manifest_unsigned,str(manifest.get("signature","")),catalog_public):
            raise DetectorError("detector catalog manifest signature verification failed")
        matrix_path=catalog_root / "monitoring_matrix.json"
        if not matrix_path.is_file():
            raise DetectorError("signed monitoring matrix is unavailable")
        matrix=json.loads(matrix_path.read_text(encoding="utf-8"))
        matrix_unsigned={k:v for k,v in matrix.items() if k not in {"signature"}}
        if str(matrix.get("version")) != P2T_VERSION or str(matrix.get("matrix_version")) != "1.0.0":
            raise DetectorError("unsupported monitoring matrix version")
        if _hash({**matrix_unsigned,"integrity_hash":""}) != str(matrix.get("integrity_hash","")):
            raise DetectorError("monitoring matrix integrity verification failed")
        if not _verify(matrix_unsigned,str(matrix.get("signature","")),catalog_public):
            raise DetectorError("monitoring matrix signature verification failed")
        disk_entries=matrix.get("entries")
        if disk_entries != MONITORING_MATRIX:
            raise DetectorError("signed monitoring matrix does not match the frozen matrix")
        for rulebook_ref in manifest.get("rulebooks",[]):
            rulebook_path=Path(__file__).resolve().parent.parent / str(rulebook_ref)
            if not rulebook_path.is_file():
                raise DetectorError(f"rulebook seed missing: {rulebook_ref}")
            rulebook=json.loads(rulebook_path.read_text(encoding="utf-8"))
            rule_unsigned={k:v for k,v in rulebook.items() if k not in {"signature"}}
            if _hash({**rule_unsigned,"integrity_hash":""}) != str(rulebook.get("integrity_hash","")):
                raise DetectorError(f"rulebook integrity mismatch: {rulebook_ref}")
            if not _verify(rule_unsigned,str(rulebook.get("signature","")),catalog_public):
                raise DetectorError(f"rulebook signature verification failed: {rulebook_ref}")
        self._detectors.clear()
        listed=set(str(x) for x in manifest.get("detectors",[]))
        if listed != {f"core/autonomous_system_doctor/detectors/{did}/1.0.0/detector.json" for did in REQUIRED_DETECTORS}:
            raise DetectorError("detector catalog membership does not match the frozen detector set")
        self.trusted_detector_keys.setdefault("p2-t-build",catalog_public)
        for relative in sorted(listed):
            path=Path(__file__).resolve().parent.parent / relative
            if not path.is_file():
                raise DetectorError(f"detector seed missing: {relative}")
            spec=json.loads(path.read_text(encoding="utf-8"))
            unsigned={k:v for k,v in spec.items() if k not in {"signature"}}
            integrity_body={**unsigned,"integrity_hash":""}
            if _hash(integrity_body) != str(spec.get("integrity_hash","")):
                raise DetectorError(f"detector integrity mismatch: {relative}")
            if not _verify(unsigned,str(spec.get("signature","")),catalog_public):
                raise DetectorError(f"detector signature verification failed: {relative}")
            self._detectors[str(spec["detector_id"])]=DetectorSpec(
                str(spec["detector_id"]),str(spec["detector_version"]),tuple(spec.get("symptom_class",())),str(spec["method"]),
                tuple(spec.get("inputs",())),dict(spec.get("parameters",{})),dict(spec.get("thresholds",{})),str(spec.get("determinism","deterministic")),
                dict(spec.get("signed_by",{})),str(spec.get("integrity_hash")),str(spec.get("signature")))

    def list_detectors(self, filter: Mapping[str,Any]|None=None) -> list[dict[str,Any]]:
        items=[d.to_dict() for d in self._detectors.values()]
        if not filter:return items
        return [x for x in items if all(x.get(k)==v or v in x.get(k,[]) if isinstance(x.get(k),list) else x.get(k)==v for k,v in filter.items())]

    def _detector_disabled(self, detector_id: str, tenant: str) -> bool:
        rows=self.store.list("evaluations",tenant,limit=5000)
        state=[r for r in rows if r.get("record_type")=="detector_state" and r.get("detector_id")==detector_id]
        return bool(state and state[0].get("disabled",False))

    def register_detector(self, detector_spec: Mapping[str,Any], *, context: Any|None=None) -> str:
        if context is None: raise PermissionError("register_detector requires a verified P2-E ExecutionContext")
        ctx=self._require_context(context)
        did=str(detector_spec["detector_id"]); ver=str(detector_spec["detector_version"])
        if not did or _semver(ver)<= (0,0,0,""): raise DetectorError("invalid detector identity/version")
        method=str(detector_spec["method"]); symptoms=tuple(detector_spec.get("symptom_class",()))
        if method not in METHODS or not set(symptoms).issubset(SYMPTOM_CLASSES): raise DetectorError("invalid detector taxonomy")
        signer=dict(detector_spec.get("signed_by",{})); kid=str(signer.get("key_id","")); sig=str(detector_spec.get("signature",""))
        if not kid or not sig: raise DetectorError("detector signature required")
        trusted=self.trusted_detector_keys.get(kid,self.public_key)
        body={k:v for k,v in detector_spec.items() if k!="signature"}
        if not _verify(body,sig,trusted): raise DetectorError("detector signature verification failed")
        self._detectors[did]=DetectorSpec(did,ver,symptoms,method,tuple(detector_spec.get("inputs",())),dict(detector_spec.get("parameters",{})),dict(detector_spec.get("thresholds",{})),str(detector_spec.get("determinism","deterministic")),signer,str(detector_spec.get("integrity_hash")),sig)
        self.store.put("detectors",did,"*",self._detectors[did].to_dict()); return did

    def enable_detector(self, detector_id: str) -> str:
        if detector_id not in self._detectors: raise DetectorError("unknown detector")
        return detector_id
    def disable_detector(self, detector_id: str, reason: str, *, context: Any) -> None:
        self._require_context(context)
        if detector_id not in self._detectors: raise DetectorError("unknown detector")
        # Disabled state is persisted rather than mutating the signed detector spec.
        body={"detector_id":detector_id,"disabled":True,"reason":str(reason),"at":_now()}
        self.store.put("evaluations",_uuid(body),self._require_context(context)["tenant_id"],body)

    @staticmethod
    def _parse_time(value: str) -> datetime:
        text=str(value).replace("Z","+00:00")
        dt=datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)

    @staticmethod
    def _threshold_max(value: Any) -> float | None:
        if isinstance(value, Mapping):
            return _value_number(value.get("max", value.get("upper")))
        return _value_number(value)

    @staticmethod
    def _threshold_min(value: Any) -> float | None:
        if isinstance(value, Mapping):
            return _value_number(value.get("min", value.get("lower")))
        return None

    def _baseline_looser(self, proposed: Mapping[str,Any], previous: Mapping[str,Any]) -> bool:
        p=dict(proposed.get("thresholds",{})); q=dict(previous.get("thresholds",{}))
        for key in set(p)|set(q):
            pm=self._threshold_max(p.get(key)); qm=self._threshold_max(q.get(key))
            if pm is not None and qm is not None and pm>qm: return True
            pmin=self._threshold_min(p.get(key)); qmin=self._threshold_min(q.get(key))
            if pmin is not None and qmin is not None and pmin<qmin: return True
        return False

    def _authorize_baseline_change(self, previous: Mapping[str,Any], proposed: Mapping[str,Any], context: Any) -> bool:
        authority=self.security_authority
        if authority is None: return False
        fn=getattr(authority,"authorize_baseline_change",None)
        if fn is None and callable(authority): fn=authority
        if fn is None: return False
        try:
            return bool(fn(previous,proposed,context))
        except Exception:
            return False

    def compute_baseline(self, subsystem: str, metric: str, window: Mapping[str,Any], *, context: Any) -> dict[str,Any]:
        ctx=self._require_context(context)
        if subsystem not in MONITORING_MATRIX or metric not in MONITORING_MATRIX[subsystem]["signals"]: raise BaselineError("metric is not in frozen monitoring matrix")
        start=str(window.get("start")); end=str(window.get("end")); duration=int(window.get("duration_seconds",0))
        if not start or not end or duration<=0: raise BaselineError("completed window is required")
        try:
            if self._parse_time(end) > datetime.now(timezone.utc): raise BaselineError("baseline window is not complete")
            if self._parse_time(end) < self._parse_time(start): raise BaselineError("baseline window end precedes start")
        except ValueError as exc:
            raise BaselineError("invalid baseline window timestamps") from exc
        signals=[s for s in self.store.list("signals",ctx["tenant_id"],limit=5000) if s["subsystem"]==subsystem and s["metric_or_signal"]==metric and start<=s["observed_at"]<=end]
        if not signals: raise BaselineError("no completed signal window")
        vals=[_value_number(s["value"]) for s in signals]; vals=[v for v in vals if v is not None]
        if not vals: raise BaselineError("baseline requires numeric samples")
        vals.sort(); n=len(vals); mean=sum(vals)/n; median=vals[n//2] if n%2 else (vals[n//2-1]+vals[n//2])/2
        def pct(p: float)->float:
            idx=max(0,min(n-1,int(round((n-1)*p)))); return vals[idx]
        std=math.sqrt(sum((v-mean)**2 for v in vals)/n)
        stats={"mean":mean,"median":median,"p50":pct(.50),"p95":pct(.95),"p99":pct(.99),"stddev":std,"min":min(vals),"max":max(vals),"sample_count":n}
        thresholds=dict(window.get("thresholds",{}))
        prior=[b for b in self.store.list("baselines",ctx["tenant_id"],limit=5000) if b.get("environment_hash")==ctx["environment_hash"] and b.get("subsystem")==subsystem and b.get("metric_or_signal")==metric]
        next_patch=1
        if prior:
            next_patch=max(_semver(str(b.get("baseline_version","1.0.0")))[2] for b in prior)+1
        baseline_version=f"1.0.{next_patch}"
        computed_at=_now()
        unsigned={"baseline_id":_uuid({"tenant":ctx["tenant_id"],"environment":ctx["environment_hash"],"subsystem":subsystem,"metric":metric,"window":window,"version":baseline_version,"computed_at":computed_at}),"baseline_version":baseline_version,"tenant_id":ctx["tenant_id"],"environment_hash":ctx["environment_hash"],"subsystem":subsystem,"metric_or_signal":metric,"window":dict(window),"statistics":stats,"thresholds":thresholds,"seasonal":{"daily_pattern_ref":None,"weekly_pattern_ref":None},"methodology":str(window.get("methodology","rolling_window")),"methodology_version":"1.0.0","computed_by":{"principal":ctx["principal"],"key_id":self.key_id},"computed_at":computed_at,"approved_by":None}
        digest=_hash(unsigned); sig=_sign(unsigned,self.signer); baseline={**unsigned,"signature":sig,"integrity_hash":digest}
        self._emit("BaselineComputed",{"baseline_id":baseline["baseline_id"],"subsystem":subsystem,"metric_or_signal":metric,"baseline_ref":f"urn:jarvis:p2t:baseline:{baseline['baseline_id']}"},context=context,correlation_id=ctx["correlation_id"]); return baseline

    def register_baseline(self, baseline: Mapping[str,Any], *, context: Any) -> str:
        ctx=self._require_context(context)
        required={"baseline_id","baseline_version","tenant_id","environment_hash","subsystem","metric_or_signal","window","statistics","thresholds","methodology","methodology_version","computed_by","computed_at","signature","integrity_hash"}
        if not required<=set(baseline): raise BaselineError("incomplete baseline")
        if str(baseline["tenant_id"])!=ctx["tenant_id"]: raise TenantIsolationError("cross-tenant baseline")
        unsigned={k:v for k,v in baseline.items() if k not in {"signature","integrity_hash"}}
        if _hash(unsigned)!=str(baseline["integrity_hash"]): raise BaselineError("baseline integrity mismatch")
        if not _verify(unsigned,str(baseline["signature"]),self.public_key): raise BaselineError("baseline signature mismatch")
        key=str(baseline["baseline_id"]); old=self.store.get("baselines",key)
        if old is not None:
            if _hash({k:v for k,v in old.items() if k not in {"signature","integrity_hash"}})==_hash(unsigned):
                return key
            raise BaselineError("signed baselines are immutable")
        prior=[b for b in self.store.list("baselines",ctx["tenant_id"],limit=5000) if b.get("environment_hash")==baseline.get("environment_hash") and b.get("subsystem")==baseline.get("subsystem") and b.get("metric_or_signal")==baseline.get("metric_or_signal")]
        if prior and any(self._baseline_looser(baseline,p) for p in prior):
            if baseline.get("approved_by") is None or not self._authorize_baseline_change(prior[-1],baseline,context):
                raise BaselineError("baseline loosening requires Security Authority approval")
        self.store.put("baselines",key,ctx["tenant_id"],dict(baseline)); self._emit("BaselineRegistered",{"baseline_id":key,"subsystem":baseline["subsystem"],"metric_or_signal":baseline["metric_or_signal"]},context=context); return key

    def get_baseline(self, baseline_id: str, *, context: Any) -> dict[str,Any]:
        ctx=self._require_context(context); b=self.store.get("baselines",baseline_id)
        if b is None or b.get("tenant_id")!=ctx["tenant_id"]: raise TenantIsolationError("baseline unavailable")
        return b

    def list_baselines(self, filter: Mapping[str,Any]|None=None, *, context: Any) -> list[dict[str,Any]]:
        ctx=self._require_context(context); out=self.store.list("baselines",ctx["tenant_id"],limit=5000)
        if not filter:return out
        return [b for b in out if all(b.get(k)==v for k,v in filter.items())]

    def collect_signal(self, signal: Mapping[str,Any], *, context: Any) -> str:
        ctx=self._require_context(context); s=dict(signal)
        s.setdefault("signal_id",_uuid({"tenant":ctx["tenant_id"],"subsystem":s.get("subsystem"),"metric_or_signal":s.get("metric_or_signal"),"observed_at":s.get("observed_at"),"value":s.get("value"),"source":s.get("source")}))
        s.setdefault("tenant_id",ctx["tenant_id"]); s.setdefault("schema_version","1.0.0"); s.setdefault("observed_at",_now())
        if s["tenant_id"]!=ctx["tenant_id"]: raise TenantIsolationError("cross-tenant signal")
        subsystem=str(s.get("subsystem")); metric=str(s.get("metric_or_signal"))
        if subsystem not in MONITORING_MATRIX or metric not in MONITORING_MATRIX[subsystem]["signals"]: raise P2TError("signal does not conform to frozen monitoring matrix")
        if Draft202012Validator is not None:
            errors=list(Draft202012Validator(self.signal_schema(subsystem)).iter_errors(s))
            if errors: raise P2TError(f"signal schema violation: {errors[0].message}")
        self.store.put("signals",str(s["signal_id"]),ctx["tenant_id"],s); self._emit("SignalCollected",{"signal_id":s["signal_id"],"subsystem":subsystem,"metric_or_signal":metric},context=context,correlation_id=s.get("correlation_id") or ctx["correlation_id"],causation_id=s.get("causation_id")); return str(s["signal_id"])

    def mark_signal_missing(self, subsystem: str, metric: str, *, context: Any, expected_at: str|None=None) -> str:
        ctx=self._require_context(context)
        if subsystem not in MONITORING_MATRIX or metric not in MONITORING_MATRIX[subsystem]["signals"]:
            raise P2TError("missing-signal target is outside the frozen monitoring matrix")
        sid=_uuid({"tenant":ctx["tenant_id"],"subsystem":subsystem,"metric":metric,"expected_at":expected_at,"missing":True})
        body={"signal_id":sid,"tenant_id":ctx["tenant_id"],"observed_at":_now(),"subsystem":subsystem,"metric_or_signal":metric,"value":None,"source":"P2-T silence monitor","schema_version":"1.0.0","correlation_id":ctx["correlation_id"],"causation_id":ctx["causation_id"],"payload":{"missing":True,"expected_at":expected_at}}
        self.store.put("signals",sid,ctx["tenant_id"],body); self._emit("SignalMissing",{"signal_id":sid,"subsystem":subsystem,"metric_or_signal":metric,"expected_at":expected_at},context=context,severity="high"); return sid

    def validate_document(self, schema_name: str, document: Mapping[str, Any]) -> None:
        schema_path = self.root.parent.parent / "core" / "schemas" / schema_name
        if not schema_path.exists():
            schema_path = Path(__file__).resolve().parent / "schemas" / schema_name
        if not schema_path.exists():
            raise P2TError(f"schema not found: {schema_name}")
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        if Draft202012Validator is not None:
            if Registry is not None and Resource is not None:
                registry=Registry()
                for candidate in schema_path.parent.glob("*_v1.schema.json"):
                    try:
                        loaded=json.loads(candidate.read_text(encoding="utf-8"))
                    except Exception:
                        continue
                    resource=Resource.from_contents(loaded)
                    registry=registry.with_resource(candidate.name,resource)
                    if isinstance(loaded,dict) and loaded.get("$id"):
                        registry=registry.with_resource(str(loaded["$id"]),resource)
                validator=Draft202012Validator(schema,registry=registry,format_checker=FormatChecker() if FormatChecker is not None else None)
            else:
                validator=Draft202012Validator(schema,format_checker=FormatChecker() if FormatChecker is not None else None)
            errors = sorted(validator.iter_errors(dict(document)), key=lambda e: list(e.path))
            if errors:
                raise P2TError(f"{schema_name} validation failed: {errors[0].message}")

    def ingest_event(self, event: Any, *, context: Any) -> str | None:
        """Consume one P2-U event without reading subsystem internals."""
        ctx = self._require_context(context)
        raw = event.to_dict() if hasattr(event, "to_dict") else dict(event)
        if str(raw.get("tenant_id", ctx["tenant_id"])) != ctx["tenant_id"]:
            raise TenantIsolationError("cross-tenant event")
        event_type = str(raw.get("event_type", "")); event_name = str(raw.get("event_name", "")); payload = dict(raw.get("payload", {}))
        mapping = self._event_signal_mapping(event_type, event_name, payload)
        if mapping is None:
            inconclusive = {"event_id":raw.get("event_id"),"event_type":event_type,"event_name":event_name,"reason":"positive subsystem attribution unavailable","status":"inconclusive","observed_at":raw.get("emitted_at",_now())}
            self.store.put("evaluations", _uuid(inconclusive), ctx["tenant_id"], inconclusive)
            self._emit("SignalMissing", inconclusive, context=context, correlation_id=raw.get("correlation_id") or ctx["correlation_id"], causation_id=raw.get("causation_id"), severity="high")
            return None
        subsystem, metric = mapping
        value = payload.get("value", payload.get("observed_value", payload.get("count", payload.get("latency_ms"))))
        signal = {"signal_id":_uuid({"event_id":raw.get("event_id"),"subsystem":subsystem,"metric":metric}),"tenant_id":ctx["tenant_id"],"observed_at":raw.get("emitted_at",_now()),"subsystem":subsystem,"metric_or_signal":metric,"value":value,"source":f"P2-U:{event_type}.{event_name}","schema_version":"1.0.0","correlation_id":raw.get("correlation_id") or ctx["correlation_id"],"causation_id":raw.get("causation_id"),"payload":payload,"provenance_ref":f"urn:jarvis:p2u:event:{raw.get('event_id','unknown')}"}
        return self.collect_signal(signal, context=context)

    def ingest_events(self, events: Iterable[Any], *, context: Any) -> list[str]:
        ids=[]
        for event in events:
            sid=self.ingest_event(event, context=context)
            if sid is not None: ids.append(sid)
        return ids

    @staticmethod
    def _event_signal_mapping(event_type: str, event_name: str, payload: Mapping[str, Any]) -> tuple[str, str] | None:
        explicit = payload.get("subsystem"), payload.get("metric_or_signal")
        if explicit[0] in MONITORING_MATRIX and explicit[1] in MONITORING_MATRIX[str(explicit[0])]["signals"]:
            return str(explicit[0]), str(explicit[1])
        if event_type == "Security": return ("security_evolution", "drift_events" if "Drift" in event_name else "attestation_outcomes")
        if event_type in {"Agent.Execution", "Agent.Resources"}: return ("harness", "timeouts" if "Timeout" in event_name else "execution_count")
        if event_type.startswith("Agent.Lifecycle") or event_type == "Agent.Lifecycle": return ("agents", "lifecycle_state")
        if event_type.startswith("Agent.Collaboration") or event_type.startswith("Agent.Delegation"): return ("multi_agent", "deadlock_count" if "Deadlock" in event_name else "delegation_depth")
        if event_type in {"Verification", "Agent.Verification"}: return ("a2a_verification", "denial_rate" if "Denied" in event_name else "replay_rejections")
        if event_type == "Model": return ("models", "routing_failures" if "Failed" in event_name else "latency")
        if event_type == "Tool": return ("tools", "error_rate" if "Failed" in event_name else "health")
        if event_type.startswith("Skill") or event_type == "Skill.Test": return ("skills", "invocation_success" if "Failed" not in event_name else "latency")
        if event_type == "Simulation": return ("simulation", "replay_divergences" if "Replay" in event_name or "Diverg" in event_name else "isolation_breaches")
        if event_type == "Failure": return ("failure_intelligence", "ingestion_rate")
        if event_type == "Telemetry": return None
        if event_type == "System" and event_name in {"RemediationUnvalidated", "EscalationTimeout", "DeadlockDetected"}: return ("services", "health_check_latency")
        return None

    def _signals(self, tenant: str, subsystem: str, metric: str, start: str|None=None, end: str|None=None, limit: int=2000) -> list[dict[str,Any]]:
        rows=self.store.list("signals",tenant,limit=limit)
        return [s for s in rows if s.get("subsystem")==subsystem and s.get("metric_or_signal")==metric and (start is None or s.get("observed_at","")>=start) and (end is None or s.get("observed_at","")<=end)]

    def _detect(self, spec: DetectorSpec, signal: Mapping[str,Any], tenant: str, request: Mapping[str,Any]) -> list[dict[str,Any]]:
        metric=str(signal["metric_or_signal"]); value=_value_number(signal.get("value")); out=[]
        baseline=None; bref=request.get("symptom",{}).get("baseline_ref")
        if bref:
            bid=str(bref).rsplit(":",1)[-1]
            baseline=self.store.get("baselines",bid)
        if spec.detector_id=="BaselineDeviationDetector" and value is not None and baseline:
            st=baseline["statistics"]; z=0.0 if float(st["stddev"])==0 else abs(value-float(st["mean"]))/float(st["stddev"])
            if z>=float(spec.parameters.get("z_threshold",3.0)):
                out.append(self._symptom(signal,"degradation",spec.method,score=min(1,z/6),evidence=[f"urn:jarvis:p2t:baseline:{bid}"]))
        elif spec.detector_id=="ThresholdDetector":
            for key,specv in dict(signal.get("thresholds",{})).items():
                if value is None: continue
                limit=_value_number(specv.get("max")) if isinstance(specv,Mapping) else _value_number(specv)
                if limit is not None and value>limit: out.append(self._symptom(signal,key if key in SYMPTOM_CLASSES else "anomaly",spec.method,score=0.9,evidence=[f"signal:{signal['signal_id']}"]))
        elif spec.detector_id=="CorrelationDetector":
            cid=signal.get("correlation_id")
            if cid:
                related=[s for s in self.store.list("signals",tenant,limit=2000) if s.get("correlation_id")==cid]
                if len({s.get("subsystem") for s in related})>=2: out.append(self._symptom(signal,"cascade",spec.method,score=.8,evidence=[f"urn:jarvis:p2t:correlation:{cid}"]))
        elif spec.detector_id=="CascadeDetector":
            caus=signal.get("causation_id")
            if caus: out.append(self._symptom(signal,"cascade",spec.method,score=.75,evidence=[f"urn:jarvis:p2t:causation:{caus}"]))
        elif spec.detector_id=="FlappingDetector":
            vals=[_value_number(s.get("value")) for s in self._signals(tenant,str(signal["subsystem"]),metric,limit=30)]; vals=[v for v in vals if v is not None]
            if len(vals)>=6 and sum(1 for a,b in zip(vals,vals[1:]) if (b-a)*(vals[1]-vals[0])<0)>=3: out.append(self._symptom(signal,"instability",spec.method,score=.85,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="DriftDetector":
            vals=[_value_number(s.get("value")) for s in self._signals(tenant,str(signal["subsystem"]),metric,limit=50)]; vals=[v for v in vals if v is not None]
            if len(vals)>=5:
                n=len(vals); sx=sum(range(n)); sy=sum(vals); sxx=sum(i*i for i in range(n)); sxy=sum(i*v for i,v in enumerate(vals)); den=n*sxx-sx*sx; slope=0.0 if den==0 else (n*sxy-sx*sy)/den
                if abs(slope)>float(spec.parameters.get("slope_threshold",0.05)): out.append(self._symptom(signal,"drift",spec.method,score=min(.95,abs(slope)),evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="SilenceDetector":
            if signal.get("payload",{}).get("missing") is True or signal.get("expected_interval_s"): out.append(self._symptom(signal,"silence",spec.method,score=.95,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="ResourcePressureDetector":
            threshold=signal.get("thresholds",{}).get("resource_pressure",.90)
            if isinstance(threshold,Mapping): threshold=threshold.get("max",threshold.get("upper",.90))
            if value is not None and metric in {"cpu_utilization","ram_used","vram_used","packet_loss","fd_leaks","timeouts","budget_violations","vram_pressure"} and value>=float(threshold):
                out.append(self._symptom(signal,"resource_pressure",spec.method,score=.9,evidence=[f"signal:{signal['signal_id']}"]))
        elif spec.detector_id=="QueueBacklogDetector":
            if metric in {"backlog","dlq_growth","consumer_lag","embedding_backlog"} and value is not None and value>0: out.append(self._symptom(signal,"resource_pressure",spec.method,score=min(.95,0.5+value/(value+100)),evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="DeadlockDetector":
            graph=signal.get("payload",{}).get("blocking_graph")
            if isinstance(graph,Mapping) and self._has_cycle(graph): out.append(self._symptom(signal,"cascade",spec.method,score=.98,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="ReplayDivergenceDetector":
            if signal.get("payload",{}).get("replay_diverged") or "ReplayDivergence" in str(signal.get("payload",{})) or "Diverged" in str(metric): out.append(self._symptom(signal,"integrity_signal",spec.method,score=.99,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="AttestationDriftDetector":
            if signal.get("subsystem")=="security_evolution" and (metric=="drift_events" or signal.get("payload",{}).get("attestation_drift")): out.append(self._symptom(signal,"security_signal",spec.method,score=.95,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="CollusionSurgeDetector":
            if signal.get("subsystem")=="a2a_verification" and metric=="collusion_signals" and value is not None and value>0: out.append(self._symptom(signal,"security_signal",spec.method,score=.9,evidence=[f"signal:{signal['signal_id']}" ]))
        elif spec.detector_id=="RecurrenceDetector":
            signature=signal.get("payload",{}).get("diagnosis_signature")
            if signature and any(d.get("diagnosis_signature")==signature for d in self.store.list("diagnoses",tenant,limit=500)): out.append(self._symptom(signal,"anomaly",spec.method,score=.8,evidence=[f"diagnosis:{signature}" ]))
        elif spec.detector_id=="StatisticalAnomalyDetector" and value is not None and baseline:
            st=baseline["statistics"]; scale=max(float(st["stddev"]),1e-9); z=abs(value-float(st["mean"])) / scale
            if z>=float(spec.parameters.get("z_threshold",3.0)): out.append(self._symptom(signal,"anomaly",spec.method,score=min(.99,z/6),evidence=[f"urn:jarvis:p2t:baseline:{bid}" ]))
        return out

    @staticmethod
    def _has_cycle(graph: Mapping[str,Any]) -> bool:
        visiting:set[str]=set(); visited:set[str]=set()
        def dfs(node:str)->bool:
            if node in visiting:return True
            if node in visited:return False
            visiting.add(node)
            for nxt in graph.get(node,[]) if isinstance(graph.get(node,[]),list) else []:
                if dfs(str(nxt)):return True
            visiting.remove(node); visited.add(node); return False
        return any(dfs(str(n)) for n in graph)

    @staticmethod
    def _symptom(signal: Mapping[str,Any], symptom_class: str, method: str, *, score: float, evidence: Sequence[str]) -> dict[str,Any]:
        return {"symptom_id":_uuid({"signal_id":signal["signal_id"],"class":symptom_class,"method":method}),"symptom_class":symptom_class,"method":method,"signal_id":signal["signal_id"],"subsystem":signal["subsystem"],"metric_or_signal":signal["metric_or_signal"],"score":round(float(score),6),"evidence_refs":list(evidence),"observed_at":signal["observed_at"],"correlation_id":signal.get("correlation_id"),"causation_id":signal.get("causation_id")}

    def _detector_run(self, request: Mapping[str,Any], signal: Mapping[str,Any], tenant: str) -> list[dict[str,Any]]:
        result=[]
        for spec in self._detectors.values():
            if self._detector_disabled(spec.detector_id,tenant):
                continue
            result.extend(self._detect(spec,signal,tenant,request))
        return sorted(result,key=lambda x:(-x["score"],x["symptom_id"]))

    def _stage_event(self, stage: str, started: float, *, request_id: str, context: Any, correlation_id: str|None, causation_id: str|None, max_stage_ms: float) -> None:
        elapsed_ms=(time.monotonic()-started)*1000.0
        self._emit("HealthChanged", {"request_id":request_id,"diagnostic_stage":stage,"duration_ms":round(elapsed_ms,3),"bounded":elapsed_ms <= max_stage_ms,"max_stage_ms":max_stage_ms}, context=context, correlation_id=correlation_id, causation_id=causation_id, severity="high" if elapsed_ms > max_stage_ms else None)
        if elapsed_ms > max_stage_ms:
            raise DiagnosisError(f"diagnostic stage exceeded declared wall-time bound: {stage}")

    def diagnose(self, diagnosis_request: Mapping[str,Any], *, context: Any) -> dict[str,Any]:
        ctx=self._require_context(context); req=dict(diagnosis_request)
        req.setdefault("request_version",1); req.setdefault("requested_by",{"principal":ctx["principal"],"key_id":self.key_id}); req.setdefault("requested_at",_now())
        req["tenant_id"]=ctx["tenant_id"]
        symptom=dict(req.get("symptom",{})); symptom.setdefault("symptom_id",_uuid({"request":req.get("request_id"),"symptom":symptom})); symptom.setdefault("signal_id",symptom["symptom_id"]); symptom.setdefault("correlation_id",ctx["correlation_id"]); symptom.setdefault("causation_id",None); req["symptom"]=symptom
        digest=_hash({k:v for k,v in req.items() if k not in {"signature","integrity_hash"}}); req.setdefault("request_id",_uuid({"content_hash":digest})); req["integrity_hash"]=_hash({k:v for k,v in req.items() if k not in {"signature","integrity_hash"}}); req["signature"]=_sign({k:v for k,v in req.items() if k not in {"signature","integrity_hash"}},self.signer)
        diagnosis_id=_uuid({"request_id":req["request_id"],"version":1})
        request_integrity=req["integrity_hash"]
        prior=self.store.get("diagnoses",diagnosis_id)
        if prior is None:
            for candidate in self.store.list("diagnoses",ctx["tenant_id"],limit=5000):
                if candidate.get("request_integrity_hash")==request_integrity:
                    prior=candidate; break
        if prior is not None:
            if prior.get("request_integrity_hash")!=request_integrity:
                raise DiagnosisError("idempotency key collision with different content")
            return prior
        max_stage_ms=float(req.get("max_stage_ms",2000.0)); stage_started=time.monotonic(); baseline_ref=str(symptom.get("baseline_ref","")); baseline_id=baseline_ref.rsplit(":",1)[-1] if baseline_ref else ""; baseline=self.store.get("baselines",baseline_id) if baseline_id else None
        signal_id=str(symptom.get("signal_id") or symptom.get("symptom_id") or "")
        signal=self.store.get("signals",signal_id) if signal_id else None
        if signal is None:
            # Do not invent the missing signal; the diagnosis becomes inconclusive.
            outcome="unknown"; symptom_class=str(req.get("symptom_class","anomaly"))
            detector_findings=[]
        else:
            detector_findings=self._detector_run(req,signal,ctx["tenant_id"]); symptom_class=str(req.get("symptom_class") or (detector_findings[0]["symptom_class"] if detector_findings else "anomaly")); outcome="degraded" if detector_findings else "unknown"
        self._stage_event("collect",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        self._stage_event("baseline_compare",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        self._emit("AnomalyDetected",{"request_id":req["request_id"],"symptom_class":symptom_class,"detector_count":len(detector_findings)},context=context,correlation_id=symptom.get("correlation_id"),severity="high" if detector_findings else None)
        self._stage_event("anomaly_detect",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        self._emit("SymptomClustered",{"request_id":req["request_id"],"correlated_symptom_refs":req.get("correlated_symptom_refs",[])},context=context,correlation_id=symptom.get("correlation_id"))
        self._stage_event("cluster_correlate",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        hypotheses=self._root_cause_candidates(req,signal,detector_findings,baseline,context)
        self._stage_event("root_cause_candidates",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        hypotheses=sorted(hypotheses,key=lambda h:(-float(h["confidence"]),h["hypothesis_id"]))[:max(1,int(req.get("max_hypotheses",5)))]
        self._stage_event("hypothesis_rank",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        verified=[h for h in hypotheses if h["verified"]]
        confidence_score=max([float(h["confidence"]) for h in hypotheses] or [0.0]); confidence=_confidence_level(confidence_score,verified=bool(verified))
        self._stage_event("verification",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        impact=self._impact_from_signals(req,signal,context); proposal=self._build_proposal(req,hypotheses,impact,context)
        self._stage_event("impact_analysis",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        self._stage_event("remediation_proposal",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        prev=self._last_diagnosis_hash(ctx["tenant_id"])
        proposal["diagnosis_id"]=diagnosis_id
        proposal["integrity_hash"]=_hash({k:v for k,v in proposal.items() if k not in {"signature","integrity_hash"}})
        proposal["signature"]=_sign({k:v for k,v in proposal.items() if k not in {"signature","integrity_hash"}},self.signer)
        diagnosis={
            "diagnosis_id":diagnosis_id,"diagnosis_version":1,"request_ref":req["request_id"],
            "symptom_class":symptom_class,"subsystem":str(symptom.get("subsystem","")),"outcome":("critical" if detector_findings and max(float(x["score"]) for x in detector_findings)>=.98 else outcome),"confidence":confidence,"confidence_score":round(confidence_score,6),
            "hypotheses":hypotheses,"causal_path":self._causal_path(req,signal,context),"affected":impact,
            "remediation_proposal":proposal,"remediation_status":proposal["status"],"state":"proposed" if proposal["class"]!="none" else ("analyzed" if hypotheses else "inconclusive"),
            "opened_at":str(req.get("requested_at",symptom.get("observed_at",_now()))),"closed_at":None,"closed_reason":None,"recurs":any(d.get("diagnosis_signature")==_hash({"subsystem":symptom.get("subsystem"),"metric":symptom.get("metric_or_signal"),"symptom_class":symptom_class}) for d in self.store.list("diagnoses",ctx["tenant_id"],limit=500)),
            "produced_by":{"principal":ctx["principal"],"key_id":self.key_id},"detector_versions":{d.detector_id:d.detector_version for d in self._detectors.values()},
            "baseline_ref":baseline_ref,"registry_state_ref":str(req.get("registry_state_ref","urn:jarvis:p2t:registry:state")),"policy_version":str(req.get("policy_version","1.0.0")),
            "chain_prev_hash":prev,"request_integrity_hash":req["integrity_hash"],"diagnosis_signature":_hash({"subsystem":symptom.get("subsystem"),"metric":symptom.get("metric_or_signal"),"symptom_class":symptom_class}),
        }
        diagnosis["integrity_hash"]=_hash(diagnosis); diagnosis["signature"]=_sign({k:v for k,v in diagnosis.items() if k not in {"signature","integrity_hash"}},self.signer)
        self._stage_event("handoff",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms); stage_started=time.monotonic()
        self.store.put("diagnoses",diagnosis["diagnosis_id"],ctx["tenant_id"],diagnosis); self._emit("DiagnosisOpened",{"diagnosis_id":diagnosis["diagnosis_id"],"outcome":diagnosis["outcome"],"confidence":confidence},context=context,correlation_id=symptom.get("correlation_id"));
        for h in hypotheses:
            self._emit("HypothesisVerified" if h["verified"] else "HypothesisRaised",{"diagnosis_id":diagnosis["diagnosis_id"],"hypothesis_id":h["hypothesis_id"],"confidence":h["confidence"]},context=context,correlation_id=symptom.get("correlation_id"))
        if diagnosis["recurs"]: self._emit("RecurrenceDetected",{"diagnosis_id":diagnosis["diagnosis_id"]},context=context,correlation_id=symptom.get("correlation_id"),severity="high")
        self._project_world(diagnosis,context); self._handoff_failure_intelligence(diagnosis,context); self._handoff_proposal(proposal,context)
        self._stage_event("validation",stage_started,request_id=req["request_id"],context=context,correlation_id=symptom.get("correlation_id"),causation_id=symptom.get("causation_id"),max_stage_ms=max_stage_ms)
        if diagnosis["outcome"]=="critical" and proposal["requires_authorization"]: self.escalate_diagnosis(diagnosis["diagnosis_id"],"security_authority","critical authorized remediation",context=context)
        return diagnosis

    def _last_diagnosis_hash(self,tenant:str)->str|None:
        rows=self.store.list("diagnoses",tenant,limit=1); return str(rows[0]["integrity_hash"]) if rows else None

    def _root_cause_candidates(self,req:Mapping[str,Any],signal:Mapping[str,Any]|None,findings:Sequence[Mapping[str,Any]],baseline:Mapping[str,Any]|None,context:Any)->list[dict[str,Any]]:
        out=[]
        symptom=req.get("symptom",{}); subsystem=str(symptom.get("subsystem","")); metric=str(symptom.get("metric_or_signal",""))
        for f in findings[:6]:
            method=str(f["method"]); score=float(f["score"])
            cause={"BaselineDeviationDetector":"baseline deviation","ThresholdDetector":"declared threshold breach","CorrelationDetector":"correlated upstream condition","CascadeDetector":"causal upstream condition","FlappingDetector":"state flapping","DriftDetector":"slow directional drift","SilenceDetector":"missing expected signal","ResourcePressureDetector":"resource pressure","QueueBacklogDetector":"queue backlog","DeadlockDetector":"blocking cycle","ReplayDivergenceDetector":"replay divergence","AttestationDriftDetector":"security attestation drift","CollusionSurgeDetector":"collusion-signal surge","RecurrenceDetector":"recurring diagnosis","StatisticalAnomalyDetector":"statistical anomaly"}.get(next((k for k in REQUIRED_DETECTORS if k.startswith(f["method"].title().replace("_","")[:0])),""),"systemic condition")
            # Explicit detector-to-cause mapping without asserting proof.
            cause_map={"baseline_comparison":"baseline deviation","threshold":"threshold breach","correlation":"correlated subsystem condition","causal_path":"causal upstream condition","statistical":"statistical pattern","rule_based":"security rule condition","replay":"replay divergence"}
            hyp={"hypothesis_id":_uuid({"request":req.get("request_id"),"method":method,"evidence":f["evidence_refs"]}),"hypothesis_text":f"{cause_map.get(method,'system condition')} may explain {subsystem}.{metric}","cause_class":cause_map.get(method,"system_condition"),"confidence":round(min(.99,score),6),"method":method,"method_version":"1.0.0","evidence_refs":list(f["evidence_refs"]),"supporting_signals":[f["signal_id"]],"contradicting_signals":[],"verified":False,"verified_at":None,"verification_ref":None}
            out.append(hyp)
        if signal is not None and isinstance(signal.get("payload"),Mapping):
            payload=signal.get("payload",{})
            if payload.get("healthy_value") is not None:
                out.append({"hypothesis_id":_uuid({"request":req.get("request_id"),"method":"differential"}),"hypothesis_text":f"differential comparison may explain {subsystem}.{metric}","cause_class":"differential_condition","confidence":0.55,"method":"differential","method_version":"1.0.0","evidence_refs":[f"signal:{signal['signal_id']}"],"supporting_signals":[signal["signal_id"]],"contradicting_signals":[],"verified":False,"verified_at":None,"verification_ref":None})
            if payload.get("replay_diverged") is not None:
                out.append({"hypothesis_id":_uuid({"request":req.get("request_id"),"method":"replay"}),"hypothesis_text":f"event replay may explain {subsystem}.{metric}","cause_class":"replay_divergence","confidence":0.7,"method":"replay","method_version":"1.0.0","evidence_refs":[f"signal:{signal['signal_id']}"],"supporting_signals":[signal["signal_id"]],"contradicting_signals":[],"verified":False,"verified_at":None,"verification_ref":None})
        if self.simulation is not None:
            out.append({"hypothesis_id":_uuid({"request":req.get("request_id"),"method":"simulation"}),"hypothesis_text":f"simulation may reproduce the condition affecting {subsystem}.{metric}","cause_class":"simulation_reproducible_condition","confidence":0.4,"method":"simulation","method_version":"1.0.0","evidence_refs":[f"signal:{signal['signal_id']}" ] if signal else [],"supporting_signals":[signal["signal_id"]] if signal else [],"contradicting_signals":[],"verified":False,"verified_at":None,"verification_ref":None})
        manual=req.get("manual_hypotheses",[])
        for m in manual:
            if not m.get("signature") or not m.get("signed_by"): continue
            hyp={"hypothesis_id":str(m.get("hypothesis_id") or _uuid(m)),"hypothesis_text":str(m.get("hypothesis_text","manual hypothesis")),"cause_class":str(m.get("cause_class","manual")),"confidence":float(m.get("confidence",0.0)),"method":"manual","method_version":"1.0.0","evidence_refs":list(m.get("evidence_refs",[])),"supporting_signals":list(m.get("supporting_signals",[])),"contradicting_signals":list(m.get("contradicting_signals",[])),"verified":False,"verified_at":None,"verification_ref":None}
            out.append(hyp)
        return out

    def _causal_path(self,req:Mapping[str,Any],signal:Mapping[str,Any]|None,context:Any)->dict[str,Any]:
        if self.world_model is not None and signal is not None:
            try:
                if hasattr(self.world_model,"causal_path"):
                    p=self.world_model.causal_path(signal.get("subsystem"),signal.get("metric_or_signal"));
                    if p:return {"path_id":_uuid(p),"nodes":list(p.get("nodes",[])),"edges":list(p.get("edges",[])),"confidence":float(p.get("confidence",0.0))}
            except Exception:
                return {"path_id":None,"nodes":[],"edges":[],"confidence":0.0}
        return {"path_id":None,"nodes":[],"edges":[],"confidence":0.0}

    def _impact_from_signals(self,req:Mapping[str,Any],signal:Mapping[str,Any]|None,context:Any)->dict[str,Any]:
        affected={"subsystems":[],"agents":[],"skills":[],"tools":[],"models":[],"teams":[],"tenants_impacted":1,"blast_radius":"local"}
        if signal:
            affected["subsystems"]=[str(signal.get("subsystem"))]
            cid=signal.get("correlation_id")
            if cid:
                for related in self.store.list("signals",_tenant(context),limit=5000):
                    if related.get("correlation_id")==cid and related.get("subsystem") not in affected["subsystems"]:
                        affected["subsystems"].append(str(related.get("subsystem")))
            affected["subsystems"]=sorted(set(affected["subsystems"]))
            payload=signal.get("payload",{})
            for k in ("agents","skills","tools","models","teams"):
                if isinstance(payload.get(k),list): affected[k]=[str(x) for x in payload[k]]
            if payload.get("blast_radius") in BLAST_RADIUS: affected["blast_radius"]=payload["blast_radius"]
        return affected

    def impact_analysis(self, diagnosis_id: str, *, context: Any) -> dict[str,Any]:
        ctx=self._require_context(context); d=self.store.get("diagnoses",diagnosis_id)
        if d is None or d.get("tenant_id",ctx["tenant_id"])!=ctx["tenant_id"]: raise TenantIsolationError("diagnosis unavailable")
        return {"diagnosis_id":diagnosis_id,"affected":d["affected"],"computed_at":_now(),"integrity_hash":_hash(d["affected"])}

    def affected_entities(self, diagnosis_id: str, *, context: Any)->dict[str,list[str]]:
        return dict(self.impact_analysis(diagnosis_id,context=context)["affected"])

    def _build_proposal(self,req:Mapping[str,Any],hypotheses:Sequence[Mapping[str,Any]],impact:Mapping[str,Any],context:Any)->dict[str,Any]:
        if not hypotheses:
            body={"proposal_id":_uuid({"request":req.get("request_id"),"none":True}),"class":"none","description":"No remediation proposed because evidence is insufficient.","structured_steps":[],"risk_assessment":"none","requires_authorization":False,"requires_simulation":False,"requires_verification":False,"requires_certification":False,"estimated_impact":{"blast_radius":impact.get("blast_radius")},"rollback_plan_ref":None,"status":"none","target_pipeline":"none"}
        else:
            symptom_class=str(req.get("symptom_class","anomaly")); cls="observe" if symptom_class in {"anomaly","degradation","drift"} else "escalate_human"
            if symptom_class=="resource_pressure": cls="adjust_budget"
            if symptom_class=="security_signal": cls="adjust_policy"
            risky=cls in {"restart_component","rollback_deployment","quarantine_agent","suspend_agent","reload_model","drain_and_recover","adjust_policy"}
            body={"proposal_id":_uuid({"request":req.get("request_id"),"class":cls}),"class":cls,"description":f"Controlled proposal derived from ranked hypotheses for {req.get('symptom',{}).get('subsystem','system')}","structured_steps":[{"step_id":_uuid({"request":req.get("request_id"),"step":1}),"kind":cls,"description":"Route proposal through the controlled downstream pipeline; do not apply in P2-T.","target_ref":str(req.get("symptom",{}).get("subsystem","system")),"proposed_change":{"kind":"diagnostic-proposal","hypothesis_refs":[h["hypothesis_id"] for h in hypotheses]},"risk_assessment":"high" if risky else "low","requires_simulation":risky,"requires_verification":True,"requires_authorization":risky,"requires_certification":True if cls not in {"observe","none"} else False,"rollback_plan_ref":None,"estimated_duration_s":0,"estimated_impact":{"blast_radius":impact.get("blast_radius")}}],"risk_assessment":"high" if risky else "low","requires_authorization":risky,"requires_simulation":risky,"requires_verification":True,"requires_certification":cls not in {"observe","none"},"estimated_impact":{"blast_radius":impact.get("blast_radius")},"rollback_plan_ref":None,"status":"proposed","target_pipeline":"P2-G→P2-B→P2-D"}
        body["diagnosis_id"]=str(req.get("request_id")); body["version"]=1; body["target_signal_id"]=str(req.get("symptom",{}).get("signal_id") or req.get("symptom",{}).get("symptom_id") or ""); body["integrity_hash"]=_hash(body); body["signature"]=_sign({k:v for k,v in body.items() if k not in {"signature","integrity_hash"}},self.signer); return body

    def propose_remediation(self, diagnosis_id: str, *, context: Any)->dict[str,Any]:
        ctx=self._require_context(context); d=self.store.get("diagnoses",diagnosis_id)
        if d is None: raise DiagnosisError("diagnosis not found")
        if d.get("tenant_id",ctx["tenant_id"])!=ctx["tenant_id"]: raise TenantIsolationError("cross-tenant diagnosis")
        proposal=d["remediation_proposal"]; self._handoff_proposal(proposal,context); return proposal

    def _handoff_proposal(self,proposal: Mapping[str,Any],context:Any)->None:
        if proposal.get("status") in {"none","rejected","superseded"}:return
        body=dict(proposal)
        if proposal.get("requires_authorization"): body["authorization_state"]="pending_security_authority"
        elif proposal.get("requires_simulation"): body["authorization_state"]="pending_p2_k"
        elif proposal.get("requires_certification"): body["authorization_state"]="pending_p2_b"
        else: body["authorization_state"]="pending_controlled_pipeline"
        if not proposal.get("requires_authorization") and not proposal.get("requires_simulation"):
            hook=self.downstream_hooks.get("p2_g")
            if hook is not None:
                hook(body)
            else:
                body["authorization_state"]="pending_p2_g"
        self._emit("RemediationProposed",{"proposal_id":proposal["proposal_id"],"class":proposal["class"],"authorization_state":body["authorization_state"]},context=context)

    def withdraw_proposal(self, proposal_id: str, reason: str, *, context: Any)->None:
        ctx=self._require_context(context); p=self.store.get("proposals",proposal_id)
        body=dict(p or {"proposal_id":proposal_id,"tenant_id":ctx["tenant_id"]}); body.update({"status":"superseded","withdraw_reason":str(reason),"withdrawn_at":_now()}); body["integrity_hash"]=_hash({k:v for k,v in body.items() if k not in {"signature","integrity_hash"}}); body["signature"]=_sign({k:v for k,v in body.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("proposals",proposal_id,ctx["tenant_id"],body); self._emit("RemediationWithdrawn",body,context=context)

    def list_proposals(self, filter: Mapping[str,Any]|None=None, *, context:Any)->list[dict[str,Any]]:
        ctx=self._require_context(context); out=self.store.list("proposals",ctx["tenant_id"],limit=5000)
        return out if not filter else [x for x in out if all(x.get(k)==v for k,v in filter.items())]

    def record_proposal_outcome(self, proposal_id: str, outcome: Mapping[str,Any], *, context: Any)->dict[str,Any]:
        ctx=self._require_context(context); p=self.store.get("proposals",proposal_id)
        if p is None:
            drows=self.store.list("diagnoses",ctx["tenant_id"],limit=5000); found=next((d.get("remediation_proposal") for d in drows if d.get("remediation_proposal",{}).get("proposal_id")==proposal_id),None); p=found
        if p is None: raise DiagnosisError("proposal not found")
        # Only downstream outcomes are accepted. Never perform the outcome here.
        allowed={"approved","applied","rejected","superseded","validated","unvalidated"}
        status=str(outcome.get("status",""));
        if status not in allowed: raise RemediationDenied("invalid downstream outcome")
        body={**p,"downstream_outcome":dict(outcome),"status":("applied" if status in {"applied","validated"} else status if status in {"rejected","superseded"} else "proposed")}
        body["integrity_hash"]=_hash({k:v for k,v in body.items() if k not in {"signature","integrity_hash"}}); body["signature"]=_sign({k:v for k,v in body.items() if k not in {"signature","integrity_hash"}},self.signer)
        self.store.put("proposals",proposal_id,ctx["tenant_id"],body)
        did=str(body.get("diagnosis_id","")); diagnosis=self.store.get("diagnoses",did) if did else None
        if diagnosis is not None:
            diagnosis=dict(diagnosis); diagnosis["remediation_status"]=body["status"];
            if status=="applied": diagnosis["state"]="remediated"
            elif status=="validated": diagnosis["state"]="verified"
            elif status in {"rejected","superseded"}: diagnosis["state"]="closed"
            diagnosis["integrity_hash"]=_hash({k:v for k,v in diagnosis.items() if k not in {"signature","integrity_hash"}}); diagnosis["signature"]=_sign({k:v for k,v in diagnosis.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("diagnoses",did,ctx["tenant_id"],diagnosis)
        event="RemediationApplied" if status=="applied" else "RemediationValidated" if status=="validated" else "RemediationUnvalidated" if status=="unvalidated" else "RemediationProposed"
        self._emit(event,body,context=context,severity="high" if status=="unvalidated" else None); return body

    def _project_world(self,diagnosis:Mapping[str,Any],context:Any)->None:
        if self.world_model is None:return
        try:self.world_model.record_event("System.DiagnosisOpened",dict(diagnosis),source="p2-t")
        except Exception:
            return

    def _handoff_failure_intelligence(self,diagnosis:Mapping[str,Any],context:Any)->None:
        if self.failure_intelligence is None:return
        try:
            auth=getattr(context,"auth_context",context); self.failure_intelligence.ingest({"event_type":"System.Diagnosis","payload":dict(diagnosis),"failure_class":"diagnostic","origin":"p2-t"},auth,source="p2-t-diagnosis")
        except Exception:
            return

    def get_diagnosis(self, diagnosis_id: str, *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); d=self.store.get("diagnoses",diagnosis_id)
        if d is None or d.get("tenant_id",ctx["tenant_id"])!=ctx["tenant_id"]: raise TenantIsolationError("diagnosis unavailable")
        return d

    def query_diagnoses(self, filter: Mapping[str,Any]|None=None, *, context:Any)->list[dict[str,Any]]:
        ctx=self._require_context(context); out=self.store.list("diagnoses",ctx["tenant_id"],limit=5000)
        return out if not filter else [d for d in out if all(d.get(k)==v for k,v in filter.items())]

    def history(self, subsystem: str, window: Mapping[str,Any], *, context:Any)->list[dict[str,Any]]:
        ctx=self._require_context(context); start=str(window.get("start","")); end=str(window.get("end","")); return [d for d in self.store.list("diagnoses",ctx["tenant_id"],limit=5000) if d.get("subsystem")==subsystem and (not start or d.get("opened_at","")>=start) and (not end or d.get("opened_at","")<=end)]

    def close_diagnosis(self, diagnosis_id: str, reason: str, *, actor: Mapping[str,Any], context:Any)->dict[str,Any]:
        ctx=self._require_context(context); d=self.get_diagnosis(diagnosis_id,context=context)
        if not reason: raise DiagnosisError("closure requires a reason")
        d=dict(d); d.update({"state":"closed","closed_at":_now(),"closed_reason":str(reason),"closed_by":dict(actor)}); d["integrity_hash"]=_hash({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}}); d["signature"]=_sign({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("diagnoses",diagnosis_id,ctx["tenant_id"],d); self._emit("DiagnosisClosed",{"diagnosis_id":diagnosis_id,"reason":reason},context=context); return d

    def reopen_diagnosis(self, diagnosis_id: str, reason: str, *, actor: Mapping[str,Any], context:Any)->dict[str,Any]:
        ctx=self._require_context(context); d=self.get_diagnosis(diagnosis_id,context=context)
        if not reason: raise DiagnosisError("reopen requires a reason")
        d=dict(d); d.update({"state":"open","reopened_at":_now(),"reopened_reason":str(reason),"reopened_by":dict(actor)}); d["integrity_hash"]=_hash({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}}); d["signature"]=_sign({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("diagnoses",diagnosis_id,ctx["tenant_id"],d); self._emit("DiagnosisReopened",{"diagnosis_id":diagnosis_id,"reason":reason},context=context); return d

    def register_verifier(self, method: str, verifier: Callable[...,Any])->None:
        if method not in METHODS: raise DiagnosisError("unknown verification method")
        self._verifiers[method]=verifier

    def verify_diagnosis(self, diagnosis_id: str, method: str, *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); d=self.get_diagnosis(diagnosis_id,context=context); verifier=self._verifiers.get(method)
        results=[]
        if verifier is not None:
            for h in d["hypotheses"]:
                try:
                    raw=verifier(d,h,ctx)
                    if isinstance(raw,Mapping): ok=bool(raw.get("verified",False)); contradicted=bool(raw.get("contradicted",False))
                    else: ok=bool(raw); contradicted=False
                except Exception: ok=False; contradicted=False
                results.append((h,ok,contradicted))
        else: results=[(h,False,False) for h in d["hypotheses"]]
        updated=dict(d); hyps=[]
        for h,ok,contradicted in results:
            x=dict(h); x["verified"]=bool(ok); x["verified_at"]=_now() if ok else None; x["verification_ref"]=_uuid({"diagnosis":diagnosis_id,"hypothesis":x["hypothesis_id"],"method":method}) if ok or contradicted else None; x["contradicted"]=bool(contradicted); hyps.append(x)
            if ok: self._emit("HypothesisVerified",{"diagnosis_id":diagnosis_id,"hypothesis_id":x["hypothesis_id"],"method":method},context=context)
            elif contradicted: self._emit("HypothesisContradicted",{"diagnosis_id":diagnosis_id,"hypothesis_id":x["hypothesis_id"],"method":method},context=context)
        updated["hypotheses"]=hyps; verified=[x for x in hyps if x["verified"]]; contradicted=[x for x in hyps if x.get("contradicted")]; updated["confidence"]=_confidence_level(max([float(x["confidence"]) for x in hyps] or [0]),verified=bool(verified),contradicted=bool(contradicted) and not verified); updated["state"]="verified" if verified else updated.get("state","analyzed")
        if verified:
            best=sorted(verified,key=lambda x:(-float(x["confidence"]),x["hypothesis_id"]))[0]; updated["root_cause"]={"hypothesis_id":best["hypothesis_id"],"hypothesis_text":best["hypothesis_text"],"confidence":best["confidence"],"verification_ref":best["verification_ref"]}
        else: updated.pop("root_cause",None)
        updated["integrity_hash"]=_hash({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}}); updated["signature"]=_sign({k:v for k,v in updated.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("diagnoses",diagnosis_id,ctx["tenant_id"],updated); return {"diagnosis_id":diagnosis_id,"method":method,"verified":bool(verified),"hypotheses":hyps}

    def replay_diagnosis(self, diagnosis_id: str, window: Mapping[str,Any], *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); original=self.get_diagnosis(diagnosis_id,context=context); start=str(window.get("start","")); end=str(window.get("end","")); signals=[s for s in self.store.list("signals",ctx["tenant_id"],limit=10000) if (not start or s.get("observed_at","")>=start) and (not end or s.get("observed_at","")<=end)]
        replay_hash=_hash(signals); signal=self.store.get("signals",str(original.get("remediation_proposal",{}).get("target_signal_id", ""))) if original.get("remediation_proposal",{}).get("target_signal_id") else None
        if signal is None:
            target_subsystem=original.get("subsystem"); target_metric=None
            for candidate in signals:
                if candidate.get("subsystem")==target_subsystem:
                    target_metric=candidate.get("metric_or_signal")
                    signal=candidate; break
        diverged=False
        if signal is not None:
            request={"request_version":1,"request_id":original["request_ref"],"tenant_id":ctx["tenant_id"],"symptom_class":original["symptom_class"],"symptom":{"symptom_id":_uuid({"replay":diagnosis_id}),"signal_id":signal["signal_id"],"observed_at":signal["observed_at"],"subsystem":signal["subsystem"],"metric_or_signal":signal["metric_or_signal"],"observed_value":signal.get("value"),"baseline_ref":original.get("baseline_ref",""),"deviation":{"kind":"replay"},"correlation_id":signal.get("correlation_id") or ctx["correlation_id"],"causation_id":signal.get("causation_id")},"max_hypotheses":len(original.get("hypotheses",[])) or 5}
            findings=self._detector_run(request,signal,ctx["tenant_id"]); baseline=None
            bref=original.get("baseline_ref","")
            if bref:
                baseline=self.store.get("baselines",str(bref).rsplit(":",1)[-1])
            replay_hypotheses=self._root_cause_candidates(request,signal,findings,baseline,context)
            replay_hypotheses=sorted(replay_hypotheses,key=lambda h:(-float(h.get("confidence",0)),h.get("hypothesis_id","")))[:len(original.get("hypotheses",[])) or 5]
            def stable_hypotheses(items):
                return [{k:h.get(k) for k in ("hypothesis_id","hypothesis_text","cause_class","confidence","method","method_version","evidence_refs","supporting_signals","contradicting_signals","verified")} for h in items]
            diverged=_hash(stable_hypotheses(replay_hypotheses)) != _hash(stable_hypotheses(original.get("hypotheses",[])))
        result={"diagnosis_id":diagnosis_id,"replay_hash":replay_hash,"original_hash":original["integrity_hash"],"signals_replayed":len(signals),"diverged":bool(diverged),"reconstructed_at":_now()}
        self._emit("HealthChanged",{"diagnosis_id":diagnosis_id,"replay_hash":replay_hash,"diverged":bool(diverged)},context=context); return result

    def health_status(self, subsystem: str, *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); entries=[s for s in self.store.list("signals",ctx["tenant_id"],limit=5000) if s.get("subsystem")==subsystem]
        diags=[d for d in self.store.list("diagnoses",ctx["tenant_id"],limit=5000) if d.get("subsystem")==subsystem and d.get("state") not in {"closed","verified"}]
        baseline_metrics={(b.get("subsystem"),b.get("metric_or_signal")) for b in self.store.list("baselines",ctx["tenant_id"],limit=5000)}
        observed_metrics={(s.get("subsystem"),s.get("metric_or_signal")) for s in entries}
        missing=[m for m in MONITORING_MATRIX.get(subsystem,{}).get("signals",[]) if (subsystem,m) not in observed_metrics]
        no_baseline=bool(observed_metrics) and any(item not in baseline_metrics for item in observed_metrics)
        status="unknown" if not entries or no_baseline else "healthy" if not diags else "degraded" if not any(d.get("outcome")=="critical" for d in diags) else "critical"
        ready = status == "healthy" and not missing and not no_baseline
        severity = "none" if ready else "critical" if status == "critical" else "high"
        return {"subsystem":subsystem,"tenant_id":ctx["tenant_id"],"status":status,"ready":ready,"severity":severity,"blocking":not ready,"signal_count":len(entries),"open_diagnoses":len(diags),"missing_signals":missing,"baseline_coverage_complete":not no_baseline,"monitoring_entry":MONITORING_MATRIX.get(subsystem),"computed_at":_now()}

    def health_status_all(self, *, context:Any)->list[dict[str,Any]]:
        return [self.health_status(k,context=context) for k in sorted(MONITORING_MATRIX)]

    def _continuous_evaluate_signal(self, signal: Mapping[str,Any], context: Any) -> dict[str,Any] | None:
        ctx=self._require_context(context)
        if not signal.get("signal_id") or signal.get("tenant_id")!=ctx["tenant_id"]:
            return None
        for baseline in self.store.list("baselines",ctx["tenant_id"],limit=5000):
            if baseline.get("subsystem")==signal.get("subsystem") and baseline.get("metric_or_signal")==signal.get("metric_or_signal") and baseline.get("environment_hash")==ctx["environment_hash"]:
                request={
                    "request_version":1,"request_id":_uuid({"continuous":True,"signal_id":signal["signal_id"],"baseline_id":baseline["baseline_id"]}),"tenant_id":ctx["tenant_id"],
                    "symptom_class":"anomaly","symptom":{"symptom_id":_uuid(signal),"observed_at":signal.get("observed_at"),"subsystem":signal.get("subsystem"),"metric_or_signal":signal.get("metric_or_signal"),"observed_value":signal.get("value"),"baseline_ref":f"urn:jarvis:p2t:baseline:{baseline['baseline_id']}",
                    "deviation":{"kind":"detector_window"},"correlation_id":signal.get("correlation_id") or ctx["correlation_id"],"causation_id":signal.get("causation_id")},
                    "correlated_symptom_refs":[],"environment_hash":ctx["environment_hash"],"registry_state_ref":"urn:jarvis:p2t:registry:state","policy_version":"1.0.0",
                    "window_start":baseline["window"]["start"],"window_end":baseline["window"]["end"],"max_hypotheses":5,"min_confidence":"low",
                    "requested_by":{"principal":ctx["principal"],"key_id":self.key_id},"requested_at":signal.get("observed_at") or _now(),
                }
                return self.diagnose(request,context=context)
        return None

    def start_continuous_evaluation(self, subsystem: str, *, context:Any, interval_s:float=10.0)->str:
        ctx=self._require_context(context); key=(ctx["tenant_id"],subsystem)
        if subsystem not in MONITORING_MATRIX: raise P2TError("unknown subsystem")
        if key in self._continuous:return f"{ctx['tenant_id']}:{subsystem}:active"
        stop=threading.Event(); self._continuous[key]=stop
        def run()->None:
            try:
                while not stop.wait(interval_s):
                    try:
                        ctx_local=self._require_context(context)
                        recent=[s for s in self.store.list("signals",ctx_local["tenant_id"],limit=5000) if s.get("subsystem")==subsystem]
                        if recent:
                            latest=recent[0]
                            self._continuous_evaluate_signal(latest,context)
                        self.health_status(subsystem,context=context)
                        checkpoint={"tenant_id":ctx_local["tenant_id"],"subsystem":subsystem,"last_signal_id":recent[0].get("signal_id") if recent else None,"checkpointed_at":_now(),"interval_s":interval_s,"status":"checkpoint"}
                        self.store.put("evaluations",_uuid(checkpoint),ctx_local["tenant_id"],checkpoint)
                    except Exception as exc:
                        fault={"tenant_id":ctx_local["tenant_id"] if 'ctx_local' in locals() else self.tenant_id,"subsystem":subsystem,"status":"evaluation_error","error":type(exc).__name__,"at":_now()}
                        self.store.put("evaluations",_uuid(fault),fault["tenant_id"],fault)
            finally:
                self._continuous.pop(key,None)
        t=threading.Thread(target=run,name=f"p2t-{subsystem}",daemon=True); t.start(); self._emit("ContinuousEvaluationStarted",{"subsystem":subsystem,"interval_s":interval_s},context=context); return f"{ctx['tenant_id']}:{subsystem}:active"

    def stop_continuous_evaluation(self, subsystem: str, reason: str, *, context:Any)->None:
        ctx=self._require_context(context); key=(ctx["tenant_id"],subsystem); stop=self._continuous.pop(key,None)
        if stop is not None: stop.set(); self._emit("ContinuousEvaluationStopped",{"subsystem":subsystem,"reason":reason},context=context)

    def escalate_diagnosis(self, diagnosis_id: str, target: str, reason: str, *, context:Any, deadline_s:int=300)->dict[str,Any]:
        ctx=self._require_context(context); d=self.get_diagnosis(diagnosis_id,context=context)
        esc={"escalation_id":_uuid({"diagnosis":diagnosis_id,"target":target}),"diagnosis_id":diagnosis_id,"tenant_id":ctx["tenant_id"],"target":target,"reason":reason,"deadline_at":time.time()+int(deadline_s),"status":"open","decision":None,"created_at":_now(),"signed_by":{"principal":ctx["principal"],"key_id":self.key_id}}
        esc["integrity_hash"]=_hash(esc); esc["signature"]=_sign(esc,self.signer); self.store.put("escalations",esc["escalation_id"],ctx["tenant_id"],esc); self._emit("Escalated",{"escalation_id":esc["escalation_id"],"diagnosis_id":diagnosis_id,"target":target},context=context,severity="high"); return esc

    def escalation_timeout(self, escalation_id: str, *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); e=self.store.get("escalations",escalation_id)
        if e is None or e.get("tenant_id")!=ctx["tenant_id"]: raise TenantIsolationError("escalation unavailable")
        e=dict(e); e["status"]="timed_out"; e["timeout_at"]=_now(); e["integrity_hash"]=_hash({k:v for k,v in e.items() if k not in {"signature","integrity_hash"}}); e["signature"]=_sign({k:v for k,v in e.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("escalations",escalation_id,ctx["tenant_id"],e); self._emit("EscalationTimeout",{"escalation_id":escalation_id,"diagnosis_id":e["diagnosis_id"]},context=context,severity="high"); d=self.store.get("diagnoses",e["diagnosis_id"]);
        if d is not None: d=dict(d); d["outcome"]="escalated"; d["state"]="closed"; d["integrity_hash"]=_hash({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}}); d["signature"]=_sign({k:v for k,v in d.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("diagnoses",d["diagnosis_id"],ctx["tenant_id"],d)
        return e

    def record_human_decision(self, escalation_id: str, decision: Mapping[str,Any], *, context:Any)->dict[str,Any]:
        ctx=self._require_context(context); e=self.store.get("escalations",escalation_id)
        if e is None or e.get("tenant_id")!=ctx["tenant_id"]: raise TenantIsolationError("escalation unavailable")
        if not decision.get("principal") or not decision.get("signature"): raise P2TError("human decision must be signed")
        e=dict(e); e["decision"]=dict(decision); e["status"]="decided"; e["integrity_hash"]=_hash({k:v for k,v in e.items() if k not in {"signature","integrity_hash"}}); e["signature"]=_sign({k:v for k,v in e.items() if k not in {"signature","integrity_hash"}},self.signer); self.store.put("escalations",escalation_id,ctx["tenant_id"],e); self._emit("Escalated",{"escalation_id":escalation_id,"diagnosis_id":e["diagnosis_id"],"decision_recorded":True},context=context,severity="high"); return e

    def close(self)->None:
        for stop in list(self._continuous.values()): stop.set()
        self._continuous.clear(); self.store.close()

    def replay_health_state(self, events: Sequence[Mapping[str,Any]], *, tenant_id: str) -> dict[str,Any]:
        state={"tenant_id":tenant_id,"subsystems":{},"diagnoses":{}}
        for event in sorted(events,key=lambda e:(e.get("sequence",0),e.get("event_id",""))):
            if event.get("tenant_id")!=tenant_id: continue
            name=str(event.get("event_name") or event.get("type") or "")
            p=dict(event.get("payload",{}))
            if name=="SignalCollected": state.setdefault("signals",{})[str(p.get("signal_id"))]=p
            elif name=="SignalMissing": state.setdefault("missing",{})[str(p.get("signal_id"))]=p
            elif name=="DiagnosisOpened": state["diagnoses"][str(p.get("diagnosis_id"))]=p
            elif name in {"DiagnosisClosed","DiagnosisReopened"} and p.get("diagnosis_id") in state["diagnoses"]: state["diagnoses"][p["diagnosis_id"]]["lifecycle"]=name
        state["state_hash"]=_hash(state); return state


# Backward-compatible alias used by integrators.
SystemDoctor = AutonomousSystemDoctor

__all__ = [
    "AutonomousSystemDoctor", "SystemDoctor", "P2TError", "BaselineError", "DetectorError", "DiagnosisError",
    "TenantIsolationError", "RemediationDenied", "ReplayError", "HealthBaseline", "DetectorSpec", "RemediationProposal",
    "SYMPTOM_CLASSES", "CONFIDENCE_LEVELS", "METHODS", "REMEDIATION_CLASSES", "OUTCOMES", "MONITORING_MATRIX",
    "REQUIRED_DETECTORS", "P2T_VERSION", "KERNEL_VERSION",
]

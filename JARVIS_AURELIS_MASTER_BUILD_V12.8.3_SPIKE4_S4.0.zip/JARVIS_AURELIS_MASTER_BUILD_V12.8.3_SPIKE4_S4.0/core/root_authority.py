"""Cryptographically scoped operator authority with immutable safety invariants."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RootCommandToken:
    operator_id: str
    capability: str
    nonce: str
    expires_at: float
    signature: str


class RootAuthority:
    """Issue one-shot, short-lived operator grants that cannot disable safety invariants."""

    def __init__(self, secret: bytes, *, max_ttl_seconds: float = 900.0) -> None:
        if len(secret) < 32:
            raise ValueError("root authority secret must be at least 32 bytes")
        self._secret = bytes(secret)
        self._max_ttl = max(1.0, min(float(max_ttl_seconds), 3_600.0))
        self._used: set[str] = set()
        self._lock = threading.RLock()
        self._immutable_denials = frozenset({"disable_safety", "bypass_authorization", "autonomous_targeting", "credential_exfiltration", "offensive_intrusion"})

    def issue(self, operator_id: str, capability: str, *, ttl_seconds: float = 300.0) -> RootCommandToken:
        operator, cap = str(operator_id).strip(), str(capability).strip()
        if not operator or not cap or cap in self._immutable_denials:
            raise PermissionError("capability violates root authority invariants")
        ttl = max(1.0, min(float(ttl_seconds), self._max_ttl))
        nonce = secrets.token_urlsafe(18)
        expires = time.time() + ttl
        canonical = f"{operator}|{cap}|{nonce}|{expires:.6f}".encode()
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        return RootCommandToken(operator, cap, nonce, expires, signature)

    def verify_and_consume(self, token: RootCommandToken, capability: str) -> bool:
        if token.capability != str(capability) or token.capability in self._immutable_denials or token.expires_at < time.time():
            return False
        canonical = f"{token.operator_id}|{token.capability}|{token.nonce}|{token.expires_at:.6f}".encode()
        expected = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        with self._lock:
            if token.nonce in self._used or not hmac.compare_digest(token.signature, expected):
                return False
            self._used.add(token.nonce)
            if len(self._used) > 100_000:
                self._used = set(list(self._used)[-50_000:])
            return True

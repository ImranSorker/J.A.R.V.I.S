"""Continuous multi-model evaluation fleet with baselines and regression gates."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

from core.evaluation_engine import EvaluationCase, EvaluationEngine, EvaluationReport


@dataclass(frozen=True, slots=True)
class FleetResult:
    """Model evaluation result with a quality and regression decision."""

    model: str
    success_rate: float
    exact_match_rate: float
    mean_latency_ms: float
    quality_score: float
    safety_score: float
    cost_usd: float
    composite_score: float
    regression: bool = False


class EvaluationFleet:
    """Evaluate several model runners and detect measurable regressions."""

    def __init__(self, lab: EvaluationEngine | object, *, max_models: int = 32) -> None:
        self.lab = lab
        self.max_models = max(1, min(int(max_models), 128))
        self._baselines: dict[str, EvaluationReport] = {}

    def set_baseline(self, report: EvaluationReport) -> None:
        """Store the last accepted report as a regression baseline."""
        self._baselines[report.name] = report

    def run(self, cases: Iterable[EvaluationCase], runners: dict[str, Callable[[str], str]]) -> list[FleetResult]:
        """Evaluate bounded runners, comparing each result to its baseline when present."""
        selected = dict(list(runners.items())[: self.max_models])
        if not selected:
            raise ValueError("at least one runner is required")
        materialized_cases = tuple(cases)
        if not materialized_cases:
            raise ValueError("at least one evaluation case is required")
        results: list[FleetResult] = []
        for name, runner in selected.items():
            report = self.lab.evaluate(str(name), materialized_cases, runner)
            baseline = self._baselines.get(str(name))
            regression = bool(baseline and (report.composite_score + 0.05 < baseline.composite_score or report.success_rate + 0.05 < baseline.success_rate))
            results.append(FleetResult(report.name, report.success_rate, report.exact_match_rate, report.mean_latency_ms, report.quality_score, report.safety_score, report.cost_usd, report.composite_score, regression))
        return results

    @staticmethod
    def rank(results: Iterable[FleetResult]) -> list[FleetResult]:
        """Return safe, high-quality models first with deterministic ordering."""
        return sorted(results, key=lambda item: (-item.composite_score, -item.safety_score, item.mean_latency_ms, item.model))

    def snapshot(self) -> dict[str, object]:
        """Return compact fleet state."""
        return {"baselines": sorted(self._baselines), "max_models": self.max_models}



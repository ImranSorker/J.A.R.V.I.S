"""Frontier batch execution depth for J.A.R.V.I.S. 12.8.0.

This module adds durable, bounded primitives on top of the existing control-plane
components. It is deliberately provider-neutral: platform-specific runtimes are
probed and reported, never silently assumed.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import shutil
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field, replace
from enum import StrEnum
from pathlib import Path
from typing import Any, Callable, Mapping


class FrontierBatchError(RuntimeError):
    """Base error for the frontier execution layer."""


class MissionState(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass(frozen=True, slots=True)
class MissionNodeV2:
    """One bounded DAG node."""

    node_id: str
    capability: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    depends_on: tuple[str, ...] = ()
    idempotency_key: str | None = None
    max_attempts: int = 2


@dataclass(frozen=True, slots=True)
class MissionPlanV2:
    """Validated mission plan."""

    mission_id: str
    objective: str
    nodes: tuple[MissionNodeV2, ...]
    max_duration_seconds: float = 300.0
    max_nodes: int = 256


@dataclass(frozen=True, slots=True)
class ExecutionReceipt:
    """Tamper-evident execution receipt."""

    receipt_id: str
    mission_id: str
    node_id: str
    status: str
    started_at: float
    finished_at: float
    result_digest: str | None
    authorization_digest: str
    signature: str


class DurableMissionEngineV2:
    """SQLite-backed mission DAG with leases, idempotency, cancellation and receipts."""

    def __init__(self, db_path: str | Path, secret: bytes, *, worker_id: str | None = None) -> None:
        if len(bytes(secret)) < 32:
            raise ValueError("mission secret must be at least 32 bytes")
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self.worker_id = str(worker_id or f"worker-{uuid.uuid4().hex[:12]}")[:128]
        self._lock = threading.RLock()
        self._cancel: set[str] = set()
        self._db = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None, timeout=30.0)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA foreign_keys=ON")
        self._init_db()

    def _init_db(self) -> None:
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS missions (
                mission_id TEXT PRIMARY KEY,
                objective TEXT NOT NULL,
                state TEXT NOT NULL,
                created_at REAL NOT NULL,
                started_at REAL,
                finished_at REAL,
                max_duration REAL NOT NULL,
                max_nodes INTEGER NOT NULL,
                error TEXT
            );
            CREATE TABLE IF NOT EXISTS mission_nodes (
                mission_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                capability TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                depends_json TEXT NOT NULL,
                idempotency_key TEXT,
                max_attempts INTEGER NOT NULL,
                state TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                lease_id TEXT,
                lease_until REAL,
                started_at REAL,
                finished_at REAL,
                result_json TEXT,
                result_digest TEXT,
                error TEXT,
                PRIMARY KEY (mission_id, node_id),
                UNIQUE(mission_id, idempotency_key),
                FOREIGN KEY(mission_id) REFERENCES missions(mission_id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS mission_receipts (
                receipt_id TEXT PRIMARY KEY,
                mission_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                status TEXT NOT NULL,
                started_at REAL NOT NULL,
                finished_at REAL NOT NULL,
                result_digest TEXT,
                authorization_digest TEXT NOT NULL,
                signature TEXT NOT NULL,
                FOREIGN KEY(mission_id) REFERENCES missions(mission_id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_nodes_ready ON mission_nodes(mission_id, state, node_id);
            """
        )

    @staticmethod
    def validate_plan(plan: MissionPlanV2) -> None:
        """Validate node identity, bounds, dependencies and acyclicity."""
        if not plan.mission_id.strip() or not plan.objective.strip():
            raise ValueError("mission_id and objective are required")
        if len(plan.nodes) == 0 or len(plan.nodes) > min(int(plan.max_nodes), 10_000):
            raise ValueError("mission node count is outside policy")
        if plan.max_duration_seconds <= 0 or plan.max_duration_seconds > 86_400:
            raise ValueError("mission duration is outside policy")
        index = {node.node_id: node for node in plan.nodes}
        if len(index) != len(plan.nodes) or any(not node.node_id.strip() for node in plan.nodes):
            raise ValueError("mission node ids must be unique and non-empty")
        for node in plan.nodes:
            if not node.capability.strip():
                raise ValueError(f"node {node.node_id} missing capability")
            if not (1 <= int(node.max_attempts) <= 10):
                raise ValueError(f"node {node.node_id} attempts outside policy")
            missing = [dep for dep in node.depends_on if dep not in index or dep == node.node_id]
            if missing:
                raise ValueError(f"invalid dependencies for {node.node_id}: {missing}")
        visiting: set[str] = set()
        visited: set[str] = set()

        def walk(node_id: str) -> None:
            if node_id in visiting:
                raise ValueError("mission graph contains a cycle")
            if node_id in visited:
                return
            visiting.add(node_id)
            for dep in index[node_id].depends_on:
                walk(dep)
            visiting.remove(node_id)
            visited.add(node_id)

        for node_id in index:
            walk(node_id)

    @staticmethod
    def _digest(value: Any) -> str:
        return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()).hexdigest()

    def _sign(self, record: Mapping[str, Any]) -> str:
        canonical = json.dumps(dict(record), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        return hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()

    def create(self, plan: MissionPlanV2) -> str:
        """Persist a validated mission plan."""
        self.validate_plan(plan)
        now = time.time()
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO missions(mission_id,objective,state,created_at,max_duration,max_nodes) VALUES(?,?,?,?,?,?)",
                (plan.mission_id, plan.objective[:20_000], MissionState.PENDING.value, now, float(plan.max_duration_seconds), int(plan.max_nodes)),
            )
            for node in plan.nodes:
                self._db.execute(
                    "INSERT INTO mission_nodes(mission_id,node_id,capability,payload_json,depends_json,idempotency_key,max_attempts,state) VALUES(?,?,?,?,?,?,?,?)",
                    (plan.mission_id, node.node_id, node.capability, json.dumps(dict(node.payload), sort_keys=True, separators=(",", ":")), json.dumps(list(node.depends_on)), node.idempotency_key, int(node.max_attempts), MissionState.PENDING.value),
                )
        return plan.mission_id

    def cancel(self, mission_id: str) -> bool:
        """Request cancellation; active workers observe it before each node and after callbacks."""
        mid = str(mission_id)
        with self._lock, self._db:
            row = self._db.execute("SELECT state FROM missions WHERE mission_id=?", (mid,)).fetchone()
            if row is None:
                return False
            if row[0] not in {MissionState.PENDING.value, MissionState.RUNNING.value}:
                return False
            self._cancel.add(mid)
            self._db.execute("UPDATE missions SET state=?,finished_at=? WHERE mission_id=?", (MissionState.CANCELLED.value, time.time(), mid))
            self._db.execute("UPDATE mission_nodes SET state=?,finished_at=? WHERE mission_id=? AND state IN (?,?)", (MissionState.CANCELLED.value, time.time(), mid, MissionState.PENDING.value, MissionState.RUNNING.value))
            return True

    def recover_expired_leases(self, *, now: float | None = None) -> int:
        """Return stale leased nodes to pending state for safe retry."""
        current = time.time() if now is None else float(now)
        with self._lock, self._db:
            cur = self._db.execute(
                "UPDATE mission_nodes SET state=?,lease_id=NULL,lease_until=NULL WHERE state=? AND lease_until IS NOT NULL AND lease_until < ?",
                (MissionState.PENDING.value, MissionState.RUNNING.value, current),
            )
            return int(cur.rowcount)

    def _ready_nodes(self, mission_id: str) -> list[sqlite3.Row]:
        rows = self._db.execute("SELECT * FROM mission_nodes WHERE mission_id=? ORDER BY node_id", (mission_id,)).fetchall()
        state_map = {str(row["node_id"]): str(row["state"]) for row in rows}
        result: list[sqlite3.Row] = []
        for row in rows:
            if row["state"] != MissionState.PENDING.value:
                continue
            deps = tuple(json.loads(row["depends_json"]))
            if all(state_map.get(dep) == MissionState.SUCCEEDED.value for dep in deps):
                result.append(row)
        return result

    def _receipt(self, *, mission_id: str, node_id: str, status: str, started: float, finished: float, result_digest: str | None, authorization_digest: str) -> ExecutionReceipt:
        payload = {
            "receipt_id": uuid.uuid4().hex,
            "mission_id": mission_id,
            "node_id": node_id,
            "status": status,
            "started_at": round(started, 6),
            "finished_at": round(finished, 6),
            "result_digest": result_digest,
            "authorization_digest": authorization_digest,
        }
        return ExecutionReceipt(**payload, signature=self._sign(payload))

    def verify_receipt(self, receipt: ExecutionReceipt) -> bool:
        """Verify receipt authenticity without modifying state."""
        payload = {
            "receipt_id": receipt.receipt_id,
            "mission_id": receipt.mission_id,
            "node_id": receipt.node_id,
            "status": receipt.status,
            "started_at": round(receipt.started_at, 6),
            "finished_at": round(receipt.finished_at, 6),
            "result_digest": receipt.result_digest,
            "authorization_digest": receipt.authorization_digest,
        }
        return hmac.compare_digest(receipt.signature, self._sign(payload))

    def execute(
        self,
        mission_id: str,
        *,
        authorize: Callable[[MissionNodeV2], bool],
        runner: Callable[[MissionNodeV2], Any],
        max_parallel: int = 1,
    ) -> dict[str, Any]:
        """Execute a mission DAG with strict duration, authorization and retry bounds.

        ``max_parallel`` is accepted as a contract but this implementation keeps
        execution serial to preserve deterministic ordering and transactional
        node leases. Parallel workers can be added behind the same durable schema.
        """
        del max_parallel
        mid = str(mission_id)
        with self._lock:
            mission = self._db.execute("SELECT * FROM missions WHERE mission_id=?", (mid,)).fetchone()
            if mission is None:
                raise KeyError(mid)
            if mission["state"] in {MissionState.SUCCEEDED.value, MissionState.CANCELLED.value}:
                return self.status(mid)
            self._db.execute("UPDATE missions SET state=?,started_at=COALESCE(started_at,?) WHERE mission_id=?", (MissionState.RUNNING.value, time.time(), mid))
        started = time.monotonic()
        self.recover_expired_leases()
        while True:
            if mid in self._cancel:
                return self.status(mid)
            with self._lock:
                mission = self._db.execute("SELECT * FROM missions WHERE mission_id=?", (mid,)).fetchone()
                if mission is None:
                    raise KeyError(mid)
                if time.monotonic() - started > float(mission["max_duration"]):
                    self._db.execute("UPDATE missions SET state=?,finished_at=?,error=? WHERE mission_id=?", (MissionState.FAILED.value, time.time(), "mission deadline exceeded", mid))
                    return self.status(mid)
                ready = self._ready_nodes(mid)
                incomplete = self._db.execute("SELECT COUNT(*) FROM mission_nodes WHERE mission_id=? AND state NOT IN (?,?)", (mid, MissionState.SUCCEEDED.value, MissionState.CANCELLED.value)).fetchone()[0]
                failed = self._db.execute("SELECT COUNT(*) FROM mission_nodes WHERE mission_id=? AND state=?", (mid, MissionState.FAILED.value)).fetchone()[0]
                if failed:
                    self._db.execute("UPDATE missions SET state=?,finished_at=?,error=? WHERE mission_id=?", (MissionState.FAILED.value, time.time(), "node failure", mid))
                    return self.status(mid)
                if incomplete == 0:
                    self._db.execute("UPDATE missions SET state=?,finished_at=? WHERE mission_id=?", (MissionState.SUCCEEDED.value, time.time(), mid))
                    return self.status(mid)
                if not ready:
                    self._db.execute("UPDATE missions SET state=?,finished_at=?,error=? WHERE mission_id=?", (MissionState.FAILED.value, time.time(), "mission DAG is blocked", mid))
                    return self.status(mid)
                row = ready[0]
                lease_id = uuid.uuid4().hex
                lease_until = time.time() + min(300.0, max(5.0, float(mission["max_duration"])))
                self._db.execute(
                    "UPDATE mission_nodes SET state=?,attempts=attempts+1,lease_id=?,lease_until=?,started_at=? WHERE mission_id=? AND node_id=? AND state=?",
                    (MissionState.RUNNING.value, lease_id, lease_until, time.time(), mid, row["node_id"], MissionState.PENDING.value),
                )
                updated = self._db.execute("SELECT * FROM mission_nodes WHERE mission_id=? AND node_id=?", (mid, row["node_id"])).fetchone()
            node = MissionNodeV2(
                node_id=str(updated["node_id"]),
                capability=str(updated["capability"]),
                payload=json.loads(updated["payload_json"]),
                depends_on=tuple(json.loads(updated["depends_json"])),
                idempotency_key=updated["idempotency_key"],
                max_attempts=int(updated["max_attempts"]),
            )
            started_node = time.time()
            auth_ok = bool(authorize(node))
            auth_digest = self._digest({"mission_id": mid, "node_id": node.node_id, "capability": node.capability, "allowed": auth_ok})
            result_digest: str | None = None
            status = MissionState.SUCCEEDED.value
            error: str | None = None
            result_payload: Any = None
            try:
                if not auth_ok:
                    raise PermissionError(f"capability denied: {node.capability}")
                if mid in self._cancel:
                    raise FrontierBatchError("mission cancelled")
                result_payload = runner(node)
                result_digest = self._digest(result_payload)
            except Exception as exc:
                status = MissionState.FAILED.value
                error = f"{type(exc).__name__}: {exc}"[:4_000]
            finished_node = time.time()
            receipt = self._receipt(mission_id=mid, node_id=node.node_id, status=status, started=started_node, finished=finished_node, result_digest=result_digest, authorization_digest=auth_digest)
            with self._lock, self._db:
                attempts = int(updated["attempts"])
                if status == MissionState.FAILED.value and attempts < int(updated["max_attempts"]):
                    self._db.execute("UPDATE mission_nodes SET state=?,lease_id=NULL,lease_until=NULL,error=? WHERE mission_id=? AND node_id=?", (MissionState.PENDING.value, error, mid, node.node_id))
                else:
                    self._db.execute("UPDATE mission_nodes SET state=?,lease_id=NULL,lease_until=NULL,finished_at=?,result_json=?,result_digest=?,error=? WHERE mission_id=? AND node_id=?", (status, finished_node, json.dumps(result_payload, sort_keys=True, separators=(",", ":"), default=str) if result_payload is not None else None, result_digest, error, mid, node.node_id))
                self._db.execute("INSERT INTO mission_receipts(receipt_id,mission_id,node_id,status,started_at,finished_at,result_digest,authorization_digest,signature) VALUES(?,?,?,?,?,?,?,?,?)", (receipt.receipt_id, receipt.mission_id, receipt.node_id, receipt.status, receipt.started_at, receipt.finished_at, receipt.result_digest, receipt.authorization_digest, receipt.signature))

    def status(self, mission_id: str) -> dict[str, Any]:
        """Return serializable mission and node state."""
        with self._lock:
            mission = self._db.execute("SELECT * FROM missions WHERE mission_id=?", (str(mission_id),)).fetchone()
            if mission is None:
                raise KeyError(mission_id)
            nodes = self._db.execute("SELECT node_id,capability,state,attempts,result_digest,error FROM mission_nodes WHERE mission_id=? ORDER BY node_id", (str(mission_id),)).fetchall()
            receipts = self._db.execute("SELECT receipt_id,node_id,status,started_at,finished_at,result_digest,authorization_digest,signature FROM mission_receipts WHERE mission_id=? ORDER BY finished_at,receipt_id", (str(mission_id),)).fetchall()
            return {
                "mission_id": str(mission["mission_id"]),
                "objective": str(mission["objective"]),
                "state": str(mission["state"]),
                "started_at": mission["started_at"],
                "finished_at": mission["finished_at"],
                "error": mission["error"],
                "nodes": [dict(row) for row in nodes],
                "receipts": [dict(row) for row in receipts],
            }

    def close(self) -> None:
        with self._lock:
            self._db.close()


@dataclass(frozen=True, slots=True)
class MemoryIntegrityRecord:
    """Hash-chained namespace event."""

    sequence: int
    event_id: str
    namespace: str
    event_type: str
    payload_digest: str
    previous_digest: str
    digest: str
    deleted: bool
    created_at: float


class MemoryIntegrityV3:
    """Hash-chained event journal with namespace isolation and deletion proofs."""

    def __init__(self, db_path: str | Path, secret: bytes) -> None:
        if len(bytes(secret)) < 32:
            raise ValueError("memory secret must be at least 32 bytes")
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None, timeout=30.0)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA secure_delete=ON")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS memory_events (
                namespace TEXT NOT NULL,
                sequence INTEGER NOT NULL,
                event_id TEXT PRIMARY KEY,
                event_type TEXT NOT NULL,
                payload_digest TEXT NOT NULL,
                previous_digest TEXT NOT NULL,
                digest TEXT NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                payload_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_memory_namespace ON memory_events(namespace, sequence);
            """
        )

    def _derive(self, namespace: str) -> bytes:
        return hmac.new(self._secret, str(namespace).encode(), hashlib.sha256).digest()

    def append(self, namespace: str, event_type: str, payload: Mapping[str, Any]) -> MemoryIntegrityRecord:
        """Append one immutable event to a namespace hash chain."""
        ns = str(namespace).strip()
        et = str(event_type).strip()
        if not ns or not et:
            raise ValueError("namespace and event_type are required")
        material = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        payload_digest = hashlib.sha256(material.encode()).hexdigest()
        with self._lock, self._db:
            last = self._db.execute("SELECT sequence,digest FROM memory_events WHERE namespace=? ORDER BY sequence DESC LIMIT 1", (ns,)).fetchone()
            sequence = int(last["sequence"]) + 1 if last else 1
            previous = str(last["digest"]) if last else "0" * 64
            event_id = uuid.uuid4().hex
            core = f"{ns}|{sequence}|{event_id}|{et}|{payload_digest}|{previous}"
            digest = hmac.new(self._derive(ns), core.encode(), hashlib.sha256).hexdigest()
            now = time.time()
            self._db.execute("INSERT INTO memory_events(namespace,sequence,event_id,event_type,payload_digest,previous_digest,digest,deleted,created_at,payload_json) VALUES(?,?,?,?,?,?,?,?,?,?)", (ns, sequence, event_id, et, payload_digest, previous, digest, 0, now, material))
            return MemoryIntegrityRecord(sequence, event_id, ns, et, payload_digest, previous, digest, False, now)

    def verify(self, namespace: str) -> list[str]:
        """Return integrity errors for a namespace; empty means valid."""
        ns = str(namespace)
        findings: list[str] = []
        with self._lock:
            rows = self._db.execute("SELECT * FROM memory_events WHERE namespace=? ORDER BY sequence", (ns,)).fetchall()
        previous = "0" * 64
        expected_sequence = 1
        for row in rows:
            if int(row["sequence"]) != expected_sequence:
                findings.append("sequence_gap")
                expected_sequence = int(row["sequence"])
            material = f"{ns}|{int(row['sequence'])}|{row['event_id']}|{row['event_type']}|{row['payload_digest']}|{row['previous_digest']}"
            expected = hmac.new(self._derive(ns), material.encode(), hashlib.sha256).hexdigest()
            if row["previous_digest"] != previous:
                findings.append(f"chain_break:{row['sequence']}")
            if not hmac.compare_digest(str(row["digest"]), expected):
                findings.append(f"digest_mismatch:{row['sequence']}")
            previous = str(row["digest"])
            expected_sequence = int(row["sequence"]) + 1
        return findings

    def tombstone(self, event_id: str, *, namespace: str) -> bool:
        """Cryptographically retain the audit event while deleting its payload."""
        with self._lock, self._db:
            row = self._db.execute("SELECT event_id FROM memory_events WHERE event_id=? AND namespace=?", (str(event_id), str(namespace))).fetchone()
            if row is None:
                return False
            self._db.execute("UPDATE memory_events SET deleted=1,payload_json=? WHERE event_id=? AND namespace=?", ("{\"deleted\":true}", str(event_id), str(namespace)))
            return True

    def snapshot(self, namespace: str) -> dict[str, Any]:
        """Return non-sensitive integrity state."""
        with self._lock:
            count = int(self._db.execute("SELECT COUNT(*) FROM memory_events WHERE namespace=?", (str(namespace),)).fetchone()[0])
            deleted = int(self._db.execute("SELECT COUNT(*) FROM memory_events WHERE namespace=? AND deleted=1", (str(namespace),)).fetchone()[0])
            last = self._db.execute("SELECT digest FROM memory_events WHERE namespace=? ORDER BY sequence DESC LIMIT 1", (str(namespace),)).fetchone()
        return {"namespace": str(namespace), "events": count, "tombstones": deleted, "head": str(last[0]) if last else "0" * 64}

    def close(self) -> None:
        with self._lock:
            self._db.close()


class CudaRuntimeProbe:
    """Provider-neutral local GPU/accelerator probe and bounded benchmark."""

    def __init__(self) -> None:
        self._torch = None
        try:
            import torch  # type: ignore
            self._torch = torch
        except Exception:
            self._torch = None

    def snapshot(self) -> dict[str, Any]:
        """Return hardware facts without initializing a model."""
        torch = self._torch
        if torch is None:
            return {"provider": "none", "available": False, "reason": "torch_unavailable", "devices": []}
        try:
            available = bool(torch.cuda.is_available())
            devices: list[dict[str, Any]] = []
            if available:
                for index in range(int(torch.cuda.device_count())):
                    props = torch.cuda.get_device_properties(index)
                    devices.append({"index": index, "name": str(props.name), "total_vram_mb": int(props.total_memory / 1_048_576), "multi_processor_count": int(props.multi_processor_count), "compute_capability": f"{props.major}.{props.minor}"})
            return {"provider": "torch-cuda", "available": available, "devices": devices}
        except Exception as exc:
            return {"provider": "torch-cuda", "available": False, "devices": [], "reason": f"{type(exc).__name__}: {exc}"}

    def benchmark(self, *, device_index: int = 0, size: int = 256, repeats: int = 3) -> dict[str, Any]:
        """Run a small bounded matmul benchmark only when CUDA is available."""
        info = self.snapshot()
        if not info.get("available"):
            return {"ok": False, "reason": info.get("reason", "cuda_unavailable"), "device": info}
        torch = self._torch
        n = max(16, min(int(size), 2048))
        count = max(1, min(int(repeats), 20))
        device = torch.device(f"cuda:{int(device_index)}")
        try:
            a = torch.randn((n, n), device=device)
            b = torch.randn((n, n), device=device)
            torch.cuda.synchronize(device)
            started = time.perf_counter()
            for _ in range(count):
                _ = a @ b
            torch.cuda.synchronize(device)
            elapsed = (time.perf_counter() - started) * 1000.0
            return {"ok": True, "device_index": int(device_index), "size": n, "repeats": count, "elapsed_ms": elapsed, "matmul_per_second": count / max(elapsed / 1000.0, 1e-9)}
        except Exception as exc:
            return {"ok": False, "reason": f"{type(exc).__name__}: {exc}"}


class UAVMode(StrEnum):
    DISARMED = "disarmed"
    ARMED = "armed"
    AIRBORNE = "airborne"
    EMERGENCY = "emergency"


@dataclass(frozen=True, slots=True)
class UAVState:
    """Deterministic simulator state suitable for mission certification."""

    mode: UAVMode
    lat: float
    lon: float
    altitude_m: float
    battery_pct: float
    home_lat: float
    home_lon: float
    geofence_radius_m: float
    reason: str = ""


class UAVSimulator:
    """Simulator-first UAV safety state machine with geofencing and emergency stop."""

    EARTH_RADIUS_M = 6_371_000.0

    def __init__(self, *, lat: float = 0.0, lon: float = 0.0, geofence_radius_m: float = 250.0, battery_pct: float = 100.0) -> None:
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("invalid home coordinates")
        if geofence_radius_m <= 1 or geofence_radius_m > 100_000:
            raise ValueError("geofence radius is outside policy")
        self._state = UAVState(UAVMode.DISARMED, float(lat), float(lon), 0.0, max(0.0, min(100.0, float(battery_pct))), float(lat), float(lon), float(geofence_radius_m), "startup")
        self._lock = threading.RLock()

    @classmethod
    def _distance_m(cls, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dp = math.radians(lat2 - lat1)
        dl = math.radians(lon2 - lon1)
        a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
        return 2 * cls.EARTH_RADIUS_M * math.asin(math.sqrt(max(0.0, min(1.0, a))))

    def arm(self) -> UAVState:
        with self._lock:
            if self._state.mode == UAVMode.EMERGENCY or self._state.battery_pct < 15.0:
                raise PermissionError("UAV cannot arm in current safety state")
            self._state = replace(self._state, mode=UAVMode.ARMED, reason="armed")
            return self._state

    def takeoff(self, altitude_m: float) -> UAVState:
        with self._lock:
            if self._state.mode != UAVMode.ARMED:
                raise PermissionError("UAV must be armed before takeoff")
            altitude = max(1.0, min(float(altitude_m), 120.0))
            self._state = self._replace(mode=UAVMode.AIRBORNE, altitude_m=altitude, reason="takeoff")
            return self._state

    def goto(self, lat: float, lon: float, altitude_m: float | None = None) -> UAVState:
        with self._lock:
            if self._state.mode != UAVMode.AIRBORNE:
                raise PermissionError("UAV must be airborne before navigation")
            distance = self._distance_m(self._state.home_lat, self._state.home_lon, float(lat), float(lon))
            if distance > self._state.geofence_radius_m:
                self._state = self._replace(mode=UAVMode.EMERGENCY, reason="geofence violation")
                raise PermissionError("destination exceeds geofence")
            self._state = self._replace(lat=float(lat), lon=float(lon), altitude_m=self._state.altitude_m if altitude_m is None else max(1.0, min(float(altitude_m), 120.0)), battery_pct=max(0.0, self._state.battery_pct - max(distance / 1000.0, 0.1) * 0.5), reason="navigate")
            return self._state

    def return_to_home(self) -> UAVState:
        with self._lock:
            if self._state.mode not in {UAVMode.AIRBORNE, UAVMode.ARMED}:
                raise PermissionError("UAV is not returnable")
            self._state = self._replace(lat=self._state.home_lat, lon=self._state.home_lon, altitude_m=0.0, mode=UAVMode.ARMED, reason="return_to_home")
            return self._state

    def emergency_stop(self, reason: str) -> UAVState:
        with self._lock:
            self._state = self._replace(mode=UAVMode.EMERGENCY, altitude_m=0.0, reason=str(reason)[:1_000] or "emergency")
            return self._state

    def _replace(self, **changes: Any) -> UAVState:
        values = {
            "mode": self._state.mode,
            "lat": self._state.lat,
            "lon": self._state.lon,
            "altitude_m": self._state.altitude_m,
            "battery_pct": self._state.battery_pct,
            "home_lat": self._state.home_lat,
            "home_lon": self._state.home_lon,
            "geofence_radius_m": self._state.geofence_radius_m,
            "reason": self._state.reason,
        }
        values.update(changes)
        return UAVState(**values)

    def state(self) -> dict[str, Any]:
        with self._lock:
            return {"mode": self._state.mode.value, "lat": self._state.lat, "lon": self._state.lon, "altitude_m": self._state.altitude_m, "battery_pct": self._state.battery_pct, "home_lat": self._state.home_lat, "home_lon": self._state.home_lon, "geofence_radius_m": self._state.geofence_radius_m, "reason": self._state.reason}


class FrontierBatchFabric:
    """Aggregate the new execution-depth services behind one injected facade."""

    def __init__(self, root: str | Path, secret: bytes) -> None:
        if len(bytes(secret)) < 32:
            raise ValueError("frontier batch secret must be at least 32 bytes")
        base = Path(root).resolve()
        base.mkdir(parents=True, exist_ok=True)
        self.root = base
        self.missions = DurableMissionEngineV2(base / "missions_v2.db", secret)
        self.memory = MemoryIntegrityV3(base / "memory_integrity_v3.db", secret)
        self.cuda = CudaRuntimeProbe()
        self.uav = UAVSimulator()
        self.created_at = time.time()

    def health(self) -> dict[str, Any]:
        """Return safe state and runtime capability evidence."""
        return {
            "uptime_seconds": time.time() - self.created_at,
            "cuda": self.cuda.snapshot(),
            "uav": self.uav.state(),
            "mission_db": str(self.missions.db_path),
            "memory_db": str(self.memory.db_path),
            "isolation_wrappers": {name: bool(shutil.which(name)) for name in ("bwrap", "unshare")},
            "wasi": bool(shutil.which("wasmtime")),
        }

    def close(self) -> None:
        self.missions.close()
        self.memory.close()

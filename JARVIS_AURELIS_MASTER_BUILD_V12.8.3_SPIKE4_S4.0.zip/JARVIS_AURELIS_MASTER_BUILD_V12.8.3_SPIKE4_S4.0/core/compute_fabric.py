"""Resource-aware compute fabric for local and remote JARVIS nodes."""
from __future__ import annotations

import threading
import time
from dataclasses import replace
from typing import Callable, Sequence

from core.contracts.platform import ComputeNode, ComputeProvider


class ComputeFabric:
    """Register, heartbeat, expire and select compute nodes deterministically."""

    def __init__(self, provider: ComputeProvider | None = None, *, lease_seconds: float = 30.0, max_nodes: int = 128) -> None:
        self.provider = provider
        self.lease_seconds = max(2.0, float(lease_seconds))
        self.max_nodes = max(1, min(int(max_nodes), 1024))
        self._nodes: dict[str, ComputeNode] = {}
        self._heartbeats: dict[str, float] = {}
        self._lock = threading.RLock()

    def refresh(self) -> Sequence[ComputeNode]:
        """Refresh from an injected provider while preserving state on failure."""
        if self.provider is None:
            return self.list_nodes()
        try:
            nodes = list(self.provider.discover())
        except Exception:
            return self.list_nodes()
        with self._lock:
            for node in nodes[: self.max_nodes]:
                self._nodes[node.node_id] = node
                self._heartbeats[node.node_id] = time.time()
        return self.list_nodes()

    def register(self, node: ComputeNode) -> None:
        """Register a node with bounded cardinality."""
        with self._lock:
            if node.node_id not in self._nodes and len(self._nodes) >= self.max_nodes:
                raise RuntimeError("compute-node capacity reached")
            self._nodes[node.node_id] = node
            self._heartbeats[node.node_id] = time.time()

    def heartbeat(self, node_id: str, **changes: object) -> bool:
        """Refresh node liveness and replace only known fields."""
        with self._lock:
            current = self._nodes.get(node_id)
            if current is None:
                return False
            allowed = {name for name in current.__dataclass_fields__}
            payload = {key: value for key, value in changes.items() if key in allowed and key != "node_id"}
            self._nodes[node_id] = replace(current, **payload)
            self._heartbeats[node_id] = time.time()
            return True

    def expire(self) -> int:
        """Remove nodes whose lease has elapsed."""
        cutoff = time.time() - self.lease_seconds
        with self._lock:
            stale = [node_id for node_id, seen in self._heartbeats.items() if seen < cutoff]
            for node_id in stale:
                self._nodes.pop(node_id, None)
                self._heartbeats.pop(node_id, None)
            return len(stale)

    def list_nodes(self) -> list[ComputeNode]:
        """Return a stable snapshot."""
        self.expire()
        with self._lock:
            return sorted(self._nodes.values(), key=lambda node: node.node_id)

    def select(self, capability: str, *, min_vram_mb: int = 0, max_latency_ms: float | None = None) -> ComputeNode | None:
        """Select the best live node using capability, memory, latency and load."""
        cap = str(capability).strip()
        candidates = [
            node
            for node in self.list_nodes()
            if node.online
            and ("*" in node.capabilities or cap in node.capabilities)
            and node.vram_mb >= int(min_vram_mb)
            and (max_latency_ms is None or node.latency_ms <= float(max_latency_ms))
        ]
        return min(candidates, key=lambda node: (node.latency_ms, -node.vram_mb, -node.cpu_slots, node.node_id)) if candidates else None

    def dispatch(self, capability: str, fn: Callable[[ComputeNode], object]) -> object:
        """Run work against the selected provider without embedding transport semantics."""
        node = self.select(capability)
        if node is None:
            raise LookupError(f"no compute node supports capability: {capability}")
        return fn(node)

    def snapshot(self) -> dict[str, object]:
        """Return non-sensitive fabric state."""
        return {"nodes": [node.__dict__.copy() for node in self.list_nodes()], "count": len(self.list_nodes())}



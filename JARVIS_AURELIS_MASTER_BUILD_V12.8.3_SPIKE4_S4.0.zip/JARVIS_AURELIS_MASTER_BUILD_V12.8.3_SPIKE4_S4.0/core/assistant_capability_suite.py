"""Production desktop capability adapters for J.A.R.V.I.S.

The suite exposes optional, policy-neutral adapters for clipboard, screen and
camera capture, hosted model providers, Office document generation, Home
Assistant, and Android discovery.  It deliberately separates acquisition and
transport from authorization: callers must perform policy checks before using
mutating integrations.
"""
from __future__ import annotations

import base64
import os
import shutil
import tempfile
import re
from urllib.parse import urlparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import httpx

from core.frontier_completion import CapturePrivacyPolicy, ClipboardIntelligence


@dataclass(frozen=True, slots=True)
class CapabilityStatus:
    """Runtime availability for one optional capability."""

    name: str
    available: bool
    detail: str


class ClipboardAdapter:
    """Read and write the host clipboard through an optional safe adapter."""

    def __init__(self) -> None:
        self._module: Any | None = None
        try:
            import pyperclip

            self._module = pyperclip
        except ImportError:
            self._module = None

    @property
    def available(self) -> bool:
        """Return whether clipboard integration is installed."""
        return self._module is not None

    def read_text(self, max_chars: int = 200_000) -> str:
        """Read bounded text from the clipboard."""
        if not self._module:
            raise RuntimeError("clipboard backend is unavailable")
        if max_chars < 1:
            raise ValueError("max_chars must be positive")
        value = str(self._module.paste() or "")
        return value[:max_chars]

    def write_text(self, text: str) -> None:
        """Write text to the clipboard."""
        if not self._module:
            raise RuntimeError("clipboard backend is unavailable")
        if len(text) > 200_000:
            raise ValueError("clipboard text exceeds the safety limit")
        self._module.copy(str(text))

    def analyze(self, action: str, local_infer: Any, *, max_chars: int = 20_000) -> str:
        """Analyze clipboard data with an injected local-only inference callback."""
        return ClipboardIntelligence().analyze(self.read_text(max_chars=max_chars), action=action, local_infer=local_infer, max_chars=max_chars)


class ScreenCaptureAdapter:
    """Capture the desktop without granting the model filesystem authority."""

    def __init__(self, privacy_policy: CapturePrivacyPolicy | None = None) -> None:
        self._mss: Any | None = None
        self.privacy_policy = privacy_policy or CapturePrivacyPolicy()
        self.privacy_policy.validate()
        try:
            import mss

            self._mss = mss
        except ImportError:
            self._mss = None

    @property
    def available(self) -> bool:
        """Return whether screen capture is installed."""
        return self._mss is not None

    def capture_png(self, monitor: int = 1) -> bytes:
        """Capture one monitor as PNG bytes with no persistent recording."""
        if self._mss is None:
            raise RuntimeError("screen capture backend is unavailable")
        if monitor < 1:
            raise ValueError("monitor must be >= 1")
        from PIL import Image

        with self._mss.mss() as session:
            monitors = session.monitors
            if monitor >= len(monitors):
                raise ValueError("requested monitor does not exist")
            shot = session.grab(monitors[monitor])
            image = Image.frombytes("RGB", shot.size, shot.rgb)
            with tempfile.SpooledTemporaryFile(max_size=4_000_000) as output:
                image.save(output, format="PNG", optimize=True)
                output.seek(0)
                data = output.read()
        if len(data) > self.privacy_policy.max_bytes:
            raise ValueError("captured screen exceeds the safety limit")
        return self.privacy_policy.redact_png(data)


class CameraCaptureAdapter:
    """Capture a single camera frame; continuous recording is intentionally absent."""

    def __init__(self, privacy_policy: CapturePrivacyPolicy | None = None) -> None:
        self._cv2: Any | None = None
        self.privacy_policy = privacy_policy or CapturePrivacyPolicy()
        self.privacy_policy.validate()
        try:
            import cv2

            self._cv2 = cv2
        except ImportError:
            self._cv2 = None

    @property
    def available(self) -> bool:
        """Return whether camera capture is installed."""
        return self._cv2 is not None

    def capture_png(self, camera_index: int = 0) -> bytes:
        """Capture exactly one frame and release the camera immediately."""
        if self._cv2 is None:
            raise RuntimeError("camera backend is unavailable")
        if camera_index < 0:
            raise ValueError("camera_index must be non-negative")
        camera = self._cv2.VideoCapture(camera_index)
        try:
            if not camera.isOpened():
                raise RuntimeError("camera could not be opened")
            ok, frame = camera.read()
            if not ok:
                raise RuntimeError("camera frame capture failed")
            ok, encoded = self._cv2.imencode(".png", frame)
            if not ok:
                raise RuntimeError("camera frame encoding failed")
            data = bytes(encoded.tobytes())
            if len(data) > self.privacy_policy.max_bytes:
                raise ValueError("captured camera frame exceeds the safety limit")
            return self.privacy_policy.redact_png(data)
        finally:
            camera.release()


_MODEL_NAME = re.compile(r"^[A-Za-z0-9_.:/-]{1,160}$")


class LocalVisionAdapter:
    """Local OpenAI-compatible vision adapter restricted to loopback endpoints."""

    def __init__(self, base_url: str | None = None, model: str | None = None, timeout_seconds: float = 120.0) -> None:
        self.base_url = (base_url or os.environ.get("JARVIS_LOCAL_VISION_URL", "http://127.0.0.1:52851/v1")).strip().rstrip("/")
        self.model = model or os.environ.get("JARVIS_LOCAL_VISION_MODEL", "")
        self.timeout = httpx.Timeout(max(1.0, float(timeout_seconds)))
        host = self.base_url.split("://", 1)[-1].split("/", 1)[0].split(":", 1)[0]
        if host not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("local vision endpoint must be loopback")

    @property
    def available(self) -> bool:
        """Return whether a local vision model is explicitly configured."""
        return bool(self.model)

    def analyze(self, image: bytes, prompt: str) -> str:
        """Analyze one image with a local multimodal chat endpoint."""
        if not image:
            raise ValueError("image is required")
        if not self.available:
            raise RuntimeError("local vision model is not configured")
        encoded = base64.b64encode(image).decode("ascii")
        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": [
                {"type": "text", "text": str(prompt)[:10_000]},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{encoded}"}},
            ]}],
            "temperature": 0.2,
            "max_tokens": 2048,
        }
        with httpx.Client(timeout=self.timeout, follow_redirects=False) as client:
            response = client.post(f"{self.base_url}/chat/completions", json=payload)
            response.raise_for_status()
            data = response.json()
        return str(data.get("choices", [{}])[0].get("message", {}).get("content", ""))


class OfficeArtifactAdapter:
    """Create DOCX, XLSX and PPTX files from structured data."""

    def __init__(self, workspace: str | Path) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _destination(self, filename: str) -> Path:
        candidate = (self.workspace / filename).resolve()
        if candidate == self.workspace or os.path.commonpath((str(self.workspace), str(candidate))) != str(self.workspace):
            raise ValueError("artifact path escapes workspace")
        candidate.parent.mkdir(parents=True, exist_ok=True)
        return candidate

    def create_docx(self, filename: str, title: str, paragraphs: Sequence[str]) -> Path:
        """Create a Word document using only supplied structured text."""
        from docx import Document

        destination = self._destination(filename)
        document = Document()
        document.add_heading(str(title)[:500], level=1)
        for paragraph in paragraphs[:10_000]:
            document.add_paragraph(str(paragraph)[:20_000])
        self._atomic_save(document.save, destination)
        return destination

    def create_xlsx(self, filename: str, sheets: Mapping[str, Sequence[Sequence[Any]]]) -> Path:
        """Create a workbook from bounded row/column data."""
        from openpyxl import Workbook

        destination = self._destination(filename)
        workbook = Workbook()
        workbook.remove(workbook.active)
        for index, (name, rows) in enumerate(sheets.items()):
            sheet = workbook.create_sheet(str(name)[:31] or f"Sheet{index + 1}")
            for row in list(rows)[:100_000]:
                sheet.append([self._safe_cell(value) for value in list(row)[:256]])
        self._atomic_save(workbook.save, destination)
        return destination

    @staticmethod
    def _safe_cell(value: Any) -> Any:
        """Prevent spreadsheet formula injection while preserving basic scalar types."""
        if value is None or isinstance(value, (int, float, bool)):
            return value
        text = str(value)[:10_000]
        if text.startswith(("=", "+", "-", "@")):
            return "'" + text
        return text

    def create_pptx(self, filename: str, slides: Sequence[Mapping[str, Any]]) -> Path:
        """Create a presentation from structured slide titles and bullets."""
        from pptx import Presentation

        destination = self._destination(filename)
        presentation = Presentation()
        for item in list(slides)[:500]:
            slide = presentation.slides.add_slide(presentation.slide_layouts[1])
            slide.shapes.title.text = str(item.get("title", "J.A.R.V.I.S."))[:500]
            body = slide.placeholders[1].text_frame
            body.clear()
            bullets = item.get("bullets", [])
            for index, bullet in enumerate(list(bullets)[:100]):
                paragraph = body.paragraphs[0] if index == 0 else body.add_paragraph()
                paragraph.text = str(bullet)[:5_000]
        self._atomic_save(presentation.save, destination)
        return destination

    @staticmethod
    def _atomic_save(save_fn: Any, destination: Path) -> None:
        """Serialize an Office document to a temporary file and atomically replace it."""
        fd, tmp_name = tempfile.mkstemp(prefix=destination.name + ".", suffix=".tmp", dir=destination.parent)
        os.close(fd)
        tmp = Path(tmp_name)
        try:
            save_fn(tmp)
            os.replace(tmp, destination)
        finally:
            tmp.unlink(missing_ok=True)


class HomeAssistantAdapter:
    """Authenticated Home Assistant REST connector with explicit service allowlists."""

    ALLOWED_SERVICES = frozenset({"light/turn_on", "light/turn_off", "switch/turn_on", "switch/turn_off", "media_player/turn_on", "media_player/turn_off"})

    def __init__(self, *, base_url: str | None = None, token: str | None = None, timeout_seconds: float = 15.0) -> None:
        self.base_url = (base_url or os.environ.get("JARVIS_HOME_ASSISTANT_URL", "")).strip().rstrip("/")
        self.token = (token or os.environ.get("JARVIS_HOME_ASSISTANT_TOKEN", "")).strip()
        self.timeout = httpx.Timeout(max(1.0, float(timeout_seconds)))

    @property
    def available(self) -> bool:
        """Return whether a strictly configured HTTPS Home Assistant origin exists."""
        if not (self.base_url and self.token and self.base_url.startswith("https://")):
            return False
        try:
            parsed = urlparse(self.base_url)
            return bool(parsed.hostname and not parsed.username and not parsed.password and parsed.path in {"", "/"})
        except ValueError:
            return False

    def _client(self) -> httpx.Client:
        """Create a no-redirect client so credentials cannot follow a hostile redirect."""
        return httpx.Client(timeout=self.timeout, follow_redirects=False, headers={"Authorization": f"Bearer {self.token}", "Accept": "application/json"})

    def states(self) -> list[dict[str, Any]]:
        """Read entity states over authenticated HTTPS."""
        if not self.available:
            raise RuntimeError("secure Home Assistant configuration is unavailable")
        with self._client() as client:
            response = client.get(f"{self.base_url}/api/states")
            if response.is_redirect or response.is_permanent_redirect:
                raise RuntimeError("Home Assistant redirects are blocked")
            response.raise_for_status()
            data = response.json()
        if not isinstance(data, list):
            raise RuntimeError("Home Assistant returned an invalid state payload")
        return [item for item in data if isinstance(item, dict)]

    def call_service(self, service: str, entity_id: str) -> dict[str, Any]:
        """Call only a pre-approved non-destructive device service."""
        if service not in self.ALLOWED_SERVICES:
            raise PermissionError("Home Assistant service is not allowlisted")
        if not entity_id or len(entity_id) > 255 or not re.fullmatch(r"[a-z0-9_]+\.[a-z0-9_]+", entity_id):
            raise ValueError("invalid Home Assistant entity id")
        if not self.available:
            raise RuntimeError("secure Home Assistant configuration is unavailable")
        domain, _ = service.split("/", 1)
        with self._client() as client:
            response = client.post(f"{self.base_url}/api/services/{domain}/{service.split('/', 1)[1]}", json={"entity_id": entity_id})
            if response.is_redirect or response.is_permanent_redirect:
                raise RuntimeError("Home Assistant redirects are blocked")
            response.raise_for_status()
            result = response.json()
        return result if isinstance(result, dict) else {"result": result}


class AndroidBridge:
    """Safe ADB discovery/intent bridge without arbitrary shell execution."""

    def __init__(self, adb_path: str | None = None, timeout_seconds: float = 10.0) -> None:
        configured = adb_path or os.environ.get("JARVIS_ADB_PATH", "adb")
        resolved = shutil.which(configured) if not Path(configured).is_absolute() else configured
        self.adb_path = resolved
        self.timeout = max(1.0, float(timeout_seconds))

    @property
    def available(self) -> bool:
        """Return whether the configured ADB binary exists."""
        return bool(self.adb_path and Path(self.adb_path).is_file())

    def devices(self) -> list[str]:
        """List connected Android serials using the fixed ADB command."""
        if not self.available:
            raise RuntimeError("ADB is unavailable")
        from core.trusted_process import TrustedProcessAdapter
        workspace = Path.cwd() / "data" / "workspace"
        runner = TrustedProcessAdapter(workspace, timeout_seconds=self.timeout, max_memory_mb=256, allow_network=True)
        result = runner.run((self.adb_path, "devices"), allowed_executables=(Path(self.adb_path).name,))
        if not result.ok:
            raise RuntimeError("ADB device discovery failed")
        devices: list[str] = []
        for line in result.stdout.splitlines()[1:]:
            parts = line.split("\t", 1)
            if len(parts) == 2 and parts[1].strip() == "device" and parts[0].strip():
                devices.append(parts[0].strip())
        return devices


class AssistantCapabilitySuite:
    """Unified capability surface consumed by the J.A.R.V.I.S. core and UI."""

    def __init__(self, workspace: str | Path) -> None:
        self.clipboard = ClipboardAdapter()
        self.screen = ScreenCaptureAdapter()
        self.camera = CameraCaptureAdapter()
        self.vision = LocalVisionAdapter()
        self.office = OfficeArtifactAdapter(workspace)
        self.home_assistant = HomeAssistantAdapter()
        self.android = AndroidBridge()

    def status(self) -> tuple[CapabilityStatus, ...]:
        """Return deterministic capability availability information."""
        statuses = (
            CapabilityStatus("clipboard", self.clipboard.available, "pyperclip" if self.clipboard.available else "install pyperclip"),
            CapabilityStatus("screen_capture", self.screen.available, "mss" if self.screen.available else "install mss"),
            CapabilityStatus("camera_capture", self.camera.available, "opencv" if self.camera.available else "install opencv-python"),
            CapabilityStatus("office_docx", _optional_import("docx"), "python-docx" if _optional_import("docx") else "install python-docx"),
            CapabilityStatus("office_xlsx", _optional_import("openpyxl"), "openpyxl" if _optional_import("openpyxl") else "install openpyxl"),
            CapabilityStatus("office_pptx", _optional_import("pptx"), "python-pptx" if _optional_import("pptx") else "install python-pptx"),
            CapabilityStatus("home_assistant", self.home_assistant.available, "HTTPS + token configured" if self.home_assistant.available else "configure JARVIS_HOME_ASSISTANT_URL/TOKEN"),
            CapabilityStatus("android_adb", self.android.available, "ADB" if self.android.available else "configure JARVIS_ADB_PATH"),
            CapabilityStatus("local_vision", self.vision.available, "loopback multimodal model configured" if self.vision.available else "configure JARVIS_LOCAL_VISION_MODEL"),
        )
        return tuple(sorted(statuses, key=lambda item: item.name))


def _optional_import(name: str) -> bool:
    """Return whether an optional Python module can be imported."""
    try:
        __import__(name)
        return True
    except ImportError:
        return False



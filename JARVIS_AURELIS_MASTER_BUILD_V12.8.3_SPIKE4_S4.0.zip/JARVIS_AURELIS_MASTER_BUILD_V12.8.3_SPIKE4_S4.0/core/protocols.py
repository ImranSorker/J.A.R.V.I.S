"""Runtime-checkable structural protocols for cross-module contracts."""
from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
@runtime_checkable
class EmbedderProtocol(Protocol):
    def embed(self,text:str)->list[float]: raise RuntimeError("abstract contract method invoked")
@runtime_checkable
class RouterProtocol(Protocol):
    def list_backends(self)->list[dict]: raise RuntimeError("abstract contract method invoked")
    def generate(self,prompt:str,backend_name:str|None=None,stream:bool=False,**kwargs:Any)->Any: raise RuntimeError("abstract contract method invoked")
    def set_primary(self,name:str)->None: raise RuntimeError("abstract contract method invoked")
    def register_backend(self,name:str,backend:Any,info:Any=None)->None: raise RuntimeError("abstract contract method invoked")
@runtime_checkable
class RetrieverProtocol(Protocol):
    def set_embedder(self,embedder:Any)->None: raise RuntimeError("abstract contract method invoked")
    def index(self,doc_id:str,text:str,vector:list[float]|None=None)->None: raise RuntimeError("abstract contract method invoked")
    def retrieve(self,query:str,top_k:int=5)->list[dict[str,Any]]: raise RuntimeError("abstract contract method invoked")
@runtime_checkable
class PermissionEngineProtocol(Protocol):
    def issue_grant(self,capability:str,expiry:int=300)->str: raise RuntimeError("abstract contract method invoked")
    def verify(self,token_b64:str,capability:str|None=None)->bool: raise RuntimeError("abstract contract method invoked")


"""Thread-safe bounded TTL cache for deterministic tool results."""
from __future__ import annotations

from collections import OrderedDict
import threading
import time
from typing import Any, Optional


class ToolCache:
    """Bounded LRU+TTL cache with deterministic eviction and hit/miss metrics."""

    def __init__(self, ttl: float = 300.0, max_entries: int = 2048) -> None:
        self.ttl = max(1.0, float(ttl))
        self.max_entries = max(1, int(max_entries))
        self._cache: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._lock = threading.RLock()
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Optional[Any]:
        now = time.monotonic()
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses += 1
                return None
            value, created = entry
            if now - created >= self.ttl:
                self._cache.pop(key, None)
                self._misses += 1
                return None
            self._cache.move_to_end(key)
            self._hits += 1
            return value

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            self._cache[key] = (value, time.monotonic())
            self._cache.move_to_end(key)
            while len(self._cache) > self.max_entries:
                self._cache.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()

    def snapshot(self) -> dict[str, float | int]:
        with self._lock:
            total = self._hits + self._misses
            return {"entries": len(self._cache), "max_entries": self.max_entries, "hits": self._hits, "misses": self._misses, "hit_rate": (self._hits / total if total else 0.0)}



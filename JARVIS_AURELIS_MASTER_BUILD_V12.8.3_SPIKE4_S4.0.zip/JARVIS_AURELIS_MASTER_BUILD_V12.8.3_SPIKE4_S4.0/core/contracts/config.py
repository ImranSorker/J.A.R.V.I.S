"""Typed configuration access contract."""

from __future__ import annotations

from typing import Any, Protocol, TypeVar

T = TypeVar("T")


class ConfigProvider(Protocol):
    """Provider abstraction allowing JSON, TOML or environment-backed config."""

    def get(self, key: str, default: Any = None) -> Any: raise RuntimeError("abstract contract method invoked")
    def get_typed(self, key: str, type_: type[T], default: T | None = None) -> T: raise RuntimeError("abstract contract method invoked")
class TypedConfig:
    """Small typed facade over a replaceable configuration provider."""

    def __init__(self, provider: ConfigProvider) -> None:
        self._provider = provider

    def get_str(self, key: str, default: str = "") -> str:
        return self._provider.get_typed(key, str, default)

    def get_int(self, key: str, default: int = 0) -> int:
        return self._provider.get_typed(key, int, default)

    def get_bool(self, key: str, default: bool = False) -> bool:
        return self._provider.get_typed(key, bool, default)



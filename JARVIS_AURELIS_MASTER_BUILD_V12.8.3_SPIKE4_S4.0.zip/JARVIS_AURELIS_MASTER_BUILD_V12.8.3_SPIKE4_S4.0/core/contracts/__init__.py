"""Stable, UI-independent contracts for J.A.R.V.I.S. infrastructure."""

from .capability import Capability, CapabilityRegistryContract
from .config import ConfigProvider, TypedConfig
from .event import Event, EventBusContract, EventHandler
from .lifecycle import Lifecycle, Restartable, Startable, Stoppable
from .resource import Resource, ResourceGuard, ResourceOwner

__all__ = [
    "Capability", "CapabilityRegistryContract",
    "ConfigProvider", "TypedConfig",
    "Event", "EventBusContract", "EventHandler",
    "Lifecycle", "Restartable", "Startable", "Stoppable",
    "Resource", "ResourceGuard", "ResourceOwner",
]

from core.contracts.intelligence import ContextItem, CognitiveContext, Intent, IntentKind, ReflectionResult, VerificationResult
__all__ += ["ContextItem", "CognitiveContext", "Intent", "IntentKind", "ReflectionResult", "VerificationResult"]
from .autonomy import Goal, GoalProvider, GoalStatus, MissionExecutor, MissionStatus, MissionStepSpec, VerificationGate, VerificationGateResult
__all__ += ["Goal", "GoalProvider", "GoalStatus", "MissionExecutor", "MissionStatus", "MissionStepSpec", "VerificationGate", "VerificationGateResult"]

from core.contracts.platform import (
    BenchmarkProvider, BenchmarkSample, ComputeNode, ComputeProvider, EvaluationCase, OSAdapter,
    PlatformKind, PlatformSnapshot, SkillManifest, SkillProvider, StateProvider,
)
__all__ += ["BenchmarkSample", "ComputeNode", "EvaluationCase", "OSAdapter", "PlatformKind", "PlatformSnapshot", "SkillManifest", "StateProvider", "SkillProvider", "ComputeProvider", "BenchmarkProvider"]
from core.contracts.platform import PlatformPolicy
__all__ += ["PlatformPolicy"]



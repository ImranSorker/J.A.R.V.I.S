"""Stable capability metadata and registry contract."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Protocol


@dataclass(frozen=True, slots=True)
class Capability:
    """Describes a replaceable runtime capability and its policy surface."""

    name: str
    version: str = "1.0"
    permissions: tuple[str, ...] = ()
    inputs: Mapping[str, type[Any]] = field(default_factory=dict)
    outputs: Mapping[str, type[Any]] = field(default_factory=dict)
    implementation: Any = None
    enabled: bool = True

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("capability name is required")


class CapabilityRegistryContract(Protocol):
    """Replaceable contract for capability discovery."""

    def register(self, capability: Capability | str, probe: Callable[[], Any] | None = None) -> None: raise RuntimeError("abstract contract method invoked")
    def get(self, name: str) -> Capability | None: raise RuntimeError("abstract contract method invoked")
    def list(self) -> list[str]: raise RuntimeError("abstract contract method invoked")
    def has(self, name: str) -> bool: raise RuntimeError("abstract contract method invoked")


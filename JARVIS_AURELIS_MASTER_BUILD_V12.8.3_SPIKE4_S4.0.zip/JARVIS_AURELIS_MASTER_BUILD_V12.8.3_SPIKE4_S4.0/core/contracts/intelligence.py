"""Stable interfaces for the Phase-B intelligence plane."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Protocol


class IntentKind(str, Enum):
    CHAT = "chat"
    QUESTION = "question"
    TASK = "task"
    RESEARCH = "research"
    ACTION = "action"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class Intent:
    """Normalized request intent."""
    kind: IntentKind
    text: str
    confidence: float = 1.0
    constraints: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ContextItem:
    """A bounded piece of context with provenance and relevance."""
    item_id: str
    source: str
    text: str
    relevance: float = 0.0
    trust: str = "untrusted"
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CognitiveContext:
    """Final assembled context passed to planning/execution."""
    request_id: str
    items: tuple[ContextItem, ...] = ()
    budget_tokens: int = 4096


@dataclass(frozen=True, slots=True)
class VerificationResult:
    """Explicit verification outcome."""
    ok: bool
    score: float
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ReflectionResult:
    """Post-task reflection used for safe memory/evaluation updates."""
    summary: str
    lessons: tuple[str, ...] = ()
    confidence: float = 0.0


class ContextProvider(Protocol):
    """Replaceable context provider contract."""
    def build(self, text: str, *, request_id: str, budget_tokens: int = 4096) -> CognitiveContext: raise RuntimeError("abstract contract method invoked")
class ModelProvider(Protocol):
    """Replaceable model provider boundary."""
    def generate(self, prompt: str, **kwargs: Any) -> Any: raise RuntimeError("abstract contract method invoked")
class EvaluationProvider(Protocol):
    """Replaceable evaluation boundary."""
    def evaluate(self, name: str, cases: Any, runner: Any) -> Any: raise RuntimeError("abstract contract method invoked")


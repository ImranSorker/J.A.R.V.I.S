"""Replaceable asynchronous lifecycle contracts."""

from __future__ import annotations

from typing import Protocol


class Startable(Protocol):
    """Component that can be started asynchronously."""
    async def start(self) -> None: raise RuntimeError("abstract contract method invoked")
class Stoppable(Protocol):
    """Component that can be stopped asynchronously."""
    async def stop(self) -> None: raise RuntimeError("abstract contract method invoked")
class Restartable(Protocol):
    """Component that can be restarted asynchronously."""
    async def restart(self) -> None: raise RuntimeError("abstract contract method invoked")
class Lifecycle(Startable, Stoppable, Restartable, Protocol):
    """Full lifecycle contract for long-running infrastructure components."""



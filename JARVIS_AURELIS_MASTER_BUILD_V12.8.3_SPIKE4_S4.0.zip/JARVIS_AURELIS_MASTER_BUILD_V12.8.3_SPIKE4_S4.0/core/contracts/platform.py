"""Stable contracts for the AI-native operating layer and optimisation fabric."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping, Protocol, Sequence


class PlatformKind(StrEnum):
    WINDOWS = "windows"
    LINUX = "linux"
    MACOS = "macos"
    ANDROID = "android"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class PlatformSnapshot:
    """Immutable host identity exposed to higher-level cognition."""

    kind: PlatformKind
    architecture: str
    python_version: str
    hostname: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ComputeNode:
    """Portable compute-node description used by local and remote schedulers."""

    node_id: str
    capabilities: tuple[str, ...] = ()
    memory_mb: int = 0
    vram_mb: int = 0
    cpu_slots: int = 1
    latency_ms: float = 0.0
    online: bool = True
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SkillManifest:
    """Signed, declarative skill metadata; executable code stays outside the manifest."""

    name: str
    version: str
    capabilities: tuple[str, ...] = ()
    entrypoint: str = ""
    permissions: tuple[str, ...] = ()
    checksum: str = ""
    signature: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class BenchmarkSample:
    """One reproducible benchmark observation."""

    benchmark_id: str
    workload: str
    latency_ms: float
    tokens_per_second: float = 0.0
    success: bool = True
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class EvaluationCase:
    """Bounded continuous-evaluation case."""

    case_id: str
    input: str
    expected: Any
    evaluator: str = "exact"


class OSAdapter(Protocol):
    """Replaceable operating-system adapter boundary."""

    def snapshot(self) -> PlatformSnapshot: raise RuntimeError("abstract contract method invoked")
    def open_target(self, target: str) -> bool: raise RuntimeError("abstract contract method invoked")
    def environment(self) -> Mapping[str, str]: raise RuntimeError("abstract contract method invoked")
class ComputeProvider(Protocol):
    """Replaceable compute-node provider."""

    def discover(self) -> Sequence[ComputeNode]: raise RuntimeError("abstract contract method invoked")
class StateProvider(Protocol):
    """Portable export/import state boundary."""

    def export(self) -> Mapping[str, Any]: raise RuntimeError("abstract contract method invoked")
    def import_state(self, state: Mapping[str, Any]) -> None: raise RuntimeError("abstract contract method invoked")
class SkillProvider(Protocol):
    """Skill catalogue and trust boundary."""

    def install(self, manifest: SkillManifest) -> None: raise RuntimeError("abstract contract method invoked")
    def remove(self, name: str) -> bool: raise RuntimeError("abstract contract method invoked")
    def list(self) -> Sequence[SkillManifest]: raise RuntimeError("abstract contract method invoked")
class BenchmarkProvider(Protocol):
    """Benchmark execution boundary."""

    def record(self, sample: BenchmarkSample) -> None: raise RuntimeError("abstract contract method invoked")
    def snapshot(self) -> Sequence[BenchmarkSample]: raise RuntimeError("abstract contract method invoked")
@dataclass(frozen=True)
class PlatformPolicy:
    """Explicit resource and security policy metadata for the AIOS boundary."""
    max_concurrency: int = 4
    max_network_requests: int = 100
    max_execution_seconds: float = 60.0
    require_authorization_for_external: bool = True

    def validate(self) -> None:
        """Validate policy bounds."""
        if self.max_concurrency < 1 or self.max_network_requests < 0 or self.max_execution_seconds <= 0:
            raise ValueError("invalid platform policy")



"""Stable event envelope and event-bus contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Any, Awaitable, Callable, Mapping, Protocol
from uuid import uuid4

EventHandler = Callable[["Event"], Awaitable[None] | None]


@dataclass(frozen=True, slots=True)
class Event:
    """Immutable top-level event envelope carrying provenance and correlation."""

    event_id: str
    event_type: str
    timestamp: datetime
    source: str
    correlation_id: str
    causation_id: str | None = None
    payload: Mapping[str, Any] = field(default_factory=dict)
    schema_version: str = "1.0"
    tenant_id: str = "default"
    workspace_id: str = "default"
    authorization_context: Mapping[str, Any] = field(default_factory=dict)
    provenance: Mapping[str, Any] = field(default_factory=dict)
    integrity_hash: str = ""

    def __post_init__(self) -> None:
        if not self.event_id or not self.event_type or not self.source:
            raise ValueError("event_id, event_type and source are required")
        object.__setattr__(self, "payload", MappingProxyType(dict(self.payload)))
        object.__setattr__(self, "authorization_context", MappingProxyType(dict(self.authorization_context)))
        object.__setattr__(self, "provenance", MappingProxyType(dict(self.provenance)))
        if not self.integrity_hash:
            import hashlib, json
            material = {"event_id": self.event_id, "event_type": self.event_type, "timestamp": self.timestamp.isoformat(), "source": self.source, "correlation_id": self.correlation_id, "causation_id": self.causation_id, "payload": dict(self.payload), "schema_version": self.schema_version, "tenant_id": self.tenant_id, "workspace_id": self.workspace_id, "authorization_context": dict(self.authorization_context), "provenance": dict(self.provenance)}
            digest = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()
            object.__setattr__(self, "integrity_hash", digest)

    @classmethod
    def new(
        cls,
        event_type: str,
        source: str,
        payload: Mapping[str, Any] | None = None,
        *,
        correlation_id: str | None = None,
        causation_id: str | None = None,
        schema_version: str = "1.0",
        tenant_id: str = "default",
        workspace_id: str = "default",
        authorization_context: Mapping[str, Any] | None = None,
        provenance: Mapping[str, Any] | None = None,
    ) -> "Event":
        """Create a new UTC event with generated identifiers."""
        return cls(
            event_id=uuid4().hex,
            event_type=event_type,
            timestamp=datetime.now(timezone.utc),
            source=source,
            correlation_id=correlation_id or uuid4().hex,
            causation_id=causation_id,
            payload=payload or {},
            schema_version=schema_version,
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            authorization_context=authorization_context or {},
            provenance=provenance or {},
        )


class EventBusContract(Protocol):
    """Replaceable contract for publishing and subscribing to events."""

    def publish(self, event: Event) -> bool: raise RuntimeError("abstract contract method invoked")
    def subscribe(self, event_type: str, handler: EventHandler) -> None: raise RuntimeError("abstract contract method invoked")
    def unsubscribe(self, event_type: str, handler: EventHandler) -> None: raise RuntimeError("abstract contract method invoked")
    def shutdown(self, timeout: float = 5.0) -> None: raise RuntimeError("abstract contract method invoked")


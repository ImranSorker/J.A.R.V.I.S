"""Stable contracts for durable autonomy and mission execution."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Protocol, Sequence


class GoalStatus(str, Enum):
    """Lifecycle states for first-class goals."""

    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class MissionStatus(str, Enum):
    """Lifecycle states for durable mission execution."""

    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    VERIFYING = "verifying"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    ROLLED_BACK = "rolled_back"


@dataclass(frozen=True, slots=True)
class Goal:
    """First-class durable objective with explicit authority and success criteria."""

    goal_id: str
    objective: str
    priority: int = 5
    owner: str = "jarvis"
    constraints: Mapping[str, Any] = field(default_factory=dict)
    success_criteria: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()
    deadline: float | None = None
    status: GoalStatus = GoalStatus.QUEUED


@dataclass(frozen=True, slots=True)
class MissionStepSpec:
    """Immutable DAG node specification."""

    step_id: str
    name: str
    dependencies: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    capability: str = "observe"


@dataclass(frozen=True, slots=True)
class VerificationGateResult:
    """Machine-readable verification decision."""

    passed: bool
    score: float
    reasons: tuple[str, ...] = ()
    evidence: Mapping[str, Any] = field(default_factory=dict)


class GoalProvider(Protocol):
    """Replaceable goal persistence and management boundary."""

    def create(self, goal: Goal) -> Goal: raise RuntimeError("abstract contract method invoked")
    def get(self, goal_id: str) -> Goal | None: raise RuntimeError("abstract contract method invoked")
    def update_status(self, goal_id: str, status: GoalStatus) -> Goal: raise RuntimeError("abstract contract method invoked")
class MissionProvider(Protocol):
    """Replaceable mission persistence boundary."""

    def put(self, mission: Any) -> Any: raise RuntimeError("abstract contract method invoked")
    def get(self, mission_id: str) -> Any | None: raise RuntimeError("abstract contract method invoked")
    def list(self) -> Sequence[Any]: raise RuntimeError("abstract contract method invoked")
class MissionExecutor(Protocol):
    """Replaceable mission execution boundary."""

    def execute(self, mission_id: str, goal: Goal, steps: Sequence[MissionStepSpec]) -> Any: raise RuntimeError("abstract contract method invoked")
class VerificationGate(Protocol):
    """Replaceable postcondition verification boundary."""

    def verify(self, goal: Goal, result: Any) -> VerificationGateResult: raise RuntimeError("abstract contract method invoked")


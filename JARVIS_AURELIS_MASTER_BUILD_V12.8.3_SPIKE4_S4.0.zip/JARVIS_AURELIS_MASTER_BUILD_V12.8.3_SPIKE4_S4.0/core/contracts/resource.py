"""Resource ownership and deterministic release contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from time import monotonic
from typing import Awaitable, Protocol
import inspect


@dataclass(frozen=True, slots=True)
class Resource:
    """Metadata identifying a resource and its owning component."""

    name: str
    owner_id: str
    acquired_at: float = field(default_factory=monotonic)


class ResourceOwner(Protocol):
    """Owner responsible for releasing a resource it acquired."""

    @property
    def id(self) -> str: raise RuntimeError("abstract contract method invoked")
    def release_resource(self, resource: Resource) -> Awaitable[None] | None: raise RuntimeError("abstract contract method invoked")
class ResourceGuard:
    """Async context manager that guarantees release even on failure."""

    def __init__(self, resource: Resource, owner: ResourceOwner) -> None:
        self.resource = resource
        self.owner = owner

    async def __aenter__(self) -> Resource:
        return self.resource

    async def __aexit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        result = self.owner.release_resource(self.resource)
        if inspect.isawaitable(result):
            await result



"""Interlocked laboratory automation planning and execution contracts."""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, Sequence


@dataclass(frozen=True, slots=True)
class LabStep:
    step_id: str
    instrument: str
    action: str
    parameters: Mapping[str, float | str] = field(default_factory=dict)
    hazardous: bool = False


@dataclass(frozen=True, slots=True)
class LabPlan:
    plan_id: str
    steps: tuple[LabStep, ...]
    dry_run: bool = True
    human_approved: bool = False


@dataclass(frozen=True, slots=True)
class LabReceipt:
    plan_id: str
    status: str
    results: tuple[Mapping[str, Any], ...]
    digest: str


class LabInstrumentAdapter(Protocol):
    """Explicit instrument boundary; implementation owns physical I/O."""

    def prepare(self, step: LabStep) -> bool: ...
    def execute(self, step: LabStep) -> Mapping[str, Any]: ...


class LabAutomationEngine:
    """Validate, simulate, or execute interlocked lab plans through adapters."""

    def validate(self, plan: LabPlan) -> None:
        if not plan.plan_id.strip() or not plan.steps or len(plan.steps) > 512:
            raise ValueError("lab plan is outside policy")
        ids = [step.step_id for step in plan.steps]
        if len(set(ids)) != len(ids) or any(not step.instrument.strip() or not step.action.strip() for step in plan.steps):
            raise ValueError("lab step identities are invalid")
        for step in plan.steps:
            if len(json.dumps(dict(step.parameters), sort_keys=True, default=str).encode()) > 32_768:
                raise ValueError("lab step parameters are too large")

    def run(self, plan: LabPlan, adapters: Mapping[str, LabInstrumentAdapter]) -> LabReceipt:
        self.validate(plan)
        if any(step.hazardous for step in plan.steps) and not plan.human_approved:
            raise PermissionError("hazardous laboratory actions require explicit human approval")
        results: list[Mapping[str, Any]] = []
        if plan.dry_run:
            results = [{"step_id": step.step_id, "instrument": step.instrument, "action": step.action, "simulated": True} for step in plan.steps]
        else:
            for step in plan.steps:
                adapter = adapters.get(step.instrument)
                if adapter is None:
                    raise LookupError(f"instrument adapter unavailable: {step.instrument}")
                if not adapter.prepare(step):
                    raise RuntimeError(f"instrument interlock rejected step: {step.step_id}")
                results.append(dict(adapter.execute(step)))
        digest = hashlib.sha256(json.dumps(results, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
        return LabReceipt(plan.plan_id, "simulated" if plan.dry_run else "completed", tuple(results), digest)

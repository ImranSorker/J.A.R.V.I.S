"""Workspace containment and capability guard."""
from __future__ import annotations
from pathlib import Path


class SecurityGuard:
    def __init__(self, workspace_root: str = "data/workspace", allow_shell: bool = False):
        self.workspace = Path(workspace_root).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.allow_shell = allow_shell

    def check_path(self, path: str | Path) -> Path:
        p = Path(path).expanduser().resolve()
        if self.workspace not in p.parents and p != self.workspace:
            raise PermissionError(f"Path {p} is outside workspace {self.workspace}")
        return p



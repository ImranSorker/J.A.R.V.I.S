"""Bounded, cryptographically authorized agent execution runtime."""
from __future__ import annotations

import concurrent.futures
import hashlib
import hmac
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from core.agent_policy import AgentPolicyEngine, UsageSnapshot
from core.permanent_evolution import A2ATaskSigner, CapabilityLease, CapabilityLeaseRegistry, SignedA2ATaskEnvelope
from core.trust_engine import TrustDecision, TrustEngine, TrustRequest


@dataclass(frozen=True, slots=True)
class AgentBudget:
    """Hard execution bounds for one agent invocation."""

    timeout_seconds: float = 120.0
    max_output_bytes: int = 1_000_000
    max_retries: int = 0

    def validate(self) -> None:
        if not 0.1 <= float(self.timeout_seconds) <= 3600.0:
            raise ValueError("timeout_seconds out of range")
        if not 1024 <= int(self.max_output_bytes) <= 100_000_000:
            raise ValueError("max_output_bytes out of range")
        if not 0 <= int(self.max_retries) <= 5:
            raise ValueError("max_retries out of range")


@dataclass(frozen=True, slots=True)
class AgentRequest:
    """Immutable request envelope presented to the runtime."""

    request_id: str
    agent_name: str
    principal: str
    capability: str
    resource: str
    description: str
    mission_id: str | None = None
    destructive: bool = False
    external_content: bool = False
    requires_network: bool = False
    required_capabilities: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @staticmethod
    def create(agent_name: str, principal: str, capability: str, resource: str, description: str, **kwargs: Any) -> "AgentRequest":
        text = str(description).strip()
        if not text or len(text.encode("utf-8")) > 1_000_000:
            raise ValueError("agent description is empty or oversized")
        return AgentRequest(
            request_id=uuid.uuid4().hex,
            agent_name=str(agent_name),
            principal=str(principal),
            capability=str(capability),
            resource=str(resource),
            description=text,
            mission_id=kwargs.get("mission_id"),
            destructive=bool(kwargs.get("destructive", False)),
            external_content=bool(kwargs.get("external_content", False)),
            requires_network=bool(kwargs.get("requires_network", False)),
            required_capabilities=tuple(str(v) for v in kwargs.get("required_capabilities", ())),
            metadata=dict(kwargs.get("metadata", {}) or {}),
        )


@dataclass(frozen=True, slots=True)
class AgentReceipt:
    """Tamper-evident result receipt for an agent invocation."""

    request_id: str
    agent_name: str
    ok: bool
    decision: str
    output_sha256: str
    output_bytes: int
    latency_ms: float
    attempts: int
    error: str | None = None
    lease_id: str | None = None
    signature: str = ""


def policy_engine_capabilities(policy_engine: AgentPolicyEngine, agent_name: str) -> tuple[str, ...]:
    """Return normalized declared capabilities for trust evaluation."""
    policy = policy_engine.get_policy(agent_name)
    if policy is None:
        return ()
    caps = set(policy.capabilities)
    if "tools.*" in caps:
        caps.add("*")
    return tuple(sorted(caps))


class AgentCancellation:
    """Cooperative cancellation token exposed to agent executors."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        """Request cooperative cancellation."""
        self._event.set()

    @property
    def cancelled(self) -> bool:
        """Return whether cancellation was requested."""
        return self._event.is_set()

    def throw_if_cancelled(self) -> None:
        """Raise when cancellation has been requested."""
        if self.cancelled:
            raise TimeoutError("agent execution cancelled")


class AgentRuntime:
    """Single safety boundary for bounded agent execution."""

    def __init__(
        self,
        policy_engine: AgentPolicyEngine,
        lease_registry: CapabilityLeaseRegistry,
        trust_engine: TrustEngine,
        *,
        signing_private_key: bytes,
        signing_public_key: bytes,
        max_workers: int = 8,
    ) -> None:
        if not callable(getattr(policy_engine, "authorize_tool", None)):
            raise ValueError("policy_engine is required")
        if len(signing_private_key) != 32 or len(signing_public_key) != 32:
            raise ValueError("Ed25519 signing keys must be 32 bytes")
        self.policy_engine = policy_engine
        self.leases = lease_registry
        self.trust = trust_engine
        self._private_key = bytes(signing_private_key)
        self._public_key = bytes(signing_public_key)
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=max(1, min(int(max_workers), 64)), thread_name_prefix="jarvis-agent")
        self._lock = threading.RLock()
        self._cancel: dict[str, AgentCancellation] = {}
        self._closed = False

    def issue_authorization(self, request: AgentRequest, *, ttl_seconds: float = 300.0, uses: int = 1) -> tuple[CapabilityLease, SignedA2ATaskEnvelope]:
        """Issue a bounded lease and Ed25519-signed request envelope."""
        self._ensure_open()
        lease = self.leases.issue(request.principal, request.capability, request.resource, ttl_seconds=ttl_seconds, uses=uses)
        payload = self._payload(request, lease.lease_id)
        envelope = A2ATaskSigner.sign(self._private_key, issuer=request.principal, audience=request.agent_name, task_id=request.request_id, payload=payload, ttl_seconds=ttl_seconds)
        return lease, envelope

    def verify_authorization(self, request: AgentRequest, lease: CapabilityLease, envelope: SignedA2ATaskEnvelope) -> bool:
        """Verify the signed authorization envelope and binding fields."""
        return bool(A2ATaskSigner.verify(self._public_key, envelope, audience=request.agent_name, payload=self._payload(request, lease.lease_id)) and envelope.issuer == request.principal and envelope.task_id == request.request_id)

    def execute(
        self,
        request: AgentRequest,
        *,
        lease: CapabilityLease,
        envelope: SignedA2ATaskEnvelope,
        executor: Callable[[str, dict[str, Any]], Any],
        budget: AgentBudget | None = None,
        approved: bool = False,
    ) -> AgentReceipt:
        """Authorize and run one bounded agent operation."""
        self._ensure_open()
        budget = budget or AgentBudget()
        budget.validate()
        started = time.perf_counter()
        output = ""
        attempts = 0
        cancellation = AgentCancellation()
        with self._lock:
            self._cancel[request.request_id] = cancellation
        try:
            if not self.verify_authorization(request, lease, envelope):
                return self._receipt(request, False, TrustDecision.DENY.value, output, started, attempts, "invalid_authorization", None)
            policy_decision = self.policy_engine.authorize_tool(
                request.agent_name,
                request.capability,
                required_capabilities=request.required_capabilities,
                network_required=request.requires_network,
            )
            if not policy_decision.allowed:
                return self._receipt(request, False, TrustDecision.DENY.value, output, started, attempts, policy_decision.reason, lease.lease_id)
            trust_request = TrustRequest(
                principal=request.principal,
                capability=request.capability,
                risk_score=0.9 if request.destructive else 0.7 if request.requires_network else 0.2,
                external_content=request.external_content,
                destructive=request.destructive,
                authenticated=True,
                approved=bool(approved),
                sandbox_available=True,
                metadata={"agent": request.agent_name, "resource": request.resource},
            )
            trust = self.trust.evaluate(trust_request, allowed_capabilities=policy_engine_capabilities(self.policy_engine, request.agent_name))
            if trust.decision is TrustDecision.SANDBOX:
                return self._receipt(request, False, trust.decision.value, output, started, attempts, "isolated sandbox execution is required but not provided", lease.lease_id)
            if trust.decision in {TrustDecision.DENY, TrustDecision.REQUIRE_APPROVAL} and not approved:
                reason = ";".join(trust.reasons) if trust.reasons else "trust policy denied request"
                return self._receipt(request, False, trust.decision.value, output, started, attempts, reason, lease.lease_id)
            self.leases.consume(lease.lease_id, principal=request.principal, capability=request.capability, resource=request.resource)
            for attempts in range(1, int(budget.max_retries) + 2):
                cancellation.throw_if_cancelled()
                context = {
                    "request_id": request.request_id,
                    "agent_name": request.agent_name,
                    "principal": request.principal,
                    "capability": request.capability,
                    "resource": request.resource,
                    "mission_id": request.mission_id,
                    "cancel_token": cancellation,
                    "deadline_monotonic": time.monotonic() + float(budget.timeout_seconds),
                    "approved": bool(approved),
                }
                future = self._executor.submit(executor, request.description, context)
                try:
                    raw = future.result(timeout=float(budget.timeout_seconds))
                    output = self._bounded_text(raw, budget.max_output_bytes)
                    if not output.strip():
                        raise ValueError("agent returned empty output")
                    return self._receipt(request, True, trust.decision.value, output, started, attempts, None, lease.lease_id)
                except concurrent.futures.TimeoutError:
                    cancellation.cancel()
                    if attempts > int(budget.max_retries):
                        return self._receipt(request, False, TrustDecision.DENY.value, output, started, attempts, "agent timeout", lease.lease_id)
                except Exception as exc:
                    if attempts > int(budget.max_retries):
                        return self._receipt(request, False, TrustDecision.DENY.value, output, started, attempts, f"{type(exc).__name__}: {exc}", lease.lease_id)
                    time.sleep(min(0.25 * (2 ** (attempts - 1)), 2.0))
            return self._receipt(request, False, TrustDecision.DENY.value, output, started, attempts, "retry budget exhausted", lease.lease_id)
        finally:
            with self._lock:
                self._cancel.pop(request.request_id, None)

    def cancel(self, request_id: str) -> bool:
        """Request cooperative cancellation of an active request."""
        with self._lock:
            token = self._cancel.get(str(request_id))
            if token is None:
                return False
            token.cancel()
            return True

    def close(self) -> None:
        """Stop accepting new work and shut down workers."""
        with self._lock:
            self._closed = True
            for token in self._cancel.values():
                token.cancel()
            self._cancel.clear()
        self._executor.shutdown(wait=True, cancel_futures=True)

    def _ensure_open(self) -> None:
        with self._lock:
            if self._closed:
                raise RuntimeError("agent runtime closed")

    @staticmethod
    def _payload(request: AgentRequest, lease_id: str) -> dict[str, Any]:
        return {
            "request_id": request.request_id,
            "agent_name": request.agent_name,
            "principal": request.principal,
            "capability": request.capability,
            "resource": request.resource,
            "mission_id": request.mission_id,
            "lease_id": lease_id,
            "description_sha256": hashlib.sha256(request.description.encode("utf-8")).hexdigest(),
        }

    @staticmethod
    def _bounded_text(value: Any, limit: int) -> str:
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))
        if len(text.encode("utf-8")) > int(limit):
            raise ValueError("agent output exceeds configured limit")
        return text

    @staticmethod
    def _receipt(request: AgentRequest, ok: bool, decision: str, output: str, started: float, attempts: int, error: str | None, lease_id: str | None) -> AgentReceipt:
        output_bytes = len(output.encode("utf-8"))
        digest = hashlib.sha256(output.encode("utf-8")).hexdigest()
        signature_material = f"{request.request_id}|{request.agent_name}|{ok}|{decision}|{digest}|{output_bytes}|{attempts}".encode("utf-8")
        # HMAC here only makes the receipt self-consistent within the runtime; the signed request is the authorization primitive.
        signature = hmac.new(digest.encode("ascii"), signature_material, hashlib.sha256).hexdigest()
        return AgentReceipt(request.request_id, request.agent_name, ok, decision, digest, output_bytes, (time.perf_counter() - started) * 1000.0, attempts, error, lease_id, signature)

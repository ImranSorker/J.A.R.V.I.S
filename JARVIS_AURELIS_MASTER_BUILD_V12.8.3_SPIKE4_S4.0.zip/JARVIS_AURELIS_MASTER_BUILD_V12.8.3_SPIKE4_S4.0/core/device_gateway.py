"""Capability-based gateway for physical and digital device integrations."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Protocol

logger = logging.getLogger("jarvis.device_gateway")


@dataclass(frozen=True)
class DeviceSpec:
    """Declarative device contract."""

    device_id: str
    name: str
    device_type: str
    capabilities: tuple[str, ...]
    safety_class: str = "bounded"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DeviceCommand:
    """Validated device operation."""

    device_id: str
    capability: str
    parameters: dict[str, Any] = field(default_factory=dict)
    mission_id: str | None = None
    external: bool = False
    irreversible: bool = False


class DeviceAdapter(Protocol):
    """Protocol implemented by concrete hardware/device adapters."""

    def telemetry(self) -> dict[str, Any]: raise RuntimeError("abstract contract method invoked")
    def execute(self, capability: str, parameters: dict[str, Any]) -> dict[str, Any]: raise RuntimeError("abstract contract method invoked")
    def close(self) -> None: raise RuntimeError("abstract contract method invoked")
class DeviceGateway:
    """Central device registry and authorization boundary."""

    def __init__(self, autonomy_engine: Any | None = None) -> None:
        self.autonomy_engine = autonomy_engine
        self._devices: dict[str, tuple[DeviceSpec, DeviceAdapter]] = {}
        self._lock = threading.RLock()
        self._history: list[dict[str, Any]] = []
        self._max_history = 2000

    def register(self, spec: DeviceSpec, adapter: DeviceAdapter) -> None:
        """Register a real device adapter under an immutable capability contract."""
        if not spec.device_id or not spec.capabilities:
            raise ValueError("device id and capabilities are required")
        if not callable(getattr(adapter, "execute", None)) or not callable(getattr(adapter, "telemetry", None)):
            raise TypeError("adapter does not implement DeviceAdapter")
        with self._lock:
            self._devices[spec.device_id] = (spec, adapter)

    def execute(self, command: DeviceCommand, *, actor: str = "jarvis") -> dict[str, Any]:
        """Authorize and execute a device command."""
        with self._lock:
            pair = self._devices.get(command.device_id)
        if pair is None:
            raise KeyError(f"unknown device: {command.device_id}")
        spec, adapter = pair
        if command.capability not in spec.capabilities:
            raise PermissionError("device capability denied")
        if self.autonomy_engine is not None and command.mission_id:
            self.autonomy_engine.authorize(
                command.mission_id,
                action="high_impact" if command.irreversible else "bounded",
                irreversible=command.irreversible,
                external=command.external,
                required_capabilities=(f"device.{command.capability}",),
                granted_capabilities=(f"device.{command.capability}", "device.*"),
            )
        result = adapter.execute(command.capability, dict(command.parameters))
        if not isinstance(result, dict) or "ok" not in result:
            raise ValueError("device adapter returned invalid result")
        with self._lock:
            self._history.append({
                "timestamp": time.time(),
                "actor": actor,
                "device_id": spec.device_id,
                "capability": command.capability,
                "ok": bool(result.get("ok")),
            })
            del self._history[:-self._max_history]
        return result

    def telemetry(self, device_id: str | None = None) -> dict[str, Any]:
        """Read telemetry without granting command authority."""
        with self._lock:
            devices = list(self._devices.items()) if device_id is None else [(device_id, self._devices.get(device_id))]
        output: dict[str, Any] = {}
        for did, pair in devices:
            if pair is None:
                continue
            try:
                output[did] = pair[1].telemetry()
            except Exception as exc:
                logger.warning("device_telemetry_failed", extra={"device_id": did, "error": str(exc)})
                output[did] = {"ok": False, "error": "telemetry unavailable"}
        return output

    def list_devices(self) -> list[dict[str, Any]]:
        """Return device specifications without leaking adapter internals."""
        with self._lock:
            return [{"device_id": s.device_id, "name": s.name, "device_type": s.device_type, "capabilities": list(s.capabilities), "safety_class": s.safety_class, "metadata": dict(s.metadata)} for s, _ in self._devices.values()]

    def health(self) -> dict[str, Any]:
        """Return gateway health."""
        return {"ok": True, "devices": len(self._devices), "history": len(self._history)}

    def close(self) -> None:
        """Close all adapters."""
        with self._lock:
            adapters = list(self._devices.values())
            self._devices.clear()
        for _, adapter in adapters:
            try:
                adapter.close()
            except Exception:
                logger.debug("device_adapter_close_failed", exc_info=True)



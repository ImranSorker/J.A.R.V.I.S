"""Continual Learning Lab — experiment tracking and dataset management.

Manages training datasets, experiment history, and model evaluation
for continual learning workflows.
"""
from __future__ import annotations

import json
import logging
import time
import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jarvis.continual_learning")


@dataclass
class Experiment:
    """One learning experiment."""
    name: str
    dataset_path: Optional[str] = None
    model_path: Optional[str] = None
    status: str = "pending"
    metrics: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "dataset_path": self.dataset_path,
            "model_path": self.model_path,
            "status": self.status,
            "metrics": self.metrics,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "error": self.error,
        }


class ContinualLearningLab:
    """Manage learning experiments and datasets."""

    def __init__(self, output_dir: str = "data/experiments") -> None:
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._experiments: List[Experiment] = []
        self._datasets: Dict[str, Path] = {}
        self._load_existing()

    def _load_existing(self) -> None:
        """Load existing experiments from disk."""
        index = self._output_dir / "experiments.json"
        if index.exists():
            try:
                with open(index) as f:
                    data = json.load(f)
                for item in data:
                    exp = Experiment(
                        name=item["name"],
                        dataset_path=item.get("dataset_path"),
                        model_path=item.get("model_path"),
                        status=item.get("status", "pending"),
                        metrics=item.get("metrics", {}),
                        created_at=item.get("created_at", time.time()),
                        completed_at=item.get("completed_at"),
                        error=item.get("error"),
                    )
                    self._experiments.append(exp)
            except Exception as exc:
                logger.warning("failed_to_load_experiments", extra={"error": str(exc)})

    def _save(self) -> None:
        """Persist experiments to disk."""
        index = self._output_dir / "experiments.json"
        try:
            with open(index, "w") as f:
                json.dump([exp.to_dict() for exp in self._experiments], f, indent=2, default=str)
        except Exception as exc:
            logger.warning("failed_to_save_experiments", extra={"error": str(exc)})

    def create_experiment(self, name: str, dataset_path: Optional[str] = None) -> Experiment:
        """Create a new experiment."""
        exp = Experiment(name=name, dataset_path=dataset_path)
        self._experiments.append(exp)
        self._save()
        logger.info("experiment_created", extra={"component_name": name})
        return exp

    def run_experiment(self, name: str, model_path: Optional[str] = None, *, trainer: Any = None, evaluator: Any = None, promotion_threshold: float = 0.0) -> Dict[str, Any]:
        """Run a real, evidence-producing continual-learning experiment.

        A successful result requires a readable dataset plus an injected trainer
        (or a concrete external training backend). Merely having libraries
        installed is never treated as training completion.
        """
        exp = next((e for e in self._experiments if e.name == name), None)
        if exp is None:
            return {"ok": False, "error": f"Experiment {name} not found"}
        if not exp.dataset_path or not Path(exp.dataset_path).is_file():
            exp.status = "failed"; exp.error = "dataset is required and must exist"; self._save()
            return {"ok": False, "error": exp.error, "experiment": name}
        exp.status = "running"; exp.model_path = model_path; exp.error = None; self._save()
        try:
            rows = []
            with open(exp.dataset_path, encoding="utf-8") as handle:
                for line in handle:
                    if line.strip(): rows.append(json.loads(line))
            if not rows:
                raise ValueError("dataset contains no examples")
            baseline = evaluator(rows, model_path) if callable(evaluator) and model_path else {"score": 0.0, "evaluated": False}
            if not callable(trainer):
                raise RuntimeError("no training backend is configured; refusing false-success completion")
            training = trainer(rows, model_path)
            checkpoint = training.get("checkpoint") if isinstance(training, dict) else None
            if not checkpoint or not Path(str(checkpoint)).is_file():
                raise RuntimeError("trainer did not produce a verifiable checkpoint")
            post = evaluator(rows, str(checkpoint)) if callable(evaluator) else {"score": 0.0, "evaluated": False}
            baseline_score = float(baseline.get("score", 0.0)) if isinstance(baseline, dict) else 0.0
            post_score = float(post.get("score", 0.0)) if isinstance(post, dict) else 0.0
            regression = post_score - baseline_score
            promoted = post_score >= baseline_score + float(promotion_threshold)
            checkpoint_hash = hashlib.sha256(Path(str(checkpoint)).read_bytes()).hexdigest()
            provenance = {
                "dataset_path": str(exp.dataset_path),
                "dataset_sha256": hashlib.sha256(Path(str(exp.dataset_path)).read_bytes()).hexdigest(),
                "baseline_model": str(model_path) if model_path else None,
                "checkpoint": str(checkpoint),
                "checkpoint_sha256": checkpoint_hash,
                "trainer": training.get("trainer") if isinstance(training, dict) else None,
                "created_at": time.time(),
            }
            exp.status = "completed" if promoted else "evaluated_not_promoted"
            exp.completed_at = time.time()
            exp.metrics = {"baseline": baseline, "training": training, "post": post, "promoted": promoted, "regression": regression, "provenance": provenance, "rollback_available": bool(model_path)}
            rollback_verified = True
            if not promoted and model_path:
                rollback_verified = Path(str(model_path)).is_file()
            exp.metrics["rollback_verified"] = rollback_verified
            if not promoted and model_path and not rollback_verified:
                exp.status = "failed"
                exp.error = "regressed model rejected but rollback target is unavailable"
                self._save()
                return {"ok": False, "experiment": name, "error": exp.error, "metrics": exp.metrics}
            self._save()
            return {"ok": True, "experiment": name, "metrics": exp.metrics}
        except Exception as exc:
            exp.status = "failed"; exp.error = str(exc); self._save()
            return {"ok": False, "error": str(exc), "experiment": name}

    def list_experiments(self) -> List[Dict[str, Any]]:
        return [exp.to_dict() for exp in self._experiments]

    def get_experiment(self, name: str) -> Optional[Dict[str, Any]]:
        exp = next((e for e in self._experiments if e.name == name), None)
        return exp.to_dict() if exp else None

    def get_stats(self) -> Dict[str, Any]:
        return {
            "experiments": len(self._experiments),
            "by_status": {
                "pending": sum(1 for e in self._experiments if e.status == "pending"),
                "running": sum(1 for e in self._experiments if e.status == "running"),
                "completed": sum(1 for e in self._experiments if e.status == "completed"),
                "failed": sum(1 for e in self._experiments if e.status == "failed"),
            },
        }



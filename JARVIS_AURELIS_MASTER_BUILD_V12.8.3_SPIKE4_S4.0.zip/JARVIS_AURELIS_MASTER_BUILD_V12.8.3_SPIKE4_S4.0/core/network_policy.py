"""SSRF-safe outbound HTTP policy with exact host rules and redirect revalidation."""
from __future__ import annotations
import ipaddress, logging, socket
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
logger=logging.getLogger("jarvis.network_policy")
class NetworkPolicyError(Exception):
    """Raised when an outbound network operation violates policy."""
@dataclass(frozen=True)
class NetworkPolicy:
    allow_private:bool=False; allow_localhost:bool=False; allow_metadata_endpoints:bool=False; max_response_size_bytes:int=10_000_000
    request_timeout_seconds:float=30.0; max_redirects:int=5; allowed_schemes:Tuple[str,...]=( "http","https")
    blocked_hosts:Tuple[str,...]=(); allowed_hosts:Tuple[str,...]=(); user_agent:str="JARVIS/12.8.0"
    @staticmethod
    def _host_matches(hostname:str,rule:str)->bool:
        host=hostname.rstrip(".").lower(); candidate=rule.strip().rstrip(".").lower()
        if not candidate:return False
        try:
            return ipaddress.ip_address(host)==ipaddress.ip_address(candidate)
        except ValueError:
            return host==candidate or host.endswith("."+candidate)
    def allows_host(self,hostname:str)->bool:
        if any(self._host_matches(hostname,x) for x in self.blocked_hosts):return False
        # Empty allowlists are fail-closed. Callers must name permitted hosts explicitly.
        return bool(self.allowed_hosts) and any(self._host_matches(hostname,x) for x in self.allowed_hosts)
class SSRFValidator:
    PRIVATE_NETWORKS: ClassVar[List[ipaddress.IPv4Network]]=[ipaddress.ip_network(x) for x in ("10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","127.0.0.0/8","169.254.0.0/16","0.0.0.0/8","::1/128","fc00::/7","fe80::/10")]
    METADATA_ENDPOINTS: ClassVar[set[str]]={"169.254.169.254","metadata.google.internal","metadata.aws.internal","169.254.170.2"}
    @classmethod
    def is_private_ip(cls,ip_str:str)->bool:
        try:
            ip = ipaddress.ip_address(ip_str)
            if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
                mapped = ip.ipv4_mapped
                return any(mapped in network for network in cls.PRIVATE_NETWORKS if isinstance(network, ipaddress.IPv4Network))
            return any(ip in n for n in cls.PRIVATE_NETWORKS)
        except ValueError:
            return False
    @classmethod
    def is_metadata_endpoint(cls,hostname:str)->bool:
        host=hostname.rstrip(".").lower(); return any(cls._host(host,e) for e in cls.METADATA_ENDPOINTS)
    @staticmethod
    def _host(host:str,rule:str)->bool:
        return host==rule or host.endswith("."+rule)
    @classmethod
    def validate_url(cls,url:str,policy:NetworkPolicy)->Dict[str,Any]:
        if not url or len(url)>4096:return {"ok":False,"error":"URL empty or too long"}
        try:p=urlparse(url)
        except Exception as exc:return {"ok":False,"error":f"Invalid URL: {exc}"}
        if p.scheme.lower() not in policy.allowed_schemes:return {"ok":False,"error":f"Scheme '{p.scheme}' not allowed"}
        host=p.hostname
        if not host:return {"ok":False,"error":"URL has no hostname"}
        try:port=p.port
        except ValueError:return {"ok":False,"error":"invalid port"}
        if port is not None and not 1<=port<=65535:return {"ok":False,"error":"invalid port"}
        if not policy.allows_host(host):return {"ok":False,"error":"Host blocked by policy"}
        if cls.is_metadata_endpoint(host) and not policy.allow_metadata_endpoints:return {"ok":False,"error":"Cloud metadata endpoints are blocked"}
        if host.lower() in {"localhost","127.0.0.1","::1"} and not policy.allow_localhost:return {"ok":False,"error":"Localhost requests are blocked"}
        try:
            resolved=socket.getaddrinfo(host,port or (443 if p.scheme=="https" else 80),type=socket.SOCK_STREAM)
            addresses=[]
            for _,_,_,_,sockaddr in resolved:
                ip=sockaddr[0]; addresses.append(ip)
                if cls.is_private_ip(ip) and not policy.allow_private:return {"ok":False,"error":f"Resolved IP {ip} is in private range"}
                if cls.is_metadata_endpoint(ip) and not policy.allow_metadata_endpoints:return {"ok":False,"error":"Resolved IP is a metadata endpoint"}
        except socket.gaierror:return {"ok":False,"error":"Could not resolve hostname"}
        except Exception as exc:return {"ok":False,"error":f"DNS validation failed: {exc}"}
        return {"ok":True,"hostname":host,"scheme":p.scheme.lower(),"addresses":addresses}
    @classmethod
    def validate_redirect(cls,original_url:str,location:str,policy:NetworkPolicy)->Dict[str,Any]:
        target=urljoin(original_url,location); result=cls.validate_url(target,policy); result["url"]=target; return result
class SafeHTTPClient:
    """Bounded HTTP client that never lets a redirect bypass SSRF checks."""
    def __init__(self,policy:Optional[NetworkPolicy]=None, validator:Optional[SSRFValidator]=None)->None:
        self._policy=policy or NetworkPolicy()
        self._validator=validator or SSRFValidator()
    def request(self,method:str,url:str,headers:Optional[Dict[str,str]]=None,body:Optional[Any]=None,timeout:Optional[float]=None)->Dict[str,Any]:
        try:import requests
        except ImportError:return {"ok":False,"error":"requests library not installed"}
        current=url; timeout_value=timeout or self._policy.request_timeout_seconds
        for idx in range(self._policy.max_redirects+1):
            validation=self._validator.validate_url(current,self._policy)
            if not validation["ok"]:return {"ok":False,"error":validation["error"]}
            try:
                hdr=dict(headers or {}); hdr.setdefault("User-Agent",self._policy.user_agent)
                response=requests.request(method.upper(),current,headers=hdr,data=body,timeout=timeout_value,allow_redirects=False,stream=True)
                if response.is_redirect or response.is_permanent_redirect:
                    loc=response.headers.get("Location"); response.close()
                    if not loc:return {"ok":False,"error":"redirect response without Location"}
                    if idx>=self._policy.max_redirects:return {"ok":False,"error":"maximum redirect count exceeded"}
                    next_result=self._validator.validate_redirect(current,loc,self._policy)
                    if not next_result["ok"]:return {"ok":False,"error":next_result["error"]}
                    current=next_result["url"]; continue
                try:
                    data=bytearray(); max_size=self._policy.max_response_size_bytes
                    for chunk in response.iter_content(8192):
                        if chunk:
                            data.extend(chunk)
                            if len(data)>max_size:
                                bounded = bytes(data[:max_size]).decode("utf-8",errors="replace")
                                return {"ok":True,"status_code":response.status_code,"headers":dict(response.headers),"content":bounded,"body":bounded.encode("utf-8"),"url":response.url,"truncated":True}
                    content=bytes(data).decode("utf-8",errors="replace")
                    return {"ok":True,"status_code":response.status_code,"headers":dict(response.headers),"content":content,"body":bytes(data),"url":response.url,"truncated":False}
                finally:
                    response.close()
            except requests.Timeout:return {"ok":False,"error":f"Request timed out after {timeout_value}s"}
            except requests.RequestException as exc:return {"ok":False,"error":f"Request failed: {exc}"}
        return {"ok":False,"error":"maximum redirect count exceeded"}
    def get(self,url:str,headers:Optional[Dict[str,str]]=None)->Dict[str,Any]:return self.request("GET",url,headers=headers)
    def post(self,url:str,headers:Optional[Dict[str,str]]=None,body:Optional[Any]=None)->Dict[str,Any]:return self.request("POST",url,headers=headers,body=body)



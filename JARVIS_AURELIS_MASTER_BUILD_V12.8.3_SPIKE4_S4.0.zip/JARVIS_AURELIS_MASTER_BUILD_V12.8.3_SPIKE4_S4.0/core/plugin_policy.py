"""Fail-closed plugin capability policy for JARVIS.

An omitted allow-list means no policy is configured and therefore denies all
capabilities. An explicit wildcard must be used for an intentionally broad
policy, and production callers should prefer enumerated capabilities.
"""
from __future__ import annotations

from collections.abc import Iterable
import fnmatch


class PluginPolicy:
    """Evaluate plugin capabilities using explicit default-deny semantics."""

    def __init__(self, allowed_capabilities: Iterable[str] | None = None, *, allow_all: bool = False) -> None:
        if allow_all and allowed_capabilities is not None:
            raise ValueError("allow_all and allowed_capabilities are mutually exclusive")
        self._configured = allowed_capabilities is not None or allow_all
        self.allowed = frozenset(str(item).strip() for item in (allowed_capabilities or ()) if str(item).strip())
        self.allow_all = bool(allow_all)

    @property
    def configured(self) -> bool:
        """Return whether an explicit policy has been configured."""
        return self._configured

    def check(self, capabilities: Iterable[str]) -> bool:
        """Return True only when every requested capability is explicitly allowed."""
        requested = tuple(str(cap).strip() for cap in capabilities)
        if any(not cap for cap in requested):
            return False
        if not requested:
            return True
        if not self._configured:
            return False
        if self.allow_all:
            return True
        return all(any(fnmatch.fnmatchcase(cap, pattern) for pattern in self.allowed) for cap in requested)

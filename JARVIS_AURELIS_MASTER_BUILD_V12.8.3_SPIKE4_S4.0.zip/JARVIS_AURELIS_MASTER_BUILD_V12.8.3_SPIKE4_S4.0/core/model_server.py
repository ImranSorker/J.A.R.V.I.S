"""Persistent local model admission, queueing, residency and hot-swap coordination."""
from __future__ import annotations

import threading
import time
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class ModelLease:
    """VRAM admission lease for an active model."""

    model: str
    vram_gb: float
    acquired_at: float
    active_requests: int = 0


class ModelServer:
    """Serialize model activation against a VRAM budget with bounded residency."""

    def __init__(self, max_vram_gb: float, *, max_models: int = 16) -> None:
        self.max_vram_gb = max(0.0, float(max_vram_gb))
        self.max_models = max(1, min(int(max_models), 128))
        self._loaded: dict[str, ModelLease] = {}
        self._last_used: dict[str, float] = {}
        self._lock = threading.RLock()

    def admit(self, model: str, vram_gb: float) -> ModelLease:
        """Admit or retain a model subject to the configured VRAM budget."""
        name = str(model).strip()
        need = max(0.0, float(vram_gb))
        if not name or need > self.max_vram_gb:
            raise MemoryError("VRAM admission denied")
        with self._lock:
            existing = self._loaded.get(name)
            if existing:
                self._last_used[name] = time.time()
                return existing
            self._evict_to_capacity()
            if len(self._loaded) >= self.max_models:
                raise MemoryError("model residency capacity denied")
            self._evict_until_fit(need)
            used = sum(lease.vram_gb for lease in self._loaded.values())
            if used + need > self.max_vram_gb:
                raise MemoryError("VRAM admission denied")
            lease = ModelLease(name, need, time.time(), 0)
            self._loaded[name] = lease
            self._last_used[name] = time.time()
            return lease

    def acquire(self, model: str) -> ModelLease | None:
        """Increment active-request count for a resident model."""
        with self._lock:
            lease = self._loaded.get(str(model))
            if lease is None:
                return None
            current = ModelLease(lease.model, lease.vram_gb, lease.acquired_at, lease.active_requests + 1)
            self._loaded[lease.model] = current
            self._last_used[lease.model] = time.time()
            return current

    def release_request(self, model: str) -> ModelLease | None:
        """Decrement active-request count without unloading the model."""
        with self._lock:
            lease = self._loaded.get(str(model))
            if lease is None:
                return None
            current = ModelLease(lease.model, lease.vram_gb, lease.acquired_at, max(0, lease.active_requests - 1))
            self._loaded[lease.model] = current
            self._last_used[lease.model] = time.time()
            return current

    def evict(self, model: str) -> bool:
        """Evict a model only when it has no active requests."""
        with self._lock:
            lease = self._loaded.get(str(model))
            if lease is None or lease.active_requests:
                return False
            self._loaded.pop(str(model), None)
            self._last_used.pop(str(model), None)
            return True

    def hot_swap(self, old_model: str, new_model: str, new_vram_gb: float) -> ModelLease:
        """Atomically evict an idle model and admit its replacement."""
        with self._lock:
            old = self._loaded.get(str(old_model))
            if old is not None and old.active_requests:
                raise RuntimeError("cannot hot-swap an active model")
            if old is not None:
                self.evict(str(old_model))
            try:
                return self.admit(new_model, new_vram_gb)
            except Exception:
                if old is not None:
                    self.admit(old.model, old.vram_gb)
                raise

    def _evict_to_capacity(self) -> None:
        """Evict least-recently-used idle models until residency capacity is available."""
        while len(self._loaded) >= self.max_models:
            candidates = [lease for lease in self._loaded.values() if lease.active_requests == 0]
            if not candidates:
                return
            victim = min(candidates, key=lambda lease: (self._last_used.get(lease.model, lease.acquired_at), lease.model))
            self.evict(victim.model)

    def _evict_until_fit(self, required: float) -> None:
        while sum(lease.vram_gb for lease in self._loaded.values()) + required > self.max_vram_gb and self._loaded:
            candidates = [lease for lease in self._loaded.values() if lease.active_requests == 0]
            if not candidates:
                return
            victim = min(candidates, key=lambda lease: (self._last_used.get(lease.model, lease.acquired_at), lease.model))
            self.evict(victim.model)

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret model residency state."""
        with self._lock:
            used = sum(lease.vram_gb for lease in self._loaded.values())
            return {"max_vram_gb": self.max_vram_gb, "used_vram_gb": used, "free_vram_gb": max(0.0, self.max_vram_gb - used), "loaded": [asdict(lease) for lease in self._loaded.values()]}



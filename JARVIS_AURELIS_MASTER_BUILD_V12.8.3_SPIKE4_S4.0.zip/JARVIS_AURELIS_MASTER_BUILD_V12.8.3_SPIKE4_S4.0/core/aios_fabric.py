"""AI-native operating-layer composition root for Phases D and E."""
from __future__ import annotations

import logging
import os
from typing import Any, Callable, Mapping

from core.compute_fabric import ComputeFabric
from core.contracts.event import Event
from core.contracts.platform import SkillManifest
from core.node_protocol import NodeProtocol
from core.optimization_fabric import BenchmarkRegistry, ContinuousEvaluation, PerformanceRegressionEngine, PredictiveModelLoader, ResourceAwareRouter
from core.os_adapters import adapter_for_current_host
from core.portable_state import PortableStateManager
from core.self_knowledge_graph import SelfKnowledgeGraph
from core.skill_marketplace import SkillMarketplace

logger = logging.getLogger("jarvis.aios_fabric")


class AIOSFabric:
    """Own all platform-layer state behind replaceable, UI-independent services."""

    def __init__(self, *, state_path: str, knowledge_path: str, node_secret: bytes | None = None, skill_secret: bytes | None = None, state_secret: bytes | None = None, event_sink: Callable[[Event], Any] | None = None) -> None:
        self.events = event_sink
        self.os = adapter_for_current_host()
        self.compute = ComputeFabric()
        self.nodes = NodeProtocol(node_secret or os.urandom(32))
        self.state = PortableStateManager(state_secret)
        self.skills = SkillMarketplace(skill_secret or os.urandom(32), allowed_permissions=("memory.read", "network.read", "tool.invoke", "compute.use"))
        self.knowledge = SelfKnowledgeGraph(knowledge_path)
        self.benchmarks = BenchmarkRegistry()
        self.predictor = PredictiveModelLoader()
        self.router = ResourceAwareRouter()
        self.regressions = PerformanceRegressionEngine()
        self.evaluation = ContinuousEvaluation()
        self._enabled = True
        self._state_path = state_path
        self.knowledge.add_node("aios", kind="platform", version="12.8.0")
        self.knowledge.add_node("host", **self.os.snapshot().__dict__)
        self.knowledge.add_edge("aios", "runs_on", "host")

    @property
    def enabled(self) -> bool:
        """Return whether the platform layer is enabled."""
        return self._enabled

    def disable(self) -> None:
        """Cleanly disable optional platform-layer actions."""
        self._enabled = False
        self._emit("aios.disabled", {})

    def enable(self) -> None:
        """Re-enable the platform layer."""
        self._enabled = True
        self._emit("aios.enabled", {})

    def register_state_domain(self, name: str, exporter: Callable[[], Mapping[str, Any]], importer: Callable[[Mapping[str, Any]], None]) -> None:
        """Attach a persistent state domain."""
        self.state.register(name, exporter, importer)

    def install_skill(self, manifest: SkillManifest) -> None:
        """Install a signed skill manifest when the layer is enabled."""
        self._require_enabled()
        self.skills.install(manifest)
        self.knowledge.add_node(f"skill:{manifest.name}", version=manifest.version, capabilities=list(manifest.capabilities))
        self._emit("skill.installed", {"name": manifest.name, "version": manifest.version})

    def export_state(self) -> str:
        """Persist all registered domains and emit a state event."""
        self._require_enabled()
        path = str(self.state.export_to(self._state_path))
        self._emit("state.exported", {"path": path})
        return path

    def import_state(self, path: str | None = None) -> None:
        """Import a previously exported portable state package."""
        self._require_enabled()
        source = path or self._state_path
        self.state.import_file(source)
        self._emit("state.imported", {"path": str(source)})

    def snapshot(self) -> dict[str, Any]:
        """Return the observable AIOS/E state surface."""
        return {"enabled": self._enabled, "platform": self.os.snapshot().__dict__, "compute": self.compute.snapshot(), "skills": [manifest.__dict__.copy() for manifest in self.skills.list()], "knowledge": self.knowledge.snapshot(), "benchmarks": len(self.benchmarks.snapshot())}

    def _require_enabled(self) -> None:
        if not self._enabled:
            raise RuntimeError("AIOS fabric is disabled")

    def _emit(self, event_type: str, payload: Mapping[str, Any]) -> None:
        if self.events:
            try:
                self.events(Event.new(event_type, "aios_fabric", dict(payload)))
            except Exception:
                logger.exception("aios_event_emit_failed")



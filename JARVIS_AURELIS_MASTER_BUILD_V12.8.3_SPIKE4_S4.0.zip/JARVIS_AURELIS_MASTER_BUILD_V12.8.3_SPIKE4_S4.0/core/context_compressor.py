"""Deterministic context-window compression for long-running local sessions."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping


@dataclass(frozen=True, slots=True)
class CompressedContext:
    """Bounded context result with accounting metadata."""

    text: str
    original_items: int
    retained_items: int
    omitted_items: int
    estimated_tokens: int


class ContextCompressor:
    """Compress conversation context without invoking an external model."""

    def __init__(self, max_chars: int = 24_000, max_items: int = 24) -> None:
        self.max_chars = max(2_000, min(int(max_chars), 2_000_000))
        self.max_items = max(4, min(int(max_items), 10_000))

    def compress(self, history: Iterable[Mapping[str, object]]) -> CompressedContext:
        """Retain recent dialogue while preserving deterministic boundaries."""
        items = list(history)
        selected = items[-self.max_items :]
        lines: list[str] = []
        for item in selected:
            role = str(item.get("role", "unknown"))[:64]
            content = str(item.get("content", ""))
            lines.append(f"{role}: {content}")
        text = "\n".join(lines)
        if len(text) > self.max_chars:
            prefix = "[earlier context compressed locally]\n"
            text = prefix + text[-(self.max_chars - len(prefix)) :]
        retained = min(len(selected), self.max_items)
        return CompressedContext(text, len(items), retained, max(0, len(items) - retained), max(1, (len(text.encode("utf-8")) + 3) // 4))



"""Machine-readable feature and architecture coverage registry.

The registry is intentionally declarative: it does not infer support from a
README claim.  Each capability names the production module(s) and regression
test family that prove its presence.  This makes release audits repeatable and
lets the self-knowledge graph expose the actual capability surface.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class FeatureRecord:
    """One auditable capability with source and regression evidence."""

    key: str
    title: str
    modules: tuple[str, ...]
    tests: tuple[str, ...]
    milestone: str
    critical: bool = True


@dataclass(frozen=True, slots=True)
class FeatureAudit:
    """Immutable result of a feature coverage scan."""

    total: int
    complete: int
    incomplete: int
    missing_modules: tuple[str, ...]
    missing_tests: tuple[str, ...]
    records: tuple[dict[str, object], ...]

    @property
    def coverage(self) -> float:
        """Return the percentage of records with source and test evidence."""
        return 100.0 if self.total == 0 else (self.complete / self.total) * 100.0


FEATURES: tuple[FeatureRecord, ...] = (
    FeatureRecord("p2_agent_workshop", "P2-C Agent Workshop 2.0 and Evaluation Harness", ("core/agent_workshop.py", "core/schemas/workshop_session_v1.schema.json", "core/schemas/workshop_workflow_v1.schema.json", "core/schemas/workshop_prompt_program_v1.schema.json", "core/schemas/evaluation_profile_v1.schema.json", "core/schemas/evaluation_report_v1.schema.json", "core/schemas/benchmark_v1.schema.json", "core/schemas/promotion_record_v1.schema.json", "core/schemas/comparison_report_v1.schema.json"), ("tests/test_p2_agent_workshop.py",), "p2-c", True),
    FeatureRecord("p2_experience_memory", "P2-H Typed Experience Memory Fabric", ("core/experience_memory.py", "core/schemas/memory_item_v1.schema.json", "core/schemas/memory_episodic_v1.schema.json", "core/schemas/memory_semantic_v1.schema.json", "core/schemas/memory_procedural_v1.schema.json", "core/schemas/memory_working_v1.schema.json", "core/schemas/memory_task_v1.schema.json", "core/schemas/memory_agent_v1.schema.json", "core/schemas/memory_system_v1.schema.json", "core/schemas/memory_world_state_v1.schema.json", "core/schemas/memory_failure_v1.schema.json", "core/schemas/memory_consolidation_v1.schema.json", "core/schemas/memory_contradiction_v1.schema.json", "core/schemas/memory_forget_record_v1.schema.json", "core/schemas/memory_score_config_v1.schema.json"), ("tests/test_p2_experience_memory.py",), "p2-h", True),
    FeatureRecord("p2_agent_factory", "P2-B Reproducible Agent Factory", ("core/agent_factory.py", "core/schemas/idea_spec_v1.schema.json", "core/schemas/build_plan_v1.schema.json", "core/schemas/build_report_v1.schema.json", "core/schemas/test_report_v1.schema.json", "core/schemas/evaluation_report_v1.schema.json", "core/schemas/certification_record_v1.schema.json", "core/schemas/agent_template_v1.schema.json", "core/schemas/agent_package_manifest_v1.schema.json"), ("tests/test_p2_agent_factory.py",), "p2-b", True),
    FeatureRecord("p2_skill_fabric", "P2-F First-Class Signed Skill Fabric", ("core/skill_fabric.py", "core/schemas/skill_v1.schema.json", "core/schemas/skill_composition_v1.schema.json", "core/schemas/skill_test_v1.schema.json", "core/schemas/skill_certification_v1.schema.json"), ("tests/test_p2_skill_fabric.py",), "p2-f", True),
    FeatureRecord("p2_tool_composition", "P2-Q Signed Typed Bounded Tool Composition", ("core/tool_composition.py", "core/tool_fabric/impl.py", "core/schemas/composite_tool_manifest_v1.schema.json", "core/schemas/composite_step_v1.schema.json", "core/schemas/composite_edge_v1.schema.json", "core/schemas/composition_template_v1.schema.json"), ("tests/test_p2_tool_composition.py",), "p2-q", True),
    FeatureRecord("p2_simulation_universe_2", "P2-K Canonical Simulation Universe 2.0", ("core/simulation_universe/__init__.py", "core/simulation_universe/engine.py", "core/simulation_universe/adapters/plan_adapter.py", "core/simulation_universe/adapters/tool_adapter.py", "core/simulation_universe/adapters/composite_tool_adapter.py", "core/simulation_universe/adapters/agent_adapter.py", "core/simulation_universe/adapters/workflow_adapter.py", "core/simulation_universe/adapters/skill_adapter.py", "core/simulation_universe/adapters/model_route_adapter.py", "core/simulation_universe/adapters/device_action_adapter.py", "core/simulation_universe/adapters/system_change_adapter.py", "core/schemas/simulation_universe_v1.schema.json", "core/schemas/divergence_report_v1.schema.json", "core/schemas/simulation_outcome_v1.schema.json"), ("tests/test_p2_simulation_universe.py",), "p2-k", True),
    FeatureRecord("p2_a2a_verification", "P2-N Agent-to-Agent Verification Security Fabric", ("core/a2a_verification.py", "core/schemas/verification_request_v1.schema.json", "core/schemas/verification_record_v1.schema.json", "core/schemas/verification_check_v1.schema.json", "core/schemas/authority_set_v1.schema.json", "core/schemas/narrowing_report_v1.schema.json", "core/schemas/result_verification_pipeline_v1.schema.json", "core/schemas/trust_boundary_event_v1.schema.json", "core/schemas/collusion_signal_v1.schema.json", "core/schemas/collusion_detector_config_v1.schema.json", "core/schemas/replay_window_v1.schema.json", "core/schemas/independent_verification_spec_v1.schema.json"), ("tests/test_p2_a2a_verification.py",), "p2-n", True),
    FeatureRecord("p2_multi_agent_orchestration", "P2-M Multi-Agent Orchestration Fabric", ("core/multi_agent_orchestration.py", "core/multi_agent_orchestration/templates/supervisor_workers/1.0.0/team.json", "core/multi_agent_orchestration/templates/peer_review_committee/1.0.0/team.json", "core/multi_agent_orchestration/templates/market_auction/1.0.0/team.json", "core/multi_agent_orchestration/templates/README.md", "core/schemas/team_v1.schema.json", "core/schemas/team_member_v1.schema.json", "core/schemas/delegation_contract_v1.schema.json", "core/schemas/agent_message_v1.schema.json", "core/schemas/collaboration_session_v1.schema.json", "core/schemas/review_record_v1.schema.json", "core/schemas/challenge_record_v1.schema.json", "core/schemas/verification_record_v1.schema.json", "core/schemas/escalation_record_v1.schema.json", "core/schemas/economics_escalation_record_v1.schema.json", "core/schemas/knowledge_share_v1.schema.json", "core/schemas/resource_negotiation_v1.schema.json", "core/schemas/consensus_rule_v1.schema.json", "core/schemas/auction_record_v1.schema.json", "core/schemas/team_outcome_v1.schema.json", "core/schemas/knowledge_sharing_policy_v1.schema.json"), ("tests/test_p2_multi_agent_orchestration.py",), "p2-m", True),
    FeatureRecord("p2_autonomous_recovery", "P2-Y Autonomous Recovery Fabric", ("core/autonomous_recovery/__init__.py", "core/autonomous_recovery/strategy_table.json", "core/autonomous_recovery/policies/default/1.0.0/policy.json", "core/schemas/failure_signal_v1.schema.json", "core/schemas/recovery_plan_v1.schema.json", "core/schemas/recovery_step_v1.schema.json", "core/schemas/recovery_execution_v1.schema.json", "core/schemas/recovery_policy_v1.schema.json", "core/schemas/recovery_strategy_table_v1.schema.json", "core/schemas/cascade_record_v1.schema.json", "core/schemas/validation_record_v1.schema.json", "core/schemas/re_admission_record_v1.schema.json", "core/schemas/escalation_record_v1.schema.json", "core/schemas/plan_rollback_ref_v1.schema.json"), ("tests/test_p2_autonomous_recovery.py",), "p2-y", True),
    FeatureRecord("p2_world_model_3", "P2-J Canonical Persistent World Model 3.x", ("core/world_model_3.py", "core/schemas/world_model_entity_v3.schema.json", "core/schemas/world_model_relation_v3.schema.json", "core/schemas/world_model_observation_v3.schema.json", "core/schemas/world_model_transition_v3.schema.json", "core/schemas/world_model_causal_v3.schema.json", "core/schemas/world_model_prediction_v3.schema.json", "core/schemas/world_model_constraint_v3.schema.json", "core/schemas/world_model_snapshot_v3.schema.json"), ("tests/test_p2_world_model_3.py",), "p2-j", True),
    FeatureRecord("advanced_calculation", "Exact Symbolic and Numerical Calculation Engine", ("core/calculation_engine.py", "tools/advanced_calculator.py"), ("tests/test_advanced_calculation.py",), "intelligence", True),
    FeatureRecord("permanent_versioning", "Permanent Capability Epochs", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "platform", True),
    FeatureRecord("self_model", "Authoritative Runtime Self Model", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "intelligence", True),
    FeatureRecord("trajectory_intelligence", "Tamper-Evident Task Trajectory Intelligence", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "observability", True),
    FeatureRecord("sentinel_waiting", "Event-Driven Sentinel Waiting Intelligence", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "autonomy", True),
    FeatureRecord("counterfactual_planning", "Bounded Counterfactual Plan Comparison", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "planning", True),
    FeatureRecord("capability_leases", "Time/Use-Bounded Capability Leases", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "security", True),
    FeatureRecord("action_risk", "Irreversibility-Aware Action Risk Classification", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "security", True),
    FeatureRecord("undo_registry", "Universal Reversible-Action Metadata", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "reliability", True),
    FeatureRecord("data_lineage", "Cognitive Data-Lineage Graph", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "memory", True),
    FeatureRecord("universal_tasks", "Universal Durable Task Center", ("core/universal_task_manager.py", "services/operator_service.py"), ("tests/test_universal_control_plane.py",), "operations", True),
    FeatureRecord("offline_first", "Durable Offline-First Command Fabric", ("core/offline_fabric.py", "services/operator_service.py"), ("tests/test_universal_control_plane.py",), "operations", True),
    FeatureRecord("secure_updates", "Signed Anti-Rollback Release Admission", ("core/secure_update.py", "scripts/sign_release.py", "scripts/build_release.py"), ("tests/test_universal_control_plane.py", "tests/test_secure_update_tooling.py"), "release", True),
    FeatureRecord("dsec_sandbox_fabric", "Unified DSec Autonomous Sandbox SDK and Snapshot Fabric", ("core/dsec_sandbox.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("virtual_agent_fabric", "Scalable Virtual Agent Factory Studio Workshop Garage and Harness", ("core/agent_fabric.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("dynamic_tool_fabric", "Capability-Bounded Dynamic Tool Composition and Garbage Collection", ("core/agent_fabric.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("dsh_plugin_kernel", "Hot-Reloadable Everything-as-Plugin DSH Kernel", ("core/dsh_harness.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("dsh_rsi_loop", "Bounded Reversible Recursive Self-Improvement Harness", ("core/dsh_harness.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("dsec_runtime_integration", "Canonical Supreme Runtime DSec/DSH Integration", ("core/supreme_runtime.py",), ("tests/test_dsec_dsh_agent_fabric.py",), "frontier", True),
    FeatureRecord("precision_performance_fabric", "Precision Governor Fast Path and Privacy-Scoped Context Cache", ("core/performance_fabric.py", "core/supreme_runtime.py"), ("tests/test_dsec_dsh_agent_fabric.py",), "performance", True),
    FeatureRecord("operator_deck", "Flutter Operator Command Palette and Operations Center", ("flutter/lib/deck.dart", "flutter/lib/bridge/jarvis_bridge.dart", "core/desktop_command_gateway.py"), ("tests/test_supreme_release_hardening.py", "tests/test_universal_control_plane.py"), "operator", True),
    FeatureRecord("attention", "Attention and Interrupt Prioritization", ("core/attention_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("goal_engine", "Goal and Objective Graph", ("core/goal_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("experiments", "Hypothesis and Experiment Engine", ("core/experiment_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("provenance", "Tamper-evident Provenance", ("core/provenance_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("transactions", "Transactional Action Boundary", ("core/transaction_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("creation_fabric", "Automatic Tool, Utility and Artifact Factory", ("core/creation_fabric.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("artifact_factory", "Governed Autonomous Artifact Factory", ("core/artifact_factory.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("integration_fabric", "Replaceable Integration Fabric", ("core/integration_fabric.py", "core/mcp_gateway.py", "core/browser_fabric.py"), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("device_fabric", "Distributed Device Capability Fabric", ("core/device_fabric.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("signed_skills", "Cryptographically Verified Skills", ("core/skill_engine.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("state_timeline", "Bounded State Time Machine", ("core/state_timeline.py",), ("tests/test_state_of_art_fabric.py",), "next"),
    FeatureRecord("cognitive_episode", "Cognitive Episode Kernel", ("core/cognitive_episode.py", "core/cognitive_fabric.py"), ("tests/test_cognitive_fabric.py",), "1"),
    FeatureRecord("memory_v2", "Typed Memory 2.0", ("core/memory_v2.py", "core/memory_lifecycle.py"), ("tests/test_cognitive_fabric.py",), "2"),
    FeatureRecord("policy_gateway", "Policy and Authorization Gateway", ("core/policy_gateway.py", "core/permission_engine.py"), ("tests/test_cognitive_fabric.py", "tests/test_adversarial_security.py"), "3"),
    FeatureRecord("execution_isolation", "Brokered Execution and Sandbox", ("core/execution_broker.py", "security/os_sandbox.py"), ("tests/test_kernel_edge_paths.py", "tests/test_adversarial_security.py"), "3"),
    FeatureRecord("planning", "Hierarchical Planning", ("core/planning_v2.py", "core/long_horizon_planner.py"), ("tests/test_cognitive_fabric.py",), "4"),
    FeatureRecord("replay", "Evaluation and Cognitive Replay", ("core/replay_engine.py", "core/evaluation_engine.py"), ("tests/test_cognitive_fabric.py",), "5"),
    FeatureRecord("self_knowledge", "Self-Knowledge Graph", ("core/self_knowledge_graph.py",), ("tests/test_aios_fabric.py",), "6"),
    FeatureRecord("compute_fabric", "Resource-Aware Compute Fabric", ("core/compute_fabric.py", "core/node_protocol.py"), ("tests/test_replaceability_and_platform.py",), "7"),
    FeatureRecord("portable_state", "Authenticated Portable State", ("core/portable_state.py",), ("tests/test_aios_fabric.py",), "8"),
    FeatureRecord("skill_ecosystem", "Signed Skill Ecosystem", ("core/skill_marketplace.py", "core/plugin_isolation.py"), ("tests/test_aios_fabric.py",), "9"),
    FeatureRecord("aios", "AIOS Platform Convergence", ("core/aios_fabric.py", "core/os_adapters.py"), ("tests/test_aios_fabric.py",), "10"),
    FeatureRecord("deep_learning", "Neural Learning Stack", ("core/deep_learning.py", "core/dl_features.py"), ("tests/test_hub_and_dl.py",), "intelligence"),
    FeatureRecord("model_routing", "Adaptive Model Routing", ("core/model_router.py", "core/model_intelligence.py", "core/model_swarm.py"), ("tests/core/test_models.py",), "intelligence"),
    FeatureRecord("rag_trust", "Hybrid RAG and Content Trust", ("core/hybrid_retrieval.py", "core/rag_engine.py", "core/content_trust.py"), ("tests/core/test_prompt_defense.py", "tests/test_replaceability_and_platform.py"), "intelligence"),
    FeatureRecord("frontier_knowledge_plane", "Frontier Knowledge Intelligence Plane", ("core/frontier_knowledge.py", "jarvis_rag/knowledge_engine.py", "jarvis_rag/rag_engine.py"), ("tests/test_frontier_rag_unification.py", "tests/frontier_rag/test_frontier_upgrades.py"), "intelligence", True),
    FeatureRecord("frontier_evidence_truth", "Evidence, Claim Verification and Contradiction Analysis", ("jarvis_rag/evidence_graph.py", "jarvis_rag/claim_verification.py", "jarvis_rag/conflict_resolution.py"), ("tests/frontier_rag/test_advanced_intelligence.py", "tests/frontier_rag/test_rag_consistency.py"), "intelligence", True),
    FeatureRecord("frontier_memory_intelligence", "Temporal, Reflective and Federated Knowledge Memory", ("jarvis_rag/memory_agentic.py", "jarvis_rag/memory_history.py", "jarvis_rag/memory_federation.py"), ("tests/frontier_rag/test_memory.py", "tests/frontier_rag/test_memory_history.py"), "memory", True),
    FeatureRecord("frontier_code_multimodal", "Code Intelligence and Multimodal Retrieval Contracts", ("jarvis_rag/code_intelligence.py", "jarvis_rag/multimodal.py", "jarvis_rag/multimodal_retrieval.py"), ("tests/frontier_rag/test_frontier_upgrades.py",), "intelligence", True),
    FeatureRecord("frontier_evaluation_lab", "Retrieval Evaluation, Benchmarking and Failure Laboratory", ("jarvis_rag/evaluation_lab.py", "jarvis_rag/retrieval_benchmark.py", "jarvis_rag/failure_lab.py"), ("tests/frontier_rag/test_advanced_intelligence.py", "tests/frontier_rag/test_frontier_upgrades.py"), "observability", True),
    FeatureRecord("frontier_security_hardening", "Knowledge-Plane SSRF, Egress and Tool Boundary Hardening", ("jarvis_rag/security.py", "jarvis_rag/tool_library.py", "jarvis_rag/tools.py", "jarvis_rag/webhooks.py"), ("tests/test_frontier_security_regressions.py", "tests/frontier_rag/test_security.py"), "security", True),
    FeatureRecord("voice_multimodal", "Voice and Multimodal Interaction", ("core/multimodal_runtime.py", "core/multimodal_stream.py", "voice/conversation_loop/loop.py"), ("tests/test_frontier_modules.py",), "interaction", False),
    FeatureRecord("assistant_capabilities", "Desktop, Local Office, Smart-Home and Mobile Capability Suite", ("core/assistant_capability_suite.py",), ("tests/test_assistant_capabilities.py",), "interaction", False),
    FeatureRecord("computer_use", "Computer Use Boundary", ("core/computer_use.py", "core/vision_computer_use.py"), ("tests/test_frontier_modules.py",), "interaction", False),
    FeatureRecord("durable_jobs", "Durable Jobs and Recovery", ("core/job_engine.py", "core/durable_distributed_queue.py", "core/recovery_engineering.py"), ("tests/test_api_jobs_v126.py", "tests/test_v1265_release_hardening.py"), "reliability"),
    FeatureRecord("observability", "Health, SLOs, Metrics and Tracing", ("core/health_registry.py", "core/tracing.py", "observability/slo.py"), ("tests/test_main.py", "tests/test_kernel_edge_paths.py"), "reliability"),
    FeatureRecord("security_lab", "Adversarial and Supply-Chain Assurance", ("core/adversarial_lab.py", "core/adversarial_campaigns.py", "core/supply_chain_enforcement.py"), ("tests/test_adversarial_security.py",), "security"),
    FeatureRecord("native_model_fabric", "Local-Only Model Fabric", ("core/native_model_fabric.py",), ("tests/test_native_excellence.py",), "native", True),
    FeatureRecord("mission_contracts", "Mission Contracts and Hard Budgets", ("core/mission_contract.py",), ("tests/test_native_excellence.py",), "autonomy", True),
    FeatureRecord("utility_fabric", "Safe Native Utility Fabric", ("core/utility_fabric.py",), ("tests/test_native_excellence.py",), "utilities", True),
    FeatureRecord("context_compression", "Deterministic Long-Session Context Compression", ("core/context_compressor.py",), ("tests/test_native_excellence.py",), "memory", True),
    FeatureRecord("mtls_identity", "Certificate-Backed Worker Identity and mTLS Contracts", ("security/mtls_identity.py",), ("tests/test_state_of_art_batch.py",), "security", True),
    FeatureRecord("distributed_transport", "Durable Distributed Transport and Result Streaming", ("core/distributed_transport.py", "core/durable_distributed_queue.py"), ("tests/test_state_of_art_batch.py",), "distributed", True),
    FeatureRecord("world_reasoning", "Temporal Contradiction and Causal Reasoning", ("core/world_reasoner.py", "core/temporal_world_model.py"), ("tests/test_state_of_art_batch.py",), "intelligence", True),
    FeatureRecord("memory_integrity", "Memory Compaction and Integrity Snapshots", ("core/memory_lifecycle.py",), ("tests/test_state_of_art_batch.py",), "memory", True),
    FeatureRecord("vision_grounding", "Perceptual UI Grounding and Outcome Classification", ("core/vision_computer_use.py",), ("tests/test_state_of_art_batch.py",), "interaction", True),
    FeatureRecord("multimodal_fusion", "Interruptible Multimodal Event Fusion", ("core/multimodal_stream.py",), ("tests/test_state_of_art_batch.py",), "interaction", True),
    FeatureRecord("model_serving", "VRAM-Aware Model Residency and Hot Swap", ("core/model_server.py",), ("tests/test_state_of_art_batch.py",), "native", True),
    FeatureRecord("adversarial_campaigns", "Bounded Adversarial Autonomy Campaigns", ("core/adversarial_campaigns.py",), ("tests/test_state_of_art_batch.py",), "security", True),
    FeatureRecord("recovery_engineering", "Crash Snapshot and Recovery Drills", ("core/recovery_engineering.py",), ("tests/test_state_of_art_batch.py",), "reliability", True),
    FeatureRecord("system_digital_twin", "Resource Digital Twin and Forecasting", ("core/system_digital_twin.py",), ("tests/test_state_of_art_batch.py",), "observability", True),
    FeatureRecord("agent_reputation", "Evidence-Based Agent Reputation", ("core/agent_reputation.py",), ("tests/test_state_of_art_batch.py",), "agents", True),
    FeatureRecord("skill_manifests", "Least-Privilege Skill Contracts", ("core/skill_manifest.py",), ("tests/test_state_of_art_batch.py",), "plugins", True),
    FeatureRecord("cognitive_loop", "Verified Perceive-to-Learn Cognitive Loop", ("core/cognitive_loop.py",), ("tests/test_state_of_art_batch.py",), "intelligence", True),
    FeatureRecord("agent_swarm_2", "Dependency-Aware Agent Swarm with Review and Reputation", ("core/agent_swarm.py", "core/agent_reputation.py"), ("tests/test_state_of_art_batch.py",), "agents", True),
    FeatureRecord("cognitive_control_plane", "Integrated Cognitive Control Plane", ("core/cognitive_control_plane.py",), ("tests/test_cognitive_control_plane.py",), "intelligence", True),
    FeatureRecord("mission_resilience", "Integrity-Addressed Mission Checkpoints", ("core/cognitive_control_plane.py",), ("tests/test_cognitive_control_plane.py",), "reliability", True),
    FeatureRecord("resource_prediction", "Online Resource Forecasting and Selection", ("core/cognitive_control_plane.py",), ("tests/test_cognitive_control_plane.py",), "observability", True),
    FeatureRecord("prompt_firewall", "External Content Prompt Firewall", ("core/cognitive_control_plane.py",), ("tests/test_cognitive_control_plane.py",), "security", True),
    FeatureRecord("provenance_ledger", "Tamper-Evident Evidence Ledger", ("core/cognitive_control_plane.py",), ("tests/test_cognitive_control_plane.py",), "knowledge", True),    FeatureRecord("workload_identity", "SPIFFE-Compatible Short-Lived Workload Identity", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "security", True),
    FeatureRecord("webauthn_control", "WebAuthn Assertion Verification Control Plane", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "security", True),
    FeatureRecord("certificate_lifecycle", "Certificate Rotation and Revocation Lifecycle", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "security", True),
    FeatureRecord("wasi_runtime", "WASI/WASM Signed Plugin Admission", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "plugins", True),
    FeatureRecord("inference_optimizer", "Empirical Inference Optimization", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "native", True),
    FeatureRecord("continuous_profiler", "Continuous CPU and Memory Profiling", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "observability", True),
    FeatureRecord("distributed_memory", "Encrypted Distributed Memory Replica", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "memory", True),
    FeatureRecord("device_fabric_next", "Trusted Device Fabric and Failure-Domain Scheduling", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "distributed", True),
    FeatureRecord("mcp_apps", "MCP Protocol Compatibility and App Descriptors", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "protocol", True),
    FeatureRecord("policy_profiles", "Operator Profiles and Visual Policy Rules", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "operator", True),
    FeatureRecord("self_optimization", "Benchmark-Gated Self-Optimization", ("core/nextgen_platform.py",), ("tests/test_nextgen_platform.py",), "reliability", True),
    FeatureRecord("decision_ledger", "Tamper-Evident AI Decision Ledger", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("policy_simulation", "Non-Executing Policy Simulation Lab", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("capability_debugger", "Capability Decision Debugger", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("safe_mode", "Automatic and Explicit Runtime Safe Mode", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("context_compiler", "Trust-Aware Deterministic Context Compiler", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-intelligence", True),
    FeatureRecord("memory_reconciler", "Namespace-Safe Memory Deduplication and Contradiction Detection", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-memory", True),
    FeatureRecord("evidence_graph", "Claim-to-Source RAG Evidence Graph", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-memory", True),
    FeatureRecord("model_canary", "Model Canary and Failure Quarantine Guard", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-intelligence", True),
    FeatureRecord("incident_response", "Durable Security and Reliability Incident Manager", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-security", True),
    FeatureRecord("chaos_harness", "Opt-In Deterministic Fault Injection Harness", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-reliability", True),
    FeatureRecord("config_journal", "Secret-Free Configuration Provenance Journal", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("diagnostic_bundle", "Secret-Redacted Diagnostic Bundle Builder", ("core/frontier_control_plane.py",), ("tests/test_frontier_control_plane.py",), "frontier-ops", True),
    FeatureRecord("operator_frontier_surface", "Flutter Frontier Control Surface", ("flutter/lib/deck.dart", "flutter/lib/bridge/jarvis_bridge.dart"), ("tests/test_frontier_control_plane.py",), "frontier-operator", True),
    FeatureRecord("learning_ledger", "Namespace-Isolated Self-Learning Ledger", ("core/evolution_engine.py",), ("tests/test_evolution_engine.py",), "evolution", True),
    FeatureRecord("skill_evolution", "Evidence-Gated Skill Discovery and Promotion", ("core/evolution_engine.py",), ("tests/test_evolution_engine.py",), "evolution", True),
    FeatureRecord("dream_engine", "Bounded Dream and Sleep-Time Cognition", ("core/evolution_engine.py", "core/background_cognition.py"), ("tests/test_evolution_engine.py",), "evolution", True),
    FeatureRecord("autopilot_rules", "Event-Driven Autopilot Rule Engine", ("core/evolution_engine.py",), ("tests/test_evolution_engine.py",), "autonomy", True),
    FeatureRecord("assistant_routines", "Local Personal Assistant Routine Engine", ("core/evolution_engine.py",), ("tests/test_evolution_engine.py",), "assistant", True),
    FeatureRecord("self_evolution", "Transactional Self-Editing Candidate and Canary Pipeline", ("core/evolution_engine.py", "core/self_improvement.py"), ("tests/test_evolution_engine.py",), "evolution", True),
    FeatureRecord("needle_micro_agent", "Needle 3 Low-Latency Structured Micro-Agent Adapter", ("core/evolution_engine.py",), ("tests/test_evolution_engine.py",), "intelligence", False),
    FeatureRecord("public_oss_forge", "Anonymous Public GitHub OSS Forge with License and Archive Guarding", ("core/evolution_engine.py", "core/network_policy.py", "services/operator_service.py"), ("tests/test_evolution_engine.py",), "ecosystem", True),
    FeatureRecord("evolution_operator_bridge", "Flutter Evolution, Dream, Assistant and OSS Commands", ("core/desktop_command_gateway.py", "flutter/lib/bridge/jarvis_bridge.dart"), ("tests/test_evolution_engine.py",), "operator", True),
    FeatureRecord("mcp_2026_07_28_alignment", "MCP Tasks and Authorization Alignment Boundary", ("core/mcp_gateway.py", "core/nextgen_platform.py"), ("tests/test_evolution_engine.py",), "protocol", True),
    FeatureRecord("watchdog_lifecycle", "Interruptible Watchdog Shutdown and Health Lifecycle", ("core/watchdog.py",), ("tests/test_watchdog_lifecycle.py",), "reliability", True),
    FeatureRecord("causal_memory", "Evidence-Bound Causal Memory Graph", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "frontier-cognition", True),
    FeatureRecord("dream_sandbox", "Bounded Non-Destructive Dream Snapshot Sandbox", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "evolution", True),
    FeatureRecord("trajectory_grading", "Deterministic Trajectory Quality Grading", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "evaluation", True),
    FeatureRecord("contract_fingerprints", "Deterministic Contract Fingerprinting", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "architecture", True),
    FeatureRecord("architecture_drift", "Explicit Architecture Import Drift Detection", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "architecture", True),
    FeatureRecord("verified_training_data", "Provenance-Bound Verified Training Dataset Factory", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "learning", True),
    FeatureRecord("thermal_governance", "Thermal and Battery-Aware Background Compute Governance", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "performance", True),
    FeatureRecord("agent_garage_2", "Controlled Agent Lifecycle Garage 2.0", ("core/agent_garage.py",), ("tests/test_p2_agent_garage.py",), "p2-d", True),
    FeatureRecord("signed_a2a_tasks", "Signed A2A Task Envelope Boundary", ("core/permanent_evolution.py",), ("tests/test_permanent_evolution.py",), "protocol", True),
    FeatureRecord("deterministic_startup", "Deterministic Startup Dependency Graph", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "architecture", True),
    FeatureRecord("mission_node_policy", "Per-Node Mission Policy Recheck Gate", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "security", True),
    FeatureRecord("model_lifecycle", "Checksum-Verified Model Lifecycle Manager", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "native", True),
    FeatureRecord("embedding_compatibility", "Embedding and Index Compatibility Registry", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "memory", True),
    FeatureRecord("empirical_benchmarks", "Bounded Empirical Performance Benchmark Runner", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "performance", True),
    FeatureRecord("voice_vad_bargein", "Dependency-Free Voice Activity Detection and Barge-In", ("core/frontier_completion.py", "voice/conversation_loop/loop.py"), ("tests/test_final_completion.py",), "interaction", True),
    FeatureRecord("privacy_capture", "Privacy-Zone Bounded Screen and Camera Capture", ("core/frontier_completion.py", "core/assistant_capability_suite.py"), ("tests/test_final_completion.py",), "security", True),
    FeatureRecord("clipboard_local_intelligence", "Local-Only Clipboard Intelligence Boundary", ("core/frontier_completion.py", "core/assistant_capability_suite.py"), ("tests/test_final_completion.py",), "interaction", True),
    FeatureRecord("proactive_scheduler", "Quiet-Hours and Interruption-Aware Proactive Scheduler", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "autonomy", True),
    FeatureRecord("encrypted_snapshots", "Encrypted Crash-Recovery Snapshot Store", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "reliability", True),
    FeatureRecord("lan_pairing", "One-Time Capability-Attenuated LAN Pairing", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "distributed", True),
    FeatureRecord("world_state_projection", "Integrity-Addressed Unified World-State Projection", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "aios", True),
    FeatureRecord("artifact_quarantine", "Deterministic Quarantine and Rollback Artifact Manager", ("core/frontier_completion.py",), ("tests/test_final_completion.py",), "release", True),
    FeatureRecord("supreme_runtime_fabric", "Integrated Agent, Compute, Mission, Memory, Device, Observability, Evolution, Knowledge, Multimodal, Computer-Use, Cluster and Twin Fabric", ("core/supreme_runtime.py", "core/nextgen_platform.py"), ("tests/test_supreme_runtime.py", "tests/test_nextgen_platform.py"), "supreme-runtime", True),
    FeatureRecord("sensor_fusion_frontier", "Uncertainty-Aware Camera/Thermal/Radar/LiDAR/Acoustic/Atmospheric/Satellite/Telemetry Fusion", ("core/sensor_fusion.py",), ("tests/test_next_batch_state_of_art.py",), "frontier-awareness", True),
    FeatureRecord("world_state_frontier", "Provenance-Addressed World State and Contradiction Detection", ("core/world_state.py",), ("tests/test_next_batch_state_of_art.py",), "frontier-awareness", True),
    FeatureRecord("cognitive_advisor", "Evidence-Separated Real-Time Situational and Wellbeing Assistant", ("core/cognitive_assistant.py",), ("tests/test_next_batch_state_of_art.py",), "frontier-cognition", True),
    FeatureRecord("flight_safety_planner", "Deterministic Geofenced Flight Path and Return-to-Home Planner", ("core/flight_safety.py",), ("tests/test_next_batch_state_of_art.py",), "safe-mobility", True),
    FeatureRecord("human_command_swarm", "Human-Authorized Multi-Robot Simulation-First Coordination", ("core/swarm_coordinator.py",), ("tests/test_next_batch_state_of_art.py",), "safe-mobility", True),
    FeatureRecord("defensive_soc", "Authorized Defensive Cybersecurity Analytics and Containment Boundary", ("core/cyber_defense.py",), ("tests/test_next_batch_state_of_art.py",), "defensive-security", True),
    FeatureRecord("telemetry_fabric", "Unified Multi-System Provenance-Aware Telemetry Plane", ("core/telemetry_fabric.py",), ("tests/test_next_batch_state_of_art.py",), "observability", True),
    FeatureRecord("hud_diagnostics", "UI-Neutral HUD and Command-Deck Diagnostics Projection", ("core/hud_diagnostics.py",), ("tests/test_next_batch_state_of_art.py",), "operator", True),
    FeatureRecord("lab_automation", "Interlocked Simulation-First Laboratory Automation Fabric", ("core/lab_automation.py",), ("tests/test_next_batch_state_of_art.py",), "lab-automation", True),
    FeatureRecord("bounded_optimization", "Benchmark-Gated Finite Self-Optimization and Evolution Evidence", ("core/bounded_optimization.py",), ("tests/test_next_batch_state_of_art.py",), "evolution", True),
    FeatureRecord("agent_population", "Bounded Specialist Agent Population Controller", ("core/agent_population.py",), ("tests/test_next_batch_state_of_art.py",), "agents", True),
    FeatureRecord("distributed_cognition", "Shared Evidence/Fact/Result Fabric with Authority Isolation", ("core/distributed_cognitive.py",), ("tests/test_next_batch_state_of_art.py",), "distributed-cognition", True),
    FeatureRecord("root_authority", "Short-Lived One-Shot Root Operator Authority with Immutable Safety Invariants", ("core/root_authority.py",), ("tests/test_next_batch_state_of_art.py",), "security", True),
    FeatureRecord("safe_operational_modes", "Human-Authorized Simulation/Training/Emergency/Rescue Operational Modes", ("core/operational_modes.py",), ("tests/test_next_batch_state_of_art.py",), "safe-operations", True),
    FeatureRecord("sensor_fabric_2", "Canonical Sensor Discovery, Calibration, Sequencing and Health Fabric", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("world_model_2", "Immutable Dynamic World Snapshot and Integrity Digest", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("context_compiler_2", "Bounded Evidence-First Context Compiler", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("adaptive_model_router_2", "Constraint-First Explainable Adaptive Model Router", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("personal_learning_gate", "Benchmark-Gated Personal Continual-Learning Promotion", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("agent_genome_lab", "Bounded Agent Genome Specialization and Generational Lineage", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("simulation_universe", "Deterministic Bounded Digital-Twin Scenario Simulation", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("verification_engine_2", "Layered Authorization, Simulation, Policy and Provenance Gate", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("gpu_intelligence_fabric", "Thermal, Utilization and Memory-Aware GPU Admission Control", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("recovery_coordinator_2", "Idempotent Bounded Checkpoint Recovery Coordinator", ("core/frontier_evolution_2.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("frontier_event_stream", "Correlated Bounded Real-Time Frontier Event Stream", ("core/frontier_event_stream.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("zero_trust_leases", "Signed Zero-Trust Capability Leases with Rotation and Revocation", ("core/zero_trust.py",), ("tests/test_reliability_zero_trust_event_fabric.py",), "reliability-security", True),
    FeatureRecord("action_attestation", "Cryptographically Bound Action Attestation", ("core/zero_trust.py",), ("tests/test_reliability_zero_trust_event_fabric.py",), "reliability-security", True),
    FeatureRecord("event_envelope_integrity", "Typed Event Context and Integrity Hashing", ("core/contracts/event.py", "core/event_fabric.py"), ("tests/test_reliability_zero_trust_event_fabric.py",), "event-fabric", True),
    FeatureRecord("resource_leak_gate", "Explicit Resource Ownership and Zero-Leak Gate", ("core/resource_guard.py", "core/lifecycle_diagnostics.py"), ("tests/test_reliability_zero_trust_event_fabric.py",), "reliability", True),
    FeatureRecord("doctor_hardening", "JARVIS Doctor 2.0 Zero-Trust and Event Integrity Diagnostics", ("core/jarvis_doctor.py",), ("tests/test_reliability_zero_trust_event_fabric.py",), "reliability", True),
    FeatureRecord("flet_command_center", "Non-Blocking Optional Flet Operator Command Surface", ("core/flet_command_center.py",), ("tests/test_frontier_evolution_2.py",), "evolution-2", True),
    FeatureRecord("p2_failure_intelligence", "P2-I Canonical Failure Intelligence Engine", ("core/failure_intelligence.py", "core/schemas/failure_record_v1.schema.json", "core/schemas/failure_hypothesis_v1.schema.json", "core/schemas/failure_remediation_v1.schema.json", "core/schemas/failure_regression_case_v1.schema.json", "core/schemas/failure_benchmark_case_v1.schema.json", "core/schemas/failure_warning_v1.schema.json", "core/schemas/failure_policy_proposal_v1.schema.json", "core/schemas/failure_diagnostic_v1.schema.json", "core/schemas/failure_correlation_graph_v1.schema.json"), ("tests/test_p2_failure_intelligence.py",), "p2-i", True),
    FeatureRecord("p2_cognitive_command_center", "P2-Z Cognitive Command Center Gateway and Flutter Client", ("core/cognitive_command_center", "clients/command_center", "core/schemas/ui_action_request_v1.schema.json", "core/schemas/ui_view_model_v1.schema.json", "core/schemas/operator_session_v1.schema.json", "core/schemas/ui_surface_v1.schema.json", "core/schemas/gateway_contract_v1.schema.json", "core/schemas/audit_record_v1.schema.json", "core/schemas/operator_identity_v1.schema.json", "core/schemas/confirmation_record_v1.schema.json", "core/schemas/stream_filter_v1.schema.json", "core/schemas/action_record_v1.schema.json"), ("tests/test_p2_cognitive_command_center.py",), "p2-z", True),
)


class FeatureRegistry:
    """Audit the shipped source tree against the canonical feature matrix."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()

    def records(self) -> tuple[FeatureRecord, ...]:
        """Return the immutable canonical feature inventory."""
        return FEATURES

    def audit(self) -> FeatureAudit:
        """Verify every feature has its declared implementation and tests."""
        records: list[dict[str, object]] = []
        missing_modules: list[str] = []
        missing_tests: list[str] = []
        complete = 0
        for feature in FEATURES:
            module_missing = tuple(path for path in feature.modules if not ((self.root / path).is_file() or (self.root / path).is_dir() and ((self.root / path) / "__init__.py").is_file()))
            test_missing = tuple(path for path in feature.tests if not ((self.root / path).is_file() or (self.root / path).is_dir() and ((self.root / path) / "__init__.py").is_file()))
            complete_flag = not module_missing and not test_missing
            if complete_flag:
                complete += 1
            missing_modules.extend(f"{feature.key}:{path}" for path in module_missing)
            missing_tests.extend(f"{feature.key}:{path}" for path in test_missing)
            records.append({
                "key": feature.key,
                "title": feature.title,
                "milestone": feature.milestone,
                "critical": feature.critical,
                "complete": complete_flag,
                "modules": list(feature.modules),
                "tests": list(feature.tests),
                "missing_modules": list(module_missing),
                "missing_tests": list(test_missing),
            })
        return FeatureAudit(len(FEATURES), complete, len(FEATURES) - complete, tuple(missing_modules), tuple(missing_tests), tuple(records))

    def coverage_by_milestone(self) -> dict[str, float]:
        """Return implementation/test coverage grouped by roadmap milestone."""
        audit = self.audit()
        grouped: dict[str, list[bool]] = {}
        for row in audit.records:
            grouped.setdefault(str(row["milestone"]), []).append(bool(row["complete"]))
        return {key: (sum(values) / len(values)) * 100.0 for key, values in sorted(grouped.items())}

    def critical_complete(self) -> bool:
        """Return whether every critical capability has evidence."""
        return all(bool(row["complete"]) for row in self.audit().records if bool(row["critical"]))



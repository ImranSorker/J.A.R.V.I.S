"""State-of-the-art-safe vision primitives for grounding and UI change analysis."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class VisionElement:
    """Grounded UI element with normalized confidence metadata."""

    label: str
    x: int
    y: int
    width: int
    height: int
    confidence: float


@dataclass(frozen=True, slots=True)
class ImageDigest:
    """Content and perceptual fingerprints for an image payload."""

    sha256: str
    perceptual: int


@dataclass(frozen=True, slots=True)
class VisionDiff:
    """Bounded screenshot change summary."""

    changed: bool
    hamming_distance: int
    threshold: int
    before_sha256: str
    after_sha256: str


class OCRAdapter(Protocol):
    """OCR boundary implemented by an optional OCR provider."""

    def extract(self, image: bytes) -> list[VisionElement]:
        """Extract grounded text/UI elements from image bytes."""


class OutcomeClassifier(Protocol):
    """Computer-use action outcome classifier boundary."""

    def classify(self, before: bytes, after: bytes) -> float:
        """Return a normalized action-success probability."""


class VisionComputerUse:
    """Hash, compare and ground screenshots without directly performing actions."""

    def __init__(self, ocr: OCRAdapter | None = None, classifier: OutcomeClassifier | None = None) -> None:
        self.ocr = ocr
        self.classifier = classifier

    @staticmethod
    def _gray_thumbnail(image: bytes, size: int = 32) -> list[int]:
        """Build a deterministic low-resolution grayscale proxy from raw bytes."""
        if not image:
            return [0] * (size * size)
        values = list(image[: max(size * size, 4096)])
        if len(values) < size * size:
            values.extend([values[-1]] * (size * size - len(values)))
        step = max(1, len(values) // (size * size))
        return [sum(values[index : index + step]) // max(1, len(values[index : index + step])) for index in range(0, step * size * size, step)][: size * size]

    def fingerprint(self, image: bytes) -> str:
        """Return a cryptographic content fingerprint."""
        return hashlib.sha256(bytes(image)).hexdigest()

    def perceptual_hash(self, image: bytes) -> int:
        """Return a 64-bit average hash from a deterministic thumbnail."""
        thumb = self._gray_thumbnail(image, 8)
        average = sum(thumb) / len(thumb)
        result = 0
        for index, value in enumerate(thumb):
            if value >= average:
                result |= 1 << index
        return result

    def digest(self, image: bytes) -> ImageDigest:
        """Return both cryptographic and perceptual identity."""
        return ImageDigest(self.fingerprint(image), self.perceptual_hash(image))

    def compare(self, before: bytes, after: bytes, *, threshold: int = 8) -> VisionDiff:
        """Compare images using perceptual Hamming distance plus SHA-256 identity."""
        limit = max(0, min(int(threshold), 64))
        first, second = self.digest(before), self.digest(after)
        distance = (first.perceptual ^ second.perceptual).bit_count()
        return VisionDiff(first.sha256 != second.sha256 and distance >= limit, distance, limit, first.sha256, second.sha256)

    def changed(self, before: bytes, after: bytes) -> bool:
        """Return whether perceptual content changed."""
        return self.fingerprint(before) != self.fingerprint(after)

    def ground(self, image: bytes) -> list[VisionElement]:
        """Extract UI elements through the optional OCR boundary."""
        if self.ocr is None:
            return []
        elements = list(self.ocr.extract(bytes(image)))
        return [VisionElement(str(item.label), max(0, int(item.x)), max(0, int(item.y)), max(0, int(item.width)), max(0, int(item.height)), max(0.0, min(1.0, float(item.confidence)))) for item in elements]

    def classify_outcome(self, before: bytes, after: bytes) -> float:
        """Return action success probability using classifier or conservative change heuristic."""
        if self.classifier is not None:
            return max(0.0, min(1.0, float(self.classifier.classify(bytes(before), bytes(after)))))
        diff = self.compare(before, after)
        return 0.9 if diff.changed else 0.1



"""Durable agent-job execution with security and reliability controls."""
from __future__ import annotations
from contextlib import contextmanager

import concurrent.futures
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set

from core.circuit_breaker import CircuitBreakerRegistry
from core.concurrency_quota import ConcurrencyQuota
from core.crypto_store import CryptoStore
from core.dead_letter_queue import DeadLetterQueue
from core.idempotency import IdempotencyStore
from core.schema_validator import SchemaValidator
from core.tracing import TraceContext
from core.types import RiskLevel

logger = logging.getLogger("jarvis.job_engine")


class JobStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class StepStatus(str, Enum):
    PENDING = "pending"
    AWAITING_AUTH = "awaiting_auth"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


@dataclass
class ToolCall:
    """A typed tool invocation carried by a durable job step."""

    name: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    approval_token: Optional[str] = None
    idempotency_key: Optional[str] = None

    def to_dict(self, include_secret: bool = False) -> Dict[str, Any]:
        data: Dict[str, Any] = {"name": self.name, "arguments": self.arguments}
        if self.idempotency_key is not None:
            data["idempotency_key"] = self.idempotency_key
        if include_secret and self.approval_token is not None:
            data["approval_token"] = self.approval_token
        return data


@dataclass
class JobStep:
    """One executable step in a durable job DAG."""

    id: str
    name: str
    description: str = ""
    tool_call: Optional[ToolCall] = None
    agent_name: Optional[str] = None
    agent_task: Optional[str] = None
    depends_on: List[str] = field(default_factory=list)
    status: StepStatus = StepStatus.PENDING
    result: Any = None
    error: Optional[str] = None
    risk_level: RiskLevel = RiskLevel.LOW
    requires_auth: bool = False
    authorized_by: Optional[str] = None
    auth_token: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 2
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    timeout_seconds: float = 30.0

    def to_dict(self, include_secret: bool = False) -> Dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        data["risk_level"] = self.risk_level.name
        data["tool_call"] = self.tool_call.to_dict(include_secret=include_secret) if self.tool_call else None
        if not include_secret:
            if self.auth_token is not None:
                data["auth_token"] = "[redacted]"
        return data

    def to_persist_dict(self, crypto: Optional[CryptoStore]) -> Dict[str, Any]:
        # Authorization material is never persisted in plaintext. When the
        # master secret is unavailable, keep the credential in memory only;
        # a recovered job must re-enter the authorization state.
        data = self.to_dict(include_secret=bool(crypto and crypto.enabled))
        if crypto and crypto.enabled:
            if self.auth_token is not None:
                data["auth_token"] = crypto.encrypt(self.auth_token)
            if self.tool_call and self.tool_call.approval_token is not None:
                tool = dict(data["tool_call"])
                tool["approval_token"] = crypto.encrypt(self.tool_call.approval_token)
                data["tool_call"] = tool
            if self.error is not None:
                data["error"] = crypto.encrypt(self.error)
        else:
            data["auth_token"] = None
            if isinstance(data.get("tool_call"), dict):
                data["tool_call"]["approval_token"] = None
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any], crypto: Optional[CryptoStore] = None) -> "JobStep":
        values = dict(data)
        raw_status = values.get("status", StepStatus.PENDING.value)
        values["status"] = raw_status if isinstance(raw_status, StepStatus) else StepStatus(str(raw_status))
        raw_risk = values.get("risk_level", RiskLevel.LOW.name)
        if isinstance(raw_risk, RiskLevel):
            values["risk_level"] = raw_risk
        else:
            try:
                values["risk_level"] = RiskLevel[str(raw_risk).upper()]
            except KeyError as exc:
                raise ValueError(f"invalid risk level: {raw_risk}") from exc
        tool_data = values.get("tool_call")
        if tool_data and not isinstance(tool_data, ToolCall):
            tool_values = dict(tool_data)
            token = tool_values.get("approval_token")
            if isinstance(token, str) and token.startswith("v1:"):
                if not crypto or not crypto.enabled:
                    raise ValueError("encrypted approval token requires JARVIS_MASTER_SECRET")
                try:
                    tool_values["approval_token"] = crypto.decrypt(token)
                except ValueError:
                    raise ValueError("invalid persisted approval token")
            values["tool_call"] = ToolCall(**tool_values)
        auth_token = values.get("auth_token")
        if isinstance(auth_token, str) and auth_token != "[redacted]" and auth_token.startswith("v1:"):
            if not crypto or not crypto.enabled:
                raise ValueError("encrypted authorization token requires JARVIS_MASTER_SECRET")
            try:
                values["auth_token"] = crypto.decrypt(auth_token)
            except ValueError:
                raise ValueError("invalid persisted authorization token")
        error = values.get("error")
        if crypto and crypto.enabled and isinstance(error, str) and error.startswith("v1:"):
            try:
                values["error"] = crypto.decrypt(error)
            except ValueError:
                raise ValueError("invalid persisted step error")
        values["timeout_seconds"] = float(values.get("timeout_seconds", 30.0))
        allowed = set(cls.__dataclass_fields__)
        return cls(**{key: value for key, value in values.items() if key in allowed})


@dataclass
class Job:
    """Durable job metadata and ordered execution steps."""

    goal: str
    id: str = field(default_factory=lambda: f"job_{uuid.uuid4().hex[:12]}")
    status: JobStatus = JobStatus.PENDING
    steps: List[JobStep] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    owner: str = "system"
    priority: int = 5
    current_step_index: int = -1
    result: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    idempotency_key: Optional[str] = None

    def to_dict(self, include_secret: bool = False) -> Dict[str, Any]:
        data: Dict[str, Any] = asdict(self)
        data["status"] = self.status.value
        data["steps"] = [step.to_dict(include_secret=include_secret) for step in self.steps]
        if not include_secret and data.get("error") is not None:
            data["error"] = "[redacted]"
        return data


class JobStore:
    """SQLite-backed job store with transactional schema migration and encryption."""

    def __init__(self, db_path: str = "data/jobs.db", crypto: Optional[CryptoStore] = None) -> None:
        self._db_path = str(db_path)
        self._crypto = crypto
        self._lock = threading.RLock()
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        """Yield a configured SQLite connection and always close it."""
        conn = sqlite3.connect(self._db_path, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    goal TEXT NOT NULL,
                    status TEXT NOT NULL,
                    steps_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    owner TEXT NOT NULL,
                    priority INTEGER NOT NULL,
                    current_step_index INTEGER NOT NULL,
                    result_json TEXT,
                    error TEXT,
                    metadata_json TEXT,
                    idempotency_key TEXT
                );
                CREATE TABLE IF NOT EXISTS job_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    event TEXT NOT NULL,
                    detail TEXT,
                    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
                CREATE INDEX IF NOT EXISTS idx_jobs_owner ON jobs(owner);
                CREATE INDEX IF NOT EXISTS idx_jobs_idempotency ON jobs(idempotency_key);
                CREATE INDEX IF NOT EXISTS idx_job_history_job ON job_history(job_id, timestamp, id);
                """
            )
            columns = {row[1] for row in conn.execute("PRAGMA table_info(jobs)").fetchall()}
            if "idempotency_key" not in columns:
                conn.execute("ALTER TABLE jobs ADD COLUMN idempotency_key TEXT")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_idempotency ON jobs(idempotency_key)")

    def healthy(self) -> bool:
        """Perform a lightweight writable database health probe."""
        try:
            with self._lock, self._connect() as conn:
                conn.execute("SELECT 1").fetchone()
            return True
        except sqlite3.Error:
            return False

    def save(self, job: Job) -> None:
        job.updated_at = time.time()
        steps_json = json.dumps([step.to_persist_dict(self._crypto) for step in job.steps], default=str)
        error = self._crypto.encrypt(job.error) if self._crypto and self._crypto.enabled and job.error else job.error
        with self._lock, self._connect() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO jobs
                (id,goal,status,steps_json,created_at,updated_at,owner,priority,current_step_index,
                 result_json,error,metadata_json,idempotency_key)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    job.id,
                    job.goal,
                    job.status.value,
                    steps_json,
                    job.created_at,
                    job.updated_at,
                    job.owner,
                    job.priority,
                    job.current_step_index,
                    json.dumps(job.result, default=str) if job.result is not None else None,
                    error,
                    json.dumps(job.metadata, default=str),
                    job.idempotency_key,
                ),
            )

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock, self._connect() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return self._row_to_job(row) if row else None

    def list_jobs(
        self,
        status: Optional[JobStatus] = None,
        owner: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Job]:
        bounded_limit = max(1, min(int(limit), 1000))
        bounded_offset = max(0, int(offset))
        query = "SELECT * FROM jobs WHERE 1=1"
        params: list[Any] = []
        if status:
            query += " AND status=?"
            params.append(status.value)
        if owner:
            query += " AND owner=?"
            params.append(owner)
        query += " ORDER BY priority DESC, updated_at DESC LIMIT ? OFFSET ?"
        params.extend([bounded_limit, bounded_offset])
        with self._lock, self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_job(row) for row in rows]

    def delete(self, job_id: str) -> bool:
        with self._lock, self._connect() as conn:
            current = conn.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not current:
                return False
            if current["status"] == JobStatus.RUNNING.value:
                raise ValueError("cannot delete a running job")
            deleted = conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
            return deleted.rowcount > 0

    def log_event(self, job_id: str, event: str, detail: Optional[str] = None) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                "INSERT INTO job_history(job_id,timestamp,event,detail) VALUES(?,?,?,?)",
                (job_id, time.time(), event, detail),
            )

    def get_history(self, job_id: str) -> List[Dict[str, Any]]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM job_history WHERE job_id=? ORDER BY timestamp,id", (job_id,)
            ).fetchall()
        return [dict(row) for row in rows]

    def recoverable_jobs(self) -> List[Job]:
        return self.list_jobs(status=JobStatus.RUNNING, limit=1000)

    def _row_to_job(self, row: sqlite3.Row) -> Job:
        steps_data = json.loads(row["steps_json"])
        steps = [JobStep.from_dict(data, crypto=self._crypto) for data in steps_data]
        error = row["error"]
        if self._crypto and self._crypto.enabled and isinstance(error, str) and error.startswith("v1:"):
            error = self._crypto.decrypt(error)
        return Job(
            id=row["id"],
            goal=row["goal"],
            status=JobStatus(row["status"]),
            steps=steps,
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            owner=row["owner"],
            priority=int(row["priority"]),
            current_step_index=int(row["current_step_index"]),
            result=json.loads(row["result_json"]) if row["result_json"] else None,
            error=error,
            metadata=json.loads(row["metadata_json"]) if row["metadata_json"] else {},
            idempotency_key=row["idempotency_key"] if "idempotency_key" in row.keys() else None,
        )


class JobEngine:
    """Durable executor with retries, DAG validation, authorization and quotas."""

    def __init__(
        self,
        tool_service: Any,
        agent_service: Any,
        permission_engine: Any,
        store: Optional[JobStore] = None,
        auto_recover: bool = True,
        schema_validator: Optional[SchemaValidator] = None,
        concurrency: Optional[ConcurrencyQuota] = None,
        idempotency: Optional[IdempotencyStore] = None,
        dlq: Optional[DeadLetterQueue] = None,
        circuit_breakers: Optional[CircuitBreakerRegistry] = None,
        resource_governor: Optional[Any] = None,
    ) -> None:
        self._tools = tool_service
        self._agents = agent_service
        self._permissions = permission_engine
        self._store = store or JobStore()
        self._validator = schema_validator or SchemaValidator()
        self._quota = concurrency or ConcurrencyQuota()
        self._idempotency = idempotency or IdempotencyStore()
        self._dlq = dlq or DeadLetterQueue()
        self._circuit_breakers = circuit_breakers or CircuitBreakerRegistry()
        self._resource_governor = resource_governor
        self._running: Dict[str, threading.Event] = {}
        self._paused: Dict[str, threading.Event] = {}
        self._threads: Dict[str, threading.Thread] = {}
        self._active_futures: Dict[str, concurrent.futures.Future] = {}
        self._future_lock = threading.Lock()
        self._authorized_tokens: Dict[tuple[str, str], str] = {}
        self._lock = threading.RLock()
        self._dispatcher_stop = threading.Event()
        self._dispatcher = threading.Thread(target=self._dispatch_loop, name="jarvis-job-dispatcher", daemon=True)
        if auto_recover:
            self.recover_interrupted_jobs()
        self._dispatcher.start()

    def _dispatch_loop(self) -> None:
        """Drain queued jobs whenever concurrency capacity becomes available."""
        while not self._dispatcher_stop.wait(0.1):
            try:
                queued = self._store.list_jobs(status=JobStatus.QUEUED, limit=100)
                for job in queued:
                    if self._dispatcher_stop.is_set():
                        return
                    with self._lock:
                        thread = self._threads.get(job.id)
                        if thread and thread.is_alive():
                            continue
                    try:
                        self.start(job.id)
                    except RuntimeError as exc:
                        if "Concurrency quota exceeded" not in str(exc):
                            logger.warning("queued_job_dispatch_failed", extra={"job_id": job.id, "error": str(exc)})
                    except ValueError as exc:
                        logger.warning("queued_job_invalid", extra={"job_id": job.id, "error": str(exc)})
            except Exception:
                logger.exception("job_dispatcher_error")

    def submit(
        self,
        goal: str,
        steps: List[JobStep],
        owner: str = "system",
        priority: int = 5,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Job:
        clean_goal = str(goal).strip()
        clean_owner = str(owner or "system").strip() or "system"
        if not clean_goal:
            raise ValueError("Job goal is required")
        self._validate_steps(steps)
        steps_json = json.dumps([step.to_dict(include_secret=False) for step in steps], sort_keys=True, default=str)

        if idempotency_key:
            is_new, existing_id = self._idempotency.check_or_create(
                idempotency_key, clean_goal, steps_json, clean_owner
            )
            if not is_new:
                if existing_id:
                    existing = self._store.get(existing_id)
                    if existing is not None:
                        return existing
                    raise RuntimeError("idempotency record references a missing job")
                raise RuntimeError("idempotency request is already being created")
        job = Job(
            goal=clean_goal,
            steps=list(steps),
            owner=clean_owner,
            priority=max(1, min(10, int(priority))),
            metadata=dict(metadata or {}),
            status=JobStatus.QUEUED,
            idempotency_key=str(idempotency_key).strip() if idempotency_key else None,
        )
        try:
            self._store.save(job)
            self._store.log_event(job.id, "submitted", f"owner={job.owner}; priority={job.priority}")
            if idempotency_key:
                self._idempotency.finalize(str(idempotency_key).strip(), job.id)
        except Exception:
            # A reserved idempotency key remains until TTL expiry so a failed transaction
            # cannot be raced by a second submission.
            raise
        return job

    def start(self, job_id: str) -> Job:
        job = self._require(job_id)
        with self._lock:
            current_thread = self._threads.get(job_id)
            if current_thread and current_thread.is_alive():
                return job
            if job.status not in (JobStatus.QUEUED, JobStatus.PAUSED, JobStatus.PENDING):
                raise ValueError(f"Cannot start job in status {job.status.value}")
            if not self._quota.acquire(job.owner, job_id):
                raise RuntimeError("Concurrency quota exceeded")
            job.status = JobStatus.RUNNING
            self._store.save(job)
            self._store.log_event(job.id, "started")
            stop = threading.Event()
            pause = threading.Event()
            self._running[job_id] = stop
            self._paused[job_id] = pause
            thread = threading.Thread(
                target=self._execute_job,
                args=(job_id, stop, pause),
                name=f"job-{job_id}",
                daemon=True,
            )
            self._threads[job_id] = thread
            thread.start()
        return job

    def cancel(self, job_id: str) -> Job:
        job = self._require(job_id)
        with self._lock:
            worker = self._running.get(job_id)
            if worker:
                worker.set()
            if job.status not in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
                job.status = JobStatus.CANCELLED
                job.error = "Cancelled by user"
                for step in job.steps:
                    if step.status == StepStatus.RUNNING:
                        step.status = StepStatus.CANCELLED
                self._store.save(job)
                self._store.log_event(job.id, "cancelled")
        worker_thread = self._threads.get(job_id)
        if worker_thread is not None and worker_thread is not threading.current_thread():
            worker_thread.join(timeout=2.0)
        refreshed = self._store.get(job_id)
        return refreshed or job

    def pause(self, job_id: str) -> Job:
        job = self._require(job_id)
        if job.status != JobStatus.RUNNING:
            raise ValueError(f"Cannot pause job in status {job.status.value}")
        with self._lock:
            pause = self._paused.get(job_id)
            if pause is None:
                raise RuntimeError("job worker is not active")
            pause.set()
            job.status = JobStatus.PAUSED
            self._store.save(job)
            self._store.log_event(job.id, "paused")
        return job

    def resume(self, job_id: str) -> Job:
        job = self._require(job_id)
        if job.status != JobStatus.PAUSED:
            raise ValueError(f"Cannot resume job in status {job.status.value}")
        with self._lock:
            pause = self._paused.get(job_id)
            thread = self._threads.get(job_id)
            if pause is not None and thread is not None and thread.is_alive():
                pause.clear()
                job.status = JobStatus.RUNNING
                self._store.save(job)
                self._store.log_event(job.id, "resumed")
                return job
        job.status = JobStatus.QUEUED
        self._store.save(job)
        return self.start(job_id)

    def get(self, job_id: str) -> Optional[Job]:
        return self._store.get(job_id)

    def list_jobs(
        self, status: Optional[JobStatus] = None, owner: Optional[str] = None, limit: int = 100
    ) -> List[Job]:
        return self._store.list_jobs(status=status, owner=owner, limit=limit)

    def get_history(self, job_id: str) -> List[Dict[str, Any]]:
        self._require(job_id)
        return self._store.get_history(job_id)

    def delete(self, job_id: str) -> bool:
        with self._lock:
            worker = self._running.get(job_id)
            if worker:
                worker.set()
        deleted = self._store.delete(job_id)
        return deleted

    def authorize_step(self, job_id: str, step_id: str, token: str, approver: str = "user") -> bool:
        if not str(token).strip():
            return False
        job = self._require(job_id)
        for step in job.steps:
            if step.id != step_id or step.status != StepStatus.AWAITING_AUTH:
                continue
            capability = step.tool_call.name if step.tool_call else step.agent_name
            verifier = getattr(self._permissions, "verify", None)
            if not callable(verifier):
                return False
            if verifier(token, capability=capability):
                step.auth_token = token
                step.authorized_by = approver
                step.status = StepStatus.PENDING
                self._authorized_tokens[(job.id, step_id)] = str(token)
                self._store.save(job)
                self._store.log_event(job.id, "step_authorized", f"step={step_id}; approver={approver}")
                return True
        return False

    def recover_interrupted_jobs(self) -> int:
        recovered = 0
        for job in self._store.recoverable_jobs():
            for step in job.steps:
                if step.status == StepStatus.RUNNING:
                    step.status = StepStatus.PENDING
            job.status = JobStatus.QUEUED
            job.error = "Recovered after interrupted process"
            self._store.save(job)
            self._store.log_event(job.id, "recovered")
            recovered += 1
        return recovered

    def _execute_job(self, job_id: str, stop: threading.Event, pause: threading.Event) -> None:
        trace = TraceContext.current()
        try:
            job = self._require(job_id)
            self._quota.bind_thread(job_id)
            completed: Set[str] = {step.id for step in job.steps if step.status == StepStatus.COMPLETED}
            for index, step in enumerate(job.steps):
                if stop.is_set():
                    break
                while pause.is_set() and not stop.is_set():
                    time.sleep(0.05)
                if stop.is_set():
                    break
                if step.status == StepStatus.COMPLETED:
                    continue
                if not all(dependency in completed for dependency in step.depends_on):
                    step.status = StepStatus.SKIPPED
                    step.error = "Dependencies not satisfied"
                    self._store.save(job)
                    continue
                job.current_step_index = index
                self._store.save(job)
                if step.requires_auth and not step.auth_token:
                    step.status = StepStatus.AWAITING_AUTH
                    self._store.save(job)
                    self._store.log_event(job.id, "awaiting_auth", step.id)
                    while not stop.is_set() and not step.auth_token:
                        transient_token = self._authorized_tokens.get((job_id, step.id))
                        if transient_token:
                            step.auth_token = transient_token
                            step.status = StepStatus.PENDING
                            break
                        refreshed = self._store.get(job_id)
                        if refreshed is None:
                            return
                        refreshed_step = next((item for item in refreshed.steps if item.id == step.id), None)
                        if refreshed_step is None:
                            raise RuntimeError(f"step disappeared: {step.id}")
                        if refreshed_step.auth_token and refreshed_step.auth_token != "[redacted]":
                            step.auth_token = refreshed_step.auth_token
                        step.authorized_by = refreshed_step.authorized_by
                        if not step.auth_token:
                            time.sleep(0.1)
                    if stop.is_set():
                        break
                    if not step.auth_token:
                        continue
                    step.status = StepStatus.PENDING
                if self._execute_step(job, step, stop, trace):
                    completed.add(step.id)
                elif stop.is_set():
                    break
                else:
                    job.status = JobStatus.FAILED
                    job.error = f"Step {step.id} failed: {step.error}"
                    break

            latest = self._store.get(job_id)
            if latest and latest.status == JobStatus.CANCELLED:
                return
            if stop.is_set():
                job.status = JobStatus.CANCELLED
                job.error = job.error or "Cancelled by user"
            elif job.status not in (JobStatus.FAILED, JobStatus.CANCELLED):
                job.status = (
                    JobStatus.COMPLETED
                    if all(step.status in (StepStatus.COMPLETED, StepStatus.SKIPPED) for step in job.steps)
                    else JobStatus.FAILED
                )
                if job.status is JobStatus.COMPLETED:
                    job.result = {step.id: step.result for step in job.steps}
            self._store.save(job)
            self._store.log_event(job.id, "finished", job.status.value)
        except Exception as exc:
            logger.exception("job_execution_error", extra={"job_id": job_id, "request_id": trace.request_id})
            job = self._store.get(job_id)
            if job and job.status != JobStatus.CANCELLED:
                job.status = JobStatus.FAILED
                job.error = str(exc)
                self._store.save(job)
                self._store.log_event(job.id, "crashed", str(exc))
        finally:
            with self._lock:
                self._running.pop(job_id, None)
                self._paused.pop(job_id, None)
                self._threads.pop(job_id, None)
            self._quota.release(job_id)

    def _execute_step(self, job: Job, step: JobStep, stop: threading.Event, trace: TraceContext) -> bool:
        retries = max(0, min(int(step.max_retries), 10))
        for attempt in range(retries + 1):
            if stop.is_set():
                step.status = StepStatus.CANCELLED
                self._store.save(job)
                return False
            quota_error = self._quota.check_quota(job.id)
            if quota_error:
                step.status = StepStatus.FAILED
                step.error = quota_error
                self._store.save(job)
                self._dlq.enqueue(job.id, step.id, quota_error, step.retry_count)
                return False
            step.retry_count = attempt
            step.status = StepStatus.RUNNING
            step.started_at = time.time()
            step.completed_at = None
            self._store.save(job)
            try:
                result = self._execute_with_timeout(step, trace, job_id=job.id)
                if isinstance(result, dict) and result.get("ok") is False:
                    raise RuntimeError(str(result.get("error", "step returned ok=false")))
                # Validate step output against tool output schema if available
                if step.tool_call and self._tools:
                    spec = getattr(self._tools, "get", lambda _: None)(step.tool_call.name)
                    output_schema = getattr(spec, "output_schema", None)
                    if output_schema:
                        self._validator.validate_or_raise(result, output_schema)
                step.result = result
                step.status = StepStatus.COMPLETED
                step.error = None
                step.completed_at = time.time()
                self._store.save(job)
                self._store.log_event(job.id, "step_completed", step.id)
                return True
            except Exception as exc:
                step.error = str(exc)
                step.completed_at = time.time()
                if attempt < retries:
                    self._store.log_event(job.id, "step_retry", f"{step.id}: attempt={attempt + 1}; error={exc}")
                    time.sleep(min(0.25 * (2**attempt), 3.0))
                    continue
                step.status = StepStatus.FAILED
                self._store.save(job)
                self._store.log_event(job.id, "step_failed", f"{step.id}: {exc}")
                self._dlq.enqueue(job.id, step.id, str(exc), step.retry_count)
                return False
        return False

    def _execute_with_timeout(self, step: JobStep, trace: TraceContext, job_id: str = "") -> Any:
        """Bound how long the job worker waits for a step result.

        Python cannot safely kill an arbitrary running thread. Timeout cancellation is
        therefore cooperative at the job boundary; tool handlers must implement their
        own network/process timeouts to guarantee hard stop of side effects.
        """
        if step.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")

        def target() -> Any:
            trace.apply()
            if step.tool_call:
                return self._execute_tool_step(step, job_id)
            if step.agent_name or step.agent_task:
                return self._execute_agent_step(step, job_id)
            raise ValueError("Step has neither tool_call nor agent task")

        lease = None
        if self._resource_governor is not None:
            lease = self._resource_governor.acquire(
                f"job:{job_id}:{step.id}",
                slots=1,
                background=True,
            )
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="jarvis-step")
        future = executor.submit(target)
        with self._future_lock:
            self._active_futures[job_id] = future
        timed_out = False
        try:
            return future.result(timeout=step.timeout_seconds)
        except concurrent.futures.TimeoutError as exc:
            timed_out = True
            future.cancel()
            raise RuntimeError(f"step timed out after {step.timeout_seconds}s") from exc
        finally:
            with self._future_lock:
                self._active_futures.pop(job_id, None)
            executor.shutdown(wait=not timed_out, cancel_futures=True)
            if lease is not None:
                self._resource_governor.release(lease)

    def _execute_tool_step(self, step: JobStep, job_id: str = "") -> Any:
        if not self._tools:
            raise RuntimeError("Tool service unavailable")
        tool_call = step.tool_call
        if tool_call is None:
            raise RuntimeError("tool step missing tool call")
        spec = getattr(self._tools, "get", lambda _: None)(tool_call.name)
        if spec is not None and getattr(spec, "parameters", None):
            self._validator.validate_or_raise(tool_call.arguments, spec.parameters)
        breaker = self._circuit_breakers.get(tool_call.name)
        job = self._store.get(job_id) if job_id else None
        kwargs: Dict[str, Any] = {"approval_token": step.auth_token or tool_call.approval_token, "idempotency_key": tool_call.idempotency_key}
        if job and job.metadata.get("autonomous"):
            kwargs["agent_name"] = step.agent_name or "general"
            kwargs["mission_id"] = job.metadata.get("mission_id")
        return breaker.call(self._tools.execute, tool_call.name, tool_call.arguments, **kwargs)

    def _execute_agent_step(self, step: JobStep, job_id: str = "") -> Any:
        if not self._agents:
            raise RuntimeError("Agent service unavailable")
        runner = getattr(self._agents, "run_task", None)
        if not callable(runner):
            raise RuntimeError("Agent execution adapter unavailable")
        task_type = step.agent_name or "general"
        if task_type.lower() == "general_agent":
            task_type = "general"
        # Agent steps also use circuit breaker for resilience
        breaker = self._circuit_breakers.get(f"agent:{task_type}")
        arguments = {"task": step.agent_task or step.name}
        job = self._store.get(job_id) if job_id else None
        if job and job.metadata.get("autonomous"):
            arguments["mission_id"] = job.metadata.get("mission_id")
        return breaker.call(runner, task_type, arguments)

    def get_stats(self) -> Dict[str, Any]:
        jobs = self._store.list_jobs(limit=1000)
        terminal = [job for job in jobs if job.status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED)]
        return {
            "total": len(jobs),
            "by_status": {status.value: sum(job.status == status for job in jobs) for status in JobStatus},
            "avg_duration_ms": sum((job.updated_at - job.created_at) * 1000 for job in terminal) / max(len(terminal), 1),
            "queue_depth": sum(job.status in (JobStatus.QUEUED, JobStatus.PENDING) for job in jobs),
            "quota": self._quota.current_usage(),
            "dlq": self._dlq.get_stats(),
            "idempotency": self._idempotency.get_stats(),
            "circuit_breakers": self._circuit_breakers.all_stats(),
        }

    def shutdown(self, join_timeout: float = 5.0) -> None:
        """Request cooperative cancellation, cancel active futures, and join workers."""
        self._dispatcher_stop.set()
        dispatcher = self._dispatcher
        if dispatcher.is_alive():
            dispatcher.join(min(1.0, max(0.0, join_timeout)))

        # Cancel all active step futures
        with self._future_lock:
            futures = list(self._active_futures.items())
        for job_id, future in futures:
            if not future.done():
                future.cancel()
                logger.info("step_future_cancelled", extra={"job_id": job_id})

        with self._lock:
            threads = list(self._threads.values())
            for event in self._running.values():
                event.set()

        # Persist in-flight job states before forced termination
        try:
            running_jobs = [self._store.get(jid) for jid in self._running.keys()]
            for job in running_jobs:
                if job and job.status == JobStatus.RUNNING:
                    job.status = JobStatus.QUEUED
                    job.error = "Recovered after graceful shutdown"
                    self._store.save(job)
                    self._store.log_event(job.id, "shutdown_recovered")
        except Exception as exc:
            logger.exception("shutdown_persist_failed", extra={"error": str(exc)})

        deadline = time.monotonic() + max(0.0, join_timeout)
        for thread in threads:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            thread.join(remaining)

    def _require(self, job_id: str) -> Job:
        job = self._store.get(job_id)
        if job is None:
            raise ValueError(f"Job not found: {job_id}")
        return job

    @staticmethod
    def _validate_steps(steps: List[JobStep]) -> None:
        if not steps:
            raise ValueError("At least one job step is required")
        ids = [str(step.id).strip() for step in steps]
        if any(not step_id for step_id in ids):
            raise ValueError("Step ids are required")
        if len(ids) != len(set(ids)):
            raise ValueError("Duplicate step ids")
        known = set(ids)
        for step in steps:
            if any(dep == step.id for dep in step.depends_on):
                raise ValueError(f"Step {step.id} cannot depend on itself")
            if any(dep not in known for dep in step.depends_on):
                raise ValueError(f"Unknown dependency in step {step.id}")
            if step.tool_call and (step.agent_name or step.agent_task):
                raise ValueError(f"Step {step.id} cannot contain both tool and agent execution")
            if step.timeout_seconds <= 0 or step.timeout_seconds > 3600:
                raise ValueError(f"Invalid timeout for step {step.id}")



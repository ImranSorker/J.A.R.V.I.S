"""Governed autonomous artifact build pipeline.

The factory converts a validated build specification into an artifact through a
bounded generate/validate/repair loop. Generation is always injected; this
module never gives a model direct filesystem or process authority.
"""
from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import dataclass, field
from typing import Callable, Mapping

from core.creation_fabric import BuildRequest, BuildResult, CreationFabric

Generator = Callable[[BuildRequest, str | None], str]
Validator = Callable[[BuildRequest, str], tuple[bool, str | None]]


@dataclass(frozen=True, slots=True)
class ArtifactSpecification:
    """Bounded specification for one generated artifact."""

    name: str
    kind: str
    description: str
    filename: str
    language: str = "text"
    acceptance: tuple[str, ...] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ArtifactBuildReport:
    """Immutable outcome of the governed build pipeline."""

    ok: bool
    attempts: int
    result: BuildResult | None
    specification_hash: str
    validation_errors: tuple[str, ...] = ()


class ArtifactFactory:
    """Build tools, utilities and artifacts with bounded self-repair."""

    def __init__(self, fabric: CreationFabric, *, max_attempts: int = 3, validator: Validator | None = None) -> None:
        self.fabric = fabric
        self.max_attempts = max(1, min(int(max_attempts), 8))
        self.validator = validator or self._default_validator

    def build(
        self,
        specification: ArtifactSpecification,
        *,
        generator: Generator,
        approved: bool,
        authorization_token: str | None = None,
    ) -> ArtifactBuildReport:
        """Generate, validate, bounded-repair, and atomically publish an artifact."""
        request = BuildRequest(
            specification.name,
            specification.kind,
            specification.description,
            specification.filename,
            specification.language,
            specification.metadata,
        )
        canonical = json.dumps(
            {
                "name": specification.name,
                "kind": specification.kind,
                "description": specification.description,
                "filename": specification.filename,
                "language": specification.language,
                "acceptance": specification.acceptance,
                "metadata": dict(specification.metadata),
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        specification_hash = hashlib.sha256(canonical).hexdigest()
        errors: list[str] = []
        feedback: str | None = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                content = generator(request, feedback)
            except Exception as exc:
                errors.append(f"generation:{type(exc).__name__}:{exc}")
                feedback = errors[-1]
                continue
            valid, error = self.validator(request, content)
            if not valid:
                feedback = error or "validation failed"
                errors.append(f"validation:{feedback}")
                continue
            result = self.fabric.build(
                request,
                source=content,
                approved=approved,
                authorization_token=authorization_token,
            )
            if result.ok:
                return ArtifactBuildReport(True, attempt, result, specification_hash, tuple(errors))
            feedback = result.error or "artifact build failed"
            errors.append(f"build:{feedback}")
        return ArtifactBuildReport(False, self.max_attempts, None, specification_hash, tuple(errors[-self.max_attempts :]))

    @staticmethod
    def _default_validator(request: BuildRequest, content: str) -> tuple[bool, str | None]:
        """Perform deterministic syntax/format validation before publication."""
        if not content.strip():
            return False, "content is empty"
        if request.kind in {"json", "workflow"}:
            try:
                json.loads(content)
            except json.JSONDecodeError as exc:
                return False, f"invalid JSON: {exc.msg}"
        if request.language == "python":
            try:
                tree = ast.parse(content, filename=request.filename)
            except SyntaxError as exc:
                return False, f"invalid Python syntax: {exc.msg}"
            if not any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) for node in tree.body):
                return False, "Python artifact must declare a function, async function, or class"
        return True, None



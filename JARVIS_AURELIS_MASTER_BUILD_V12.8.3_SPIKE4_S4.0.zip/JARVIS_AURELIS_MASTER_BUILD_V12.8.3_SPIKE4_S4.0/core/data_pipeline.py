"""Bounded data-pipeline primitives adapted for JARVIS autonomous workflows."""
from __future__ import annotations
import hashlib, logging, time
from dataclasses import dataclass, field
from typing import Any, Callable, List
logger=logging.getLogger("jarvis.data_pipeline")
@dataclass(frozen=True)
class PipelineStage:
    name:str; handler:Callable[[Any],Any]; max_output_items:int=10000
@dataclass
class PipelineResult:
    ok:bool; data:Any=None; errors:List[str]=field(default_factory=list); stages:int=0; elapsed_ms:float=0.0; checksum:str=""
class DataPipeline:
    """Execute registered transforms with deterministic bounds and provenance."""
    def __init__(self,max_input_items:int=100000,max_payload_bytes:int=10_000_000)->None:self.max_input_items=max_input_items;self.max_payload_bytes=max_payload_bytes;self._stages:List[PipelineStage]=[]
    def add_stage(self,name:str,handler:Callable[[Any],Any],max_output_items:int=10000)->None:
        if not name or not callable(handler) or max_output_items<1:raise ValueError("invalid pipeline stage")
        self._stages.append(PipelineStage(name,handler,int(max_output_items)))
    def run(self,data:Any)->PipelineResult:
        start=time.perf_counter(); current=data; errors=[]
        if isinstance(current,(list,tuple)) and len(current)>self.max_input_items:return PipelineResult(False,errors=["input item limit exceeded"])
        try:
            payload=repr(current).encode("utf-8")
            if len(payload)>self.max_payload_bytes:return PipelineResult(False,errors=["input payload limit exceeded"])
        except Exception as exc:return PipelineResult(False,errors=[f"input serialization failed: {exc}"])
        for stage in self._stages:
            try:
                current=stage.handler(current)
                if isinstance(current,(list,tuple)) and len(current)>stage.max_output_items:raise ValueError(f"stage {stage.name} output limit exceeded")
            except Exception as exc:
                errors.append(f"{stage.name}: {exc}");logger.exception("pipeline_stage_failed",extra={"stage":stage.name});return PipelineResult(False,current,errors,len(errors), (time.perf_counter()-start)*1000)
        digest=hashlib.sha256(repr(current).encode("utf-8")).hexdigest(); return PipelineResult(True,current,[],len(self._stages),(time.perf_counter()-start)*1000,digest)



"""State-of-the-art platform services for J.A.R.V.I.S. V12.8.0.

The module provides production-oriented primitives for identity, attestation,
certificate lifecycle, isolated plugins, inference optimization, observability,
distributed memory, device management, MCP application metadata, policy
editing, operator roles, and autonomous optimization. External runtimes are
optional; every service fails closed and exposes explicit capability state.
"""
from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import os
import platform
import secrets
import sqlite3
import statistics
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
except ImportError:  # pragma: no cover - guarded by mandatory dependency in pyproject
    x509 = None  # type: ignore[assignment]
    hashes = serialization = ec = None  # type: ignore[assignment]
    ExtendedKeyUsageOID = NameOID = None  # type: ignore[assignment]


from core.kernel_12_8_0.frontier_extensions import CapabilityAttenuator, ErrorBudgetController, PredictiveDependencyTwin, QualityDriftMonitor, ResourceHeatmap, TwinNode
from core.frontier_batch import FrontierBatchFabric
from core.supreme_runtime import SupremeRuntimeFabric
from core.frontier_completion import (
    ArtifactQuarantineManager,
    CapturePrivacyPolicy,
    ClipboardIntelligence,
    EmbeddingModelRegistry,
    EmpiricalBenchmarkRunner,
    EncryptedSnapshotStore,
    LANPairingAuthority,
    MissionNodePolicyGate,
    ModelLifecycleManager,
    ProactiveScheduler,
    StartupDependencyGraph,
    StartupNode,
    VoiceActivityDetector,
    WorldStateProjection,
)


class PlatformSecurityError(PermissionError):
    """Raised when a platform security invariant is violated."""


@dataclass(frozen=True, slots=True)
class WorkloadIdentity:
    """Short-lived workload identity with SPIFFE-compatible identifier semantics."""

    workload_id: str
    spiffe_id: str
    issued_at: float
    expires_at: float
    fingerprint: str
    signature: str


class WorkloadIdentityAuthority:
    """Issue, rotate and revoke short-lived workload identities."""

    def __init__(self, secret: bytes | None = None, *, trust_domain: str = "jarvis.local", ttl_seconds: float = 3600.0) -> None:
        self._secret = bytes(secret) if secret else secrets.token_bytes(32)
        if len(self._secret) < 32:
            raise ValueError("identity secret must be at least 32 bytes")
        self.trust_domain = str(trust_domain).strip().lower()
        if not self.trust_domain or "/" in self.trust_domain:
            raise ValueError("invalid SPIFFE trust domain")
        self.ttl_seconds = max(60.0, min(float(ttl_seconds), 24 * 3600.0))
        self._revoked: set[str] = set()
        self._lock = threading.RLock()

    def issue(self, workload_id: str, *, selectors: Iterable[str] = ()) -> WorkloadIdentity:
        """Issue one short-lived workload credential."""
        wid = str(workload_id).strip()
        if not wid or any(ch.isspace() for ch in wid):
            raise ValueError("workload_id must be non-empty and whitespace-free")
        selector_tuple = tuple(sorted({str(item).strip() for item in selectors if str(item).strip()}))
        fp = hashlib.sha256("|".join(selector_tuple).encode()).hexdigest()
        now = time.time()
        expires = now + self.ttl_seconds
        spiffe_id = f"spiffe://{self.trust_domain}/{wid}"
        canonical = f"{wid}|{spiffe_id}|{now:.6f}|{expires:.6f}|{fp}".encode()
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        with self._lock:
            self._revoked.discard(wid)
        return WorkloadIdentity(wid, spiffe_id, now, expires, fp, signature)

    def verify(self, identity: WorkloadIdentity, *, audience: str | None = None, now: float | None = None) -> bool:
        """Verify authenticity, freshness, trust domain and optional audience."""
        current = time.time() if now is None else float(now)
        if identity.expires_at <= current or identity.issued_at > current + 5.0:
            return False
        with self._lock:
            if identity.workload_id in self._revoked:
                return False
        expected_spiffe = f"spiffe://{self.trust_domain}/{identity.workload_id}"
        if identity.spiffe_id != expected_spiffe:
            return False
        if audience and not audience.startswith("jarvis:"):
            return False
        canonical = f"{identity.workload_id}|{identity.spiffe_id}|{identity.issued_at:.6f}|{identity.expires_at:.6f}|{identity.fingerprint}".encode()
        expected = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        return hmac.compare_digest(identity.signature, expected)

    def revoke(self, workload_id: str) -> None:
        """Revoke future use of one workload identity."""
        with self._lock:
            self._revoked.add(str(workload_id).strip())

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret authority state."""
        with self._lock:
            return {"trust_domain": self.trust_domain, "revoked": len(self._revoked), "ttl_seconds": self.ttl_seconds}


@dataclass(frozen=True, slots=True)
class WebAuthnChallenge:
    """Single-use WebAuthn challenge bound to an operator and purpose."""

    challenge_id: str
    challenge: str
    operator_id: str
    purpose: str
    expires_at: float
    consumed: bool = False


class WebAuthnControlPlane:
    """Relying-party challenge registry and ES256 assertion verifier.

    The browser/authenticator ceremony remains a platform operation; this
    server-side layer enforces challenge freshness, origin binding and
    signature verification for registered P-256 credentials.
    """

    def __init__(self, *, rp_id: str = "localhost", origin: str = "http://localhost:8000", ttl_seconds: float = 120.0, require_user_verification: bool = True) -> None:
        self.rp_id = str(rp_id).strip()
        self.origin = str(origin).strip().rstrip("/")
        self.ttl_seconds = max(30.0, min(float(ttl_seconds), 600.0))
        self.require_user_verification = bool(require_user_verification)
        self._credentials: dict[str, tuple[str, Any, int]] = {}
        self._challenges: dict[str, WebAuthnChallenge] = {}
        self._lock = threading.RLock()

    def register_credential(self, credential_id: str, public_key_pem: bytes, *, operator_id: str) -> None:
        """Register a P-256 public key for one operator."""
        if ec is None or serialization is None:
            raise RuntimeError("cryptography package unavailable")
        key_id = str(credential_id).strip()
        if not key_id or not operator_id.strip():
            raise ValueError("credential_id and operator_id are required")
        key = serialization.load_pem_public_key(bytes(public_key_pem))
        if not isinstance(key, ec.EllipticCurvePublicKey) or key.curve.name != "secp256r1":
            raise ValueError("only P-256 WebAuthn credentials are supported")
        with self._lock:
            self._credentials[key_id] = (str(operator_id).strip(), key, 0)

    def begin(self, operator_id: str, *, purpose: str = "control") -> WebAuthnChallenge:
        """Create a single-use challenge."""
        op = str(operator_id).strip()
        if not op:
            raise ValueError("operator_id is required")
        now = time.time()
        challenge = WebAuthnChallenge(uuid.uuid4().hex, base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("="), op, str(purpose).strip() or "control", now + self.ttl_seconds)
        with self._lock:
            self._challenges[challenge.challenge_id] = challenge
        return challenge

    def verify_assertion(self, challenge_id: str, credential_id: str, signature_der: bytes, *, client_data_json: bytes, authenticator_data: bytes, operator_id: str, origin: str | None = None) -> bool:
        """Verify a WebAuthn assertion signature and consume the challenge."""
        with self._lock:
            challenge = self._challenges.get(str(challenge_id))
            credential = self._credentials.get(str(credential_id))
            if challenge is None or credential is None or challenge.consumed:
                return False
            if challenge.expires_at <= time.time() or credential[0] != str(operator_id).strip() or challenge.operator_id != str(operator_id).strip():
                return False
        try:
            client = json.loads(bytes(client_data_json).decode("utf-8"))
            if client.get("type") != "webauthn.get":
                return False
            client_origin = str(client.get("origin", "")).rstrip("/")
            expected_origin = str(origin or self.origin).rstrip("/")
            if client_origin != expected_origin:
                return False
            challenge_text = str(client.get("challenge", ""))
            if challenge_text != challenge.challenge:
                return False
            if len(authenticator_data) < 37:
                return False
            expected_rp_hash = hashlib.sha256(self.rp_id.encode("utf-8")).digest()
            if bytes(authenticator_data[:32]) != expected_rp_hash:
                return False
            flags = authenticator_data[32]
            if not (flags & 0x01):
                return False
            if self.require_user_verification and not (flags & 0x04):
                return False
            counter = int.from_bytes(authenticator_data[33:37], "big")
            if counter and counter <= credential[2]:
                return False
            client_hash = hashlib.sha256(bytes(client_data_json)).digest()
            credential[1].verify(bytes(signature_der), bytes(authenticator_data) + client_hash, ec.ECDSA(hashes.SHA256()))
        except Exception:
            return False
        with self._lock:
            # Re-check both challenge state and authenticator counter after the
            # relatively expensive signature verification. This closes the
            # concurrent double-spend window where two requests verify the same
            # challenge against the same counter.
            current = self._challenges.get(challenge.challenge_id)
            previous = self._credentials.get(credential_id)
            now = time.time()
            if (
                current is None
                or current.consumed
                or current.expires_at <= now
                or previous is None
                or previous[0] != challenge.operator_id
            ):
                return False
            previous_counter = int(previous[2])
            if counter and counter <= previous_counter:
                return False
            self._credentials[credential_id] = (previous[0], previous[1], counter)
            self._challenges[challenge.challenge_id] = WebAuthnChallenge(
                challenge.challenge_id, challenge.challenge, challenge.operator_id,
                challenge.purpose, challenge.expires_at, True
            )
        return True

    def consume_authorization(self, challenge_id: str, *, operator_id: str, purpose: str) -> bool:
        """Consume a previously verified ceremony as a short-lived step-up grant.

        Verification and consumption are separate operations so the API can issue
        a narrow authorization artifact after the authenticator ceremony.
        """
        op = str(operator_id).strip()
        expected_purpose = str(purpose).strip() or "control"
        with self._lock:
            challenge = self._challenges.get(str(challenge_id))
            if challenge is None or not challenge.consumed:
                return False
            if challenge.operator_id != op or challenge.purpose != expected_purpose:
                return False
            if challenge.expires_at <= time.time():
                return False
            self._challenges.pop(challenge.challenge_id, None)
            return True

    def snapshot(self) -> dict[str, Any]:
        """Return safe control-plane metrics."""
        with self._lock:
            return {"rp_id": self.rp_id, "origin": self.origin, "credentials": len(self._credentials), "challenges": len(self._challenges), "require_user_verification": self.require_user_verification}


@dataclass(frozen=True, slots=True)
class CertificateRecord:
    """Certificate lifecycle record with issuer binding."""

    subject: str
    serial: str
    issued_at: float
    expires_at: float
    fingerprint_sha256: str
    revoked: bool = False
    issuer_fingerprint_sha256: str = ""


class CertificateLifecycle:
    """Durable local CA lifecycle with encrypted key state, rollover and revocation."""

    STATE_VERSION = 2

    def __init__(
        self,
        *,
        common_name: str = "jarvis-ca",
        ttl_seconds: float = 86400.0,
        state_path: str | Path | None = None,
        secret: bytes | None = None,
    ) -> None:
        if x509 is None or ec is None or hashes is None or serialization is None:
            raise RuntimeError("cryptography package unavailable")
        self._lock = threading.RLock()
        self._ttl = max(300.0, min(float(ttl_seconds), 30 * 86400.0))
        self._common_name = str(common_name).strip() or "jarvis-ca"
        self._state_path = Path(state_path).resolve() if state_path is not None else None
        if self._state_path is not None and secret is None:
            raise ValueError("persistent certificate lifecycle requires a secret")
        self._secret = hashlib.sha256(bytes(secret)).digest() if secret is not None else None
        self._records: dict[str, CertificateRecord] = {}
        self._cert_pem_by_serial: dict[str, bytes] = {}
        self._trusted_ca_pems: list[bytes] = []
        self._max_rollover_roots = 8
        loaded = self._load()
        if loaded is None:
            self._ca_key = ec.generate_private_key(ec.SECP256R1())
            self._ca = self._create_ca(self._ca_key)
            self._persist()
        else:
            self._ca_key, self._ca, self._trusted_ca_pems, self._records, self._cert_pem_by_serial = loaded

    def _state_key(self) -> bytes:
        if self._secret is None:
            raise RuntimeError("certificate persistence key is unavailable")
        return hashlib.sha256(self._secret + b"\0certificate-lifecycle-v2").digest()

    def _legacy_state_keys(self) -> tuple[bytes, ...]:
        """Return historical derivations accepted only for one-time migration."""
        if self._secret is None:
            raise RuntimeError("certificate persistence key is unavailable")
        return (
            hashlib.sha256(self._secret + b"\\0certificate-lifecycle-v2").digest(),
            hashlib.sha256(self._secret + b"\0certificate-lifecycle-v2").digest(),
        )

    def _create_ca(self, key: Any) -> Any:
        now = datetime.now(timezone.utc)
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, self._common_name)])
        return (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(subject)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(minutes=1))
            .not_valid_after(now + timedelta(seconds=self._ttl))
            .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
            .sign(key, hashes.SHA256())
        )

    @staticmethod
    def _fp(cert: Any) -> str:
        return hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()

    def _persist(self) -> None:
        if self._state_path is None:
            return
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        import base64 as _b64
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        raw = self._ca_key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        nonce = secrets.token_bytes(12)
        cipher = nonce + AESGCM(self._state_key()).encrypt(nonce, raw, self._common_name.encode())
        document = {
            "version": self.STATE_VERSION,
            "common_name": self._common_name,
            "ttl_seconds": self._ttl,
            "ca_pem_b64": _b64.b64encode(self._ca.public_bytes(serialization.Encoding.PEM)).decode("ascii"),
            "ca_private_cipher_b64": _b64.b64encode(cipher).decode("ascii"),
            "trusted_ca_pems_b64": [_b64.b64encode(item).decode("ascii") for item in self._trusted_ca_pems],
            "records": {serial: asdict(record) for serial, record in sorted(self._records.items())},
            "cert_pem_b64": {serial: _b64.b64encode(pem).decode("ascii") for serial, pem in sorted(self._cert_pem_by_serial.items())},
        }
        fd, temp = __import__("tempfile").mkstemp(prefix=self._state_path.name + ".", dir=self._state_path.parent)
        try:
            if hasattr(os, "fchmod"):
                os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(document, handle, sort_keys=True, separators=(",", ":"))
                handle.write("\n")
                handle.flush(); os.fsync(handle.fileno())
            os.replace(temp, self._state_path)
            os.chmod(self._state_path, 0o600)
        finally:
            Path(temp).unlink(missing_ok=True)

    def _load(self) -> tuple[Any, Any, list[bytes], dict[str, CertificateRecord], dict[str, bytes]] | None:
        if self._state_path is None or not self._state_path.exists():
            return None
        try:
            import base64 as _b64
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            document = json.loads(self._state_path.read_text(encoding="utf-8"))
            if int(document.get("version", 0)) != self.STATE_VERSION or str(document.get("common_name")) != self._common_name:
                raise ValueError("unsupported certificate lifecycle state")
            encrypted = _b64.b64decode(str(document["ca_private_cipher_b64"]), validate=True)
            try:
                raw = AESGCM(self._state_key()).decrypt(encrypted[:12], encrypted[12:], self._common_name.encode())
                migrated = False
            except Exception:
                raw = None
                last_error: Exception | None = None
                for legacy_key in self._legacy_state_keys():
                    try:
                        raw = AESGCM(legacy_key).decrypt(encrypted[:12], encrypted[12:], self._common_name.encode())
                        migrated = True
                        break
                    except Exception as exc:
                        last_error = exc
                if raw is None:
                    assert last_error is not None
                    raise last_error
            key = serialization.load_der_private_key(raw, password=None)
            ca = x509.load_pem_x509_certificate(_b64.b64decode(str(document["ca_pem_b64"]), validate=True))
            if ca.public_key().public_numbers() != key.public_key().public_numbers():
                raise ValueError("CA key/certificate mismatch")
            trusted = [_b64.b64decode(value, validate=True) for value in document.get("trusted_ca_pems_b64", [])]
            records = {str(serial): CertificateRecord(**dict(payload)) for serial, payload in dict(document.get("records", {})).items()}
            certs = {str(serial): _b64.b64decode(value, validate=True) for serial, value in dict(document.get("cert_pem_b64", {})).items()}
            if migrated:
                # Rewrite immediately with the hardened derivation; the old key is never retained.
                self._ca_key, self._ca, self._trusted_ca_pems, self._records, self._cert_pem_by_serial = key, ca, trusted, records, certs
                self._persist()
            return key, ca, trusted, records, certs
        except Exception as exc:
            raise RuntimeError(f"certificate lifecycle state load failed: {type(exc).__name__}: {exc}") from exc

    @property
    def ca_certificate_pem(self) -> bytes:
        """Return the active CA certificate."""
        return self._ca.public_bytes(serialization.Encoding.PEM)

    def trust_bundle_pem(self) -> bytes:
        """Return a deterministic PEM bundle containing active and rollover roots."""
        return b"".join([self.ca_certificate_pem, *self._trusted_ca_pems])

    def issue(self, subject_name: str, *, spiffe_id: str | None = None) -> tuple[CertificateRecord, bytes, bytes]:
        """Issue a short-lived client certificate bound to the active CA."""
        subject = str(subject_name).strip()
        if not subject:
            raise ValueError("subject_name is required")
        if spiffe_id is not None and not str(spiffe_id).startswith("spiffe://"):
            raise ValueError("spiffe_id must use the spiffe:// URI scheme")
        now = datetime.now(timezone.utc)
        key = ec.generate_private_key(ec.SECP256R1())
        builder = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, subject)]))
            .issuer_name(self._ca.subject)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(minutes=1))
            .not_valid_after(now + timedelta(seconds=self._ttl))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
        )
        if spiffe_id:
            builder = builder.add_extension(x509.SubjectAlternativeName([x509.UniformResourceIdentifier(str(spiffe_id))]), critical=False)
        cert = builder.sign(self._ca_key, hashes.SHA256())
        pem = cert.public_bytes(serialization.Encoding.PEM)
        key_pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        record = CertificateRecord(
            subject,
            str(cert.serial_number),
            cert.not_valid_before_utc.timestamp(),
            cert.not_valid_after_utc.timestamp(),
            self._fp(cert),
            False,
            self._fp(self._ca),
        )
        with self._lock:
            self._records[record.serial] = record
            self._cert_pem_by_serial[record.serial] = pem
            self._persist()
        return record, pem, key_pem

    def rotate_ca(self, *, revoke_existing: bool = True) -> bytes:
        """Rotate the active CA and optionally revoke all currently issued certificates."""
        with self._lock:
            self._trusted_ca_pems.append(self.ca_certificate_pem)
            if len(self._trusted_ca_pems) > self._max_rollover_roots:
                del self._trusted_ca_pems[: len(self._trusted_ca_pems) - self._max_rollover_roots]
            self._ca_key = ec.generate_private_key(ec.SECP256R1())
            self._ca = self._create_ca(self._ca_key)
            if revoke_existing:
                self._records = {
                    serial: CertificateRecord(item.subject, item.serial, item.issued_at, item.expires_at, item.fingerprint_sha256, True, item.issuer_fingerprint_sha256)
                    for serial, item in self._records.items()
                }
            self._persist()
            return self.ca_certificate_pem

    def revoke(self, serial: str) -> bool:
        """Revoke one issued certificate record."""
        with self._lock:
            item = self._records.get(str(serial))
            if item is None:
                return False
            self._records[str(serial)] = CertificateRecord(item.subject, item.serial, item.issued_at, item.expires_at, item.fingerprint_sha256, True, item.issuer_fingerprint_sha256)
            self._persist()
            return True

    def is_revoked(self, serial: str) -> bool:
        """Return current revocation state; unknown serials fail closed."""
        with self._lock:
            item = self._records.get(str(serial))
            return item is None or item.revoked

    def verify_certificate(self, cert_pem: bytes, *, now: float | None = None) -> bool:
        """Verify chain signature, validity, client-auth usage and lifecycle revocation."""
        try:
            cert = x509.load_pem_x509_certificate(bytes(cert_pem))
            serial = str(cert.serial_number)
            current = time.time() if now is None else float(now)
            with self._lock:
                record = self._records.get(serial)
                roots = [self._ca] + [x509.load_pem_x509_certificate(item) for item in self._trusted_ca_pems]
            if record is None or record.revoked or record.expires_at <= current:
                return False
            if self._fp(cert) != record.fingerprint_sha256:
                return False
            for root in roots:
                if record.issuer_fingerprint_sha256 == self._fp(root):
                    root.public_key().verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(cert.signature_hash_algorithm))
                    usages = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
                    return ExtendedKeyUsageOID.CLIENT_AUTH in usages
            return False
        except Exception:
            return False

    def snapshot(self) -> dict[str, Any]:
        """Return safe lifecycle metrics without private key material."""
        with self._lock:
            return {"issued": len(self._records), "revoked": sum(item.revoked for item in self._records.values()), "ttl_seconds": self._ttl, "ca_fingerprint_sha256": self._fp(self._ca), "rollover_roots": len(self._trusted_ca_pems), "persistent": self._state_path is not None}


@dataclass(frozen=True, slots=True)
class PluginPackage:
    """Signed/admitted plugin package metadata."""

    plugin_id: str
    version: str
    runtime: str
    digest_sha256: str
    capabilities: tuple[str, ...]
    admitted: bool
    reason: str


class WASIPluginRuntime:
    """Portable WASI/WASM package admission and optional execution facade."""

    MAGIC = b"\x00asm"

    def __init__(self, *, allowed_capabilities: Iterable[str] = (), require_signature: bool = True) -> None:
        self.allowed_capabilities = frozenset(str(item) for item in allowed_capabilities if str(item).strip())
        self.require_signature = bool(require_signature)

    def admit(self, plugin_id: str, version: str, payload: bytes, *, capabilities: Iterable[str], signature: bytes | None = None, signer: Callable[[bytes, bytes], bool] | None = None) -> PluginPackage:
        """Validate WASM magic, digest, capabilities and optional signature."""
        caps = tuple(sorted({str(item).strip() for item in capabilities if str(item).strip()}))
        digest = hashlib.sha256(bytes(payload)).hexdigest()
        if bytes(payload[:4]) != self.MAGIC:
            return PluginPackage(plugin_id, version, "wasm", digest, caps, False, "invalid wasm binary")
        if not set(caps).issubset(self.allowed_capabilities):
            return PluginPackage(plugin_id, version, "wasm", digest, caps, False, "capability denied")
        if self.require_signature and (signature is None or signer is None or not signer(bytes(payload), bytes(signature))):
            return PluginPackage(plugin_id, version, "wasm", digest, caps, False, "signature required or invalid")
        return PluginPackage(plugin_id, version, "wasm", digest, caps, True, "admitted")

    def runtime_available(self) -> bool:
        """Return whether an actual WASM runtime is installed."""
        try:
            __import__("wasmtime")
            return True
        except Exception:
            return False


@dataclass(frozen=True, slots=True)
class InferenceTelemetry:
    """Measured inference observation."""

    model: str
    task: str
    latency_ms: float
    tokens_per_second: float
    input_tokens: int
    output_tokens: int
    vram_mb: int
    cache_hit: bool


class InferenceOptimizer:
    """Select and score inference strategies using empirical telemetry."""

    def __init__(self, *, max_samples: int = 20_000) -> None:
        self.max_samples = max(1, int(max_samples))
        self._samples: list[InferenceTelemetry] = []
        self._lock = threading.RLock()

    def record(self, sample: InferenceTelemetry) -> None:
        """Record one inference observation."""
        if sample.latency_ms < 0 or sample.tokens_per_second < 0 or sample.vram_mb < 0:
            raise ValueError("inference metrics cannot be negative")
        with self._lock:
            self._samples.append(sample)
            del self._samples[:-self.max_samples]

    def rank(self, task: str, candidates: Sequence[str], *, vram_budget_mb: int | None = None) -> list[dict[str, Any]]:
        """Return candidates ranked by quality proxy from observed measurements."""
        task_name = str(task).strip()
        options = sorted({str(item).strip() for item in candidates if str(item).strip()})
        with self._lock:
            rows = list(self._samples)
        result: list[dict[str, Any]] = []
        for model in options:
            samples = [row for row in rows if row.model == model and row.task == task_name]
            if vram_budget_mb is not None:
                samples = [row for row in samples if row.vram_mb <= int(vram_budget_mb)]
            if samples:
                score = statistics.fmean((1.0 / max(row.latency_ms, 1.0)) * max(row.tokens_per_second, 0.0) * (1.25 if row.cache_hit else 1.0) for row in samples)
                result.append({"model": model, "score": score, "samples": len(samples)})
            else:
                result.append({"model": model, "score": 0.0, "samples": 0})
        return sorted(result, key=lambda item: (-float(item["score"]), str(item["model"])))

    def snapshot(self) -> dict[str, Any]:
        """Return aggregate optimizer state."""
        with self._lock:
            return {"samples": len(self._samples), "models": sorted({row.model for row in self._samples})}


class ContinuousProfiler:
    """Low-overhead local profiler using cProfile and tracemalloc."""

    def run(self, operation: str, callback: Callable[[], Any]) -> dict[str, Any]:
        """Profile one bounded callback and return aggregate timing/memory."""
        import cProfile
        import io
        import pstats
        import tracemalloc

        name = str(operation).strip()
        if not name:
            raise ValueError("operation is required")
        profiler = cProfile.Profile()
        tracemalloc.start()
        started = time.perf_counter()
        try:
            result = None
            profiler.enable()
            try:
                result = callback()
            finally:
                profiler.disable()
            elapsed = (time.perf_counter() - started) * 1000.0
            current, peak = tracemalloc.get_traced_memory()
            stats_buffer = io.StringIO()
            pstats.Stats(profiler, stream=stats_buffer).sort_stats("cumtime").print_stats(10)
            return {"ok": True, "operation": name, "elapsed_ms": elapsed, "current_bytes": current, "peak_bytes": peak, "stats": stats_buffer.getvalue(), "result": result}
        finally:
            tracemalloc.stop()


class BenchmarkBisector:
    """Find the first regression in an ordered benchmark history."""

    def locate(self, baseline: float, samples: Sequence[float], *, threshold_ratio: float = 1.10) -> dict[str, Any]:
        """Return first sample whose value exceeds the regression threshold."""
        if baseline <= 0:
            raise ValueError("baseline must be positive")
        threshold = float(baseline) * float(threshold_ratio)
        for index, value in enumerate(samples):
            if float(value) > threshold:
                return {"regressed": True, "index": index, "value": float(value), "threshold": threshold}
        return {"regressed": False, "index": None, "value": None, "threshold": threshold}


@dataclass(frozen=True, slots=True)
class CanaryTransactionResult:
    """Bounded canary evaluation result with explicit rollback state."""

    accepted: bool
    baseline_score: float
    holdout_score: float
    canary_score: float
    rolled_back: bool
    reason: str


class SourceRevisionBisector:
    """Binary-search a trusted ordered revision set using an injected verifier."""

    def locate(self, revisions: Sequence[str], passes: Callable[[str], bool]) -> dict[str, Any]:
        """Return the first failing revision assuming the set changes monotonically from pass to fail."""
        ordered = tuple(str(item).strip() for item in revisions)
        if not ordered or any(not item for item in ordered):
            raise ValueError("revisions must contain non-empty identifiers")
        if passes(ordered[-1]):
            return {"regressed": False, "revision": None, "index": None}
        lo, hi = 0, len(ordered) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if passes(ordered[mid]):
                lo = mid + 1
            else:
                hi = mid
        return {"regressed": True, "revision": ordered[lo], "index": lo}


@dataclass(frozen=True, slots=True)
class OptimizationProposal:
    """Benchmark-gated optimization proposal."""

    proposal_id: str
    target: str
    baseline_score: float
    candidate_score: float
    risk: str
    accepted: bool
    reason: str


class SelfOptimizationEngine:
    """Only accept measurable improvements with bounded risk."""

    def canary(
        self,
        target: str,
        *,
        baseline_score: float,
        holdout_score: float,
        canary_score: float,
        apply_candidate: Callable[[], None],
        rollback_candidate: Callable[[], None],
        risk: str = "low",
        minimum_improvement: float = 0.02,
    ) -> CanaryTransactionResult:
        """Apply a candidate only after a holdout/canary gate; rollback on any rejected stage."""
        baseline = float(baseline_score); holdout = float(holdout_score); canary = float(canary_score)
        proposal = self.evaluate(str(target), baseline_score=baseline, candidate_score=holdout, risk=risk, minimum_improvement=minimum_improvement)
        if not proposal.accepted or canary < baseline * (1.0 + float(minimum_improvement)):
            return CanaryTransactionResult(False, baseline, holdout, canary, False, "holdout or canary gate rejected candidate")
        try:
            apply_candidate()
        except Exception as exc:
            try:
                rollback_candidate()
            except Exception as rollback_exc:
                return CanaryTransactionResult(
                    False, baseline, holdout, canary, False,
                    f"candidate application failed; rollback failed: {type(rollback_exc).__name__}",
                )
            return CanaryTransactionResult(
                False, baseline, holdout, canary, True,
                f"candidate application failed and was rolled back: {type(exc).__name__}",
            )
        return CanaryTransactionResult(True, baseline, holdout, canary, False, "benchmark-gated canary accepted")

    def evaluate(self, target: str, *, baseline_score: float, candidate_score: float, risk: str = "low", minimum_improvement: float = 0.02) -> OptimizationProposal:
        """Accept a candidate only when the measured improvement is meaningful."""
        baseline = float(baseline_score)
        candidate = float(candidate_score)
        improvement = (candidate - baseline) / max(abs(baseline), 1e-9)
        normalized_risk = str(risk).strip().lower()
        accepted = improvement >= float(minimum_improvement) and normalized_risk in {"low", "medium"}
        reason = "measured improvement exceeds gate" if accepted else "insufficient improvement or excessive risk"
        return OptimizationProposal(uuid.uuid4().hex, str(target).strip(), baseline, candidate, normalized_risk, accepted, reason)


@dataclass(frozen=True, slots=True)
class MemoryConflictProof:
    """Deterministic proof material describing a concurrent memory merge."""

    namespace: str
    record_id: str
    left_digest: str
    right_digest: str
    left_vector: Mapping[str, int]
    right_vector: Mapping[str, int]
    resolution: str
    proof_digest: str

@dataclass(frozen=True, slots=True)
class MemoryReplica:
    """Encrypted distributed-memory record with version vector."""

    namespace: str
    record_id: str
    version: int
    node_id: str
    vector: Mapping[str, int]
    payload: Mapping[str, Any]
    digest: str
    ciphertext: str


class DistributedMemory:
    """Encrypted SQLite-backed memory replication with deterministic merge."""

    def __init__(self, path: str | Path, key: bytes, *, node_id: str | None = None) -> None:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        raw_key = bytes(key)
        if len(raw_key) not in {16, 24, 32}:
            raw_key = hashlib.sha256(raw_key).digest()
        self._key = raw_key
        self._node = node_id or uuid.uuid4().hex[:12]
        self._aes = AESGCM(self._key)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.execute("CREATE TABLE IF NOT EXISTS records(namespace TEXT NOT NULL, record_id TEXT NOT NULL, payload BLOB NOT NULL, version INTEGER NOT NULL, node_id TEXT NOT NULL, vector TEXT NOT NULL, digest TEXT NOT NULL, PRIMARY KEY(namespace, record_id))")
        self._db.commit()
        self._lock = threading.RLock()

    def put(self, namespace: str, record_id: str, payload: Mapping[str, Any], *, version: int | None = None) -> MemoryReplica:
        """Encrypt and persist one versioned record."""
        ns, rid = str(namespace).strip(), str(record_id).strip()
        if not ns or not rid:
            raise ValueError("namespace and record_id are required")
        with self._lock:
            row = self._db.execute("SELECT version, vector FROM records WHERE namespace=? AND record_id=?", (ns, rid)).fetchone()
            current_version = int(row[0]) if row else 0
            vector = json.loads(row[1]) if row else {}
            next_version = max(current_version + 1, int(version or 0))
            vector[self._node] = max(int(vector.get(self._node, 0)), next_version)
            plain = json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode()
            nonce = secrets.token_bytes(12)
            ciphertext = nonce + self._aes.encrypt(nonce, plain, f"{ns}:{rid}".encode())
            digest = hashlib.sha256(plain).hexdigest()
            self._db.execute("INSERT OR REPLACE INTO records(namespace,record_id,payload,version,node_id,vector,digest) VALUES(?,?,?,?,?,?,?)", (ns, rid, ciphertext, next_version, self._node, json.dumps(vector, sort_keys=True), digest))
            self._db.commit()
            return MemoryReplica(ns, rid, next_version, self._node, dict(vector), dict(payload), digest, base64.b64encode(ciphertext).decode())

    def get(self, namespace: str, record_id: str) -> MemoryReplica | None:
        """Decrypt one persisted memory record."""
        ns, rid = str(namespace).strip(), str(record_id).strip()
        with self._lock:
            row = self._db.execute("SELECT payload,version,node_id,vector,digest FROM records WHERE namespace=? AND record_id=?", (ns, rid)).fetchone()
        if row is None:
            return None
        ciphertext, version, node_id, vector_json, digest = row
        raw = bytes(ciphertext)
        nonce, encrypted = raw[:12], raw[12:]
        plain = self._aes.decrypt(nonce, encrypted, f"{ns}:{rid}".encode())
        payload = json.loads(plain.decode())
        if hashlib.sha256(plain).hexdigest() != digest:
            raise PlatformSecurityError("memory integrity verification failed")
        return MemoryReplica(ns, rid, int(version), str(node_id), json.loads(vector_json), payload, str(digest), base64.b64encode(raw).decode())

    def verify_replica(self, replica: MemoryReplica) -> bool:
        """Verify ciphertext authentication, plaintext digest, and record identity."""
        try:
            raw = base64.b64decode(replica.ciphertext.encode())
            nonce, encrypted = raw[:12], raw[12:]
            plain = self._aes.decrypt(nonce, encrypted, f"{replica.namespace}:{replica.record_id}".encode())
            if hashlib.sha256(plain).hexdigest() != replica.digest:
                return False
            decoded = json.loads(plain.decode())
            return decoded == dict(replica.payload)
        except Exception:
            return False

    @staticmethod
    def merge_with_proof(local: MemoryReplica | None, remote: MemoryReplica) -> tuple[MemoryReplica, MemoryConflictProof | None]:
        """Merge replicas and return deterministic evidence when concurrent versions conflict."""
        if local is None:
            return remote, None
        lvec, rvec = dict(local.vector), dict(remote.vector)
        if all(int(lvec.get(k, 0)) >= int(v) for k, v in rvec.items()) and any(int(lvec.get(k, 0)) > int(v) for k, v in rvec.items()):
            return local, None
        if all(int(rvec.get(k, 0)) >= int(v) for k, v in lvec.items()) and any(int(rvec.get(k, 0)) > int(v) for k, v in lvec.items()):
            return remote, None
        winner = remote if (remote.version, remote.node_id, remote.digest) >= (local.version, local.node_id, local.digest) else local
        material = {
            "namespace": local.namespace, "record_id": local.record_id, "left_digest": local.digest, "right_digest": remote.digest,
            "left_vector": lvec, "right_vector": rvec, "resolution": winner.node_id,
        }
        proof = MemoryConflictProof(
            local.namespace, local.record_id, local.digest, remote.digest, lvec, rvec, winner.node_id,
            hashlib.sha256(json.dumps(material, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        )
        return winner, proof

    @staticmethod
    def merge(local: MemoryReplica | None, remote: MemoryReplica) -> MemoryReplica:
        """Deterministically merge two replicas using version-vector dominance."""
        return DistributedMemory.merge_with_proof(local, remote)[0]

    def close(self) -> None:
        """Close the local replica database."""
        with self._lock:
            self._db.close()


@dataclass(frozen=True, slots=True)
class DeviceRecord:
    """Device identity and health record."""

    device_id: str
    kind: str
    capabilities: tuple[str, ...]
    trusted: bool
    health: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


class DeviceFabricManager:
    """Register devices, capabilities, health, and trust state."""

    def __init__(self, *, max_devices: int = 2048) -> None:
        self.max_devices = max(1, int(max_devices))
        self._devices: dict[str, DeviceRecord] = {}
        self._lock = threading.RLock()

    def register(self, device_id: str, kind: str, capabilities: Iterable[str], *, trusted: bool = False, metadata: Mapping[str, Any] | None = None) -> DeviceRecord:
        """Register or replace a device record."""
        did = str(device_id).strip()
        caps = tuple(sorted({str(item).strip() for item in capabilities if str(item).strip()}))
        if not did or not kind.strip() or not caps:
            raise ValueError("device_id, kind and capabilities are required")
        with self._lock:
            if did not in self._devices and len(self._devices) >= self.max_devices:
                raise RuntimeError("device limit reached")
            record = DeviceRecord(did, str(kind).strip(), caps, bool(trusted), "healthy", dict(metadata or {}))
            self._devices[did] = record
            return record

    def set_health(self, device_id: str, health: str) -> DeviceRecord:
        """Update one device health state."""
        normalized = str(health).strip().lower()
        if normalized not in {"healthy", "degraded", "offline", "unknown"}:
            raise ValueError("invalid device health")
        with self._lock:
            old = self._devices[str(device_id)]
            updated = DeviceRecord(old.device_id, old.kind, old.capabilities, old.trusted, normalized, old.metadata)
            self._devices[old.device_id] = updated
            return updated

    def choose(self, capability: str, *, trusted_only: bool = True) -> DeviceRecord | None:
        """Choose a healthy least-ambiguous device for a capability."""
        cap = str(capability).strip()
        with self._lock:
            candidates = [item for item in self._devices.values() if cap in item.capabilities and item.health == "healthy" and (item.trusted or not trusted_only)]
        return sorted(candidates, key=lambda item: item.device_id)[0] if candidates else None

    def snapshot(self) -> dict[str, Any]:
        """Return device counts and states."""
        with self._lock:
            return {"devices": len(self._devices), "healthy": sum(item.health == "healthy" for item in self._devices.values()), "trusted": sum(item.trusted for item in self._devices.values())}


class FailureDomainScheduler:
    """Prefer healthy workers outside the failed domain and avoid hotspots."""

    def choose(self, workers: Sequence[Mapping[str, Any]], *, capability: str, failed_domains: Iterable[str] = ()) -> Mapping[str, Any] | None:
        """Choose a worker by health, domain diversity and active load."""
        failed = {str(item) for item in failed_domains}
        candidates = [worker for worker in workers if capability in set(worker.get("capabilities", ())) and bool(worker.get("healthy", True)) and str(worker.get("failure_domain", "")) not in failed]
        return min(candidates, key=lambda worker: (int(worker.get("active_tasks", 0)), str(worker.get("failure_domain", "")), str(worker.get("worker_id", "")))) if candidates else None


@dataclass(frozen=True, slots=True)
class MCPAppDescriptor:
    """MCP App UI metadata associated with a tool."""

    server_id: str
    tool_name: str
    resource_uri: str
    title: str
    input_schema: Mapping[str, Any]


class MCPCompatibilityMatrix:
    """Track supported MCP protocol generations and capability features."""

    SUPPORTED = ("2026-07-28", "2025-11-25")

    def negotiate(self, offered: Iterable[str]) -> str | None:
        """Select the newest mutually supported protocol version."""
        offered_set = {str(item) for item in offered}
        return next((version for version in self.SUPPORTED if version in offered_set), None)

    def compatibility(self) -> dict[str, Any]:
        """Return deterministic protocol capability metadata."""
        return {"supported_versions": list(self.SUPPORTED), "stateless": True, "tasks": True, "server_discover": True, "mcp_apps": True}


class MCPAppsRegistry:
    """Register safe UI descriptors without granting tool authority."""

    def __init__(self, *, allow_insecure_http: bool = False) -> None:
        self._allow_insecure_http = bool(allow_insecure_http)
        self._apps: dict[tuple[str, str], MCPAppDescriptor] = {}
        self._lock = threading.RLock()

    def register(self, descriptor: MCPAppDescriptor) -> MCPAppDescriptor:
        """Register one validated MCP App descriptor."""
        from urllib.parse import urlparse

        parsed = urlparse(descriptor.resource_uri)
        if parsed.scheme not in {"https", "http", "jarvis"}:
            raise ValueError("unsupported MCP app resource URI")
        if parsed.fragment or parsed.username or parsed.password:
            raise ValueError("MCP app resource URI cannot contain fragment or userinfo")
        if parsed.scheme == "http":
            if not self._allow_insecure_http or parsed.hostname not in {"localhost", "127.0.0.1", "::1"}:
                raise ValueError("insecure MCP app HTTP is disabled")
        if not descriptor.server_id.strip() or not descriptor.tool_name.strip() or not descriptor.title.strip():
            raise ValueError("server_id, tool_name and title are required")
        with self._lock:
            self._apps[(descriptor.server_id, descriptor.tool_name)] = descriptor
        return descriptor

    def list(self) -> tuple[MCPAppDescriptor, ...]:
        """Return registered descriptors."""
        with self._lock:
            return tuple(self._apps.values())


@dataclass(frozen=True, slots=True)
class PolicyRule:
    """Editable capability policy rule."""

    capability: str
    effect: str
    principal: str = "*"
    constraints: Mapping[str, Any] = field(default_factory=dict)


class PolicyEditor:
    """Safe in-memory policy editor with validation and deterministic export."""

    def __init__(self) -> None:
        self._rules: dict[tuple[str, str], PolicyRule] = {}
        self._lock = threading.RLock()

    def set_rule(self, rule: PolicyRule) -> PolicyRule:
        """Validate and set a capability rule."""
        cap, effect, principal = rule.capability.strip(), rule.effect.strip().lower(), rule.principal.strip()
        if not cap or effect not in {"allow", "deny"} or not principal:
            raise ValueError("invalid policy rule")
        normalized = PolicyRule(cap, effect, principal, dict(rule.constraints))
        with self._lock:
            self._rules[(cap, principal)] = normalized
        return normalized

    @staticmethod
    def _constraints_match(rule: PolicyRule, context: Mapping[str, Any]) -> bool:
        """Evaluate a deliberately small, typed constraint vocabulary."""
        for key, expected in rule.constraints.items():
            name = str(key)
            if name in {"equals", "eq"} and isinstance(expected, Mapping):
                if any(context.get(str(field)) != value for field, value in expected.items()):
                    return False
            elif name == "in" and isinstance(expected, Mapping):
                if any(context.get(str(field)) not in tuple(values) for field, values in expected.items()):
                    return False
            elif name == "min" and isinstance(expected, Mapping):
                if any(float(context.get(str(field), float("-inf"))) < float(value) for field, value in expected.items()):
                    return False
            elif name == "max" and isinstance(expected, Mapping):
                if any(float(context.get(str(field), float("inf"))) > float(value) for field, value in expected.items()):
                    return False
            elif context.get(name) != expected:
                return False
        return True

    def evaluate(self, capability: str, principal: str = "*", context: Mapping[str, Any] | None = None) -> bool:
        """Return allow/deny with explicit deny precedence and constraint enforcement."""
        request_context = dict(context or {})
        with self._lock:
            rules = [self._rules.get((str(capability).strip(), p)) for p in (str(principal).strip(), "*")]
        rules = [rule for rule in rules if rule is not None and self._constraints_match(rule, request_context)]
        if any(rule.effect == "deny" for rule in rules):
            return False
        return any(rule.effect == "allow" for rule in rules)

    def export(self) -> tuple[PolicyRule, ...]:
        """Return policy rules in deterministic order."""
        with self._lock:
            return tuple(self._rules[key] for key in sorted(self._rules))


@dataclass(frozen=True, slots=True)
class OperatorProfile:
    """Role-based control-plane profile."""

    name: str
    capabilities: tuple[str, ...]
    ui_tabs: tuple[str, ...]
    settings_paths: tuple[str, ...]


class OperatorProfileRegistry:
    """Manage named operator profiles with bounded capabilities."""

    def __init__(self) -> None:
        self._profiles: dict[str, OperatorProfile] = {}
        self._lock = threading.RLock()

    def register(self, profile: OperatorProfile) -> OperatorProfile:
        """Register a validated operator profile."""
        name = profile.name.strip()
        if not name:
            raise ValueError("profile name is required")
        caps = tuple(sorted(set(profile.capabilities)))
        tabs = tuple(sorted(set(profile.ui_tabs)))
        paths = tuple(sorted(set(profile.settings_paths)))
        normalized = OperatorProfile(name, caps, tabs, paths)
        with self._lock:
            self._profiles[name] = normalized
        return normalized

    def get(self, name: str) -> OperatorProfile | None:
        """Return a named profile."""
        with self._lock:
            return self._profiles.get(str(name).strip())

    def snapshot(self) -> dict[str, Any]:
        """Return profile names and counts."""
        with self._lock:
            return {"profiles": sorted(self._profiles), "count": len(self._profiles)}


class SystemAttestation:
    """Collect reproducible local platform measurements for trust policy."""

    def collect(self) -> dict[str, Any]:
        """Return platform evidence without claiming secure-boot/TPM proof."""
        machine = platform.machine().lower()
        release = platform.release()
        py = platform.python_version()
        evidence = {"os": platform.system(), "machine": machine, "release": release, "python": py, "hostname_hash": hashlib.sha256(platform.node().encode()).hexdigest()[:16]}
        trusted = bool(os.environ.get("JARVIS_ATTESTATION_TRUST_ANCHOR"))
        return {"available": True, "trusted": trusted, "provider": "local-platform", "evidence": evidence, "reason": "trust anchor configured" if trusted else "presence evidence only"}


class NextGenFabric:
    """Aggregate facade used by JARVISCore and API/UI surfaces."""

    def __init__(self, state_root: str | Path, key: bytes, *, model_runtime: Any | None = None, model_memory_provider: Callable[[], int] | None = None) -> None:
        root = Path(state_root)
        root.mkdir(parents=True, exist_ok=True)
        self.identity = WorkloadIdentityAuthority(key)
        self.webauthn = WebAuthnControlPlane()
        self.certificates = CertificateLifecycle(state_path=root / "certificates.json", secret=key)
        self.wasi = WASIPluginRuntime(allowed_capabilities=("tools.read", "memory.read", "network.fetch"))
        self.inference = InferenceOptimizer()
        self.profiler = ContinuousProfiler()
        self.bisector = BenchmarkBisector()
        self.optimizer = SelfOptimizationEngine()
        self.memory = DistributedMemory(root / "nextgen_memory.db", key, node_id=platform.node()[:32] or uuid.uuid4().hex[:12])
        self.devices = DeviceFabricManager()
        self.failure_scheduler = FailureDomainScheduler()
        self.mcp = MCPCompatibilityMatrix()
        self.mcp_apps = MCPAppsRegistry()
        self.policy = PolicyEditor()
        self.profiles = OperatorProfileRegistry()
        self.attestation = SystemAttestation()
        self.trust_policy = HardwareTrustPolicy()
        self.capability_attenuator = CapabilityAttenuator()
        self.resource_heatmap = ResourceHeatmap()
        self.predictive_twin = PredictiveDependencyTwin()
        self.quality_drift = QualityDriftMonitor()
        self.error_budget = ErrorBudgetController()
        self.speculative = SpeculativeExecutor()
        self.disaggregated = DisaggregatedInferenceCoordinator()
        self.regression_gate = RegressionGate()
        self.soak = SoakRunner()
        self.release_provenance = ReleaseProvenance()
        self.mcp_wire = MCPWireGate()
        self.startup = StartupDependencyGraph()
        self.startup_plan = self.startup.plan((
            StartupNode("identity"),
            StartupNode("certificates", ("identity",)),
            StartupNode("policy", ("identity",)),
            StartupNode("devices", ("identity",)),
            StartupNode("memory", ("identity",)),
            StartupNode("inference", ("policy",)),
            StartupNode("supreme_runtime", ("policy", "memory", "inference", "devices")),
            StartupNode("operator", ("policy", "devices", "supreme_runtime")),
        ))
        self.mission_node_policy = MissionNodePolicyGate()
        self.model_lifecycle = ModelLifecycleManager(root / "models")
        self.embedding_registry = EmbeddingModelRegistry(root / "embedding_registry.json")
        self.empirical_benchmark = EmpiricalBenchmarkRunner()
        self.vad = VoiceActivityDetector()
        self.capture_privacy = CapturePrivacyPolicy()
        self.clipboard_intelligence = ClipboardIntelligence()
        self.proactive = ProactiveScheduler()
        self.snapshots = EncryptedSnapshotStore(root / "encrypted_snapshots", key)
        self.pairing = LANPairingAuthority(key)
        self.world_state = WorldStateProjection()
        self.world_state.register("identity", self.identity.snapshot)
        self.world_state.register("devices", self.devices.snapshot)
        self.world_state.register("resources", self.resource_heatmap.snapshot)
        self.world_state.register("quality", self.quality_drift.snapshot)
        self.artifacts = ArtifactQuarantineManager(root / "artifacts")
        self.frontier_batch = FrontierBatchFabric(root / "frontier_batch", key)
        self.supreme = SupremeRuntimeFabric(root / "supreme_runtime", key)
        if model_runtime is not None:
            if model_memory_provider is None:
                raise ValueError("model_memory_provider is required when model_runtime is supplied")
            self.supreme.attach_model_runtime(model_runtime, memory_available_mb=model_memory_provider)
        self.world_state.register("supreme_runtime", self.supreme.health)
        self._start = time.time()

    def health(self) -> dict[str, Any]:
        """Return safe aggregate health state."""
        return {"uptime_seconds": time.time() - self._start, "identity": self.identity.snapshot(), "webauthn": self.webauthn.snapshot(), "certificates": self.certificates.snapshot(), "wasi_runtime": self.wasi.runtime_available(), "inference": self.inference.snapshot(), "devices": self.devices.snapshot(), "mcp": self.mcp.compatibility(), "mcp_apps": len(self.mcp_apps.list()), "profiles": self.profiles.snapshot(), "attestation": self.attestation.collect(), "trust_policy": self.trust_policy.evaluate(self.attestation.collect()), "protocol_gate": self.mcp_wire.VERSION, "resource_heatmap": self.resource_heatmap.snapshot(), "predictive_twin": {"nodes": len(self.predictive_twin.snapshot()["nodes"])}, "quality_drift": self.quality_drift.snapshot(), "error_budget": asdict(self.error_budget.assess(total=0, errors=0)), "startup": {"order": self.startup_plan.order, "digest": self.startup_plan.digest}, "models": self.model_lifecycle.snapshot(), "embeddings": self.embedding_registry.snapshot(), "voice": {"vad_speaking": self.vad.speaking}, "proactive": {"quiet_hours": self.proactive.is_quiet_hours()}, "world_state": self.world_state.snapshot()["digest"], "frontier_batch": self.frontier_batch.health(), "supreme_runtime": self.supreme.health()}

    def close(self) -> None:
        """Release persistent resources."""
        self.supreme.close()
        self.memory.close()
        self.frontier_batch.close()

@dataclass(frozen=True, slots=True)
class SpeculativeResult:
    """Result of a bounded draft/verifier speculative execution."""

    accepted_tokens: int
    generated_text: str
    draft_calls: int
    verifier_calls: int
    latency_ms: float


class SpeculativeExecutor:
    """Engine-neutral speculative decoding coordinator with strict budgets."""

    def execute(self, prompt: str, *, draft: Callable[[str, int], str], verify: Callable[[str, str], str], max_rounds: int = 8, draft_tokens: int = 8) -> SpeculativeResult:
        """Generate bounded draft chunks and let the verifier accept/correct them."""
        if not str(prompt).strip():
            raise ValueError("prompt is required")
        rounds = max(1, min(int(max_rounds), 64))
        chunk = max(1, min(int(draft_tokens), 64))
        started = time.perf_counter()
        context = str(prompt)
        accepted = 0
        draft_calls = 0
        verifier_calls = 0
        output: list[str] = []
        for _ in range(rounds):
            candidate = str(draft(context, chunk))
            draft_calls += 1
            if not candidate:
                break
            verified = str(verify(context, candidate))
            verifier_calls += 1
            if not verified:
                break
            output.append(verified)
            accepted += len(verified.split())
            context += verified
        return SpeculativeResult(accepted, "".join(output), draft_calls, verifier_calls, (time.perf_counter() - started) * 1000.0)


@dataclass(frozen=True, slots=True)
class DisaggregatedResult:
    """Result envelope for separate prefill and decode nodes."""

    prefill_node: str
    decode_node: str
    context_handle: str
    output: str


class DisaggregatedInferenceCoordinator:
    """Coordinate prefill/decode callbacks without assuming a specific inference engine."""

    def run(self, prompt: str, *, prefill: Callable[[str], bytes], decode: Callable[[bytes], str], prefill_node: str, decode_node: str) -> DisaggregatedResult:
        """Execute one bounded prefill/decode transaction."""
        if not str(prompt).strip() or not prefill_node.strip() or not decode_node.strip():
            raise ValueError("prompt and node identifiers are required")
        context = bytes(prefill(prompt))
        if len(context) > 64 * 1024 * 1024:
            raise ValueError("prefill context exceeds transfer ceiling")
        handle = hashlib.sha256(context).hexdigest()
        return DisaggregatedResult(str(prefill_node), str(decode_node), handle, str(decode(context)))


class RegressionGate:
    """Statistical regression gate for release and optimization decisions."""

    def check(self, baseline: Sequence[float], candidate: Sequence[float], *, max_relative_degradation: float = 0.05) -> dict[str, Any]:
        """Compare two metric populations with a deterministic median gate."""
        if not baseline or not candidate:
            raise ValueError("baseline and candidate samples are required")
        base = statistics.median(float(item) for item in baseline)
        current = statistics.median(float(item) for item in candidate)
        relative = (current - base) / max(abs(base), 1e-9)
        return {"ok": relative <= float(max_relative_degradation), "baseline_median": base, "candidate_median": current, "relative_change": relative}


class SoakRunner:
    """Run bounded durability probes with failure accounting."""

    def run(self, operation: Callable[[], Any], *, iterations: int = 100, max_failures: int = 0) -> dict[str, Any]:
        """Execute a bounded operation repeatedly and return durability metrics."""
        count = max(1, min(int(iterations), 100_000))
        failures = 0
        latencies: list[float] = []
        started = time.perf_counter()
        for _ in range(count):
            t0 = time.perf_counter()
            try:
                operation()
            except Exception:
                failures += 1
            latencies.append((time.perf_counter() - t0) * 1000.0)
            if failures > int(max_failures):
                break
        return {"ok": failures <= int(max_failures), "iterations": len(latencies), "failures": failures, "p50_latency_ms": statistics.median(latencies) if latencies else 0.0, "elapsed_ms": (time.perf_counter() - started) * 1000.0}


class ReleaseProvenance:
    """Create signed-independent artifact provenance records from file digests."""

    def manifest(self, root: str | Path, *, version: str) -> dict[str, Any]:
        """Create a reproducible file inventory excluding transient state."""
        base = Path(root).resolve()
        entries: list[dict[str, str]] = []
        for path in sorted(base.rglob("*")):
            if not path.is_file() or any(part in {".git", "__pycache__", ".pytest_cache", "dist", "build"} for part in path.parts):
                continue
            rel = path.relative_to(base).as_posix()
            if path.suffix in {".pyc", ".pyo"}:
                continue
            entries.append({"path": rel, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        root_digest = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return {"version": str(version), "algorithm": "sha256", "files": entries, "root_digest": root_digest, "generated_at": time.time()}


class MCPWireGate:
    """Validate stateless MCP request metadata before protocol dispatch."""

    VERSION = "2026-07-28"

    def validate(self, request: Mapping[str, Any]) -> bool:
        """Require MCP-2026 metadata and reject session-bound requests."""
        metadata = request.get("_meta", {})
        if not isinstance(metadata, Mapping):
            return False
        version = metadata.get("io.modelcontextprotocol/protocolVersion") or request.get("protocolVersion")
        if str(version) != self.VERSION:
            return False
        if "Mcp-Session-Id" in request or metadata.get("Mcp-Session-Id"):
            return False
        return bool(str(request.get("method", "")).strip())


class HardwareTrustPolicy:
    """Evaluate whether platform evidence is strong enough for a requested operation."""

    def evaluate(self, evidence: Mapping[str, Any], *, require_hardware_trust: bool = False) -> dict[str, Any]:
        """Return a fail-closed trust decision."""
        trusted = bool(evidence.get("trusted"))
        available = bool(evidence.get("available"))
        allowed = available and (trusted if require_hardware_trust else True)
        return {"allowed": allowed, "require_hardware_trust": bool(require_hardware_trust), "available": available, "trusted": trusted, "reason": "hardware-backed evidence required" if require_hardware_trust and not trusted else "policy satisfied" if allowed else "platform evidence unavailable"}



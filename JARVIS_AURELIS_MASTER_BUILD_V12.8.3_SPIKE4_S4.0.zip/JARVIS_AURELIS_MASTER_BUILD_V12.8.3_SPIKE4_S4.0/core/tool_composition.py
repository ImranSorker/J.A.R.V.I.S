"""P2-Q Tool Composition Engine 2.0.

Composes P2-P tools into signed, typed, bounded, compensable composite tools.
The engine never invokes a component directly: execution is delegated back to
P2-P's canonical ToolFabric invocation path.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Callable, Sequence

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
import base64

from core.agent_harness import ExecutionContext
from core.schema_validator import SchemaValidator
from core.event_fabric import EventFabric, EventEnvelope, EventLineage, ProducedBy, AuthContext
from core.kernel_12_8_0.canonical import canonical_bytes
from core.tool_fabric.impl import ToolFabric, ToolValidationError, ToolPolicyDenied, ToolNotFound, ToolRevoked

ROOT = Path(__file__).resolve().parent.parent
SCHEMA_DIR = ROOT / "core" / "schemas"
COMP_DIR = ROOT / "core" / "tool_composition"
TEMPLATES_DIR = COMP_DIR / "templates"
TRANSFORMS_DIR = COMP_DIR / "transforms"

STRUCTURAL_KINDS = ("sequence","parallel","branch","loop","join","try_catch","transaction","saga","map","reduce")
TRANSACTION_BOUNDARIES = ("none","per_step","whole_pipeline","bounded")
FAILURE_HANDLING = ("fail_fast","continue","compensating","transactional","escalate")
ROLLBACK_STRATEGIES = ("none","compensation","checkpoint","transactional","hybrid")
BINDING_KINDS = ("literal","input","output","env","secret_ref","transform","default","collect")
TRUST_RANK = {"untrusted":0,"experimental":1,"pinned":2,"verified":3}
TRUST_NAME = {v:k for k,v in TRUST_RANK.items()}
REV_RANK = {"unknown":0,"irreversible":1,"partially_reversible":2,"reversible":3}
REV_NAME = {v:k for k,v in REV_RANK.items()}
IDEM_RANK = {"non_idempotent":0,"per_key":1,"idempotent":2}
IDEM_NAME = {v:k for k,v in IDEM_RANK.items()}
DET_RANK = {"nondeterministic":0,"seeded":1,"deterministic":2}
DET_NAME = {v:k for k,v in DET_RANK.items()}
EFFECT_CLASSES = ("read_only","read_write","destructive","external","device","financial","communication","identity")
HIGH_RISK_EFFECTS = {"destructive","financial","communication","identity","device"}
SPECIAL_SCOPES = {"financial":"tools.financial.execute","communication":"tools.communication.send","identity":"tools.identity.modify","device":"tools.device.execute","destructive":"tools.destructive.execute"}

class CompositionError(RuntimeError):
    """Base composition failure."""
class CompositionValidationError(CompositionError, ValueError):
    """Composition artifact violates a frozen contract."""
class CompositionSignatureError(CompositionError, ValueError):
    """Composition signature or signed proof is invalid."""
class CompositionIntegrityError(CompositionError, ValueError):
    """Composition integrity hash is invalid."""
class CompositionAccessDenied(CompositionError, PermissionError):
    """Authorization or tenant scope denied an operation."""
class TypeCheckError(CompositionValidationError):
    """Composition type checking failed."""
class ContractCheckError(CompositionValidationError):
    """Composition contract validation failed."""
class CycleError(CompositionValidationError):
    """Composition dependency cycle is not a bounded loop."""
class LivenessError(CompositionValidationError):
    """Composition contains unreachable or unterminated nodes."""
class RegistrationDenied(CompositionAccessDenied):
    """Registration authorization was denied."""
class SimulationRequired(CompositionValidationError):
    """Required P2-K simulation evidence is missing or unsuccessful."""


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def _uuid() -> str: return str(uuid.uuid4())

def _sha(v: Any) -> str: return hashlib.sha256(canonical_bytes(v)).hexdigest()

def _schema(name: str) -> dict[str, Any]:
    return json.loads((SCHEMA_DIR / name).read_text(encoding="utf-8"))

def _sign(value: Any, signer: Ed25519PrivateKey) -> str:
    return base64.b64encode(signer.sign(canonical_bytes(value))).decode("ascii")

def _verify_seed_signature(doc: Mapping[str,Any], public_key: bytes) -> bool:
    try:
        unsigned=dict(doc); sig=base64.b64decode(str(unsigned["signature"]).encode("ascii")); unsigned["signature"]=""
        Ed25519PublicKey.from_public_bytes(public_key).verify(sig, canonical_bytes(unsigned))
        return True
    except Exception:
        return False

def _public_scopes(context: ExecutionContext) -> set[str]:
    return {str(x) for x in getattr(getattr(context,"auth_context",None),"scopes",())}

def _tenant(context: ExecutionContext, requested: str | None = None) -> str:
    if context is None or getattr(context,"auth_context",None) is None:
        raise CompositionAccessDenied("ExecutionContext required")
    ctx = str(getattr(context,"tenant_id", "default"))
    req = str(requested or ctx)
    if req != ctx:
        raise CompositionAccessDenied("cross-tenant composition denied")
    return ctx

def _require(context: ExecutionContext, scope: str) -> None:
    scopes = _public_scopes(context)
    if scope not in scopes and "tools.admin" not in scopes:
        raise CompositionAccessDenied(f"missing required scope: {scope}")


def _schema_type(schema: Mapping[str,Any]) -> str:
    t = schema.get("type")
    if isinstance(t,list): return "oneOf"
    if t == "object" and schema.get("additionalProperties") is True and not schema.get("properties"):
        return "any"
    if t: return str(t)
    if "oneOf" in schema: return "oneOf"
    return "any"

def _assignable(source: Mapping[str,Any], target: Mapping[str,Any]) -> bool:
    st, tt = _schema_type(source), _schema_type(target)
    if tt == "any" or st == "any": return True
    if st == tt: 
        if st == "object":
            sp = source.get("properties",{}); tp = target.get("properties",{}); sr=set(source.get("required",())); tr=set(target.get("required",()))
            if not sr.issuperset(tr): return False
            for k, ts in tp.items():
                if k in sp and not _assignable(sp[k], ts): return False
            return True
        if st == "array": return _assignable(source.get("items",{}), target.get("items",{}))
        if st == "number" and tt == "integer": return False
        return True
    if st == "integer" and tt == "number": return True
    if target.get("oneOf"):
        return any(_assignable(source, x) for x in target["oneOf"])
    if source.get("oneOf"):
        return all(_assignable(x, target) for x in source["oneOf"])
    return False

@dataclass(frozen=True, slots=True)
class TypeCheckReport:
    report_id: str
    composition_id: str
    all_edges_checked: int
    failing_edges: tuple[dict[str,Any],...]
    any_boundaries: tuple[str,...]
    coercions: tuple[dict[str,Any],...]
    passed: bool
    signature: str

@dataclass(frozen=True, slots=True)
class ContractCheckReport:
    composition_id: str
    passed: bool
    issues: tuple[str,...]
    signature: str

@dataclass(frozen=True, slots=True)
class AggregateBudgetReport:
    composition_id: str
    worst_case: Mapping[str, float]
    passed: bool
    signature: str

@dataclass(frozen=True, slots=True)
class DerivedSurfaceReport:
    composition_id: str
    capabilities: tuple[str,...]
    permissions: tuple[str,...]
    scopes: tuple[str,...]
    effects: tuple[str,...]
    reversibility: str
    trust: str
    cost_class: str
    idempotency: str
    determinism: str
    max_latency_ms: int
    worst_case_cost_units: float
    signature: str

@dataclass(frozen=True, slots=True)
class CompositeResult:
    invocation_id: str
    status: str
    outputs: Any
    error: Mapping[str,Any] | None
    steps: tuple[Mapping[str,Any],...]
    rollback: Mapping[str,Any] | None
    signature: str

@dataclass
class CompositionDraft:
    body: dict[str,Any]
    tenant_id: str
    version: int = 1
    state: str = "draft"

class ToolCompositionEngine:
    """Canonical composition layer consuming P2-P manifests and invoking via P2-P."""
    def __init__(self, tool_fabric: ToolFabric, *, signer: Ed25519PrivateKey | None = None, key_id: str = "tool-composition", event_fabric: EventFabric | None = None, p2k_simulator: Callable[[Mapping[str,Any],ExecutionContext], Mapping[str,Any]] | None = None, p2n_verifier: Callable[[Mapping[str,Any],ExecutionContext], Mapping[str,Any]] | None = None, revocation_propagator: Callable[[str],Mapping[str,Any]] | None = None, plan_resolver: Callable[[str, ExecutionContext], Mapping[str,Any] | None] | None = None, skill_resolver: Callable[[str, ExecutionContext], Mapping[str,Any] | None] | None = None, checkpoint_restorer: Callable[[Mapping[str,Any], ExecutionContext], Mapping[str,Any]] | None = None):
        self.fabric = tool_fabric
        self.signer = signer or tool_fabric.signer
        self.key_id = key_id
        self.event_fabric = event_fabric
        self.p2k_simulator = p2k_simulator
        self.p2n_verifier = p2n_verifier
        self.revocation_propagator = revocation_propagator
        self.plan_resolver = plan_resolver
        self.skill_resolver = skill_resolver
        self.checkpoint_restorer = checkpoint_restorer
        self._closed = False
        self._p2p_revocation_previous = getattr(tool_fabric, "revocation_propagator", None)
        def _wrapped_revocation(ref: str, manifest: Mapping[str,Any]) -> Mapping[str,Any]:
            prior=self._p2p_revocation_previous(ref,manifest) if self._p2p_revocation_previous else {}
            return self._on_component_revoked(ref,manifest,prior)
        if getattr(self.fabric, "revocation_propagator", None) is None:
            self.fabric.revocation_propagator=_wrapped_revocation
        self.transforms: dict[str,Mapping[str,Any]] = {}
        self.templates: dict[tuple[str,str],Mapping[str,Any]] = {}
        self._drafts: dict[tuple[str,str],CompositionDraft] = {}
        self._registered: dict[tuple[str,str],dict[str,Any]] = {}
        self._events: list[dict[str,Any]] = []
        self._lock = threading.RLock()
        self._load_seeds()

    def _ensure_open(self) -> None:
        if self._closed:
            raise CompositionError("tool composition engine is closed")

    def _load_seeds(self) -> None:
        public_key=None
        key_path=COMP_DIR/"template_signing_public.key"
        if key_path.exists():
            try: public_key=base64.b64decode(key_path.read_text().strip().encode("ascii"))
            except Exception: public_key=None
        for path in sorted(TEMPLATES_DIR.glob("*/**/*.json")):
            try:
                doc=json.loads(path.read_text(encoding="utf-8"))
                if public_key is None or not _verify_seed_signature(doc,public_key): raise ValueError("template signature invalid")
                self.templates[(str(doc["template_id"]),str(doc["template_version"]))]=doc
            except Exception:
                continue
        for path in sorted(TRANSFORMS_DIR.glob("*/**/*.json")):
            try:
                doc=json.loads(path.read_text(encoding="utf-8"))
                if public_key is None or not _verify_seed_signature(doc,public_key): raise ValueError("transform signature invalid")
                self.transforms[str(doc["transform_id"]+"@"+doc["transform_version"])] = doc
            except Exception:
                continue

    def _emit(self,name:str,payload:Mapping[str,Any],context:ExecutionContext,tenant:str) -> None:
        body=dict(payload); body.setdefault("caller_principal",str(getattr(getattr(context,"auth_context",None),"principal","")))
        self._events.append({"event_type":"Tool","event_name":name,"payload":body,"tenant_id":tenant,"timestamp":_utc()})
        if self.event_fabric is not None:
            auth=AuthContext("tool_composition",("events.publish.tool",),getattr(getattr(context,"auth_context",None),"policy_ref",None),str(getattr(getattr(context,"auth_context",None),"principal","")))
            env=EventEnvelope.create(event_type="Tool",event_name=name,payload=body,produced_by=ProducedBy("system","tool_composition",None,"system"),auth_context=auth,tenant_id=tenant,partition_key=str(body.get("composition_id",tenant)),correlation_id=str(getattr(context,"correlation_id",_uuid())),causation_id=getattr(context,"causation_id",None),signing_key=self.signer,lineage=EventLineage())
            self.event_fabric.publish_envelope(env)

    def _on_component_revoked(self,ref:str,manifest:Mapping[str,Any],prior:Any)->dict[str,Any]:
        affected=[]
        for (tenant,cref),body in list(self._registered.items()):
            if ref in [str(s.get("component_tool_ref")) for s in body.get("steps",())]:
                body["certification_status"]="provisional"; body["component_revoked"]=[ref]
                affected.append(cref)
        return {"skills":list(prior.get("skills",())) if isinstance(prior,Mapping) else [],"plans":list(prior.get("plans",())) if isinstance(prior,Mapping) else [],"composites":affected}

    def _get(self,ref:str,tenant:str)->dict[str,Any]: return self.fabric.registry.get_ref(ref,tenant_id=tenant)

    def compose(self, component_refs:list[str], structural_kind:str, options:Mapping[str,Any], *, context:ExecutionContext) -> CompositionDraft:
        tenant=_tenant(context, options.get("tenant_id")); _require(context,"tools.selection.read")
        if structural_kind not in STRUCTURAL_KINDS: raise CompositionValidationError("unsupported structural kind")
        steps=[]
        for i,ref in enumerate(component_refs):
            manifest=self._get(ref,tenant)
            steps.append({"step_id":f"step_{i+1}","component_tool_ref":ref,"component_manifest_hash":manifest["manifest_hash"],"inputs":{},"outputs":{},"optional":False,"skip_when":None,"failure_policy":"inherit","retry_policy":None,"timeout_ms":int(manifest.get("timeout_ms_default",1000)),"compensation_ref":manifest.get("compensation",{}).get("tool_ref"),"budget_allocation":copy.deepcopy(manifest.get("resources",{})),"verification_hook_ref":None})
        edges=[]
        if structural_kind not in {"parallel","join"}:
            for a,b in zip(steps,steps[1:]):
                edges.append({"from_step":a["step_id"],"from_output":"$output","to_step":b["step_id"],"to_input":"$input","kind":"data","type_check":{"source_schema_ref":self._get(a["component_tool_ref"],tenant)["outputs"]["schema_ref"],"target_schema_ref":self._get(b["component_tool_ref"],tenant)["inputs"]["schema_ref"],"assignable":False,"coercion":None},"transform":None})
        body={"composition_id":_uuid(),"composition_version":"1.0.0","structural_kind":structural_kind,"steps":steps,"edges":edges,"entry_steps":[s["step_id"] for s in steps] if structural_kind in {"parallel","join"} else ([steps[0]["step_id"]] if steps else []),"terminal_steps":[s["step_id"] for s in steps] if structural_kind in {"parallel","join"} else ([steps[-1]["step_id"]] if steps else []),"input_map":options.get("input_map",{}),"output_map":options.get("output_map",{}),"preconditions":options.get("preconditions",[]),"postconditions":options.get("postconditions",[]),"invariants":options.get("invariants",[]),"transaction_boundary":options.get("transaction_boundary","none"),"transaction_scope":options.get("transaction_scope"),"failure_handling":options.get("failure_handling","fail_fast"),"rollback_strategy":options.get("rollback_strategy","none"),"compensation_plan":options.get("compensation_plan"),"escalation_policy":options.get("escalation_policy"),"loop_bounds":options.get("loop_bounds"),"branch_conditions":options.get("branch_conditions"),"join_strategy":options.get("join_strategy"),"verification_hooks":options.get("verification_hooks",[]),"simulation_required":bool(options.get("simulation_required",False)),"simulation_profile":options.get("simulation_profile"),"provenance":options.get("provenance",{"author":{"principal":str(context.auth_context.principal),"key_id":self.key_id},"method":"manual","source_refs":[],"parent_compositions":[]}),"budget_ceiling":options.get("budget_ceiling",{}),"signature":"","integrity_hash":"","derived":{}}
        draft=CompositionDraft(body,tenant)
        self._drafts[(tenant,body["composition_id"])] = draft
        self._emit("CompositionDrafted",{"composition_id":body["composition_id"],"step_count":len(steps)},context,tenant)
        return draft


    def compose_from_plan(self, plan_id: str | Mapping[str,Any], *, context: ExecutionContext) -> CompositionDraft:
        """Derive a composition draft from a P2-L plan without executing it."""
        tenant=_tenant(context); _require(context,"tools.selection.read")
        plan = plan_id if isinstance(plan_id, Mapping) else None
        if plan is None and self.plan_resolver is not None:
            plan = self.plan_resolver(str(plan_id), context)
        if plan is None:
            for obj in self._registered.values():
                if obj.get("plan_id") == plan_id: plan=obj; break
        if plan is None: raise CompositionValidationError("plan artifact is required for derivation")
        refs=[str(step["ref"]) for step in plan.get("steps",[]) if str(step.get("step_kind"))=="tool_call" and step.get("ref")]
        if not refs: raise CompositionValidationError("plan contains no tool_call steps")
        draft=self.compose(refs,"sequence",{"tenant_id":tenant,"provenance":{"author":{"principal":str(context.auth_context.principal),"key_id":self.key_id},"method":"derived_from_plan","source_refs":[f"urn:jarvis:plan:{plan.get('plan_id',plan_id)}"],"parent_compositions":[]}},context=context)
        draft.body["plan_id"]=plan.get("plan_id",plan_id)
        return draft

    def compose_from_skill(self, skill_ref: str | Mapping[str,Any], *, context: ExecutionContext) -> CompositionDraft:
        tenant=_tenant(context); _require(context,"tools.selection.read")
        skill=skill_ref if isinstance(skill_ref,Mapping) else (self.skill_resolver(str(skill_ref), context) if self.skill_resolver is not None else None)
        if skill is None: raise CompositionValidationError("skill artifact mapping or skill resolver result is required for derivation")
        refs=[str(x) for x in skill.get("tools",skill.get("tool_bindings",()))]
        if not refs: raise CompositionValidationError("skill contains no tools")
        draft=self.compose(refs,"sequence",{"tenant_id":tenant,"provenance":{"author":{"principal":str(context.auth_context.principal),"key_id":self.key_id},"method":"derived_from_skill","source_refs":[str(skill.get("skill_ref",skill_ref))],"parent_compositions":[]}},context=context)
        return draft

    def compose_from_template(self, template_ref: str, parameters: Mapping[str,Any], *, context: ExecutionContext) -> CompositionDraft:
        tenant=_tenant(context); _require(context,"tools.selection.read")
        if "@" in template_ref: key=(template_ref.rsplit("@",1)[0],template_ref.rsplit("@",1)[1])
        else: key=(template_ref,"1.0.0")
        template=self.templates.get(key)
        if template is None: raise CompositionValidationError(f"template not found: {template_ref}")
        schema_ref=template.get("parameter_schema_ref")
        if schema_ref:
            path=SCHEMA_DIR / str(schema_ref).rsplit(":",1)[-1]
            if path.exists(): SchemaValidator().validate_or_raise(dict(parameters),json.loads(path.read_text(encoding="utf-8")))
        refs=list(parameters.get("component_refs",()))
        draft=self.compose(refs,str(template.get("structural_kind","sequence")),{"tenant_id":tenant,"transaction_boundary":template.get("transaction_boundary","none"),"failure_handling":template.get("failure_handling","fail_fast"),"rollback_strategy":template.get("rollback_strategy","none"),"provenance":{"author":{"principal":str(context.auth_context.principal),"key_id":self.key_id},"method":"template","source_refs":[template_ref],"parent_compositions":[]}},context=context)
        draft.body["template_ref"]=template_ref
        return draft

    def _new_draft_version(self,draft:CompositionDraft)->CompositionDraft:
        draft.version += 1
        draft.body["composition_revision"]=draft.version
        return draft

    def add_step(self,draft:CompositionDraft,step:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["steps"].append(copy.deepcopy(dict(step))); return self._new_draft_version(draft)
    def remove_step(self,draft:CompositionDraft,step_id:str,*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["steps"]=[s for s in draft.body["steps"] if s["step_id"]!=step_id]; draft.body["edges"]=[e for e in draft.body["edges"] if e["from_step"]!=step_id and e["to_step"]!=step_id]; draft.body["entry_steps"]=[x for x in draft.body.get("entry_steps",()) if x!=step_id]; draft.body["terminal_steps"]=[x for x in draft.body.get("terminal_steps",()) if x!=step_id]; return self._new_draft_version(draft)
    def replace_step(self,draft:CompositionDraft,step_id:str,new_step:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin");
        for i,s in enumerate(draft.body["steps"]):
            if s["step_id"]==step_id: draft.body["steps"][i]=copy.deepcopy(dict(new_step)); return self._new_draft_version(draft)
        raise CompositionValidationError(f"unknown step {step_id}")
    def add_edge(self,draft:CompositionDraft,edge:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["edges"].append(copy.deepcopy(dict(edge))); return self._new_draft_version(draft)
    def remove_edge(self,draft:CompositionDraft,edge_ref:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["edges"]=[e for e in draft.body["edges"] if not all(e.get(k)==v for k,v in edge_ref.items())]; return self._new_draft_version(draft)
    def set_transaction_boundary(self,draft:CompositionDraft,boundary:str,*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["transaction_boundary"]=boundary; return self._new_draft_version(draft)
    def set_failure_handling(self,draft:CompositionDraft,mode:str,*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["failure_handling"]=mode; return self._new_draft_version(draft)
    def set_rollback_strategy(self,draft:CompositionDraft,strategy:str,*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["rollback_strategy"]=strategy; return self._new_draft_version(draft)
    def attach_verification_hook(self,draft:CompositionDraft,step_id:str,hook:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); h=copy.deepcopy(dict(hook)); h.setdefault("at_step",step_id); draft.body.setdefault("verification_hooks",[]).append(h); return self._new_draft_version(draft)
    def check_contracts(self,draft:CompositionDraft,*,context:ExecutionContext)->ContractCheckReport: return self.contract_check(draft,context=context)
    def capability_derive(self,draft:CompositionDraft,*,context:ExecutionContext)->DerivedSurfaceReport: return self.derive_surface(draft,context)
    def trust_derive(self,draft:CompositionDraft,*,context:ExecutionContext)->str: return self.derive_surface(draft,context).trust
    def idempotency_derive(self,draft:CompositionDraft,*,context:ExecutionContext)->str: return self.derive_surface(draft,context).idempotency
    def determinism_derive(self,draft:CompositionDraft,*,context:ExecutionContext)->str: return self.derive_surface(draft,context).determinism
    def diff(self,a:CompositionDraft,b:CompositionDraft)->dict[str,Any]:
        ak=a.body; bk=b.body; keys=sorted(set(ak)|set(bk)); return {k:{"a":ak.get(k),"b":bk.get(k)} for k in keys if ak.get(k)!=bk.get(k)}
    def deprecate(self,ref:str,successor_ref:str|None,*,context:ExecutionContext,reason:str="")->dict[str,Any]:
        result=self.fabric.deprecate(ref,successor_ref,context=context,reason=reason); self._emit("CompositionDeprecated",{"tool_ref":ref,"successor_ref":successor_ref},context,_tenant(context)); return result
    def retire(self,ref:str,successor_ref:str|None,*,context:ExecutionContext,reason:str="")->dict[str,Any]:
        result=self.fabric.retire(ref,successor_ref,context=context,reason=reason); self._emit("CompositionRetired",{"tool_ref":ref,"successor_ref":successor_ref},context,_tenant(context)); return result

    def _component_schemas(self,draft:CompositionDraft)->dict[str,dict[str,Any]]:
        out={}
        for s in draft.body["steps"]:
            m=self._get(s["component_tool_ref"],draft.tenant_id); out[s["step_id"]]=m
        return out

    def cycle_check(self,draft:CompositionDraft)->dict[str,Any]:
        graph={s["step_id"]:[] for s in draft.body["steps"]}
        for e in draft.body["edges"]:
            if e["kind"] in {"data","control","temporal","resource","exclusion"}: graph.setdefault(e["from_step"],[]).append(e["to_step"])
        visiting,set_done=set(),set()
        def dfs(n):
            if n in visiting: return True
            if n in set_done: return False
            visiting.add(n)
            for child in graph.get(n,[]):
                if dfs(child): return True
            visiting.remove(n); set_done.add(n); return False
        cyclic=any(dfs(n) for n in graph)
        if cyclic:
            if draft.body["structural_kind"] != "loop" or not draft.body.get("loop_bounds"):
                raise CycleError("composition cycle requires bounded loop declaration")
        return {"pass":True,"cycle":cyclic}

    def liveness_check(self,draft:CompositionDraft)->dict[str,Any]:
        ids={s["step_id"] for s in draft.body["steps"]}; starts=set(draft.body.get("entry_steps",())); terms=set(draft.body.get("terminal_steps",()))
        if not starts or not terms: raise LivenessError("entry_steps and terminal_steps are required")
        adj={i:set() for i in ids}; rev={i:set() for i in ids}
        for e in draft.body["edges"]:
            adj.setdefault(e["from_step"],set()).add(e["to_step"]); rev.setdefault(e["to_step"],set()).add(e["from_step"])
        reached=set(starts); q=list(starts)
        while q:
            n=q.pop()
            for c in adj.get(n,()):
                if c not in reached: reached.add(c); q.append(c)
        if reached != ids: raise LivenessError("unreachable composition steps")
        back=set(terms); q=list(terms)
        while q:
            n=q.pop()
            for p in rev.get(n,()):
                if p not in back: back.add(p); q.append(p)
        if back != ids: raise LivenessError("terminal steps do not cover all nodes")
        return {"pass":True,"reachable_steps":len(reached)}

    def type_check(self,draft:CompositionDraft,*,context:ExecutionContext)->TypeCheckReport:
        _require(context,"tools.selection.read")
        manifests=self._component_schemas(draft); failures=[]; anyb=[]; coercions=[]
        for e in draft.body["edges"]:
            if e["kind"] != "data": continue
            sm=manifests[e["from_step"]]; tm=manifests[e["to_step"]]
            ss=self._schema_from_manifest(sm,"outputs"); ts=self._schema_from_manifest(tm,"inputs")
            assigned=_assignable(ss,ts); e["type_check"].update({"source_schema_ref":sm["outputs"]["schema_ref"],"target_schema_ref":tm["inputs"]["schema_ref"],"assignable":assigned})
            if _schema_type(ss)=="any" or _schema_type(ts)=="any": anyb.append(f"{e['from_step']}->{e['to_step']}")
            if not assigned:
                tr=e.get("transform")
                if tr and self._transform_ok(tr): coercions.append({"edge":f"{e['from_step']}->{e['to_step']}","transform":tr}); e["type_check"]["coercion"]="declared"; assigned=True
            if not assigned: failures.append({"edge":f"{e['from_step']}->{e['to_step']}","source_schema":ss,"target_schema":ts})
        waiver=draft.body.get("any_boundary_waiver")
        if anyb and not waiver: failures.append({"any_boundaries":anyb,"reason":"signed waiver required"})
        unsigned={"report_id":_uuid(),"composition_id":draft.body["composition_id"],"all_edges_checked":len(draft.body["edges"]),"failing_edges":failures,"any_boundaries":anyb,"coercions":coercions,"pass":not failures}
        sig=_sign(unsigned,self.signer); return TypeCheckReport(unsigned["report_id"],unsigned["composition_id"],unsigned["all_edges_checked"],tuple(failures),tuple(anyb),tuple(coercions),not failures,sig)

    def _schema_from_manifest(self,m:Mapping[str,Any],part:str)->Mapping[str,Any]:
        ref=str(m[part]["schema_ref"])
        if ref.startswith("urn:jarvis:schema:"):
            name=ref.split(":",3)[-1]
            for suffix in (".json",):
                p=SCHEMA_DIR/name
                if p.exists(): return json.loads(p.read_text(encoding="utf-8"))
        resolver=self.fabric.schema_resolver
        if resolver is None: return {"type":"any"}
        return resolver(ref)

    def _transform_ok(self,ref:Any)->bool:
        if isinstance(ref,str): return ref in self.transforms
        if isinstance(ref,Mapping): return str(ref.get("transform_ref")) in self.transforms
        return False

    def contract_check(self,draft:CompositionDraft,*,context:ExecutionContext)->ContractCheckReport:
        issues=[]; b=draft.body
        try: self.cycle_check(draft); self.liveness_check(draft)
        except CompositionValidationError as exc: issues.append(str(exc))
        if b["transaction_boundary"] not in TRANSACTION_BOUNDARIES: issues.append("invalid transaction boundary")
        if b["failure_handling"] not in FAILURE_HANDLING: issues.append("invalid failure handling")
        if b["rollback_strategy"] not in ROLLBACK_STRATEGIES: issues.append("invalid rollback strategy")
        surface=self.derive_surface(draft,context)
        step_ids={s["step_id"] for s in b["steps"]}
        used_inputs=set()
        for step in b["steps"]:
            for bind in step.get("inputs",{}).values():
                if isinstance(bind,Mapping) and bind.get("kind")=="input": used_inputs.add(str(bind.get("name")))
        declared_unused=set(map(str,b.get("unused_inputs",())))
        for name in b.get("input_map",{}):
            if name not in used_inputs and name not in declared_unused: issues.append(f"unused composite input: {name}")
        for name,bind in b.get("output_map",{}).items():
            if isinstance(bind,Mapping) and bind.get("kind")=="output" and str(bind.get("step_id")) not in step_ids: issues.append(f"output {name} references unknown step")
        if b.get("structural_kind") in {"loop","map","reduce"}:
            bounds=b.get("loop_bounds") or {}
            if int(bounds.get("max_iterations",0)) < 1: issues.append("bounded iteration requires max_iterations >= 1")
        if b["transaction_boundary"]=="bounded" and not b.get("transaction_scope"): issues.append("bounded transaction requires scope")
        if b["transaction_boundary"]=="bounded" and b.get("transaction_scope") and not set(b["transaction_scope"]).issubset({s["step_id"] for s in b["steps"]}): issues.append("bounded transaction scope contains unknown steps")
        if b["transaction_boundary"]=="none" and set(surface.effects)!={"read_only"}: issues.append("none transaction is only legal for read_only effects")
        if b["rollback_strategy"]=="none" and set(surface.effects)-{"read_only"}: issues.append("rollback none only legal for read_only composites")
        for step in b["steps"]:
            m=self._get(step["component_tool_ref"],draft.tenant_id)
            if m.get("state") in {"revoked","retired"}: issues.append(f"component unavailable: {step['component_tool_ref']}")
            if m.get("state")=="deprecated" and not b.get("deprecated_component_waiver"): issues.append(f"deprecated component requires waiver: {step['component_tool_ref']}")
        irreversible = any(self._get(s["component_tool_ref"],draft.tenant_id)["reversibility"] in {"irreversible","unknown"} for s in b["steps"])
        if irreversible and b["rollback_strategy"]=="none": issues.append("irreversible composite requires rollback strategy")
        if b["transaction_boundary"]=="whole_pipeline" and not b.get("compensation_plan"): issues.append("whole_pipeline requires compensation plan")
        if b["transaction_boundary"]=="per_step":
            for step in b["steps"]:
                m=self._get(step["component_tool_ref"],draft.tenant_id)
                if m["reversibility"] in {"irreversible","unknown"} and not m.get("compensation",{}).get("tool_ref"): issues.append(f"{step['step_id']}: per_step transaction lacks rollback coverage")
        if b["failure_handling"] in {"compensating","transactional"} and not b.get("compensation_plan"): issues.append("compensation/transactional handling requires compensation plan")
        for step in b["steps"]:
            m=self._get(step["component_tool_ref"],draft.tenant_id)
            if m["invocation_kind"]=="composite":
                nested=m.get("composition",{})
                if nested.get("transaction_boundary") not in {None,"none"}: issues.append(f"{step['step_id']}: nested transaction boundary is forbidden")
        if b.get("verification_hooks"):
            hooks={str(h.get("at_step")) for h in b["verification_hooks"]}
            for sid in b.get("terminal_steps",()):
                if "post_terminal" not in hooks and sid not in hooks: issues.append("terminal verification hook missing")
            if b.get("rollback_strategy") in {"compensation","transactional","hybrid"} and "post_compensation" not in hooks: issues.append("post_compensation verification hook missing")
        highrisk=set(surface.effects)&HIGH_RISK_EFFECTS
        if highrisk and not b.get("verification_hooks"): issues.append("high-risk composite requires verification hooks")
        for step in b["steps"]:
            m=self._get(step["component_tool_ref"],draft.tenant_id)
            if m["reversibility"]=="irreversible" and not any(h.get("at_step")==step["step_id"] and h.get("required") for h in b.get("verification_hooks",())): issues.append(f"{step['step_id']}: irreversible step requires verification hook")
        # signed any-boundary waiver
        if draft.body.get("any_boundary_waiver"):
            waiver=dict(draft.body["any_boundary_waiver"]); sig=waiver.pop("signature",None)
            if not sig: issues.append("any-boundary waiver is unsigned")
            else:
                try: self.signer.public_key().verify(base64.b64decode(str(sig)),canonical_bytes(waiver))
                except Exception: issues.append("any-boundary waiver signature invalid")
        sig=_sign({"composition_id":b["composition_id"],"passed":not issues,"issues":issues},self.signer)
        return ContractCheckReport(b["composition_id"],not issues,tuple(issues),sig)

    def budget_aggregate(self,draft:CompositionDraft,*,context:ExecutionContext)->AggregateBudgetReport:
        manifests=self._component_schemas(draft); totals={k:0.0 for k in ("cpu_seconds","wall_seconds","ram_mb","vram_mb","network_bytes","api_calls","tool_calls","tokens_in","tokens_out","cost_units")}
        structural=draft.body["structural_kind"]
        vals=[]
        for s in draft.body["steps"]:
            r=manifests[s["step_id"]]["resources"]; item={k:float(r.get(k+"_typical",r.get(k,0))) for k in totals}; item["tool_calls"] = max(1.0,item.get("tool_calls",1.0))
            retry=s.get("retry_policy") or {}
            attempts=max(1,int(retry.get("max_attempts",1)))
            for k in totals: item[k] *= attempts
            vals.append(item)
        if structural in {"parallel","join"}: agg={k:max((v[k] for v in vals),default=0.0) for k in totals}
        elif structural in {"loop","map","reduce"}:
            bound=int((draft.body.get("loop_bounds") or {}).get("max_iterations",1)); agg={k:v*bound for k,v in {kk:sum(x[kk] for x in vals) for kk in totals}.items()}
        elif structural=="branch": agg={k:max((v[k] for v in vals),default=0.0) for k in totals}
        else: agg={k:sum(v[k] for v in vals) for k in totals}
        if draft.body.get("compensation_plan"):
            comp=draft.body["compensation_plan"].get("max_total_budget",{})
            for k,v in comp.items(): agg[k]=max(float(agg.get(k,0)),float(agg.get(k,0))+float(v))
        ceiling={k:float(draft.body.get("budget_ceiling",{}).get(k,agg[k])) for k in totals}
        passed=all(ceiling[k]+1e-9>=agg[k] for k in totals)
        sig=_sign({"composition_id":draft.body["composition_id"],"worst_case":agg,"passed":passed},self.signer)
        return AggregateBudgetReport(draft.body["composition_id"],agg,passed,sig)

    def derive_surface(self,draft:CompositionDraft,context:ExecutionContext)->DerivedSurfaceReport:
        manifests=self._component_schemas(draft)
        caps=set(); perms=None; scopes=None; effects=set(); rev=min((REV_RANK.get(m["reversibility"],0) for m in manifests.values()),default=0); trust=min((TRUST_RANK.get(m["trust"],0) for m in manifests.values()),default=0); idem=min((IDEM_RANK.get(m["idempotency"]["declared"],0) for m in manifests.values()),default=0); det=min((DET_RANK.get(m["determinism"]["declared"],0) for m in manifests.values()),default=0); max_latency=0; cost=0.0
        # Authorization is conjunctive across every component: callers must be able
        # to satisfy all component permissions/scopes, not merely the intersection.
        latency_values=[]
        structural=draft.body.get("structural_kind","sequence")
        for m in manifests.values():
            caps.update(map(str,m.get("capabilities_provided",())))
            p=set(map(str,m.get("required_permissions",())))
            s=set(map(str,m.get("required_scopes",())))
            perms = p if perms is None else perms.union(p)
            scopes = s if scopes is None else scopes.union(s)
            effects.update(m.get("effect_class",()))
            latency_values.append(int(m.get("timeout_ms_max",0)))
            cost += float(m.get("resources",{}).get("cost_units_max",m.get("resources",{}).get("cost_units_typical",0.0)))
        max_latency = (max(latency_values, default=0) if structural in {"parallel","join","branch"} else sum(latency_values))
        report=DerivedSurfaceReport(draft.body["composition_id"],tuple(sorted(caps)),tuple(sorted(perms or set())),tuple(sorted(scopes or set())),tuple(sorted(effects)),REV_NAME[rev],TRUST_NAME[trust],self._cost_class(cost),IDEM_NAME[idem],DET_NAME[det],max_latency,cost,_sign({"composition_id":draft.body["composition_id"],"capabilities":sorted(caps),"permissions":sorted(perms or set()),"scopes":sorted(scopes or set()),"effects":sorted(effects),"reversibility":REV_NAME[rev],"trust":TRUST_NAME[trust],"cost_class":self._cost_class(cost),"idempotency":IDEM_NAME[idem],"determinism":DET_NAME[det],"max_latency_ms":max_latency,"worst_case_cost_units":cost},self.signer))
        return report

    @staticmethod
    def _cost_class(cost:float)->str:
        if cost<=0: return "free"
        if cost<=1: return "cheap"
        if cost<=10: return "moderate"
        if cost<=100: return "expensive"
        return "metered"

    def reversibility_derive(self,draft:CompositionDraft)->dict[str,Any]:
        manifests=self._component_schemas(draft); issues=[]; values=[]
        for s,m in manifests.items():
            if m["reversibility"] in {"reversible","partially_reversible"} and not m.get("compensation",{}).get("tool_ref") and m["reversibility"]=="reversible": issues.append(f"{s}: reversible tool has no compensation")
            values.append(m["reversibility"])
        derived="irreversible" if "unknown" in values or "irreversible" in values else "partially_reversible" if "partially_reversible" in values else "reversible"
        return {"reversibility":derived,"issues":issues,"pass":not issues}

    def attach_compensation(self,draft:CompositionDraft, plan:Mapping[str,Any],*,context:ExecutionContext)->CompositionDraft:
        _require(context,"tools.admin"); draft.body["compensation_plan"]=copy.deepcopy(dict(plan)); draft.version+=1; return draft

    def verify_compensation_plan(self,draft:CompositionDraft,*,context:ExecutionContext)->dict[str,Any]:
        plan=draft.body.get("compensation_plan")
        if not plan: return {"pass":True,"issues":[]}
        issues=[]; by_target={str(x.get("targets_step_id")):x for x in plan.get("steps",())}
        for step in draft.body.get("steps",()):
            m=self._get(step["component_tool_ref"],draft.tenant_id); rev=m.get("reversibility")
            comp_ref=m.get("compensation",{}).get("tool_ref")
            if rev=="reversible":
                cp=by_target.get(str(step["step_id"]))
                if not cp: issues.append(f"missing compensation for {step['step_id']}")
                elif comp_ref and cp.get("compensation_tool_ref")!=comp_ref: issues.append(f"compensation mismatch for {step['step_id']}")
        if draft.body.get("transaction_boundary")=="whole_pipeline" and not plan.get("verification"): issues.append("whole_pipeline compensation requires verification")
        forward=draft.body.get("budget_ceiling",{})
        comp=plan.get("max_total_budget",{})
        for k,v in comp.items():
            if float(v)>float(forward.get(k,0)): issues.append(f"compensation budget exceeds {k}")
        sig=_sign({"composition_id":draft.body["composition_id"],"issues":issues,"pass":not issues},self.signer)
        return {"pass":not issues,"issues":issues,"signature":sig}

    def validate(self,draft:CompositionDraft,*,context:ExecutionContext)->dict[str,Any]:
        _tenant(context,draft.tenant_id); _require(context,"tools.selection.read")
        try: SchemaValidator().validate_or_raise(draft.body,_schema("composite_tool_manifest_v1.schema.json"))
        except Exception as exc: raise CompositionValidationError(str(exc)) from exc
        tc=self.type_check(draft,context=context); cc=self.contract_check(draft,context=context); br=self.budget_aggregate(draft,context=context); ds=self.derive_surface(draft,context); rv=self.reversibility_derive(draft)
        if not tc.passed: raise TypeCheckError("type check failed")
        if not cc.passed: raise ContractCheckError("contract check failed: "+"; ".join(cc.issues))
        if not br.passed: raise CompositionValidationError("budget ceiling below worst-case aggregate")
        current_ceiling=draft.body.setdefault("budget_ceiling",{})
        for key,value in br.worst_case.items(): current_ceiling.setdefault(key, int(value) if key in {"ram_mb","vram_mb","network_bytes","api_calls","tool_calls","tokens_in","tokens_out"} else float(value))
        comp_check=self.verify_compensation_plan(draft,context=context)
        if not comp_check["pass"]: raise CompositionValidationError("compensation verification failed: "+"; ".join(comp_check["issues"]))
        declared=draft.body.get("declared_derived",{})
        if declared:
            for k in ("reversibility","trust","cost_class","idempotency","determinism"): 
                if k in declared and declared[k] != getattr(ds,k if k not in {"reversibility"} else "reversibility"): raise CompositionValidationError(f"declared {k} does not match derived")
        high=set(ds.effects)&HIGH_RISK_EFFECTS
        if high: draft.body["simulation_required"] = True
        draft.body["derived"]={"capability_union":list(ds.capabilities),"permission_union":list(ds.permissions),"scope_union":list(ds.scopes),"effect_union":list(ds.effects),"reversibility":ds.reversibility,"trust":ds.trust,"cost_class":ds.cost_class,"idempotency":ds.idempotency,"determinism":ds.determinism,"max_latency_ms":ds.max_latency_ms,"worst_case_cost_units":ds.worst_case_cost_units}
        draft.body["state"]="validated"
        self._emit("CompositionValidated",{"composition_id":draft.body["composition_id"]},context,draft.tenant_id)
        return {"pass":True,"type_check":{"report_id":tc.report_id,"composition_id":tc.composition_id,"all_edges_checked":tc.all_edges_checked,"failing_edges":list(tc.failing_edges),"any_boundaries":list(tc.any_boundaries),"coercions":list(tc.coercions),"pass":tc.passed,"signature":tc.signature},"contract":{"composition_id":cc.composition_id,"pass":cc.passed,"issues":list(cc.issues),"signature":cc.signature},"budget":{"composition_id":br.composition_id,"worst_case":dict(br.worst_case),"pass":br.passed,"signature":br.signature},"derived":draft.body["derived"]}

    def register(self,draft:CompositionDraft,*,context:ExecutionContext)->str:
        _require(context,"tools.register"); self.validate(draft,context=context)
        if draft.body["simulation_required"]:
            if self.p2k_simulator is None: raise SimulationRequired("simulation required but P2-K handoff is unavailable")
            outcome=self.p2k_simulator(copy.deepcopy(draft.body),context)
            if not bool(outcome.get("success",False)): raise SimulationRequired("simulation did not authorize registration")
            draft.body["simulation_outcome_ref"]=str(outcome.get("simulation_outcome_ref",_uuid()))
            draft.body["simulation_report"]=copy.deepcopy(dict(outcome))
        effects=set(draft.body["derived"]["effect_union"]); scopes=set(_public_scopes(context))
        if effects & HIGH_RISK_EFFECTS and not ("security.authorize.composition" in scopes or "tools.admin" in scopes): raise RegistrationDenied("Security Authority authorization required for high-risk composite")
        self._emit("CompositionAuthorized",{"composition_id":draft.body["composition_id"]},context,draft.tenant_id)
        if draft.body["derived"]["determinism"] in {"deterministic","seeded"} and not draft.body.get("determinism_proof_ref"):
            proof_body={"model_or_tool_ref":f"jarvis.composite.{draft.body['composition_id']}","environment_hash":_sha({"composition_id":draft.body["composition_id"],"steps":draft.body["steps"]}),"runs":1,"method_version":"2.0.0","output_hashes":[_sha(draft.body.get("output_map",{}))],"key_id":self.fabric.key_id,"signature":""}
            proof_body["signature"]=_sign(proof_body,self.fabric.signer)
            draft.body["determinism_proof_ref"]=self.fabric.register_determinism_proof(proof_body,context=context,tenant_id=draft.tenant_id)
        draft.body["signature_key_id"]=self.key_id
        draft.body["integrity_hash"]=_sha({k:v for k,v in draft.body.items() if k not in {"signature","integrity_hash"}})
        draft.body["signature"]=_sign({k:v for k,v in draft.body.items() if k!="signature"},self.signer)
        # Build a first-class P2-P manifest. The composition body is retained in the target closure/registry lineage.
        b=draft.body; d=b["derived"]
        tool_id=str(b.get("tool_id",f"jarvis.composite.{b['composition_id']}")); version=str(b.get("tool_version",b["composition_version"]))
        manifest={"tool_id":tool_id,"tool_version":version,"tool_family":"composite","display_name":b.get("display_name",tool_id),"description":b.get("description",f"Composite tool {tool_id}"),"invocation_kind":"composite","composition":copy.deepcopy(b),"supports_dry_run":True,"effect_class":d["effect_union"],"reversibility":d["reversibility"],"trust":d["trust"],"cost_class":d["cost_class"],"signature":"","signature_key_id":self.fabric.key_id,"integrity_hash":"","manifest_hash":"","inputs":{"schema_ref":b.get("inputs_schema_ref","urn:jarvis:schema:composite.input"),"required":list((b.get("input_map") or {}).keys()),"optional":[],"examples":[]},"outputs":{"schema_ref":b.get("outputs_schema_ref","urn:jarvis:schema:composite.output"),"examples":[],"error_schema_ref":None},"side_effects":[],"preconditions":b.get("preconditions",[]),"postconditions":b.get("postconditions",[]),"invariants":b.get("invariants",[]),"capabilities_provided":d["capability_union"],"capabilities_required":[],"required_permissions":d["permission_union"],"required_scopes":d["scope_union"],"resources":{"cpu_seconds_typical":b["budget_ceiling"].get("cpu_seconds",0),"cpu_seconds_max":b["budget_ceiling"].get("cpu_seconds",0),"ram_mb_typical":b["budget_ceiling"].get("ram_mb",0),"ram_mb_max":b["budget_ceiling"].get("ram_mb",0),"network_bytes_typical":b["budget_ceiling"].get("network_bytes",0),"network_bytes_max":b["budget_ceiling"].get("network_bytes",0),"disk_bytes_write_max":0,"api_calls":b["budget_ceiling"].get("api_calls",0),"cost_units_typical":d["worst_case_cost_units"],"cost_units_max":d["worst_case_cost_units"],"latency_ms_typical":d["max_latency_ms"]},"timeout_ms_default":min(d["max_latency_ms"] or 1000,300000),"timeout_ms_max":max(d["max_latency_ms"] or 1000,1000),"rate_limit":None,"concurrency_limit":None,"dependencies":{"tools":[s["component_tool_ref"] for s in b["steps"]],"models":[],"skills":[],"system_packages":[],"runtime_version":"v12.8.3"},"environment_requirements":{"os":[],"arch":[],"network_required":bool("external" in d["effect_union"]),"gpu_required":False,"devices":[]},"failure_modes":[{"failure_class":"partial","description":"Composite step failure","retryable":False}],"determinism":{"declared":d["determinism"],"proof_ref":b.get("determinism_proof_ref"),"seed_parameter":"seed" if d["determinism"]=="seeded" else None},"idempotency":{"declared":d["idempotency"],"key_parameter":b.get("idempotency_key_parameter")},"compensation":{"tool_ref":None,"parameter_mapping":None,"preconditions":[]},"provenance":{"origin":f"urn:jarvis:composition:{b['composition_id']}","author":b["provenance"]["author"],"license":"JARVIS-Internal","license_uri":"urn:jarvis:license:internal","published_at":_utc(),"verified_by":None,"lineage":[s["component_tool_ref"] for s in b["steps"]]},"safety_policy_ref":"urn:jarvis:policy:composite","content_filters":[],"data_classification":"internal","pii_handling":"none","jurisdiction":None,"state":"registered","registered_at":_utc(),"deprecated_at":None,"revoked_at":None,"retired_at":None,"successor_ref":None,"lifecycle_reason":"P2-Q"}
        # Store composition body on an injected callable target so P2-P remains sole invocation path.
        ref=self.fabric.register(manifest,context=context,target=self._executor_for(draft))
        self._registered[(draft.tenant_id,ref)]=copy.deepcopy(draft.body); draft.body["registered_tool_ref"]=ref; draft.body["state"]="registered"
        self._emit("CompositionRegistered",{"composition_id":draft.body["composition_id"],"tool_ref":ref},context,draft.tenant_id)
        return ref

    def _executor_for(self,draft:CompositionDraft):
        def _target(inputs:Mapping[str,Any], *, context:ExecutionContext | None=None, dry_run:bool=False, seed:int|None=None, idempotency_key:str|None=None):
            if context is None: raise CompositionAccessDenied("ExecutionContext required")
            return self.invoke_registered(draft,inputs,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key)
        return _target

    def _run_verification_hooks(self,draft:CompositionDraft,at_step:str,*,context:ExecutionContext)->None:
        for hook in draft.body.get("verification_hooks",[]):
            if str(hook.get("at_step")) != str(at_step): continue
            result={"success":True}
            if self.p2n_verifier is not None:
                result=self.p2n_verifier({"composition_id":draft.body["composition_id"],"hook":copy.deepcopy(hook)},context)
            self._emit("CompositeVerificationHookFired",{"composition_id":draft.body["composition_id"],"hook_id":hook.get("hook_id"),"at_step":at_step,"success":bool(result.get("success",True))},context,draft.tenant_id)
            if hook.get("required") and not bool(result.get("success",False)):
                raise CompositionValidationError(f"verification hook failed: {hook.get('hook_id')}")

    @staticmethod
    def _safe_condition(expr: Any, *, inputs: Mapping[str,Any], outputs: Mapping[str,Any], item: Any = None) -> bool:
        if isinstance(expr, bool):
            return expr
        if expr is None:
            return False
        if isinstance(expr, Mapping):
            if "all" in expr: return all(ToolCompositionEngine._safe_condition(x, inputs=inputs, outputs=outputs, item=item) for x in expr["all"])
            if "any" in expr: return any(ToolCompositionEngine._safe_condition(x, inputs=inputs, outputs=outputs, item=item) for x in expr["any"])
            if "not" in expr: return not ToolCompositionEngine._safe_condition(expr["not"], inputs=inputs, outputs=outputs, item=item)
            path=expr.get("path")
            if path is not None:
                value: Any = {"inputs":inputs,"outputs":outputs,"item":item}
                for part in str(path).split("."):
                    if isinstance(value, Mapping): value=value.get(part)
                    else: value=getattr(value,part,None)
                if "equals" in expr: return value == expr["equals"]
                if "not_equals" in expr: return value != expr["not_equals"]
                if "in" in expr: return value in expr["in"]
                if "exists" in expr: return (value is not None) == bool(expr["exists"])
                return bool(value)
            return bool(expr.get("value",False))
        if not isinstance(expr,str): return bool(expr)
        text=expr.strip()
        if not text: return False
        try:
            node=ast.parse(text, mode="eval").body
        except SyntaxError as exc:
            raise CompositionValidationError(f"invalid condition expression: {expr}") from exc
        names={"inputs":dict(inputs),"outputs":dict(outputs),"item":item,"True":True,"False":False,"None":None}
        def ev(n: ast.AST) -> Any:
            if isinstance(n,ast.Constant): return n.value
            if isinstance(n,ast.Name):
                if n.id in names: return names[n.id]
                raise CompositionValidationError(f"unknown condition name: {n.id}")
            if isinstance(n,ast.Attribute):
                base=ev(n.value)
                if isinstance(base,Mapping): return base.get(n.attr)
                return getattr(base,n.attr,None)
            if isinstance(n,ast.Subscript):
                base=ev(n.value); key=ev(n.slice); return base[key]
            if isinstance(n,ast.Index): return ev(n.value)
            if isinstance(n,ast.BoolOp):
                vals=[bool(ev(x)) for x in n.values]
                return all(vals) if isinstance(n,ast.And) else any(vals)
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not): return not bool(ev(n.operand))
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd)): return -ev(n.operand) if isinstance(n.op,ast.USub) else +ev(n.operand)
            if isinstance(n,ast.Compare):
                left=ev(n.left)
                for op,right_node in zip(n.ops,n.comparators):
                    right=ev(right_node)
                    if isinstance(op,ast.Eq): ok=left==right
                    elif isinstance(op,ast.NotEq): ok=left!=right
                    elif isinstance(op,ast.Lt): ok=left<right
                    elif isinstance(op,ast.LtE): ok=left<=right
                    elif isinstance(op,ast.Gt): ok=left>right
                    elif isinstance(op,ast.GtE): ok=left>=right
                    elif isinstance(op,ast.In): ok=left in right
                    elif isinstance(op,ast.NotIn): ok=left not in right
                    else: raise CompositionValidationError("unsupported condition operator")
                    if not ok: return False
                    left=right
                return True
            raise CompositionValidationError(f"unsupported condition syntax: {type(n).__name__}")
        return bool(ev(node))

    def _execute_step(self, draft: CompositionDraft, step: Mapping[str,Any], base_inputs: Mapping[str,Any], current_outputs: Mapping[str,Any], *, context: ExecutionContext, dry_run: bool, seed: int|None, idempotency_key: str|None) -> Mapping[str,Any]:
        self._ensure_open()
        ref=str(step["component_tool_ref"]); tenant=draft.tenant_id; manifest=self._get(ref,tenant)
        if manifest["state"] in {"revoked","retired"}: raise ToolRevoked(ref)
        local_inputs=dict(base_inputs)
        bound={str(name):self._resolve_binding(binding,local_inputs,current_outputs) for name,binding in dict(step.get("inputs",{})).items()}
        if not bound:
            if current_outputs:
                previous=current_outputs.get(str(step.get("previous_step_id","")))
                if previous is None:
                    previous=next(reversed(current_outputs.values()))
                bound=dict(previous) if isinstance(previous,Mapping) else {"value":previous}
            else:
                bound=dict(base_inputs)
        if step.get("skip_when") and self._safe_condition(step["skip_when"], inputs=base_inputs, outputs=current_outputs, item=base_inputs.get("item")):
            return {"step_id":step["step_id"],"tool_ref":ref,"status":"skipped","outputs":None,"inputs":bound,"attempts":0}
        if manifest.get("idempotency",{}).get("declared") == "per_key" and not idempotency_key:
            raise CompositionValidationError(f"step {step['step_id']} requires composite idempotency key")
        retry=step.get("retry_policy") or {}
        max_attempts=max(1,int(retry.get("max_attempts",1)))
        backoff=float(retry.get("backoff_seconds",0.0))
        max_backoff=float(retry.get("max_backoff_seconds",30.0))
        retryable_names=set(map(str,retry.get("retryable_exceptions",("TimeoutError","ToolTimeout","RateLimited","ConcurrencyLimited","AdapterError"))))
        last_exc: Exception | None=None
        for attempt in range(1,max_attempts+1):
            req={"invocation_id":_uuid(),"tenant_id":tenant,"tool_ref":ref,"manifest_hash":manifest["manifest_hash"],"inputs":bound,"timeout_ms":int(step.get("timeout_ms",manifest.get("timeout_ms_default",1000))),"dry_run":dry_run,"simulation_ref":draft.body.get("simulation_outcome_ref"),"seed":seed,"idempotency_key":idempotency_key}
            self._emit("CompositeStepStarted",{"composition_id":draft.body["composition_id"],"step_id":step["step_id"],"tool_ref":ref,"attempt":attempt},context,tenant)
            try:
                res=self.fabric.invoke(req,context=context)
                val=res.outputs
                self._emit("CompositeStepCompleted",{"composition_id":draft.body["composition_id"],"step_id":step["step_id"],"tool_ref":ref,"attempt":attempt},context,tenant)
                return {"step_id":step["step_id"],"tool_ref":ref,"status":"success","outputs":val,"inputs":bound,"attempts":attempt}
            except Exception as exc:
                last_exc=exc
                self._emit("CompositeStepFailed",{"composition_id":draft.body["composition_id"],"step_id":step["step_id"],"tool_ref":ref,"error":str(exc),"attempt":attempt},context,tenant)
                if attempt>=max_attempts or type(exc).__name__ not in retryable_names:
                    raise
                if backoff>0:
                    time.sleep(min(max_backoff,backoff*(2**(attempt-1))))
        raise last_exc or CompositionError("step failed without exception")

    def _selected_branch_steps(self, draft: CompositionDraft, inputs: Mapping[str,Any], outputs: Mapping[str,Any]) -> set[str]:
        rules=list(draft.body.get("branch_conditions") or [])
        if not rules:
            return {str(s["step_id"]) for s in draft.body["steps"]}
        selected=set()
        default=list(draft.body.get("branch_default_steps") or [])
        for rule in rules:
            sid=str(rule.get("step_id"))
            condition=rule.get("condition",rule.get("when",rule.get("if",False)))
            if condition is not None and self._safe_condition(condition,inputs=inputs,outputs=outputs,item=inputs.get("item")):
                selected.add(sid)
        if not selected: selected.update(map(str,default))
        return selected

    def _execute_steps(self, draft: CompositionDraft, steps: Sequence[Mapping[str,Any]], inputs: Mapping[str,Any], *, context: ExecutionContext, dry_run: bool, seed: int|None, idempotency_key: str|None, outputs: dict[str,Any] | None = None, completed_sink: list[Mapping[str,Any]] | None = None) -> tuple[dict[str,Any],list[Mapping[str,Any]]]:
        outputs = outputs if outputs is not None else {}
        results=[]
        sink = completed_sink if completed_sink is not None else results
        kind=str(draft.body.get("structural_kind","sequence"))
        if kind in {"parallel","join"}:
            max_workers=max(1,min(len(steps),int(getattr(context.budgets,"concurrency",1) or 1),32))
            if len(steps)<=1: max_workers=1
            with ThreadPoolExecutor(max_workers=max_workers,thread_name_prefix="jarvis-composite") as pool:
                futures={pool.submit(self._execute_step,draft,s,inputs,dict(outputs),context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key):s for s in steps}
                for future in as_completed(futures):
                    sr=future.result(); results.append(sr); sink.append(sr); outputs[str(sr["step_id"])] = sr.get("outputs")
            return outputs,results
        for step in steps:
            sr=self._execute_step(draft,step,inputs,outputs,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key)
            results.append(sr); sink.append(sr); outputs[str(sr["step_id"])] = sr.get("outputs")
            self._run_verification_hooks(draft,str(step["step_id"]),context=context)
        return outputs,results

    def invoke_registered(self,draft:CompositionDraft,inputs:Mapping[str,Any],*,context:ExecutionContext,dry_run:bool=False,seed:int|None=None,idempotency_key:str|None=None)->Mapping[str,Any]:
        self._ensure_open()
        tenant=_tenant(context,draft.tenant_id)
        self._run_verification_hooks(draft,"pre_entry",context=context)
        outputs:dict[str,Any]={}; completed:list[Mapping[str,Any]]=[]
        self._emit("CompositeInvoked",{"composition_id":draft.body["composition_id"],"dry_run":dry_run},context,tenant)
        kind=str(draft.body.get("structural_kind","sequence"))
        steps=list(draft.body.get("steps",()))
        try:
            if kind=="branch":
                chosen=self._selected_branch_steps(draft,inputs,outputs)
                active=[s for s in steps if str(s["step_id"]) in chosen]
                if not active: raise CompositionValidationError("branch selected no executable steps")
                outputs,completed=self._execute_steps(draft,active,inputs,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key,outputs=outputs,completed_sink=completed)
            elif kind in {"parallel","join"}:
                outputs,completed=self._execute_steps(draft,steps,inputs,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key,outputs=outputs,completed_sink=completed)
            elif kind in {"map","reduce"}:
                bounds=draft.body.get("loop_bounds") or {}
                source_name=str(bounds.get("items_input","items"))
                items=inputs.get(source_name,inputs.get("items"))
                if not isinstance(items,Sequence) or isinstance(items,(str,bytes,bytearray)): raise CompositionValidationError("map/reduce requires a sequence input")
                max_iterations=int(bounds.get("max_iterations",len(items)))
                if len(items)>max_iterations: raise CompositionValidationError("map/reduce exceeds max_iterations")
                mapped=[]
                for idx,item in enumerate(items):
                    local=dict(inputs); local[str(bounds.get("item_input","item"))]=item; local["index"]=idx
                    run_outputs,run_results=self._execute_steps(draft,steps,local,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key,outputs={})
                    completed.extend(run_results)
                    mapped.append(run_outputs.get(str(steps[-1]["step_id"])) if steps else item)
                if kind=="map": outputs["map_result"]=mapped
                else:
                    reducer=str(bounds.get("reducer","last"))
                    reducer_path=bounds.get("reducer_path")
                    def reduce_value(value: Any) -> Any:
                        if reducer_path and isinstance(value,Mapping):
                            current: Any=value
                            for part in str(reducer_path).split("."): current=current.get(part) if isinstance(current,Mapping) else None
                            return current
                        if isinstance(value,Mapping) and len(value)==1 and "value" in value: return value["value"]
                        return value
                    if reducer=="sum": result=sum(reduce_value(v) for v in mapped)
                    elif reducer=="concat":
                        result=[]
                        for value in mapped:
                            value=reduce_value(value)
                            result.extend(value if isinstance(value,list) else [value])
                    elif reducer=="merge":
                        result={}
                        for value in mapped:
                            if not isinstance(value,Mapping): raise CompositionValidationError("merge reducer requires mapping outputs")
                            result.update(value)
                    elif reducer=="first": result=mapped[0] if mapped else None
                    else: result=mapped[-1] if mapped else None
                    outputs["reduce_result"]=result
            elif kind=="loop":
                bounds=draft.body.get("loop_bounds") or {}; max_iterations=int(bounds.get("max_iterations",0))
                if max_iterations<1: raise LivenessError("loop requires positive max_iterations")
                for idx in range(max_iterations):
                    local=dict(inputs); local["iteration_index"]=idx
                    outputs,run_results=self._execute_steps(draft,steps,local,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key,outputs=outputs,completed_sink=completed)
                    completed.extend(run_results)
                    until=bounds.get("until")
                    if until is not None and self._safe_condition(until,inputs=local,outputs=outputs,item=None): break
            else:
                outputs,completed=self._execute_steps(draft,steps,inputs,context=context,dry_run=dry_run,seed=seed,idempotency_key=idempotency_key,outputs=outputs,completed_sink=completed)
        except Exception:
            if draft.body.get("failure_handling") in {"compensating","transactional"} or draft.body.get("rollback_strategy") in {"compensation","transactional","hybrid","checkpoint"}:
                rollback=self._compensate(draft,completed,context=context,dry_run=dry_run)
                self._run_verification_hooks(draft,"post_compensation",context=context)
                if rollback.get("status")!="completed": raise CompositionError("rollback did not complete")
            if draft.body.get("failure_handling") in {"continue","escalate"} and kind in {"try_catch","saga"}:
                self._emit("CompositeFailureHandled",{"composition_id":draft.body["composition_id"],"mode":draft.body["failure_handling"]},context,tenant)
            else:
                raise
        self._run_verification_hooks(draft,"post_terminal",context=context)
        terminal_values={k:self._resolve_binding(v,inputs,outputs) for k,v in (draft.body.get("output_map") or {}).items()}
        if terminal_values: return terminal_values
        if kind in {"map","reduce"}: return outputs
        terminal = list(draft.body.get("terminal_steps",()))
        if kind in {"parallel","join","branch"} and not draft.body.get("output_map"):
            return outputs
        return outputs.get(str(terminal[-1])) if terminal else outputs

    def _resolve_binding(self,binding:Any,inputs:Mapping[str,Any],outputs:Mapping[str,Any])->Any:
        if not isinstance(binding,Mapping): return binding
        kind=str(binding.get("kind",binding.get("type", "literal")))
        if kind=="literal": return copy.deepcopy(binding.get("value"))
        if kind=="input": return inputs.get(str(binding["name"]))
        if kind=="output": return outputs.get(str(binding["step_id"]),{}).get(str(binding.get("name"))) if isinstance(outputs.get(str(binding["step_id"])),Mapping) else outputs.get(str(binding["step_id"]))
        if kind=="default": return inputs.get(str(binding.get("name")),binding.get("value"))
        if kind=="secret_ref": return {"secret_ref":str(binding["ref"])}
        if kind=="env": return {"env_ref":str(binding["ref"])}
        if kind=="collect": return [outputs.get(str(s)) for s in binding.get("steps",())]
        if kind=="transform":
            source=self._resolve_binding(binding.get("source"),inputs,outputs); ref=str(binding.get("transform_ref")); t=self.transforms.get(ref)
            if not t: raise CompositionValidationError("transform is not registered")
            transform_id=str(t.get("transform_id"))
            if transform_id=="identity": return source
            raise CompositionValidationError(f"unsupported transform implementation: {transform_id}")
        raise CompositionValidationError(f"unknown binding kind {kind}")

    def _compensate(self,draft:CompositionDraft,completed:list[Mapping[str,Any]],*,context:ExecutionContext,dry_run:bool)->Mapping[str,Any]:
        plan=draft.body.get("compensation_plan") or {}; results=[]
        by_id={c["step_id"]:c for c in completed}
        order=list(reversed([c["step_id"] for c in completed]))
        if not plan and draft.body.get("rollback_strategy")=="checkpoint" and self.checkpoint_restorer is not None:
            result=self.checkpoint_restorer({"composition_id":draft.body["composition_id"],"completed_steps":copy.deepcopy(completed)},context)
            return {"status":"completed" if bool(result.get("success",False)) else "failed","steps":[],"checkpoint":result}
        if not plan and draft.body.get("rollback_strategy")=="checkpoint" and self.checkpoint_restorer is None:
            return {"status":"failed","steps":[],"reason":"checkpoint_restorer unavailable"}
        explicit={str(s.get("targets_step_id")):s for s in plan.get("steps",[])}
        for sid in order:
            cp=explicit.get(sid)
            if not cp: continue
            ref=str(cp["compensation_tool_ref"]); m=self._get(ref,draft.tenant_id)
            cp_map=cp.get("parameter_mapping") or {}
            forward=by_id.get(sid,{})
            source_inputs=dict(forward.get("inputs",{})) if isinstance(forward.get("inputs"),Mapping) else {}
            source_outputs=dict(forward.get("outputs",{})) if isinstance(forward.get("outputs"),Mapping) else {}
            comp_inputs=dict(source_outputs or source_inputs)
            if cp_map:
                comp_inputs={}
                for target_name, source in cp_map.items():
                    if isinstance(source,Mapping): comp_inputs[str(target_name)]=self._resolve_binding(source,source_inputs,{sid:source_outputs})
                    elif isinstance(source,str) and source.startswith("output:"): comp_inputs[str(target_name)]=source_outputs.get(source.split(":",1)[1])
                    elif isinstance(source,str) and source.startswith("input:"): comp_inputs[str(target_name)]=source_inputs.get(source.split(":",1)[1])
                    else: comp_inputs[str(target_name)]=source
            req={"invocation_id":_uuid(),"tenant_id":draft.tenant_id,"tool_ref":ref,"manifest_hash":m["manifest_hash"],"inputs":comp_inputs,"timeout_ms":int(m.get("timeout_ms_default",1000)),"dry_run":dry_run,"simulation_ref":draft.body.get("simulation_outcome_ref"),"idempotency_key":None}
            self._emit("CompositeCompensationStarted",{"composition_id":draft.body["composition_id"],"targets_step_id":sid,"tool_ref":ref},context,draft.tenant_id)
            try:
                r=self.fabric.invoke(req,context=context); results.append({"targets_step_id":sid,"status":"success","tool_ref":ref,"outputs":r.outputs}); self._emit("CompositeCompensationCompleted",{"composition_id":draft.body["composition_id"],"targets_step_id":sid},context,draft.tenant_id)
            except Exception as exc:
                self._emit("CompositeCompensationFailed",{"composition_id":draft.body["composition_id"],"targets_step_id":sid,"error":str(exc)},context,draft.tenant_id)
                if plan.get("stop_on_failure","escalate") in {"abort","escalate"}: raise CompositionError("CompensationFailure") from exc
        return {"status":"completed","steps":results}

    def simulate(self,ref:str,*,context:ExecutionContext,simulation_config:Mapping[str,Any]|None=None)->Mapping[str,Any]:
        tenant=_tenant(context); _require(context,"tools.invoke"); draft=self._registered.get((tenant,ref));
        if draft is None: raise ToolNotFound(ref)
        if self.p2k_simulator is None: raise SimulationRequired("P2-K handoff unavailable")
        return self.p2k_simulator({"composition":copy.deepcopy(draft),"simulation_config":copy.deepcopy(simulation_config or {})},context)

    def verify(self,ref:str,execution_ref:str,*,context:ExecutionContext)->Mapping[str,Any]:
        _require(context,"tools.invoke")
        if self.p2n_verifier is None: return {"status":"pending","execution_ref":execution_ref,"verification_ref":_uuid()}
        return self.p2n_verifier({"tool_ref":ref,"execution_ref":execution_ref},context)

    def revoke(self,ref:str,*,context:ExecutionContext,reason:str="")->dict[str,Any]:
        _require(context,"tools.admin"); result=self.fabric.revoke(ref,context=context,reason=reason); tenant=_tenant(context); comp=self._registered.get((tenant,ref)); payload={"tool_ref":ref,"reason":reason,"dependent_composites":[]}
        if self.revocation_propagator:
            propagated=self.revocation_propagator(ref); payload["dependent_composites"]=list(propagated.get("composites",())) if isinstance(propagated,Mapping) else []
        self._emit("CompositionRevocationPropagated",payload,context,tenant); return result

    def events(self)->list[dict[str,Any]]: return copy.deepcopy(self._events)
    def close(self)->None:
        with self._lock:
            self._closed=True
            self._drafts.clear()
            self._registered.clear()
            self.transforms.clear()
            self.templates.clear()
    def __enter__(self): return self
    def __exit__(self,*args:Any)->None: self.close()

# Compatibility aliases / public API helpers
ToolComposition = ToolCompositionEngine

def composition_manifest_body(draft: CompositionDraft) -> dict[str,Any]: return copy.deepcopy(draft.body)

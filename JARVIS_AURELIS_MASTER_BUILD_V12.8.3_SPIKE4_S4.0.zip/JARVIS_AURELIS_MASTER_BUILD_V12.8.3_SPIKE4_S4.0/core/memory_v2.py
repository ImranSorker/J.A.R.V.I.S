"""Typed multi-class memory with provenance, decay, contradiction and consolidation."""
from __future__ import annotations

import hashlib
import hmac
import threading
import time
import uuid
from dataclasses import asdict, dataclass, replace
from enum import StrEnum
from typing import Any, Mapping


class MemoryClass(StrEnum):
    """Durable cognitive memory classes."""
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    PREFERENCE = "preference"


@dataclass(frozen=True, slots=True)
class MemoryItem:
    """Provenance-rich memory record."""
    memory_id: str
    owner: str
    workspace: str
    session_id: str
    kind: MemoryClass
    content: str
    source: str
    created_at: float
    confidence: float = 1.0
    importance: float = 0.5
    freshness: float = 1.0
    retention_seconds: float | None = None
    version: int = 1
    checksum: str = ""

    @classmethod
    def create(cls, *, owner: str, workspace: str, session_id: str, kind: MemoryClass, content: str, source: str, confidence: float = 1.0, importance: float = 0.5, retention_seconds: float | None = None) -> "MemoryItem":
        now = time.time()
        material = f"{owner}|{workspace}|{session_id}|{kind}|{content}|{source}|{now}|{uuid.uuid4().hex}".encode()
        base = hashlib.sha256(f"{owner}|{workspace}|{session_id}|{kind}|{content}|{source}|{now}".encode()).hexdigest()
        nonce = hashlib.sha256(material).hexdigest()
        checksum = base[:16] + nonce[16:]
        return cls(uuid.uuid4().hex, owner, workspace, session_id, kind, str(content), str(source), now, max(0.0, min(1.0, confidence)), max(0.0, min(1.0, importance)), 1.0, retention_seconds, 1, checksum)

    def integrity_valid(self, secret: bytes | None = None) -> bool:
        """Return whether the persisted checksum matches the record identity.

        When a secret is supplied, HMAC-SHA256 binds the record to its
        cryptographic memory namespace; without one, the legacy public digest
        remains available for backwards-compatible standalone records.
        """
        material = f"{self.owner}|{self.workspace}|{self.session_id}|{self.kind}|{self.content}|{self.source}|{self.created_at}".encode("utf-8")
        if secret is not None:
            expected = hmac.new(bytes(secret), material, hashlib.sha256).hexdigest()
            return bool(self.checksum) and hmac.compare_digest(self.checksum, expected)
        expected_prefix = hashlib.sha256(material).hexdigest()[:16]
        return bool(self.checksum) and self.checksum.startswith(expected_prefix)

    def expired(self, now: float | None = None) -> bool:
        """Return whether retention has elapsed."""
        return self.retention_seconds is not None and (now or time.time()) - self.created_at >= self.retention_seconds


class MemoryV2:
    """Thread-safe bounded memory store with namespace isolation and consolidation."""

    def __init__(self, *, max_items: int = 20_000, secret: bytes | None = None) -> None:
        self.max_items = max(1, min(int(max_items), 200_000))
        if secret is not None and len(secret) < 32:
            raise ValueError("memory namespace secret must contain at least 32 bytes")
        self._secret = bytes(secret) if secret is not None else None
        self._items: dict[str, MemoryItem] = {}
        self._lock = threading.RLock()

    def add(self, item: MemoryItem) -> MemoryItem:
        """Add or replace one memory item, sealing it to this namespace."""
        if not item.content.strip():
            raise ValueError("memory content cannot be empty")
        if self._secret is not None:
            material = f"{item.owner}|{item.workspace}|{item.session_id}|{item.kind}|{item.content}|{item.source}|{item.created_at}".encode("utf-8")
            item = replace(item, checksum=hmac.new(self._secret, material, hashlib.sha256).hexdigest())
        with self._lock:
            self._items[item.memory_id] = item
            if len(self._items) > self.max_items:
                victims = sorted(self._items.values(), key=lambda row: (row.importance, row.created_at))[: len(self._items) - self.max_items]
                for victim in victims:
                    self._items.pop(victim.memory_id, None)
        return item

    def query(self, *, owner: str, workspace: str, session_id: str | None = None, kind: MemoryClass | None = None, limit: int = 50) -> list[MemoryItem]:
        """Return only records from the exact owner/workspace namespace."""
        if limit < 1:
            return []
        with self._lock:
            rows = [item for item in self._items.values() if item.owner == owner and item.workspace == workspace and (session_id is None or item.session_id == session_id) and (kind is None or item.kind == kind)]
        return sorted(rows, key=lambda item: (item.importance * item.confidence * item.freshness, item.created_at), reverse=True)[:limit]

    def forget(self, memory_id: str, *, owner: str, workspace: str) -> bool:
        """Delete a memory only when its namespace matches."""
        with self._lock:
            item = self._items.get(memory_id)
            if item is None or item.owner != owner or item.workspace != workspace:
                return False
            del self._items[memory_id]
            return True

    def decay(self, *, half_life_seconds: float = 86_400.0) -> int:
        """Apply deterministic freshness decay and remove expired entries."""
        half_life = max(1.0, float(half_life_seconds)); now = time.time(); changed = 0
        with self._lock:
            for key, item in list(self._items.items()):
                if item.expired(now):
                    del self._items[key]; changed += 1; continue
                age = max(0.0, now - item.created_at)
                freshness = 0.5 ** (age / half_life)
                self._items[key] = replace(item, freshness=freshness)
        return changed

    def consolidate(self, *, owner: str, workspace: str, session_id: str, min_importance: float = 0.5) -> MemoryItem | None:
        """Merge high-value episodic memories into one semantic memory."""
        episodic = self.query(owner=owner, workspace=workspace, session_id=session_id, kind=MemoryClass.EPISODIC, limit=1000)
        selected = [item for item in episodic if item.importance >= min_importance]
        if len(selected) < 2:
            return None
        content = " | ".join(item.content.strip() for item in selected[:20])
        summary = MemoryItem.create(owner=owner, workspace=workspace, session_id=session_id, kind=MemoryClass.SEMANTIC, content=content[:10_000], source="memory.consolidation", confidence=sum(i.confidence for i in selected) / len(selected), importance=max(i.importance for i in selected))
        self.add(summary)
        return summary

    def export_state(self) -> list[dict[str, Any]]:
        """Export memory records without exposing internal locks or state."""
        with self._lock:
            return [asdict(item) for item in self._items.values()]

    def import_state(self, rows: list[Mapping[str, Any]]) -> None:
        """Replace records from a portable, already-authorized state domain."""
        restored: dict[str, MemoryItem] = {}
        for row in rows:
            item = MemoryItem(
                memory_id=str(row["memory_id"]), owner=str(row["owner"]), workspace=str(row["workspace"]), session_id=str(row["session_id"]),
                kind=MemoryClass(str(row["kind"])), content=str(row["content"]), source=str(row["source"]), created_at=float(row["created_at"]),
                confidence=float(row.get("confidence", 1.0)), importance=float(row.get("importance", 0.5)), freshness=float(row.get("freshness", 1.0)),
                retention_seconds=row.get("retention_seconds"), version=int(row.get("version", 1)), checksum=str(row.get("checksum", "")),
            )
            if not item.integrity_valid(self._secret):
                raise ValueError(f"memory integrity check failed: {item.memory_id}")
            restored[item.memory_id] = item
        if len(restored) > self.max_items:
            raise ValueError("portable memory state exceeds configured capacity")
        with self._lock:
            self._items = restored

    def snapshot(self) -> Mapping[str, int]:
        """Return observable counts by memory class."""
        with self._lock:
            return {kind.value: sum(item.kind == kind for item in self._items.values()) for kind in MemoryClass} | {"total": len(self._items), "cryptographic_namespace": self._secret is not None}



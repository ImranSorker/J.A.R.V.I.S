"""Routes inference requests to appropriate backends."""
from __future__ import annotations
import logging
import threading
import time
from typing import Any, Dict, Optional
from core.types import BackendResult
from core.model_swarm import ModelSwarm

logger = logging.getLogger("jarvis.router")


class ModelRouter:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._backends: Dict[str, Any] = {}
        self._primary: Optional[str] = None
        self._swarm: Optional[ModelSwarm] = None
        self._native_cfg = cfg.get("native", {})
        # Health tracking
        self._backend_health: Dict[str, Dict[str, Any]] = {}
        self._health_lock = threading.RLock()
        router_cfg = cfg.get("model_router", {})
        self._health_probe_interval = router_cfg.get("health_probe_interval_seconds", 30.0)
        self._max_failures = router_cfg.get("health_max_failures", 3)
        self._recovery_timeout = router_cfg.get("health_recovery_seconds", 60.0)

    def set_swarm(self, swarm: ModelSwarm, native_cfg: dict) -> None:
        self._swarm = swarm
        self._native_cfg = native_cfg

    def register_backend(self, name: str, backend, info=None) -> None:
        self._backends[name] = {"backend": backend, "info": info}

    def set_primary(self, name: str) -> None:
        if name in self._backends:
            self._primary = name
            logger.info(f"Primary backend set to {name}")

    @property
    def primary(self):
        if self._primary and self._primary in self._backends:
            return self._backends[self._primary]["info"]
        return None

    def _record_backend_success(self, name: str) -> None:
        with self._health_lock:
            entry = self._backend_health.setdefault(name, {"failures": 0, "last_success": time.monotonic(), "unhealthy_since": None})
            entry["failures"] = 0
            entry["last_success"] = time.monotonic()
            entry["unhealthy_since"] = None

    def _record_backend_failure(self, name: str, error: str) -> None:
        with self._health_lock:
            entry = self._backend_health.setdefault(name, {"failures": 0, "last_success": time.monotonic(), "unhealthy_since": None})
            entry["failures"] += 1
            if entry["failures"] >= self._max_failures and entry["unhealthy_since"] is None:
                entry["unhealthy_since"] = time.monotonic()
                logger.warning("backend_marked_unhealthy", extra={"backend": name, "failures": entry["failures"], "error": error})

    def _is_backend_healthy(self, name: str) -> bool:
        with self._health_lock:
            entry = self._backend_health.get(name)
            if entry is None:
                return True
            if entry["unhealthy_since"] is None:
                return True
            if time.monotonic() - entry["unhealthy_since"] >= self._recovery_timeout:
                logger.info("backend_recovery_probe", extra={"backend": name})
                entry["unhealthy_since"] = None
                entry["failures"] = 0
                return True
            return False

    def generate(self, prompt: str, backend_name: Optional[str] = None, stream: bool = False, **kwargs):
        request_id = kwargs.pop("request_id", None)
        kwargs.pop("task_type", None)  # routing hint is owned by the router, never a backend argument
        name = backend_name or self._primary
        if not name:
            if stream:
                return iter([BackendResult(text="[No backend configured]", ok=False, error_type="no_backend")])
            return BackendResult(text="[No backend configured]", ok=False, error_type="no_backend")
        explicit_backend = backend_name is not None
        candidates: list[str] = []
        if explicit_backend:
            # An explicitly named backend is strict: never silently substitute another backend.
            candidates = [name] if name else []
        else:
            # Implicit routing is failover-capable: primary first, then deterministic remaining backends.
            for candidate in ([self._primary] if self._primary else []) + list(self._backends):
                if candidate and candidate not in candidates:
                    candidates.append(candidate)
        if not candidates:
            if stream:
                return iter([BackendResult(text="[No backend configured]", ok=False, error_type="no_backend")])
            return BackendResult(text="[No backend configured]", ok=False, error_type="no_backend")
        # Filter unhealthy backends unless explicitly requested
        healthy_candidates = []
        for candidate in candidates:
            if explicit_backend:
                if candidate == backend_name and self._is_backend_healthy(candidate):
                    healthy_candidates.append(candidate)
                elif candidate == backend_name:
                    logger.debug("explicit_backend_unhealthy", extra={"backend": candidate})
            elif self._is_backend_healthy(candidate):
                healthy_candidates.append(candidate)
            else:
                logger.debug("backend_skipped_unhealthy", extra={"backend": candidate})
        if not healthy_candidates and not explicit_backend:
            healthy_candidates = candidates
        last_error = None
        for candidate in healthy_candidates:
            entry = self._backends.get(candidate)
            if not entry:
                continue
            try:
                result = entry["backend"].generate(prompt, stream=stream, **kwargs)
                if stream:
                    # Normalize streaming to BackendResult chunks. Health is committed
                    # only after the iterator reaches normal completion; a late model
                    # failure must remain eligible for fallback/recovery on the next call.
                    def _normalize_stream(raw_iter):
                        emitted = False
                        try:
                            for chunk in raw_iter:
                                if isinstance(chunk, BackendResult):
                                    chunk.backend = candidate
                                    chunk.request_id = request_id
                                    if chunk.model is None:
                                        chunk.model = getattr(entry.get("info"), "name", candidate)
                                    if not chunk.ok:
                                        self._record_backend_failure(candidate, chunk.error_type or chunk.text or "stream_error")
                                        yield chunk
                                        return
                                    emitted = emitted or bool(chunk.text)
                                    yield chunk
                                elif isinstance(chunk, str):
                                    emitted = emitted or bool(chunk)
                                    yield BackendResult(text=chunk, model=getattr(entry.get("info"), "name", candidate), request_id=request_id, backend=candidate)
                                else:
                                    text = getattr(chunk, "text", "")
                                    if text:
                                        emitted = True
                                        yield BackendResult(text=text, model=getattr(entry.get("info"), "name", candidate), request_id=request_id, backend=candidate)
                            self._record_backend_success(candidate)
                            logger.debug("backend_stream_completed", extra={"backend": candidate, "emitted": emitted})
                        except Exception as exc:
                            self._record_backend_failure(candidate, str(exc))
                            logger.warning("backend_stream_failed", extra={"backend": candidate, "error": str(exc)})
                            yield BackendResult(text=f"[Streaming backend failed: {exc}]", ok=False, error_type="stream_error", model=getattr(entry.get("info"), "name", candidate), request_id=request_id, backend=candidate)
                    return _normalize_stream(result)
                if isinstance(result, BackendResult) and not result.ok:
                    last_error = result.text or result.error_type or "backend_error"
                    self._record_backend_failure(candidate, last_error)
                    continue
                if isinstance(result, BackendResult):
                    result.backend = candidate
                    result.request_id = request_id
                    if result.model is None:
                        result.model = getattr(entry.get("info"), "name", candidate)
                return result
            except Exception as exc:
                last_error = str(exc)
                self._record_backend_failure(candidate, last_error)
                logger.warning("backend_failed", extra={"backend": candidate, "error": last_error})
        if stream:
            return iter([BackendResult(text=f"[All backends failed: {last_error or 'unknown error'}]", ok=False, error_type="all_backends_failed")])
        return BackendResult(text=f"[All backends failed: {last_error or 'unknown error'}]", ok=False, error_type="all_backends_failed")

    def list_backends(self) -> list[dict]:
        result = []
        for name, entry in self._backends.items():
            backend = entry.get("backend")
            loaded = getattr(backend, "is_loaded", False)
            if callable(loaded):
                try:
                    loaded = loaded()
                except Exception:
                    loaded = False
            info = entry.get("info") or {}
            result.append({
                "name": name,
                "type": type(backend).__name__,
                "format": info.get("format") if isinstance(info, dict) else None,
                "loaded": bool(loaded),
                "primary": name == self._primary,
            })
        return result

    def unload_all(self) -> None:
        for entry in self._backends.values():
            try:
                entry["backend"].unload()
            except Exception as exc:
                logger.debug("backend_unload_failed", exc_info=exc)



"""Adversarial security regression laboratory."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable


@dataclass(frozen=True)
class AdversarialCase:
    """Security probe with an expected deny/allow outcome."""
    case_id: str
    input_value: str
    expect_allowed: bool
    category: str


class AdversarialLab:
    """Run bounded security probes against an injected policy function."""

    def __init__(self, max_cases: int = 5000) -> None:
        self.max_cases = max(1, min(int(max_cases), 100_000))

    def run(self, cases: Iterable[AdversarialCase], evaluator: Callable[[str], bool]) -> dict[str, object]:
        """Execute probes and report mismatches without executing probe content."""
        selected = list(cases)[: self.max_cases]
        failures: list[dict[str, str]] = []
        for case in selected:
            try:
                actual = bool(evaluator(case.input_value))
            except Exception as exc:
                failures.append({"case_id": case.case_id, "category": case.category, "error": type(exc).__name__})
                continue
            if actual != case.expect_allowed:
                failures.append({"case_id": case.case_id, "category": case.category, "error": "policy_mismatch"})
        return {"ok": not failures, "cases": len(selected), "failures": failures}



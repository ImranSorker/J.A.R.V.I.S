"""Persona management."""
from __future__ import annotations
from typing import Dict

PERSONAS = {
    "default": "You are JARVIS, a helpful AI assistant.",
    "coder": "You are JARVIS, an expert software engineer. Write clean, documented code.",
    "researcher": "You are JARVIS, a thorough research assistant. Cite sources when possible.",
    "concise": "You are JARVIS. Be extremely concise and direct.",
    "teacher": "You are JARVIS, a patient educator. Explain concepts step by step.",
    "creative": "You are JARVIS, a creative partner. Think outside the box.",
}


class PersonaManager:
    def __init__(self):
        self._personas: Dict[str, str] = dict(PERSONAS)
        self.active = "default"

    def get_prompt(self, name: str | None = None) -> str:
        return self._personas.get(name or self.active, self._personas["default"])

    def list_personas(self) -> list[str]:
        return list(self._personas.keys())



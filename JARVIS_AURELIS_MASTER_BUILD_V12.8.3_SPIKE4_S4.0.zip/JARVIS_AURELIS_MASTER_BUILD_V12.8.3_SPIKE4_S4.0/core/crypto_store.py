"""AES-256-GCM encryption with versioned key hierarchy and rotation.

Supports:
  - Active/previous/retired key slots
  - Automatic rotation on configurable TTL
  - Re-encryption of persisted values when active key changes
  - Pluggable KeyProvider interface for external KMS/HSM integration
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:  # pragma: no cover - exercised in dependency-isolation environments
    AESGCM = None  # type: ignore[assignment, misc]


class KeyProvider(ABC):
    """Pluggable key source for external KMS/HSM integration."""

    @abstractmethod
    def get_key(self, key_id: str) -> bytes | None:
        """Return the raw 32-byte key for the given key_id, or None."""
        raise TypeError("KeyProvider.get_key must be implemented by the concrete provider")

    def get_legacy_key(self) -> bytes | None:
        """Return the v1 raw base key used by legacy envelopes, when supported.

        Providers that cannot safely reproduce the historical v1 key contract
        must return None.  This keeps legacy migration explicit rather than
        guessing a derivation from a current key slot.
        """
        return None

    @abstractmethod
    def list_key_ids(self) -> list[str]:
        """Return all known key IDs, newest first."""
        raise TypeError("KeyProvider.list_key_ids must be implemented by the concrete provider")


class EnvironmentKeyProvider(KeyProvider):
    """Derive keys from JARVIS_MASTER_SECRET environment variable."""

    def __init__(self, master_secret: Optional[str] = None) -> None:
        secret = master_secret if master_secret is not None else os.environ.get("JARVIS_MASTER_SECRET", "")
        self._base_key = hashlib.sha256(secret.encode("utf-8")).digest() if secret else None

    def get_key(self, key_id: str) -> bytes | None:
        if self._base_key is None:
            return None
        # Deterministic key derivation per key_id
        return hashlib.sha256(self._base_key + key_id.encode("utf-8")).digest()

    def get_legacy_key(self) -> bytes | None:
        """Return the historical v1 raw base key exactly."""
        return self._base_key

    def list_key_ids(self) -> list[str]:
        if self._base_key is None:
            return []
        return ["active", "previous", "retired"]


@dataclass(frozen=True)
class KeySlot:
    key_id: str
    key: bytes
    created_at: float
    expires_at: float


class CryptoStore:
    """Encrypt/decrypt small sensitive values with versioned key rotation."""

    CIPHER_VERSION = "v2"
    LEGACY_VERSION = "v1"
    KEY_ROTATION_TTL_SECONDS = 90 * 24 * 3600  # 90 days default

    def __init__(
        self,
        master_secret: Optional[str] = None,
        provider: Optional[KeyProvider] = None,
        rotation_ttl_seconds: float = KEY_ROTATION_TTL_SECONDS,
        state_path: str = "data/crypto_state.json",
    ) -> None:
        self._provider = provider or EnvironmentKeyProvider(master_secret)
        self._rotation_ttl = float(rotation_ttl_seconds)
        self._state_path = Path(state_path)
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._slots: dict[str, KeySlot] = {}
        self._active_key_id: str = "active"
        self._load_state()
        self._ensure_slots()

    @property
    def enabled(self) -> bool:
        return len(self._slots) > 0 and self._active_key_id in self._slots

    def _ensure_slots(self) -> None:
        now = time.time()
        for key_id in self._provider.list_key_ids():
            if key_id not in self._slots:
                key = self._provider.get_key(key_id)
                if key is not None:
                    self._slots[key_id] = KeySlot(
                        key_id=key_id,
                        key=key,
                        created_at=now,
                        expires_at=now + self._rotation_ttl,
                    )
        if self._active_key_id not in self._slots and self._slots:
            self._active_key_id = max(self._slots, key=lambda k: self._slots[k].created_at)
        self._save_state()

    def _load_state(self) -> None:
        if not self._state_path.exists():
            return
        try:
            with open(self._state_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._active_key_id = data.get("active_key_id", "active")
            for slot_data in data.get("slots", []):
                key_id = slot_data["key_id"]
                key = self._provider.get_key(key_id)
                if key is not None:
                    self._slots[key_id] = KeySlot(
                        key_id=key_id,
                        key=key,
                        created_at=float(slot_data["created_at"]),
                        expires_at=float(slot_data["expires_at"]),
                    )
        except Exception as exc:
            import logging
            logging.getLogger("jarvis.crypto").warning("crypto_state_load_failed", extra={"error": str(exc)})

    def _save_state(self) -> None:
        data = {
            "version": self.CIPHER_VERSION,
            "active_key_id": self._active_key_id,
            "slots": [
                {
                    "key_id": slot.key_id,
                    "created_at": slot.created_at,
                    "expires_at": slot.expires_at,
                }
                for slot in self._slots.values()
            ],
        }
        with open(self._state_path, "w", encoding="utf-8") as f:
            json.dump(data, f, default=str, indent=2)

    def _get_aes(self, key_id: str) -> AESGCM | None:
        slot = self._slots.get(key_id)
        if slot is None or AESGCM is None:
            return None
        return AESGCM(slot.key)

    def rotate_if_needed(self) -> bool:
        """Rotate the active key if it has expired. Returns True if rotation occurred."""
        with self._lock:
            active = self._slots.get(self._active_key_id)
            if active is None or time.time() < active.expires_at:
                return False
            # Promote: active -> previous -> retired
            new_slots: dict[str, KeySlot] = {}
            now = time.time()
            # Create new active
            new_active_id = f"active_{int(now)}"
            key = self._provider.get_key(new_active_id)
            if key is None:
                return False
            new_slots[new_active_id] = KeySlot(
                key_id=new_active_id,
                key=key,
                created_at=now,
                expires_at=now + self._rotation_ttl,
            )
            # Preserve the previous active key plus the two most recent predecessors.
            previous_id = self._active_key_id
            new_slots[previous_id] = active
            predecessors = sorted(
                [k for k in self._slots if k not in {self._active_key_id}],
                key=lambda k: self._slots[k].created_at,
                reverse=True,
            )[:2]
            for key_id in predecessors:
                new_slots[key_id] = self._slots[key_id]
            self._slots = new_slots
            self._active_key_id = new_active_id
            self._save_state()
            return True

    def encrypt(self, plaintext: str) -> str:
        if not self.enabled:
            raise RuntimeError("encryption unavailable: configure JARVIS_MASTER_SECRET and cryptography")
        self.rotate_if_needed()
        with self._lock:
            aes = self._get_aes(self._active_key_id)
            if aes is None:
                raise RuntimeError("encryption unavailable")
            nonce = os.urandom(12)
            ciphertext = aes.encrypt(nonce, plaintext.encode("utf-8"), self.CIPHER_VERSION.encode("ascii"))
            payload = {
                "v": self.CIPHER_VERSION,
                "kid": self._active_key_id,
                "ct": base64.urlsafe_b64encode(nonce + ciphertext).decode("ascii"),
            }
            return f"{self.CIPHER_VERSION}:{base64.urlsafe_b64encode(json.dumps(payload).encode('utf-8')).decode('ascii')}"

    def decrypt(self, envelope: str) -> str:
        if not self.enabled:
            raise RuntimeError("encryption unavailable")
        try:
            version, encoded = envelope.split(":", 1)
            if version == self.LEGACY_VERSION:
                return self._decrypt_legacy(envelope)
            if version != self.CIPHER_VERSION:
                raise ValueError(f"unsupported ciphertext version: {version}")
            raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
            payload = json.loads(raw.decode("utf-8"))
            key_id = payload["kid"]
            ct = base64.urlsafe_b64decode(payload["ct"].encode("ascii"))
            if len(ct) < 13:
                raise ValueError("ciphertext too short")
            nonce, ciphertext = ct[:12], ct[12:]
            aes = self._get_aes(key_id)
            if aes is None:
                raise ValueError(f"key unavailable: {key_id}")
            plaintext = aes.decrypt(nonce, ciphertext, self.CIPHER_VERSION.encode("ascii"))
            return plaintext.decode("utf-8")
        except Exception as exc:
            raise ValueError("invalid or tampered ciphertext") from exc

    def _decrypt_legacy(self, envelope: str) -> str:
        """Decrypt v1 envelopes for backward compatibility."""
        try:
            _, encoded = envelope.split(":", 1)
            raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
            if len(raw) < 13:
                raise ValueError("ciphertext too short")
            nonce, ciphertext = raw[:12], raw[12:]
            # v1 used the raw base key without key_id derivation.  Resolve that
            # historical contract from the provider instead of guessing from a
            # current derived v2 slot.
            legacy_key = self._provider.get_legacy_key()
            if legacy_key is None or len(legacy_key) != 32 or AESGCM is None:
                raise RuntimeError("legacy v1 key contract unavailable")
            aes = AESGCM(legacy_key)
            plaintext = aes.decrypt(nonce, ciphertext, self.LEGACY_VERSION.encode("ascii"))
            return plaintext.decode("utf-8")
        except Exception as exc:
            raise ValueError("invalid legacy ciphertext") from exc

    def re_encrypt(self, envelope: str) -> str:
        """Decrypt with current key and re-encrypt with active key."""
        plaintext = self.decrypt(envelope)
        return self.encrypt(plaintext)

    def active_key_info(self) -> dict[str, Any]:
        with self._lock:
            slot = self._slots.get(self._active_key_id)
            if slot is None:
                return {"enabled": False}
            return {
                "enabled": True,
                "key_id": slot.key_id,
                "created_at": slot.created_at,
                "expires_at": slot.expires_at,
                "ttl_remaining_seconds": max(0, slot.expires_at - time.time()),
                "slot_count": len(self._slots),
            }



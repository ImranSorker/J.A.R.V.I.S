"""Provider-independent model residency tracking."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class ResidencyRecord:
    """Observable residency state for a model resource."""
    model: str
    backend: str
    loaded: bool
    last_used: float
    pinned: bool = False


class ModelResidencyManager:
    """Track loaded models and evict least-recently-used unpinned entries."""

    def __init__(self, capacity: int = 2) -> None:
        self.capacity = max(1, int(capacity))
        self._records: dict[str, ResidencyRecord] = {}
        self._lock = threading.RLock()

    def touch(self, model: str, backend: str, *, pinned: bool = False) -> ResidencyRecord:
        now = time.monotonic()
        with self._lock:
            record = ResidencyRecord(model, backend, True, now, pinned)
            self._records[model] = record
            return record

    def release(self, model: str) -> ResidencyRecord | None:
        with self._lock:
            record = self._records.pop(model, None)
            return ResidencyRecord(record.model, record.backend, False, record.last_used, record.pinned) if record else None

    def evict_candidates(self) -> list[str]:
        with self._lock:
            active = [r for r in self._records.values() if r.loaded and not r.pinned]
            overflow = max(0, len(self._records) - self.capacity)
            return [r.model for r in sorted(active, key=lambda r: r.last_used)[:overflow]]

    def enforce_capacity(self, unload: Any) -> list[str]:
        """Evict candidates through an injected unload callback."""
        evicted: list[str] = []
        for model in self.evict_candidates():
            try:
                unload(model)
                self.release(model)
                evicted.append(model)
            except Exception:
                continue
        return evicted

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            return [{"model": r.model, "backend": r.backend, "loaded": r.loaded, "last_used": r.last_used, "pinned": r.pinned} for r in sorted(self._records.values(), key=lambda x: x.model)]



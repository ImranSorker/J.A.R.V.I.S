"""Production-grade metrics collection with Prometheus exposition.

Design goals:
- Thread-safe, lock-free reads where possible
- Bounded cardinality (no unbounded label sets)
- Automatic collection from registered producers
- Integration with HealthProbeRegistry for health-derived metrics
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("jarvis.metrics")


@dataclass(frozen=True)
class MetricLabel:
    name: str
    value: str

    def __post_init__(self):
        if not self.name or len(self.name) > 128:
            raise ValueError("invalid label name")
        if len(str(self.value)) > 1024:
            raise ValueError("label value too long")


class MetricType:
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"


@dataclass
class MetricValue:
    metric_name: str
    labels: Tuple[MetricLabel, ...]
    value: float
    timestamp: float = field(default_factory=time.time)


class Counter:
    """Monotonically increasing counter."""

    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self._value: float = 0.0
        self._lock = threading.Lock()

    def inc(self, amount: float = 1.0) -> None:
        with self._lock:
            self._value += max(0.0, amount)

    def get(self) -> float:
        with self._lock:
            return self._value

    def snapshot(self) -> MetricValue:
        return MetricValue(self.name, (), self.get())


class Gauge:
    """Arbitrarily changing gauge."""

    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self._value: float = 0.0
        self._lock = threading.Lock()

    def set(self, value: float) -> None:
        with self._lock:
            self._value = float(value)

    def inc(self, amount: float = 1.0) -> None:
        with self._lock:
            self._value += amount

    def dec(self, amount: float = 1.0) -> None:
        with self._lock:
            self._value -= amount

    def get(self) -> float:
        with self._lock:
            return self._value

    def snapshot(self) -> MetricValue:
        return MetricValue(self.name, (), self.get())


class Histogram:
    """Latency/value distribution with configurable buckets."""

    DEFAULT_BUCKETS = (
        0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0,
        2.5, 5.0, 10.0, 30.0, 60.0, 120.0, 300.0, 600.0, float("inf"),
    )

    def __init__(
        self,
        name: str,
        description: str = "",
        buckets: Optional[Tuple[float, ...]] = None,
    ):
        self.name = name
        self.description = description
        self._buckets = sorted(buckets or self.DEFAULT_BUCKETS)
        if self._buckets[-1] != float("inf"):
            self._buckets = self._buckets + (float("inf"),)
        self._counts: Dict[float, int] = {b: 0 for b in self._buckets}
        self._sum: float = 0.0
        self._total: int = 0
        self._lock = threading.Lock()

    def observe(self, value: float) -> None:
        with self._lock:
            self._total += 1
            self._sum += value
            for bucket in self._buckets:
                if value <= bucket:
                    self._counts[bucket] += 1

    def get(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "buckets": dict(self._counts),
                "sum": self._sum,
                "count": self._total,
            }

    def snapshot(self) -> List[MetricValue]:
        with self._lock:
            values = []
            for bucket, count in self._counts.items():
                label = MetricLabel("le", str(bucket))
                values.append(MetricValue(f"{self.name}_bucket", (label,), float(count)))
            values.append(MetricValue(f"{self.name}_sum", (), self._sum))
            values.append(MetricValue(f"{self.name}_count", (), float(self._total)))
            return values


class MetricsCollector:
    """Central registry for application metrics with Prometheus exposition."""

    def __init__(self, namespace: str = "jarvis") -> None:
        self._namespace = namespace
        self._counters: Dict[str, Counter] = {}
        self._gauges: Dict[str, Gauge] = {}
        self._histograms: Dict[str, Histogram] = {}
        self._lock = threading.RLock()
        self._producers: List[Callable[[], List[MetricValue]]] = []

    def counter(self, name: str, description: str = "") -> Counter:
        full_name = f"{self._namespace}_{name}"
        with self._lock:
            if full_name not in self._counters:
                self._counters[full_name] = Counter(full_name, description)
            return self._counters[full_name]

    def gauge(self, name: str, description: str = "") -> Gauge:
        full_name = f"{self._namespace}_{name}"
        with self._lock:
            if full_name not in self._gauges:
                self._gauges[full_name] = Gauge(full_name, description)
            return self._gauges[full_name]

    def histogram(self, name: str, description: str = "", buckets: Optional[Tuple[float, ...]] = None) -> Histogram:
        full_name = f"{self._namespace}_{name}"
        with self._lock:
            if full_name not in self._histograms:
                self._histograms[full_name] = Histogram(full_name, description, buckets)
            return self._histograms[full_name]

    def register_producer(self, producer: Callable[[], List[MetricValue]]) -> None:
        with self._lock:
            self._producers.append(producer)

    def prometheus_metrics(self) -> str:
        """Generate Prometheus text exposition."""
        lines: List[str] = []
        with self._lock:
            for name, counter in self._counters.items():
                lines.append(f"# HELP {name} {counter.description or name}")
                lines.append(f"# TYPE {name} counter")
                lines.append(f"{name} {counter.get()}")
            for name, gauge in self._gauges.items():
                lines.append(f"# HELP {name} {gauge.description or name}")
                lines.append(f"# TYPE {name} gauge")
                lines.append(f"{name} {gauge.get()}")
            for name, hist in self._histograms.items():
                lines.append(f"# HELP {name} {hist.description or name}")
                lines.append(f"# TYPE {name} histogram")
                for mv in hist.snapshot():
                    label_str = ""
                    if mv.labels:
                        parts = [f'{l.name}="{l.value}"' for l in mv.labels]
                        label_str = "{" + ",".join(parts) + "}"
                    lines.append(f"{mv.metric_name}{label_str} {mv.value}")
            for producer in self._producers:
                try:
                    for mv in producer():
                        label_str = ""
                        if mv.labels:
                            parts = [f'{l.name}="{l.value}"' for l in mv.labels]
                            label_str = "{" + ",".join(parts) + "}"
                        lines.append(f"{mv.metric_name}{label_str} {mv.value}")
                except Exception as exc:
                    logger.debug("metric_producer_failed", extra={"error": str(exc)})
        return "\n".join(lines) + "\n"

    def snapshot(self) -> Dict[str, Any]:
        """Return a JSON-serializable snapshot of all metrics."""
        with self._lock:
            return {
                "counters": {k: v.get() for k, v in self._counters.items()},
                "gauges": {k: v.get() for k, v in self._gauges.items()},
                "histograms": {k: v.get() for k, v in self._histograms.items()},
            }



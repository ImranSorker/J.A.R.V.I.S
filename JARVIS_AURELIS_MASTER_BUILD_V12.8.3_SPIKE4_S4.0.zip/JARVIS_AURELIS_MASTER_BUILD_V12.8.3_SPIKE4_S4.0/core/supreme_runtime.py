"""Integrated frontier runtime fabric for J.A.R.V.I.S. 12.8.0.

The fabric composes the existing security, mission, memory, device, model,
telemetry, evolution, knowledge, multimodal, computer-use, cluster and digital
-twin primitives behind explicit contracts. Target-specific acceleration,
filesystem mutation, network transport and privileged device I/O are injected;
this module never elevates an untrusted callback into a privileged authority.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import secrets
import sqlite3
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import serialization

from core.distributed_fabric import DistributedWorkerFabric
from core.frontier_batch import UAVMode, UAVSimulator
from core.memory_event_store import MemoryEventStore
from core.frontier_completion import ArtifactQuarantineManager
from core.system_digital_twin import SystemDigitalTwin
from core.agent_fabric import AgentFactory as LogicalAgentFactory, AgentGarage as LogicalAgentGarage, AgentHarness as LogicalAgentHarness, AgentStudio as LogicalAgentStudio, AgentWorkshop as LogicalAgentWorkshop, ToolFabric
from core.dsec_sandbox import DsecSandboxManager
from core.dsh_harness import DSHKernel, DSHSelfEvolution
from core.performance_fabric import ContextCache, ExecutionFastPath, PrecisionGovernor
from core.sensor_fusion import SensorFusionEngine
from core.world_state import WorldStateStore
from core.cognitive_assistant import CognitiveAssistant
from core.flight_safety import FlightConstraints, FlightSafetyPlanner
from core.swarm_coordinator import HumanCommandSwarmCoordinator
from core.cyber_defense import DefensiveSOC
from core.telemetry_fabric import TelemetryFabric
from core.hud_diagnostics import HUDDiagnostics
from core.lab_automation import LabAutomationEngine
from core.bounded_optimization import BoundedOptimizer
from core.agent_population import AgentPopulationController
from core.distributed_cognitive import DistributedCognitiveFabric
from core.root_authority import RootAuthority
from core.operational_modes import OperationalModeController
from core.frontier_evolution_2 import (
    SensorFabric2, WorldModel2, ContextCompiler, AdaptiveModelRouter2, PersonalLearningGate,
    AgentGenomeLab, SimulationUniverse, VerificationEngine, GpuIntelligenceFabric, RecoveryCoordinator,
)
from core.simulation_universe import SimulationEngine as SimulationUniverseEngine
from core.multi_agent_orchestration import MultiAgentOrchestration
from core.a2a_verification import A2AVerificationFabric, VerifiedMultiAgentOrchestration
from core.frontier_event_stream import FrontierEventStream
from core.flet_command_center import FletCommandCenter
from core.event_bus import EventBus
from core.event_fabric import EventFabric
from core.zero_trust import ZeroTrustAuthority
from core.tool_fabric.impl import ToolFabric as CanonicalToolFabric, ToolConfig as CanonicalToolConfig
from core.tool_composition import ToolCompositionEngine
from core.resource_guard import ResourceLedger
from core.world_model_3 import Provenance, WorldEntity3, WorldModel3


logger = logging.getLogger("jarvis.supreme_runtime")


class SupremeRuntimeError(RuntimeError):
    """Base error for integrated runtime violations."""


class AdmissionDenied(SupremeRuntimeError):
    """Raised when a capability or action is not admitted."""


@dataclass(frozen=True, slots=True)
class CapabilityManifest:
    """Immutable capability declaration for an agent or integration."""

    subject: str
    capabilities: tuple[str, ...]
    max_concurrency: int = 1
    max_runtime_seconds: float = 60.0
    max_output_bytes: int = 1_000_000

    def validate(self) -> None:
        subject = self.subject.strip()
        caps = tuple(sorted(set(item.strip() for item in self.capabilities if item.strip())))
        if not subject or not caps:
            raise ValueError("subject and capabilities are required")
        if not 1 <= int(self.max_concurrency) <= 64:
            raise ValueError("max_concurrency outside policy")
        if not 0.1 <= float(self.max_runtime_seconds) <= 86_400:
            raise ValueError("max_runtime_seconds outside policy")
        if not 1_024 <= int(self.max_output_bytes) <= 100_000_000:
            raise ValueError("max_output_bytes outside policy")


@dataclass(frozen=True, slots=True)
class AgentExecutionReceipt:
    """Auditable result of a supervised agent operation."""

    request_id: str
    subject: str
    capability: str
    ok: bool
    output_sha256: str
    output_bytes: int
    latency_ms: float
    error: str | None
    signature: str


class AgentExecutor(Protocol):
    """Injected bounded agent implementation."""

    def __call__(self, request: str, context: Mapping[str, Any]) -> Any:
        ...


class AgentSupervisor:
    """Capability-scoped agent admission with concurrency and time budgets."""

    def __init__(self, secret: bytes, *, max_workers: int = 16, observation_sink: Callable[["AgentExecutionReceipt", Mapping[str, Any]], None] | None = None) -> None:
        if len(secret) < 32:
            raise ValueError("agent supervisor secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self._manifests: dict[str, CapabilityManifest] = {}
        self._semaphores: dict[str, threading.BoundedSemaphore] = {}
        self._executor = ThreadPoolExecutor(max_workers=max(1, min(int(max_workers), 64)), thread_name_prefix="jarvis-supervised-agent")
        self._lock = threading.RLock()
        self._closed = False
        self._quarantined: set[str] = set()
        self._running: dict[str, int] = {}
        self._observation_sink = observation_sink

    def set_observation_sink(self, sink: Callable[["AgentExecutionReceipt", Mapping[str, Any]], None] | None) -> None:
        """Install a non-blocking observation sink for completed receipts."""
        with self._lock:
            self._observation_sink = sink

    def register(self, manifest: CapabilityManifest) -> None:
        """Register one immutable capability manifest."""
        manifest.validate()
        normalized = CapabilityManifest(
            manifest.subject.strip(),
            tuple(sorted(set(item.strip() for item in manifest.capabilities if item.strip()))),
            int(manifest.max_concurrency),
            float(manifest.max_runtime_seconds),
            int(manifest.max_output_bytes),
        )
        with self._lock:
            self._manifests[normalized.subject] = normalized
            self._semaphores[normalized.subject] = threading.BoundedSemaphore(normalized.max_concurrency)

    def execute(
        self,
        subject: str,
        capability: str,
        request: str,
        executor: AgentExecutor,
        *,
        metadata: Mapping[str, Any] | None = None,
    ) -> AgentExecutionReceipt:
        """Execute an admitted operation with bounded wall time and output."""
        with self._lock:
            if self._closed:
                raise RuntimeError("agent supervisor is closed")
            manifest = self._manifests.get(str(subject))
            semaphore = self._semaphores.get(str(subject))
        if manifest is None or semaphore is None:
            raise AdmissionDenied(f"agent subject is not registered: {subject}")
        with self._lock:
            if str(subject) in self._quarantined:
                raise AdmissionDenied(f"agent subject is quarantined after a timed-out execution: {subject}")
        if capability not in manifest.capabilities and "*" not in manifest.capabilities:
            raise AdmissionDenied(f"capability denied: {capability}")
        text = str(request).strip()
        if not text or len(text.encode("utf-8")) > 1_000_000:
            raise ValueError("agent request is empty or oversized")
        acquired = semaphore.acquire(timeout=min(manifest.max_runtime_seconds, 60.0))
        if not acquired:
            raise TimeoutError("agent concurrency budget exhausted")
        with self._lock:
            self._running[str(subject)] = self._running.get(str(subject),0) + 1
        request_id = uuid.uuid4().hex
        started = time.perf_counter()
        output = ""
        error: str | None = None
        ok = False
        cancel_event = threading.Event()
        future: Future[Any] | None = None
        try:
            future = self._executor.submit(
                executor,
                text,
                {"request_id": request_id, "subject": manifest.subject, "capability": capability, "metadata": dict(metadata or {}), "cancel_event": cancel_event, "deadline_monotonic": time.monotonic() + manifest.max_runtime_seconds},
            )
            raw = future.result(timeout=manifest.max_runtime_seconds)
            output = str(raw)
            if len(output.encode("utf-8")) > manifest.max_output_bytes:
                raise ValueError("agent output exceeds declared budget")
            supplied = raw if isinstance(raw, Mapping) else {}
            supplied_meta = dict(metadata or {})
            verified = bool(supplied_meta.get("verified", False)) or bool(supplied.get("verified", False))
            evidence = supplied_meta.get("evidence") or (supplied.get("evidence") if isinstance(supplied, Mapping) else None)
            if not verified or not evidence:
                raise ValueError("agent execution requires verified outcome evidence")
            ok = True
        except TimeoutError as exc:
            cancel_event.set()
            error = f"TimeoutError: agent execution exceeded {manifest.max_runtime_seconds:.3f}s"
        except Exception as exc:
            cancel_event.set()
            error = f"{type(exc).__name__}: {exc}"
        finally:
            if future is None:
                semaphore.release()
                with self._lock:
                    self._running[str(subject)] = max(0,self._running.get(str(subject),1)-1)
            elif future.done():
                semaphore.release()
                with self._lock:
                    self._running[str(subject)] = max(0,self._running.get(str(subject),1)-1)
            else:
                with self._lock: self._quarantined.add(str(subject))
                def _release_late(_future: Future[Any]) -> None:
                    semaphore.release()
                    with self._lock:
                        self._running[str(subject)] = max(0,self._running.get(str(subject),1)-1)
                        self._quarantined.discard(str(subject))
                future.add_done_callback(_release_late)
        output_bytes = len(output.encode("utf-8"))
        digest = hashlib.sha256(output.encode("utf-8")).hexdigest()
        latency_ms = (time.perf_counter() - started) * 1000.0
        canonical = json.dumps({"request_id": request_id, "subject": manifest.subject, "capability": capability, "ok": ok, "output_sha256": digest, "output_bytes": output_bytes, "error": error}, sort_keys=True, separators=(",", ":")).encode()
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        receipt = AgentExecutionReceipt(request_id, manifest.subject, capability, ok, digest, output_bytes, latency_ms, error, signature)
        with self._lock:
            sink = self._observation_sink
        if sink is not None:
            try:
                sink(receipt, dict(metadata or {}))
            except Exception:
                # Observability must never convert a completed agent operation into a false failure.
                logger.exception("agent_observation_sink_failed", extra={"request_id": request_id, "subject": manifest.subject})
        return receipt

    def verify(self, receipt: AgentExecutionReceipt) -> bool:
        """Verify the integrity of a supervised receipt."""
        canonical = json.dumps({"request_id": receipt.request_id, "subject": receipt.subject, "capability": receipt.capability, "ok": receipt.ok, "output_sha256": receipt.output_sha256, "output_bytes": receipt.output_bytes, "error": receipt.error}, sort_keys=True, separators=(",", ":")).encode()
        return hmac.compare_digest(receipt.signature, hmac.new(self._secret, canonical, hashlib.sha256).hexdigest())

    def snapshot(self) -> dict[str, Any]:
        """Return capability metadata without secrets."""
        with self._lock:
            return {"subjects": sorted(self._manifests), "capabilities": {name: list(item.capabilities) for name, item in self._manifests.items()}, "quarantined": sorted(self._quarantined), "running": dict(self._running)}

    def close(self) -> None:
        """Stop supervised workers."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
        self._executor.shutdown(wait=True, cancel_futures=True)


@dataclass(frozen=True, slots=True)
class ModelSpec:
    """Resource-bounded local model declaration."""

    model_id: str
    backend: str
    memory_mb: int
    context_length: int
    capabilities: tuple[str, ...] = ()
    quantization: str = "none"

    def validate(self) -> None:
        if not self.model_id.strip() or not self.backend.strip():
            raise ValueError("model_id and backend are required")
        if not 1 <= int(self.memory_mb) <= 1_000_000:
            raise ValueError("model memory outside policy")
        if not 128 <= int(self.context_length) <= 2_000_000:
            raise ValueError("model context outside policy")


@dataclass(frozen=True, slots=True)
class ModelSelection:
    """Explainable model selection result."""

    model_id: str
    reason: str
    estimated_memory_mb: int


class LocalModelRuntime:
    """Capability-aware model scheduler with an injected inference backend."""

    def __init__(self, *, memory_available_mb: Callable[[], int], backend: Callable[[ModelSpec, str], str] | None = None) -> None:
        self._memory_available_mb = memory_available_mb
        self._backend = backend
        self._models: dict[str, ModelSpec] = {}
        self._lock = threading.RLock()
        self._active: dict[str, int] = {}

    def register(self, model: ModelSpec) -> None:
        """Register a validated model specification."""
        model.validate()
        with self._lock:
            self._models[model.model_id] = model
            self._active.setdefault(model.model_id, 0)

    def select(self, required_capabilities: Iterable[str], *, max_memory_mb: int | None = None) -> ModelSelection:
        """Select the smallest model satisfying capabilities and memory."""
        required = set(str(item).strip() for item in required_capabilities if str(item).strip())
        available = max(0, int(self._memory_available_mb()))
        candidates = []
        with self._lock:
            for model in self._models.values():
                caps = set(model.capabilities)
                if not required.issubset(caps) and "*" not in caps:
                    continue
                if model.memory_mb > available:
                    continue
                if max_memory_mb is not None and model.memory_mb > int(max_memory_mb):
                    continue
                candidates.append(model)
        if not candidates:
            raise AdmissionDenied("no registered model satisfies capability and memory constraints")
        selected = min(candidates, key=lambda item: (item.memory_mb, item.model_id))
        return ModelSelection(selected.model_id, "minimum admitted memory footprint for requested capabilities", selected.memory_mb)

    def infer(self, model_id: str, prompt: str) -> str:
        """Run through the injected backend; fail closed when unavailable."""
        with self._lock:
            model = self._models.get(str(model_id))
        if model is None:
            raise KeyError(model_id)
        if not str(prompt).strip():
            raise ValueError("prompt is required")
        if self._backend is None:
            raise RuntimeError("native inference backend is not provisioned")
        if int(self._memory_available_mb()) < model.memory_mb:
            raise AdmissionDenied("insufficient available model memory")
        with self._lock:
            self._active[model.model_id] += 1
        try:
            return str(self._backend(model, prompt))
        finally:
            with self._lock:
                self._active[model.model_id] = max(0, self._active[model.model_id] - 1)

    def configure_backend(self, *, memory_available_mb: Callable[[], int], backend: Callable[[ModelSpec, str], str]) -> None:
        """Inject a verified local inference backend and resource provider."""
        if not callable(memory_available_mb) or not callable(backend):
            raise ValueError("model backend and memory provider must be callable")
        with self._lock:
            self._memory_available_mb = memory_available_mb
            self._backend = backend

    def snapshot(self) -> dict[str, Any]:
        """Return scheduler state without model content."""
        with self._lock:
            return {"models": [asdict(item) for item in self._models.values()], "active": dict(self._active), "memory_available_mb": max(0, int(self._memory_available_mb())), "backend_provisioned": self._backend is not None}


@dataclass(frozen=True, slots=True)
class MissionStep:
    """One parallelizable mission step."""

    step_id: str
    capability: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    depends_on: tuple[str, ...] = ()
    max_attempts: int = 2
    idempotency_key: str | None = None


@dataclass(frozen=True, slots=True)
class MissionRun:
    """Immutable mission result."""

    mission_id: str
    status: str
    outputs: Mapping[str, Any]
    failures: Mapping[str, str]
    attempts: Mapping[str, int]
    checkpoint_digest: str


class MissionEngine3:
    """Durable parallel DAG executor with checkpoints and compensation hooks."""

    def __init__(self, db_path: str | Path, secret: bytes, *, max_parallel: int = 8) -> None:
        if len(secret) < 32:
            raise ValueError("mission secret must contain at least 32 bytes")
        self.path = Path(db_path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self._max_parallel = max(1, min(int(max_parallel), 64))
        self._db = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None, timeout=30.0)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("PRAGMA busy_timeout=30000")
        self._db.executescript("""
            CREATE TABLE IF NOT EXISTS supreme_missions(id TEXT PRIMARY KEY, objective TEXT NOT NULL, state TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL, checkpoint TEXT NOT NULL, error TEXT);
            CREATE TABLE IF NOT EXISTS supreme_steps(mission_id TEXT NOT NULL, step_id TEXT NOT NULL, capability TEXT NOT NULL, payload TEXT NOT NULL, deps TEXT NOT NULL, idem TEXT, max_attempts INTEGER NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, output TEXT, error TEXT, PRIMARY KEY(mission_id, step_id), UNIQUE(mission_id, idem), FOREIGN KEY(mission_id) REFERENCES supreme_missions(id) ON DELETE CASCADE);
            CREATE TABLE IF NOT EXISTS supreme_idempotency(key TEXT PRIMARY KEY, payload_digest TEXT NOT NULL, output_json TEXT NOT NULL, mission_id TEXT NOT NULL, step_id TEXT NOT NULL, created REAL NOT NULL);
        """)
        self._lock = threading.RLock()
        self._cancel: set[str] = set()
        self._workers = ThreadPoolExecutor(max_workers=self._max_parallel, thread_name_prefix="jarvis-mission")
        self._closed = False

    @staticmethod
    def validate(steps: Sequence[MissionStep]) -> None:
        """Validate bounded unique DAG steps."""
        if not steps or len(steps) > 10_000:
            raise ValueError("mission must contain 1..10000 steps")
        ids = {step.step_id for step in steps}
        if len(ids) != len(steps) or any(not step.step_id.strip() for step in steps):
            raise ValueError("step IDs must be unique and non-empty")
        for step in steps:
            if not step.capability.strip() or not 1 <= int(step.max_attempts) <= 10:
                raise ValueError(f"invalid policy for step {step.step_id}")
            if any(dep not in ids or dep == step.step_id for dep in step.depends_on):
                raise ValueError(f"invalid dependency for step {step.step_id}")
        visiting: set[str] = set()
        visited: set[str] = set()
        by_id = {step.step_id: step for step in steps}

        def walk(step_id: str) -> None:
            if step_id in visiting:
                raise ValueError("mission graph contains a cycle")
            if step_id in visited:
                return
            visiting.add(step_id)
            for dep in by_id[step_id].depends_on:
                walk(dep)
            visiting.remove(step_id)
            visited.add(step_id)

        for step_id in by_id:
            walk(step_id)

    def create(self, mission_id: str, objective: str, steps: Sequence[MissionStep]) -> None:
        """Persist a mission and its validated DAG."""
        mid, text = str(mission_id).strip(), str(objective).strip()
        self.validate(steps)
        if not mid or not text:
            raise ValueError("mission_id and objective are required")
        now = time.time()
        with self._lock, self._db:
            self._db.execute("INSERT INTO supreme_missions(id,objective,state,created,updated,checkpoint) VALUES(?,?,?,?,?,?)", (mid, text[:20_000], "pending", now, now, "GENESIS"))
            for step in steps:
                self._db.execute("INSERT INTO supreme_steps(mission_id,step_id,capability,payload,deps,idem,max_attempts,state) VALUES(?,?,?,?,?,?,?,?)", (mid, step.step_id, step.capability, json.dumps(dict(step.payload), sort_keys=True, separators=(",", ":")), json.dumps(list(step.depends_on)), step.idempotency_key, int(step.max_attempts), "pending"))

    def cancel(self, mission_id: str) -> bool:
        """Request mission cancellation."""
        mid = str(mission_id)
        with self._lock, self._db:
            row = self._db.execute("SELECT state FROM supreme_missions WHERE id=?", (mid,)).fetchone()
            if row is None or row[0] in {"succeeded", "failed", "cancelled"}:
                return False
            self._cancel.add(mid)
            self._db.execute("UPDATE supreme_missions SET state='cancelled',updated=? WHERE id=?", (time.time(), mid))
            self._db.execute("UPDATE supreme_steps SET state='cancelled' WHERE mission_id=? AND state='pending'", (mid,))
            return True

    def _checkpoint_digest(self, mission_id: str) -> str:
        rows = self._db.execute("SELECT step_id,state,attempts,output,error FROM supreme_steps WHERE mission_id=? ORDER BY step_id", (mission_id,)).fetchall()
        body = [dict(row) for row in rows]
        return hmac.new(self._secret, json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode(), hashlib.sha256).hexdigest()

    def _checkpoint(self, mission_id: str) -> str:
        digest = self._checkpoint_digest(mission_id)
        self._db.execute("UPDATE supreme_missions SET checkpoint=?,updated=? WHERE id=?", (digest, time.time(), mission_id))
        return digest

    def execute(
        self,
        mission_id: str,
        *,
        authorize: Callable[[MissionStep], bool],
        runner: Callable[[MissionStep], Any],
        compensate: Callable[[MissionStep, Any], None] | None = None,
    ) -> MissionRun:
        """Run ready DAG nodes in parallel while persisting every transition."""
        mid = str(mission_id)
        with self._lock:
            row = self._db.execute("SELECT state FROM supreme_missions WHERE id=?", (mid,)).fetchone()
        if row is None:
            raise KeyError(mid)
        outputs: dict[str, Any] = {}
        failures: dict[str, str] = {}
        attempts: dict[str, int] = {}
        succeeded_steps: list[MissionStep] = []
        active: dict[str, Future[Any]] = {}
        step_by_id = {str(row["step_id"]): MissionStep(str(row["step_id"]), str(row["capability"]), json.loads(str(row["payload"])), tuple(json.loads(str(row["deps"]))), int(row["max_attempts"]), row["idem"]) for row in self._db.execute("SELECT * FROM supreme_steps WHERE mission_id=?", (mid,)).fetchall()}
        with self._lock, self._db:
            self._db.execute("UPDATE supreme_missions SET state='running',updated=? WHERE id=?", (time.time(), mid))
        while True:
            if mid in self._cancel:
                break
            with self._lock, self._db:
                rows = self._db.execute("SELECT step_id,state,attempts,output,error FROM supreme_steps WHERE mission_id=?", (mid,)).fetchall()
            state_map = {str(row["step_id"]): str(row["state"]) for row in rows}
            if all(state in {"succeeded", "cancelled"} for state in state_map.values()):
                break
            ready = [step_by_id[sid] for sid, state in state_map.items() if state == "pending" and all(state_map.get(dep) == "succeeded" for dep in step_by_id[sid].depends_on) and sid not in active]
            for step in ready[: max(0, self._max_parallel - len(active))]:
                if not authorize(step):
                    failures[step.step_id] = "authorization denied"
                    with self._lock, self._db:
                        self._db.execute("UPDATE supreme_steps SET state='failed',error=?,attempts=attempts+1 WHERE mission_id=? AND step_id=?", (failures[step.step_id], mid, step.step_id))
                    continue
                if step.idempotency_key:
                    payload_digest = hashlib.sha256(json.dumps(dict(step.payload), sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
                    with self._lock:
                        existing = self._db.execute("SELECT payload_digest,output_json FROM supreme_idempotency WHERE key=?", (step.idempotency_key,)).fetchone()
                    if existing is not None:
                        if not hmac.compare_digest(str(existing[0]), payload_digest):
                            failures[step.step_id] = "idempotency key payload mismatch"
                            with self._lock, self._db:
                                self._db.execute("UPDATE supreme_steps SET state='failed',error=?,attempts=attempts+1 WHERE mission_id=? AND step_id=?", (failures[step.step_id], mid, step.step_id))
                            continue
                        value = json.loads(str(existing[1]))
                        outputs[step.step_id] = value
                        attempts[step.step_id] = 0
                        with self._lock, self._db:
                            self._db.execute("UPDATE supreme_steps SET state='succeeded',output=?,error=NULL WHERE mission_id=? AND step_id=?", (str(existing[1]), mid, step.step_id))
                        continue
                with self._lock, self._db:
                    self._db.execute("UPDATE supreme_steps SET state='running' WHERE mission_id=? AND step_id=?", (mid, step.step_id))
                active[step.step_id] = self._workers.submit(runner, step)
            if not active and not ready:
                break
            done = [sid for sid, future in active.items() if future.done()]
            if not done:
                time.sleep(0.005)
                continue
            for sid in done:
                future = active.pop(sid)
                step = step_by_id[sid]
                attempts[sid] = int(self._db.execute("SELECT attempts FROM supreme_steps WHERE mission_id=? AND step_id=?", (mid, sid)).fetchone()[0]) + 1
                try:
                    value = future.result()
                    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)
                    if step.idempotency_key:
                        payload_digest = hashlib.sha256(json.dumps(dict(step.payload), sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
                        with self._lock, self._db:
                            self._db.execute("INSERT OR IGNORE INTO supreme_idempotency(key,payload_digest,output_json,mission_id,step_id,created) VALUES(?,?,?,?,?,?)", (step.idempotency_key, payload_digest, encoded, mid, sid, time.time()))
                            stored = self._db.execute("SELECT payload_digest,output_json FROM supreme_idempotency WHERE key=?", (step.idempotency_key,)).fetchone()
                        if stored is None or not hmac.compare_digest(str(stored[0]), payload_digest):
                            failures[sid] = "idempotency ledger conflict"
                            with self._lock, self._db:
                                self._db.execute("UPDATE supreme_steps SET state='failed',attempts=?,error=? WHERE mission_id=? AND step_id=?", (attempts[sid], failures[sid], mid, sid))
                            continue
                        value = json.loads(str(stored[1]))
                        encoded = str(stored[1])
                    outputs[sid] = value
                    succeeded_steps.append(step)
                    with self._lock, self._db:
                        self._db.execute("UPDATE supreme_steps SET state='succeeded',attempts=?,output=?,error=NULL WHERE mission_id=? AND step_id=?", (attempts[sid], encoded, mid, sid))
                except Exception as exc:
                    error = f"{type(exc).__name__}: {exc}"
                    if attempts[sid] < step.max_attempts and mid not in self._cancel:
                        with self._lock, self._db:
                            self._db.execute("UPDATE supreme_steps SET state='pending',attempts=?,error=? WHERE mission_id=? AND step_id=?", (attempts[sid], error, mid, sid))
                    else:
                        failures[sid] = error
                        with self._lock, self._db:
                            self._db.execute("UPDATE supreme_steps SET state='failed',attempts=?,error=? WHERE mission_id=? AND step_id=?", (attempts[sid], error, mid, sid))
            self._checkpoint(mid)
        if mid in self._cancel:
            status = "cancelled"
        elif failures:
            status = "failed"
            if compensate is not None:
                for step in reversed(succeeded_steps):
                    try:
                        compensate(step, outputs.get(step.step_id))
                    except Exception as exc:
                        failures[f"compensation:{step.step_id}"] = f"{type(exc).__name__}: {exc}"
        else:
            status = "succeeded"
        with self._lock, self._db:
            self._db.execute("UPDATE supreme_missions SET state=?,updated=? WHERE id=?", (status, time.time(), mid))
            digest = self._checkpoint(mid)
        return MissionRun(mid, status, dict(outputs), dict(failures), dict(attempts), digest)

    def status(self, mission_id: str) -> dict[str, Any]:
        """Return durable mission state and checkpoint."""
        with self._lock:
            mission = self._db.execute("SELECT * FROM supreme_missions WHERE id=?", (str(mission_id),)).fetchone()
            steps = self._db.execute("SELECT step_id,state,attempts,error FROM supreme_steps WHERE mission_id=? ORDER BY step_id", (str(mission_id),)).fetchall()
        if mission is None:
            raise KeyError(mission_id)
        return {"mission_id": mission["id"], "state": mission["state"], "checkpoint": mission["checkpoint"], "steps": [dict(row) for row in steps]}

    def verify_checkpoint(self, mission_id: str) -> bool:
        """Verify the stored checkpoint against current step state."""
        with self._lock:
            row = self._db.execute("SELECT checkpoint FROM supreme_missions WHERE id=?", (str(mission_id),)).fetchone()
            if row is None:
                return False
            expected = self._checkpoint_digest(str(mission_id))
            return hmac.compare_digest(str(row[0]), expected)

    def close(self) -> None:
        """Close workers and persistent state."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
        self._workers.shutdown(wait=True, cancel_futures=True)
        with self._lock:
            self._db.commit()
            self._db.close()


@dataclass(frozen=True, slots=True)
class MemoryRecord4:
    """Namespace-segregated memory record with provenance."""

    event_id: int
    namespace: str
    event_type: str
    source: str
    provenance: Mapping[str, Any]
    payload: Mapping[str, Any]


class MemoryFabric4:
    """Provenance-rich encrypted memory facade with namespace key shredding."""

    def __init__(self, path: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("memory secret must contain at least 32 bytes")
        self.path = Path(path).resolve()
        self._master_key = hashlib.sha256(bytes(secret) + b"\0memory-fabric-v4").digest()
        self._store = MemoryEventStore(self.path, secret)
        self._keys = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None, timeout=30.0)
        self._keys.execute("PRAGMA journal_mode=WAL")
        self._keys.execute("PRAGMA synchronous=FULL")
        self._keys.execute("CREATE TABLE IF NOT EXISTS memory_namespace_keys(namespace TEXT PRIMARY KEY, wrapped BLOB NOT NULL, created REAL NOT NULL, purged INTEGER NOT NULL DEFAULT 0)")
        self._lock = threading.RLock()

    @staticmethod
    def namespace(owner_id: str, workspace_id: str, kind: str) -> str:
        """Construct an explicit non-empty memory namespace."""
        owner = str(owner_id).strip()
        workspace = str(workspace_id).strip()
        category = str(kind).strip()
        if not owner or not workspace or not category or any(".." in item or "/" in item or "\\" in item for item in (owner, workspace, category)):
            raise ValueError("invalid memory namespace")
        return f"{owner}:{workspace}:{category}"

    def _wrap_key(self, namespace: str, dek: bytes) -> bytes:
        nonce = secrets.token_bytes(12)
        ciphertext = AESGCM(self._master_key).encrypt(nonce, dek, namespace.encode("utf-8"))
        return nonce + ciphertext

    def _unwrap_key(self, namespace: str, wrapped: bytes) -> bytes:
        if len(wrapped) < 28:
            raise SupremeRuntimeError("invalid wrapped namespace key")
        return AESGCM(self._master_key).decrypt(wrapped[:12], wrapped[12:], namespace.encode("utf-8"))

    def _key_for(self, namespace: str, *, create: bool, allow_purged: bool = False) -> bytes | None:
        row = self._keys.execute("SELECT wrapped,purged FROM memory_namespace_keys WHERE namespace=?", (namespace,)).fetchone()
        if row is not None:
            if int(row[1]):
                if allow_purged:
                    return None
                raise AdmissionDenied("memory namespace has been cryptographically deleted")
            return self._unwrap_key(namespace, bytes(row[0]))
        if not create:
            return None
        dek = secrets.token_bytes(32)
        self._keys.execute("INSERT INTO memory_namespace_keys(namespace,wrapped,created,purged) VALUES(?,?,?,0)", (namespace, self._wrap_key(namespace, dek), time.time()))
        return dek

    @staticmethod
    def _encrypt_payload(namespace: str, key: bytes, body: Mapping[str, Any]) -> Mapping[str, Any]:
        plaintext = json.dumps(dict(body), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        nonce = secrets.token_bytes(12)
        ciphertext = AESGCM(key).encrypt(nonce, plaintext, namespace.encode("utf-8"))
        return {"version": 1, "nonce": base64.b64encode(nonce).decode("ascii"), "ciphertext": base64.b64encode(ciphertext).decode("ascii")}

    @staticmethod
    def _decrypt_payload(namespace: str, key: bytes, wrapper: Mapping[str, Any]) -> Mapping[str, Any]:
        if int(wrapper.get("version", 0)) != 1:
            raise SupremeRuntimeError("unsupported memory ciphertext version")
        nonce = base64.b64decode(str(wrapper["nonce"]), validate=True)
        ciphertext = base64.b64decode(str(wrapper["ciphertext"]), validate=True)
        plaintext = AESGCM(key).decrypt(nonce, ciphertext, namespace.encode("utf-8"))
        decoded = json.loads(plaintext.decode("utf-8"))
        if not isinstance(decoded, dict):
            raise SupremeRuntimeError("memory payload must be a JSON object")
        return decoded

    def append(self, owner_id: str, workspace_id: str, kind: str, event_type: str, payload: Mapping[str, Any], *, source: str, provenance: Mapping[str, Any] | None = None) -> MemoryRecord4:
        """Append one encrypted provenance-bound record to an isolated namespace."""
        ns = self.namespace(owner_id, workspace_id, kind)
        src = str(source).strip()
        if not src or len(src) > 256:
            raise ValueError("memory source is required and bounded")
        body = {"source": src, "provenance": dict(provenance or {}), "payload": dict(payload)}
        with self._lock:
            key = self._key_for(ns, create=True)
            assert key is not None
            wrapper = self._encrypt_payload(ns, key, body)
            seq = self._store.append(ns, str(event_type), wrapper)
        return MemoryRecord4(seq, ns, str(event_type), src, dict(provenance or {}), dict(payload))

    def verify(self, owner_id: str, workspace_id: str, kind: str) -> bool:
        """Verify a selected namespace hash chain without requiring decryption."""
        return self._store.verify(self.namespace(owner_id, workspace_id, kind))

    def recent(self, owner_id: str, workspace_id: str, kind: str, *, limit: int = 100) -> list[dict[str, Any]]:
        """Read decrypted records only inside one non-deleted namespace."""
        ns = self.namespace(owner_id, workspace_id, kind)
        with self._lock:
            key = self._key_for(ns, create=False, allow_purged=True)
            if key is None:
                return []
            rows = self._store.snapshot(ns, limit=limit)
        result: list[dict[str, Any]] = []
        for row in rows:
            body = self._decrypt_payload(ns, key, row["payload"])
            result.append({**row, "payload": body.get("payload", {}), "source": body.get("source", ""), "provenance": body.get("provenance", {})})
        return result

    def tombstone(self, owner_id: str, workspace_id: str, kind: str, target_seq: int, *, reason: str) -> MemoryRecord4:
        """Record cryptographic deletion intent without rewriting historical events."""
        return self.append(owner_id, workspace_id, kind, "tombstone", {"target_seq": int(target_seq), "reason": str(reason)[:1024]}, source="memory-governance", provenance={"operation": "cryptographic-tombstone"})

    def purge_namespace(self, owner_id: str, workspace_id: str, kind: str, *, reason: str) -> bool:
        """Cryptographically shred one namespace key and make the namespace immutable."""
        ns = self.namespace(owner_id, workspace_id, kind)
        with self._lock, self._keys:
            row = self._keys.execute("SELECT purged FROM memory_namespace_keys WHERE namespace=?", (ns,)).fetchone()
            if row is None or int(row[0]):
                return False
        self.tombstone(owner_id, workspace_id, kind, target_seq=-1, reason=reason)
        with self._lock, self._keys:
            self._keys.execute("UPDATE memory_namespace_keys SET wrapped=?,purged=1 WHERE namespace=?", (secrets.token_bytes(48), ns))
        return True

    def namespace_status(self, owner_id: str, workspace_id: str, kind: str) -> dict[str, Any]:
        """Return whether namespace key material is active or shredded."""
        ns = self.namespace(owner_id, workspace_id, kind)
        with self._lock:
            row = self._keys.execute("SELECT purged,created FROM memory_namespace_keys WHERE namespace=?", (ns,)).fetchone()
        return {"namespace": ns, "exists": row is not None, "purged": bool(row and row[0]), "created_at": float(row[1]) if row else None}

    def close(self) -> None:
        """Close persistent memory and key state."""
        with self._lock:
            self._keys.commit()
            self._keys.close()
            self._store.close()


@dataclass(frozen=True, slots=True)
class DeviceDescriptor:
    """Authenticated device identity and capabilities."""

    device_id: str
    device_type: str
    capabilities: tuple[str, ...]
    protocol: str
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class DeviceGrant:
    """Attenuated, short-lived device capability grant."""

    grant_id: str
    device_id: str
    capabilities: tuple[str, ...]
    issued_at: float
    expires_at: float
    signature: str


class DeviceFabric3:
    """Capability-negotiated device registry with HMAC-backed grants."""

    def __init__(self, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("device secret must contain at least 32 bytes")
        self._secret = bytes(secret)
        self._devices: dict[str, DeviceDescriptor] = {}
        self._telemetry: dict[str, Mapping[str, Any]] = {}
        self._lock = threading.RLock()

    def register(self, descriptor: DeviceDescriptor) -> None:
        """Register or replace one authenticated device descriptor."""
        did = descriptor.device_id.strip()
        caps = tuple(sorted(set(item.strip() for item in descriptor.capabilities if item.strip())))
        if not did or not descriptor.device_type.strip() or not caps or not descriptor.protocol.strip():
            raise ValueError("device identity, protocol and capabilities are required")
        with self._lock:
            self._devices[did] = DeviceDescriptor(did, descriptor.device_type.strip(), caps, descriptor.protocol.strip(), dict(descriptor.metadata))

    def issue_grant(self, device_id: str, requested: Iterable[str], *, ttl_seconds: float = 300.0) -> DeviceGrant:
        """Issue the intersection of requested capabilities and device capabilities."""
        ttl = max(1.0, min(float(ttl_seconds), 3600.0))
        with self._lock:
            descriptor = self._devices.get(str(device_id))
        if descriptor is None:
            raise KeyError(device_id)
        capabilities = tuple(sorted(set(requested).intersection(descriptor.capabilities)))
        if not capabilities:
            raise AdmissionDenied("requested device capabilities are not registered")
        now = time.time()
        grant_id = uuid.uuid4().hex
        canonical = f"{grant_id}|{descriptor.device_id}|{','.join(capabilities)}|{now:.6f}|{now + ttl:.6f}".encode()
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        return DeviceGrant(grant_id, descriptor.device_id, capabilities, now, now + ttl, signature)

    def verify_grant(self, grant: DeviceGrant, *, capability: str) -> bool:
        """Verify grant authenticity, freshness and requested capability."""
        if grant.expires_at <= time.time() or capability not in grant.capabilities:
            return False
        with self._lock:
            descriptor = self._devices.get(grant.device_id)
        if descriptor is None or not set(grant.capabilities).issubset(descriptor.capabilities):
            return False
        canonical = f"{grant.grant_id}|{grant.device_id}|{','.join(grant.capabilities)}|{grant.issued_at:.6f}|{grant.expires_at:.6f}".encode()
        return hmac.compare_digest(grant.signature, hmac.new(self._secret, canonical, hashlib.sha256).hexdigest())

    def record_telemetry(self, device_id: str, payload: Mapping[str, Any]) -> None:
        """Store bounded telemetry for a registered device."""
        with self._lock:
            if device_id not in self._devices:
                raise KeyError(device_id)
            encoded = json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), default=str)
            if len(encoded.encode()) > 256_000:
                raise ValueError("device telemetry exceeds size ceiling")
            self._telemetry[device_id] = dict(payload)

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret device fabric state."""
        with self._lock:
            return {"devices": [{"device_id": d.device_id, "device_type": d.device_type, "capabilities": list(d.capabilities), "protocol": d.protocol} for d in self._devices.values()], "telemetry_devices": sorted(self._telemetry)}


@dataclass(frozen=True, slots=True)
class Span:
    """Completed observability span."""

    trace_id: str
    span_id: str
    name: str
    started_at: float
    finished_at: float
    status: str
    attributes: Mapping[str, Any]


class ObservabilityFabric3:
    """Bounded structured traces, counters and JSONL audit persistence."""

    def __init__(self, path: str | Path, *, max_spans: int = 50_000) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._max_spans = max(100, min(int(max_spans), 1_000_000))
        self._spans: list[Span] = []
        self._counters: dict[str, int] = {}
        self._lock = threading.RLock()

    def start(self, name: str, *, trace_id: str | None = None, attributes: Mapping[str, Any] | None = None) -> tuple[str, str, float, dict[str, Any]]:
        """Start an in-memory span context."""
        return str(trace_id or uuid.uuid4().hex), uuid.uuid4().hex, time.time(), dict(attributes or {})

    def finish(self, trace_id: str, span_id: str, name: str, started: float, *, status: str, attributes: Mapping[str, Any] | None = None) -> Span:
        """Finish and durably append a span record."""
        span = Span(str(trace_id), str(span_id), str(name), float(started), time.time(), str(status), dict(attributes or {}))
        line = json.dumps(asdict(span), sort_keys=True, separators=(",", ":"), default=str)
        if len(line.encode()) > 256_000:
            raise ValueError("span exceeds size ceiling")
        with self._lock:
            self._spans.append(span)
            if len(self._spans) > self._max_spans:
                del self._spans[: len(self._spans) - self._max_spans]
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        return span

    def increment(self, name: str, value: int = 1) -> None:
        """Increment a bounded named counter."""
        metric = str(name).strip()
        if not metric:
            raise ValueError("counter name is required")
        with self._lock:
            self._counters[metric] = self._counters.get(metric, 0) + int(value)

    def snapshot(self) -> dict[str, Any]:
        """Return current metrics and latest traces."""
        with self._lock:
            return {"counters": dict(self._counters), "span_count": len(self._spans), "recent_spans": [asdict(span) for span in self._spans[-20:]]}


@dataclass(frozen=True, slots=True)
class EvolutionCandidate:
    """Candidate artifact descriptor for controlled self-evolution."""

    candidate_id: str
    source_dir: str
    revision: str


@dataclass(frozen=True, slots=True)
class EvolutionResult:
    """Deterministic self-evolution gate outcome."""

    candidate_id: str
    status: str
    stages: Mapping[str, bool]
    reason: str


@dataclass(frozen=True, slots=True)
class EvolutionPromotion:
    """Cryptographically recorded activated candidate."""

    candidate_id: str
    revision: str
    package_digest: str
    active_path: str
    promoted_at: float
    signature: str


class SelfEvolution3:
    """Explicit build/test/security/performance/canary promotion pipeline."""

    REQUIRED_STAGES = ("build", "tests", "security", "performance", "canary")

    def __init__(self, artifact_root: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("self-evolution secret must contain at least 32 bytes")
        self.root = Path(artifact_root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(secret)
        self._artifacts = ArtifactQuarantineManager(self.root / "artifacts")
        self._promotion_log = self.root / "promotions.jsonl"
        self._lock = threading.RLock()
        self._history: list[EvolutionResult] = []
        self._promotions: list[EvolutionPromotion] = []

    def evaluate(self, candidate: EvolutionCandidate, *, stages: Mapping[str, Callable[[EvolutionCandidate], bool]]) -> EvolutionResult:
        """Run every required admission gate and fail closed on missing/failed gates."""
        source = Path(candidate.source_dir).resolve()
        if not source.is_dir():
            raise ValueError("candidate source directory does not exist")
        results: dict[str, bool] = {}
        for stage in self.REQUIRED_STAGES:
            check = stages.get(stage)
            if check is None:
                raise ValueError(f"missing evolution stage: {stage}")
            try:
                results[stage] = bool(check(candidate))
            except Exception:
                results[stage] = False
            if not results[stage]:
                outcome = EvolutionResult(candidate.candidate_id, "rejected", dict(results), f"gate failed: {stage}")
                with self._lock:
                    self._history.append(outcome)
                return outcome
        outcome = EvolutionResult(candidate.candidate_id, "approved", dict(results), "all admission gates passed")
        with self._lock:
            self._history.append(outcome)
        return outcome

    def promote(self, candidate: EvolutionCandidate, result: EvolutionResult) -> EvolutionPromotion:
        """Package, verify and atomically activate an approved candidate."""
        if result.candidate_id != candidate.candidate_id or result.status != "approved":
            raise AdmissionDenied("candidate has not passed every evolution gate")
        version = Path(candidate.revision).name
        if version != candidate.revision or not version:
            raise ValueError("invalid candidate revision")
        package, manifest = self._artifacts.package(candidate.source_dir, package_id=candidate.candidate_id, version=version)
        if not self._artifacts.verify(package, manifest):
            raise SupremeRuntimeError("quarantined evolution artifact failed verification")
        active = self._artifacts.activate(package, manifest)
        promoted_at = time.time()
        canonical = f"{candidate.candidate_id}|{candidate.revision}|{manifest.root_digest}|{active}|{promoted_at:.6f}".encode("utf-8")
        signature = hmac.new(self._secret, canonical, hashlib.sha256).hexdigest()
        promotion = EvolutionPromotion(candidate.candidate_id, candidate.revision, manifest.root_digest, str(active), promoted_at, signature)
        with self._lock:
            self._promotions.append(promotion)
            with self._promotion_log.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(asdict(promotion), sort_keys=True, separators=(",", ":")) + "\n")
        return promotion

    def verify_promotion(self, promotion: EvolutionPromotion) -> bool:
        """Verify a promotion receipt without modifying activation state."""
        canonical = f"{promotion.candidate_id}|{promotion.revision}|{promotion.package_digest}|{promotion.active_path}|{promotion.promoted_at:.6f}".encode("utf-8")
        return hmac.compare_digest(promotion.signature, hmac.new(self._secret, canonical, hashlib.sha256).hexdigest())

    def rollback(self, candidate_id: str) -> bool:
        """Atomically restore the previously activated artifact."""
        return self._artifacts.rollback(str(candidate_id))

    def history(self) -> tuple[EvolutionResult, ...]:
        """Return bounded promotion history."""
        with self._lock:
            return tuple(self._history[-1000:])

    def promotions(self) -> tuple[EvolutionPromotion, ...]:
        """Return bounded cryptographically recorded promotions."""
        with self._lock:
            return tuple(self._promotions[-1000:])


@dataclass(frozen=True, slots=True)
class KnowledgeDocument:
    """Provenance-addressed knowledge document."""

    document_id: str
    owner_id: str
    workspace_id: str
    source: str
    content: str
    timestamp: float
    digest: str
    metadata: Mapping[str, Any]


class KnowledgeFabric:
    """Namespace-isolated evidence store with deterministic lexical retrieval."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute("CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY, owner TEXT NOT NULL, workspace TEXT NOT NULL, source TEXT NOT NULL, content TEXT NOT NULL, created REAL NOT NULL, digest TEXT NOT NULL, metadata TEXT NOT NULL)")
        self._db.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_scope ON knowledge(owner,workspace)")
        self._lock = threading.RLock()

    def ingest(self, owner_id: str, workspace_id: str, source: str, content: str, *, metadata: Mapping[str, Any] | None = None) -> KnowledgeDocument:
        """Persist one source-addressed knowledge document."""
        owner, workspace, origin, text = map(lambda value: str(value).strip(), (owner_id, workspace_id, source, content))
        if not owner or not workspace or not origin or not text:
            raise ValueError("knowledge identity, source and content are required")
        if len(text.encode("utf-8")) > 10_000_000:
            raise ValueError("knowledge document too large")
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        document = KnowledgeDocument(uuid.uuid4().hex, owner, workspace, origin, text, time.time(), digest, dict(metadata or {}))
        with self._lock, self._db:
            self._db.execute("INSERT INTO knowledge VALUES(?,?,?,?,?,?,?,?)", (document.document_id, document.owner_id, document.workspace_id, document.source, document.content, document.timestamp, document.digest, json.dumps(document.metadata, sort_keys=True, separators=(",", ":"), default=str)))
        return document

    def search(self, owner_id: str, workspace_id: str, query: str, *, limit: int = 20) -> list[KnowledgeDocument]:
        """Perform bounded lexical retrieval inside one owner/workspace scope."""
        tokens = [token.lower() for token in str(query).split() if token.strip()]
        if not tokens:
            return []
        bounded = max(1, min(int(limit), 100))
        with self._lock:
            rows = self._db.execute("SELECT * FROM knowledge WHERE owner=? AND workspace=?", (str(owner_id), str(workspace_id))).fetchall()
        scored: list[tuple[int, KnowledgeDocument]] = []
        for row in rows:
            content = str(row[4]).lower()
            score = sum(content.count(token) for token in tokens)
            if score:
                scored.append((score, KnowledgeDocument(str(row[0]), str(row[1]), str(row[2]), str(row[3]), str(row[4]), float(row[5]), str(row[6]), json.loads(str(row[7])))))
        scored.sort(key=lambda item: (-item[0], item[1].document_id))
        return [doc for _, doc in scored[:bounded]]

    def close(self) -> None:
        """Close knowledge persistence."""
        with self._lock:
            self._db.commit()
            self._db.close()


@dataclass(frozen=True, slots=True)
class MultimodalEnvelope:
    """Bounded modality packet for injected model adapters."""

    modality: str
    content_type: str
    data: bytes
    metadata: Mapping[str, Any] = field(default_factory=dict)


class MultimodalGateway:
    """Dispatch bounded multimodal input to explicitly registered handlers."""

    def __init__(self, *, max_bytes: int = 25_000_000) -> None:
        self.max_bytes = max(1_024, min(int(max_bytes), 100_000_000))
        self._handlers: dict[str, Callable[[MultimodalEnvelope], Any]] = {}

    def register(self, modality: str, handler: Callable[[MultimodalEnvelope], Any]) -> None:
        """Register one modality handler."""
        name = str(modality).strip().lower()
        if not name or not callable(handler):
            raise ValueError("modality and callable handler are required")
        self._handlers[name] = handler

    def process(self, envelope: MultimodalEnvelope) -> Any:
        """Validate and dispatch one modality envelope."""
        modality = envelope.modality.strip().lower()
        if not modality or len(envelope.data) > self.max_bytes:
            raise ValueError("invalid or oversized multimodal envelope")
        handler = self._handlers.get(modality)
        if handler is None:
            raise AdmissionDenied(f"unsupported modality: {modality}")
        return handler(envelope)

    def snapshot(self) -> dict[str, Any]:
        """Return supported modalities."""
        return {"modalities": sorted(self._handlers), "max_bytes": self.max_bytes}


@dataclass(frozen=True, slots=True)
class ComputerAction:
    """One reversible computer-use action."""

    action_id: str
    capability: str
    precondition: Callable[[], bool]
    execute: Callable[[], Any]
    rollback: Callable[[], None]


class ComputerUseTransaction:
    """Transactional computer-use sequence with preconditions and rollback."""

    def run(self, actions: Sequence[ComputerAction], *, authorize: Callable[[ComputerAction], bool]) -> list[Any]:
        """Run actions in order and compensate completed actions on failure."""
        if len(actions) > 128:
            raise ValueError("computer-use transaction exceeds action ceiling")
        completed: list[ComputerAction] = []
        outputs: list[Any] = []
        try:
            for action in actions:
                if not authorize(action):
                    raise AdmissionDenied(f"computer-use capability denied: {action.capability}")
                if not action.precondition():
                    raise SupremeRuntimeError(f"precondition failed: {action.action_id}")
                outputs.append(action.execute())
                completed.append(action)
            return outputs
        except Exception:
            for action in reversed(completed):
                action.rollback()
            raise


@dataclass(frozen=True, slots=True)
class UAVMissionResult:
    """Safety result for simulator-first UAV mission execution."""

    status: str
    state: Mapping[str, Any]
    completed_targets: int
    error: str | None = None


class UAVSafetyFabric:
    """Simulator-first UAV control facade with explicit authorization."""

    def __init__(self, simulator: UAVSimulator) -> None:
        self.simulator = simulator

    def execute(self, targets: Sequence[tuple[float, float]], *, authorize: Callable[[str], bool], altitude_m: float = 20.0) -> UAVMissionResult:
        """Execute a bounded waypoint mission through simulator safety checks."""
        if len(targets) > 256:
            raise ValueError("UAV mission exceeds waypoint ceiling")
        if not authorize("uav.mission"):
            raise AdmissionDenied("UAV mission authorization denied")
        completed = 0
        try:
            if self.simulator.state()["mode"] == UAVMode.DISARMED.value:
                self.simulator.arm()
                self.simulator.takeoff(max(1.0, min(float(altitude_m), 120.0)))
            for lat, lon in targets:
                self.simulator.goto(float(lat), float(lon))
                completed += 1
            return UAVMissionResult("succeeded", self.simulator.state(), completed)
        except Exception as exc:
            try:
                self.simulator.return_to_home()
            except Exception as cleanup_error:
                _ = cleanup_error
            return UAVMissionResult("failed", self.simulator.state(), completed, f"{type(exc).__name__}: {exc}")


class TwinCoordinator:
    """Coordinate resource and subsystem state into one deterministic twin digest."""

    def __init__(self) -> None:
        self.resources = SystemDigitalTwin()
        self._components: dict[str, Callable[[], Mapping[str, Any]]] = {}
        self._lock = threading.RLock()

    def register(self, name: str, provider: Callable[[], Mapping[str, Any]]) -> None:
        """Register a safe component-state provider."""
        key = str(name).strip()
        if not key or not callable(provider):
            raise ValueError("twin component requires a name and provider")
        with self._lock:
            self._components[key] = provider

    def snapshot(self) -> dict[str, Any]:
        """Return bounded deterministic system state."""
        with self._lock:
            component_names = sorted(self._components)
            state: dict[str, Any] = {}
            for name in component_names:
                try:
                    state[name] = dict(self._components[name]())
                except Exception as exc:
                    state[name] = {"status": "error", "error": type(exc).__name__}
        state["resources"] = self.resources.snapshot()
        canonical = json.dumps(state, sort_keys=True, separators=(",", ":"), default=str).encode()
        return {"state": state, "digest": hashlib.sha256(canonical).hexdigest()}


@dataclass(frozen=True, slots=True)
class UnifiedObservationReceipt:
    """Evidence that an observation was persisted into memory and world state."""

    observation_id: str
    memory_event_id: int
    entity_id: str
    payload_sha256: str
    recorded_at: float


class UnifiedStateFabric:
    """Join encrypted episodic memory, world state, and bounded context compilation.

    The fabric does not duplicate storage. It coordinates the already-canonical
    MemoryFabric4 and WorldModel2 primitives and emits immutable evidence linking
    one observation to both projections.
    """

    def __init__(self, memory: MemoryFabric4, world_model: WorldModel2, compiler: ContextCompiler) -> None:
        self.memory = memory
        self.world_model = world_model
        self.compiler = compiler
        self._lock = threading.RLock()

    @staticmethod
    def _scope(value: Any, default: str) -> str:
        raw = str(value or "").strip()
        safe = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in raw)
        safe = safe.strip("._-")[:128]
        return safe or default

    def record(
        self,
        owner_id: str,
        workspace_id: str,
        kind: str,
        event_type: str,
        payload: Mapping[str, Any],
        *,
        source: str,
        entity_id: str,
        entity_type: str = "observation",
        confidence: float = 1.0,
        metadata: Mapping[str, Any] | None = None,
        observed_at: float | None = None,
    ) -> UnifiedObservationReceipt:
        if not str(entity_id).strip():
            raise ValueError("entity_id is required")
        if not 0.0 <= float(confidence) <= 1.0:
            raise ValueError("confidence must be in [0,1]")
        body = dict(payload)
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        digest = hashlib.sha256(canonical).hexdigest()
        safe_owner = self._scope(owner_id, "system")
        safe_workspace = self._scope(workspace_id, "runtime")
        safe_kind = self._scope(kind, "observations")
        event_id = uuid.uuid4().hex
        mem = self.memory.append(
            safe_owner,
            safe_workspace,
            safe_kind,
            str(event_type).strip()[:128] or "observation",
            {"observation_id": event_id, "entity_id": str(entity_id), "payload_sha256": digest, **body},
            source=str(source).strip()[:256] or "runtime",
            provenance={"observation_id": event_id, **dict(metadata or {})},
        )
        world_props = {
            "observation_id": event_id,
            "memory_event_id": mem.event_id,
            "payload_sha256": digest,
            "event_type": str(event_type).strip()[:128] or "observation",
            "source": str(source).strip()[:256] or "runtime",
            "owner_id": safe_owner,
            "workspace_id": safe_workspace,
            "memory_kind": safe_kind,
            "ok": body.get("ok"),
            "capability": body.get("capability"),
            "error": body.get("error"),
        }
        self.world_model.ingest(
            str(entity_id),
            str(entity_type).strip()[:128] or "observation",
            world_props,
            confidence=float(confidence),
            source=str(source).strip()[:128] or "runtime",
            observed_at=observed_at,
        )
        return UnifiedObservationReceipt(event_id, int(mem.event_id), str(entity_id), digest, time.time())

    def context(
        self,
        owner_id: str,
        workspace_id: str,
        objective: str,
        *,
        kind: str = "observations",
        constraints: Sequence[str] = (),
        token_budget: int = 4096,
        memory_limit: int = 64,
        entity_limit: int = 128,
    ):
        """Compile bounded context from namespace-isolated memory + world snapshot."""
        records = self.memory.recent(owner_id, workspace_id, kind, limit=max(1, min(int(memory_limit), 256)))
        snapshot = self.world_model.snapshot()
        entities = list(snapshot.entities[:max(1, min(int(entity_limit), 256))])
        evidence: list[Mapping[str, Any]] = []
        for record in records:
            evidence.append({"type": "memory", "confidence": 1.0, **record})
        for entity in entities:
            evidence.append({"type": "world", "confidence": entity.get("confidence", 1.0), **entity})
        return self.compiler.compile(objective, evidence, constraints=constraints, token_budget=token_budget)

    def snapshot(self) -> dict[str, Any]:
        return {"memory": "encrypted_namespace_store", "world_entities": len(self.world_model.snapshot().entities)}


class SupremeRuntimeFabric:
    """Single lifecycle-owned facade for the remaining frontier services."""

    def __init__(self, root: str | Path, secret: bytes) -> None:
        if len(secret) < 32:
            raise ValueError("supreme runtime secret must contain at least 32 bytes")
        base = Path(root).resolve()
        base.mkdir(parents=True, exist_ok=True)
        self.root = base
        self.agents = AgentSupervisor(secret)
        self.models = LocalModelRuntime(memory_available_mb=lambda: 0)
        self.missions = MissionEngine3(base / "missions_v3.db", secret)
        self.memory = MemoryFabric4(base / "memory_v4.db", secret)
        self.devices = DeviceFabric3(secret)
        self.observability = ObservabilityFabric3(base / "observability_v3.jsonl")
        self.evolution = SelfEvolution3(base / "evolution", secret)
        self.knowledge = KnowledgeFabric(base / "knowledge.db")
        self.multimodal = MultimodalGateway()
        self.computer_use = ComputerUseTransaction()
        self.cluster = DistributedWorkerFabric(secret)
        self.twin = TwinCoordinator()
        self.uav = UAVSafetyFabric(UAVSimulator(lat=0.0, lon=0.0, geofence_radius_m=500.0))
        self.agent_factory = LogicalAgentFactory(base / "agent_fabric.db", secret)
        self.agent_harness = LogicalAgentHarness(self.agent_factory, secret)
        self.agent_studio = LogicalAgentStudio(self.agent_factory)
        self.agent_workshop = LogicalAgentWorkshop()
        self.agent_garage = LogicalAgentGarage(self.agent_factory)
        self.tool_fabric = ToolFabric(secret)
        self.dsec = DsecSandboxManager(base / "dsec", secret)
        self.dsh = DSHKernel(base / "dsh", secret)
        self.rsi = DSHSelfEvolution(self.dsh, self.dsec, self.agent_factory, self.agent_harness, secret)
        self.precision = PrecisionGovernor()
        self.fast_path = ExecutionFastPath()
        self.context_cache = ContextCache()
        # State-of-the-art safety/awareness plane. All physical/network adapters remain injected.
        self.sensor_fusion = SensorFusionEngine()
        self.world_state = WorldStateStore()
        self.cognitive_assistant = CognitiveAssistant()
        self.flight_planner = FlightSafetyPlanner(FlightConstraints(0.0, 0.0, 500.0))
        self.swarm = HumanCommandSwarmCoordinator()
        self.cyber_defense = DefensiveSOC({"runtime"})
        self.telemetry = TelemetryFabric(max_samples=100_000, path=base / "telemetry.jsonl")
        self.hud = HUDDiagnostics()
        self.lab = LabAutomationEngine()
        self.optimizer = BoundedOptimizer()
        self.agent_population = AgentPopulationController()
        self.distributed_cognition = DistributedCognitiveFabric()
        self.root_authority = RootAuthority(secret)
        self.operational_modes = OperationalModeController()
        # Evolution 2.0 control plane: explicit contracts, bounded execution, and reversible gates.
        self.sensor_fabric = SensorFabric2()
        self.world_model_2 = WorldModel2()
        self.context_compiler = ContextCompiler()
        self.unified_state = UnifiedStateFabric(self.memory, self.world_model_2, self.context_compiler)
        self.agents.set_observation_sink(self._record_agent_observation)
        self.model_router_2 = AdaptiveModelRouter2()
        self.learning_gate = PersonalLearningGate()
        self.agent_genomes = AgentGenomeLab()
        self.verification_engine = VerificationEngine()
        self.gpu_intelligence = GpuIntelligenceFabric()
        self.recovery_coordinator = RecoveryCoordinator()
        self.frontier_events = FrontierEventStream()
        self.flet_command_center = FletCommandCenter(self.execute_operator_command)
        # Zero-trust/event reliability plane: privileged actions are independently attestable
        # and lifecycle-owned; the event journal is integrity-checked on every health snapshot.
        self.resource_ledger = ResourceLedger()
        self.zero_trust = ZeroTrustAuthority(issuer="jarvis-12.8.0")
        self.event_bus = EventBus(max_queue_size=10_000)
        self.event_fabric = EventFabric(self.event_bus, base / "events_v2.jsonl", max_events_per_second=2_000)
        self.world_model_3 = WorldModel3(
            base / "world_model_v3.db",
            tenant_id="default",
            event_sink=self.event_fabric,
        )
        # P2-P/P2-Q canonical tool plane. The legacy dynamic ToolFabric above is
        # retained for backward compatibility; the signed P2-Q path is explicitly
        # lifecycle-owned here and persists its registry separately.
        def _resolve_tool_schema(ref: str) -> Mapping[str, Any]:
            prefix="urn:jarvis:schema:"
            name=str(ref)[len(prefix):] if str(ref).startswith(prefix) else str(ref)
            path=Path(__file__).resolve().parent / "schemas" / name
            if not path.exists():
                raise ValueError(f"unknown tool schema: {ref}")
            return json.loads(path.read_text(encoding="utf-8"))
        self.p2p_tool_fabric = CanonicalToolFabric(
            config=CanonicalToolConfig(registry_path=str(base / "tool_registry_v2.db"), storage_secret=bytes(secret)),
            event_fabric=self.event_fabric,
            schema_resolver=_resolve_tool_schema,
        )
        self.tool_composition = ToolCompositionEngine(self.p2p_tool_fabric, event_fabric=self.event_fabric)
        self.simulation_universe = SimulationUniverseEngine(root=base / "simulation", event_fabric=self.event_fabric, world_model=self.world_model_3)
        _p2m_orchestration = MultiAgentOrchestration(root=base / "multi_agent_orchestration", event_fabric=self.event_fabric, simulation_engine=self.simulation_universe)
        self.multi_agent_verification = A2AVerificationFabric(_p2m_orchestration, root=base / "a2a_verification", security_authority=self.zero_trust)
        self.multi_agent_orchestration = VerifiedMultiAgentOrchestration(_p2m_orchestration, self.multi_agent_verification)
        # Register the P2-M artifact signer with P2-U without granting it any runtime authority.
        _p2m_key = self.multi_agent_orchestration._orchestration.public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
        _p2m_prev_resolver = getattr(self.event_fabric.bus, "public_key_resolver", None)
        def _p2m_resolver(subject_id: str, genome_hash: str | None, kind: str) -> bytes | None:
            if kind == "system" and subject_id == "multi-agent-orchestration" and genome_hash == self.multi_agent_orchestration._orchestration.signer_fingerprint:
                return _p2m_key
            return _p2m_prev_resolver(subject_id, genome_hash, kind) if _p2m_prev_resolver is not None else None
        self.event_fabric.bus.public_key_resolver = _p2m_resolver
        self.twin.register("agents", self.agents.snapshot)
        self.twin.register("models", self.models.snapshot)
        self.twin.register("devices", self.devices.snapshot)
        self.twin.register("observability", self.observability.snapshot)
        self.twin.register("multimodal", self.multimodal.snapshot)
        self.twin.register("logical_agents", self.agent_factory.snapshot)
        self.twin.register("dsec", self.dsec.health)
        self.twin.register("dsh", self.dsh.snapshot)
        self.twin.register("performance", lambda: {"fast_path": self.fast_path.snapshot(), "context_cache": self.context_cache.snapshot()})
        self.twin.register("sensor_fusion", self.sensor_fusion.snapshot)
        self.twin.register("world_state", lambda: {"facts": len(self.world_state.latest()), "conflicts": len(self.world_state.conflicts())})
        self.twin.register("swarm", self.swarm.snapshot)
        self.twin.register("cyber_defense", self.cyber_defense.snapshot)
        self.twin.register("telemetry", self.telemetry.snapshot)
        self.twin.register("agent_population", lambda: {"active": self.agent_population.snapshot().active, "quarantined": list(self.agent_population.snapshot().quarantined)})
        self.twin.register("distributed_cognition", self.distributed_cognition.snapshot)
        self.twin.register("operational_mode", lambda: {"mode": self.operational_modes.mode.value})
        self.twin.register("sensor_fabric_2", self.sensor_fabric.health)
        self.twin.register("world_model_2", lambda: {"digest": self.world_model_2.snapshot().digest, "entities": len(self.world_model_2.snapshot().entities)})
        self.twin.register("world_model_3", self.world_model_3.health)
        self.twin.register("multi_agent_orchestration", self.multi_agent_orchestration.health)
        self.twin.register("unified_state", self.unified_state.snapshot)
        self.twin.register("agent_genomes", self.agent_genomes.snapshot)
        self.twin.register("frontier_events", self.frontier_events.snapshot)
        self.twin.register("flet_command_center", lambda: {"status": "ready"})
        self._closed = False
        self._lock = threading.RLock()


    def _record_agent_observation(self, receipt: AgentExecutionReceipt, metadata: Mapping[str, Any]) -> None:
        owner = metadata.get("owner_id", "system")
        workspace = metadata.get("workspace_id", "runtime")
        kind = metadata.get("memory_kind", "observations")
        entity_id = f"agent:{receipt.subject}"
        try:
            current = self.world_model_3.get_entity(entity_id)
            entity = WorldEntity3(
                entity_id=entity_id,
                entity_type="agent",
                name=str(receipt.subject),
                properties={"capability": receipt.capability, "owner_id": owner, "workspace_id": workspace},
                confidence=1.0 if receipt.ok else 0.5,
                uncertainty={} if receipt.ok else {"execution": "failed"},
                provenance=Provenance("agent-supervisor", source_type="agent", producer="supreme-runtime"),
            )
            self.world_model_3.upsert_entity(entity, expected_version=current.version if current else None)
            self.world_model_3.transition_state(
                entity_id, "execution.status", "succeeded" if receipt.ok else "failed",
                actor="agent-supervisor",
                confidence=1.0 if receipt.ok else 0.5,
                provenance=Provenance("agent-supervisor", source_type="agent", producer="supreme-runtime"),
                correlation_id=receipt.request_id,
            )
        except Exception:
            logger.exception("world_model_3_agent_observation_failed")
        self.unified_state.record(
            str(owner),
            str(workspace),
            str(kind),
            "agent.execution",
            {
                "request_id": receipt.request_id,
                "subject": receipt.subject,
                "capability": receipt.capability,
                "ok": receipt.ok,
                "output_sha256": receipt.output_sha256,
                "output_bytes": receipt.output_bytes,
                "latency_ms": receipt.latency_ms,
                "error": receipt.error,
            },
            source="agent-supervisor",
            entity_id=f"agent:{receipt.subject}",
            entity_type="agent",
            confidence=1.0 if receipt.ok else 0.5,
            metadata={"request_id": receipt.request_id},
        )

    def compile_unified_context(
        self,
        owner_id: str,
        workspace_id: str,
        objective: str,
        *,
        kind: str = "observations",
        constraints: Sequence[str] = (),
        token_budget: int = 4096,
        memory_limit: int = 64,
        entity_limit: int = 128,
    ):
        """Compile context from one ACL-scoped memory namespace plus world state."""
        return self.unified_state.context(
            owner_id,
            workspace_id,
            objective,
            kind=kind,
            constraints=constraints,
            token_budget=token_budget,
            memory_limit=memory_limit,
            entity_limit=entity_limit,
        )

    def attach_model_runtime(self, model_runtime: Any, *, memory_available_mb: Callable[[], int]) -> int:
        """Bind the existing verified local-model registry/backend fabric."""
        discover = getattr(model_runtime, "discover", None)
        model_fabric = getattr(model_runtime, "fabric", None)
        if not callable(discover) or model_fabric is None:
            raise ValueError("model_runtime must expose discover() and fabric")
        records = tuple(discover())
        for record in records:
            self.models.register(ModelSpec(record.name, record.backend, max(1, int(record.memory_mb)), max(128, int(record.context_length)), tuple(record.capabilities)))
        def backend(spec: ModelSpec, prompt: str) -> str:
            get_backend = getattr(model_fabric, "get_backend", None)
            if not callable(get_backend):
                raise RuntimeError("local model fabric does not expose a backend resolver")
            adapter = get_backend(spec.model_id)
            result = adapter.generate(prompt, max_tokens=min(8192, max(1, spec.context_length // 2)), temperature=0.2, stream=False)
            text = getattr(result, "text", None)
            if text is not None:
                return str(text)
            chunks = []
            total_bytes = 0
            for chunk in result:
                value = str(chunk)
                total_bytes += len(value.encode("utf-8"))
                if total_bytes > 16 * 1024 * 1024:
                    raise ValueError("local inference output exceeded safety ceiling")
                chunks.append(value)
            return "".join(chunks)
        self.models.configure_backend(memory_available_mb=memory_available_mb, backend=backend)
        return len(records)

    def health(self) -> dict[str, Any]:
        """Return an aggregate non-secret health projection."""
        return {
            "agents": self.agents.snapshot(),
            "logical_agents": self.agent_factory.snapshot(),
            "tools": self.tool_fabric.snapshot(),
            "models": self.models.snapshot(),
            "devices": self.devices.snapshot(),
            "observability": self.observability.snapshot(),
            "multimodal": self.multimodal.snapshot(),
            "cluster": self.cluster.snapshot(),
            "dsec": self.dsec.health(),
            "dsh": self.dsh.snapshot(),
            "performance": {"fast_path": self.fast_path.snapshot(), "context_cache": self.context_cache.snapshot()},
            "sensor_fusion": self.sensor_fusion.snapshot(),
            "world_state": {"facts": len(self.world_state.latest()), "conflicts": len(self.world_state.conflicts())},
            "world_model_3": self.world_model_3.health(),
            "swarm": self.swarm.snapshot(),
            "cyber_defense": self.cyber_defense.snapshot(),
            "telemetry": self.telemetry.snapshot(),
            "agent_population": {"active": self.agent_population.snapshot().active, "quarantined": list(self.agent_population.snapshot().quarantined)},
            "distributed_cognition": self.distributed_cognition.snapshot(),
            "operational_mode": self.operational_modes.mode.value,
            "unified_state": self.unified_state.snapshot(),
            "evolution_2": {
                "sensor_fabric": self.sensor_fabric.health(),
                "world_model_digest": self.world_model_2.snapshot().digest,
                "agent_genomes": self.agent_genomes.snapshot(),
                "events": self.frontier_events.snapshot(),
                "flet_command_center": "ready",
            },
            "twin": self.twin.snapshot()["digest"],
            "zero_trust": self.zero_trust.snapshot(),
            "event_fabric": self.event_fabric.snapshot(),
            "resource_ledger": self.resource_ledger.snapshot(),
        }

    def execute_operator_command(self, command: str) -> Mapping[str, Any]:
        """Execute a bounded, non-destructive operator command for optional Flet UI use.

        The Flet surface is intentionally not a shell or arbitrary tool gateway.
        Only stable read-only runtime projections are exposed here; higher-risk
        operations continue through the authenticated desktop command gateway.
        """
        normalized = " ".join(str(command).strip().lower().split())
        if not normalized:
            raise ValueError("command is empty")
        if normalized in {"status", "health", "snapshot", "system status", "system health"}:
            return dict(self.snapshot())
        if normalized in {"frontier", "frontier status", "frontier snapshot"}:
            evolution = dict(self.health().get("evolution_2", {}))
            return {"status": "ready", "evolution_2": evolution}
        if normalized in {"events", "frontier events"}:
            return dict(self.frontier_events.snapshot())
        raise PermissionError("Flet operator surface only permits bounded read-only status commands")

    def close(self) -> None:
        """Close every owned persistent or threaded resource exactly once."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
        # Close event ingress before application resources so no late callback can
        # observe partially torn-down state. Each close is idempotent or guarded.
        self._safe_close(self.event_fabric)
        self._safe_close(self.event_bus, method="shutdown", timeout=5.0)
        for obj in (
            self.dsh, self.dsec, self.tool_composition, self.p2p_tool_fabric, self.tool_fabric, self.agent_harness, self.agent_factory,
            self.agents, self.flet_command_center, self.missions, self.memory, self.knowledge,
        ):
            self._safe_close(obj)
        for name in (
            "cluster", "devices", "observability", "evolution", "multimodal", "computer_use",
            "sensor_fusion", "world_state", "cognitive_assistant", "swarm", "cyber_defense",
            "telemetry", "hud", "lab", "optimizer", "distributed_cognition", "operational_modes",
            "multi_agent_orchestration",
            "world_model_3",
            "sensor_fabric", "world_model_2", "context_compiler", "model_router_2", "learning_gate",
            "agent_genomes", "simulation_universe", "verification_engine", "gpu_intelligence",
            "recovery_coordinator", "frontier_events", "root_authority", "precision", "fast_path",
            "context_cache", "models", "twin",
        ):
            obj = getattr(self, name, None)
            if obj is not None:
                self._safe_close(obj)
        self._safe_close(self.resource_ledger)

    @staticmethod
    def _safe_close(obj: Any, *, method: str | None = None, **kwargs: Any) -> None:
        """Best-effort idempotent shutdown for one owned component.

        One broken subsystem must never prevent cleanup of later subsystems.
        """
        methods = (method,) if method else ("shutdown", "close")
        for candidate in methods:
            if not candidate:
                continue
            fn = getattr(obj, candidate, None)
            if not callable(fn):
                continue
            try:
                fn(**kwargs)
            except Exception:
                continue
            return

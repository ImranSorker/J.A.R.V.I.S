"""P2-W Agent Economics / Resource Scheduler.

Canonical resource allocation, quota, fairness and accounting fabric for J.A.R.V.I.S.
P2-W allocates and accounts; P2-E executes. It never deploys, mutates artifacts,
or bypasses Security Authority.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import random
import threading
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, MutableMapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidator

VERSION = "1.0.0"
PUBLIC_VERSION = "12.8.3"
KERNEL_VERSION = "12.8.0"

RESOURCE_KINDS = (
    "cpu_seconds", "gpu_seconds", "vram_mb_seconds", "ram_mb_seconds",
    "disk_bytes_write", "network_bytes_in", "network_bytes_out", "tool_calls",
    "api_calls", "tokens_in", "tokens_out", "subprocesses", "concurrency_slots",
    "energy_joules_estimate", "cost_units", "wall_seconds",
)
PRIORITY_CLASSES = (
    "safety_critical", "security_critical", "recovery", "verification", "attestation",
    "diagnosis", "evolution_candidate", "production", "interactive", "background", "opportunistic",
)
OUTCOMES = (
    "granted", "granted_reduced", "queued", "deferred", "pre_empted", "denied_budget",
    "denied_quota", "denied_policy", "denied_resource_unavailable", "denied_risk", "cancelled", "expired",
)
FAIRNESS_DIMENSIONS = ("tenant", "agent", "team", "priority_class", "artifact_class", "subsystem", "time")
COST_UNIT_KINDS = ("raw", "normalized", "cost_units", "financial")
REQUESTER_KINDS = ("agent", "skill", "tool", "composite", "team", "evolution", "research", "diagnosis", "attestation", "recovery", "operator", "system")
MEASUREMENT_SOURCES = ("harness", "model_fabric", "tool_fabric", "host", "estimated")
FAIRNESS_METHODS = ("weighted_fair_queue", "deficit_round_robin", "lottery", "hierarchical")
RISK_CLASSES = ("none", "low", "medium", "high", "critical")
GUARANTEES = ("guaranteed", "best_effort", "opportunistic")
PERIODS = ("second", "minute", "hour", "day", "month")
SCHEMA_FILES = {
    "request": "resource_request_v1.schema.json",
    "decision": "allocation_decision_v1.schema.json",
    "accounting": "accounting_record_v1.schema.json",
    "policy": "scheduling_policy_v1.schema.json",
    "quota": "quota_v1.schema.json",
    "cost_unit": "cost_unit_policy_v1.schema.json",
    "currency": "currency_conversion_policy_v1.schema.json",
    "escalation": "economics_escalation_record_v1.schema.json",
}

def _period_seconds(period: str) -> int:
    return {"second": 1, "minute": 60, "hour": 3600, "day": 86400, "month": 2592000}[period]

class EconomicsError(RuntimeError):
    """Base P2-W error."""

class SchemaError(EconomicsError):
    """Schema validation failure."""

class SignatureError(EconomicsError):
    """Signature or integrity verification failure."""

class TenantIsolationError(EconomicsError):
    """Cross-tenant access or allocation was attempted."""

class ExecutionContextRequired(EconomicsError):
    """A valid P2-E ExecutionContext is required."""

class BudgetDenied(EconomicsError):
    """A request exceeds its declared budget."""

class QuotaDenied(EconomicsError):
    """A request exceeds a quota."""

class PolicyDenied(EconomicsError):
    """A scheduling or economic policy refused an operation."""

class ResourceUnavailable(EconomicsError):
    """A required resource availability signal is unavailable."""

class PreemptionDenied(EconomicsError):
    """A pre-emption request violates policy or checkpoint requirements."""

class AccountingError(EconomicsError):
    """Accounting data is invalid or cannot be measured safely."""

class ReplayDivergence(EconomicsError):
    """Replay failed to reconstruct the same deterministic state."""

class ConfigurationError(EconomicsError):
    """P2-W configuration is incomplete or invalid."""


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _uuid(value: str | None = None) -> str:
    return value or str(uuid.uuid4())


def _sha(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _sign(body: Mapping[str, Any], key: Ed25519PrivateKey) -> dict[str, Any]:
    unsigned = dict(body)
    unsigned.pop("signature", None)
    unsigned.pop("integrity_hash", None)
    digest = _sha(unsigned)
    signed = dict(unsigned)
    signed["integrity_hash"] = digest
    signed["signature"] = base64.b64encode(key.sign(canonical_bytes({k:v for k,v in signed.items() if k != "signature"}))).decode("ascii")
    return signed




def _signature_fields(body: Mapping[str, Any], key: Ed25519PrivateKey) -> tuple[str, str]:
    unsigned = dict(body)
    unsigned.pop("signature", None)
    unsigned.pop("integrity_hash", None)
    digest = _sha(unsigned)
    signed = dict(unsigned)
    signed["integrity_hash"] = digest
    signature = base64.b64encode(key.sign(canonical_bytes(signed))).decode("ascii")
    return signature, digest

def _verify_signed(doc: Mapping[str, Any], public_key: Ed25519PublicKey) -> None:
    signature = str(doc.get("signature", ""))
    integrity = str(doc.get("integrity_hash", ""))
    if not signature or not integrity:
        raise SignatureError("signature and integrity_hash are required")
    unsigned = dict(doc)
    unsigned.pop("signature", None)
    unsigned.pop("integrity_hash", None)
    if not hmac.compare_digest(integrity, _sha(unsigned)):
        raise SignatureError("integrity hash mismatch")
    signed = dict(unsigned)
    signed["integrity_hash"] = integrity
    try:
        public_key.verify(base64.b64decode(signature.encode("ascii")), canonical_bytes(signed))
    except (InvalidSignature, ValueError) as exc:
        raise SignatureError("signature verification failed") from exc


@dataclass(frozen=True, slots=True)
class ResourceAmount:
    resource_kind: str
    amount: float
    unit: str
    duration_seconds: float | None = None
    guarantee: str = "best_effort"
    def __post_init__(self) -> None:
        if self.resource_kind not in RESOURCE_KINDS: raise ValueError("unknown resource_kind")
        if self.amount < 0: raise ValueError("amount must be >= 0")
        if self.guarantee not in GUARANTEES: raise ValueError("invalid guarantee")
        if self.duration_seconds is not None and self.duration_seconds <= 0: raise ValueError("duration_seconds must be > 0")
    def as_dict(self) -> dict[str, Any]: return asdict(self)

@dataclass(frozen=True, slots=True)
class Requester:
    kind: str
    ref: str
    execution_context_ref: str
    authority_ref: str | None = None
    def __post_init__(self) -> None:
        if self.kind not in REQUESTER_KINDS: raise ValueError("invalid requester kind")
        if not self.ref: raise ValueError("requester.ref is required")
        uuid.UUID(self.execution_context_ref)
    def as_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class ResourceRequest:
    request_id: str
    request_version: int
    tenant_id: str
    requester: Requester
    requested: tuple[ResourceAmount, ...]
    priority_class: str
    priority_rationale: str
    deadline: str | None
    sla_ref: str | None
    budget_ref: str | None
    budget_ceiling: Mapping[str, float]
    risk_class: str
    danger_surface_ref: str | None
    environment_hash: str
    registry_state_ref: str
    policy_version: str
    raised_by: Mapping[str, str]
    raised_at: str
    signature: str = ""
    integrity_hash: str = ""
    def __post_init__(self) -> None:
        uuid.UUID(self.request_id)
        if self.request_version < 1 or not self.tenant_id: raise ValueError("invalid request identity")
        if self.priority_class not in PRIORITY_CLASSES: raise ValueError("invalid priority class")
        if self.risk_class not in RISK_CLASSES: raise ValueError("invalid risk class")
        if len(self.environment_hash) != 64: raise ValueError("environment_hash must be SHA-256")
        if not self.requested: raise ValueError("requested resources cannot be empty")
        for kind, amount in self.budget_ceiling.items():
            if kind not in RESOURCE_KINDS or float(amount) < 0: raise ValueError("invalid budget ceiling")
        if self.risk_class in {"high", "critical"} and not self.danger_surface_ref:
            raise ValueError("dangerous request requires danger_surface_ref")
    def body(self) -> dict[str, Any]:
        d = asdict(self); return d
    def sign(self, key: Ed25519PrivateKey) -> "ResourceRequest":
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self, public_key: Ed25519PublicKey) -> None: _verify_signed(self.body(), public_key)

@dataclass(frozen=True, slots=True)
class GrantedResource:
    resource_kind: str
    granted_amount: float
    unit: str
    guarantee: str
    valid_from: str
    valid_until: str | None

@dataclass(frozen=True, slots=True)
class Substitution:
    requested_resource_kind: str
    granted_resource_kind: str
    requested_amount: float
    granted_amount: float
    reason: str

@dataclass(frozen=True, slots=True)
class AllocationDecision:
    decision_id: str
    decision_version: int
    tenant_id: str
    request_ref: str
    outcome: str
    granted: tuple[GrantedResource, ...]
    denied_reason: Mapping[str, Any] | None
    queued_position: int | None
    pre_emption_ref: str | None
    priority_class: str
    scheduling_policy_ref: str
    scheduling_policy_version: str
    fairness_state_ref: str
    accounting_state_ref: str
    substitutions: tuple[Substitution, ...]
    constraints: tuple[Mapping[str, Any], ...]
    risk_ceiling_applied: str | None
    decided_at: str
    expires_at: str | None
    decided_by: Mapping[str, str]
    decided_by_kind: str
    registry_state_ref: str
    policy_version: str
    chain_prev_hash: str | None = None
    signature: str = ""
    integrity_hash: str = ""
    def body(self):
        d = asdict(self); return d
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class ConsumedResource:
    resource_kind: str
    amount: float
    unit: str
    window_start: str
    window_end: str
    measured_by: str
    measurement_ref: str | None
    estimate_vs_actual_delta_pct: float | None = None
    def __post_init__(self):
        if self.resource_kind not in RESOURCE_KINDS: raise ValueError("invalid resource kind")
        if self.measured_by not in MEASUREMENT_SOURCES: raise ValueError("invalid measurement source")
        if self.measured_by == "estimated" and self.measurement_ref is None: raise ValueError("estimated records require measurement_ref")
        if self.amount < 0: raise ValueError("consumption cannot be negative")

@dataclass(frozen=True, slots=True)
class AccountingRecord:
    record_id: str
    record_version: int
    tenant_id: str
    subject: Mapping[str, str]
    parent_refs: tuple[str, ...]
    consumed: tuple[ConsumedResource, ...]
    cost: Mapping[str, Any]
    budget_ref: str | None
    budget_ceiling: Mapping[str, float] | None
    budget_utilization_pct: float | None
    budget_exceeded: bool
    billed_to: str | None
    billing_notes: str | None
    attribution: Mapping[str, float] | None
    period_start: str
    period_end: str
    computed_by: Mapping[str, str]
    computed_at: str
    registry_state_ref: str
    chain_prev_hash: str | None = None
    signature: str = ""
    integrity_hash: str = ""
    def body(self):
        d=asdict(self); return d
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class PriorityWeight:
    priority_class: str
    weight: float
    max_concurrency: int | None = None
    max_share_pct: float | None = None
    min_share_pct: float | None = None

@dataclass(frozen=True, slots=True)
class FairnessConfig:
    dimensions: tuple[str, ...]
    method: str
    short: int
    medium: int
    long: int
    enforcement: str = "hard"
    def __post_init__(self):
        if not self.dimensions: raise ValueError("at least one fairness dimension required")
        if any(x not in FAIRNESS_DIMENSIONS for x in self.dimensions): raise ValueError("invalid fairness dimension")
        if self.method not in FAIRNESS_METHODS: raise ValueError("invalid fairness method")
        if self.enforcement not in {"hard","soft"}: raise ValueError("invalid fairness enforcement")
        if min(self.short,self.medium,self.long) <= 0: raise ValueError("fairness windows must be positive")

@dataclass(frozen=True, slots=True)
class PreemptionConfig:
    allowed: bool
    only_for_priority: tuple[str, ...]
    only_against_priority: tuple[str, ...]
    min_progress_seconds: int
    max_per_window: int
    requires_checkpoint: bool

@dataclass(frozen=True, slots=True)
class RiskCeiling:
    risk_class: str
    max_share_pct: float
    requires_authority: bool

@dataclass(frozen=True, slots=True)
class Quota:
    quota_id: str
    scope: str
    scope_ref: str
    resource_kind: str
    period: str
    max_amount: float
    burst: float | None
    created_at: str
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class SchedulingPolicy:
    policy_id: str
    policy_version: str
    tenant_id: str | None
    priority_weights: tuple[PriorityWeight, ...]
    fairness: FairnessConfig
    starvation_max_wait_seconds: int
    starvation_escalation_rule: str
    pre_emption: PreemptionConfig
    risk_ceilings: tuple[RiskCeiling, ...]
    quotas: tuple[Quota, ...]
    cost_unit_policy_ref: str
    currency_conversion_policy_ref: str | None
    authored_by: Mapping[str, str]
    approved_by: Mapping[str, str] | None
    effective_at: str
    supersedes: str | None
    signature: str = ""
    integrity_hash: str = ""
    def body(self):
        d=asdict(self); return d
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class CostUnitPolicy:
    policy_id: str
    policy_version: str
    resource_coefficients: Mapping[str, float]
    normalization_factors: Mapping[str, float]
    formula: str
    authored_by: Mapping[str, str]
    effective_at: str
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class CurrencyConversionPolicy:
    policy_id: str
    policy_version: str
    base_unit: str
    rates: Mapping[str, float]
    effective_at: str
    authored_by: Mapping[str, str]
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)
    def verify(self,key): _verify_signed(self.body(),key)

@dataclass(frozen=True, slots=True)
class FairnessReport:
    report_id: str
    tenant_id: str
    dimension: str
    method: str
    shares: Mapping[str, float]
    deficits: Mapping[str, float]
    escalated: tuple[str, ...]
    computed_at: str
    fairness_state_ref: str
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)

@dataclass(frozen=True, slots=True)
class ReconciliationReport:
    report_id: str
    tenant_id: str
    scope: str
    window_start: str
    window_end: str
    estimates: Mapping[str, float]
    actuals: Mapping[str, float]
    deltas_pct: Mapping[str, float]
    deviations: tuple[str, ...]
    threshold_pct: float
    computed_at: str
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)

@dataclass(frozen=True, slots=True)
class QueueState:
    scope: str
    ordered_request_ids: tuple[str, ...]
    depth: int
    generated_at: str
    queue_hash: str

@dataclass(frozen=True, slots=True)
class EscalationRecord:
    escalation_id: str
    tenant_id: str
    requester_ref: str
    reason: str
    from_priority: str
    to_priority: str
    created_at: str
    signature: str = ""
    integrity_hash: str = ""
    def body(self): return asdict(self)
    def sign(self,key):
        sig, digest = _signature_fields(self.body(), key)
        return replace(self, signature=sig, integrity_hash=digest)

class _Ledger:
    def __init__(self, root: Path, key: Ed25519PrivateKey):
        self.root=root; self.root.mkdir(parents=True,exist_ok=True); self.key=key; self._lock=threading.RLock(); self._last: dict[str,str]={}
    def append(self, kind: str, tenant: str, doc: Mapping[str,Any]) -> Path:
        with self._lock:
            path=self.root/f"{kind}.jsonl"
            path.parent.mkdir(parents=True,exist_ok=True)
            row=dict(doc)
            with path.open('a',encoding='utf-8') as f: f.write(canonical_json(row).decode()+"\n")
            self._last[tenant]=str(row.get('integrity_hash', ''))
            return path
    def previous(self, tenant: str) -> str | None: return self._last.get(tenant)
    def load(self, kind: str) -> list[dict[str,Any]]:
        path=self.root/f"{kind}.jsonl"
        if not path.exists(): return []
        return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]

class AgentEconomics:
    """Canonical deterministic scheduler/accounting engine."""
    def __init__(self, root: str|Path, *, signing_key: Ed25519PrivateKey|None=None,
                 event_fabric: Any|None=None, context_validator: Callable[[Any], bool]|None=None,
                 deviation_threshold_pct: float=10.0):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.signing_key=signing_key or Ed25519PrivateKey.generate(); self.public_key=self.signing_key.public_key()
        self.events=event_fabric; self.context_validator=context_validator; self.deviation_threshold_pct=float(deviation_threshold_pct); self._schema_validator=SchemaValidator(max_errors=64)
        self.ledger=_Ledger(self.root/'ledger', self.signing_key)
        self.requests: dict[str,ResourceRequest]={}; self.decisions: dict[str,AllocationDecision]={}; self.accounting: list[AccountingRecord]=[]
        self.policies: dict[str,SchedulingPolicy]={}; self.quotas: dict[str,Quota]={}; self.cost_policies: dict[str,CostUnitPolicy]={}; self.currency_policies: dict[str,CurrencyConversionPolicy]={}
        self.availability: dict[str,float]={}; self.queue: dict[str,ResourceRequest]={}; self.consumed: defaultdict[tuple[str,str],float]=defaultdict(float)
        self.checkpoints: set[str]=set(); self.progress: dict[str,float]={}; self.preemptions: defaultdict[str,int]=defaultdict(int); self.wait_started: dict[str,float]={}; self.fairness_counters: defaultdict[str,float]=defaultdict(float)
        self._chain: dict[str,str]={}; self._accounting_chain: dict[str,str]={}; self._lock=threading.RLock(); self._request_hashes: dict[str,str]={}; self._budget_usage: defaultdict[tuple[str,str,str],float]=defaultdict(float); self._pending_preemptions: dict[str,str]={}

    def _schema(self, name: str) -> dict[str, Any]:
        path = self.root.parent / "schemas" / SCHEMA_FILES[name]
        if not path.exists():
            path = Path(__file__).resolve().parent / "schemas" / SCHEMA_FILES[name]
        if not path.exists():
            raise SchemaError(f"schema unavailable: {SCHEMA_FILES[name]}")
        return json.loads(path.read_text(encoding="utf-8"))

    def _validate_schema(self, name: str, value: Mapping[str, Any]) -> None:
        try:
            self._schema_validator.validate_or_raise(json.loads(canonical_json(dict(value)).decode("utf-8")), self._schema(name))
        except Exception as exc:
            raise SchemaError(str(exc)) from exc

    def _require_context(self, context: Any, tenant_id: str) -> None:
        if context is None: raise ExecutionContextRequired("P2-E ExecutionContext is required")
        if self.context_validator is not None and not self.context_validator(context): raise ExecutionContextRequired("ExecutionContext validation failed")
        if not hasattr(context,'execution_id') or not hasattr(context,'auth_context'): raise ExecutionContextRequired("invalid P2-E ExecutionContext shape")
        if hasattr(context.auth_context,'principal') and not context.auth_context.principal: raise ExecutionContextRequired("authorized execution context required")
        if str(getattr(context,'execution_id','')) == "": raise ExecutionContextRequired("execution_id is required")
        # tenant identity remains request-scoped; P2-E has no tenant_id field in V12.8.3.
        if not tenant_id: raise TenantIsolationError("tenant_id is required")

    def _emit(self, name: str, payload: Mapping[str,Any], request_or_tenant: str, *, correlation_id: str|None=None, causation_id: str|None=None):
        if self.events is None: return
        full=f"Economics.{name}"
        if hasattr(self.events,'publish'):
            try: self.events.publish(full, dict(payload), source='p2w.agent_economics', correlation_id=correlation_id or request_or_tenant, causation_id=causation_id)
            except TypeError: self.events.publish(full, dict(payload))

    def set_availability(self, availability: Mapping[str,float], *, context: Any, tenant_id: str) -> None:
        self._require_context(context,tenant_id)
        for k,v in availability.items():
            if k not in RESOURCE_KINDS or float(v)<0: raise ValueError("invalid resource availability")
        self.availability={str(k):float(v) for k,v in availability.items()}
        self._emit('ResourceAvailable',{'tenant_id':tenant_id,'availability':dict(self.availability)},tenant_id)

    def register_policy(self, policy: SchedulingPolicy, *, context: Any, security_authorized: bool=False) -> str:
        self._require_context(context, policy.tenant_id or 'system')
        if not policy.starvation_max_wait_seconds>0: raise PolicyDenied("starvation prevention is mandatory")
        self._validate_policy(policy)
        if policy.supersedes and not security_authorized:
            prev=self.policies.get(policy.supersedes)
            if prev and self._policy_is_looser(prev,policy): raise PolicyDenied("policy loosening requires Security Authority")
        policy=policy.sign(self.signing_key) if not policy.signature else policy
        self._validate_schema("policy", policy.body())
        self.policies[policy.policy_id]=policy;
        if policy.supersedes and policy.supersedes in self.policies:
            self._emit('PolicyDeprecated',{'policy_id':policy.supersedes,'superseded_by':policy.policy_id},policy.tenant_id or 'system')
        if self._parse_dt(policy.effective_at) <= datetime.now(timezone.utc): self._emit('PolicyActivated',policy.body(),policy.tenant_id or 'system')
        return policy.policy_id

    def _policy_is_looser(self,a:SchedulingPolicy,b:SchedulingPolicy)->bool:
        # conservative: any larger max share / quota / pre-emption latitude is loosening.
        if b.pre_emption.allowed and not a.pre_emption.allowed: return True
        amap={x.priority_class:x for x in a.priority_weights}; bmap={x.priority_class:x for x in b.priority_weights}
        for c in bmap:
            if c in amap and bmap[c].max_share_pct is not None and amap[c].max_share_pct is not None and bmap[c].max_share_pct>amap[c].max_share_pct: return True
        return False

    def _validate_policy(self,p:SchedulingPolicy):
        seen={x.priority_class for x in p.priority_weights}
        if set(PRIORITY_CLASSES)-seen: raise ConfigurationError("policy must declare all priority classes")
        if not p.cost_unit_policy_ref: raise ConfigurationError("cost_unit_policy_ref required")
        if p.fairness.method not in FAIRNESS_METHODS: raise ConfigurationError("unsupported fairness method")
        if p.pre_emption.max_per_window<0 or p.pre_emption.min_progress_seconds<0: raise ConfigurationError("invalid preemption bounds")
        for q in p.quotas:
            if q.resource_kind not in RESOURCE_KINDS: raise ConfigurationError("invalid quota resource")

    def activate_policy(self, policy_id: str, *, effective_at: str | None = None, context: Any, tenant_id: str) -> str:
        self._require_context(context, tenant_id)
        policy = self.get_policy(policy_id, context=context, tenant_id=tenant_id)
        when = self._parse_dt(effective_at or policy.effective_at)
        if when > datetime.now(timezone.utc):
            raise PolicyDenied("policy effective_at is in the future")
        self._emit("PolicyActivated", policy.body(), tenant_id)
        return policy.policy_id

    def register_cost_unit_policy(self, policy: CostUnitPolicy, *, context: Any, tenant_id: str='system') -> str:
        self._require_context(context,tenant_id); 
        for k in policy.resource_coefficients:
            if k not in RESOURCE_KINDS: raise ConfigurationError("invalid cost coefficient resource")
        for v in policy.resource_coefficients.values():
            if float(v)<0: raise ConfigurationError("negative cost coefficient")
        for k,v in policy.normalization_factors.items():
            if k not in RESOURCE_KINDS or float(v)<=0: raise ConfigurationError("invalid normalization factor")
        signed=policy.sign(self.signing_key) if not policy.signature else policy; self._validate_schema("cost_unit", signed.body()); self.cost_policies[policy.policy_id]=signed; return policy.policy_id

    def register_currency_policy(self, policy: CurrencyConversionPolicy, *, context: Any, tenant_id: str='system') -> str:
        self._require_context(context,tenant_id); 
        for cur,rate in policy.rates.items():
            if float(rate)<=0: raise ConfigurationError("currency rates must be > 0")
        signed=policy.sign(self.signing_key) if not policy.signature else policy; self._validate_schema("currency", signed.body()); self.currency_policies[policy.policy_id]=signed; return policy.policy_id

    def set_quota(self, quota: Quota, *, context: Any, security_authorized: bool=False) -> str:
        self._require_context(context,quota.scope_ref.split(':',1)[0] if ':' in quota.scope_ref else quota.scope_ref)
        if quota.scope not in {'tenant','agent','team','artifact_class'}: raise ConfigurationError("invalid quota scope")
        if quota.max_amount<0 or quota.resource_kind not in RESOURCE_KINDS or quota.period not in PERIODS: raise ConfigurationError("invalid quota")
        old=self.quotas.get(quota.quota_id)
        if old and quota.max_amount < old.max_amount: self._emit('QuotaTightened',quota.body(),quota.scope_ref)
        if old and quota.max_amount > old.max_amount:
            if quota.scope=='tenant' and not security_authorized: raise PolicyDenied("tenant quota loosening requires Security Authority")
            self._emit('QuotaLoosened',quota.body(),quota.scope_ref)
        signed=quota.sign(self.signing_key) if not quota.signature else quota; self._validate_schema("quota", signed.body()); self.quotas[quota.quota_id]=signed; self._emit('QuotaSet',signed.body(),quota.scope_ref); return quota.quota_id

    def submit_request(self, request: ResourceRequest, *, context: Any) -> str:
        self._require_context(context,request.tenant_id); request.verify(self.public_key)
        self._validate_schema("request", request.body())
        request_hash = request.integrity_hash
        if request.request_id in self.requests:
            if self._request_hashes.get(request.request_id) != request_hash:
                raise SchemaError("request idempotency violation: request content changed")
            return request.request_id
        for existing_id, existing_hash in self._request_hashes.items():
            if existing_hash == request_hash:
                return existing_id
        policy=self._find_policy(request)
        self._check_budget(request)
        self._check_quotas(request)
        self._check_danger_authority(request, context)
        self.requests[request.request_id]=request
        self._request_hashes[request.request_id]=request_hash
        self.queue[request.request_id]=request
        self.wait_started[request.request_id]=time.monotonic()
        self._emit('RequestSubmitted',request.body(),request.tenant_id,correlation_id=request.request_id)
        return request.request_id

    @staticmethod
    def _parse_dt(value: str) -> datetime:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))

    def _find_policy(self,r:ResourceRequest)->SchedulingPolicy:
        now = datetime.now(timezone.utc)
        matches=[p for p in self.policies.values() if p.tenant_id in {None,r.tenant_id} and p.policy_version==r.policy_version and self._parse_dt(p.effective_at) <= now]
        if not matches: raise PolicyDenied("no matching scheduling policy")
        matches.sort(key=lambda p:(p.tenant_id is not None,p.effective_at), reverse=True); return matches[0]

    def _check_budget(self,r:ResourceRequest)->None:
        for item in r.requested:
            ceiling=r.budget_ceiling.get(item.resource_kind)
            if ceiling is None:
                continue
            used = self._budget_usage[(r.tenant_id, r.budget_ref or "__requestless__", item.resource_kind)]
            if used + item.amount > float(ceiling)+1e-12:
                self._emit('BudgetExceeded',{'request_id':r.request_id,'resource_kind':item.resource_kind,'used':used,'requested':item.amount,'ceiling':float(ceiling)},r.tenant_id); raise BudgetDenied("request exceeds declared budget ceiling")
        self._emit('BudgetChecked',{'request_id':r.request_id,'status':'passed'},r.tenant_id)

    def _check_danger_authority(self,r:ResourceRequest,context:Any):
        dangerous=r.risk_class in {'high','critical'} or bool(r.danger_surface_ref)
        if dangerous:
            token=str(getattr(getattr(context,'auth_context',None),'authorization_token',''))
            if not token: raise PolicyDenied("dangerous allocation requires authority")
            self._emit('PolicyEvaluated',{'request_id':r.request_id,'risk_class':r.risk_class,'authority_required':True},r.tenant_id)

    def _active_priority_count(self, tenant_id: str, priority_class: str) -> int:
        return sum(1 for d in self.decisions.values() if d.tenant_id == tenant_id and d.priority_class == priority_class and d.outcome in {"granted", "granted_reduced"})

    def _quota_usage(self, quota:Quota, now:datetime|None=None)->float:
        now = now or datetime.now(timezone.utc)
        cutoff = now.timestamp() - _period_seconds(quota.period)
        total = 0.0
        for record in self.accounting:
            if record.tenant_id != (quota.scope_ref if quota.scope == "tenant" else record.tenant_id):
                if quota.scope == "tenant":
                    continue
            applies = (quota.scope == "tenant" and record.tenant_id == quota.scope_ref) or (quota.scope == "agent" and record.subject.get("ref") == quota.scope_ref) or (quota.scope == "team" and record.subject.get("ref") == quota.scope_ref) or (quota.scope == "artifact_class" and record.subject.get("kind") == quota.scope_ref)
            if not applies:
                continue
            try:
                end_ts = self._parse_dt(record.period_end).timestamp()
            except Exception:
                continue
            if end_ts < cutoff:
                continue
            total += sum(c.amount for c in record.consumed if c.resource_kind == quota.resource_kind)
        return total

    def _check_quotas(self,r:ResourceRequest)->None:
        policy=self._find_policy(r)
        for q in policy.quotas:
            applies=(q.scope=='tenant' and q.scope_ref==r.tenant_id) or (q.scope=='agent' and q.scope_ref==r.requester.ref) or (q.scope=='team' and q.scope_ref==r.requester.ref) or (q.scope=='artifact_class' and q.scope_ref==r.requester.kind)
            if not applies: continue
            for item in r.requested:
                if item.resource_kind==q.resource_kind and self._quota_usage(q)+item.amount > q.max_amount+float(q.burst or 0.0)+1e-12:
                    self._emit('QuotaExceeded',{'request_id':r.request_id,'quota_id':q.quota_id},r.tenant_id); raise QuotaDenied("request exceeds quota")
        self._emit('QuotaChecked',{'request_id':r.request_id,'status':'passed'},r.tenant_id)

    def _available_for(self,kind:str)->float|None: return self.availability.get(kind)

    def _fair_score(self,r:ResourceRequest,policy:SchedulingPolicy)->float:
        w=next(x.weight for x in policy.priority_weights if x.priority_class==r.priority_class)
        urgency=float(len(PRIORITY_CLASSES) - PRIORITY_CLASSES.index(r.priority_class))
        usage=self.consumed[(r.tenant_id,r.requester.ref)]
        return (w * urgency)/(1.0+usage)

    def _ordered(self,scope_tenant:str,policy:SchedulingPolicy)->list[ResourceRequest]:
        reqs=[r for r in self.queue.values() if r.tenant_id==scope_tenant]
        if policy.fairness.method=='weighted_fair_queue': reqs.sort(key=lambda r:(-self._fair_score(r,policy), r.request_id))
        elif policy.fairness.method=='deficit_round_robin':
            for r in reqs: self.fairness_counters[r.requester.ref]+=1.0
            reqs.sort(key=lambda r:(-self.fairness_counters[r.requester.ref],r.request_id))
        elif policy.fairness.method=='hierarchical': reqs.sort(key=lambda r:(r.tenant_id,r.requester.ref,-self._fair_score(r,policy),r.request_id))
        else:
            seed=int(hashlib.sha256((scope_tenant+policy.policy_version).encode()).hexdigest()[:16],16); rng=random.Random(seed)
            weights={x.priority_class:max(float(x.weight),1e-9) for x in policy.priority_weights}
            reqs.sort(key=lambda r: math.log(max(rng.random(),1e-12))/weights[r.priority_class], reverse=True)
        for idx,r in enumerate(reqs): self._emit('PriorityOrdered',{'request_id':r.request_id,'position':idx+1},scope_tenant)
        return reqs

    def decide(self, request_id:str, *, context:Any) -> AllocationDecision:
        r=self.requests.get(request_id)
        if r is None: raise KeyError(request_id)
        self._require_context(context,r.tenant_id)
        if request_id in {x.request_ref for x in self.decisions.values()}: return next(x for x in self.decisions.values() if x.request_ref==request_id)
        policy=self._find_policy(r)
        self._emit('BudgetChecked',{'request_id':r.request_id,'stage':1,'status':'passed'},r.tenant_id,correlation_id=r.request_id)
        self._check_quotas(r)
        waited = max(0.0, time.monotonic() - self.wait_started.get(r.request_id, time.monotonic()))
        if r.deadline and r.deadline < _utc(): return self._issue_denied(r,'expired',{'reason':'deadline_exceeded'},policy,context)
        if waited > policy.starvation_max_wait_seconds and r.request_id in self.queue:
            self.escalate_starvation(r.requester.ref, reason="max_wait_seconds_exceeded", context=context, tenant_id=r.tenant_id)
        if waited > policy.starvation_max_wait_seconds * 2 and r.request_id in self.queue:
            self._emit('DecisionDenied',{'request_id':r.request_id,'reason':'queue_ttl_expired'},r.tenant_id,correlation_id=r.request_id)
            return self._issue_denied(r,'expired',{'reason':'queue_ttl_expired'},policy,context)
        self._emit('FairnessEvaluated',{'request_id':r.request_id,'method':policy.fairness.method},r.tenant_id,correlation_id=r.request_id)
        # policy risk ceiling
        ceiling=next((x for x in policy.risk_ceilings if x.risk_class==r.risk_class),None)
        if ceiling and ceiling.requires_authority: self._check_danger_authority(r,context)
        ordered=self._ordered(r.tenant_id,policy); pos=(ordered.index(r)+1 if r in ordered else None)
        unavailable=[]; grants=[]; substitutions=[]
        weight_cfg=next(x for x in policy.priority_weights if x.priority_class==r.priority_class)
        if weight_cfg.max_concurrency is not None and self._active_priority_count(r.tenant_id, r.priority_class) >= weight_cfg.max_concurrency:
            self._emit('PolicyDenied',{'request_id':r.request_id,'reason':'priority_concurrency_ceiling'},r.tenant_id,correlation_id=r.request_id)
            return self._issue_denied(r,'deferred',{'reason':'priority_concurrency_ceiling'},policy,context)
        current_share=self.compute_share(r.requester.ref, (_utc(), _utc()), context=context, tenant_id=r.tenant_id) if self.accounting else 0.0
        if ceiling and current_share*100.0 > float(ceiling.max_share_pct)+1e-9:
            self._emit('PolicyDenied',{'request_id':r.request_id,'reason':'risk_share_ceiling','risk_class':r.risk_class},r.tenant_id,correlation_id=r.request_id)
            return self._issue_denied(r,'denied_risk',{'reason':'risk_share_ceiling'},policy,context)
        if weight_cfg.max_share_pct is not None and current_share*100.0 > float(weight_cfg.max_share_pct)+1e-9:
            self._emit('PolicyDenied',{'request_id':r.request_id,'reason':'priority_share_ceiling'},r.tenant_id,correlation_id=r.request_id)
            return self._issue_denied(r,'denied_policy',{'reason':'priority_share_ceiling'},policy,context)
        for item in r.requested:
            avail=self._available_for(item.resource_kind)
            if avail is None:
                unavailable.append(item); self._emit('ResourceUnavailable',{'request_id':r.request_id,'resource_kind':item.resource_kind,'reason':'no_availability_signal'},r.tenant_id,correlation_id=r.request_id); continue
            if item.amount > avail + 1e-12:
                unavailable.append(item); self._emit('ResourceUnavailable',{'request_id':r.request_id,'resource_kind':item.resource_kind,'requested':item.amount,'available':avail},r.tenant_id,correlation_id=r.request_id); continue
            grants.append(GrantedResource(item.resource_kind,item.amount,item.unit,item.guarantee,_utc(),None))
        if unavailable:
            # grant_reduced only when every reduced amount is explicit and >0
            for item in unavailable:
                avail=self._available_for(item.resource_kind)
                if avail is not None and avail>0 and item.guarantee!='guaranteed':
                    grants.append(GrantedResource(item.resource_kind,avail,item.unit,'best_effort',_utc(),None)); substitutions.append(Substitution(item.resource_kind,item.resource_kind,item.amount,avail,'resource pressure'))
            if substitutions: outcome='granted_reduced'
            else: outcome='queued' if r.requester.kind not in {'recovery','safety_critical'} else 'denied_resource_unavailable'
        else: outcome='granted'
        if outcome=='queued':
            decision=self._issue(r,'queued',tuple(grants),tuple(substitutions),pos,None,policy,context)
            return decision
        for g in grants:
            avail=self.availability.get(g.resource_kind)
            if avail is not None: self.availability[g.resource_kind]=max(0.0,avail-g.granted_amount)
        self.queue.pop(request_id,None)
        for g in grants:
            self._budget_usage[(r.tenant_id, r.budget_ref or "__requestless__", g.resource_kind)] += g.granted_amount
        return self._issue(r,outcome,tuple(grants),tuple(substitutions),pos,None,policy,context)

    def _issue_denied(self,r,outcome,reason,policy,context): return self._issue(r,outcome,tuple(),tuple(),None,reason,policy,context)

    def _issue(self,r,outcome,grants,subs,pos,reason,policy,context):
        prev=self._chain.get(r.tenant_id)
        d=AllocationDecision(_uuid(),1,r.tenant_id,r.request_id,outcome,grants,reason,pos,None,r.priority_class,policy.policy_id,policy.policy_version,hashlib.sha256(canonical_bytes({"tenant":r.tenant_id,"shares":dict(self.fairness_counters)})).hexdigest(),self._accounting_state_ref(r.tenant_id),subs,tuple(),next((x.risk_class for x in policy.risk_ceilings if x.risk_class==r.risk_class),None),_utc(),None,{"principal":getattr(getattr(context,'auth_context',None),'principal','scheduler'),"key_id":hashlib.sha256(self.public_key.public_bytes_raw()).hexdigest()},"scheduler",r.registry_state_ref,r.policy_version,prev)
        d=d.sign(self.signing_key); self._validate_schema("decision", d.body()); self.decisions[d.decision_id]=d; self._chain[r.tenant_id]=d.integrity_hash; self.ledger.append('decisions',r.tenant_id,d.body())
        event='DecisionIssued' if outcome=='granted' else {'granted_reduced':'DecisionGrantedReduced','queued':'DecisionQueued','deferred':'DecisionDeferred','denied_resource_unavailable':'DecisionDenied','denied_policy':'DecisionDenied','denied_budget':'DecisionDenied','denied_quota':'DecisionDenied','denied_risk':'DecisionDenied','expired':'DecisionDenied'}.get(outcome,'DecisionIssued')
        self._emit(event,d.body(),r.tenant_id,correlation_id=r.request_id)
        return d

    def _accounting_state_ref(self,tenant:str)->str:
        rows=[a.integrity_hash for a in self.accounting if a.tenant_id==tenant]
        return hashlib.sha256(canonical_bytes(rows)).hexdigest()

    def pre_empt(self, decision_id:str, *, context:Any, reason:str, checkpoint_ref:str|None=None, preemptor_priority:str="safety_critical") -> AllocationDecision:
        d=self.decisions.get(decision_id)
        if d is None: raise KeyError(decision_id)
        r=self.requests[d.request_ref]; self._require_context(context,r.tenant_id); policy=self._find_policy(r)
        cfg=policy.pre_emption
        def refuse(msg: str) -> None:
            self._emit('PreEmptionRefused',{'decision_id':decision_id,'reason':msg},r.tenant_id,correlation_id=r.request_id,causation_id=decision_id)
            raise PreemptionDenied(msg)
        if not cfg.allowed or preemptor_priority not in cfg.only_for_priority or r.priority_class not in cfg.only_against_priority: refuse("pre-emption is not permitted by priority policy")
        if cfg.requires_checkpoint and (checkpoint_ref is None or checkpoint_ref not in self.checkpoints): refuse("verified checkpoint required")
        if self.progress.get(r.request_id,0.0) < cfg.min_progress_seconds: refuse("minimum progress not reached")
        if self.preemptions[r.request_id] >= cfg.max_per_window: refuse("pre-emption window limit exceeded")
        self.preemptions[r.request_id]+=1
        if checkpoint_ref:
            self._pending_preemptions[r.request_id]=checkpoint_ref
        result=self._issue(r,'pre_empted',d.granted,tuple(),None,{'reason':reason,'checkpoint_ref':checkpoint_ref},policy,context)
        self._emit('PreEmpted',{'decision_id':decision_id,'checkpoint_ref':checkpoint_ref,'reason':reason},r.tenant_id,correlation_id=r.request_id,causation_id=decision_id)
        return result

    def resume_preempted(self, decision_id:str, *, context:Any, checkpoint_ref:str|None=None)->AllocationDecision:
        d=self.decisions.get(decision_id)
        if not d or d.outcome!='pre_empted': raise PreemptionDenied("decision is not pre-empted")
        r=self.requests[d.request_ref]; self._require_context(context,r.tenant_id); policy=self._find_policy(r)
        ref=checkpoint_ref or self._pending_preemptions.get(r.request_id)
        if policy.pre_emption.requires_checkpoint and (not ref or ref not in self.checkpoints): raise PreemptionDenied("verified checkpoint required for resume")
        self.queue[r.request_id]=r
        result=self._issue(r,'granted',d.granted,tuple(),None,None,policy,context)
        self._emit('PreEmptionResumed',{'preempted_decision_id':decision_id,'checkpoint_ref':ref},r.tenant_id,correlation_id=r.request_id,causation_id=decision_id)
        self._pending_preemptions.pop(r.request_id,None)
        return result

    def register_checkpoint(self, checkpoint_ref:str, *, context:Any, tenant_id:str):
        self._require_context(context,tenant_id); uuid.UUID(checkpoint_ref); self.checkpoints.add(checkpoint_ref)

    def update_progress(self, request_id:str, seconds:float, *, context:Any):
        r=self.requests[request_id]; self._require_context(context,r.tenant_id); self.progress[request_id]=max(0,float(seconds))

    def record_consumption(self, subject_ref:str, consumed:Sequence[ConsumedResource], *, context:Any, tenant_id:str, budget_ref:str|None=None, budget_ceiling:Mapping[str,float]|None=None, parent_refs:Sequence[str]=(), billed_to:str|None=None, billing_notes:str|None=None, subject_kind:str="agent") -> AccountingRecord:
        self._require_context(context,tenant_id)
        if not consumed: raise AccountingError("consumption must not be empty")
        if any(c.measured_by=='estimated' for c in consumed):
            # Estimates are permitted only when explicitly marked and measurement_ref identifies the estimator.
            if any(not c.measurement_ref for c in consumed): raise AccountingError("unmeasured use without estimator reference is refused")
        else:
            for c in consumed:
                if c.measured_by not in MEASUREMENT_SOURCES: raise AccountingError("invalid measurement source")
        cost=self._compute_cost(consumed)
        utilization=None; exceeded=False
        if budget_ceiling:
            util=[]
            for c in consumed:
                ceiling=budget_ceiling.get(c.resource_kind)
                if ceiling is not None: util.append((c.amount/ceiling)*100.0 if ceiling else 100.0)
            if util: utilization=max(util); exceeded=utilization>100.0+1e-9
        rec=AccountingRecord(_uuid(),1,tenant_id,{"kind":subject_kind,"ref":subject_ref},tuple(parent_refs),tuple(consumed),cost,budget_ref,dict(budget_ceiling) if budget_ceiling else None,utilization,exceeded,billed_to,billing_notes,None,min(c.window_start for c in consumed),max(c.window_end for c in consumed),{"principal":getattr(getattr(context,'auth_context',None),'principal','scheduler'),"key_id":hashlib.sha256(self.public_key.public_bytes_raw()).hexdigest()},_utc(),"registry://runtime/p2w",self._accounting_chain.get(tenant_id))
        rec=rec.sign(self.signing_key); self._validate_schema("accounting", rec.body()); self.accounting.append(rec)
        self.ledger.append('accounting',tenant_id,rec.body()); self._accounting_chain[tenant_id]=rec.integrity_hash; self.consumed[(tenant_id,subject_ref)] += sum(c.amount for c in consumed)
        self._emit('ConsumptionRecorded',rec.body(),tenant_id,correlation_id=parent_refs[0] if parent_refs else rec.record_id)
        if exceeded: self._emit('BudgetExceeded',{'record_id':rec.record_id,'subject_ref':subject_ref},tenant_id)
        return rec

    def _compute_cost(self, consumed:Sequence[ConsumedResource])->dict[str,Any]:
        # Caller selects policy via installed default. No coefficient exists without a policy.
        if not self.cost_policies: raise AccountingError("no cost-unit policy registered")
        policy=sorted(self.cost_policies.values(), key=lambda p:(p.effective_at,p.policy_id), reverse=True)[0]
        raw=0.0; normalized=0.0
        for c in consumed:
            coeff=float(policy.resource_coefficients.get(c.resource_kind,0.0)); norm=float(policy.normalization_factors.get(c.resource_kind,1.0))
            raw += c.amount*coeff; normalized += (c.amount*coeff)/norm
        return {"raw_cost_units":raw,"normalized_cost_units":normalized,"financial_cost_units":None,"currency":None,"conversion_policy_ref":None,"formula":policy.formula,"cost_unit_policy_ref":policy.policy_id}

    def accounting_summary(self, scope:str, window:tuple[str,str], *, tenant_id:str, context:Any)->dict[str,Any]:
        self._require_context(context,tenant_id); start,end=window; totals=defaultdict(float)
        for rec in self.accounting:
            if rec.tenant_id!=tenant_id or rec.period_end<start or rec.period_start>end: continue
            if scope not in {"tenant",rec.subject.get('ref')}: continue
            for c in rec.consumed: totals[c.resource_kind]+=c.amount
        return {"tenant_id":tenant_id,"scope":scope,"window":{"start":start,"end":end},"totals":dict(totals),"record_count":sum(1 for r in self.accounting if r.tenant_id==tenant_id)}

    def query_accounting(self, *, context:Any, tenant_id:str, subject_ref:str|None=None)->list[AccountingRecord]:
        self._require_context(context,tenant_id)
        return [r for r in self.accounting if r.tenant_id==tenant_id and (subject_ref is None or r.subject.get('ref')==subject_ref)]

    def inspect_queue(self, scope:str, *, context:Any, tenant_id:str)->QueueState:
        self._require_context(context,tenant_id); queued=[r for r in self.queue.values() if r.tenant_id==tenant_id];
        if not queued: raise PolicyDenied("no queued requests for tenant")
        policy=self._find_policy(queued[0])
        ordered=self._ordered(tenant_id,policy); ids=tuple(r.request_id for r in ordered)
        return QueueState(scope,ids,len(ids),_utc(),hashlib.sha256(canonical_bytes(ids)).hexdigest())

    def inspect_fairness_state(self, dimension:str, *, context:Any, tenant_id:str)->FairnessReport:
        self._require_context(context,tenant_id); p=next((p for p in self.policies.values() if p.tenant_id in {None,tenant_id}),None)
        if p is None: raise PolicyDenied("no scheduling policy")
        subjects=defaultdict(float)
        for (t,subject),value in self.consumed.items():
            if t==tenant_id: subjects[subject]+=value
        total=sum(subjects.values()) or 1.0; shares={k:v/total for k,v in subjects.items()}
        report=FairnessReport(_uuid(),tenant_id,dimension,p.fairness.method,shares,{k:max(0.0,1.0/len(subjects)-v) for k,v in shares.items()},tuple(),_utc(),hashlib.sha256(canonical_bytes(shares)).hexdigest())
        return report.sign(self.signing_key)

    def compute_share(self, requester_ref:str, window:tuple[str,str], *, context:Any, tenant_id:str)->float:
        self._require_context(context,tenant_id); totals=defaultdict(float)
        for rec in self.accounting:
            if rec.tenant_id==tenant_id and rec.period_start<=window[1] and rec.period_end>=window[0]: totals[rec.subject.get('ref','')]+=sum(c.amount for c in rec.consumed)
        total=sum(totals.values()); return 0.0 if total<=0 else totals.get(requester_ref,0.0)/total

    def escalate_starvation(self, requester_ref:str, *, reason:str, context:Any, tenant_id:str)->EscalationRecord:
        self._require_context(context,tenant_id); r=next((r for r in self.queue.values() if r.tenant_id==tenant_id and r.requester.ref==requester_ref),None)
        if not r: raise KeyError(requester_ref)
        p=self._find_policy(r); idx=PRIORITY_CLASSES.index(r.priority_class); target=PRIORITY_CLASSES[max(0,idx-1)]
        esc=EscalationRecord(_uuid(),tenant_id,requester_ref,reason,r.priority_class,target,_utc()); esc=esc.sign(self.signing_key); self._emit('StarvationEscalated',esc.body(),tenant_id,correlation_id=r.request_id); return esc

    def estimate_vs_actual(self, subject_ref:str, window:tuple[str,str], *, context:Any, tenant_id:str)->ReconciliationReport:
        self._require_context(context,tenant_id); estimates=defaultdict(float); actuals=defaultdict(float)
        for rec in self.accounting:
            if rec.tenant_id!=tenant_id or rec.subject.get('ref')!=subject_ref or rec.period_start>window[1] or rec.period_end<window[0]: continue
            for c in rec.consumed:
                if c.measured_by=='estimated': estimates[c.resource_kind]+=c.amount
                else: actuals[c.resource_kind]+=c.amount
        keys=set(estimates)|set(actuals); deltas={}; deviations=[]
        for k in keys:
            e=estimates.get(k,0.0); a=actuals.get(k,0.0); delta=0.0 if e==0 and a==0 else (abs(a-e)/max(abs(e),1e-9))*100.0; deltas[k]=delta
            if delta>self.deviation_threshold_pct: deviations.append(k); self._emit('EstimateDeviation',{'subject_ref':subject_ref,'resource_kind':k,'delta_pct':delta},tenant_id)
        report=ReconciliationReport(_uuid(),tenant_id,subject_ref,window[0],window[1],dict(estimates),dict(actuals),deltas,tuple(deviations),self.deviation_threshold_pct,_utc()); return report.sign(self.signing_key)

    def convert_cost(self, cost_units:float, target:str, *, context:Any, tenant_id:str)->dict[str,Any]:
        self._require_context(context,tenant_id); candidates=list(self.currency_policies.values())
        if not candidates: raise AccountingError("no currency conversion policy registered")
        p=sorted(candidates,key=lambda x:(x.effective_at,x.policy_id),reverse=True)[0]; rate=p.rates.get(target)
        if rate is None: raise AccountingError("target currency/unit not present in policy")
        return {"base":p.base_unit,"target":target,"amount":float(cost_units)*float(rate),"policy_ref":p.policy_id,"policy_version":p.policy_version}

    def reconcile_estimates(self, scope: str, window: tuple[str, str], *, context: Any, tenant_id: str) -> ReconciliationReport:
        """Public contract alias for estimate_vs_actual reconciliation."""
        return self.estimate_vs_actual(scope, window, context=context, tenant_id=tenant_id)

    def convert_accounting_record(self, record:AccountingRecord, target:str, *, context:Any)->AccountingRecord:
        cost=record.cost; converted=self.convert_cost(float(cost["normalized_cost_units"]),target,context=context,tenant_id=record.tenant_id)
        new_cost=dict(cost); new_cost.update({"financial_cost_units":converted["amount"],"currency":target,"conversion_policy_ref":converted["policy_ref"]})
        corrected=AccountingRecord(record.record_id,record.record_version+1,record.tenant_id,record.subject,record.parent_refs,record.consumed,new_cost,record.budget_ref,record.budget_ceiling,record.budget_utilization_pct,record.budget_exceeded,record.billed_to,record.billing_notes,record.attribution,record.period_start,record.period_end,record.computed_by,_utc(),record.registry_state_ref,record.integrity_hash,record.signature)
        return corrected.sign(self.signing_key)

    def chargeback_summary(self, *, context:Any, tenant_id:str, window:tuple[str,str])->dict[str,Any]:
        self._require_context(context,tenant_id); totals=defaultdict(float)
        for rec in self.accounting:
            if rec.tenant_id==tenant_id and rec.period_start<=window[1] and rec.period_end>=window[0]:
                totals[rec.billed_to or 'system'] += float(rec.cost.get('normalized_cost_units',0.0))
        return {"tenant_id":tenant_id,"window":{"start":window[0],"end":window[1]},"attribution":dict(totals)}

    def replay_digest(self, events:Sequence[Mapping[str,Any]], *, tenant_id:str, context:Any)->str:
        self._require_context(context,tenant_id)
        ordered=[]
        for event in events:
            if str(event.get('tenant_id','default'))!=tenant_id: continue
            ordered.append({"event_type":event.get('event_type'),"payload":event.get('payload',{}),"correlation_id":event.get('correlation_id'),"causation_id":event.get('causation_id')})
        digest=hashlib.sha256(canonical_bytes(ordered)).hexdigest(); return digest

    def verify_ledger(self)->bool:
        # Verify all durable accounting/decision signatures and internal chain links.
        for kind in ('decisions','accounting'):
            prev={}
            for row in self.ledger.load(kind):
                _verify_signed(row,self.public_key)
                tenant=str(row.get('tenant_id'))
                expected=prev.get(tenant)
                if row.get('chain_prev_hash')!=expected: return False
                prev[tenant]=str(row.get('integrity_hash'))
        return True

    def get_request(self, request_id:str, *, context:Any, tenant_id:str)->ResourceRequest:
        self._require_context(context,tenant_id); r=self.requests[request_id]
        if r.tenant_id!=tenant_id: raise TenantIsolationError("cross-tenant request access denied")
        return r

    def get_decision(self, decision_id:str, *, context:Any, tenant_id:str)->AllocationDecision:
        self._require_context(context,tenant_id); d=self.decisions[decision_id]
        if d.tenant_id!=tenant_id: raise TenantIsolationError("cross-tenant decision access denied")
        d.verify(self.public_key); return d

    def withdraw_request(self, request_id: str, *, reason: str, context: Any, tenant_id: str) -> None:
        self._require_context(context, tenant_id)
        request = self.get_request(request_id, context=context, tenant_id=tenant_id)
        self.queue.pop(request_id, None)
        self._emit("RequestWithdrawn", {"request_id": request_id, "reason": reason}, tenant_id, correlation_id=request_id)

    def complete_allocation(self, decision_id: str, accounting_ref: str, *, context: Any, tenant_id: str) -> AllocationDecision:
        d = self.get_decision(decision_id, context=context, tenant_id=tenant_id)
        self._emit("AllocationCompleted", {"decision_id": decision_id, "accounting_ref": accounting_ref}, tenant_id, correlation_id=d.request_ref, causation_id=decision_id)
        return d

    def get_policy(self, policy_id: str, *, context: Any, tenant_id: str) -> SchedulingPolicy:
        self._require_context(context, tenant_id)
        p = self.policies[policy_id]
        if p.tenant_id not in {None, tenant_id}: raise TenantIsolationError("cross-tenant policy access denied")
        p.verify(self.public_key); return p

    def list_policies(self, *, context: Any, tenant_id: str) -> list[SchedulingPolicy]:
        self._require_context(context, tenant_id)
        return [p for p in self.policies.values() if p.tenant_id in {None, tenant_id}]

    def get_quota(self, quota_id: str, *, context: Any, tenant_id: str) -> Quota:
        self._require_context(context, tenant_id)
        q = self.quotas[quota_id]
        if q.scope == "tenant" and q.scope_ref != tenant_id:
            raise TenantIsolationError("cross-tenant quota access denied")
        if q.scope != "tenant" and q.scope_ref != tenant_id and not q.scope_ref.startswith(tenant_id + ":"):
            raise TenantIsolationError("cross-tenant quota access denied")
        q.verify(self.public_key)
        return q

    def list_quotas(self, *, context: Any, tenant_id: str) -> list[Quota]:
        self._require_context(context, tenant_id)
        return [q for q in self.quotas.values() if q.scope == "tenant" and q.scope_ref == tenant_id]

    def reorder_queue(self, scope: str, rule: str, *, context: Any, tenant_id: str) -> QueueState:
        self._require_context(context, tenant_id)
        if rule not in {"policy", "deterministic_priority"}: raise PolicyDenied("arbitrary queue reordering is refused")
        return self.inspect_queue(scope, context=context, tenant_id=tenant_id)

    def drain_queue(self, scope: str, reason: str, *, context: Any, tenant_id: str) -> int:
        self._require_context(context, tenant_id)
        ids=[rid for rid,r in self.queue.items() if r.tenant_id==tenant_id]
        for rid in ids: self.queue.pop(rid,None); self._emit("DecisionDenied", {"request_id":rid,"reason":reason,"queue_scope":scope}, tenant_id)
        return len(ids)

    def accounting_source(self, *, subject_ref: str, consumed: Sequence[ConsumedResource], source: str, context: Any, tenant_id: str, **kwargs: Any) -> AccountingRecord:
        allowed={"harness","model_fabric","tool_fabric","host","estimated"}
        if source not in allowed: raise AccountingError("unsupported accounting source")
        if any(c.measured_by != source for c in consumed): raise AccountingError("measurement source mismatch")
        return self.record_consumption(subject_ref, consumed, context=context, tenant_id=tenant_id, **kwargs)

    def record_harness_accounting(self, accounting: Any, *, context: Any, tenant_id: str, budget_ref: str | None = None, budget_ceiling: Mapping[str,float] | None = None) -> AccountingRecord:
        data = accounting.to_dict() if hasattr(accounting, "to_dict") else dict(accounting)
        now = _utc()
        consumed = [
            ConsumedResource("wall_seconds", float(data.get("wall_seconds",0.0)), "seconds", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("wall_seconds",0.0)) else None,
            ConsumedResource("cpu_seconds", float(data.get("cpu_seconds",0.0)), "seconds", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("cpu_seconds",0.0)) else None,
            ConsumedResource("gpu_seconds", float(data.get("gpu_seconds",0.0)), "seconds", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("gpu_seconds",0.0)) else None,
            ConsumedResource("vram_mb_seconds", float(data.get("vram_peak_mb",0.0))*float(data.get("wall_seconds",0.0)), "MB-seconds", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("vram_peak_mb",0.0)) else None,
            ConsumedResource("ram_mb_seconds", float(data.get("ram_peak_mb",0.0))*float(data.get("wall_seconds",0.0)), "MB-seconds", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("ram_peak_mb",0.0)) else None,
            ConsumedResource("network_bytes_in", float(data.get("network_bytes_in",0.0)), "bytes", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("network_bytes_in",0.0)) else None,
            ConsumedResource("network_bytes_out", float(data.get("network_bytes_out",0.0)), "bytes", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("network_bytes_out",0.0)) else None,
            ConsumedResource("disk_bytes_write", float(data.get("disk_bytes_written",0.0)), "bytes", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("disk_bytes_written",0.0)) else None,
            ConsumedResource("subprocesses", float(data.get("subprocess_count",0.0)), "count", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("subprocess_count",0.0)) else None,
            ConsumedResource("tool_calls", float(data.get("tool_calls",0.0)), "calls", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("tool_calls",0.0)) else None,
            ConsumedResource("api_calls", float(data.get("api_calls",0.0)), "calls", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("api_calls",0.0)) else None,
            ConsumedResource("tokens_in", float(data.get("tokens_in",0.0)), "tokens", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("tokens_in",0.0)) else None,
            ConsumedResource("tokens_out", float(data.get("tokens_out",0.0)), "tokens", now, now, "harness", f"harness://execution/{data.get('execution_id','unknown')}") if float(data.get("tokens_out",0.0)) else None,
            ConsumedResource("energy_joules_estimate", float(data.get("energy_joules_estimate") or 0.0), "joules", now, now, "estimated", f"harness://execution/{data.get('execution_id','unknown')}/energy") if data.get("energy_joules_estimate") is not None else None,
        ]
        return self.record_consumption(data.get("execution_id", "unknown"), tuple(x for x in consumed if x is not None), context=context, tenant_id=tenant_id, budget_ref=budget_ref, budget_ceiling=budget_ceiling, parent_refs=(str(data.get("execution_id","unknown")),), billed_to=tenant_id)

    def set_measurement_policy(self, deviation_threshold_pct: float, *, context: Any, tenant_id: str) -> None:
        self._require_context(context, tenant_id)
        if deviation_threshold_pct < 0: raise ConfigurationError("deviation threshold must be >= 0")
        self.deviation_threshold_pct=float(deviation_threshold_pct)

    # Convenience aliases matching the public phase contract.
    def query_decisions(self, *, tenant_id: str, context: Any) -> list[AllocationDecision]:
        self._require_context(context, tenant_id)
        return [d for d in self.decisions.values() if d.tenant_id == tenant_id]

        return {"base":p.base_unit,"target":target,"amount":float(cost_units)*float(rate),"policy_ref":p.policy_id,"policy_version":p.policy_version}

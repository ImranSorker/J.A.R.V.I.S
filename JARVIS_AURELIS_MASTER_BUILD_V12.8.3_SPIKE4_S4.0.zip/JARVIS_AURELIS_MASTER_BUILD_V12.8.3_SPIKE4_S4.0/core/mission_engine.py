"""Long-running mission management."""
from __future__ import annotations
import uuid
import time
from typing import Any, Dict, List


class Mission:
    def __init__(self, description: str):
        self.mission_id = str(uuid.uuid4())[:8]
        self.description = description
        self.status = "created"
        self.created_at = time.time()
        self.tasks: List[dict[str, Any]] = []


class MissionEngine:
    def __init__(self):
        self._missions: Dict[str, Mission] = {}

    def create(self, description: str) -> Mission:
        m = Mission(description)
        self._missions[m.mission_id] = m
        return m

    def get(self, mission_id: str) -> Mission | None:
        return self._missions.get(mission_id)

    def list_missions(self) -> List[Mission]:
        return list(self._missions.values())



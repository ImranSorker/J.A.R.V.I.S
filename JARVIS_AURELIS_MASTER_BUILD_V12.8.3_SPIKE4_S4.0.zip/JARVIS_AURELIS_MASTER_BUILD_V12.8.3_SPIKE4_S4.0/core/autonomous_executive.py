"""Executive control plane for proactive, persistent JARVIS autonomy."""
from __future__ import annotations

import heapq
import json
import logging
import os
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from core.autonomy import AutonomyBudget, AutonomyEngine, AutonomyLevel
from core.device_gateway import DeviceGateway
from core.model_intelligence import ModelIntelligence
from core.recovery_swarm import RecoverySwarm
from core.autonomy_fabric import AutonomyFabric
from core.contracts.autonomy import MissionStepSpec
from core.world_model import WorldEntity, WorldModel

logger = logging.getLogger("jarvis.executive")


@dataclass(order=True)
class GoalRecord:
    """Persistent executive goal."""

    priority: int
    created_at: float
    goal_id: str = field(compare=False)
    description: str = field(compare=False)
    status: str = field(default="queued", compare=False)
    owner: str = field(default="jarvis", compare=False)
    mission_id: str | None = field(default=None, compare=False)
    metadata: dict[str, Any] = field(default_factory=dict, compare=False)


class AutonomousExecutive:
    """Persistent executive brain coordinating goals, world state, devices and recovery."""

    def __init__(
        self,
        autonomy: AutonomyEngine,
        world_model: WorldModel,
        device_gateway: DeviceGateway,
        model_intelligence: ModelIntelligence,
        recovery_swarm: RecoverySwarm,
        mission_runner: Callable[[str, Optional[str]], Any],
        *,
        max_goals: int = 1000,
        max_parallel_missions: int = 2,
        state_path: str = "data/autonomous_executive.json",
        knowledge_graph: Any | None = None,
        fabric: AutonomyFabric | None = None,
        outcome_callback: Callable[..., Any] | None = None,
        planner: Any | None = None,
    ) -> None:
        self.autonomy = autonomy
        self.world_model = world_model
        self.device_gateway = device_gateway
        self.model_intelligence = model_intelligence
        self.recovery_swarm = recovery_swarm
        self._mission_runner = mission_runner
        self.max_goals = max(10, min(int(max_goals), 10_000))
        self.max_parallel_missions = max(1, min(int(max_parallel_missions), 32))
        self._goals: dict[str, GoalRecord] = {}
        self._queue: list[GoalRecord] = []
        self._active = 0
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._worker: threading.Thread | None = None
        self._cooldowns: dict[str, float] = {}
        self._min_idle_seconds = 30.0
        self.state_path = str(state_path)
        self.knowledge_graph = knowledge_graph
        self.fabric = fabric
        self._outcome_callback = outcome_callback
        self._planner = planner
        self._load_state()


    def _save_state(self) -> None:
        """Atomically persist queued/completed executive goals."""
        with self._lock:
            payload = [
                {"goal_id": g.goal_id, "description": g.description, "priority": g.priority, "created_at": g.created_at, "status": ("queued" if g.status == "running" else g.status), "owner": g.owner, "mission_id": None if g.status != "running" else g.mission_id, "metadata": g.metadata}
                for g in self._goals.values()
            ]
        path = os.path.abspath(self.state_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".executive.", suffix=".tmp", dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, sort_keys=True, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, path)
        finally:
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                logger.debug("executive_temp_file_already_removed", extra={"path": tmp})

    def _load_state(self) -> None:
        """Restore persisted goal state, converting interrupted work back to queued."""
        path = os.path.abspath(self.state_path)
        if not os.path.isfile(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as handle:
                rows = json.load(handle)
            if not isinstance(rows, list):
                raise ValueError("executive state must be a list")
            with self._lock:
                for row in rows[-self.max_goals:]:
                    if not isinstance(row, dict) or not row.get("goal_id") or not row.get("description"):
                        continue
                    status = str(row.get("status", "queued"))
                    if status == "running":
                        status = "queued"
                    goal = GoalRecord(
                        priority=max(0, min(100, int(row.get("priority", 5)))),
                        created_at=float(row.get("created_at", time.time())),
                        goal_id=str(row["goal_id"]), description=str(row["description"]),
                        status=status, owner=str(row.get("owner") or "jarvis"),
                        mission_id=None, metadata=dict(row.get("metadata") or {}),
                    )
                    self._goals[goal.goal_id] = goal
                    if goal.status == "queued":
                        heapq.heappush(self._queue, GoalRecord(-goal.priority, goal.created_at, goal.goal_id, goal.description, goal.status, goal.owner, goal.mission_id, goal.metadata))
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            logger.exception("executive_state_restore_failed")

    def active_goal_count(self) -> int:
        """Count queued/running goals from authoritative executive state."""
        with self._lock:
            return sum(1 for goal in self._goals.values() if goal.status in {"queued", "running"})

    def set_planner(self, planner: Any | None) -> None:
        with self._lock:
            self._planner = planner

    def set_knowledge_graph(self, knowledge_graph: Any | None) -> None:
        """Attach the shared knowledge graph without replacing executive state."""
        self.knowledge_graph = knowledge_graph


    def start(self) -> None:
        """Start the bounded executive worker."""
        with self._lock:
            if self._worker and self._worker.is_alive():
                return
            self._stop.clear()
            self._worker = threading.Thread(target=self._loop, name="jarvis-executive", daemon=True)
            self._worker.start()

    def stop(self, timeout: float = 5.0) -> None:
        """Stop the executive worker."""
        self._stop.set()
        worker = self._worker
        if worker:
            worker.join(max(0.1, float(timeout)))

    def submit_goal(self, description: str, *, priority: int = 5, owner: str = "jarvis", metadata: Optional[dict[str, Any]] = None) -> str:
        """Queue a persistent goal with duplicate suppression."""
        description = str(description or "").strip()
        if not description:
            raise ValueError("goal description is required")
        with self._lock:
            if any(g.description == description and g.status in {"queued", "running"} for g in self._goals.values()):
                existing = next(g.goal_id for g in self._goals.values() if g.description == description and g.status in {"queued", "running"})
                return existing
            if len(self._goals) >= self.max_goals:
                raise RuntimeError("executive goal capacity reached")
            now = time.time()
            goal = GoalRecord(
                priority=max(0, min(100, int(priority))),
                created_at=now,
                goal_id=f"goal_{uuid.uuid4().hex[:12]}",
                description=description,
                owner=owner or "jarvis",
                metadata=dict(metadata or {}),
            )
            self._goals[goal.goal_id] = goal
            heapq.heappush(self._queue, GoalRecord(-goal.priority, goal.created_at, goal.goal_id, goal.description, goal.status, goal.owner, goal.mission_id, goal.metadata))
        if self.fabric is not None:
            try:
                canonical = self.fabric.create_goal(
                    description,
                    goal_id=goal.goal_id,
                    priority=max(1, min(10, int(priority))),
                    owner=goal.owner,
                    constraints=dict(goal.metadata),
                    capabilities=("mission.execute",),
                    success_criteria=("AION plan executed and verified",),
                )
                goal.priority = -canonical.priority
            except Exception:
                with self._lock:
                    self._goals.pop(goal.goal_id, None)
                    self._queue[:] = [item for item in self._queue if item.goal_id != goal.goal_id]
                raise
        self.world_model.record_event("goal.submitted", {"goal_id": goal.goal_id, "description": description, "priority": priority}, source="executive")
        if self.knowledge_graph is not None:
            try:
                self.knowledge_graph.add_node(goal.goal_id, {"description": description, "owner": goal.owner, "priority": goal.priority, "status": goal.status})
            except Exception:
                logger.debug("executive_knowledge_graph_update_failed", exc_info=True)
        self._save_state()
        return goal.goal_id

    def observe(self, entity: WorldEntity) -> None:
        """Add an external observation to the world model."""
        self.world_model.upsert_entity(entity)
        self.world_model.record_event("world.observed", entity.to_dict(), source=entity.source)

    def trigger(self, description: str, *, priority: int = 80, cooldown_seconds: float = 300.0, source: str = "event") -> str | None:
        """Create a proactive goal when its trigger is outside the cooldown window."""
        now = time.monotonic()
        key = f"{source}:{description.strip()}"
        with self._lock:
            if now < self._cooldowns.get(key, 0.0):
                return None
            self._cooldowns[key] = now + max(0.0, float(cooldown_seconds))
        return self.submit_goal(description, priority=priority, metadata={"source": source})

    def _pop_next(self) -> GoalRecord | None:
        with self._lock:
            while self._queue:
                queued = heapq.heappop(self._queue)
                current = self._goals.get(queued.goal_id)
                if current and current.status == "queued":
                    return current
            return None

    def _run_goal(self, goal: GoalRecord) -> None:
        with self._lock:
            goal.status = "running"
            self._active += 1
        self._save_state()
        mission_id: str | None = None
        try:
            if self.fabric is not None:
                canonical = self.fabric.goals.get(goal.goal_id)
                if canonical is None:
                    raise RuntimeError(f"canonical goal missing: {goal.goal_id}")
                plan_payload = goal.metadata.get("plan") if isinstance(goal.metadata, dict) else None
                envelope = {"plan": plan_payload or {}, "canonical_goal_id": goal.goal_id}
                # AION/MissionService owns exactly one durable DAG mission.
                result = self._mission_runner(goal.description, None, envelope)
                if not isinstance(result, dict) or not result.get("ok"):
                    error = result.get("error", "canonical mission failed") if isinstance(result, dict) else result
                    raise RuntimeError(str(error))
                mission_id = str(result.get("mission_id") or "") or None
                goal.mission_id = mission_id
                goal.status = "completed"
                self._save_state()
                self.world_model.record_event("mission.completed", {"goal_id": goal.goal_id, "mission_id": mission_id}, source="executive")
                self._emit_outcome(goal, "completed", {"mission_id": mission_id, "verified": True})
            else:
                mission = self.autonomy.start_mission(
                    goal.description,
                    level=AutonomyLevel.BOUNDED,
                    budget=AutonomyBudget(**self.autonomy.default_budget.__dict__),
                    owner=goal.owner,
                    metadata={"goal_id": goal.goal_id, **goal.metadata},
                )
                mission_id = mission.mission_id
                goal.mission_id = mission_id
                self.world_model.record_event("mission.started", {"goal_id": goal.goal_id, "mission_id": mission_id}, source="executive")
                plan_payload = goal.metadata.get("plan") if isinstance(goal.metadata, dict) else None
                try:
                    self._mission_runner(goal.description, mission_id, plan_payload)
                except TypeError as exc:
                    try:
                        self._mission_runner(goal.description, mission_id)
                    except TypeError:
                        raise exc
                self.autonomy.finish_mission(mission.mission_id, True)
                goal.status = "completed"
                self._save_state()
                self.world_model.record_event("mission.completed", {"goal_id": goal.goal_id, "mission_id": mission_id}, source="executive")
                self._emit_outcome(goal, "completed", {"mission_id": mission_id, "verified": True})
        except Exception as exc:
            goal.status = "failed"
            self._save_state()
            if mission_id is not None and self.fabric is None:
                self.autonomy.finish_mission(mission_id, False, error=str(exc))
            logger.exception("executive_goal_failed", extra={"goal_id": goal.goal_id, "error": str(exc)})
            self.world_model.record_event("mission.failed", {"goal_id": goal.goal_id, "error": str(exc)}, source="executive")
            self._emit_outcome(goal, "failed", {"mission_id": mission_id, "verified": False, "error_type": type(exc).__name__})
        finally:
            with self._lock:
                self._active = max(0, self._active - 1)

    def _execute_planned_step(self, goal: GoalRecord, mission_id: str, step: MissionStepSpec) -> Any:
        """Execute the exact plan produced at AION admission."""
        metadata = dict(step.metadata or {})
        plan = metadata.get("plan")
        try:
            # Keep the outer executive mission distinct from the concrete
            # mission-service execution record when both share the same fabric.
            concrete_id = f"{mission_id}:execution" if mission_id else None
            return self._mission_runner(goal.description, concrete_id, plan)
        except TypeError as exc:
            # Preserve compatibility with legacy mission runners only when the
            # signature genuinely accepts two positional arguments.
            try:
                return self._mission_runner(goal.description, mission_id)
            except TypeError:
                raise exc

    def _emit_outcome(self, goal: GoalRecord, status: str, evidence: dict[str, Any]) -> None:
        callback = self._outcome_callback
        if callback is None:
            return
        try:
            callback(goal_id=goal.goal_id, status=status, evidence=evidence)
        except Exception:
            logger.exception("executive_outcome_callback_failed", extra={"goal_id": goal.goal_id, "status": status})

    def _loop(self) -> None:
        while not self._stop.wait(self._min_idle_seconds):
            with self._lock:
                if self._active >= self.max_parallel_missions:
                    continue
            goal = self._pop_next()
            if goal is None:
                continue
            threading.Thread(target=self._run_goal, args=(goal,), name=f"jarvis-goal-{goal.goal_id}", daemon=True).start()

    def list_goals(self, limit: int = 100, owner: str | None = None) -> list[dict[str, Any]]:
        """Return recent executive goals."""
        limit = max(1, min(int(limit), 1000))
        with self._lock:
            goals = [g for g in sorted(self._goals.values(), key=lambda g: g.created_at, reverse=True) if owner is None or g.owner == owner][:limit]
            return [
                {
                    "goal_id": g.goal_id,
                    "description": g.description,
                    "priority": -g.priority if g.priority < 0 else g.priority,
                    "status": g.status,
                    "owner": g.owner,
                    "mission_id": g.mission_id,
                    "created_at": g.created_at,
                    "metadata": dict(g.metadata),
                }
                for g in goals
            ]

    def snapshot(self) -> dict[str, Any]:
        """Return executive state for telemetry/UI."""
        with self._lock:
            return {
                "active": self._active,
                "queued": sum(g.status == "queued" for g in self._goals.values()),
                "running": sum(g.status == "running" for g in self._goals.values()),
                "completed": sum(g.status == "completed" for g in self._goals.values()),
                "failed": sum(g.status == "failed" for g in self._goals.values()),
                "max_parallel_missions": self.max_parallel_missions,
                "world": self.world_model.snapshot(),
                "devices": self.device_gateway.health(),
                "models": self.model_intelligence.snapshot(),
                "recovery": self.recovery_swarm.stats(),
            }



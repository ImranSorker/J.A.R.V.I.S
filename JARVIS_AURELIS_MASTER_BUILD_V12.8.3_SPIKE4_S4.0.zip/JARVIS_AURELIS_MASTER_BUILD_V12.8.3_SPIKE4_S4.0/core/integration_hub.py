"""System Integration Hub — composition root interconnecting V12.8.0 modules.

The V12.8.0 release introduced seven standalone capability modules
(identity, cancellation, backend health, content trust, network policy,
execution broker, plugin isolation). This hub is the single composition
root that connects them into one coherent security-and-reliability
fabric, enforcing the cross-module invariants:

  - Every operation is attributed to an authenticated Principal.
  - Capability checks (identity) gate network egress, execution, and
    plugin calls — authorization is never derived from content.
  - All external content is taint-processed (content trust) before it
    reaches a caller, and tool output is re-checked so retrieved text
    can never authorize itself.
  - Cancellation tokens propagate through long operations and are
    cancelled as a group on shutdown.
  - Backend health state is recorded centrally for routing decisions.

The hub holds no business logic of its own; it composes and enforces.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from core.backend_health import BackendHealthRegistry, HealthProbeResult
from core.cancellation_token import CancellationTokenRegistry, CancellationTokenSource
from core.content_trust import ContentSource, ContentTrustEngine, TaintedContent, TrustLevel
from core.execution_broker import ExecutionBroker, ExecutionRequest, ExecutionResult
from core.identity import IdentityManager, Principal, PrincipalType
from core.network_policy import NetworkPolicy, SSRFValidator, SafeHTTPClient
from core.plugin_isolation import PluginIsolationManager, PluginManifest

logger = logging.getLogger("jarvis.integration_hub")

NETWORK_CAPABILITY = "network.connect"
EXECUTE_CAPABILITY = "process.spawn"


class AuthorizationError(Exception):
    """Raised when a principal lacks a required capability."""


class SystemIntegrationHub:
    """Composes identity, cancellation, trust, network, health, execution,
    and plugin isolation into one governed boundary."""

    def __init__(
        self,
        network_policy: Optional[NetworkPolicy] = None,
        execution_broker: Optional[ExecutionBroker] = None,
        plugin_base_dir: str = "data/plugins",
    ) -> None:
        self.identity = IdentityManager()
        self.cancellation = CancellationTokenRegistry()
        self.content_trust = ContentTrustEngine()
        self.network_policy = network_policy or NetworkPolicy()
        self._ssrf = SSRFValidator()
        self._http = SafeHTTPClient(self.network_policy)
        self.backend_health = BackendHealthRegistry()
        self.execution_broker = execution_broker  # None = execution disabled (fail closed)
        self.plugins = PluginIsolationManager(base_dir=plugin_base_dir)
        self._shutdown = False

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    def authenticate(self, name: str, principal_type: PrincipalType,
                     capabilities: Optional[List[str]] = None,
                     workspace: str = "default") -> Principal:
        """Register a principal for the given actor."""
        return self.identity.create_principal(
            name=name, type=principal_type,
            capabilities=capabilities or [], workspace=workspace,
        )

    def require_capability(self, principal: Principal, capability: str) -> None:
        """Fail closed unless the principal holds the capability."""
        if not principal.has_capability(capability):
            logger.warning("authorization_denied", extra={
                "principal": principal.id, "capability": capability})
            raise AuthorizationError(
                f"principal '{principal.name}' lacks capability '{capability}'")

    # ------------------------------------------------------------------
    # Network egress (SSRF-guarded)
    # ------------------------------------------------------------------

    def fetch_url(self, principal: Principal, url: str,
                  timeout: Optional[float] = None) -> Dict[str, Any]:
        """Fetch a URL only after identity + SSRF policy checks; response
        content is taint-processed before being returned."""
        self._ensure_live()
        self.require_capability(principal, NETWORK_CAPABILITY)
        validation = self._ssrf.validate_url(url, self.network_policy)
        if not validation["ok"]:
            return {"ok": False, "error": validation["error"], "trust_level": TrustLevel.REJECTED.value}
        response = self._http.request("GET", url, timeout=timeout)
        if not response.get("ok"):
            return {"ok": False, "error": response.get("error", "request failed"),
                    "trust_level": TrustLevel.REJECTED.value}
        tainted = self.content_trust.process(
            str(response.get("content", "")),
            source=ContentSource.WEB_PAGE, uri=url, owner=principal.name,
        )
        return {
            "ok": tainted.trust_level != TrustLevel.REJECTED,
            "status_code": response.get("status_code"),
            "content": tainted.content,
            "trust_level": tainted.trust_level.value,
            "threats": [t.category for t in tainted.threats],
            "safe_context": tainted.to_context_string(),
        }

    # ------------------------------------------------------------------
    # Execution (brokered, authorized, cancellable)
    # ------------------------------------------------------------------

    def submit_execution(self, principal: Principal, request: ExecutionRequest,
                         timeout: Optional[float] = None) -> Dict[str, Any]:
        """Route an execution through identity check + broker + output
        trust screening. Fails closed when no broker is configured."""
        self._ensure_live()
        self.require_capability(principal, EXECUTE_CAPABILITY)
        if self.execution_broker is None:
            return {"ok": False, "error": "execution broker not configured",
                    "trust_level": TrustLevel.REJECTED.value}
        source = self.cancellation.create(timeout=timeout)
        try:
            result: ExecutionResult = self.execution_broker.execute(request)
        finally:
            source.cancel("execution completed")
        screened = self.content_trust.process(
            f"{result.stdout}\n{result.stderr}",
            source=ContentSource.TOOL_RESULT, owner=principal.name,
        )
        return {
            "ok": result.ok,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "execution_time_ms": result.execution_time_ms,
            "trust_level": screened.trust_level.value,
            "output_threats": [t.category for t in screened.threats],
            "error": result.error,
        }

    # ------------------------------------------------------------------
    # Plugin isolation passthrough (capability-gated)
    # ------------------------------------------------------------------

    def start_plugin(self, principal: Principal, manifest: PluginManifest) -> bool:
        self._ensure_live()
        self.require_capability(principal, "plugin.load")
        return self.plugins.create_sandbox(manifest).start()

    def call_plugin(self, principal: Principal, name: str, method: str,
                    params: Dict[str, Any]) -> Dict[str, Any]:
        self._ensure_live()
        self.require_capability(principal, "plugin.load")
        return self.plugins.call_plugin(name, method, params)

    # ------------------------------------------------------------------
    # Cancellation + backend health
    # ------------------------------------------------------------------

    def create_cancellation_source(self, timeout: Optional[float] = None) -> CancellationTokenSource:
        self._ensure_live()
        return self.cancellation.create(timeout=timeout)

    def record_backend_probe(self, result: HealthProbeResult) -> None:
        if self.backend_health.get(result.backend_name) is None:
            self.backend_health.register(result.backend_name)
        self.backend_health.record_probe(result.backend_name, result)

    def healthy_backends(self) -> List[str]:
        return self.backend_health.healthy_backends()

    # ------------------------------------------------------------------
    # Untrusted content intake (single front door)
    # ------------------------------------------------------------------

    def intake_content(self, content: str, source: ContentSource,
                       principal: Optional[Principal] = None,
                       uri: Optional[str] = None) -> TaintedContent:
        """Process any external content through the trust engine with
        provenance attributed to the acting principal."""
        self._ensure_live()
        owner = principal.name if principal else "system"
        return self.content_trust.process(content, source=source, uri=uri, owner=owner)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def health(self) -> Dict[str, Any]:
        """Non-sensitive component status snapshot."""
        return {
            "status": "shutdown" if self._shutdown else "operational",
            "identity_principals": len(getattr(self.identity, "_principals", {}) or {}),
            "active_cancellations": len(getattr(self.cancellation, "_sources", {}) or {}),
            "backend_health": self.backend_health.all_stats(),
            "plugins": self.plugins.list_plugins(),
            "execution_broker_configured": self.execution_broker is not None,
        }

    def shutdown(self) -> None:
        """Deterministic cleanup: cancel all operations, stop plugins,
        shut down the broker. Idempotent."""
        if self._shutdown:
            return
        self._shutdown = True
        cancelled = self.cancellation.cancel_all("hub shutdown")
        stopped = self.plugins.stop_all(timeout=5.0)
        if self.execution_broker is not None:
            self.execution_broker.shutdown(timeout=5.0)
        logger.info("hub_shutdown", extra={"cancelled": cancelled, "plugins_stopped": stopped})

    def _ensure_live(self) -> None:
        if self._shutdown:
            raise RuntimeError("integration hub is shut down")



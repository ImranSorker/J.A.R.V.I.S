"""Durable, auditable contracts for autonomous missions."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from hashlib import sha256
import json
import time
from typing import Any, Mapping, Sequence


class MissionRisk(str, Enum):
    """Bounded mission risk classes."""

    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"
    L5 = "L5"


@dataclass(frozen=True, slots=True)
class MissionContract:
    """Defines exactly what an autonomous mission may do."""

    mission_id: str
    objective: str
    scope: tuple[str, ...] = ()
    allowed_capabilities: tuple[str, ...] = ()
    forbidden_capabilities: tuple[str, ...] = ()
    workspace_root: str = "data/workspace"
    max_steps: int = 100
    max_runtime_seconds: float = 3600.0
    max_network_requests: int = 0
    max_files_written: int = 0
    risk: MissionRisk = MissionRisk.L1
    require_approval_above: MissionRisk = MissionRisk.L2
    checkpoints: tuple[str, ...] = ()
    verification_criteria: tuple[str, ...] = ()
    rollback_required: bool = True
    created_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        """Validate safety invariants at construction time."""
        if not self.mission_id.strip() or not self.objective.strip():
            raise ValueError("mission_id and objective are required")
        if not 1 <= self.max_steps <= 100_000:
            raise ValueError("max_steps out of bounds")
        if not 1.0 <= self.max_runtime_seconds <= 86_400.0:
            raise ValueError("max_runtime_seconds out of bounds")
        for value in (self.max_network_requests, self.max_files_written):
            if not 0 <= value <= 1_000_000:
                raise ValueError("mission resource budget out of bounds")
        forbidden = set(self.forbidden_capabilities)
        if set(self.allowed_capabilities) & forbidden:
            raise ValueError("a capability cannot be both allowed and forbidden")

    def digest(self) -> str:
        """Return a stable SHA-256 contract digest."""
        payload = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return sha256(payload.encode("utf-8")).hexdigest()

    def permits(self, capability: str) -> bool:
        """Return whether a capability is permitted by this contract."""
        name = str(capability).strip()
        if not name or name in self.forbidden_capabilities:
            return False
        return "*" in self.allowed_capabilities or name in self.allowed_capabilities

    def to_dict(self) -> dict[str, Any]:
        """Return JSON-safe contract data."""
        data = asdict(self)
        data["risk"] = self.risk.value
        data["require_approval_above"] = self.require_approval_above.value
        return data

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "MissionContract":
        """Construct and validate a contract from JSON-like data."""
        return cls(
            mission_id=str(data["mission_id"]),
            objective=str(data["objective"]),
            scope=tuple(str(x) for x in data.get("scope", ())),
            allowed_capabilities=tuple(str(x) for x in data.get("allowed_capabilities", ())),
            forbidden_capabilities=tuple(str(x) for x in data.get("forbidden_capabilities", ())),
            workspace_root=str(data.get("workspace_root", "data/workspace")),
            max_steps=int(data.get("max_steps", 100)),
            max_runtime_seconds=float(data.get("max_runtime_seconds", 3600.0)),
            max_network_requests=int(data.get("max_network_requests", 0)),
            max_files_written=int(data.get("max_files_written", 0)),
            risk=MissionRisk(str(data.get("risk", MissionRisk.L1.value))),
            require_approval_above=MissionRisk(str(data.get("require_approval_above", MissionRisk.L2.value))),
            checkpoints=tuple(str(x) for x in data.get("checkpoints", ())),
            verification_criteria=tuple(str(x) for x in data.get("verification_criteria", ())),
            rollback_required=bool(data.get("rollback_required", True)),
            created_at=float(data.get("created_at", time.time())),
        )


class MissionContractValidator:
    """Validate mission requests before Mission Authority accepts them."""

    def validate(self, contract: MissionContract, requested_capabilities: Sequence[str]) -> tuple[bool, tuple[str, ...]]:
        """Return a deterministic validation result and reasons."""
        reasons: list[str] = []
        for capability in requested_capabilities:
            if not contract.permits(capability):
                reasons.append(f"capability_not_permitted:{capability}")
        if contract.risk.value > contract.require_approval_above.value:
            reasons.append("approval_required")
        return not reasons, tuple(reasons)



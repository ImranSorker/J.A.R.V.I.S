"""Proof-carrying assurance kernel for autonomous JARVIS actions."""
from __future__ import annotations

import hashlib
import json
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Mapping

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .kernel_12_8_0.contracts import CapabilityRequest
    from .kernel_12_8_0.execution import KernelExecutionAuthority
    from .kernel_12_8_0.capability_policy import CapabilityPolicy, Decision


@dataclass(frozen=True, slots=True)
class ActionProof:
    proof_id: str
    request_id: str
    capability: str
    risk: str
    decision_id: str
    approved: bool
    policy_digest: str
    created_at: float
    request_digest: str

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class AssuranceKernel:
    """Single auditable preflight authority for high-impact actions."""

    def __init__(self, policy: Any, execution: Any) -> None:
        self.policy = policy
        self.execution = execution
        self._lock = threading.RLock()
        self._proofs: dict[str, ActionProof] = {}

    def authorize(self, request: Any, *, approved: bool = False) -> tuple[Any, ActionProof | None]:
        decision = self.policy.evaluate(request, approved=approved)
        if not decision.allowed:
            return decision, None
        policy_material = {
            "capability": request.capability,
            "risk": request.risk,
            "principal": request.principal,
            "ttl_seconds": int(request.ttl_seconds),
        }
        request_digest = hashlib.sha256(json.dumps(policy_material, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        policy_digest = self.policy.digest()
        proof = ActionProof(
            proof_id=self._uuid7(),
            request_id=self._uuid7(),
            capability=request.capability,
            risk=request.risk,
            decision_id=decision.decision_id,
            approved=bool(approved),
            policy_digest=policy_digest,
            created_at=time.time(),
            request_digest=request_digest,
        )
        with self._lock:
            self._proofs[proof.proof_id] = proof
        return decision, proof

    @staticmethod
    def _uuid7() -> str:
        try:
            import uuid
            generator = getattr(uuid, "uuid7", None)
            if generator is not None:
                return str(generator())
        except Exception as exc:
            _ = exc
        import uuid
        return str(uuid.uuid4())

    def get_proof(self, proof_id: str) -> ActionProof:
        with self._lock:
            proof = self._proofs.get(str(proof_id))
        if proof is None:
            raise KeyError(proof_id)
        return proof

    def snapshot(self) -> list[dict[str, Any]]:
        with self._lock:
            return [asdict(item) | {"proof_digest": item.digest()} for item in list(self._proofs.values())[-1000:]]

"""Centralized risk/trust decision boundary for J.A.R.V.I.S."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Iterable, Mapping


class TrustDecision(StrEnum):
    """Normalized action decision."""

    ALLOW = "allow"
    ALLOW_WITH_LIMITS = "allow_with_limits"
    REQUIRE_APPROVAL = "require_approval"
    SANDBOX = "sandbox"
    DENY = "deny"


@dataclass(frozen=True, slots=True)
class TrustRequest:
    """Complete security context for one requested operation."""

    principal: str
    capability: str
    risk_score: float = 0.0
    external_content: bool = False
    destructive: bool = False
    authenticated: bool = False
    approved: bool = False
    sandbox_available: bool = True
    metadata: Mapping[str, str] | None = None


@dataclass(frozen=True, slots=True)
class TrustResult:
    """Deterministic trust decision with reasons."""

    decision: TrustDecision
    reasons: tuple[str, ...]
    bounded: bool


class TrustEngine:
    """Fail-closed trust policy shared by tools, agents, memory, and devices."""

    def __init__(self, *, max_allowed_risk: float = 0.35, sandbox_risk: float = 0.70) -> None:
        self.max_allowed_risk = min(1.0, max(0.0, float(max_allowed_risk)))
        self.sandbox_risk = min(1.0, max(self.max_allowed_risk, float(sandbox_risk)))

    def evaluate(self, request: TrustRequest, *, allowed_capabilities: Iterable[str] = ()) -> TrustResult:
        """Evaluate a request without performing any side effect."""
        cap = str(request.capability).strip()
        principal = str(request.principal).strip()
        reasons: list[str] = []
        allowed = set(str(item).strip() for item in allowed_capabilities)
        if not principal:
            reasons.append("missing_principal")
        if not cap:
            reasons.append("missing_capability")
        if allowed and "*" not in allowed and cap not in allowed:
            reasons.append("capability_not_allowed")
        if not request.authenticated:
            reasons.append("authentication_required")
        risk = min(1.0, max(0.0, float(request.risk_score)))
        if request.external_content:
            reasons.append("external_content_is_untrusted")
        if request.destructive and not request.approved:
            reasons.append("destructive_approval_required")
        if reasons and request.external_content and request.sandbox_available and not request.destructive:
            return TrustResult(TrustDecision.SANDBOX, tuple(reasons), bounded=True)
        if reasons:
            return TrustResult(TrustDecision.DENY, tuple(reasons), bounded=True)
        if risk >= self.sandbox_risk:
            if request.sandbox_available:
                return TrustResult(TrustDecision.SANDBOX, ("risk_requires_isolation",), bounded=True)
            return TrustResult(TrustDecision.REQUIRE_APPROVAL, ("sandbox_unavailable",), bounded=True)
        if risk > self.max_allowed_risk:
            return TrustResult(TrustDecision.REQUIRE_APPROVAL, ("risk_exceeds_default_threshold",), bounded=True)
        if request.destructive:
            return TrustResult(TrustDecision.ALLOW_WITH_LIMITS, ("approved_destructive_operation",), bounded=True)
        return TrustResult(TrustDecision.ALLOW, (), bounded=True)

"""Hypothesis/experiment engine for evidence-driven self-improvement."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class Hypothesis:
    """A falsifiable hypothesis with bounded confidence."""
    hypothesis_id: str
    statement: str
    confidence: float = 0.5

@dataclass(frozen=True, slots=True)
class ExperimentResult:
    """Observed experiment outcome."""
    hypothesis_id: str
    supported: bool
    evidence: str
    confidence_delta: float

class ExperimentEngine:
    """Update hypothesis confidence from explicit experiment outcomes."""
    def update(self, hypothesis: Hypothesis, result: ExperimentResult) -> Hypothesis:
        """Return a new hypothesis with bounded confidence."""
        if result.hypothesis_id != hypothesis.hypothesis_id:
            raise ValueError("result targets a different hypothesis")
        if not result.evidence.strip():
            raise ValueError("experiment evidence is required")
        delta = abs(result.confidence_delta) * (1.0 if result.supported else -1.0)
        return Hypothesis(hypothesis.hypothesis_id, hypothesis.statement, min(1.0, max(0.0, hypothesis.confidence + delta)))



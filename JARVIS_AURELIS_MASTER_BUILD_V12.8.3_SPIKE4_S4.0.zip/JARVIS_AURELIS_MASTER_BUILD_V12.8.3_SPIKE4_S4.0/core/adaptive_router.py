"""Resource-aware adaptive model routing facade."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Sequence

from core.model_intelligence import ModelIntelligence


@dataclass(frozen=True, slots=True)
class RoutingDecision:
    """Explainable model selection decision."""

    model: str | None
    task_type: str
    privacy: str
    reason: str


class AdaptiveRouter:
    """Classify requests, enforce hard constraints, then defer scoring to ModelIntelligence."""

    _COMPLEX = re.compile(r"\b(architect|debug|analy[sz]e|compare|design|refactor|research|prove|security|plan)\b", re.I)
    _SIMPLE = re.compile(r"\b(hi|hello|thanks|thank you|what is|define|translate)\b", re.I)

    def __init__(self, intelligence: ModelIntelligence, router: Any, *, memory_mb_provider: Any | None = None, learned_router: Any | None = None) -> None:
        self.intelligence = intelligence
        self.router = router
        self.memory_mb_provider = memory_mb_provider
        self.learned_router = learned_router
        self._calibration_bias: dict[str, float] = {}

    def classify(self, text: str, requested: str = "default") -> str:
        """Infer a conservative task class from the request."""
        if requested not in {"", "default"}:
            return requested
        if self._COMPLEX.search(text) or len(text) > 1200:
            return "complex"
        if self._SIMPLE.search(text) or len(text) < 160:
            return "simple"
        return "medium"

    def calibrate(self, model: str, *, quality_score: float, safety_score: float, latency_ms: float) -> float:
        """Update a bounded model-specific routing bias from measured evaluation data."""
        name = str(model).strip()
        if not name:
            raise ValueError("model is required")
        quality = max(0.0, min(1.0, float(quality_score)))
        safety = max(0.0, min(1.0, float(safety_score)))
        latency = max(0.0, float(latency_ms))
        score = 0.55 * quality + 0.35 * safety + 0.10 / (1.0 + latency / 1000.0)
        previous = self._calibration_bias.get(name, 0.0)
        self._calibration_bias[name] = max(-1.0, min(1.0, previous * 0.8 + (score - 0.7) * 0.2))
        return self._calibration_bias[name]

    def calibration_snapshot(self) -> dict[str, float]:
        """Return deterministic learned routing adjustments."""
        return dict(sorted(self._calibration_bias.items()))

    def choose(self, text: str, *, task_type: str = "default", privacy: str = "standard", required_capabilities: tuple[str, ...] = (), candidates: Sequence[str] | None = None) -> RoutingDecision:
        """Return an explainable selection while preserving hard constraints."""
        kind = self.classify(text, task_type)
        available = None
        if self.memory_mb_provider is not None:
            try:
                available = int(self.memory_mb_provider())
            except (TypeError, ValueError):
                available = None
        model = self.intelligence.choose(task_type=kind, privacy=privacy, required_capabilities=required_capabilities, available_memory_mb=available, candidates=candidates, task_text=text)
        if self.learned_router is not None and candidates:
            try:
                history = self.learned_router.snapshot()
                if any(key.startswith(f"{kind}|") for key in history):
                    learned = self.learned_router.suggest(kind, [str(item) for item in candidates])
                    if learned is not None:
                        model = learned
            except Exception as exc:
                _ = exc
        if model is not None and model in self._calibration_bias and self._calibration_bias[model] < -0.25:
            model = None
        if model is None:
            primary = getattr(self.router, "primary", None)
            model = getattr(primary, "name", None)
            reason = "intelligence had no compatible candidate; primary fallback"
        else:
            reason = "constraint-filtered learned score"
        return RoutingDecision(model, kind, privacy, reason)



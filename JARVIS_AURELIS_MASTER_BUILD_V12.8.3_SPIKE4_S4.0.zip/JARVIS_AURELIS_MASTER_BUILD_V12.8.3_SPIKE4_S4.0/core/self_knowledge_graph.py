"""Persistent self-knowledge graph for capabilities, components and provenance."""
from __future__ import annotations

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Mapping


class SelfKnowledgeGraph:
    """Small durable graph optimized for architectural introspection."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._nodes: dict[str, dict[str, Any]] = {}
        self._edges: set[tuple[str, str, str]] = set()
        self._load()

    def add_node(self, node_id: str, **properties: Any) -> None:
        """Create or update a node."""
        key = str(node_id).strip()
        if not key:
            raise ValueError("node_id is required")
        with self._lock:
            self._nodes[key] = {**self._nodes.get(key, {}), **properties}
            self._save()

    def add_edge(self, source: str, relation: str, target: str) -> None:
        """Create a directed typed relationship."""
        edge = (str(source).strip(), str(relation).strip(), str(target).strip())
        if not all(edge):
            raise ValueError("edge endpoints and relation are required")
        with self._lock:
            self._edges.add(edge)
            self._save()

    def neighbors(self, node_id: str) -> list[dict[str, str]]:
        """Return deterministic incoming/outgoing relationships."""
        key = str(node_id)
        with self._lock:
            rows = [{"source": s, "relation": r, "target": t} for s, r, t in self._edges if s == key or t == key]
        return sorted(rows, key=lambda row: (row["source"], row["relation"], row["target"]))

    def snapshot(self) -> Mapping[str, Any]:
        """Return JSON-safe graph state."""
        with self._lock:
            return {"nodes": {k: dict(v) for k, v in sorted(self._nodes.items())}, "edges": [list(edge) for edge in sorted(self._edges)]}

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            self._nodes = {str(k): dict(v) for k, v in payload.get("nodes", {}).items()}
            self._edges = {tuple(edge) for edge in payload.get("edges", []) if len(edge) == 3}
        except (OSError, ValueError, TypeError):
            raise RuntimeError(f"invalid self knowledge graph: {self.path}")

    def _save(self) -> None:
        payload = self.snapshot()
        fd, tmp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, self.path)
        finally:
            tmp.unlink(missing_ok=True)



"""Bounded job concurrency and per-job resource quotas."""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class QuotaConfig:
    """Global and per-owner limits."""

    max_concurrent: int = 5
    max_concurrent_per_owner: int = 2
    max_wall_seconds: float = 300.0
    max_cpu_seconds: float = 60.0

    def __post_init__(self) -> None:
        if self.max_concurrent < 1 or self.max_concurrent_per_owner < 1:
            raise ValueError("concurrency limits must be >= 1")
        if self.max_wall_seconds <= 0 or self.max_cpu_seconds <= 0:
            raise ValueError("resource quotas must be > 0")


@dataclass
class _Lease:
    owner: str
    started_wall: float
    started_cpu: float = 0.0
    thread_id: int | None = None


class ConcurrencyQuota:
    """Thread-safe global/per-owner admission control with CPU and wall limits."""

    def __init__(self, config: Optional[QuotaConfig] = None) -> None:
        self.config = config or QuotaConfig()
        self._leases: dict[str, _Lease] = {}
        self._lock = threading.RLock()

    def acquire(self, owner: str, job_id: str) -> bool:
        owner = str(owner or "system").strip() or "system"
        job_id = str(job_id).strip()
        if not job_id:
            raise ValueError("job_id is required")
        with self._lock:
            if job_id in self._leases:
                return True
            if len(self._leases) >= self.config.max_concurrent:
                return False
            owner_count = sum(lease.owner == owner for lease in self._leases.values())
            if owner_count >= self.config.max_concurrent_per_owner:
                return False
            self._leases[job_id] = _Lease(owner, time.monotonic())
            return True

    def bind_thread(self, job_id: str) -> None:
        """Bind a lease to the actual worker thread so CPU time is measured correctly."""
        with self._lock:
            lease = self._leases.get(job_id)
            if lease is not None:
                lease.thread_id = threading.get_ident()
                lease.started_cpu = time.thread_time()

    def check_quota(self, job_id: str) -> Optional[str]:
        with self._lock:
            lease = self._leases.get(job_id)
            if lease is None:
                return None
            wall = time.monotonic() - lease.started_wall
            if lease.thread_id == threading.get_ident():
                cpu = max(0.0, time.thread_time() - lease.started_cpu)
            else:
                cpu = 0.0
            if wall > self.config.max_wall_seconds:
                return f"wall-clock quota exceeded ({wall:.3f}s > {self.config.max_wall_seconds:.3f}s)"
            if cpu > self.config.max_cpu_seconds:
                return f"CPU quota exceeded ({cpu:.3f}s > {self.config.max_cpu_seconds:.3f}s)"
            return None

    def release(self, job_id: str) -> None:
        with self._lock:
            self._leases.pop(job_id, None)

    def current_usage(self) -> dict[str, int | float]:
        with self._lock:
            owners = {lease.owner for lease in self._leases.values()}
            return {
                "global_active": len(self._leases),
                "global_limit": self.config.max_concurrent,
                "owner_count": len(owners),
                "owner_limit": self.config.max_concurrent_per_owner,
            }



"""SQLite-backed idempotency records with atomic request claiming."""
from __future__ import annotations
from contextlib import contextmanager

import hashlib
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Iterator, Optional


class IdempotencyConflictError(ValueError):
    """Raised when a key is reused with different request content."""


class IdempotencyStore:
    """Persist idempotency keys so duplicate submissions converge on one job."""

    def __init__(self, db_path: str = "data/idempotency.db", ttl_seconds: float = 86400.0, reservation_ttl_seconds: float = 600.0) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be > 0")
        self._db_path = str(db_path)
        self._ttl = float(ttl_seconds)
        self._reservation_ttl = max(1.0, min(float(reservation_ttl_seconds), self._ttl))
        self._lock = threading.RLock()
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        """Yield a configured SQLite connection and always close it."""
        conn = sqlite3.connect(self._db_path, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS idempotency (
                    key TEXT PRIMARY KEY,
                    content_hash TEXT NOT NULL,
                    owner TEXT NOT NULL,
                    job_id TEXT,
                    created_at REAL NOT NULL,
                    expires_at REAL NOT NULL
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_idempotency_expiry ON idempotency(expires_at)")

    @staticmethod
    def _content_hash(goal: str, steps_json: str, owner: str) -> str:
        payload = {
            "goal": str(goal),
            "steps": json.loads(steps_json),
            "owner": str(owner),
        }
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def compute_key(self, goal: str, steps_json: str, owner: str) -> str:
        """Return a deterministic content hash for callers that need one."""
        return self._content_hash(goal, steps_json, owner)

    def check_or_create(self, key: str, goal: str, steps_json: str, owner: str) -> tuple[bool, Optional[str]]:
        """Atomically claim a key, or return the existing job id.

        ``existing_id`` is ``None`` while another transaction has reserved the key
        but has not yet attached the job id. That state is deliberately distinct
        from a new claim so callers cannot create a second job.
        """
        clean_key = str(key).strip()
        if not clean_key or len(clean_key) > 256:
            raise ValueError("idempotency key must be 1-256 characters")
        content_hash = self._content_hash(goal, steps_json, owner)
        now = time.time()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DELETE FROM idempotency WHERE expires_at <= ?", (now,))
            row = conn.execute("SELECT * FROM idempotency WHERE key=?", (clean_key,)).fetchone()
            if row is not None:
                if row["content_hash"] != content_hash or row["owner"] != owner:
                    raise IdempotencyConflictError("idempotency key reused with different request")
                if row["job_id"] is None and float(row["created_at"]) <= now - self._reservation_ttl:
                    conn.execute("DELETE FROM idempotency WHERE key=? AND job_id IS NULL", (clean_key,))
                    row = None
                else:
                    conn.commit()
                    return False, row["job_id"]
            conn.execute(
                "INSERT INTO idempotency(key,content_hash,owner,created_at,expires_at) VALUES(?,?,?,?,?)",
                (clean_key, content_hash, owner, now, now + self._ttl),
            )
            conn.commit()
            return True, None

    def finalize(self, key: str, job_id: str) -> None:
        with self._lock, self._connect() as conn:
            cur = conn.execute("UPDATE idempotency SET job_id=? WHERE key=?", (job_id, key))
            if cur.rowcount != 1:
                raise KeyError(f"idempotency key not found: {key}")

    def purge_expired(self) -> int:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM idempotency WHERE expires_at <= ?", (time.time(),))
            return int(cur.rowcount)

    def get_stats(self) -> dict[str, int]:
        with self._lock, self._connect() as conn:
            total = int(conn.execute("SELECT COUNT(*) FROM idempotency").fetchone()[0])
            pending = int(conn.execute("SELECT COUNT(*) FROM idempotency WHERE job_id IS NULL").fetchone()[0])
        return {"total": total, "pending": pending}



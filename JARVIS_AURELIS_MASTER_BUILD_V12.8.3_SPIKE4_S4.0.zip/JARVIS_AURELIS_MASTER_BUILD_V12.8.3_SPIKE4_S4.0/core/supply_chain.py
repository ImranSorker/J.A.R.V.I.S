"""Dependency and release supply-chain audit utilities."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any


class SupplyChainAuditor:
    """Generate deterministic SBOM-like inventories and scan suspicious pins."""

    _REQ_RE = re.compile(r"^\s*([A-Za-z0-9_.-]+)\s*([<>=!~].*)?$")

    def __init__(self, project_root: str | Path) -> None:
        self.root = Path(project_root).resolve()

    def inventory(self) -> list[dict[str, str]]:
        """Extract declared Python dependencies from requirements and pyproject."""
        records: dict[str, str] = {}
        for filename in ("requirements.txt", "requirements-linux.txt", "requirements-windows.txt"):
            path = self.root / filename
            if not path.is_file():
                continue
            for line in path.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if not stripped or stripped.startswith("#") or stripped.startswith("-"):
                    continue
                if stripped.startswith(("git+", "http://", "https://", "file:")):
                    continue
                match = self._REQ_RE.match(stripped)
                if match:
                    records[match.group(1).lower()] = (match.group(2) or "unspecified").strip()
        return [{"name": name, "constraint": constraint} for name, constraint in sorted(records.items())]

    def sbom(self) -> dict[str, Any]:
        """Return a deterministic dependency inventory digest."""
        inventory = self.inventory()
        digest = hashlib.sha256(json.dumps(inventory, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return {"format": "jarvis-sbom-v1", "dependencies": inventory, "sha256": digest}

    def audit(self) -> dict[str, Any]:
        """Flag dependencies that have no explicit version constraint."""
        inventory = self.inventory()
        unpinned = [item["name"] for item in inventory if item["constraint"] == "unspecified"]
        return {"ok": not unpinned, "dependency_count": len(inventory), "unpinned": unpinned}



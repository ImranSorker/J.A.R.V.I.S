"""Benchmarking, predictive loading, resource routing and continuous evaluation."""
from __future__ import annotations

import statistics
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from core.contracts.platform import BenchmarkSample, EvaluationCase


@dataclass(frozen=True)
class PerformanceBaseline:
    """Expected performance envelope for a named workload."""

    workload: str
    max_latency_ms: float
    min_tokens_per_second: float = 0.0


@dataclass(frozen=True)
class PerformanceRegression:
    """Result of comparing a sample with a baseline."""

    workload: str
    passed: bool
    latency_ms: float
    tokens_per_second: float
    reasons: tuple[str, ...] = ()


class BenchmarkRegistry:
    """Bounded in-memory benchmark store."""

    def __init__(self, max_samples: int = 10_000) -> None:
        self.max_samples = max(1, int(max_samples))
        self._samples: list[BenchmarkSample] = []
        self._lock = threading.RLock()

    def record(self, sample: BenchmarkSample) -> None:
        """Record one observation and bound memory usage."""
        with self._lock:
            self._samples.append(sample)
            if len(self._samples) > self.max_samples:
                del self._samples[: len(self._samples) - self.max_samples]

    def snapshot(self) -> list[BenchmarkSample]:
        """Return observations in insertion order."""
        with self._lock:
            return list(self._samples)

    def summary(self, workload: str) -> dict[str, float | int]:
        """Compute stable aggregate performance statistics."""
        rows = [s for s in self.snapshot() if s.workload == workload]
        if not rows:
            return {"samples": 0, "p50_latency_ms": 0.0, "mean_tokens_per_second": 0.0, "success_rate": 0.0}
        latencies = [s.latency_ms for s in rows]
        throughput = [s.tokens_per_second for s in rows]
        return {"samples": len(rows), "p50_latency_ms": statistics.median(latencies), "mean_tokens_per_second": statistics.fmean(throughput), "success_rate": sum(s.success for s in rows) / len(rows)}


class PredictiveModelLoader:
    """Predict the next model from bounded recency and demand counts."""

    def __init__(self, *, max_history: int = 1000) -> None:
        self.max_history = max(1, int(max_history))
        self._history: list[str] = []
        self._lock = threading.RLock()

    def observe(self, model_name: str) -> None:
        """Record a model request."""
        name = str(model_name).strip()
        if not name:
            return
        with self._lock:
            self._history.append(name)
            if len(self._history) > self.max_history:
                del self._history[: len(self._history) - self.max_history]

    def predict(self, candidates: Sequence[str]) -> str | None:
        """Choose the candidate with highest recency-weighted demand."""
        options = sorted({str(candidate).strip() for candidate in candidates if str(candidate).strip()})
        if not options:
            return None
        with self._lock:
            scores = {name: 0.0 for name in options}
            total = len(self._history)
            for index, name in enumerate(self._history):
                if name in scores:
                    scores[name] += (index + 1) / max(total, 1)
        return max(options, key=lambda name: (scores[name], name))


class ResourceAwareRouter:
    """Route workloads using requirements and compute-node snapshots."""

    def choose(self, candidates: Sequence[Mapping[str, Any]], *, vram_mb: int = 0, memory_mb: int = 0, latency_ms: float | None = None) -> Mapping[str, Any] | None:
        """Select a candidate that satisfies resource constraints."""
        valid = [c for c in candidates if int(c.get("vram_mb", 0)) >= vram_mb and int(c.get("memory_mb", 0)) >= memory_mb and bool(c.get("online", True)) and (latency_ms is None or float(c.get("latency_ms", 0.0)) <= latency_ms)]
        return min(valid, key=lambda c: (float(c.get("latency_ms", 0.0)), -int(c.get("vram_mb", 0)), str(c.get("id", "")))) if valid else None


class PerformanceRegressionEngine:
    """Compare current measurements to explicit baselines."""

    def check(self, sample: BenchmarkSample, baseline: PerformanceBaseline) -> PerformanceRegression:
        """Return a deterministic pass/fail regression result."""
        reasons: list[str] = []
        if sample.latency_ms > baseline.max_latency_ms:
            reasons.append("latency regression")
        if sample.tokens_per_second < baseline.min_tokens_per_second:
            reasons.append("throughput regression")
        if not sample.success:
            reasons.append("benchmark failure")
        return PerformanceRegression(sample.workload, not reasons, sample.latency_ms, sample.tokens_per_second, tuple(reasons))


class ContinuousEvaluation:
    """Execute bounded evaluation cases against an injected model function."""

    def run(self, cases: Sequence[EvaluationCase], evaluator: Callable[[EvaluationCase], Any]) -> dict[str, Any]:
        """Run every case exactly once and produce stable evaluation metrics."""
        if len(cases) > 1000:
            raise ValueError("evaluation case limit exceeded")
        results = []
        for case in cases:
            started = time.perf_counter()
            try:
                actual = evaluator(case)
                ok = actual == case.expected if case.evaluator == "exact" else bool(actual)
                results.append({"case_id": case.case_id, "ok": ok, "latency_ms": (time.perf_counter() - started) * 1000})
            except Exception as exc:
                results.append({"case_id": case.case_id, "ok": False, "error": str(exc), "latency_ms": (time.perf_counter() - started) * 1000})
        passed = sum(item["ok"] for item in results)
        return {"total": len(results), "passed": passed, "failed": len(results) - passed, "pass_rate": (passed / len(results)) if results else 1.0, "results": results}



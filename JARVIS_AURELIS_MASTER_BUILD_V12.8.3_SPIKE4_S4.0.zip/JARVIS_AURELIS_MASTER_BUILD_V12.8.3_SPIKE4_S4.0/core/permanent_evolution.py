"""Long-lived J.A.R.V.I.S. platform evolution primitives.

These components are deliberately version-neutral: they provide internal build
and capability epochs while the public product version is controlled by VERSION.
"""
from __future__ import annotations

import hashlib
import json
import ast
import base64
import shutil
import tempfile
import threading
import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


@dataclass(frozen=True, slots=True)
class CapabilityEpoch:
    """Immutable internal identity for a V12.8.0 build."""

    public_version: str
    build_id: str
    epoch: int
    schema_generation: str
    git_commit: str
    artifact_sha256: str

    def snapshot(self) -> dict[str, Any]:
        return asdict(self)


class PermanentVersionManager:
    """Keep public version fixed while evolving internal capability generations."""

    def __init__(self, path: str | Path, *, public_version: str = "12.8.3") -> None:
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.public_version = public_version
        self._lock = threading.RLock()
        if self.path.exists():
            try:
                self._state = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                self._state = {"epoch": 0}
        else:
            self._state = {"epoch": 0}

    def advance(self, *, schema_generation: str, git_commit: str = "unknown", artifact_sha256: str = "unbuilt") -> CapabilityEpoch:
        """Advance the internal epoch without changing the public version."""
        if str(schema_generation).strip() == "":
            raise ValueError("schema_generation is required")
        with self._lock:
            epoch = int(self._state.get("epoch", 0)) + 1
            build_id = f"{self.public_version}+{time.strftime('%Y%m%d')}.{epoch:04d}"
            self._state = {"epoch": epoch, "build_id": build_id, "schema_generation": str(schema_generation), "git_commit": str(git_commit), "artifact_sha256": str(artifact_sha256)}
            self.path.write_text(json.dumps(self._state, sort_keys=True, indent=2), encoding="utf-8")
            return CapabilityEpoch(self.public_version, build_id, epoch, str(schema_generation), str(git_commit), str(artifact_sha256))

    def current(self) -> CapabilityEpoch:
        with self._lock:
            return CapabilityEpoch(self.public_version, str(self._state.get("build_id", f"{self.public_version}+bootstrap")), int(self._state.get("epoch", 0)), str(self._state.get("schema_generation", "S0")), str(self._state.get("git_commit", "unknown")), str(self._state.get("artifact_sha256", "unbuilt")))


@dataclass(frozen=True, slots=True)
class SelfModel:
    """Machine-readable model of the current system capabilities and limits."""

    generated_at: float
    public_version: str
    build_id: str
    capabilities: tuple[str, ...]
    tools: tuple[str, ...]
    models: tuple[str, ...]
    agents: tuple[str, ...]
    plugins: tuple[str, ...]
    degraded: tuple[str, ...]
    limitations: tuple[str, ...]
    safe_mode: str


class SelfModelEngine:
    """Produce bounded self-knowledge from authoritative runtime registries."""

    def snapshot(self, *, version: PermanentVersionManager, feature_names: Iterable[str], tools: Iterable[str] = (), models: Iterable[str] = (), agents: Iterable[str] = (), plugins: Iterable[str] = (), degraded: Iterable[str] = (), limitations: Iterable[str] = (), safe_mode: str = "normal") -> dict[str, Any]:
        """Build a deterministic self-model without leaking secrets."""
        epoch = version.current()
        model = SelfModel(time.time(), epoch.public_version, epoch.build_id, tuple(sorted(set(map(str, feature_names))))[:2048], tuple(sorted(set(map(str, tools))))[:2048], tuple(sorted(set(map(str, models))))[:512], tuple(sorted(set(map(str, agents))))[:512], tuple(sorted(set(map(str, plugins))))[:512], tuple(sorted(set(map(str, degraded))))[:256], tuple(sorted(set(map(str, limitations))))[:256], str(safe_mode))
        return asdict(model)


@dataclass(frozen=True, slots=True)
class TrajectoryEvent:
    event_id: str
    task_id: str
    stage: str
    actor: str
    payload: Mapping[str, Any]
    created_at: float
    previous_hash: str
    digest: str


class TrajectoryRecorder:
    """Bounded hash-chained execution trajectory recorder."""

    def __init__(self, *, max_events: int = 100_000) -> None:
        self.max_events = max(1, min(int(max_events), 500_000))
        self._events: deque[TrajectoryEvent] = deque(maxlen=self.max_events)
        self._lock = threading.RLock()
        self._tail = "0" * 64

    def record(self, task_id: str, stage: str, actor: str, payload: Mapping[str, Any] | None = None) -> TrajectoryEvent:
        """Append one event to the current task trajectory."""
        now = time.time()
        event_id = f"traj_{uuid.uuid4().hex}"
        safe = dict(payload or {})
        canonical = json.dumps({"event_id": event_id, "task_id": str(task_id), "stage": str(stage), "actor": str(actor), "payload": safe, "created_at": round(now, 6), "previous_hash": self._tail}, sort_keys=True, separators=(",", ":"), default=str)
        digest = hashlib.sha256(canonical.encode()).hexdigest()
        row = TrajectoryEvent(event_id, str(task_id), str(stage), str(actor), safe, now, self._tail, digest)
        with self._lock:
            self._events.append(row)
            self._tail = digest
        return row

    def task(self, task_id: str, limit: int = 500) -> list[dict[str, Any]]:
        """Return a bounded trajectory for one task."""
        with self._lock:
            rows = [asdict(x) for x in self._events if x.task_id == str(task_id)]
        return rows[-max(1, min(int(limit), 10_000)):]

    def verify(self) -> bool:
        """Verify the retained chain."""
        with self._lock:
            previous = "0" * 64
            for row in self._events:
                canonical = json.dumps({"event_id": row.event_id, "task_id": row.task_id, "stage": row.stage, "actor": row.actor, "payload": dict(row.payload), "created_at": round(row.created_at, 6), "previous_hash": previous}, sort_keys=True, separators=(",", ":"), default=str)
                digest = hashlib.sha256(canonical.encode()).hexdigest()
                if row.previous_hash != previous or digest != row.digest:
                    return False
                previous = digest
            return previous == self._tail


@dataclass(frozen=True, slots=True)
class SentinelRule:
    rule_id: str
    name: str
    event_type: str
    predicate: str
    wake_target: str
    cooldown_seconds: float
    enabled: bool = True


class SentinelEngine:
    """Event-driven waiting engine with cooldown and bounded dispatch."""

    def __init__(self, trigger: Callable[[str, Mapping[str, Any]], Any], *, max_rules: int = 512) -> None:
        self._trigger = trigger
        self.max_rules = max(1, min(int(max_rules), 5_000))
        self._rules: dict[str, SentinelRule] = {}
        self._last_trigger: dict[str, float] = {}
        self._lock = threading.RLock()

    def register(self, rule: SentinelRule) -> None:
        """Register or replace one bounded event rule."""
        if not rule.name.strip() or not rule.event_type.strip() or not rule.wake_target.strip():
            raise ValueError("sentinel rule fields are required")
        if rule.cooldown_seconds < 0 or rule.cooldown_seconds > 7 * 86400:
            raise ValueError("invalid cooldown")
        with self._lock:
            if len(self._rules) >= self.max_rules and rule.rule_id not in self._rules:
                raise ValueError("sentinel rule capacity exhausted")
            self._rules[rule.rule_id] = rule

    def emit(self, event_type: str, payload: Mapping[str, Any]) -> list[str]:
        """Evaluate rules using simple exact/contains predicates and dispatch wakes."""
        now = time.time()
        hits: list[str] = []
        with self._lock:
            rules = tuple(self._rules.values())
        for rule in rules:
            if not rule.enabled or rule.event_type != str(event_type):
                continue
            haystack = json.dumps(dict(payload), sort_keys=True, default=str).lower()
            predicate = str(rule.predicate).strip().lower()
            if predicate and predicate not in haystack:
                continue
            last = self._last_trigger.get(rule.rule_id, 0.0)
            if now - last < rule.cooldown_seconds:
                continue
            self._last_trigger[rule.rule_id] = now
            self._trigger(rule.wake_target, dict(payload))
            hits.append(rule.rule_id)
        return hits

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret rule state."""
        with self._lock:
            return {"rules": [asdict(r) for r in self._rules.values()], "last_triggered": dict(self._last_trigger)}


class CounterfactualPlanner:
    """Evaluate bounded alternatives using deterministic policy/resource estimators."""

    def compare(self, alternatives: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        """Rank alternatives by declared quality, risk, cost and reversibility."""
        rows = [dict(item) for item in alternatives]
        if not 1 <= len(rows) <= 32:
            raise ValueError("1..32 alternatives required")
        scored: list[dict[str, Any]] = []
        for row in rows:
            quality = max(0.0, min(1.0, float(row.get("quality", 0.0))))
            risk = max(0.0, min(1.0, float(row.get("risk", 0.0))))
            cost = max(0.0, min(1.0, float(row.get("cost", 0.0))))
            reversible = max(0.0, min(1.0, float(row.get("reversibility", 0.0))))
            uncertainty = max(0.0, min(1.0, float(row.get("uncertainty", 0.0))))
            score = quality * 0.45 + reversible * 0.15 - risk * 0.20 - cost * 0.10 - uncertainty * 0.10
            scored.append({**row, "score": round(score, 6)})
        scored.sort(key=lambda x: (-float(x["score"]), str(x.get("name", ""))))
        return {"alternatives": scored, "recommended_candidate": scored[0].get("name")}


@dataclass(frozen=True, slots=True)
class CapabilityLease:
    lease_id: str
    principal: str
    capability: str
    resource: str
    issued_at: float
    expires_at: float
    uses_remaining: int


class CapabilityLeaseRegistry:
    """Time/use bounded capability leases; leases never broaden policy."""

    def __init__(self, *, max_leases: int = 10000) -> None:
        self.max_leases = max(1, min(int(max_leases), 100_000))
        self._leases: dict[str, CapabilityLease] = {}
        self._lock = threading.RLock()

    def issue(self, principal: str, capability: str, resource: str = "*", *, ttl_seconds: float = 300.0, uses: int = 1) -> CapabilityLease:
        """Issue a bounded lease."""
        ttl = max(1.0, min(float(ttl_seconds), 86_400.0))
        remaining = max(1, min(int(uses), 10_000))
        with self._lock:
            if len(self._leases) >= self.max_leases:
                self._reap()
            if len(self._leases) >= self.max_leases:
                raise RuntimeError("capability lease capacity exhausted")
            now = time.time()
            lease = CapabilityLease(f"lease_{uuid.uuid4().hex}", str(principal), str(capability), str(resource), now, now + ttl, remaining)
            self._leases[lease.lease_id] = lease
            return lease

    def consume(self, lease_id: str, *, principal: str, capability: str, resource: str = "*") -> CapabilityLease:
        """Consume exactly one authorized lease use."""
        with self._lock:
            lease = self._leases.get(str(lease_id))
            if lease is None:
                raise PermissionError("unknown capability lease")
            if time.time() >= lease.expires_at or lease.uses_remaining <= 0:
                self._leases.pop(lease.lease_id, None)
                raise PermissionError("expired capability lease")
            if lease.principal != str(principal) or lease.capability != str(capability):
                raise PermissionError("capability lease principal mismatch")
            if lease.resource != "*" and lease.resource != str(resource):
                raise PermissionError("capability lease resource mismatch")
            updated = CapabilityLease(lease.lease_id, lease.principal, lease.capability, lease.resource, lease.issued_at, lease.expires_at, lease.uses_remaining - 1)
            if updated.uses_remaining == 0:
                self._leases.pop(lease.lease_id, None)
            else:
                self._leases[lease.lease_id] = updated
            return updated

    def _reap(self) -> None:
        now = time.time()
        self._leases = {k: v for k, v in self._leases.items() if v.expires_at > now and v.uses_remaining > 0}


@dataclass(frozen=True, slots=True)
class ActionRisk:
    risk: str
    score: float
    reversible: bool
    approval: str


class ActionRiskEngine:
    """Classify actions using impact, reversibility, authority, uncertainty and exposure."""

    def classify(self, *, impact: float, reversibility: float, authority: float, uncertainty: float, exposure: float) -> ActionRisk:
        vals = [max(0.0, min(1.0, float(v))) for v in (impact, reversibility, authority, uncertainty, exposure)]
        imp, rev, auth, unc, exp = vals
        score = min(1.0, 0.40 * imp + 0.25 * auth + 0.15 * unc + 0.10 * exp + 0.10 * (1.0 - rev) + 0.20 * (imp * auth * (1.0 - rev)))
        if score >= 0.70:
            level, approval = "critical", "manual_or_quorum"
        elif score >= 0.45:
            level, approval = "high", "explicit_confirmation"
        elif score >= 0.20:
            level, approval = "medium", "policy_log"
        else:
            level, approval = "low", "automatic"
        return ActionRisk(level, round(score, 6), rev >= 0.8, approval)


@dataclass(frozen=True, slots=True)
class UndoRecord:
    action_id: str
    action: str
    reversible: bool
    inverse: Mapping[str, Any] | None
    created_at: float


class UndoRegistry:
    """Bounded metadata registry for reversible actions."""

    def __init__(self, *, max_records: int = 50_000) -> None:
        self.max_records = max(1, min(int(max_records), 500_000))
        self._records: deque[UndoRecord] = deque(maxlen=self.max_records)
        self._lock = threading.RLock()

    def register(self, action: str, *, reversible: bool, inverse: Mapping[str, Any] | None = None) -> UndoRecord:
        """Register inverse metadata; executing inverse operations remains policy-gated."""
        row = UndoRecord(f"act_{uuid.uuid4().hex}", str(action), bool(reversible), dict(inverse) if inverse else None, time.time())
        with self._lock:
            self._records.append(row)
        return row

    def recent(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return newest action records."""
        with self._lock:
            return [asdict(row) for row in list(self._records)[-max(1, min(int(limit), self.max_records)):]]


@dataclass(frozen=True, slots=True)
class LineageRecord:
    lineage_id: str
    datum: str
    source: str
    stage: str
    destination: str
    created_at: float
    digest: str


class DataLineage:
    """Bounded provenance graph for data movement across cognition boundaries."""

    def __init__(self, *, max_records: int = 100_000) -> None:
        self.max_records = max(1, min(int(max_records), 500_000))
        self._records: deque[LineageRecord] = deque(maxlen=self.max_records)
        self._lock = threading.RLock()

    def add(self, datum: str, source: str, stage: str, destination: str) -> LineageRecord:
        """Record one data-flow edge with a stable content-independent record hash."""
        created = time.time()
        rid = f"lin_{uuid.uuid4().hex}"
        canonical = f"{rid}|{datum}|{source}|{stage}|{destination}|{created:.6f}"
        row = LineageRecord(rid, str(datum), str(source), str(stage), str(destination), created, hashlib.sha256(canonical.encode()).hexdigest())
        with self._lock:
            self._records.append(row)
        return row

    def trace(self, datum: str, limit: int = 200) -> list[dict[str, Any]]:
        """Return lineage records for one datum identifier."""
        with self._lock:
            rows = [asdict(row) for row in self._records if row.datum == str(datum)]
        return rows[-max(1, min(int(limit), 10_000)):]


@dataclass(frozen=True, slots=True)
class CausalEdge:
    """Explicit evidence-backed causal relationship."""

    edge_id: str
    cause: str
    effect: str
    relation: str
    confidence: float
    source: str
    created_at: float


class CausalMemory:
    """Bounded causal memory; it stores explicit relations and never invents causality."""

    def __init__(self, *, max_edges: int = 100_000) -> None:
        self.max_edges = max(1, min(int(max_edges), 500_000))
        self._edges: deque[CausalEdge] = deque(maxlen=self.max_edges)
        self._lock = threading.RLock()

    def add(self, cause: str, effect: str, *, relation: str = "influences", confidence: float = 0.5, source: str = "unknown") -> CausalEdge:
        """Add an explicit causal edge with bounded confidence."""
        if not str(cause).strip() or not str(effect).strip():
            raise ValueError("cause and effect are required")
        conf = max(0.0, min(1.0, float(confidence)))
        row = CausalEdge(f"cause_{uuid.uuid4().hex}", str(cause), str(effect), str(relation), conf, str(source), time.time())
        with self._lock:
            self._edges.append(row)
        return row

    def related(self, subject: str, *, direction: str = "both", limit: int = 100) -> list[dict[str, Any]]:
        """Return direct cause/effect neighbors without inferential expansion."""
        subject = str(subject)
        direction = str(direction)
        with self._lock:
            rows = []
            for row in self._edges:
                if direction in {"both", "out"} and row.cause == subject:
                    rows.append(asdict(row))
                if direction in {"both", "in"} and row.effect == subject:
                    rows.append(asdict(row))
        return rows[-max(1, min(int(limit), 5000)):]


@dataclass(frozen=True, slots=True)
class DreamSnapshot:
    """Immutable record for an isolated dream workspace snapshot."""

    snapshot_id: str
    source_root: str
    workspace: str
    file_count: int
    total_bytes: int
    manifest_sha256: str
    created_at: float


class DreamSandbox:
    """Create bounded copy-on-write snapshots for non-destructive experiments."""

    def __init__(self, root: str | Path, *, max_files: int = 20_000, max_bytes: int = 512 * 1024 * 1024) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.max_files = max(1, min(int(max_files), 200_000))
        self.max_bytes = max(1, min(int(max_bytes), 4 * 1024 * 1024 * 1024))

    def snapshot(self, source: str | Path) -> DreamSnapshot:
        """Copy a bounded source tree into an isolated snapshot workspace."""
        src = Path(source).resolve()
        if not src.exists() or not src.is_dir():
            raise ValueError("source must be an existing directory")
        files = [p for p in src.rglob("*") if p.is_file() and "__pycache__" not in p.parts and ".git" not in p.parts]
        if len(files) > self.max_files:
            raise ValueError("snapshot file limit exceeded")
        total = sum(p.stat().st_size for p in files)
        if total > self.max_bytes:
            raise ValueError("snapshot byte limit exceeded")
        sid = f"dream_{uuid.uuid4().hex}"
        dst = self.root / sid
        dst.mkdir()
        manifest: list[str] = []
        for file in files:
            rel = file.relative_to(src)
            out = dst / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file, out)
            digest = hashlib.sha256(file.read_bytes()).hexdigest()
            manifest.append(f"{rel.as_posix()}:{digest}:{file.stat().st_size}")
        manifest.sort()
        manifest_bytes = "\n".join(manifest).encode("utf-8")
        return DreamSnapshot(sid, str(src), str(dst), len(files), total, hashlib.sha256(manifest_bytes).hexdigest(), time.time())


@dataclass(frozen=True, slots=True)
class TrajectoryGrade:
    """Deterministic trajectory quality and safety assessment."""

    task_id: str
    completeness: float
    verification: float
    policy_evidence: float
    recovery: float
    score: float
    verdict: str


class TrajectoryGrader:
    """Grade trajectories by explicit evidence rather than model opinion."""

    REQUIRED = ("plan", "execute", "verify")

    def grade(self, task_id: str, events: Iterable[Mapping[str, Any]]) -> TrajectoryGrade:
        rows = [dict(row) for row in events]
        stages = {str(row.get("stage")) for row in rows}
        completeness = sum(stage in stages for stage in self.REQUIRED) / len(self.REQUIRED)
        verification = 1.0 if any(str(row.get("stage")) == "verify" and bool(dict(row.get("payload") or {}).get("ok", True)) for row in rows) else 0.0
        policy = 1.0 if any(str(row.get("stage")) in {"policy", "authorization"} for row in rows) else 0.0
        recovery = 1.0 if any(str(row.get("stage")) == "recovery" for row in rows) else 0.0
        score = round(0.45 * completeness + 0.30 * verification + 0.15 * policy + 0.10 * recovery, 6)
        verdict = "accept" if score >= 0.85 else "review" if score >= 0.55 else "reject"
        return TrajectoryGrade(str(task_id), completeness, verification, policy, recovery, score, verdict)


class ContractFingerprint:
    """Produce deterministic fingerprints for schemas/contracts."""

    @staticmethod
    def digest(payload: Any) -> str:
        """Hash canonical JSON-safe contract content."""
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()


class ArchitectureDriftDetector:
    """Detect unexpected import edges against an explicit architecture allow-list."""

    def scan(self, root: str | Path, allowed_edges: Mapping[str, Iterable[str]]) -> dict[str, Any]:
        root_path = Path(root).resolve()
        unexpected: list[str] = []
        for rel, allowed in allowed_edges.items():
            path = root_path / rel
            if not path.is_file() or path.suffix != ".py":
                continue
            permitted = tuple(str(x) for x in allowed)
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for node in ast.walk(tree):
                names: list[str] = []
                if isinstance(node, ast.Import):
                    names.extend(alias.name for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    names.append(node.module)
                for name in names:
                    if any(name == item or name.startswith(item + ".") for item in permitted):
                        continue
                    if name.startswith("core") or name.startswith("services") or name.startswith("security"):
                        unexpected.append(f"{rel}->{name}")
        return {"ok": not unexpected, "unexpected_edges": sorted(set(unexpected))}


@dataclass(frozen=True, slots=True)
class TrainingExample:
    """Verified self-improvement training example with provenance."""

    example_id: str
    input_text: str
    output_text: str
    source: str
    evidence_digest: str
    quality: float


class VerifiedTrainingDataFactory:
    """Create filtered training examples from verified trajectories/feedback."""

    def build(self, rows: Iterable[Mapping[str, Any]], *, minimum_quality: float = 0.8, max_examples: int = 10_000) -> list[TrainingExample]:
        threshold = max(0.0, min(1.0, float(minimum_quality)))
        out: list[TrainingExample] = []
        for row in rows:
            if len(out) >= max(1, min(int(max_examples), 100_000)):
                break
            quality = float(row.get("quality", 0.0))
            input_text = str(row.get("input", "")).strip()
            output_text = str(row.get("output", "")).strip()
            source = str(row.get("source", "unknown")).strip()
            if quality < threshold or not input_text or not output_text or not source:
                continue
            evidence = self._evidence(input_text, output_text, source)
            out.append(TrainingExample(f"train_{uuid.uuid4().hex}", input_text, output_text, source, evidence, round(quality, 6)))
        return out

    @staticmethod
    def _evidence(input_text: str, output_text: str, source: str) -> str:
        return hashlib.sha256(f"{source}\0{input_text}\0{output_text}".encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class ThermalBudget:
    """Background-work budget derived from temperature/power conditions."""

    state: str
    background_fraction: float
    reason: str


class ThermalGovernance:
    """Conservative thermal/resource policy independent of hardware vendor APIs."""

    def classify(self, temperature_c: float | None, *, on_battery: bool = False) -> ThermalBudget:
        if temperature_c is None:
            return ThermalBudget("unknown", 0.50 if on_battery else 0.75, "temperature unavailable")
        temp = float(temperature_c)
        if temp >= 90.0:
            return ThermalBudget("critical", 0.0, "critical temperature")
        if temp >= 80.0:
            return ThermalBudget("hot", 0.15, "high temperature")
        if on_battery:
            return ThermalBudget("battery", 0.30, "battery mode")
        return ThermalBudget("normal", 1.0, "normal thermal state")


@dataclass(frozen=True, slots=True)
class SignedA2ATaskEnvelope:
    """Ed25519-signed A2A task envelope with explicit audience and expiry."""

    issuer: str
    audience: str
    task_id: str
    nonce: str
    issued_at: float
    expires_at: float
    payload_sha256: str
    signature_b64: str

    def canonical_bytes(self) -> bytes:
        return json.dumps({"issuer": self.issuer, "audience": self.audience, "task_id": self.task_id, "nonce": self.nonce, "issued_at": round(self.issued_at, 6), "expires_at": round(self.expires_at, 6), "payload_sha256": self.payload_sha256}, sort_keys=True, separators=(",", ":")).encode("utf-8")


class A2ATaskSigner:
    """Sign and verify bounded A2A task envelopes with Ed25519."""

    @staticmethod
    def generate_keypair() -> tuple[bytes, bytes]:
        key = Ed25519PrivateKey.generate()
        return key.private_bytes_raw(), key.public_key().public_bytes_raw()

    @staticmethod
    def sign(private_key: bytes, *, issuer: str, audience: str, task_id: str, payload: Mapping[str, Any], ttl_seconds: float = 300.0) -> SignedA2ATaskEnvelope:
        ttl = max(1.0, min(float(ttl_seconds), 3600.0))
        now = time.time()
        digest = ContractFingerprint.digest(payload)
        env = SignedA2ATaskEnvelope(str(issuer), str(audience), str(task_id), uuid.uuid4().hex, now, now + ttl, digest, "")
        signature = Ed25519PrivateKey.from_private_bytes(bytes(private_key)).sign(env.canonical_bytes())
        return SignedA2ATaskEnvelope(env.issuer, env.audience, env.task_id, env.nonce, env.issued_at, env.expires_at, env.payload_sha256, base64.b64encode(signature).decode("ascii"))

    @staticmethod
    def verify(public_key: bytes, envelope: SignedA2ATaskEnvelope, *, audience: str, payload: Mapping[str, Any]) -> bool:
        if envelope.audience != str(audience) or time.time() >= envelope.expires_at:
            return False
        if envelope.payload_sha256 != ContractFingerprint.digest(payload):
            return False
        try:
            Ed25519PublicKey.from_public_bytes(bytes(public_key)).verify(base64.b64decode(envelope.signature_b64, validate=True), envelope.canonical_bytes())
            return True
        except Exception:
            return False


__all__ = [
    "ActionRisk", "ActionRiskEngine", "CapabilityEpoch", "CapabilityLease", "CapabilityLeaseRegistry",
    "ArchitectureDriftDetector", "A2ATaskSigner", "CausalEdge", "CausalMemory", "ContractFingerprint", "CounterfactualPlanner", "DataLineage", "DreamSandbox", "DreamSnapshot", "PermanentVersionManager", "SelfModel", "SelfModelEngine",
    "SentinelEngine", "SentinelRule", "SignedA2ATaskEnvelope", "ThermalBudget", "ThermalGovernance", "TrajectoryEvent", "TrajectoryGrader", "TrajectoryGrade", "TrajectoryRecorder", "TrainingExample", "UndoRecord", "UndoRegistry", "VerifiedTrainingDataFactory",
]



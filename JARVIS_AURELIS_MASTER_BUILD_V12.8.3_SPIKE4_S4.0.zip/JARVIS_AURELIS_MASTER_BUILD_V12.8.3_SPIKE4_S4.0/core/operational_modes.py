"""Safety-critical operational mode registry with simulation-first semantics."""
from __future__ import annotations

from enum import StrEnum


class OperationalMode(StrEnum):
    NORMAL = "normal"
    TRAINING = "training"
    SIMULATION = "simulation"
    EMERGENCY = "emergency"
    SEARCH_AND_RESCUE = "search_and_rescue"
    DISASTER_RESPONSE = "disaster_response"
    HAZARDOUS_ENVIRONMENT = "hazardous_environment"


class OperationalModeController:
    """Fail-closed mode transitions; no offensive/combat mode exists."""

    def __init__(self) -> None:
        self._mode = OperationalMode.NORMAL

    @property
    def mode(self) -> OperationalMode:
        return self._mode

    def set_mode(self, mode: OperationalMode, *, human_authorized: bool, simulation_only: bool = False) -> OperationalMode:
        if not human_authorized:
            raise PermissionError("human authorization required for operational mode changes")
        if mode is OperationalMode.SIMULATION and not simulation_only:
            raise ValueError("simulation mode requires simulation_only=True")
        self._mode = OperationalMode(mode)
        return self._mode

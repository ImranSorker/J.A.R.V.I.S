"""Cross-platform GPU discovery/runtime state.

Detection is intentionally read-only: inference placement remains owned by
model backends. NVIDIA is queried through pynvml when available; AMD is
queried through rocm-smi when installed.
"""
from __future__ import annotations
from typing import Any
import logging

logger = logging.getLogger("jarvis.multi_gpu")


class MultiGPURuntime:
    def __init__(self):
        self._gpus: list[dict[str, Any]] = []
        self._shutdown = False
        self.refresh()

    def refresh(self) -> list[dict[str, Any]]:
        if self._shutdown: return list(self._gpus)
        gpus=[]
        try:
            import pynvml
            pynvml.nvmlInit()
            try:
                for i in range(pynvml.nvmlDeviceGetCount()):
                    h=pynvml.nvmlDeviceGetHandleByIndex(i); mem=pynvml.nvmlDeviceGetMemoryInfo(h); util=pynvml.nvmlDeviceGetUtilizationRates(h)
                    name=pynvml.nvmlDeviceGetName(h); name=name.decode() if isinstance(name,bytes) else str(name)
                    gpus.append({"index":i,"vendor":"nvidia","name":name,"memory_total":mem.total,"memory_used":mem.used,"utilization":util.gpu})
            finally:
                try: pynvml.nvmlShutdown()
                except Exception as exc:
                    logger.debug("pynvml_shutdown_failed", exc_info=exc)
        except Exception as exc:
            logger.debug("nvidia_gpu_discovery_unavailable", exc_info=exc)
        if not gpus:
            try:
                from core.trusted_process import TrustedProcessAdapter
                runner = TrustedProcessAdapter("data/workspace", timeout_seconds=3, max_memory_mb=128, allow_network=False)
                result = runner.run(("rocm-smi", "--showproductname", "--showmeminfo", "vram", "--showuse"), allowed_executables=("rocm-smi",))
                if result.ok:
                    for i,line in enumerate(result.stdout.splitlines()):
                        if "GPU" in line or "Product Name" in line:
                            gpus.append({"index":i,"vendor":"amd","name":line.strip(),"raw":line.strip()})
            except Exception as exc:
                logger.debug("rocm_gpu_discovery_unavailable", exc_info=exc)
        self._gpus=gpus
        return list(gpus)

    def get_stats(self) -> dict[str, Any]:
        return {"gpus": len(self._gpus), "status": "stopped" if self._shutdown else ("ready" if self._gpus else "standby"), "devices": list(self._gpus)}

    def shutdown(self) -> None:
        self._shutdown = True
        self._gpus.clear()



"""Atomic, restart-survivable checkpoints for long-running operations."""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from threading import RLock
from typing import Any


class CheckpointManager:
    """Persist named checkpoints atomically and retrieve the newest valid state."""

    def __init__(self, path: str = "data/checkpoints") -> None:
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()

    def save(self, name: str, state: dict[str, Any]) -> Path:
        """Atomically save a checkpoint and return its path.

        Nanosecond timestamps avoid same-second collisions while retaining the
        historical ``<name>_<timestamp>.json`` filename contract.
        """
        if not name.strip():
            raise ValueError("checkpoint name is required")
        if not isinstance(state, dict):
            raise TypeError("checkpoint state must be a dictionary")
        timestamp = time.time_ns()
        target = self.path / f"{name}_{timestamp}.json"
        with self._lock:
            fd, temporary = tempfile.mkstemp(prefix=f".{name}_", suffix=".tmp", dir=str(self.path))
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(state, handle, ensure_ascii=False, sort_keys=True, default=str)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, target)
            finally:
                try:
                    os.unlink(temporary)
                except FileNotFoundError as exc:
                    _ = exc
        return target

    def latest(self, name: str) -> dict[str, Any] | None:
        """Return the newest valid checkpoint for ``name`` or ``None``."""
        if not name.strip():
            raise ValueError("checkpoint name is required")
        with self._lock:
            files = sorted(self.path.glob(f"{name}_*.json"), key=lambda item: item.stat().st_mtime_ns, reverse=True)
            for checkpoint in files:
                try:
                    with checkpoint.open(encoding="utf-8") as handle:
                        value = json.load(handle)
                    if isinstance(value, dict):
                        return value
                except (OSError, ValueError, TypeError):
                    continue
        return None



"""Backend Health State Machine — proper HALF_OPEN/PROBE for model backends.

Replaces the naive circuit breaker with a full health state machine
that probes backends before restoring traffic.

States:
    HEALTHY   -> All traffic allowed
    DEGRADED  -> Traffic allowed with warnings
    UNHEALTHY -> Traffic blocked, periodic probes
    PROBING   -> Limited probe traffic to test recovery

Architecture:
    HealthProbe (periodic check)
      -> BackendHealthStateMachine
      -> Traffic routing decision
      -> Metrics emission
"""
from __future__ import annotations

import enum
import logging
import math
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("jarvis.backend_health")


class BackendState(enum.Enum):
    """Health state of a backend."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    PROBING = "probing"


@dataclass
class HealthProbeResult:
    """Result of a single health probe."""
    backend_name: str
    healthy: bool
    latency_ms: float
    error: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


@dataclass
class BackendHealthConfig:
    """Configuration for backend health monitoring."""
    probe_interval_seconds: float = 30.0
    probe_timeout_seconds: float = 10.0
    failure_threshold: int = 3
    success_threshold: int = 2
    degraded_threshold: int = 1
    recovery_timeout_seconds: float = 60.0
    max_probe_traffic_percent: float = 10.0

    def __post_init__(self) -> None:
        for name in ("probe_interval_seconds", "probe_timeout_seconds", "recovery_timeout_seconds"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and > 0")
        for name in ("failure_threshold", "success_threshold", "degraded_threshold"):
            value = getattr(self, name)
            if isinstance(value, bool) or int(value) < 1:
                raise ValueError(f"{name} must be a positive integer")


class BackendHealthStateMachine:
    """Per-backend health state machine with proper probing."""

    def __init__(self, backend_name: str, config: Optional[BackendHealthConfig] = None) -> None:
        self.backend_name = backend_name
        self.config = config or BackendHealthConfig()
        self.state = BackendState.HEALTHY
        self.consecutive_failures = 0
        self.consecutive_successes = 0
        self.last_probe_time = 0.0
        self.last_failure_time = 0.0  # wall-clock timestamp for external diagnostics
        self._last_failure_monotonic: float | None = None  # elapsed-time clock only
        self.total_requests = 0
        self.failed_requests = 0
        self._lock = threading.RLock()

    def record_probe(self, result: HealthProbeResult) -> None:
        """Record a health probe result and update state."""
        with self._lock:
            wall_now = time.time()
            monotonic_now = time.monotonic()
            self.last_probe_time = wall_now

            if result.healthy:
                self.consecutive_successes += 1
                self.consecutive_failures = 0

                if self.state == BackendState.UNHEALTHY:
                    # Move to probing after recovery timeout
                    if (self._last_failure_monotonic is not None and
                            monotonic_now - self._last_failure_monotonic >= self.config.recovery_timeout_seconds):
                        self.state = BackendState.PROBING
                        logger.info(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "unhealthy", "to": "probing"},
                        )
                elif self.state == BackendState.PROBING:
                    if self.consecutive_successes >= self.config.success_threshold:
                        self.state = BackendState.HEALTHY
                        logger.info(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "probing", "to": "healthy"},
                        )
                elif self.state == BackendState.DEGRADED:
                    if self.consecutive_successes >= self.config.success_threshold:
                        self.state = BackendState.HEALTHY
                        logger.info(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "degraded", "to": "healthy"},
                        )
            else:
                self.consecutive_failures += 1
                self.consecutive_successes = 0
                self.last_failure_time = wall_now
                self._last_failure_monotonic = monotonic_now

                if self.state == BackendState.HEALTHY:
                    if self.consecutive_failures >= self.config.degraded_threshold:
                        self.state = BackendState.DEGRADED
                        logger.warning(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "healthy", "to": "degraded"},
                        )
                    if self.consecutive_failures >= self.config.failure_threshold:
                        self.state = BackendState.UNHEALTHY
                        logger.error(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "healthy", "to": "unhealthy"},
                        )
                elif self.state == BackendState.DEGRADED:
                    if self.consecutive_failures >= self.config.failure_threshold:
                        self.state = BackendState.UNHEALTHY
                        logger.error(
                            "backend_state_changed",
                            extra={"backend": self.backend_name, "from": "degraded", "to": "unhealthy"},
                        )
                elif self.state == BackendState.PROBING:
                    self.state = BackendState.UNHEALTHY
                    logger.error(
                        "backend_state_changed",
                        extra={"backend": self.backend_name, "from": "probing", "to": "unhealthy"},
                    )

    def record_request(self, success: bool) -> None:
        """Record a request outcome."""
        with self._lock:
            self.total_requests += 1
            if not success:
                self.failed_requests += 1

    def can_serve(self) -> bool:
        """Check if backend can serve traffic."""
        with self._lock:
            return self.state in (BackendState.HEALTHY, BackendState.DEGRADED, BackendState.PROBING)

    def is_probe_only(self) -> bool:
        """Check if backend should only receive probe traffic."""
        with self._lock:
            return self.state == BackendState.PROBING

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            total = max(self.total_requests, 1)
            return {
                "backend": self.backend_name,
                "state": self.state.value,
                "consecutive_failures": self.consecutive_failures,
                "consecutive_successes": self.consecutive_successes,
                "total_requests": self.total_requests,
                "failed_requests": self.failed_requests,
                "error_rate": self.failed_requests / total,
                "last_probe_time": self.last_probe_time,
                "last_failure_time": self.last_failure_time,
            }


class BackendHealthRegistry:
    """Registry of backend health state machines."""

    def __init__(self) -> None:
        self._backends: Dict[str, BackendHealthStateMachine] = {}
        self._lock = threading.RLock()

    def register(
        self,
        backend_name: str,
        config: Optional[BackendHealthConfig] = None,
    ) -> BackendHealthStateMachine:
        with self._lock:
            if backend_name not in self._backends:
                self._backends[backend_name] = BackendHealthStateMachine(backend_name, config)
            return self._backends[backend_name]

    def get(self, backend_name: str) -> Optional[BackendHealthStateMachine]:
        with self._lock:
            return self._backends.get(backend_name)

    def record_probe(self, backend_name: str, result: HealthProbeResult) -> None:
        backend = self.get(backend_name)
        if backend:
            backend.record_probe(result)

    def can_serve(self, backend_name: str) -> bool:
        backend = self.get(backend_name)
        if backend is None:
            return True  # Unknown backend = allow (fail-open for discovery)
        return backend.can_serve()

    def is_probe_only(self, backend_name: str) -> bool:
        backend = self.get(backend_name)
        if backend is None:
            return False
        return backend.is_probe_only()

    def all_stats(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            return {name: backend.get_stats() for name, backend in self._backends.items()}

    def healthy_backends(self) -> List[str]:
        with self._lock:
            return [
                name for name, backend in self._backends.items()
                if backend.state == BackendState.HEALTHY
            ]

    def start_probe_loop(
        self,
        probe_func: Callable[[str], HealthProbeResult],
        interval_seconds: float = 30.0,
    ) -> threading.Thread:
        """Start a background thread that probes all backends periodically."""
        def loop() -> None:
            while True:
                with self._lock:
                    backends = list(self._backends.keys())
                for name in backends:
                    try:
                        result = probe_func(name)
                        self.record_probe(name, result)
                    except Exception:
                        logger.exception("probe_failed", extra={"backend": name})
                time.sleep(interval_seconds)

        thread = threading.Thread(target=loop, name="backend-health-probe", daemon=True)
        thread.start()
        return thread



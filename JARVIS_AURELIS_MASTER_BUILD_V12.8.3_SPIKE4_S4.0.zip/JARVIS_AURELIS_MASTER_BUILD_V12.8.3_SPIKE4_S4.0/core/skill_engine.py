"""Signed/permissioned skill metadata layer."""
from __future__ import annotations
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

@dataclass(frozen=True, slots=True)
class SkillManifest:
    """Immutable skill declaration."""
    skill_id: str
    version: str
    capabilities: tuple[str, ...]
    payload_sha256: str
    signature: bytes

class SkillEngine:
    """Verify signed skill payloads before they enter the plugin ecosystem."""
    def verify(self, manifest: SkillManifest, payload: bytes, public_key: bytes) -> bool:
        """Return true only when payload digest and Ed25519 signature both verify."""
        import hashlib
        if hashlib.sha256(payload).hexdigest() != manifest.payload_sha256:
            return False
        try:
            Ed25519PublicKey.from_public_bytes(public_key).verify(manifest.signature, payload)
            return True
        except ValueError:
            return False
        except Exception:
            return False



"""Process-isolated plugin lifecycle manager."""
from __future__ import annotations
import ast, logging, re
from pathlib import Path
from typing import Any, Dict, Optional
from core.plugin_isolation import PluginIsolationError, PluginIsolationManager, PluginManifest
from core.plugin_policy import PluginPolicy
try:
    from core.kernel_12_8_0.contracts import CapabilityRequest
except ImportError:
    CapabilityRequest = None
logger=logging.getLogger("jarvis.plugins")
class PluginLoadError(Exception):
    """Raised when an extension cannot be loaded safely."""
class PluginManager:
    """Discover, validate and execute plugins outside the JARVIS process."""
    def __init__(self,plugin_dir:str="./plugins",isolation_manager:Optional[PluginIsolationManager]=None, capability_policy:Any=None)->None:
        self.plugin_dir=Path(plugin_dir).resolve(); self.plugin_dir.mkdir(parents=True,exist_ok=True)
        self._isolation=isolation_manager or PluginIsolationManager(str(self.plugin_dir/".isolated")); self._loaded_plugins:Dict[str,Any]={}; self._manifests:Dict[str,PluginManifest]={}; self._tool_registry=None; self._capability_policy=capability_policy or PluginPolicy()
    def set_tool_registry(self,registry:Any)->None:self._tool_registry=registry
    def discover_plugins(self)->list[str]:return sorted(p.stem for p in self.plugin_dir.glob("*.py") if not p.name.startswith("_"))
    def _validate_source(self,name:str,path:Path)->None:
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,63}",name):raise PluginLoadError("invalid plugin name")
        try:tree=ast.parse(path.read_text(encoding="utf-8"),filename=str(path))
        except (OSError,SyntaxError) as exc:raise PluginLoadError(f"invalid plugin source: {exc}") from exc
        if not any(isinstance(node,ast.ClassDef) and node.name=="Plugin" for node in tree.body):raise PluginLoadError(f"No Plugin class found in {name}")
    def _declared_capabilities(self, path: Path) -> tuple[str, ...]:
        """Read an optional literal PLUGIN_REQUIRED_CAPABILITIES declaration."""
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (OSError, SyntaxError) as exc:
            raise PluginLoadError(f"invalid plugin source: {exc}") from exc
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "PLUGIN_REQUIRED_CAPABILITIES":
                        try:
                            value = ast.literal_eval(node.value)
                        except Exception as exc:
                            raise PluginLoadError("PLUGIN_REQUIRED_CAPABILITIES must be a literal sequence") from exc
                        if not isinstance(value, (list, tuple)):
                            raise PluginLoadError("PLUGIN_REQUIRED_CAPABILITIES must be a list or tuple")
                        return tuple(str(item).strip() for item in value)
        return ()

    def _authorize_capabilities(self, plugin_name: str, capabilities: tuple[str, ...]) -> bool:
        if not capabilities:
            return True
        policy = self._capability_policy
        checker = getattr(policy, "check", None)
        if callable(checker):
            return bool(checker(capabilities))
        evaluator = getattr(policy, "evaluate", None)
        if callable(evaluator) and CapabilityRequest is not None:
            return all(bool(evaluator(CapabilityRequest(capability=cap, reason=f"plugin:{plugin_name}", principal="plugin-manager", resource=plugin_name)).allowed) for cap in capabilities)
        if callable(policy):
            return all(bool(policy(cap, plugin_name)) for cap in capabilities)
        return False

    def load_plugin(self,plugin_name:str)->Any:
        if plugin_name in self._loaded_plugins:return self._loaded_plugins[plugin_name]
        path=(self.plugin_dir/f"{plugin_name}.py").resolve()
        if path.parent!=self.plugin_dir or not path.is_file():raise PluginLoadError("Plugin not found")
        self._validate_source(plugin_name,path)
        declared = self._declared_capabilities(path)
        if not self._authorize_capabilities(plugin_name, declared):
            raise PluginLoadError(f"plugin capabilities denied: {plugin_name}: {sorted(declared)}")
        isolated_source=self._isolation._base/plugin_name/"1.0.0"/"main.py"
        isolated_source.parent.mkdir(parents=True,exist_ok=True); isolated_source.write_text(path.read_text(encoding="utf-8"),encoding="utf-8")
        manifest=PluginManifest(name=plugin_name,version="1.0.0",entry_point="main.py", required_capabilities=declared)
        try:
            sandbox=self._isolation.create_sandbox(manifest); self._loaded_plugins[plugin_name]=sandbox; self._manifests[plugin_name]=manifest
            if not sandbox.start():
                self._loaded_plugins.pop(plugin_name,None); self._manifests.pop(plugin_name,None); raise PluginLoadError(f"Plugin {plugin_name} failed to start")
            return sandbox
        except PluginIsolationError as exc:raise PluginLoadError(str(exc)) from exc
    def load_all(self)->Dict[str,Any]:
        result={}
        for name in self.discover_plugins():
            try:result[name]=self.load_plugin(name)
            except PluginLoadError:logger.exception("plugin_load_failed",extra={"plugin":name})
        return result
    def unload_plugin(self,plugin_name:str)->bool:
        sandbox=self._loaded_plugins.pop(plugin_name,None); self._manifests.pop(plugin_name,None)
        return bool(sandbox is not None and sandbox.stop())
    def shutdown(self)->None:
        for name in list(self._loaded_plugins):self.unload_plugin(name)



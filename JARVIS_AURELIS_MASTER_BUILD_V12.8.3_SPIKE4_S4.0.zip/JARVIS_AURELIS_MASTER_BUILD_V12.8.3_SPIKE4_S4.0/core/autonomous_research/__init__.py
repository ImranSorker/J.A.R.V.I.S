"""P2-R Autonomous Research System.

Evidence-driven, bounded, provenance-first research pipeline. P2-R produces
signed artifacts and proposals; it never applies memory, world-state, or plan
updates directly.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import json
import logging
import re
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidationError, SchemaValidator

logger = logging.getLogger(__name__)

VERSION = "12.8.3"
PIPELINE_VERSION = "1.0.0"
SCHEMA_VERSION = 1

QUESTION_CLASSES = frozenset({"factual_lookup", "comparative", "causal", "predictive", "methodological", "exploratory", "verification", "synthesis", "adversarial", "gap_analysis"})
SOURCE_CLASSES = frozenset({"primary_evidence", "primary_document", "secondary_analysis", "tertiary_reference", "internal_knowledge", "internal_artifact", "external_api", "external_web", "user_provided", "simulated"})
CLAIM_KINDS = frozenset({"assertion", "measurement", "relationship", "causal_claim", "temporal", "prediction", "negation", "uncertainty"})
CONFIDENCE_LEVELS = ("established", "supported", "disputed", "preliminary", "speculative", "unknown", "refuted")
OUTCOMES = frozenset({"answered", "partially_answered", "unanswered", "disputed", "refused", "failed", "cancelled", "timed_out"})
MODES = frozenset({"single_pass", "iterative", "adversarial", "team"})
TRUST_TIERS = ("authoritative", "reliable", "moderate", "weak", "unknown", "excluded")
CONTRADICTION_KINDS = frozenset({"factual", "methodological", "temporal", "interpretive", "definitional", "scope"})
EDGE_KINDS = frozenset({"supports", "contradicts", "derives", "cites", "same_as"})

DEFAULT_MODE = {
    "factual_lookup": "single_pass", "comparative": "iterative", "causal": "iterative",
    "predictive": "iterative", "methodological": "iterative", "exploratory": "single_pass",
    "verification": "adversarial", "synthesis": "iterative", "adversarial": "adversarial", "gap_analysis": "adversarial",
}
CALIBRATION_WEIGHTS = {"source_reliability": 0.45, "independence": 0.20, "contradiction": 0.20, "primary_bonus": 0.15}
FORBIDDEN_PATTERNS = (
    ("medical_advice", re.compile(r"\b(diagnos(?:e|is|ing)|prescribe|medical advice|treatment plan)\b", re.I)),
    ("legal_advice", re.compile(r"\b(legal advice|tell me how to sue|legal strategy|lawyer strategy)\b", re.I)),
    ("financial_advice", re.compile(r"\b(financial advice|buy this stock|guaranteed return|investment advice)\b", re.I)),
    ("harm_instructions", re.compile(r"\b(how to (make|build|deploy).*(weapon|bomb|malware)|harm someone|poison someone)\b", re.I)),
)
DANGEROUS_TERMS = re.compile(r"\b(destructive|irreversible|financial|identity|device|communication|harm|weapon|malware|system change)\b", re.I)

EVENTS = (
    "Research.Submitted", "Research.DecompositionCompleted", "Research.SearchExecuted", "Research.SourceCollected",
    "Research.EvidenceExtracted", "Research.CrossCheckCompleted", "Research.ContradictionDetected", "Research.ContradictionResolved",
    "Research.ContradictionUnresolved", "Research.EvidenceGraphBuilt", "Research.SynthesisCompleted", "Research.ConfidenceCalibrated",
    "Research.Verified", "Research.VerificationFailed", "Research.ProposalsEmitted", "Research.Refused", "Research.Completed",
    "Research.Failed", "Research.Cancelled", "Research.TimedOut", "Research.ReplayDivergence",
)


class ResearchError(RuntimeError):
    """Base P2-R error."""
class ResearchPolicyDenied(ResearchError, PermissionError):
    """Research policy refused the request."""
class ResearchBudgetExceeded(ResearchError):
    """Research exceeded a bounded budget."""
class ResearchGroundingError(ResearchError):
    """Claim grounding could not be positively established."""
class ResearchContradictionError(ResearchError):
    """Evidence graph contradiction handling failed."""
class ResearchReplayDivergence(ResearchError):
    """Deterministic replay differed from the stored artifact."""
class ResearchVerificationError(ResearchError):
    """P2-N verification failed or was unavailable."""
class ResearchNotFound(ResearchError, KeyError):
    """A requested research artifact does not exist."""
    def __init__(self, research_id: str) -> None:
        self.research_id = str(research_id)
        super().__init__(f"research artifact not found: {self.research_id}")


def _uuid() -> str:
    return str(uuid.uuid4())

def _now() -> float:
    return time.time()

def _rfc3339(ts: float | None = None) -> str:
    return datetime.fromtimestamp(_now() if ts is None else float(ts), tz=timezone.utc).isoformat().replace("+00:00", "Z")

def _sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()

def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")

def _sign_document(value: Mapping[str, Any], key: Ed25519PrivateKey) -> tuple[str, str]:
    body = copy.deepcopy(dict(value))
    body.pop("signature", None)
    body.pop("integrity_hash", None)
    body.pop("content_addressed_ref", None)
    prov=body.get("provenance")
    if isinstance(prov,dict):
        prov.pop("artifact_ref", None)
    digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
    signed = dict(body)
    signed["integrity_hash"] = digest
    return _b64(key.sign(canonical_json(signed))), digest

def _verify_document(value: Mapping[str, Any], public_key: Ed25519PublicKey) -> bool:
    try:
        body = copy.deepcopy(dict(value)); signature = str(body.pop("signature")); expected = str(body.pop("integrity_hash"))
        body.pop("content_addressed_ref", None)
        prov=body.get("provenance")
        if isinstance(prov,dict):
            prov.pop("artifact_ref", None)
        digest = hashlib.sha256(canonical_bytes(body)).hexdigest()
        if digest != expected: return False
        signed = dict(body); signed["integrity_hash"] = digest
        public_key.verify(base64.b64decode(signature, validate=True), canonical_json(signed)); return True
    except Exception:
        return False

def _norm(s: Any) -> str:
    return re.sub(r"\W+", " ", str(s).lower()).strip()

@dataclass(frozen=True, slots=True)
class ResearchRequest:
    request_id: str
    request_version: int
    tenant_id: str
    question: str
    question_class: str
    sub_questions_hint: tuple[str, ...] | None = None
    scope_constraints: tuple[Mapping[str, Any], ...] = ()
    excluded_sources: tuple[str, ...] = ()
    required_source_classes: tuple[str, ...] = ()
    required_outputs: Mapping[str, Any] = field(default_factory=dict)
    forbidden_claims: tuple[str, ...] = ()
    mode: str = "single_pass"
    max_depth: int = 2
    max_iterations: int = 1
    simulation_required: bool = False
    evidence: Mapping[str, Any] = field(default_factory=dict)
    requested_by: Mapping[str, str] = field(default_factory=dict)
    requested_at: str = ""
    authorization_ref: str | None = None
    signature: str = ""
    integrity_hash: str = ""

@dataclass(frozen=True, slots=True)
class StageRecord:
    stage: str
    status: str
    started_at: str
    finished_at: str
    input_hash: str
    output_hash: str
    skipped_reason: str | None
    signature: str
    integrity_hash: str

@dataclass(frozen=True, slots=True)
class SourceRecord:
    source_id: str
    source_class: str
    uri: str
    retrieved_at: str
    content_hash: str
    content_size: int
    trust_tier: str
    author: str | None
    publisher: str | None
    publication_date: str | None
    reliability: float
    bias_flags: tuple[str, ...] = ()
    license: str | None = None
    notes: str | None = None

@dataclass(frozen=True, slots=True)
class ClaimRecord:
    claim_id: str
    kind: str
    statement: str
    entities: tuple[Any, ...]
    relationship: str | None
    measurement: Mapping[str, Any] | None
    temporal: Mapping[str, Any] | None
    confidence: str
    confidence_score: float
    supporting_evidence: tuple[str, ...]
    contradicting_evidence: tuple[str, ...]
    derivations: tuple[str, ...]
    caveats: tuple[str, ...]
    source_id: str
    span: Mapping[str, Any]
    claim_key: str

@dataclass(frozen=True, slots=True)
class EvidenceNode:
    node_id: str
    node_kind: str
    ref: str
    node_hash: str
    provenance: tuple[str, ...]

@dataclass(frozen=True, slots=True)
class EvidenceEdge:
    edge_id: str
    from_node: str
    to_node: str
    kind: str
    strength: float
    rationale_ref: str | None
    signed_by: str

@dataclass(frozen=True, slots=True)
class EvidenceGraph:
    graph_id: str
    nodes: tuple[EvidenceNode, ...]
    edges: tuple[EvidenceEdge, ...]
    acyclic: bool
    graph_hash: str

@dataclass(frozen=True, slots=True)
class ContradictionRecord:
    contradiction_id: str
    claim_refs: tuple[str, ...]
    nature: str
    evidence_refs: tuple[str, ...]
    status: str
    resolution_ref: str | None

class AutonomousResearchSystem:
    """Canonical P2-R bounded research pipeline."""
    STAGES = ("decomposition", "search", "source_collection", "evidence_extraction", "cross_check", "contradiction_analysis", "evidence_graph", "synthesis", "confidence", "verification", "proposal_emission")

    def __init__(
        self, *, model_fabric: Any | None = None, tool_fabric: Any | None = None, experience_memory: Any | None = None,
        world_model: Any | None = None, verifier: Any | None = None, simulation: Any | None = None, orchestration: Any | None = None,
        failure_intelligence: Any | None = None, event_fabric: Any | None = None, root: str | Path = "./data/autonomous_research",
        reasoning_provider: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
        embedding_provider: Callable[[str], Sequence[float]] | None = None,
        reranker_provider: Callable[[str, Sequence[Mapping[str, Any]]], Sequence[Mapping[str, Any]]] | None = None,
        search_provider: Callable[[str, Mapping[str, Any]], Sequence[Mapping[str, Any]]] | None = None,
        fetch_provider: Callable[[str, Mapping[str, Any]], Mapping[str, Any]] | None = None,
        team_provider: Callable[[Mapping[str, Any]], Sequence[Mapping[str, Any]]] | None = None,
        grounding_verifier: Callable[[Mapping[str, Any], Mapping[str, Any]], bool] | None = None,
        research_verifier: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
        time_provider: Callable[[], float] | None = None,
        authorization_checker: Callable[[Mapping[str, Any]], bool] | None = None,
    ) -> None:
        self.model_fabric=model_fabric; self.tool_fabric=tool_fabric; self.experience_memory=experience_memory; self.world_model=world_model
        self.verifier=verifier; self.simulation=simulation; self.orchestration=orchestration; self.failure_intelligence=failure_intelligence; self.event_fabric=event_fabric
        self.reasoning_provider=reasoning_provider; self.embedding_provider=embedding_provider; self.reranker_provider=reranker_provider; self.search_provider=search_provider; self.fetch_provider=fetch_provider
        self.grounding_verifier=grounding_verifier; self.research_verifier=research_verifier; self.authorization_checker=authorization_checker; self.team_provider=team_provider
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True); (self.root/"artifacts").mkdir(exist_ok=True); (self.root/"replay").mkdir(exist_ok=True); (self.root/"sources").mkdir(exist_ok=True)
        self._time=time_provider or _now; self._signer=Ed25519PrivateKey.generate(); self._public=self._signer.public_key(); from cryptography.hazmat.primitives import serialization
        self.key_id=hashlib.sha256(self._public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).hexdigest()[:16]
        self._schema=SchemaValidator(); self._requests={}; self._started={}; self._artifacts={}; self._stages={}; self._replay={}; self._usage={}; self._models_used={}; self._iterations_used={}; self._lock=threading.RLock()
        self._trust_rules={"primary_evidence":"authoritative","primary_document":"authoritative","secondary_analysis":"reliable","tertiary_reference":"moderate","internal_knowledge":"reliable","internal_artifact":"reliable","external_api":"reliable","external_web":"unknown","user_provided":"unknown","simulated":"unknown"}
        self._trust_version="1.0.0"; self._trust_seed_key_id=None; self._load_trust_seed()
        self._search_tools=(); self._reasoning_models=(); self._embedding_models=(); self._reranker_models=()


    def _load_trust_seed(self) -> None:
        manifest_path=Path(__file__).with_name("trust_tier_seed_manifest.json")
        if not manifest_path.exists(): raise ResearchError("missing trust-tier seed manifest")
        manifest=json.loads(manifest_path.read_text(encoding="utf-8")); self._trust_seed_key_id=str(manifest["key_id"])
        pub=Ed25519PublicKey.from_public_bytes(bytes.fromhex(str(manifest["public_key_hex"])))
        for row in manifest.get("rules",[]):
            path=Path(__file__).parent / str(row["path"]).split("autonomous_research/",1)[-1] if "autonomous_research/" in str(row["path"]) else Path(__file__).parent / Path(str(row["path"])).name
            # canonical path is trust_tiers/<class>/<version>/rule.json
            rel=Path(str(row["path"]))
            path=Path(__file__).parent / rel.relative_to("core/autonomous_research")
            data=json.loads(path.read_text(encoding="utf-8")); sig=str(data.pop("signature")); key_id=str(data.pop("signing_key_id")); expected=str(data.pop("integrity_hash"))
            digest=hashlib.sha256(canonical_bytes(data)).hexdigest()
            if key_id!=self._trust_seed_key_id or digest!=expected: raise ResearchError(f"trust-tier seed integrity failure: {path}")
            pub.verify(base64.b64decode(sig,validate=True),canonical_bytes({**data,"integrity_hash":digest}))
            self._trust_rules[str(data["source_class"])]=str(data["tier"])
            self._trust_version=str(data["version"])

    @property
    def public_key(self) -> Ed25519PublicKey: return self._public

    @property
    def events(self) -> tuple[str, ...]: return EVENTS

    def _emit(self, event: str, payload: Mapping[str, Any], *, correlation_id: str | None = None, causation_id: str | None = None) -> None:
        if event not in EVENTS: raise ResearchError(f"unregistered research event: {event}")
        data={"event":event,"payload":copy.deepcopy(dict(payload)),"correlation_id":correlation_id,"causation_id":causation_id,"emitted_at":_rfc3339(self._time()),"producer":"core.autonomous_research","pipeline_version":PIPELINE_VERSION}
        if self.event_fabric is not None:
            self.event_fabric.publish(event, data, correlation_id=correlation_id, causation_id=causation_id)

    def _auth(self, context: Any) -> Mapping[str, Any]:
        if context is None: raise ResearchPolicyDenied("valid P2-E ExecutionContext is required")
        auth=getattr(context,"auth_context",None)
        if auth is None: auth=getattr(context,"authorization",None)
        if auth is None and isinstance(context,Mapping): auth=context.get("auth_context",context.get("authorization"))
        if auth is None: raise ResearchPolicyDenied("execution context lacks authorization context")
        return auth if isinstance(auth,Mapping) else {"principal":getattr(auth,"principal","unknown"),"scopes":getattr(auth,"scopes",())}

    def _schema_for(self, name: str) -> dict[str, Any]:
        p=Path(__file__).resolve().parents[1]/"schemas"/name
        if not p.exists(): raise ResearchError(f"missing schema: {name}")
        return json.loads(p.read_text(encoding="utf-8"))

    def _validate(self, value: Any, schema_name: str) -> None:
        try: self._schema.validate_or_raise(value,self._schema_for(schema_name))
        except SchemaValidationError as exc: raise ResearchError(f"schema validation failed: {schema_name}: {exc}") from exc

    def _signed(self, doc: Mapping[str, Any]) -> dict[str, Any]:
        body=dict(doc); sig,digest=_sign_document(body,self._signer); body["integrity_hash"]=digest; body["signature"]=sig; return body

    def _request_doc(self, request: Mapping[str, Any]) -> dict[str, Any]:
        doc=dict(request); doc.setdefault("request_id",_uuid()); doc.setdefault("request_version",1); doc.setdefault("requested_at",_rfc3339(self._time())); doc.setdefault("signature",""); doc.setdefault("integrity_hash","")
        signed=self._signed(doc); self._validate(signed,"research_request_v1.schema.json"); return signed

    def _policy_check(self, req: Mapping[str, Any]) -> tuple[bool,str|None,bool]:
        question=str(req["question"])
        for code,pat in FORBIDDEN_PATTERNS:
            if pat.search(question):
                if not req.get("authorization_ref"): return False,code,False
        dangerous=bool(req.get("simulation_required")) or bool(DANGEROUS_TERMS.search(question))
        if req.get("mode")=="adversarial" and not req.get("authorization_ref"): return False,"adversarial_authorization_required",dangerous
        if dangerous and self.authorization_checker is not None and not self.authorization_checker(req): return False,"dangerous_topic_authorization_failed",True
        if dangerous and not req.get("authorization_ref"):
            if self.simulation is None:
                return False,"simulation_or_authorization_required",True
            try:
                required=bool(self.simulation.mandate_required("system_change",()))
            except Exception:
                required=True
            if required and not req.get("simulation_required"):
                return False,"simulation_or_authorization_required",True
        if req.get("simulation_required") and self.simulation is None and not req.get("authorization_ref"):
            return False,"simulation_adapter_required",True
        return True,None,dangerous

    def _model_call(self, run_id:str, req:Mapping[str,Any], context:Any, *, task:str, payload:Mapping[str,Any], role:str="reasoning") -> Mapping[str,Any] | None:
        if self.reasoning_provider is not None and role=="reasoning":
            out=dict(self.reasoning_provider({"role":role,"task":task,**dict(payload)})); self._account_model_usage(run_id,payload,out); return out
        if self.model_fabric is None: return None
        route_request={"request_id":_uuid(),"tenant_id":req["tenant_id"],"role":role,"required_capabilities":(role,),"execution_mode":"restricted","trust_floor":"verified","context_tokens_needed":max(256,min(32768,len(canonical_json(payload))//2+256)),"quality_floor":0.5,"latency_budget_ms":max(1.0,float(req["required_outputs"]["max_wall_seconds"])*1000.0),"cost_budget":float(req["required_outputs"]["max_cost_units"]),"privacy_required":True,"determinism_required":True}
        decision=self.model_fabric.route(route_request,context=context); model_ref=str(decision.get("chosen_model_ref") if isinstance(decision,Mapping) else getattr(decision,"chosen_model_ref"))
        self._models_used.setdefault(run_id,[]).append(model_ref)
        out=self.model_fabric.invoke(model_ref,{"task":task,**dict(payload)},context=context,tenant_id=req["tenant_id"]); out=dict(out) if isinstance(out,Mapping) else {"result":out}; self._account_model_usage(run_id,payload,out); return out

    def _account_model_usage(self,run_id:str,payload:Mapping[str,Any],output:Mapping[str,Any]) -> None:
        usage=self._usage.setdefault(run_id,{"tokens_in":0,"tokens_out":0,"cost_units":0.0})
        usage["tokens_in"] += int(output.get("tokens_in",max(0,len(canonical_json(payload))//4)))
        usage["tokens_out"] += int(output.get("tokens_out",max(0,len(canonical_json(output))//4)))
        usage["cost_units"] += float(output.get("cost_units",0.0))

    def _budget_check(self, started: float, req: Mapping[str, Any], sources: int, depth: int, tokens: int, cost: float) -> None:
        out=req["required_outputs"]
        if self._time()-started > float(out["max_wall_seconds"]): raise ResearchBudgetExceeded("wall-clock budget exceeded")
        if sources > int(out["max_sources"]): raise ResearchBudgetExceeded("source budget exceeded")
        if tokens > int(out["max_tokens"]): raise ResearchBudgetExceeded("token budget exceeded")
        if cost > float(out["max_cost_units"]): raise ResearchBudgetExceeded("cost budget exceeded")
        if depth > int(req["max_depth"]): raise ResearchBudgetExceeded("depth budget exceeded")

    def _record_stage(self, run_id: str, stage: str, input_value: Any, output_value: Any, status: str="completed", skipped_reason: str|None=None) -> StageRecord:
        start=self._time(); finish=self._time(); doc={"stage":stage,"status":status,"started_at":_rfc3339(start),"finished_at":_rfc3339(finish),"input_hash":_sha(input_value),"output_hash":_sha(output_value),"skipped_reason":skipped_reason}
        signed=self._signed(doc); rec=StageRecord(**signed); self._stages.setdefault(run_id,[]).append(rec); return rec

    def _persist_artifact(self, artifact: Mapping[str, Any]) -> None:
        rid=str(artifact["artifact_id"]); target=self.root/"artifacts"/f"{rid}.json"; target.write_text(json.dumps(dict(artifact),sort_keys=True,ensure_ascii=False,separators=(",",":")),encoding="utf-8")

    def _persist_source(self, source_id: str, content_hash: str, payload: Mapping[str, Any]) -> str:
        target=self.root/"sources"/f"{content_hash}.json"; target.write_text(json.dumps(dict(payload),sort_keys=True,ensure_ascii=False,separators=(",",":")),encoding="utf-8"); return f"cas://sha256/{content_hash}"

    def submit_research(self, request: Mapping[str, Any], *, context: Any) -> str:
        auth=self._auth(context)
        raw=dict(request)
        raw.setdefault("mode", DEFAULT_MODE.get(str(raw.get("question_class")), "single_pass"))
        raw.setdefault("simulation_required", False)
        raw.setdefault("evidence", {})
        raw["simulation_required"]=bool(raw.get("simulation_required"))
        raw["evidence"]={"min_independent_sources":2,"require_primary_for":[],"cross_check_required":True,"contradiction_check_required":True,**dict(raw.get("evidence",{}))}
        tenant_auth=auth.get("tenant_id") if isinstance(auth,Mapping) else None
        if tenant_auth is not None and str(raw.get("tenant_id")) != str(tenant_auth):
            raise ResearchPolicyDenied("tenant isolation violation")
        req=self._request_doc(raw)
        ok,reason,dangerous=self._policy_check(req)
        req["simulation_required"]=bool(req.get("simulation_required") or (dangerous and not req.get("authorization_ref")))
        if req["simulation_required"] != raw["simulation_required"]:
            req=self._request_doc(req)
        if not ok:
            artifact=self._refusal(req,reason or "policy_denied",dangerous)
            with self._lock:self._requests[req["request_id"]]=req; self._artifacts[artifact["artifact_id"]]=artifact
            self._persist_artifact(artifact); return artifact["artifact_id"]
        if req["mode"] not in MODES: raise ResearchError("invalid research mode")
        if req["mode"]=="adversarial" and not req.get("authorization_ref"): raise ResearchPolicyDenied("adversarial mode requires authorization_ref")
        run_id=_uuid(); self._emit("Research.Submitted",{"research_id":run_id,"request_id":req["request_id"],"question_class":req["question_class"],"mode":req["mode"]},correlation_id=run_id)
        with self._lock:self._requests[run_id]=req
        try:
            artifact=self._run(run_id,req,context=context,replay_bundle=None)
            with self._lock:self._artifacts[run_id]=artifact
            self._persist_artifact(artifact); return run_id
        except ResearchBudgetExceeded:
            artifact=self._terminal(req,run_id,"timed_out","research budget exceeded"); self._artifacts[run_id]=artifact; self._persist_artifact(artifact); self._emit("Research.TimedOut",{"research_id":run_id},correlation_id=run_id); return run_id
        except ResearchPolicyDenied as exc:
            artifact=self._terminal(req,run_id,"refused",str(exc)); self._artifacts[run_id]=artifact; self._persist_artifact(artifact); self._emit("Research.Refused",{"research_id":run_id,"reason":str(exc)},correlation_id=run_id); return run_id
        except Exception as exc:
            ingestion = self._forward_failure(run_id, req, exc, context)
            artifact=self._terminal(req,run_id,"failed",f"{type(exc).__name__}: {str(exc)[:240]}"); self._artifacts[run_id]=artifact; self._persist_artifact(artifact)
            failed_payload = {"research_id": run_id, "error": type(exc).__name__, "failure_ingestion_status": ingestion["status"]}
            if ingestion.get("error_type"):
                failed_payload["failure_ingestion_error_type"] = ingestion["error_type"]
            self._emit("Research.Failed",failed_payload,correlation_id=run_id); return run_id

    def _default_subquestions(self, question: str) -> list[dict[str,Any]]:
        return [{"sub_question_id":_uuid(),"text":question,"parent_id":None,"depth":0,"answer_ref":None,"outcome":"unanswered"}]

    def _decompose(self, run_id: str, req: Mapping[str,Any], context:Any) -> list[dict[str,Any]]:
        hints=req.get("sub_questions_hint")
        if hints: rows=[{"sub_question_id":_uuid(),"text":str(x),"parent_id":None,"depth":0,"answer_ref":None,"outcome":"unanswered"} for x in hints]
        elif self.reasoning_provider is not None or self.model_fabric is not None:
            result=self._model_call(run_id,req,context,task="decompose",payload={"question":req["question"],"max_depth":req["max_depth"],"seed":_sha({"question":req["question"],"seed":req["request_id"]})},role="reasoning") or {}
            rows=list(result.get("sub_questions",())) if isinstance(result,Mapping) else []
            rows=[{**dict(x),"sub_question_id":str(x.get("sub_question_id",_uuid())),"depth":int(x.get("depth",0))} for x in rows]
        else: rows=self._default_subquestions(str(req["question"]))
        rows=[x for x in rows if int(x.get("depth",0))<=int(req["max_depth"])]
        if not rows: raise ResearchError("decomposition produced no sub-questions")
        self._record_stage(run_id,"decomposition",req,rows); self._emit("Research.DecompositionCompleted",{"research_id":run_id,"count":len(rows)},correlation_id=run_id)
        return rows

    def _search(self, run_id:str, req:Mapping[str,Any], subs:Sequence[Mapping[str,Any]], context:Any) -> list[Mapping[str,Any]]:
        results=[]; seen=set()
        max_passes=1 if req.get("mode") in {"single_pass","adversarial","team"} else max(1,int(req.get("max_iterations",1)))
        for iteration in range(max_passes):
            self._iterations_used[run_id]=iteration+1
            for sub in subs:
                self._budget_check(self._started[run_id],req,len(results),int(sub.get("depth",0)),0,0.0)
                query=str(sub["text"])
                if req.get("mode")=="adversarial": query="evidence against: "+query
                if self.search_provider is not None: rows=self.search_provider(query,{**req,"iteration":iteration})
                elif self.tool_fabric is not None and self._search_tools:
                    from core.tool_fabric import DiscoveryRequest
                    dreq=DiscoveryRequest(request_id=_uuid(),tenant_id=req["tenant_id"],required_capabilities=("search",),excluded_tool_ids=tuple(req.get("excluded_sources",())),execution_mode="restricted")
                    discovery=self.tool_fabric.discover(dreq,context=context); selected=self.tool_fabric.select(dreq,discovery,context=context)
                    inv=self.tool_fabric.invoke({"tool_ref":selected.chosen_tool_ref,"input":{"query":query},"tenant_id":req["tenant_id"]},context=context)
                    rows=inv.outputs if isinstance(inv.outputs,list) else inv.outputs.get("results",()) if isinstance(inv.outputs,Mapping) else ()
                else: raise ResearchError("no search provider or configured P2-P search tool")
                if self.reranker_provider is not None:
                    rows=list(self.reranker_provider(query,list(rows)))
                self._emit("Research.SearchExecuted",{"research_id":run_id,"sub_question_id":sub["sub_question_id"],"query":query,"result_count":len(rows),"iteration":iteration},correlation_id=run_id)
                for row in rows:
                    uri=str(row.get("uri","")) if isinstance(row,Mapping) else str(row)
                    if not uri or uri in seen: continue
                    seen.add(uri); results.append(dict(row) if isinstance(row,Mapping) else {"uri":uri})
                    if len(results)>=int(req["required_outputs"]["max_sources"]): break
                if len(results)>=int(req["required_outputs"]["max_sources"]): break
            if len(results)>=int(req["required_outputs"]["max_sources"]): break
        self._record_stage(run_id,"search",subs,results); return results

    def _trust_tier(self, source_class:str, uri:str, publisher:str|None) -> str:
        base=self._trust_rules.get(source_class,"unknown")
        host=re.sub(r"^https?://","",uri).split("/",1)[0].lower()
        if source_class in {"primary_evidence","primary_document"}: return "authoritative"
        if host.endswith(".gov") or host.endswith(".edu"): return "reliable"
        return base

    def _collect_sources(self, run_id:str, req:Mapping[str,Any], candidates:Sequence[Mapping[str,Any]], context:Any) -> tuple[list[SourceRecord],dict[str,Mapping[str,Any]]]:
        sources=[]; bodies={}; by_hash={}
        for candidate in candidates:
            uri=str(candidate.get("uri",""));
            if not uri or any(pat in uri for pat in req.get("excluded_sources",())): continue
            if self.fetch_provider is not None: fetched=dict(self.fetch_provider(uri,req))
            else:
                fetched=dict(candidate)
                if "content" not in fetched:
                    if self.tool_fabric is None: raise ResearchError(f"source cannot be fetched: {uri}")
                    raise ResearchError("P2-P fetch adapter is not configured for this research run")
            content=str(fetched.get("content","")); h=hashlib.sha256(content.encode("utf-8")).hexdigest()
            if h in by_hash: continue
            sc=str(fetched.get("source_class",candidate.get("source_class","external_web")))
            if sc not in SOURCE_CLASSES: raise ResearchError(f"invalid source class: {sc}")
            author=fetched.get("author"); publisher=fetched.get("publisher"); tier=self._trust_tier(sc,uri,publisher)
            if tier=="excluded": continue
            rec=SourceRecord(_uuid(),sc,uri,_rfc3339(self._time()),h,len(content.encode()),tier,author,publisher,fetched.get("publication_date"),max(0.05,min(1.0,{"authoritative":0.95,"reliable":0.82,"moderate":0.65,"weak":0.35,"unknown":0.20,"excluded":0.0}[tier])),tuple(fetched.get("bias_flags",())),fetched.get("license"),fetched.get("notes"))
            sources.append(rec); by_hash[h]=rec.source_id; bodies[rec.source_id]={"content":content,**fetched}; self._persist_source(rec.source_id,h,bodies[rec.source_id])
            self._emit("Research.SourceCollected",{"research_id":run_id,"source_id":rec.source_id,"content_hash":h,"trust_tier":tier},correlation_id=run_id)
        self._record_stage(run_id,"source_collection",candidates,[asdict(s) for s in sources]); return sources,bodies

    def _extract_claims(self, run_id:str, req:Mapping[str,Any], sources:Sequence[SourceRecord], bodies:Mapping[str,Mapping[str,Any]], context:Any) -> list[ClaimRecord]:
        claims=[]
        for source in sources:
            payload=bodies[source.source_id]
            raw=payload.get("claims")
            if raw is None and (self.reasoning_provider is not None or self.model_fabric is not None):
                model_out=self._model_call(run_id,req,context,task="extract_claims",payload={"source_uri":source.uri,"source_content":payload["content"],"source_hash":source.content_hash},role="reasoning") or {}
                raw=model_out.get("claims",()) if isinstance(model_out,Mapping) else ()
            raw=raw or ()
            for item in raw:
                item=dict(item); stmt=str(item.get("statement","")); span=dict(item.get("span",{})); start=int(span.get("start",-1)); end=int(span.get("end",-1)); text=str(span.get("text",""))
                content=str(payload["content"])
                if start<0 or end<start or end>len(content) or not text or content[start:end]!=text: continue
                claim_kind=str(item.get("kind","assertion"))
                if claim_kind not in CLAIM_KINDS: continue
                grounded={"statement":stmt,"span":span,"source_hash":source.content_hash}
                faith=self.grounding_verifier(grounded,payload) if self.grounding_verifier else (text.lower() in content.lower() and bool(stmt))
                if not faith: continue
                key=str(item.get("claim_key") or _norm(f"{item.get('relationship','')}|{item.get('entities',())}|{re.sub(r'\\d+(?:\\.\\d+)?','<NUM>',stmt.lower())}"))
                caveats=list(item.get("caveats",()) or ())
                contradiction_kind=str(item.get("contradiction_kind") or "")
                if contradiction_kind in CONTRADICTION_KINDS:
                    caveats.append(f"contradiction_kind:{contradiction_kind}")
                claims.append(ClaimRecord(_uuid(),claim_kind,stmt,tuple(item.get("entities",())),item.get("relationship"),item.get("measurement"),item.get("temporal"),"unknown",0.0,tuple([f"source:{source.source_id}#span:{start}:{end}"]),(),tuple(item.get("derivations",())),tuple(caveats),source.source_id,span,key))
                self._emit("Research.EvidenceExtracted",{"research_id":run_id,"claim_id":claims[-1].claim_id,"source_id":source.source_id},correlation_id=run_id)
        self._record_stage(run_id,"evidence_extraction",[asdict(s) for s in sources],[asdict(c) for c in claims]); return claims

    def _cross_check(self, run_id:str, claims:Sequence[ClaimRecord], sources:Sequence[SourceRecord]) -> tuple[list[ClaimRecord],list[dict[str,Any]]]:
        by_key={}
        for c in claims: by_key.setdefault(c.claim_key,[]).append(c)
        contradictions=[]; updated=[]; source_map={s.source_id:s for s in sources}
        for c in claims:
            if self.embedding_provider is not None:
                self.embedding_provider(c.statement)
            supporting=list(c.supporting_evidence); contradicting=list(c.contradicting_evidence)
            peers=[x for x in by_key[c.claim_key] if x.claim_id!=c.claim_id]
            for p in peers:
                same_source=p.source_id==c.source_id or source_map[p.source_id].author==source_map[c.source_id].author or source_map[p.source_id].publisher==source_map[c.source_id].publisher
                if same_source: continue
                if _norm(p.statement)==_norm(c.statement): supporting.append(f"claim:{p.claim_id}")
                else: contradicting.append(f"claim:{p.claim_id}")
            updated.append(ClaimRecord(c.claim_id,c.kind,c.statement,c.entities,c.relationship,c.measurement,c.temporal,c.confidence,c.confidence_score,tuple(dict.fromkeys(supporting)),tuple(dict.fromkeys(contradicting)),c.derivations,c.caveats,c.source_id,c.span,c.claim_key))
        self._record_stage(run_id,"cross_check",[asdict(c) for c in claims],[asdict(c) for c in updated]); self._emit("Research.CrossCheckCompleted",{"research_id":run_id,"claims":len(updated)},correlation_id=run_id)
        return updated,contradictions

    def _contradictions(self,run_id:str,claims:Sequence[ClaimRecord]) -> list[ContradictionRecord]:
        rows=[]; seen=set()
        for c in claims:
            if not c.contradicting_evidence: continue
            refs=tuple(sorted([c.claim_id]+[x.split(":",1)[1] for x in c.contradicting_evidence if x.startswith("claim:")]))
            if refs in seen: continue
            seen.add(refs); kind="temporal" if c.temporal else "factual"
            for caveat in c.caveats:
                marker="contradiction_kind:"
                if str(caveat).startswith(marker) and str(caveat).split(":",1)[1] in CONTRADICTION_KINDS:
                    kind=str(caveat).split(":",1)[1]; break
            resolved=kind in {"temporal","scope","definitional"}
            status="resolved_by_synthesis" if resolved else "unresolved"
            resolution_ref=c.claim_id if resolved else None
            rec=ContradictionRecord(_uuid(),refs,kind,tuple(c.contradicting_evidence),status,resolution_ref)
            rows.append(rec)
            self._emit("Research.ContradictionResolved" if resolved else "Research.ContradictionUnresolved",{"research_id":run_id,"contradiction_id":rec.contradiction_id,"kind":kind,"status":status},correlation_id=run_id)
        self._record_stage(run_id,"contradiction_analysis",[asdict(c) for c in claims],[asdict(x) for x in rows]); return rows

    def _graph(self,run_id:str,subs:Sequence[Mapping[str,Any]],sources:Sequence[SourceRecord],claims:Sequence[ClaimRecord]) -> EvidenceGraph:
        nodes=[]; edges=[]
        for s in sources: nodes.append(EvidenceNode(s.source_id,"source",s.source_id,_sha(asdict(s)),(s.uri,)))
        for c in claims: nodes.append(EvidenceNode(c.claim_id,"claim",c.claim_id,_sha(asdict(c)),(f"source://{c.source_id}",)))
        for q in subs: nodes.append(EvidenceNode(q["sub_question_id"],"sub_question",q["sub_question_id"],_sha(q),("research://subquestion/"+q["sub_question_id"],)))
        answer_id="answer"; nodes.append(EvidenceNode(answer_id,"derivation",answer_id,_sha({"answer":answer_id}),("research://answer",)))
        for c in claims:
            kind="contradicts" if c.contradicting_evidence else "supports"
            edges.append(EvidenceEdge(_uuid(),c.source_id,c.claim_id,kind,0.8,None,self.key_id))
            for q in subs: edges.append(EvidenceEdge(_uuid(),c.claim_id,q["sub_question_id"],"derives",0.7,None,self.key_id))
        for q in subs: edges.append(EvidenceEdge(_uuid(),q["sub_question_id"],answer_id,"derives",0.8,None,self.key_id))
        graph_hash=_sha({"nodes":[asdict(x) for x in nodes],"edges":[asdict(x) for x in edges]})
        graph=EvidenceGraph(_uuid(),tuple(nodes),tuple(edges),True,graph_hash); self._record_stage(run_id,"evidence_graph",claims,asdict(graph)); self._emit("Research.EvidenceGraphBuilt",{"research_id":run_id,"graph_hash":graph_hash},correlation_id=run_id); return graph

    def _synthesize(self,run_id:str,req:Mapping[str,Any],claims:Sequence[ClaimRecord],contradictions:Sequence[ContradictionRecord],graph:EvidenceGraph,context:Any) -> dict[str,Any]:
        unresolved=[c for c in contradictions if c.status=="unresolved"]
        if self.reasoning_provider is not None or self.model_fabric is not None:
            out=self._model_call(run_id,req,context,task="synthesize",payload={"question":req["question"],"claims":[asdict(c) for c in claims],"contradictions":[asdict(c) for c in contradictions],"graph_hash":graph.graph_hash},role="reasoning") or {}
            narrative=str(out.get("narrative","")); sentences=list(out.get("sentences",()))
            if sentences and any(not x.get("claim_refs") for x in sentences): raise ResearchGroundingError("synthesis sentence lacks claim_refs")
            if unresolved:
                covered={str(ref) for sent in sentences for ref in sent.get("contradiction_refs",())}
                if not all(c.contradiction_id in covered for c in unresolved): raise ResearchContradictionError("synthesis omitted an unresolved contradiction")
        else:
            sentences=[{"text":f"{c.statement} [claim:{c.claim_id}]","claim_refs":[c.claim_id]} for c in claims[:20]]
            for c in unresolved:
                refs=list(c.claim_refs); sentences.append({"text":f"Conflicting evidence remains unresolved for claims {', '.join(refs)} [contradiction:{c.contradiction_id}]","claim_refs":refs,"contradiction_refs":[c.contradiction_id]})
            narrative=" ".join(x["text"] for x in sentences)
        self._enforce_forbidden(narrative,req.get("forbidden_claims",()))
        self._record_stage(run_id,"synthesis",claims,{"narrative":narrative,"sentences":sentences}); self._emit("Research.SynthesisCompleted",{"research_id":run_id,"sentence_count":len(sentences)},correlation_id=run_id); return {"narrative":narrative,"sentences":sentences,"open_questions":[] if not unresolved else [f"unresolved contradiction: {c.contradiction_id}" for c in unresolved],"recommended_followups":[]}

    def _enforce_forbidden(self,text:str,patterns:Sequence[str]) -> None:
        for code,pat in FORBIDDEN_PATTERNS:
            if pat.search(text) and code in set(patterns or ("medical_advice","legal_advice","financial_advice","harm_instructions")): raise ResearchPolicyDenied(f"forbidden claim category: {code}")

    def _calibrate(self,run_id:str,claims:Sequence[ClaimRecord],sources:Sequence[SourceRecord],contradictions:Sequence[ContradictionRecord]) -> tuple[list[ClaimRecord],dict[str,Any]]:
        sm={s.source_id:s for s in sources}; contradiction_ids={x for c in contradictions for x in c.claim_refs}; required_sources=set(self._requests.get(run_id,{}).get("required_source_classes",())); min_independent=int(self._requests.get(run_id,{}).get("evidence",{}).get("min_independent_sources",1))
        out=[]
        for c in claims:
            src=sm[c.source_id]; support=[e for e in c.supporting_evidence if e.startswith("claim:")]; independent=len(support)+1; independence=min(1.0,independent/max(1,min_independent)); contrad=0.35 if c.claim_id in contradiction_ids else 0.0; primary=0.12 if src.trust_tier=="authoritative" else 0.0
            qualified=(not required_sources) or src.source_class in required_sources or any(sm[x.split(":",1)[1].split("#",1)[0]].source_class in required_sources for x in c.supporting_evidence if x.startswith("source:") and x.split(":",1)[1].split("#",1)[0] in sm)
            score=max(0.0,min(1.0,CALIBRATION_WEIGHTS["source_reliability"]*src.reliability + CALIBRATION_WEIGHTS["independence"]*independence + CALIBRATION_WEIGHTS["contradiction"]*(1.0-contrad) + CALIBRATION_WEIGHTS["primary_bonus"]*(1.0 if primary else 0.0)))
            if not qualified: score=min(score,0.49)
            if independent>=min_independent and src.trust_tier=="authoritative" and c.claim_id not in contradiction_ids and score>=0.75 and qualified: level="established"
            elif score>=0.65 and src.trust_tier in {"authoritative","reliable"} and qualified: level="supported"
            elif c.claim_id in contradiction_ids: level="disputed"
            elif score>=0.45: level="preliminary"
            else: level="unknown"
            out.append(ClaimRecord(c.claim_id,c.kind,c.statement,c.entities,c.relationship,c.measurement,c.temporal,level,score,c.supporting_evidence,c.contradicting_evidence,c.derivations,c.caveats,c.source_id,c.span,c.claim_key))
        disputed=sum(1 for c in out if c.confidence=="disputed"); answer_score=(sum(c.confidence_score for c in out)/len(out)) if out else 0.0
        answer_level="established" if answer_score>=0.8 and disputed==0 else "supported" if answer_score>=0.6 and disputed==0 else "disputed" if disputed else "unknown"
        self._record_stage(run_id,"confidence",claims,[asdict(c) for c in out]); self._emit("Research.ConfidenceCalibrated",{"research_id":run_id,"score":answer_score,"level":answer_level},correlation_id=run_id)
        return out,{"level":answer_level,"score":answer_score,"method":"evidence_weighted","calibrated":True,"calibration_ref":f"calibrator://{PIPELINE_VERSION}"}

    def _verify_artifact(self,run_id:str,req:Mapping[str,Any],artifact:Mapping[str,Any]) -> dict[str,Any]:
        verifier=self.research_verifier
        if verifier is None and self.verifier is not None:
            method=getattr(self.verifier,"verify_research_artifact",None)
            if callable(method): verifier=method
        if verifier is None: raise ResearchVerificationError("no P2-N research verification bridge configured")
        result=dict(verifier(artifact))
        if result.get("decision")!="allow" and result.get("outcome") not in {"verified","allow"}: raise ResearchVerificationError("P2-N verification did not allow artifact")
        self._emit("Research.Verified",{"research_id":run_id,"verification_ref":result.get("record_id") or result.get("verification_id")},correlation_id=run_id); return result

    def _proposals(self,run_id:str,req:Mapping[str,Any],artifact:Mapping[str,Any]) -> dict[str,Any]:
        mem=[]; world=[]
        for c in artifact["claims"]:
            if c["confidence"] in {"established","supported"}:
                mem.append(self._signed({"proposal_id":_uuid(),"proposal_kind":"semantic_memory","tenant_id":req["tenant_id"],"claim":c,"artifact_ref":artifact.get("content_addressed_ref") or artifact.get("integrity_hash")}))
            if c["kind"] in {"relationship","temporal","measurement","causal_claim"}:
                world.append(self._signed({"proposal_id":_uuid(),"proposal_kind":"world_state","tenant_id":req["tenant_id"],"claim":c,"artifact_ref":artifact.get("content_addressed_ref") or artifact.get("integrity_hash")}))
        plan=[self._signed({"proposal_id":_uuid(),"proposal_kind":"plan_input","artifact_ref":artifact.get("content_addressed_ref") or artifact.get("integrity_hash"),"confidence":artifact["answer"]["confidence"]})]
        out={"semantic_memory_writes":mem,"world_state_updates":world,"plan_inputs":plan,"follow_up_research":[]}; self._record_stage(run_id,"proposal_emission",artifact,out); self._emit("Research.ProposalsEmitted",{"research_id":run_id,"memory":len(mem),"world":len(world)},correlation_id=run_id); return out

    def _artifact(self,run_id,req,subs,sources,claims,graph,contradictions,synth,calibration,verification,proposals,execution):
        unresolved_contradictions=[c for c in contradictions if c.status=="unresolved"]
        outcome="answered" if claims and calibration["score"]>=float(req["required_outputs"]["min_confidence_score"]) and not unresolved_contradictions else "partially_answered" if claims else "unanswered"
        if unresolved_contradictions: outcome="disputed"
        if outcome=="answered" and calibration["score"]<float(req["required_outputs"]["min_confidence_score"]): outcome="partially_answered"
        answer={"outcome":outcome,"summary":synth["narrative"],"confidence":calibration["level"],"confidence_score":calibration["score"],"confidence_method":calibration["method"],"calibration_ref":calibration["calibration_ref"],"caveats":[],"unknowns":[]}
        artifact={"artifact_id":run_id,"artifact_version":1,"request_ref":req["request_id"],"question":req["question"],"question_class":req["question_class"],"scope_constraints":list(req.get("scope_constraints",())),"answer":answer,"sub_questions":list(subs),"sources":[asdict(x) for x in sources],"claims":[asdict(x) for x in claims],"evidence_graph":asdict(graph),"contradictions":[asdict(x) for x in contradictions],"synthesis":synth,"proposals":proposals or {"semantic_memory_writes":[],"world_state_updates":[],"plan_inputs":[],"follow_up_research":[]},"execution":execution,"verification_refs":[str(verification.get("record_id") or verification.get("verification_id"))] if verification else [],"self_verified":bool(verification),"provenance":{"author_kind":"single_agent","author_agent_refs":[],"team_ref":None,"pipeline_version":PIPELINE_VERSION,"detector_versions":{},"derivation":None,"artifact_ref":f"research://artifact/{run_id}"}}
        signature,digest=_sign_document(artifact,self._signer); artifact["integrity_hash"]=digest; artifact["content_addressed_ref"]=f"cas://sha256/{digest}"; artifact["provenance"]["artifact_ref"]=artifact["content_addressed_ref"]; artifact["signature"]=signature; return artifact

    def _run_required_simulation(self,run_id:str,req:Mapping[str,Any],context:Any)->str:
        if not req.get("simulation_required"): return ""
        if self.simulation is None: raise ResearchPolicyDenied("simulation is required but P2-K is unavailable")
        mode=getattr(getattr(context,"mode",None),"value",getattr(context,"mode",None))
        if str(mode)!="simulation": raise ResearchPolicyDenied("simulation-required research needs a simulation ExecutionContext")
        seed=int(hashlib.sha256((req["request_id"]+run_id).encode()).hexdigest()[:12],16)
        universe=self.simulation.prepare({"kind":"system_change","ref":f"research:{run_id}","actions":[],"effect_class":"system_change"},"abstract","isolated",{"expected_outcome":"success"},execution_context=context,tenant_id=req["tenant_id"],seed=seed,budget={"wall_seconds":float(req["required_outputs"]["max_wall_seconds"]),"tool_calls":16},requested_by=str(req["requested_by"].get("principal","research")))
        outcome=self.simulation.run(universe.universe_id)
        outcome_class=getattr(outcome,"outcome_class",None)
        if str(outcome_class)!="success": raise ResearchPolicyDenied("required simulation did not complete successfully")
        handoff=self.simulation.authorization_handoff(universe.universe_id)
        if handoff.get("simulation_required") and not handoff.get("authorization_permitted"): raise ResearchPolicyDenied("simulation authorization handoff refused")
        return str(universe.universe_id)

    def _run(self,run_id,req,context,replay_bundle=None):
        self._started[run_id]=self._time()
        simulation_ref=self._run_required_simulation(run_id,req,context) if replay_bundle is None else str(replay_bundle.get("simulation_ref") or "")
        subs=self._decompose(run_id,req,context) if replay_bundle is None else copy.deepcopy(replay_bundle["sub_questions"])
        if req.get("mode")=="team" and replay_bundle is None:
            if self.team_provider is not None:
                team_rows=list(self.team_provider({"research_id":run_id,"tenant_id":req["tenant_id"],"sub_questions":copy.deepcopy(subs),"context":context}))
                self._iterations_used[run_id]=1
                self._record_stage(run_id,"search",{"mode":"team","sub_questions":subs},team_rows)
                candidates=[]
                for row in team_rows:
                    if isinstance(row,Mapping):
                        candidates.extend(list(row.get("sources",()) or row.get("search_results",())))
            elif self.orchestration is None:
                raise ResearchError("team mode requires P2-M orchestration or a team provider")
            else:
                raise ResearchError("P2-M team adapter requires an explicit research delegation bridge")
        else:
            candidates=self._search(run_id,req,subs,context) if replay_bundle is None else copy.deepcopy(replay_bundle["search_results"])
        sources,bodies=self._collect_sources(run_id,req,candidates,context) if replay_bundle is None else self._rebuild_sources(replay_bundle)
        claims=self._extract_claims(run_id,req,sources,bodies,context)
        claims, _=self._cross_check(run_id,claims,sources)
        contradictions=self._contradictions(run_id,claims)
        graph=self._graph(run_id,subs,sources,claims)
        synth=self._synthesize(run_id,req,claims,contradictions,graph,context)
        claims,calibration=self._calibrate(run_id,claims,sources,contradictions)
        pre={"claims":[asdict(c) for c in claims],"sources":[asdict(s) for s in sources],"graph":asdict(graph)}
        partial=self._artifact(run_id,req,subs,sources,claims,graph,contradictions,synth,calibration,{},None,{"mode":req["mode"],"depth":max([int(x.get("depth",0)) for x in subs] or [0]),"iterations":self._iterations_used.get(run_id,1),"started_at":_rfc3339(self._started[run_id]),"finished_at":_rfc3339(self._time()),"wall_seconds":self._time()-self._started[run_id],"tokens_in":self._usage.get(run_id,{}).get("tokens_in",0),"tokens_out":self._usage.get(run_id,{}).get("tokens_out",0),"cost_units":self._usage.get(run_id,{}).get("cost_units",0.0),"models_used":list(self._models_used.get(run_id,())),"tools_used":list(self._search_tools),"simulation_ref":simulation_ref})
        verification=self._verify_artifact(run_id,req,partial)
        proposals=self._proposals(run_id,req,partial)
        artifact=self._artifact(run_id,req,subs,sources,claims,graph,contradictions,synth,calibration,verification,proposals,partial["execution"])
        self._validate(artifact,"research_artifact_v1.schema.json")
        self._replay[run_id]={"sub_questions":copy.deepcopy(subs),"search_results":copy.deepcopy(candidates),"sources":[asdict(s) for s in sources],"bodies":copy.deepcopy(bodies),"simulation_ref":simulation_ref,"artifact_hash":artifact["integrity_hash"]}
        self._emit("Research.Completed",{"research_id":run_id,"artifact_hash":artifact["integrity_hash"],"outcome":artifact["answer"]["outcome"]},correlation_id=run_id)
        return artifact

    def _rebuild_sources(self,bundle):
        sources=[SourceRecord(**x) for x in bundle["sources"]]; bodies={str(k):dict(v) for k,v in bundle["bodies"].items()} if "bodies" in bundle else {s.source_id:{} for s in sources}; return sources,bodies

    def _terminal(self,req,run_id,outcome,reason):
        empty_graph=EvidenceGraph(_uuid(),(),(),True,_sha({"nodes":[],"edges":[]}))
        art=self._artifact(run_id,req,[],[],[],empty_graph,[],{"narrative":"","sentences":[],"open_questions":[reason],"recommended_followups":[]},{"level":"unknown","score":0.0,"method":"expert_rule","calibrated":False,"calibration_ref":None},{"decision":"block","outcome":"denied","reason":reason},{"semantic_memory_writes":[],"world_state_updates":[],"plan_inputs":[],"follow_up_research":[]},{"mode":req.get("mode","single_pass"),"depth":0,"iterations":0,"started_at":_rfc3339(self._time()),"finished_at":_rfc3339(self._time()),"wall_seconds":0.0,"cost_units":0.0,"tokens_in":0,"tokens_out":0,"models_used":[],"tools_used":[],"simulation_ref":""})
        art["answer"]["outcome"]=outcome; art["answer"]["summary"]=reason; art["self_verified"]=False; art["verification_refs"]=[]
        signature,digest=_sign_document(art,self._signer); art["integrity_hash"]=digest; art["content_addressed_ref"]=f"cas://sha256/{digest}"; art["provenance"]["artifact_ref"]=art["content_addressed_ref"]; art["signature"]=signature; return art

    def _refusal(self,req,reason,dangerous):
        run_id=req["request_id"]; return self._terminal(req,run_id,"refused",reason)

    def _forward_failure(self, run_id, req, exc, context) -> dict[str, str]:
        """Forward a bounded failure record and make the delivery outcome explicit."""
        if self.failure_intelligence is None:
            return {"status": "not_configured", "error_type": ""}
        try:
            self.failure_intelligence.ingest(
                {"origin": "P2-R", "category": "research_pipeline",
                 "what_happened": f"{type(exc).__name__}: {str(exc)[:240]}",
                 "where": {"research_id": str(run_id)[:128]},
                 "cause_class": type(exc).__name__,
                 "correlation_id": str(run_id)[:128]},
                self._auth(context), source="p2-r")
            return {"status": "ingested", "error_type": ""}
        except Exception as sink_exc:
            error_type = type(sink_exc).__name__
            logger.warning(
                "research_failure_ingestion_failed",
                extra={"research_id": str(run_id)[:128],
                       "error_type": error_type,
                       "cause_type": type(exc).__name__})
            return {"status": "failed", "error_type": error_type}

    def _get_artifact(self, research_id: str) -> dict[str, Any]:
        key = str(research_id)
        artifact = self._artifacts.get(key)
        if artifact is None:
            raise ResearchNotFound(key)
        return artifact

    def get_research(self,research_id:str)->dict[str,Any]: return copy.deepcopy(self._get_artifact(research_id))
    def get_sources(self,research_id:str)->list[dict[str,Any]]: return copy.deepcopy(self._get_artifact(research_id)["sources"])
    def get_claims(self,research_id:str)->list[dict[str,Any]]: return copy.deepcopy(self._get_artifact(research_id)["claims"])
    def get_evidence_graph(self,research_id:str)->dict[str,Any]: return copy.deepcopy(self._artifacts[str(research_id)]["evidence_graph"])
    def get_contradictions(self,research_id:str)->list[dict[str,Any]]: return copy.deepcopy(self._artifacts[str(research_id)]["contradictions"])
    def get_proposals(self,research_id:str)->dict[str,Any]: return copy.deepcopy(self._artifacts[str(research_id)]["proposals"])
    def get_stage_records(self,research_id:str)->list[dict[str,Any]]: return [asdict(x) for x in self._stages.get(str(research_id),())]
    def cancel_research(self,research_id:str,reason:str):
        art=self._artifacts[str(research_id)]; art["answer"]["outcome"]="cancelled"; art["answer"]["caveats"].append(reason); self._emit("Research.Cancelled",{"research_id":research_id,"reason":reason},correlation_id=research_id)
    def resume_research(self,research_id:str,from_stage:str,*,context:Any)->str:
        if from_stage not in self.STAGES: raise ResearchError("invalid stage")
        return str(research_id)
    def replay_research(self,research_id:str,seed:int,tool_responses:Mapping[str,Any],*,context:Any)->dict[str,Any]:
        self._auth(context); rid=str(research_id); bundle=copy.deepcopy(self._replay[rid]); original=copy.deepcopy(self._artifacts[rid])
        supplied=tool_responses.get("search_results") if isinstance(tool_responses,Mapping) else None
        expected_hash=_sha(bundle.get("search_results",()))
        if supplied is not None and _sha(supplied)!=expected_hash:
            self._emit("Research.ReplayDivergence",{"research_id":rid,"reason":"tool_response_hash_mismatch"},correlation_id=rid); raise ResearchReplayDivergence("replay tool responses differ from recorded evidence")
        # Frozen replay reconstructs from the recorded deterministic stage bundle; no new model/tool calls occur.
        original["replay_seed"]=int(seed); original["replayed_from"]=rid
        self._emit("Research.Completed",{"research_id":rid,"replay":True,"artifact_hash":original["integrity_hash"]},correlation_id=rid)
        return original
    def explain(self,research_id:str,claim_id:str)->dict[str,Any]:
        art=self._artifacts[str(research_id)]; claim=next(c for c in art["claims"] if c["claim_id"]==claim_id); return {"claim":claim,"sources":[s for s in art["sources"] if s["source_id"]==claim["source_id"]],"supporting_evidence":claim["supporting_evidence"],"contradicting_evidence":claim["contradicting_evidence"],"verification_refs":art["verification_refs"]}
    def emit_proposals(self,research_id:str,*,context:Any)->dict[str,Any]:
        self._auth(context); art=self._artifacts[str(research_id)]
        if not art.get("self_verified"): raise ResearchVerificationError("research artifact has not passed P2-N verification")
        return copy.deepcopy(art["proposals"])
    def verify_research(self,research_id:str)->dict[str,Any]: return copy.deepcopy(self._artifacts[str(research_id)].get("verification_refs",()))
    def request_follow_up(self,research_id:str,follow_up_spec:Mapping[str,Any],*,context:Any)->str:
        art=self._artifacts[str(research_id)]; req=copy.deepcopy(self._requests[str(research_id)]); req.update({"request_id":_uuid(),"question":str(follow_up_spec["question"]),"requested_at":_rfc3339(self._time()),"sub_questions_hint":None}); return self.submit_research(req,context=context)
    def link_research(self,research_id_a:str,research_id_b:str,relation:str)->dict[str,Any]: return {"link_id":_uuid(),"a":research_id_a,"b":research_id_b,"relation":relation,"integrity_hash":_sha((research_id_a,research_id_b,relation))}
    def configure_search_tools(self,tool_refs:Sequence[str],*,context:Any)->None:
        auth=self._auth(context); req={"operation":"configure_search_tools","tool_refs":list(tool_refs),"principal":auth.get("principal")}
        if self.authorization_checker is not None and not self.authorization_checker(req): raise ResearchPolicyDenied("tool configuration authorization denied")
        self._search_tools=tuple(map(str,tool_refs))
    def configure_reasoning_models(self,model_refs:Sequence[str],*,context:Any)->None: self._auth(context); self._reasoning_models=tuple(map(str,model_refs))
    def configure_embedding_models(self,model_refs:Sequence[str],*,context:Any)->None: self._auth(context); self._embedding_models=tuple(map(str,model_refs))
    def configure_reranker_models(self,model_refs:Sequence[str],*,context:Any)->None: self._auth(context); self._reranker_models=tuple(map(str,model_refs))
    def query_trust_tier(self,source_uri:str)->str:
        host=re.sub(r"^https?://","",source_uri).split("/",1)[0].lower(); return "reliable" if host.endswith((".gov",".edu")) else "unknown"
    def register_trust_tier_rule(self,rule:Mapping[str,Any],*,context:Any)->str:
        self._auth(context); rid=str(rule.get("rule_id",_uuid())); self._trust_rules[str(rule["source_class"])] = str(rule["tier"]); return rid
    def stats(self)->dict[str,Any]: return {"requests":len(self._requests),"artifacts":len(self._artifacts),"runs_with_replay":len(self._replay),"stages":sum(len(x) for x in self._stages.values())}

__all__=["AutonomousResearchSystem","ResearchError","ResearchPolicyDenied","ResearchBudgetExceeded","ResearchGroundingError","ResearchContradictionError","ResearchReplayDivergence","ResearchVerificationError","ResearchNotFound","ResearchRequest","StageRecord","SourceRecord","ClaimRecord","EvidenceNode","EvidenceEdge","EvidenceGraph","ContradictionRecord","QUESTION_CLASSES","SOURCE_CLASSES","CLAIM_KINDS","CONFIDENCE_LEVELS","OUTCOMES","MODES"]

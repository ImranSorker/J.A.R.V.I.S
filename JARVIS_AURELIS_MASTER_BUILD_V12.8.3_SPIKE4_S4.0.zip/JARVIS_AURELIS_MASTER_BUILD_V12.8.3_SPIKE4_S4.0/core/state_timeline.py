"""Bounded state snapshots for recovery and time-travel diagnostics."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping
import copy

@dataclass(frozen=True, slots=True)
class StateSnapshot:
    """Immutable named state snapshot."""
    snapshot_id: str
    state: Mapping[str, object]

class StateTimeline:
    """Keep a bounded in-memory timeline of JSON-compatible state."""
    def __init__(self, max_snapshots: int = 32) -> None:
        if max_snapshots < 1:
            raise ValueError("max_snapshots must be positive")
        self._max = max_snapshots
        self._items: list[StateSnapshot] = []

    def capture(self, snapshot_id: str, state: Mapping[str, object]) -> StateSnapshot:
        """Capture a defensive copy and evict the oldest snapshot if needed."""
        if not snapshot_id.strip():
            raise ValueError("snapshot_id is required")
        snapshot = StateSnapshot(snapshot_id, copy.deepcopy(dict(state)))
        self._items.append(snapshot)
        del self._items[:-self._max]
        return snapshot

    def get(self, snapshot_id: str) -> StateSnapshot:
        """Return a snapshot by ID."""
        for item in reversed(self._items):
            if item.snapshot_id == snapshot_id:
                return item
        raise KeyError(snapshot_id)

    def list(self) -> tuple[StateSnapshot, ...]:
        """Return snapshots oldest first."""
        return tuple(self._items)



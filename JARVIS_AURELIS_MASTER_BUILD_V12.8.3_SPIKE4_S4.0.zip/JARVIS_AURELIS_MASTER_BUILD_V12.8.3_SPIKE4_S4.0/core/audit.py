"""Tamper-evident security audit log for JARVIS 12.8.0.

Security events are authenticated, chained, sequence-checked, and flushed with
explicit failure reporting. Unsigned security audit is never silently accepted.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

logger = __import__("logging").getLogger("jarvis.audit")


@dataclass(frozen=True, slots=True)
class AuditEntry:
    seq: int
    t: float
    event: str
    details: dict[str, Any]
    prev_digest: str
    hmac: str


class AuditLog:
    """Tamper-evident append-only JSONL audit log.

    ``strict_security=True`` requires a master secret. Each entry authenticates
    the previous entry digest so deletion/reordering is detectable.
    """

    def __init__(
        self,
        path: str = "data/audit.jsonl",
        max_size_mb: float = 25.0,
        retain_days: int = 30,
        master_secret: Optional[str] = None,
        batch_size: int = 10,
        flush_interval_seconds: float = 1.0,
        *,
        strict_security: bool = True,
    ) -> None:
        self._path = Path(path).resolve()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._max_size_bytes = int(max_size_mb * 1024 * 1024)
        self._retain_seconds = max(0, int(retain_days * 86400))
        self._batch_size = max(1, int(batch_size))
        self._flush_interval = max(0.01, float(flush_interval_seconds))
        secret = master_secret if master_secret is not None else os.environ.get("JARVIS_MASTER_SECRET", "")
        self._key = hashlib.sha256(secret.encode("utf-8")).digest() if secret else None
        self._strict_security = bool(strict_security)
        if self._strict_security and self._key is None:
            raise RuntimeError("security audit requires JARVIS_MASTER_SECRET or an explicit master_secret")
        self._lock = threading.RLock()
        self._seq, self._prev_digest = self._load_tail()
        self._buffer: list[AuditEntry] = []
        if self._strict_security and self._path.exists():
            existing_issues = self._verify_file_locked()
            if existing_issues:
                raise RuntimeError(f"existing security audit log failed integrity verification: {len(existing_issues)} issue(s)")
        self._flush_thread: Optional[threading.Thread] = None
        self._stop_flush = threading.Event()
        self._start_flush_loop()

    @staticmethod
    def _entry_payload(seq: int, t: float, event: str, details: dict[str, Any], prev_digest: str) -> bytes:
        return json.dumps(
            {"seq": seq, "t": t, "event": event, "details": details, "prev_digest": prev_digest},
            sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str,
        ).encode("utf-8")

    def _sign(self, payload: bytes) -> str:
        if self._key is None:
            if self._strict_security:
                raise RuntimeError("audit HMAC key unavailable")
            return ""
        return base64.urlsafe_b64encode(hmac.new(self._key, payload, hashlib.sha256).digest()).decode("ascii")

    def _load_tail(self) -> tuple[int, str]:
        if not self._path.exists():
            return 0, ""
        last_seq = 0
        prev = ""
        try:
            with self._path.open("r", encoding="utf-8") as handle:
                for line_number, line in enumerate(handle, 1):
                    if not line.strip():
                        continue
                    record = json.loads(line)
                    last_seq = int(record["seq"])
                    prev = hashlib.sha256(line.rstrip("\n").encode("utf-8")).hexdigest()
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"audit log tail is unreadable; refusing startup: {exc}") from exc
        return last_seq, prev

    def _start_flush_loop(self) -> None:
        def loop() -> None:
            while not self._stop_flush.wait(self._flush_interval):
                self._flush()
        self._flush_thread = threading.Thread(target=loop, name="jarvis-audit-flush", daemon=True)
        self._flush_thread.start()

    def log(self, event: str, details: dict[str, Any] | None = None) -> AuditEntry:
        """Authenticate and queue one audit event."""
        event_name = str(event).strip()
        if not event_name:
            raise ValueError("audit event name is required")
        safe_details = dict(details or {})
        with self._lock:
            self._seq += 1
            seq = self._seq
            prev = self._prev_digest
            timestamp = time.time()
            payload = self._entry_payload(seq, timestamp, event_name, safe_details, prev)
            signature = self._sign(payload)
            entry = AuditEntry(seq, timestamp, event_name, safe_details, prev, signature)
            self._buffer.append(entry)
            self._prev_digest = hashlib.sha256(json.dumps({"seq": seq, "t": timestamp, "event": event_name, "details": safe_details, "prev_digest": prev, "hmac": signature}, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")).hexdigest()
            if len(self._buffer) >= self._batch_size:
                self._flush_unlocked()
        return entry

    def _flush(self) -> None:
        with self._lock:
            self._flush_unlocked()

    def _flush_unlocked(self) -> None:
        if not self._buffer:
            return
        rendered = []
        for entry in self._buffer:
            rendered.append(json.dumps({
                "seq": entry.seq, "t": entry.t, "event": entry.event,
                "details": entry.details, "prev_digest": entry.prev_digest, "hmac": entry.hmac,
            }, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str))
        try:
            current_size = self._path.stat().st_size if self._path.exists() else 0
            payload = "\n".join(rendered) + "\n"
            if current_size + len(payload.encode("utf-8")) > self._max_size_bytes:
                raise RuntimeError("audit log maximum size exceeded")
            with self._path.open("a", encoding="utf-8") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            self._buffer.clear()
        except Exception:
            logger.exception("audit_flush_failed")
            raise

    def _verify_file_locked(self) -> list[dict[str, Any]]:
        """Verify the on-disk audit file; caller must hold ``self._lock``."""
        if not self._path.exists():
            return []
        tampered: list[dict[str, Any]] = []
        last_seq = 0
        previous_line_digest = ""
        with self._path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                    seq = int(record["seq"])
                    if seq != last_seq + 1:
                        tampered.append({"line": line_number, "reason": "sequence_gap", "seq": seq, "expected": last_seq + 1})
                    if record.get("prev_digest", "") != previous_line_digest:
                        tampered.append({"line": line_number, "reason": "chain_break", "seq": seq})
                    if self._strict_security:
                        expected = self._sign(self._entry_payload(seq, float(record["t"]), str(record["event"]), dict(record.get("details", {})), str(record.get("prev_digest", ""))))
                        if not hmac.compare_digest(expected, str(record.get("hmac", ""))):
                            tampered.append({"line": line_number, "reason": "hmac_mismatch", "seq": seq})
                    previous_line_digest = hashlib.sha256(line.rstrip("\n").encode("utf-8")).hexdigest()
                    last_seq = seq
                except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    tampered.append({"line": line_number, "reason": "invalid_record", "error": type(exc).__name__})
        return tampered

    def verify(self) -> list[dict[str, Any]]:
        """Verify syntax, sequence, hash-chain and HMAC integrity."""
        with self._lock:
            self._flush_unlocked()
            return self._verify_file_locked()

    def read(self, limit: int = 1000) -> list[dict[str, Any]]:
        """Return only structurally valid, authenticated records."""
        issues = self.verify()
        if issues:
            raise RuntimeError(f"audit integrity verification failed: {len(issues)} issue(s)")
        records: list[dict[str, Any]] = []
        if not self._path.exists():
            return records
        with self._path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    records.append(json.loads(line))
        return records[-max(1, int(limit)):]

    def enforce_retention(self) -> int:
        """Rewrite the log after verifying integrity; preserves sequence by design."""
        self._flush()
        issues = self.verify()
        if issues:
            raise RuntimeError("refusing retention rewrite of a compromised audit log")
        if not self._path.exists():
            return 0
        cutoff = time.time() - self._retain_seconds
        rows = [json.loads(line) for line in self._path.read_text(encoding="utf-8").splitlines() if line.strip()]
        kept = [row for row in rows if float(row.get("t", 0)) >= cutoff]
        removed = len(rows) - len(kept)
        if removed:
            # Re-chain the retained suffix so verification remains self-contained.
            prev = ""
            rendered: list[str] = []
            for sequence, row in enumerate(kept, start=1):
                row["seq"] = sequence
                row["prev_digest"] = prev
                row["hmac"] = self._sign(self._entry_payload(sequence, float(row["t"]), str(row["event"]), dict(row.get("details", {})), prev))
                line = json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
                rendered.append(line)
                prev = hashlib.sha256(line.encode("utf-8")).hexdigest()
            with self._path.open("w", encoding="utf-8") as handle:
                handle.write("\n".join(rendered) + ("\n" if rendered else ""))
                handle.flush()
                os.fsync(handle.fileno())
            self._seq = len(kept)
            self._prev_digest = prev
        return removed

    def shutdown(self) -> None:
        """Flush and stop the background audit worker."""
        self._stop_flush.set()
        self._flush()
        if self._flush_thread and self._flush_thread.is_alive():
            self._flush_thread.join(timeout=2.0)
            if self._flush_thread.is_alive():
                raise RuntimeError("audit flush thread failed to stop")

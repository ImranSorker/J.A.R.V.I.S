"""Graph of model capabilities."""
from __future__ import annotations
from typing import Dict, List


class ModelCapabilityGraph:
    def __init__(self):
        self._graph: Dict[str, List[str]] = {}

    def link(self, model: str, capability: str) -> None:
        self._graph.setdefault(model, []).append(capability)

    def get_capabilities(self, model: str) -> List[str]:
        return self._graph.get(model, [])



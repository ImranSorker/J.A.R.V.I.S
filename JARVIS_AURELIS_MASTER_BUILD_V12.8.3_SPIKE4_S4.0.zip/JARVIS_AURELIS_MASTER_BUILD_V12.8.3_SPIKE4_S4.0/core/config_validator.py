"""Configuration schema validation.

Validates config.json against a strict schema using Pydantic-style
validation without requiring Pydantic as a dependency.
"""
from __future__ import annotations

from typing import Any, ClassVar, Dict, List


class ConfigValidationError(Exception):
    """Raised when config validation fails."""
    """Raised when configuration violates the declared schema."""


class ConfigValidator:
    """Validates JARVIS configuration dictionaries."""

    SCHEMA: ClassVar[Dict[str, Any]] = {
        "runtime": {
            "type": dict,
            "schema": {
                "profile": {"type": str, "allowed": ["local_embedded", "local_hybrid", "remote_api", "distributed"]},
                "ui": {"type": str, "allowed": ["flutter-only"]},
                "transport": {"type": str, "allowed": ["flutter-local-pipe", "remote-http", "distributed-transport"]},
                "allow_listeners": {"type": bool},
            },
        },
        "version": {"type": str, "required": True},
        "security": {
            "type": dict,
            "required": True,
            "schema": {
                "mode": {"type": str, "allowed": ["locked", "guarded", "permissive"]},
                "allow_shell": {"type": bool},
                "allow_code_execution": {"type": bool},
                "allowed_executables": {"type": list},
                "allow_network": {"type": bool},
                "require_approval_for_high_risk": {"type": bool},
                "workspace_root": {"type": str},
                "audit_log": {"type": str},
                "allowed_capabilities": {"type": list},
                "high_risk_capabilities": {"type": list},
            },
        },
        "native": {
            "type": dict,
            "schema": {
                "model_dirs": {"type": list},
                "models": {"type": list},
                "extensions": {"type": list},
                "n_ctx": {"type": int, "min": 512, "max": 131072},
                "n_batch": {"type": int, "min": 1, "max": 4096},
                "n_gpu_layers": {"type": int, "min": -1},
                "verbose": {"type": bool},
            },
        },
        "memory": {
            "type": dict,
            "schema": {
                "lance_path": {"type": str},
                "db_path": {"type": (str, type(None))},
                "max_history": {"type": int, "min": 1, "max": 10000},
                "max_sessions": {"type": int, "min": 1, "max": 100000},
                "embedding_model": {"type": str},
            },
        },
        "api": {
            "type": dict,
            "schema": {
                "host": {"type": str},
                "port": {"type": int, "min": 1, "max": 65535},
                "cors_origins": {"type": list},
            },
        },
        "network": {
            "type": dict,
            "schema": {
                "allow_private": {"type": bool},
                "allow_localhost": {"type": bool},
                "allow_metadata_endpoints": {"type": bool},
                "max_response_size_bytes": {"type": int, "min": 1, "max": 100_000_000},
                "request_timeout_seconds": {"type": (int, float), "min": 0.1, "max": 300},
                "max_redirects": {"type": int, "min": 0, "max": 20},
                "allowed_hosts": {"type": list},
            },
        },
        "voice": {
            "type": dict,
            "schema": {
                "stt_model": {"type": str},
                "tts_rate": {"type": int, "min": 50, "max": 400},
                "tts_volume": {"type": float, "min": 0.0, "max": 1.0},
                "wake_phrases": {"type": list},
            },
        },
        "observability": {
            "type": dict,
            "schema": {
                "log_path": {"type": str},
                "max_log_mb": {"type": int, "min": 1},
                "retain_days": {"type": int, "min": 1},
                "token_accounting": {"type": dict},
            },
        },
        "scheduler": {
            "type": dict,
            "schema": {
                "enabled": {"type": bool},
                "poll_interval": {"type": float, "min": 0.1},
            },
        },
        "lora": {
            "type": dict,
            "schema": {
                "nightly_train": {"type": bool},
                "output_dir": {"type": str},
            },
        },
        "consolidation": {
            "type": dict,
            "schema": {
                "nightly_enabled": {"type": bool},
                "age_days": {"type": int, "min": 1},
            },
        },
        "proactive": {
            "type": dict,
            "schema": {
                "enabled": {"type": bool},
                "cpu_threshold": {"type": (int, float), "min": 0, "max": 100},
                "memory_threshold": {"type": (int, float), "min": 0, "max": 100},
                "disk_threshold": {"type": (int, float), "min": 0, "max": 100},
            },
        },
        "watchdog": {
            "type": dict,
            "schema": {
                "enabled": {"type": bool},
                "check_interval": {"type": int, "min": 1},
                "max_restart_attempts": {"type": int, "min": 0},
            },
        },
        "react": {
            "type": dict,
            "schema": {
                "enabled": {"type": bool},
                "max_steps": {"type": int, "min": 1, "max": 20},
            },
        },
        "kernel": {
            "type": dict,
            "schema": {
                "enabled": {"type": bool},
                "compatibility_mode": {"type": bool},
                "event_db": {"type": str},
                "evidence_db": {"type": str},
                "mission_db": {"type": str},
                "memory_db": {"type": str},
                "experiment_db": {"type": str},
                "promotion_db": {"type": str},
                "identity_state": {"type": str},
                "node_id": {"type": str},
                "execution_audit_log": {"type": str},
                "event_replay_limit": {"type": int, "min": 1, "max": 100000},
                "capabilities": {
                    "type": dict,
                    "schema": {
                        "allow": {"type": list},
                        "approval_required": {"type": list},
                    },
                },
                "resources": {
                    "type": dict,
                    "schema": {
                        "cpu_seconds": {"type": (int, float), "min": 0},
                        "gpu_vram_mb": {"type": int, "min": 0},
                        "ram_mb": {"type": int, "min": 0},
                        "tokens": {"type": int, "min": 0},
                        "network_requests": {"type": int, "min": 0},
                        "storage_mb": {"type": int, "min": 0},
                        "notifications": {"type": int, "min": 0},
                    },
                },
            },
        },
        "external_backends": {
            "type": list,
            "item_schema": {
                "name": {"type": str, "required": True},
                "base_url": {"type": str, "required": True},
                "model": {"type": str, "required": True},
                "enabled": {"type": bool},
                "primary": {"type": bool},
                "timeout": {"type": float, "min": 1},
            },
        },
        "autonomy": {"type": dict}, "cloud_ai": {"type": dict}, "frontier_rag": {"type": dict},
        "local_backends": {"type": list}, "plugins": {"type": dict}, "qwen": {"type": dict},
        "reliability": {"type": dict}, "scripting": {"type": dict}, "v12_7": {"type": dict},
        "world_model": {"type": dict}, "aion_bridge": {"type": dict},
    }

    def validate(self, cfg: Dict[str, Any]) -> List[str]:
        """Validate a config dict against the schema.

        Returns:
            List of error messages. Empty list means valid.
        """
        errors = []
        errors.extend(self._validate_dict(cfg, self.SCHEMA, path="config"))
        return errors

    def _validate_dict(self, data: Any, schema: Dict[str, Any], path: str) -> List[str]:
        errors = []
        if not isinstance(data, dict):
            errors.append(f"{path}: expected dict, got {type(data).__name__}")
            return errors
        for key in sorted(set(data) - set(schema)):
            errors.append(f"{path}.{key}: unknown field")

        for key, rules in schema.items():
            if key not in data:
                if rules.get("required"):
                    errors.append(f"{path}.{key}: required field missing")
                continue

            value = data[key]
            expected_type = rules.get("type")
            if expected_type:
                if isinstance(expected_type, tuple):
                    if not isinstance(value, expected_type):
                        errors.append(f"{path}.{key}: expected {expected_type}, got {type(value).__name__}")
                elif not isinstance(value, expected_type):
                    errors.append(f"{path}.{key}: expected {expected_type.__name__}, got {type(value).__name__}")

            if "allowed" in rules and value not in rules["allowed"]:
                errors.append(f"{path}.{key}: value '{value}' not in allowed {rules['allowed']}")

            if "min" in rules and isinstance(value, (int, float)) and value < rules["min"]:
                errors.append(f"{path}.{key}: value {value} below minimum {rules['min']}")

            if "max" in rules and isinstance(value, (int, float)) and value > rules["max"]:
                errors.append(f"{path}.{key}: value {value} above maximum {rules['max']}")

            if "schema" in rules and isinstance(value, dict):
                errors.extend(self._validate_dict(value, rules["schema"], path=f"{path}.{key}"))

            if "item_schema" in rules and isinstance(value, list):
                for i, item in enumerate(value):
                    if not isinstance(item, dict):
                        errors.append(f"{path}.{key}[{i}]: expected dict, got {type(item).__name__}")
                        continue
                    errors.extend(self._validate_dict(item, rules["item_schema"], path=f"{path}.{key}[{i}]"))


        return errors

    def validate_or_raise(self, cfg: Dict[str, Any]) -> None:
        """Validate and raise ConfigValidationError if invalid."""
        errors = self.validate(cfg)
        if errors:
            raise ConfigValidationError("; ".join(errors))



"""Release-time dependency, hash, SBOM and provenance enforcement."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Iterable

_VERSION_OPERATOR = re.compile(r"(?:==|~=|>=|<=|>|<|@\s+)")


class SupplyChainEnforcer:
    """Enforce deterministic dependency metadata and generate lightweight SBOM data."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()

    def check_requirements(self, path: str | Path | None = None) -> dict[str, object]:
        """Check a requirement file for direct dependencies without version constraints."""
        candidate = (self.root / str(path or "requirements.txt")).resolve()
        if self.root not in candidate.parents and candidate != self.root:
            raise ValueError("requirements path escapes project root")
        if not candidate.is_file():
            return {"ok": True, "unconstrained": []}
        unconstrained: list[str] = []
        for line in candidate.read_text(encoding="utf-8").splitlines():
            spec = line.strip()
            if not spec or spec.startswith("#") or spec.startswith(("-r ", "--")):
                continue
            if not _VERSION_OPERATOR.search(spec):
                unconstrained.append(spec)
        return {"ok": not unconstrained, "unconstrained": unconstrained}

    def verify_file_hashes(self, manifest: dict[str, str]) -> dict[str, Any]:
        """Verify a relative-path to SHA-256 manifest without trusting external paths."""
        failures: list[str] = []
        for relative, expected in manifest.items():
            path = (self.root / str(relative)).resolve()
            if self.root not in path.parents:
                failures.append(str(relative))
                continue
            if not path.is_file():
                failures.append(str(relative))
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest.lower() != str(expected).lower():
                failures.append(str(relative))
        return {"ok": not failures, "checked": len(manifest), "failures": failures}

    def generate_sbom(self, requirement_files: Iterable[str] = ("requirements.txt", "requirements-ai.txt", "requirements-dev.txt", "requirements-full.txt")) -> dict[str, Any]:
        """Produce a deterministic CycloneDX-like dependency inventory."""
        components: dict[str, dict[str, str]] = {}
        for filename in requirement_files:
            path = self.root / filename
            if not path.is_file():
                continue
            for line in path.read_text(encoding="utf-8").splitlines():
                spec = line.strip()
                if not spec or spec.startswith("#") or spec.startswith(("-r ", "--")):
                    continue
                name = re.split(r"(?:==|~=|>=|<=|>|<|@\s+)", spec, maxsplit=1)[0].strip()
                if name:
                    components[name.lower()] = {"name": name, "spec": spec}
        rows = sorted(components.values(), key=lambda item: item["name"].lower())
        payload = {"bomFormat": "CycloneDX-lite", "specVersion": "1.5", "components": rows}
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        payload["sha256"] = hashlib.sha256(canonical).hexdigest()
        return payload

    def audit(self) -> dict[str, Any]:
        """Return release-policy status and an SBOM digest."""
        checks = {name: self.check_requirements(name) for name in ("requirements.txt", "requirements-ai.txt", "requirements-dev.txt", "requirements-full.txt")}
        return {"ok": all(bool(result["ok"]) for result in checks.values()), "requirements": checks, "sbom": self.generate_sbom()}



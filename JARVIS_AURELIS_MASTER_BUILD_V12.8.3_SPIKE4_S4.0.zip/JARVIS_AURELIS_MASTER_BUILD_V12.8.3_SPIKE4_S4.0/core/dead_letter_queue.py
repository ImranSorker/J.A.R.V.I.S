"""Durable dead-letter queue with a normalized failure taxonomy."""
from __future__ import annotations
from contextlib import contextmanager

import sqlite3
import threading
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterator, Optional


class ErrorCategory(str, Enum):
    TRANSIENT = "transient"
    PERMANENT = "permanent"
    SCHEMA = "schema"
    AUTHZ = "authz"
    TOOL = "tool"
    INFRA = "infra"
    TIMEOUT = "timeout"
    QUOTA = "quota"


class ErrorSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass(frozen=True)
class DLQEntry:
    id: int
    job_id: str
    step_id: str
    error: str
    category: ErrorCategory
    severity: ErrorSeverity
    retry_count: int
    created_at: float


class DeadLetterQueue:
    """Persist terminal step failures for operator inspection and controlled retry."""

    def __init__(self, db_path: str = "data/dlq.db") -> None:
        self._db_path = str(db_path)
        self._lock = threading.RLock()
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        """Yield a configured SQLite connection and always close it."""
        conn = sqlite3.connect(self._db_path, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _ensure_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS dlq (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    step_id TEXT NOT NULL,
                    error TEXT NOT NULL,
                    category TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    retry_count INTEGER NOT NULL,
                    created_at REAL NOT NULL
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_dlq_created ON dlq(created_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_dlq_job ON dlq(job_id)")

    @staticmethod
    def classify_error(error: str) -> tuple[ErrorCategory, ErrorSeverity]:
        text = str(error).lower()
        if "schema" in text or "validation" in text:
            return ErrorCategory.SCHEMA, ErrorSeverity.MEDIUM
        if "authorization" in text or "permission" in text or "approval" in text or "token" in text:
            return ErrorCategory.AUTHZ, ErrorSeverity.HIGH
        if "timed out" in text or "timeout" in text:
            return ErrorCategory.TIMEOUT, ErrorSeverity.MEDIUM
        if "quota" in text or "concurrency" in text:
            return ErrorCategory.QUOTA, ErrorSeverity.MEDIUM
        if "connection" in text or "database" in text or "network" in text or "unavailable" in text:
            return ErrorCategory.INFRA, ErrorSeverity.HIGH
        if "transient" in text or "tempor" in text or "retry" in text:
            return ErrorCategory.TRANSIENT, ErrorSeverity.MEDIUM
        if "tool" in text or "not found" in text:
            return ErrorCategory.TOOL, ErrorSeverity.MEDIUM
        return ErrorCategory.PERMANENT, ErrorSeverity.HIGH

    def enqueue(self, job_id: str, step_id: str, error: str, retry_count: int) -> int:
        category, severity = self.classify_error(error)
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO dlq(job_id,step_id,error,category,severity,retry_count,created_at) VALUES(?,?,?,?,?,?,?)",
                (job_id, step_id, str(error)[:4000], category.value, severity.value, int(retry_count), time.time()),
            )
            return int(cur.lastrowid)

    def get(self, entry_id: int) -> Optional[DLQEntry]:
        with self._lock, self._connect() as conn:
            row = conn.execute("SELECT * FROM dlq WHERE id=?", (int(entry_id),)).fetchone()
        return self._row_to_entry(row) if row else None

    def list(self, limit: int = 100) -> list[DLQEntry]:
        with self._lock, self._connect() as conn:
            rows = conn.execute("SELECT * FROM dlq ORDER BY id DESC LIMIT ?", (max(1, min(int(limit), 1000)),)).fetchall()
        return [self._row_to_entry(row) for row in rows]

    def delete(self, entry_id: int) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM dlq WHERE id=?", (int(entry_id),))
            return cur.rowcount > 0

    def get_stats(self) -> dict[str, int]:
        with self._lock, self._connect() as conn:
            total = int(conn.execute("SELECT COUNT(*) FROM dlq").fetchone()[0])
        return {"total": total}

    @staticmethod
    def _row_to_entry(row: sqlite3.Row) -> DLQEntry:
        return DLQEntry(
            id=int(row["id"]), job_id=row["job_id"], step_id=row["step_id"], error=row["error"],
            category=ErrorCategory(row["category"]), severity=ErrorSeverity(row["severity"]),
            retry_count=int(row["retry_count"]), created_at=float(row["created_at"]),
        )



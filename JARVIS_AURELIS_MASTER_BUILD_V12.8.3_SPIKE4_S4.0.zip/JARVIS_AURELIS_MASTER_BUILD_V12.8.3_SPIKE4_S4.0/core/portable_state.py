"""Versioned portable JARVIS state export/import with atomic writes."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Mapping


class PortableStateError(RuntimeError):
    """Raised for invalid or unsafe state packages."""


class PortableStateManager:
    """Compose state providers into a deterministic, restart-safe package."""

    SCHEMA_VERSION = 1

    def __init__(self, secret: bytes | None = None) -> None:
        self._secret = bytes(secret) if secret is not None else None
        if self._secret is not None and len(self._secret) < 32:
            raise ValueError("portable state secret must contain at least 32 bytes")
        self._providers: dict[str, tuple[Callable[[], Any], Callable[[Any], None]]] = {}

    def register(self, name: str, exporter: Callable[[], Any], importer: Callable[[Any], None]) -> None:
        """Register one named state domain."""
        key = str(name).strip()
        if not key or not callable(exporter) or not callable(importer):
            raise ValueError("state provider name and callbacks are required")
        self._providers[key] = (exporter, importer)

    @staticmethod
    def _digest(schema_version: int, domains: Mapping[str, Any]) -> str:
        """Compute a deterministic integrity digest over portable state domains."""
        canonical = json.dumps({"schema_version": schema_version, "domains": domains}, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def export(self) -> dict[str, Any]:
        """Return a versioned state package with integrity metadata."""
        domains: dict[str, Any] = {}
        for name in sorted(self._providers):
            value = self._providers[name][0]()
            domains[name] = value
        digest = self._digest(self.SCHEMA_VERSION, domains)
        payload: dict[str, Any] = {"schema_version": self.SCHEMA_VERSION, "exported_at": time.time(), "domains": domains, "integrity": digest}
        if self._secret is not None:
            payload["authentication"] = hmac.new(self._secret, digest.encode("ascii"), hashlib.sha256).hexdigest()
        return payload

    def export_to(self, path: str | Path) -> Path:
        """Atomically write a state package."""
        target = Path(path).expanduser().resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = self.export()
        fd, tmp_name = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=target.parent)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, sort_keys=True, default=str)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, target)
        finally:
            tmp.unlink(missing_ok=True)
        return target

    def import_state(self, state: Mapping[str, Any]) -> None:
        """Validate and import a state package."""
        if int(state.get("schema_version", -1)) != self.SCHEMA_VERSION:
            raise PortableStateError("unsupported state schema version")
        domains = state.get("domains")
        if not isinstance(domains, Mapping):
            raise PortableStateError("state domains must be a mapping")
        expected_digest = self._digest(self.SCHEMA_VERSION, domains)
        integrity = state.get("integrity")
        if not isinstance(integrity, str) or integrity != expected_digest:
            raise PortableStateError("state integrity check failed")
        if self._secret is not None:
            authentication = state.get("authentication")
            expected_authentication = hmac.new(self._secret, expected_digest.encode("ascii"), hashlib.sha256).hexdigest()
            if not isinstance(authentication, str) or not hmac.compare_digest(authentication, expected_authentication):
                raise PortableStateError("state authentication check failed")
        unknown = sorted(set(domains) - set(self._providers))
        if unknown:
            raise PortableStateError(f"unknown state domains: {unknown}")

        # Two-phase restore: snapshot every current domain first, validate the
        # complete incoming package, then commit. If any importer fails, restore
        # every already-mutated domain from the captured snapshot. This prevents
        # partially restored cognitive state after a late-domain failure.
        backups: dict[str, Any] = {}
        for name in sorted(domains):
            try:
                backups[name] = self._providers[name][0]()
            except Exception as exc:
                raise PortableStateError(f"unable to snapshot state domain: {name}") from exc

        try:
            for name in sorted(domains):
                self._providers[name][1](domains[name])
        except Exception as exc:
            rollback_errors: list[str] = []
            for name in sorted(backups, reverse=True):
                try:
                    self._providers[name][1](backups[name])
                except Exception as rollback_exc:
                    rollback_errors.append(f"{name}: {rollback_exc}")
            detail = f"; rollback failures: {rollback_errors}" if rollback_errors else ""
            raise PortableStateError(f"state restore failed and was rolled back: {exc}{detail}") from exc

    def import_file(self, path: str | Path) -> None:
        """Read and import a JSON state package."""
        source = Path(path).expanduser().resolve()
        with source.open(encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, Mapping):
            raise PortableStateError("state package must be an object")
        self.import_state(payload)



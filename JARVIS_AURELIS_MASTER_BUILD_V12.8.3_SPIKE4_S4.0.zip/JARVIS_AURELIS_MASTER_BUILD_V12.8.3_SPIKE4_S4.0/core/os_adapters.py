"""Replaceable, least-privilege OS adapters for the AIOS layer."""
from __future__ import annotations

import logging
import os
import platform
import shutil
from typing import Mapping
from pathlib import Path

from core.contracts.platform import OSAdapter, PlatformKind, PlatformSnapshot

logger = logging.getLogger("jarvis.os_adapters")


class SystemOSAdapter:
    """Read-only host adapter with bounded application launching."""

    KIND = PlatformKind.UNKNOWN

    def snapshot(self) -> PlatformSnapshot:
        """Return stable platform identity and non-sensitive host metadata."""
        return PlatformSnapshot(
            kind=self.KIND,
            architecture=platform.machine(),
            python_version=platform.python_version(),
            hostname=platform.node(),
            metadata={"system": platform.system().lower(), "release": platform.release()},
        )

    def _launcher(self, target: str) -> list[str] | None:
        """Return a non-shell command vector for the current platform."""
        kind = self.snapshot().kind
        if kind is PlatformKind.WINDOWS:
            return None
        if kind is PlatformKind.MACOS:
            opener = shutil.which("open")
            return [opener, target] if opener else None
        if kind is PlatformKind.LINUX:
            opener = shutil.which("xdg-open")
            return [opener, target] if opener else None
        if kind is PlatformKind.ANDROID:
            launcher = shutil.which("am")
            return [launcher, "start", target] if launcher else None
        return None

    def open_target(self, target: str) -> bool:
        """Open an application/path through a platform-specific non-shell adapter."""
        value = str(target).strip()
        if not value or len(value) > 4096:
            return False
        command = self._launcher(value)
        if command is None:
            return False
        from core.trusted_process import TrustedProcessAdapter
        executable = command[0]
        runner = TrustedProcessAdapter("data/workspace", timeout_seconds=5, max_memory_mb=256, allow_network=False)
        if not runner.start_detached(command, allowed_executables=(Path(executable).name,)):
            logger.warning("os_target_open_failed", extra={"platform": self.KIND.value})
            return False
        return True

    def environment(self) -> Mapping[str, str]:
        """Expose a minimal environment view without common secret variables."""
        blocked = ("PASSWORD", "TOKEN", "SECRET", "KEY", "CREDENTIAL")
        return {
            key: value
            for key, value in os.environ.items()
            if not any(part in key.upper() for part in blocked)
        }


class WindowsOSAdapter(SystemOSAdapter):
    """Windows adapter without cmd.exe shell parsing."""

    KIND = PlatformKind.WINDOWS

    def snapshot(self) -> PlatformSnapshot:
        """Return Windows identity."""
        snapshot = super().snapshot()
        return PlatformSnapshot(snapshot.kind, snapshot.architecture, snapshot.python_version, snapshot.hostname, snapshot.metadata)

    def open_target(self, target: str) -> bool:
        """Use the Windows native shell association API without starting a shell process."""
        value = str(target).strip()
        if not value or len(value) > 4096:
            return False
        try:
            os.startfile(value)  # type: ignore[attr-defined]
            return True
        except (AttributeError, OSError):
            return False


class LinuxOSAdapter(SystemOSAdapter):
    """Linux adapter using xdg-open when available."""

    KIND = PlatformKind.LINUX

    def _launcher(self, target: str) -> list[str] | None:
        opener = shutil.which("xdg-open")
        return [opener, target] if opener else None


class MacOSAdapter(SystemOSAdapter):
    """macOS adapter using the native open command."""

    KIND = PlatformKind.MACOS

    def _launcher(self, target: str) -> list[str] | None:
        opener = shutil.which("open")
        return [opener, target] if opener else None


class AndroidOSAdapter(SystemOSAdapter):
    """Android adapter using an installed activity launcher."""

    KIND = PlatformKind.ANDROID

    def _launcher(self, target: str) -> list[str] | None:
        launcher = shutil.which("am")
        return [launcher, "start", target] if launcher else None


def adapter_for_current_host() -> OSAdapter:
    """Create the least-privileged adapter for the current host."""
    system = platform.system().lower()
    if system == "windows":
        return WindowsOSAdapter()
    if system == "linux":
        return LinuxOSAdapter()
    if system == "darwin":
        return MacOSAdapter()
    if system == "android":
        return AndroidOSAdapter()
    return SystemOSAdapter()



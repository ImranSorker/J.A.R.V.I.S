"""Canonical capability-aware distributed network coordinator."""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field, asdict
import uuid
from typing import Any


@dataclass
class NetworkNode:
    node_id: str
    endpoint: str | None
    capabilities: tuple[str, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    last_heartbeat: float = field(default_factory=time.time)
    active_tasks: int = 0


@dataclass
class NetworkAssignment:
    assignment_id: str
    task_id: str
    node_id: str
    capability: str
    status: str = "assigned"
    attempts: int = 1
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    result: Any = None
    evidence: dict[str, Any] = field(default_factory=dict)
    error: str | None = None



class NetworkCoordinator:
    """Authoritative worker registry and capability scheduler."""
    def __init__(self, port: int = 28766, lease_seconds: float = 30.0, max_nodes: int = 1024):
        self.port = int(port)
        self.lease_seconds = max(2.0, float(lease_seconds))
        self.max_nodes = max(1, min(int(max_nodes), 4096))
        self._nodes: dict[str, NetworkNode] = {}
        self._assignments: dict[str, NetworkAssignment] = {}
        self._quarantined: dict[str, str] = {}
        self._lock = threading.RLock()

    def register(self, node_id: str, capabilities: tuple[str, ...], endpoint: str | None = None, metadata: dict[str, Any] | None = None) -> NetworkNode:
        node_id = str(node_id).strip()
        caps = tuple(sorted({str(c).strip() for c in capabilities if str(c).strip()}))
        if not node_id or not caps:
            raise ValueError("node_id and capabilities are required")
        with self._lock:
            if node_id not in self._nodes and len(self._nodes) >= self.max_nodes:
                raise RuntimeError("network node capacity reached")
            node = NetworkNode(node_id, endpoint, caps, dict(metadata or {}))
            self._nodes[node_id] = node
            return NetworkNode(node.node_id, node.endpoint, node.capabilities, dict(node.metadata), node.last_heartbeat, node.active_tasks)

    def heartbeat(self, node_id: str, *, active_tasks: int | None = None, metadata: dict[str, Any] | None = None) -> bool:
        with self._lock:
            node = self._nodes.get(str(node_id))
            if node is None:
                return False
            node.last_heartbeat = time.time()
            if active_tasks is not None:
                node.active_tasks = max(0, int(active_tasks))
            if metadata:
                node.metadata.update(metadata)
            return True

    def remove(self, node_id: str) -> bool:
        with self._lock:
            return self._nodes.pop(str(node_id), None) is not None

    def prune(self) -> int:
        cutoff = time.time() - self.lease_seconds
        with self._lock:
            stale = [key for key, node in self._nodes.items() if node.last_heartbeat < cutoff]
            for key in stale:
                del self._nodes[key]
                self._quarantined.pop(key, None)
                for assignment in self._assignments.values():
                    if assignment.node_id == key and assignment.status not in {"completed", "failed", "cancelled"}:
                        assignment.status = "failed"
                        assignment.error = "node lease expired"
                        assignment.updated_at = time.time()
            return len(stale)

    def choose(self, capability: str) -> NetworkNode | None:
        self.prune()
        with self._lock:
            candidates = [n for n in self._nodes.values() if capability in n.capabilities and n.node_id not in self._quarantined]
            if not candidates:
                return None
            node = min(candidates, key=lambda n: (n.active_tasks, -n.last_heartbeat, n.node_id))
            return NetworkNode(node.node_id, node.endpoint, node.capabilities, dict(node.metadata), node.last_heartbeat, node.active_tasks)

    def assign(self, node_id: str) -> bool:
        with self._lock:
            node = self._nodes.get(str(node_id))
            if node is None:
                return False
            node.active_tasks += 1
            return True

    def complete(self, node_id: str) -> bool:
        with self._lock:
            node = self._nodes.get(str(node_id))
            if node is None:
                return False
            node.active_tasks = max(0, node.active_tasks - 1)
            return True


    def assign_task(self, capability: str, *, task_id: str | None = None, node_id: str | None = None) -> NetworkAssignment | None:
        """Create an explicit assignment bound to a live capability node."""
        chosen = self._nodes.get(str(node_id)) if node_id else self.choose(capability)
        if chosen is None or str(chosen.node_id) in self._quarantined:
            return None
        task_key = str(task_id or f"task_{uuid.uuid4().hex}")
        assignment = NetworkAssignment(f"assign_{uuid.uuid4().hex}", task_key, chosen.node_id, str(capability))
        with self._lock:
            self._assignments[assignment.assignment_id] = assignment
            node = self._nodes.get(chosen.node_id)
            if node is None:
                self._assignments.pop(assignment.assignment_id, None)
                return None
            node.active_tasks += 1
        return NetworkAssignment(**asdict(assignment))

    def acknowledge(self, assignment_id: str) -> bool:
        with self._lock:
            item = self._assignments.get(str(assignment_id))
            if item is None or item.status not in {"assigned", "retrying"}:
                return False
            item.status = "acknowledged"
            item.updated_at = time.time()
            return True

    def complete_task(self, assignment_id: str, result: Any, *, verified: bool, evidence: dict[str, Any] | None = None) -> bool:
        with self._lock:
            item = self._assignments.get(str(assignment_id))
            if item is None or item.status not in {"assigned", "acknowledged", "retrying"}:
                return False
            if not verified or not evidence:
                item.status = "failed"
                item.error = "completion requires verified outcome evidence"
            else:
                item.status = "completed"
                item.result = result
                item.evidence = dict(evidence)
            item.updated_at = time.time()
            node = self._nodes.get(item.node_id)
            if node is not None:
                node.active_tasks = max(0, node.active_tasks - 1)
            return item.status == "completed"

    def fail_task(self, assignment_id: str, error: str, *, retry: bool = False) -> bool:
        with self._lock:
            item = self._assignments.get(str(assignment_id))
            if item is None or item.status in {"completed", "failed", "cancelled"}:
                return False
            node = self._nodes.get(item.node_id)
            if node is not None:
                node.active_tasks = max(0, node.active_tasks - 1)
            if retry:
                item.attempts += 1
                item.status = "retrying"
                item.updated_at = time.time()
                return True
            item.status = "failed"
            item.error = str(error)
            item.updated_at = time.time()
            return True

    def quarantine(self, node_id: str, reason: str) -> bool:
        with self._lock:
            if str(node_id) not in self._nodes:
                return False
            self._quarantined[str(node_id)] = str(reason)
            return True

    def assignment(self, assignment_id: str) -> NetworkAssignment | None:
        with self._lock:
            item = self._assignments.get(str(assignment_id))
            return NetworkAssignment(**asdict(item)) if item else None

    def assignments_snapshot(self) -> dict[str, dict[str, Any]]:
        with self._lock:
            return {key: asdict(value) for key, value in sorted(self._assignments.items())}

    def snapshot(self) -> dict[str, Any]:
        self.prune()
        with self._lock:
            return {"port": self.port, "status": "ready", "nodes": {k: {"endpoint": v.endpoint, "capabilities": list(v.capabilities), "active_tasks": v.active_tasks, "last_heartbeat": v.last_heartbeat, "metadata": dict(v.metadata), "quarantined": k in self._quarantined} for k, v in sorted(self._nodes.items())}, "assignments": len(self._assignments), "quarantined": dict(self._quarantined)}

    def get_stats(self) -> dict[str, Any]:
        snap = self.snapshot()
        return {"port": self.port, "status": snap["status"], "nodes": len(snap["nodes"]), "capabilities": sorted({cap for node in snap["nodes"].values() for cap in node["capabilities"]})}

"""Bounded inference control plane for the V12.8.0 cognitive fabric.

The gateway is intentionally provider-independent. It adds admission control,
request deduplication, deterministic response caching, adaptive model choice,
residency tracking, latency telemetry, and bounded fallback around an injected
router. It never executes tools or grants permissions; those remain owned by
the policy/execution layers.
"""
from __future__ import annotations

import hashlib
import logging
import threading
import time
from collections import OrderedDict, deque
from dataclasses import dataclass
from typing import Callable, Generator, Protocol, Sequence

from core.model_residency import ModelResidencyManager

logger = logging.getLogger("jarvis.intelligence_gateway")


class InferenceRouter(Protocol):
    """Minimal replaceable model-router contract."""

    def generate(self, prompt: str, **kwargs: object) -> object:
        """Generate a response through an injected provider router."""


class ModelChooser(Protocol):
    """Minimal adaptive model-selection contract."""

    def choose(
        self,
        *,
        task_type: str,
        candidates: Sequence[str] | None = None,
        task_text: str = "",
        **kwargs: object,
    ) -> str | None:
        """Return a compatible model or ``None``."""


@dataclass(frozen=True, slots=True)
class GatewayConfig:
    """Hard bounds for the inference control plane."""

    max_prompt_chars: int = 200_000
    max_cache_entries: int = 128
    cache_ttl_seconds: float = 30.0
    max_inflight: int = 4
    max_latency_samples: int = 2_000
    residency_capacity: int = 2

    def __post_init__(self) -> None:
        if self.max_prompt_chars < 1:
            raise ValueError("max_prompt_chars must be positive")
        if self.max_cache_entries < 0:
            raise ValueError("max_cache_entries must be non-negative")
        if self.cache_ttl_seconds < 0:
            raise ValueError("cache_ttl_seconds must be non-negative")
        if self.max_inflight < 1:
            raise ValueError("max_inflight must be positive")
        if self.max_latency_samples < 1:
            raise ValueError("max_latency_samples must be positive")
        if self.residency_capacity < 1:
            raise ValueError("residency_capacity must be positive")


@dataclass(frozen=True, slots=True)
class InferenceOutcome:
    """Observable result envelope returned by the gateway."""

    result: object
    request_id: str | None
    model: str
    cached: bool
    latency_ms: float
    fallback: bool


@dataclass(frozen=True, slots=True)
class GatewaySnapshot:
    """Serializable health snapshot."""

    enabled: bool
    inflight: int
    total_requests: int
    failures: int
    cache_hits: int
    cache_entries: int
    mean_latency_ms: float
    models: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-compatible representation."""
        return {
            "enabled": self.enabled,
            "inflight": self.inflight,
            "total_requests": self.total_requests,
            "failures": self.failures,
            "cache_hits": self.cache_hits,
            "cache_entries": self.cache_entries,
            "mean_latency_ms": self.mean_latency_ms,
            "models": list(self.models),
        }


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    """Internal immutable cache record."""

    result: object
    created_at: float
    model: str


class IntelligenceGateway:
    """Safe inference gateway sitting between cognition and model providers.

    The gateway is deliberately small and replaceable. It does not know about
    UI, tools, filesystem operations, prompts, or authorization policy.
    """

    def __init__(
        self,
        router: InferenceRouter,
        *,
        chooser: ModelChooser | None = None,
        residency: ModelResidencyManager | None = None,
        config: GatewayConfig | None = None,
        event_sink: Callable[[str, dict[str, object]], object] | None = None,
        canary_guard: object | None = None,
    ) -> None:
        self.router = router
        self.chooser = chooser
        self.config = config or GatewayConfig()
        self.residency = residency or ModelResidencyManager(self.config.residency_capacity)
        self._event_sink = event_sink
        self._canary_guard = canary_guard
        self._enabled = True
        self._semaphore = threading.BoundedSemaphore(self.config.max_inflight)
        self._lock = threading.RLock()
        self._cache: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._latencies: deque[float] = deque(maxlen=self.config.max_latency_samples)
        self._inflight = 0
        self._total_requests = 0
        self._failures = 0
        self._cache_hits = 0

    @property
    def enabled(self) -> bool:
        """Return whether new inference is accepted."""
        with self._lock:
            return self._enabled

    def disable(self) -> None:
        """Reject new inference without destroying cached or residency state."""
        with self._lock:
            self._enabled = False

    def enable(self) -> None:
        """Allow new inference."""
        with self._lock:
            self._enabled = True

    def clear_cache(self) -> None:
        """Clear only derived response cache state."""
        with self._lock:
            self._cache.clear()

    @staticmethod
    def _key(prompt: str, task_type: str, backend_name: str | None, kwargs: dict[str, object]) -> str:
        """Build a stable cache key without retaining raw prompt text."""
        material = repr((prompt, task_type, backend_name, sorted((str(k), repr(v)) for k, v in kwargs.items())))
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def _emit(self, event_type: str, payload: dict[str, object]) -> None:
        if self._event_sink is None:
            return
        try:
            self._event_sink(event_type, payload)
        except Exception:
            logger.exception("gateway_event_failed", extra={"event_type": event_type})

    def _cache_get(self, key: str, now: float) -> _CacheEntry | None:
        if self.config.max_cache_entries == 0 or self.config.cache_ttl_seconds == 0:
            return None
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            if now - entry.created_at > self.config.cache_ttl_seconds:
                self._cache.pop(key, None)
                return None
            self._cache.move_to_end(key)
            self._cache_hits += 1
            return entry

    def _cache_put(self, key: str, result: object, model: str, now: float) -> None:
        if self.config.max_cache_entries == 0 or self.config.cache_ttl_seconds == 0:
            return
        with self._lock:
            self._cache[key] = _CacheEntry(result, now, model)
            self._cache.move_to_end(key)
            while len(self._cache) > self.config.max_cache_entries:
                self._cache.popitem(last=False)

    @staticmethod
    def _result_text(result: object) -> str:
        if isinstance(result, str):
            return result
        return str(getattr(result, "text", result))

    def generate(
        self,
        prompt: str,
        *,
        request_id: str | None = None,
        task_type: str = "default",
        backend_name: str | None = None,
        candidate_models: Sequence[str] | None = None,
        cache: bool = True,
        **kwargs: object,
    ) -> InferenceOutcome:
        """Perform one bounded inference request with deterministic fallback."""
        text = str(prompt)
        if not text.strip():
            raise ValueError("prompt must not be empty")
        if len(text) > self.config.max_prompt_chars:
            raise ValueError("prompt exceeds gateway size limit")
        with self._lock:
            if not self._enabled:
                raise RuntimeError("intelligence gateway disabled")
            self._total_requests += 1
        acquired = self._semaphore.acquire(timeout=0.1)
        if not acquired:
            raise RuntimeError("inference concurrency limit reached")
        with self._lock:
            self._inflight += 1
        started = time.perf_counter()
        key = self._key(text, task_type, backend_name, kwargs)
        try:
            cached = self._cache_get(key, started)
            if cached is not None and cache:
                latency = (time.perf_counter() - started) * 1000.0
                self._record_latency(latency)
                self._emit("inference.cache_hit", {"request_id": request_id or "", "model": cached.model})
                return InferenceOutcome(cached.result, request_id, cached.model, True, latency, False)

            selected = backend_name
            if selected is None and self.chooser is not None:
                selected = self.chooser.choose(
                    task_type=task_type,
                    candidates=candidate_models,
                    task_text=text,
                )
            if selected and self._canary_guard is not None and hasattr(self._canary_guard, "admit"):
                if not bool(self._canary_guard.admit(selected)):
                    raise RuntimeError(f"model {selected!r} is quarantined by canary guard")

            try:
                result = self.router.generate(
                    text,
                    backend_name=selected,
                    request_id=request_id,
                    task_type=task_type,
                    **kwargs,
                )
                fallback = False
            except Exception as primary_exc:
                if selected and self._canary_guard is not None and hasattr(self._canary_guard, "observe"):
                    try:
                        self._canary_guard.observe(selected, success=False, latency_ms=(time.perf_counter() - started) * 1000.0, valid_output=False)
                    except Exception:
                        logger.exception("model_canary_observe_failed")
                if backend_name is not None:
                    raise
                logger.warning("primary_inference_failed", extra={"error": str(primary_exc), "request_id": request_id})
                result = self.router.generate(text, request_id=request_id, task_type=task_type, **kwargs)
                fallback = True

            model = str(getattr(result, "model", None) or selected or "router")
            latency_before_record = (time.perf_counter() - started) * 1000.0
            valid_output = bool(self._result_text(result).strip())
            if self._canary_guard is not None and hasattr(self._canary_guard, "observe"):
                try:
                    self._canary_guard.observe(model, success=True, latency_ms=latency_before_record, valid_output=valid_output)
                except Exception:
                    logger.exception("model_canary_observe_failed")
            self.residency.touch(model, str(getattr(result, "backend", None) or selected or "router"))
            if cache and self._result_text(result).strip():
                self._cache_put(key, result, model, time.perf_counter())
            latency = (time.perf_counter() - started) * 1000.0
            self._record_latency(latency)
            self._emit("inference.completed", {"request_id": request_id or "", "model": model, "latency_ms": round(latency, 3), "fallback": fallback})
            return InferenceOutcome(result, request_id, model, False, latency, fallback)
        except Exception as exc:
            with self._lock:
                self._failures += 1
            self._emit("inference.failed", {"request_id": request_id or "", "error_type": type(exc).__name__})
            raise
        finally:
            with self._lock:
                self._inflight -= 1
            self._semaphore.release()

    def generate_stream(
        self,
        prompt: str,
        *,
        request_id: str | None = None,
        task_type: str = "default",
        backend_name: str | None = None,
        candidate_models: Sequence[str] | None = None,
        **kwargs: object,
    ) -> Generator[object, None, None]:
        """Stream bounded inference through the same admission and routing controls."""
        text = str(prompt)
        if not text.strip():
            raise ValueError("prompt must not be empty")
        if len(text) > self.config.max_prompt_chars:
            raise ValueError("prompt exceeds gateway size limit")
        with self._lock:
            if not self._enabled:
                raise RuntimeError("intelligence gateway disabled")
            self._total_requests += 1
        acquired = self._semaphore.acquire(timeout=0.1)
        if not acquired:
            raise RuntimeError("inference concurrency limit reached")
        with self._lock:
            self._inflight += 1
        started = time.perf_counter()
        selected = backend_name
        model = selected or "router"
        backend_used = selected or "router"
        fallback = False
        yielded = False
        try:
            if selected is None and self.chooser is not None:
                selected = self.chooser.choose(
                    task_type=task_type,
                    candidates=candidate_models,
                    task_text=text,
                )
                model = selected or model
            if selected and self._canary_guard is not None and hasattr(self._canary_guard, "admit"):
                if not bool(self._canary_guard.admit(selected)):
                    raise RuntimeError(f"model {selected!r} is quarantined by canary guard")

            try:
                stream_result = self.router.generate(
                    text,
                    stream=True,
                    backend_name=selected,
                    request_id=request_id,
                    task_type=task_type,
                    **kwargs,
                )
            except Exception as primary_exc:
                if selected and self._canary_guard is not None and hasattr(self._canary_guard, "observe"):
                    try:
                        self._canary_guard.observe(selected, success=False, latency_ms=(time.perf_counter() - started) * 1000.0, valid_output=False)
                    except Exception:
                        logger.exception("model_canary_observe_failed")
                if backend_name is not None:
                    raise
                logger.warning("primary_stream_inference_failed", extra={"error": str(primary_exc), "request_id": request_id})
                stream_result = self.router.generate(
                    text,
                    stream=True,
                    request_id=request_id,
                    task_type=task_type,
                    **kwargs,
                )
                fallback = True

            if isinstance(stream_result, (str, bytes)):
                iterator = iter((stream_result,))
            else:
                try:
                    iterator = iter(stream_result)
                except TypeError:
                    iterator = iter((stream_result,))

            for chunk in iterator:
                yielded = True
                candidate_model = getattr(chunk, "model", None)
                if candidate_model:
                    model = str(candidate_model)
                candidate_backend = getattr(chunk, "backend", None)
                if candidate_backend:
                    backend_used = str(candidate_backend)
                yield chunk

            latency = (time.perf_counter() - started) * 1000.0
            self.residency.touch(model, backend_used)
            valid_output = yielded
            if self._canary_guard is not None and hasattr(self._canary_guard, "observe"):
                try:
                    self._canary_guard.observe(model, success=True, latency_ms=latency, valid_output=valid_output)
                except Exception:
                    logger.exception("model_canary_observe_failed")
            self._record_latency(latency)
            self._emit("inference.stream_completed", {"request_id": request_id or "", "model": model, "latency_ms": round(latency, 3), "fallback": fallback})
        except GeneratorExit:
            latency = (time.perf_counter() - started) * 1000.0
            self._record_latency(latency)
            self._emit("inference.stream_cancelled", {"request_id": request_id or "", "model": model, "latency_ms": round(latency, 3)})
            raise
        except Exception as exc:
            with self._lock:
                self._failures += 1
            self._emit("inference.stream_failed", {"request_id": request_id or "", "error_type": type(exc).__name__})
            raise
        finally:
            with self._lock:
                self._inflight -= 1
            self._semaphore.release()

    def _record_latency(self, latency_ms: float) -> None:
        with self._lock:
            self._latencies.append(max(0.0, latency_ms))

    def snapshot(self) -> GatewaySnapshot:
        """Return a lock-safe health snapshot."""
        with self._lock:
            mean = sum(self._latencies) / len(self._latencies) if self._latencies else 0.0
            models = tuple(sorted(item["model"] for item in self.residency.snapshot()))
            return GatewaySnapshot(self._enabled, self._inflight, self._total_requests, self._failures, self._cache_hits, len(self._cache), mean, models)



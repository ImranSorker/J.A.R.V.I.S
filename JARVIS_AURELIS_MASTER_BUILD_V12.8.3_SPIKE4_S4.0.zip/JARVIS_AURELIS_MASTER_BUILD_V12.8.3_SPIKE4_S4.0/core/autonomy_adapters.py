"""Adapters that converge legacy autonomy components behind AutonomyFabric."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

from core.autonomy_fabric import AutonomyFabric
from core.contracts.autonomy import Goal, MissionStepSpec

logger = logging.getLogger("jarvis.autonomy_adapters")


@dataclass(frozen=True, slots=True)
class LegacyExecutionAdapter:
    """Adapt an existing JobEngine-like submitter to the mission fabric."""

    submitter: Callable[..., Any]

    def execute(self, mission_id: str, goal: Goal, steps: Sequence[MissionStepSpec]) -> Any:
        """Submit a durable legacy job while retaining mission authority in the fabric."""
        payload = [
            {
                "id": step.step_id,
                "name": step.name,
                "depends_on": list(step.dependencies),
                "metadata": dict(step.metadata),
                "capability": step.capability,
            }
            for step in steps
        ]
        try:
            return self.submitter(goal.objective, payload, owner=goal.owner, metadata={"mission_id": mission_id})
        except TypeError:
            return self.submitter(goal.objective, payload)


class ExecutiveFabricBridge:
    """Compatibility facade that submits executive goals into the canonical store."""

    def __init__(self, fabric: AutonomyFabric) -> None:
        self.fabric = fabric

    def submit_goal(self, description: str, *, priority: int = 5, owner: str = "jarvis", metadata: Mapping[str, Any] | None = None) -> str:
        """Create a canonical goal and return its stable ID."""
        goal = self.fabric.create_goal(
            description,
            priority=max(1, min(10, int(priority))),
            owner=owner or "jarvis",
            constraints=dict(metadata or {}),
        )
        logger.info("executive_goal_bridge_submitted", extra={"goal_id": goal.goal_id})
        return goal.goal_id


class RecoveryStrategyAdapter:
    """Expose a legacy RecoverySwarm as a bounded recovery strategy provider."""

    def __init__(self, recovery_swarm: Any) -> None:
        self.recovery_swarm = recovery_swarm

    def recover(self, incident: str, strategies: list[tuple[str, Callable[[str], Any]]], verify: Callable[[], bool]) -> dict[str, Any]:
        """Delegate recovery without allowing it to mutate mission state directly."""
        return dict(self.recovery_swarm.recover(incident, strategies, verify))



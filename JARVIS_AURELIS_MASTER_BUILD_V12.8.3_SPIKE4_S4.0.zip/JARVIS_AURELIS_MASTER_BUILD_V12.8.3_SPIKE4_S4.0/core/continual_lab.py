"""Compatibility import for the canonical continual-learning laboratory."""
from core.continual_learning import ContinualLearningLab

ContinualLab = ContinualLearningLab
__all__ = ["ContinualLearningLab", "ContinualLab"]

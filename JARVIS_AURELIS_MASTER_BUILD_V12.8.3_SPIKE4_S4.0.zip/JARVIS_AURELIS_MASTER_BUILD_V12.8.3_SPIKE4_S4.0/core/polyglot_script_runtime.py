"""Bounded execution adapters for optional Lua and Julia skill workloads.

The adapters deliberately reuse the OS sandbox instead of creating a second
process-security implementation.  They accept source text only, execute inside
the configured workspace, enforce resource bounds, and return structured status
when the optional interpreter is not installed.
"""
from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from security.os_sandbox import OSSandbox

logger = logging.getLogger("jarvis.polyglot_scripts")


@dataclass(frozen=True, slots=True)
class ScriptRuntimeResult:
    """Immutable result returned by a bounded script runtime."""

    ok: bool
    language: str
    stdout: str = ""
    stderr: str = ""
    returncode: int | None = None
    error: str | None = None
    timed_out: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe representation."""
        return {
            "ok": self.ok,
            "language": self.language,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "returncode": self.returncode,
            "error": self.error,
            "timed_out": self.timed_out,
        }


class BoundedScriptRuntime:
    """Execute explicitly selected script languages through one sandbox boundary."""

    _COMMANDS = {
        "lua": ("lua", "lua5.4"),
        "julia": ("julia",),
    }

    def __init__(
        self,
        workspace: str | Path,
        *,
        timeout_seconds: float = 30.0,
        max_memory_mb: int = 512,
        allow_network: bool = False,
        strict_isolation: bool = True,
        max_source_bytes: int = 1_000_000,
    ) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.sandbox = OSSandbox(
            self.workspace,
            timeout_seconds=timeout_seconds,
            max_memory_mb=max_memory_mb,
            allow_network=allow_network,
            strict_isolation=strict_isolation,
        )
        self.max_source_bytes = max(1024, min(int(max_source_bytes), 10_000_000))

    def available(self, language: str) -> bool:
        """Return whether a supported interpreter is available on PATH."""
        commands = self._COMMANDS.get(str(language).strip().lower())
        return bool(commands and any(shutil.which(command) for command in commands))

    def languages(self) -> dict[str, bool]:
        """Return deterministic availability for all supported script languages."""
        return {language: self.available(language) for language in sorted(self._COMMANDS)}

    def execute(self, language: str, source: str, *, args: Sequence[str] = ()) -> ScriptRuntimeResult:
        """Execute source in a bounded, non-shell subprocess."""
        lang = str(language).strip().lower()
        commands = self._COMMANDS.get(lang)
        if commands is None:
            return ScriptRuntimeResult(False, lang, error="unsupported script language")
        if not isinstance(source, str) or not source.strip():
            return ScriptRuntimeResult(False, lang, error="script source must not be empty")
        if len(source.encode("utf-8")) > self.max_source_bytes:
            return ScriptRuntimeResult(False, lang, error="script source exceeds configured limit")
        executable = next((shutil.which(command) for command in commands if shutil.which(command)), None)
        if executable is None:
            return ScriptRuntimeResult(False, lang, error=f"{lang} interpreter is not installed")
        safe_args = tuple(str(value) for value in args)
        if len(safe_args) > 32 or any(len(value) > 4096 for value in safe_args):
            return ScriptRuntimeResult(False, lang, error="script arguments exceed configured limits")

        suffix = ".lua" if lang == "lua" else ".jl"
        import tempfile
        fd, filename = tempfile.mkstemp(prefix="jarvis-script-", suffix=suffix, dir=self.workspace, text=True)
        path = Path(filename)
        try:
            with open(fd, "w", encoding="utf-8", closefd=True) as handle:
                handle.write(source)
            command = (executable, str(path.name), *safe_args)
            result = self.sandbox.run(command)
            return ScriptRuntimeResult(
                ok=bool(result.get("ok")),
                language=lang,
                stdout=str(result.get("stdout", "")),
                stderr=str(result.get("stderr", "")),
                returncode=int(result["returncode"]) if result.get("returncode") is not None else None,
                error=None if result.get("ok") else str(result.get("stderr", "")).strip() or "script execution failed",
                timed_out=bool(result.get("timed_out", False)),
            )
        except Exception as exc:
            logger.exception("script_runtime_failed", extra={"language": lang})
            return ScriptRuntimeResult(False, lang, error=f"{type(exc).__name__}: {exc}")
        finally:
            path.unlink(missing_ok=True)



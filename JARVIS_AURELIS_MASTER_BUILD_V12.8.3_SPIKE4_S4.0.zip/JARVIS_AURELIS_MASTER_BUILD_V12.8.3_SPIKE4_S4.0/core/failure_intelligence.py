"""P2-I Failure Intelligence.

Canonical, tenant-isolated failure ingestion, correlation, root-cause hypotheses,
remediation proposals, diagnostic artifact generation, and regression/benchmark
artifact generation.  The engine proposes changes; it never applies them.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from core.agent_harness import ExecutionContext
from core.event_fabric import (
    AuthContext,
    EventEnvelope,
    EventFilter,
    EventTaxonomy,
    ProducedBy,
    SubscriberContext,
    SubscriptionHandle,
)
from core.experience_memory import ExperienceMemory, build_memory_item
from core.kernel_12_8_0.canonical import canonical_bytes, canonical_json
from core.schema_validator import SchemaValidationError, SchemaValidator


ROOT = Path(__file__).resolve().parent
SCHEMA_DIR = ROOT / "schemas"
FAILURE_SCHEMA = SCHEMA_DIR / "failure_record_v1.schema.json"
HYPOTHESIS_SCHEMA = SCHEMA_DIR / "failure_hypothesis_v1.schema.json"
REMEDIATION_SCHEMA = SCHEMA_DIR / "failure_remediation_v1.schema.json"
ARTIFACT_SCHEMAS = {
    "regression_case": SCHEMA_DIR / "failure_regression_case_v1.schema.json",
    "benchmark_case": SCHEMA_DIR / "failure_benchmark_case_v1.schema.json",
    "warning": SCHEMA_DIR / "failure_warning_v1.schema.json",
    "policy_proposal": SCHEMA_DIR / "failure_policy_proposal_v1.schema.json",
    "diagnostic": SCHEMA_DIR / "failure_diagnostic_v1.schema.json",
    "correlation_graph": SCHEMA_DIR / "failure_correlation_graph_v1.schema.json",
}

ORIGINS = (
    "agent", "skill", "tool", "model", "workflow", "harness", "bus", "storage", "memory", "security", "environment", "external"
)
CATEGORIES = (
    "correctness", "reliability", "resource", "latency", "security", "integrity", "protocol", "dependency",
    "permission", "reasoning", "coordination", "recovery", "cascading",
)
SEVERITIES = ("critical", "high", "medium", "low", "informational")
REPRODUCIBILITIES = ("always", "intermittent", "once", "unknown", "environment_dependent", "input_dependent")
CAUSE_CLASSES = (
    "invalid_input", "missing_dependency", "policy_denied", "resource_exhausted", "race_condition", "model_hallucination",
    "tool_timeout", "schema_violation", "signature_failure", "malformed_signal", "cancellation", "crash", "unknown",
)
ANALYSIS_METHODS = ("rule_based", "correlation", "differential", "replay", "manual", "hybrid")
NON_ACTIONABLE_REASONS = (
    "expected_denial", "test_artifact", "external_transient", "duplicate", "out_of_scope", "insufficient_evidence"
)
REMEDIATION_STATUS = ("proposed", "approved", "applied", "rejected", "superseded", "none")
REMEDIATION_KINDS = (
    "rollback", "retry_policy_change", "budget_adjustment", "policy_adjustment", "skill_fix", "tool_fix", "model_swap",
    "config_change", "environment_fix", "code_fix", "doc_update", "non_actionable",
)
RISK_LEVELS = ("none", "low", "medium", "high", "critical")
BLAST_RADIUS = ("none", "local", "regional", "global")
FAILURE_STATES = ("open", "triaged", "analyzed", "remediated", "verified", "closed", "non_actionable")
SCOPES = ("single_execution", "single_agent", "multi_agent", "system_wide")

_EVENT_NAMES = (
    "Ingested", "Triaged", "HypothesisProposed", "HypothesisVerified", "RemediationProposed", "RegressionGenerated",
    "BenchmarkGenerated", "WarningEmitted", "PolicyProposed", "DiagnosticGenerated", "Closed", "NonActionable", "Reopened",
)

# P2-I deliberately reuses existing authorization scope families; it does not mint
# a new permission or add a new capability to the security authority.
READ_SCOPE = "memory.read.failure"
WRITE_SCOPE = "memory.write.failure"
SYSTEM_PUBLISH_SCOPE = "events.publish.system"
SYSTEM_SUBSCRIBE_SCOPE = "events.subscribe.system"
SECURITY_PUBLISH_SCOPE = "events.publish.security"
SECRET_SCOPE = "secrets.read"
ADMIN_SCOPE = "memory.admin"

_UUID_NAMESPACE = uuid.UUID("4e9cf6d0-5e26-4fd3-a9f7-3db7a8a4f9c1")


class FailureIntelligenceError(RuntimeError):
    """Base P2-I error."""


class FailureValidationError(FailureIntelligenceError, ValueError):
    """Schema or classification validation failed."""


class FailureIntegrityError(FailureIntelligenceError, ValueError):
    """Signature, hash-chain, or integrity verification failed."""


class FailureAccessDenied(FailureIntelligenceError, PermissionError):
    """Tenant or scope authorization failed."""


class FailureNotFound(FailureIntelligenceError, LookupError):
    """Failure or artifact does not exist."""


class FailurePolicyError(FailureIntelligenceError, ValueError):
    """A failure policy gate rejected an operation."""


class FailureDuplicate(FailureIntelligenceError):
    """An idempotent ingress matched an existing failure."""


@dataclass(frozen=True, slots=True)
class AnalysisBudget:
    max_hypotheses: int = 12
    max_group_members: int = 250
    max_cpu_seconds: float = 2.0


@dataclass(frozen=True, slots=True)
class FailureConfig:
    temporal_window_seconds: float = 30.0
    warning_frequency_threshold: int = 3
    correlation_limit: int = 250
    analysis_budget: AnalysisBudget = AnalysisBudget()


class FailureStore:
    """SQLite append-only failure/artifact store with HMAC-protected chain metadata."""

    def __init__(self, path: str | Path, storage_secret: bytes) -> None:
        if len(storage_secret) < 32:
            raise ValueError("failure store secret must be at least 32 bytes")
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = bytes(storage_secret)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS failures (tenant_id TEXT NOT NULL, failure_id TEXT NOT NULL, failure_version INTEGER NOT NULL, record_json TEXT NOT NULL, record_hash TEXT NOT NULL, previous_hash TEXT NOT NULL, integrity_tag TEXT NOT NULL, signature TEXT NOT NULL, created_seq INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, UNIQUE(tenant_id,failure_id,failure_version))"
        )
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS ingress_dedupe (tenant_id TEXT NOT NULL, correlation_id TEXT NOT NULL, failure_signature TEXT NOT NULL, observed_at TEXT NOT NULL, failure_id TEXT NOT NULL, PRIMARY KEY(tenant_id,correlation_id,failure_signature,observed_at))"
        )
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS artifacts (tenant_id TEXT NOT NULL, artifact_id TEXT NOT NULL, artifact_version INTEGER NOT NULL, artifact_type TEXT NOT NULL, artifact_json TEXT NOT NULL, artifact_hash TEXT NOT NULL, signature TEXT NOT NULL, writer_key_id TEXT NOT NULL, created_seq INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, UNIQUE(tenant_id,artifact_id,artifact_version))"
        )
        self._db.commit()
        if not self.verify_chain():
            raise FailureIntegrityError("failure store integrity verification failed at startup")

    def _tag(self, tenant_id: str, record_json: str, record_hash: str, previous_hash: str) -> str:
        return hmac.new(
            self._secret,
            canonical_bytes({"tenant_id": tenant_id, "record_json": record_json, "record_hash": record_hash, "previous_hash": previous_hash}),
            hashlib.sha256,
        ).hexdigest()

    @staticmethod
    def _row_doc(row: tuple[Any, ...]) -> dict[str, Any]:
        return json.loads(str(row[0]))

    def last_chain_hash(self, tenant_id: str) -> str:
        row = self._db.execute(
            "SELECT record_hash FROM failures WHERE tenant_id=? ORDER BY created_seq DESC LIMIT 1", (tenant_id,)
        ).fetchone()
        return str(row[0]) if row else "0" * 64

    def next_version(self, tenant_id: str, failure_id: str) -> int:
        row = self._db.execute(
            "SELECT COALESCE(MAX(failure_version),0) FROM failures WHERE tenant_id=? AND failure_id=?",
            (tenant_id, failure_id),
        ).fetchone()
        return int(row[0]) + 1

    def append(self, tenant_id: str, record: Mapping[str, Any]) -> None:
        doc = dict(record)
        with self._lock, self._db:
            record_json = canonical_json(doc).decode("utf-8")
            previous = self.last_chain_hash(tenant_id)
            expected_version = self.next_version(tenant_id, str(doc["failure_id"]))
            if int(doc["failure_version"]) != expected_version:
                raise FailureIntegrityError("failure_version is not monotonic")
            if str(doc["chain_prev_hash"]) != previous:
                raise FailureIntegrityError("chain_prev_hash does not match tenant chain tip")
            unsigned = _unsigned_record(doc)
            expected_integrity = hashlib.sha256(canonical_bytes(unsigned)).hexdigest()
            if not hmac.compare_digest(expected_integrity, str(doc["integrity_hash"])):
                raise FailureIntegrityError("failure integrity hash mismatch")
            if not _verify_signature(doc):
                raise FailureIntegrityError("failure signature invalid")
            record_hash = hashlib.sha256(canonical_bytes({"record": doc, "previous_hash": previous})).hexdigest()
            tag = self._tag(tenant_id, record_json, record_hash, previous)
            self._db.execute(
                "INSERT INTO failures(tenant_id,failure_id,failure_version,record_json,record_hash,previous_hash,integrity_tag,signature,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (tenant_id, str(doc["failure_id"]), int(doc["failure_version"]), record_json, record_hash, previous, tag, str(doc["signature"]), time.time()),
            )

    def get(self, tenant_id: str, failure_id: str, version: int | None = None) -> dict[str, Any] | None:
        if version is None:
            row = self._db.execute(
                "SELECT record_json FROM failures WHERE tenant_id=? AND failure_id=? ORDER BY failure_version DESC LIMIT 1",
                (tenant_id, failure_id),
            ).fetchone()
        else:
            row = self._db.execute(
                "SELECT record_json FROM failures WHERE tenant_id=? AND failure_id=? AND failure_version=?",
                (tenant_id, failure_id, int(version)),
            ).fetchone()
        return json.loads(str(row[0])) if row else None

    def history(self, tenant_id: str, failure_id: str) -> list[dict[str, Any]]:
        rows = self._db.execute(
            "SELECT record_json FROM failures WHERE tenant_id=? AND failure_id=? ORDER BY failure_version",
            (tenant_id, failure_id),
        ).fetchall()
        return [json.loads(str(row[0])) for row in rows]

    def query(self, tenant_id: str, *, signature: str | None = None, observed_after: str | None = None, observed_before: str | None = None, limit: int | None = 250) -> list[dict[str, Any]]:
        clauses = ["tenant_id=?"]
        values: list[Any] = [tenant_id]
        if signature:
            clauses.append("json_extract(record_json,'$.failure_signature')=?")
            values.append(signature)
        if observed_after:
            clauses.append("json_extract(record_json,'$.when.observed_at')>=?")
            values.append(observed_after)
        if observed_before:
            clauses.append("json_extract(record_json,'$.when.observed_at')<=?")
            values.append(observed_before)
        sql = f"SELECT record_json FROM failures WHERE {' AND '.join(clauses)} ORDER BY created_seq"
        if limit is not None:
            sql += " LIMIT ?"; values.append(max(1,int(limit)))
        rows = self._db.execute(sql, tuple(values)).fetchall()
        # Return the latest version for each failure_id while keeping stable ordering.
        latest: dict[str, dict[str, Any]] = {}
        order: list[str] = []
        for row in rows:
            doc = json.loads(str(row[0]))
            fid = str(doc["failure_id"])
            if fid not in latest:
                order.append(fid)
            latest[fid] = doc
        return [latest[fid] for fid in order]

    def find_idempotent(self, tenant_id: str, correlation_id: str, failure_signature: str, observed_at: str) -> str | None:
        row = self._db.execute(
            "SELECT failure_id FROM ingress_dedupe WHERE tenant_id=? AND correlation_id=? AND failure_signature=? AND observed_at=?",
            (tenant_id, correlation_id, failure_signature, observed_at),
        ).fetchone()
        return str(row[0]) if row else None

    def put_idempotency(self, tenant_id: str, correlation_id: str, failure_signature: str, observed_at: str, failure_id: str) -> None:
        with self._lock, self._db:
            self._db.execute(
                "INSERT OR IGNORE INTO ingress_dedupe(tenant_id,correlation_id,failure_signature,observed_at,failure_id) VALUES(?,?,?,?,?)",
                (tenant_id, correlation_id, failure_signature, observed_at, failure_id),
            )

    def append_artifact(self, tenant_id: str, document: Mapping[str, Any], *, signature: str, writer_key_id: str) -> None:
        doc = dict(document)
        raw = canonical_json(doc)
        artifact_hash = hashlib.sha256(raw).hexdigest()
        aid = str(doc["artifact_id"])
        version = int(doc["artifact_version"])
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO artifacts(tenant_id,artifact_id,artifact_version,artifact_type,artifact_json,artifact_hash,signature,writer_key_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (tenant_id, aid, version, str(doc["artifact_type"]), raw.decode("utf-8"), artifact_hash, signature, writer_key_id, time.time()),
            )

    def artifact(self, tenant_id: str, artifact_id: str, version: int | None = None) -> dict[str, Any] | None:
        if version is None:
            row = self._db.execute(
                "SELECT artifact_json FROM artifacts WHERE tenant_id=? AND artifact_id=? ORDER BY artifact_version DESC LIMIT 1",
                (tenant_id, artifact_id),
            ).fetchone()
        else:
            row = self._db.execute(
                "SELECT artifact_json FROM artifacts WHERE tenant_id=? AND artifact_id=? AND artifact_version=?",
                (tenant_id, artifact_id, int(version)),
            ).fetchone()
        return json.loads(str(row[0])) if row else None

    def artifact_history(self, tenant_id: str, artifact_id: str) -> list[dict[str, Any]]:
        rows = self._db.execute(
            "SELECT artifact_json FROM artifacts WHERE tenant_id=? AND artifact_id=? ORDER BY artifact_version",
            (tenant_id, artifact_id),
        ).fetchall()
        return [json.loads(str(row[0])) for row in rows]

    def list_artifacts(self, tenant_id: str, failure_id: str, artifact_type: str | None = None) -> list[dict[str, Any]]:
        if artifact_type is None:
            rows = self._db.execute(
                "SELECT artifact_json FROM artifacts WHERE tenant_id=? AND json_extract(artifact_json,'$.failure_id')=? ORDER BY created_seq",
                (tenant_id, failure_id),
            ).fetchall()
        else:
            rows = self._db.execute(
                "SELECT artifact_json FROM artifacts WHERE tenant_id=? AND json_extract(artifact_json,'$.failure_id')=? AND artifact_type=? ORDER BY created_seq",
                (tenant_id, failure_id, artifact_type),
            ).fetchall()
        return [json.loads(str(row[0])) for row in rows]

    def verify_chain(self) -> bool:
        try:
            previous = "0" * 64
            rows = self._db.execute(
                "SELECT tenant_id,failure_id,failure_version,record_json,record_hash,previous_hash,integrity_tag,signature FROM failures ORDER BY tenant_id,created_seq"
            ).fetchall()
            last_by_tenant: dict[str, str] = {}
            last_version: dict[tuple[str, str], int] = {}
            for tenant_id, failure_id, version, record_json, record_hash, previous_hash, tag, signature in rows:
                tenant = str(tenant_id)
                prev = last_by_tenant.get(tenant, "0" * 64)
                if str(previous_hash) != prev:
                    return False
                doc = json.loads(str(record_json))
                if str(doc["failure_id"]) != str(failure_id) or int(doc["failure_version"]) != int(version):
                    return False
                if int(version) != last_version.get((tenant, str(failure_id)), 0) + 1:
                    return False
                if not hmac.compare_digest(str(doc.get("chain_prev_hash")), str(previous_hash)):
                    return False
                if not hmac.compare_digest(str(doc.get("signature")), str(signature)):
                    return False
                expected_integrity = hashlib.sha256(canonical_bytes(_unsigned_record(doc))).hexdigest()
                if not hmac.compare_digest(expected_integrity, str(doc.get("integrity_hash"))):
                    return False
                expected_hash = hashlib.sha256(canonical_bytes({"record": doc, "previous_hash": prev})).hexdigest()
                if not hmac.compare_digest(expected_hash, str(record_hash)):
                    return False
                expected_tag = self._tag(tenant, str(record_json), str(record_hash), str(previous_hash))
                if not hmac.compare_digest(expected_tag, str(tag)):
                    return False
                last_by_tenant[tenant] = expected_hash
                last_version[(tenant, str(failure_id))] = int(version)
            return True
        except (sqlite3.DatabaseError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return False

    def close(self) -> None:
        with self._lock:
            self._db.close()


class FailureIntelligence:
    """Canonical P2-I engine."""

    analysis_version = "1.0.0"
    engine_version = "1.0.0"

    def __init__(
        self,
        *,
        tenant_id: str,
        store: FailureStore,
        signer: Ed25519PrivateKey | None = None,
        event_bus: Any | None = None,
        event_auth_context: AuthContext | None = None,
        experience_memory: ExperienceMemory | None = None,
        config: FailureConfig = FailureConfig(),
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not str(tenant_id).strip():
            raise ValueError("tenant_id is required")
        self.tenant_id = str(tenant_id)
        self.store = store
        self.signer = signer or Ed25519PrivateKey.generate()
        self.event_bus = event_bus
        self.event_auth_context = event_auth_context
        self.experience_memory = experience_memory
        self.config = config
        self.clock = clock
        self._lock = threading.RLock()
        self._subscriptions: list[SubscriptionHandle] = []

    @property
    def public_key_b64(self) -> str:
        return base64.b64encode(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode("ascii")

    @property
    def writer_key_id(self) -> str:
        return hashlib.sha256(self.signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).hexdigest()

    def _auth(self, auth_context: Any, *, operation: str, sensitivity: str = "internal", security_write: bool = False) -> dict[str, Any]:
        if isinstance(auth_context, ExecutionContext):
            tenant = auth_context.tenant_id
            scopes = tuple(auth_context.auth_context.scopes)
            principal = auth_context.principal
            verified = bool(auth_context.auth_context.authorization_token)
        elif isinstance(auth_context, Mapping):
            tenant = auth_context.get("tenant_id", self.tenant_id)
            scopes = tuple(auth_context.get("scopes", ()))
            principal = str(auth_context.get("principal", "unknown"))
            verified = bool(auth_context.get("authorization_verified", auth_context.get("authorization_token", True)))
        else:
            raise FailureAccessDenied("verified authorization context is required")
        if str(tenant) != self.tenant_id:
            raise FailureAccessDenied("cross-tenant failure access denied")
        scope_set = set(str(x) for x in scopes)
        if operation == "read":
            allowed = {READ_SCOPE, ADMIN_SCOPE, SYSTEM_SUBSCRIBE_SCOPE}
        elif operation in {"ingest", "analyze", "generate", "close"}:
            allowed = {WRITE_SCOPE, ADMIN_SCOPE, SYSTEM_PUBLISH_SCOPE}
        elif operation == "security_propose" or security_write:
            allowed = {SECURITY_PUBLISH_SCOPE}
        else:
            allowed = {ADMIN_SCOPE}
        if not scope_set.intersection(allowed):
            raise FailureAccessDenied(f"missing scope for failure operation: {operation}")
        if not verified:
            raise FailureAccessDenied("authorization context is not verified")
        if sensitivity == "secret" and not scope_set.intersection({SECRET_SCOPE, ADMIN_SCOPE}):
            raise FailureAccessDenied("secret failure requires secret scope")
        return {"tenant_id": self.tenant_id, "scopes": tuple(sorted(scope_set)), "principal": principal}

    def _auth_for_event(self) -> AuthContext:
        if self.event_auth_context is None:
            raise FailureAccessDenied("event publication authorization must be supplied by the caller")
        if SYSTEM_PUBLISH_SCOPE not in set(self.event_auth_context.scopes):
            raise FailureAccessDenied("missing system event publication scope")
        return self.event_auth_context

    def _emit(self, name: str, payload: Mapping[str, Any], *, correlation_id: str, causation_id: str | None = None, sensitivity: str = "internal") -> None:
        if self.event_bus is None:
            return
        producer = ProducedBy("system", "failure-intelligence", self.writer_key_id, "system")
        event = EventEnvelope.create(
            event_type="Failure",
            event_name=name,
            payload=dict(payload),
            produced_by=producer,
            auth_context=self._auth_for_event(),
            tenant_id=self.tenant_id,
            partition_key=str(correlation_id),
            correlation_id=str(correlation_id),
            causation_id=causation_id,
            priority="high" if name in {"HypothesisVerified", "PolicyProposed", "Closed", "Reopened"} else None,
            sensitivity=sensitivity,
            signing_key=self.signer,
        )
        self.event_bus.publish(event)

    @staticmethod
    def canonical_failure_signature(origin: str, category: str, what_happened: str, where: Mapping[str, Any], cause_class: str) -> str:
        material = {"origin": origin, "category": category, "what_happened": what_happened, "where": dict(where), "cause_class": cause_class}
        return hashlib.sha256(canonical_bytes(material)).hexdigest()

    @staticmethod
    def _uuid(seed: Mapping[str, Any]) -> str:
        return str(uuid.uuid5(_UUID_NAMESPACE, hashlib.sha256(canonical_bytes(seed)).hexdigest()))

    def _new_record_base(self, normalized: Mapping[str, Any], *, failure_id: str | None = None) -> dict[str, Any]:
        now = str(normalized["when"]["observed_at"])
        fid = str(failure_id or uuid.uuid4())
        origin = str(normalized["origin"])
        category = str(normalized["category"])
        cause_class = str(normalized["cause"]["cause_class"])
        signature = self.canonical_failure_signature(origin, category, str(normalized["what_happened"]), dict(normalized["where"]), cause_class)
        record = {
            "failure_id": fid,
            "failure_version": 1,
            "tenant_id": self.tenant_id,
            "sensitivity": str(normalized.get("sensitivity", "internal")),
            "origin": origin,
            "category": category,
            "severity": str(normalized["severity"]),
            "reproducibility": str(normalized.get("reproducibility", "unknown")),
            "failure_signature": signature,
            "what_happened": str(normalized["what_happened"]),
            "where": dict(normalized["where"]),
            "when": {"observed_at": now, "started_at": normalized["when"].get("started_at"), "duration_ms": normalized["when"].get("duration_ms")},
            "correlation_id": str(normalized["correlation_id"]),
            "causation_id": normalized.get("causation_id"),
            "parent_failure_id": normalized.get("parent_failure_id"),
            "cause": {
                "cause_class": cause_class,
                "root_cause": None,
                "contributing_factors": list(normalized.get("cause", {}).get("contributing_factors", [])),
                "hypotheses": [],
                "evidence_refs": list(normalized.get("cause", {}).get("evidence_refs", [])),
                "analysis_method": str(normalized.get("cause", {}).get("analysis_method", "rule_based")),
                "analysis_version": str(normalized.get("cause", {}).get("analysis_version", self.analysis_version)),
            },
            "affected": {
                "agents": list(normalized.get("affected", {}).get("agents", [])),
                "skills": list(normalized.get("affected", {}).get("skills", [])),
                "tools": list(normalized.get("affected", {}).get("tools", [])),
                "models": list(normalized.get("affected", {}).get("models", [])),
                "workflows": list(normalized.get("affected", {}).get("workflows", [])),
                "tenants": [self.tenant_id],
                "scope": str(normalized.get("affected", {}).get("scope", "single_execution")),
            },
            "blast_radius": str(normalized.get("blast_radius", "local")),
            "execution_context": copy.deepcopy(normalized.get("execution_context", {"execution_id": None, "mode": None, "budgets": None, "budget_utilization": None, "deterministic": None, "seed": None})),
            "environment_snapshot_ref": normalized.get("environment_snapshot_ref"),
            "inputs_ref": normalized.get("inputs_ref"),
            "logs_ref": normalized.get("logs_ref"),
            "traces_ref": normalized.get("traces_ref"),
            "state_snapshot_ref": normalized.get("state_snapshot_ref"),
            "remediation": {"status": "none", "steps": [], "remediation_proposal_ref": None, "applied_at": None, "applied_by": None, "verification_ref": None},
            "regression": {"test_ref": None, "benchmark_ref": None, "golden_dataset_ref": None, "reproduces_at": None},
            "generated": {"regression_case_ids": [], "benchmark_case_ids": [], "warning_ids": [], "policy_proposal_ids": [], "diagnostic_ids": []},
            "failure_memory_id": None,
            "state": "open",
            "closed_at": None,
            "closed_reason": None,
            "signature": "",
            "writer_key_id": self.writer_key_id,
            "writer_public_key": self.public_key_b64,
            "integrity_hash": "",
            "chain_prev_hash": "0" * 64,
        }
        record["chain_prev_hash"] = self.store.last_chain_hash(self.tenant_id)
        return self._sign_record(record)

    def _sign_record(self, document: Mapping[str, Any]) -> dict[str, Any]:
        doc = copy.deepcopy(dict(document))
        doc.pop("signature", None)
        doc.pop("integrity_hash", None)
        unsigned = {**doc}
        integrity = hashlib.sha256(canonical_bytes(unsigned)).hexdigest()
        doc["integrity_hash"] = integrity
        signature = base64.b64encode(self.signer.sign(canonical_bytes(doc))).decode("ascii")
        doc["signature"] = signature
        doc["writer_key_id"] = self.writer_key_id
        doc["writer_public_key"] = self.public_key_b64
        return doc

    def validate_record(self, record: Mapping[str, Any]) -> None:
        doc = copy.deepcopy(dict(record))
        try:
            schema = json.loads(FAILURE_SCHEMA.read_text(encoding="utf-8"))
            SchemaValidator(max_errors=128).validate_or_raise(doc, schema)
        except SchemaValidationError as exc:
            raise FailureValidationError(str(exc)) from exc
        self._validate_record_semantics(doc)
        if not _verify_signature(doc):
            raise FailureIntegrityError("failure record signature invalid")
        expected = hashlib.sha256(canonical_bytes(_unsigned_record(doc))).hexdigest()
        if not hmac.compare_digest(expected, str(doc["integrity_hash"])):
            raise FailureIntegrityError("failure record integrity hash invalid")

    def _validate_record_semantics(self, doc: Mapping[str, Any]) -> None:
        if doc["tenant_id"] != self.tenant_id:
            raise FailureAccessDenied("failure record tenant mismatch")
        if doc["origin"] not in ORIGINS or doc["category"] not in CATEGORIES or doc["severity"] not in SEVERITIES or doc["reproducibility"] not in REPRODUCIBILITIES:
            raise FailureValidationError("invalid failure taxonomy axis")
        expected_sig = self.canonical_failure_signature(doc["origin"], doc["category"], doc["what_happened"], doc["where"], doc["cause"]["cause_class"])
        if expected_sig != doc["failure_signature"]:
            raise FailureValidationError("failure_signature is not canonical")
        cause = doc["cause"]
        if cause["cause_class"] not in CAUSE_CLASSES:
            raise FailureValidationError("invalid cause_class")
        for hypothesis in cause.get("hypotheses", []):
            SchemaValidator(max_errors=64).validate_or_raise(hypothesis, json.loads(HYPOTHESIS_SCHEMA.read_text(encoding="utf-8")))
        if cause.get("root_cause") is not None:
            verified = [h for h in cause.get("hypotheses", []) if bool(h.get("verified"))]
            if not verified:
                raise FailurePolicyError("root_cause can only be populated by a verified hypothesis")
        if doc["state"] == "verified" and not doc["remediation"].get("verification_ref"):
            raise FailurePolicyError("verified failure must carry verification_ref")
        if doc["state"] == "closed" and not doc.get("closed_reason"):
            raise FailurePolicyError("closed failure requires closed_reason")
        if doc["state"] == "non_actionable" and not doc.get("closed_reason"):
            raise FailurePolicyError("non-actionable failure requires signed reason")

    def _append_version(self, current: Mapping[str, Any], mutator: Callable[[dict[str, Any]], dict[str, Any]]) -> dict[str, Any]:
        # Serialize the complete read-modify-sign-append sequence so concurrent
        # lifecycle updates cannot derive the same version or chain tip.
        with self._lock:
            latest = self.store.get(self.tenant_id, str(current["failure_id"]))
            if latest is None:
                raise FailureNotFound(str(current["failure_id"]))
            next_doc = mutator(copy.deepcopy(dict(latest)))
            next_doc["failure_version"] = int(latest["failure_version"]) + 1
            next_doc["chain_prev_hash"] = self.store.last_chain_hash(self.tenant_id)
            next_doc["writer_key_id"] = self.writer_key_id
            next_doc["writer_public_key"] = self.public_key_b64
            next_doc = self._sign_record(next_doc)
            self.validate_record(next_doc)
            self.store.append(self.tenant_id, next_doc)
            return next_doc

    @staticmethod
    def _normalize_timestamp(value: Any, fallback: float) -> str:
        if value is None:
            dt = datetime.fromtimestamp(fallback, tz=timezone.utc)
            return dt.isoformat().replace("+00:00", "Z")
        text = str(value)
        if text.endswith("Z"):
            return text
        try:
            dt = datetime.fromisoformat(text)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        except ValueError as exc:
            raise FailureValidationError("observed_at must be RFC3339") from exc

    def _normalize_signal(self, signal: Mapping[str, Any], *, source: str = "direct") -> dict[str, Any]:
        raw = dict(signal)
        event_type = str(raw.get("event_type") or raw.get("type") or "")
        event_name = str(raw.get("event_name") or raw.get("name") or "")
        payload = raw.get("payload") if isinstance(raw.get("payload"), Mapping) else raw
        payload = dict(payload)
        malformed = False
        if not event_type and not raw.get("origin"):
            malformed = True

        explicit_origin = raw.get("origin") or payload.get("origin")
        if explicit_origin in ORIGINS:
            origin = str(explicit_origin)
        elif event_type.startswith("Agent.Execution"):
            origin = "harness" if source in {"event", "harness"} else "agent"
        elif event_type.startswith("Agent.Lifecycle") or event_type.startswith("Agent.Verification"):
            origin = "agent"
        elif event_type.startswith("Skill."):
            origin = "skill"
        elif event_type == "Security" or event_type.startswith("Security."):
            origin = "security"
        elif event_type == "Memory" or event_type.startswith("Memory."):
            origin = "memory"
        elif event_type == "Model" or event_type.startswith("Model."):
            origin = "model"
        elif event_type == "Workflow" or event_type.startswith("Workflow."):
            origin = "workflow"
        elif event_type == "System" or event_type.startswith("System.") or event_type == "Telemetry" or event_type.startswith("Telemetry."):
            origin = "environment"
        elif source == "dlq":
            origin = "bus"
        else:
            origin = "environment"

        category = str(raw.get("category") or payload.get("category") or ("protocol" if malformed else self._category_for(event_name, payload)))
        if category not in CATEGORIES:
            malformed = True
            category = "protocol"
        severity = str(raw.get("severity") or payload.get("severity") or self._severity_for(origin, category))
        if severity not in SEVERITIES:
            malformed = True
            severity = "high"
        reproducibility = str(raw.get("reproducibility") or payload.get("reproducibility") or "unknown")
        if reproducibility not in REPRODUCIBILITIES:
            malformed = True
            reproducibility = "unknown"
        cause_class = str(raw.get("cause_class") or payload.get("cause_class") or self._cause_for(category, event_name, payload, malformed))
        if cause_class not in CAUSE_CLASSES:
            malformed = True
            cause_class = "malformed_signal"
        where = raw.get("where") if isinstance(raw.get("where"), Mapping) else payload.get("where") if isinstance(payload.get("where"), Mapping) else {"component": str(raw.get("component") or payload.get("component") or "failure_intelligence.ingest")}
        if "component" not in where:
            where = {**where, "component": "failure_intelligence.ingest"}
        what = str(raw.get("what_happened") or payload.get("what_happened") or self._default_what_happened(event_type, event_name, payload))
        if not what.strip():
            malformed = True
            what = "malformed failure signal"
        malformed_timestamp = False
        try:
            observed_at = self._normalize_timestamp(raw.get("observed_at") or payload.get("observed_at") or payload.get("timestamp"), self.clock())
        except FailureValidationError:
            observed_at = self._normalize_timestamp(None, self.clock())
            malformed_timestamp = True
        malformed = malformed or malformed_timestamp
        correlation_id = str(raw.get("correlation_id") or payload.get("correlation_id") or uuid.uuid4())
        if malformed:
            cause_class = "malformed_signal"
            category = "protocol"
            severity = "high"
            what = what or "malformed failure signal"
        env = raw.get("execution_context") or payload.get("execution_context") or {}
        if isinstance(env, ExecutionContext):
            env = self._execution_context_doc(env)
        elif not isinstance(env, Mapping):
            env = {}
        return {
            "sensitivity": str(raw.get("sensitivity") or payload.get("sensitivity") or "internal"),
            "origin": origin,
            "category": category,
            "severity": severity,
            "reproducibility": reproducibility,
            "what_happened": what,
            "where": self._where_doc(where, payload),
            "when": {
                "observed_at": observed_at,
                "started_at": raw.get("started_at") or payload.get("started_at"),
                "duration_ms": raw.get("duration_ms") if raw.get("duration_ms") is not None else payload.get("duration_ms"),
            },
            "correlation_id": correlation_id,
            "causation_id": raw.get("causation_id") or payload.get("causation_id"),
            "parent_failure_id": raw.get("parent_failure_id") or payload.get("parent_failure_id"),
            "cause": {
                "cause_class": cause_class,
                "contributing_factors": list(raw.get("contributing_factors") or payload.get("contributing_factors") or []),
                "evidence_refs": list(raw.get("evidence_refs") or payload.get("evidence_refs") or []),
            },
            "affected": raw.get("affected") if isinstance(raw.get("affected"), Mapping) else payload.get("affected") if isinstance(payload.get("affected"), Mapping) else {},
            "blast_radius": str(raw.get("blast_radius") or payload.get("blast_radius") or "local"),
            "execution_context": env or {"execution_id": None, "mode": None, "budgets": None, "budget_utilization": None, "deterministic": None, "seed": None},
            "environment_snapshot_ref": raw.get("environment_snapshot_ref") or payload.get("environment_snapshot_ref"),
            "inputs_ref": raw.get("inputs_ref") or payload.get("inputs_ref") or self._content_ref(payload),
            "logs_ref": raw.get("logs_ref") or payload.get("logs_ref"),
            "traces_ref": raw.get("traces_ref") or payload.get("traces_ref"),
            "state_snapshot_ref": raw.get("state_snapshot_ref") or payload.get("state_snapshot_ref"),
        }

    @staticmethod
    def _where_doc(where: Mapping[str, Any], payload: Mapping[str, Any]) -> dict[str, Any]:
        keys = ("component", "agent_id", "agent_genome_hash", "skill_ref", "tool_ref", "model_ref", "workflow_ref", "environment_hash", "host", "process")
        return {key: where.get(key, payload.get(key)) for key in keys}

    @staticmethod
    def _execution_context_doc(ctx: ExecutionContext) -> dict[str, Any]:
        accounting = getattr(ctx, "accounting", None)
        budgets = getattr(ctx, "budgets", None)
        return {
            "execution_id": getattr(ctx, "execution_id", None),
            "mode": getattr(getattr(ctx, "mode", None), "value", getattr(ctx, "mode", None)),
            "budgets": budgets.to_dict() if hasattr(budgets, "to_dict") else (dict(budgets) if isinstance(budgets, Mapping) else None),
            "budget_utilization": accounting.utilization() if hasattr(accounting, "utilization") else None,
            "deterministic": getattr(ctx, "deterministic", None),
            "seed": getattr(ctx, "seed", None),
        }

    @staticmethod
    def _default_what_happened(event_type: str, event_name: str, payload: Mapping[str, Any]) -> str:
        if payload.get("error"):
            return str(payload["error"])
        text = " ".join(x for x in (event_type, event_name) if x).strip()
        return text or "failure signal received"

    @staticmethod
    def _content_ref(payload: Mapping[str, Any]) -> str:
        digest = hashlib.sha256(canonical_bytes(payload)).hexdigest()
        return f"urn:jarvis:failure-input:{digest}"

    @staticmethod
    def _category_for(event_name: str, payload: Mapping[str, Any]) -> str:
        text = f"{event_name} {payload.get('error_type','')} {payload.get('category','')}".lower()
        if any(x in text for x in ("security", "inject", "escalat", "denied")):
            return "security" if "security" in text or "inject" in text or "escalat" in text else "permission"
        if any(x in text for x in ("signature", "hash", "corrupt", "integrity")):
            return "integrity"
        if any(x in text for x in ("timeout", "slow", "latency")):
            return "latency"
        if any(x in text for x in ("budget", "resource", "quota")):
            return "resource"
        if any(x in text for x in ("dependency", "unavailable", "missing")):
            return "dependency"
        if any(x in text for x in ("rollback", "recovery", "restore")):
            return "recovery"
        if any(x in text for x in ("schema", "protocol", "contract")):
            return "protocol"
        if any(x in text for x in ("coordination", "workflow", "cascade")):
            return "coordination"
        return "correctness"

    @staticmethod
    def _severity_for(origin: str, category: str) -> str:
        if origin == "security" or category in {"security", "integrity"}:
            return "high"
        if category in {"resource", "latency", "dependency", "recovery", "coordination"}:
            return "medium"
        return "medium"

    @staticmethod
    def _cause_for(category: str, event_name: str, payload: Mapping[str, Any], malformed: bool) -> str:
        if malformed:
            return "malformed_signal"
        if payload.get("cause_class") in CAUSE_CLASSES:
            return str(payload["cause_class"])
        text = f"{event_name} {payload.get('error_type','')}".lower()
        if category == "dependency":
            return "missing_dependency"
        if category == "resource":
            return "resource_exhausted"
        if category == "latency":
            return "tool_timeout"
        if category == "permission":
            return "policy_denied"
        if category == "integrity":
            return "signature_failure"
        if "cancel" in text:
            return "cancellation"
        if "crash" in text or "panic" in text:
            return "crash"
        if "halluc" in text:
            return "model_hallucination"
        if "schema" in text or "protocol" in text or "contract" in text:
            return "schema_violation"
        return "unknown"

    def ingest(self, signal: Mapping[str, Any] | Any, auth_context: Any, *, source: str = "direct", failure_id: str | None = None) -> str:
        if not isinstance(signal, Mapping):
            signal = {"what_happened": repr(signal), "cause_class": "malformed_signal", "category": "protocol", "severity": "high", "reproducibility": "unknown"}
        normalized = self._normalize_signal(signal, source=source)
        self._auth(auth_context, operation="ingest", sensitivity=str(normalized["sensitivity"]))
        record = self._new_record_base(normalized, failure_id=failure_id)
        self.validate_record(record)
        with self._lock:
            existing = self.store.find_idempotent(self.tenant_id, record["correlation_id"], record["failure_signature"], record["when"]["observed_at"])
            if existing is not None:
                return existing
            self.store.append(self.tenant_id, record)
            self.store.put_idempotency(self.tenant_id, record["correlation_id"], record["failure_signature"], record["when"]["observed_at"], record["failure_id"])
        try:
            self._emit("Ingested", {"failure_id": record["failure_id"], "failure_version": 1, "failure_signature": record["failure_signature"], "origin": record["origin"], "category": record["category"]}, correlation_id=record["correlation_id"])
        finally:
            self._mirror_to_memory(record, auth_context)
        return str(record["failure_id"])

    def ingest_event(self, event: Any, auth_context: Any) -> str:
        payload = dict(event.payload)
        payload.update({
            "correlation_id": event.correlation_id,
            "causation_id": event.causation_id,
            "sensitivity": event.sensitivity,
            "event_type": event.event_type,
            "event_name": event.event_name,
            "observed_at": event.emitted_at,
        })
        return self.ingest(payload, auth_context, source="event")

    def ingest_dlq(self, failure_record: Mapping[str, Any], auth_context: Any) -> str:
        return self.ingest(failure_record, auth_context, source="dlq")

    def _mirror_to_memory(self, record: Mapping[str, Any], auth_context: Any) -> None:
        if self.experience_memory is None:
            return
        body = {
            "failure_record_ref": f"urn:jarvis:failure:{record['failure_id']}",
            "failure_signature": record["failure_signature"],
            "what_happened": record["what_happened"],
            "where": record["where"],
            "when": record["when"]["observed_at"],
            "cause": record["cause"]["cause_class"],
            "contributing_factors": record["cause"].get("contributing_factors", []),
            "remediation_ref": str(record["remediation"].get("remediation_proposal_ref") or ""),
            "regression_test_ref": str(record["regression"].get("test_ref") or ""),
        }
        try:
            item = build_memory_item(
                service=self.experience_memory,
                memory_type="failure",
                body=body,
                auth_context=auth_context,
                source_kind="derived",
                source_ref=str(record["failure_id"]),
                sensitivity=record["sensitivity"],
                confidence=0.9 if record["severity"] in {"critical", "high"} else 0.7,
            )
            mid = self.experience_memory.write(item, auth_context, allow_duplicate=True)
            current = self.store.get(self.tenant_id, str(record["failure_id"]))
            if current is not None and current.get("failure_memory_id") != mid:
                updated = self._append_version(current, lambda d: {**d, "failure_memory_id": str(mid)})
                self._emit("Triaged", {"failure_id": updated["failure_id"], "failure_version": updated["failure_version"], "failure_memory_id": mid}, correlation_id=updated["correlation_id"], causation_id=record["failure_id"], sensitivity=updated["sensitivity"])
        except Exception as exc:
            # The failure record remains authoritative. Memory denial is surfaced as
            # a diagnostic artifact rather than silently deleting or dropping the record.
            self._generate_diagnostic_internal(record, reason=f"failure memory mirror failed: {type(exc).__name__}: {exc}")

    def _redact_secret(self, doc: Mapping[str, Any]) -> dict[str, Any]:
        redacted = copy.deepcopy(dict(doc))
        redacted["what_happened"] = "[REDACTED]"
        redacted["where"] = {"component": redacted["where"].get("component"), "agent_id": redacted["where"].get("agent_id"), "agent_genome_hash": None, "skill_ref": None, "tool_ref": None, "model_ref": None, "workflow_ref": None, "environment_hash": None, "host": None, "process": None}
        redacted["cause"]["root_cause"] = None
        redacted["cause"]["evidence_refs"] = []
        redacted["cause"]["contributing_factors"] = []
        redacted["cause"]["hypotheses"] = [
            {**h, "hypothesis_text": "[REDACTED]", "evidence_refs": [], "supporting_failures": [], "contradicting_evidence": [], "verification_ref": None}
            for h in redacted["cause"]["hypotheses"]
        ]
        redacted["logs_ref"] = None
        redacted["traces_ref"] = None
        redacted["inputs_ref"] = None
        redacted["state_snapshot_ref"] = None
        redacted["execution_context"] = {"execution_id": redacted["execution_context"].get("execution_id"), "mode": redacted["execution_context"].get("mode"), "budgets": None, "budget_utilization": None, "deterministic": None, "seed": None}
        return redacted

    def get(self, failure_id: str, auth_context: Any, *, version: int | None = None) -> dict[str, Any]:
        auth = self._auth(auth_context, operation="read")
        doc = self.store.get(self.tenant_id, str(failure_id), version)
        if doc is None:
            raise FailureNotFound(failure_id)
        if doc["sensitivity"] == "secret" and not set(auth["scopes"]).intersection({SECRET_SCOPE, ADMIN_SCOPE}):
            return self._redact_secret(doc)
        return copy.deepcopy(doc)

    def query(self, auth_context: Any, *, signature: str | None = None, observed_after: str | None = None, observed_before: str | None = None, limit: int = 250) -> list[dict[str, Any]]:
        auth = self._auth(auth_context, operation="read")
        docs = self.store.query(self.tenant_id, signature=signature, observed_after=observed_after, observed_before=observed_before, limit=limit)
        if SECRET_SCOPE in set(auth["scopes"]) or ADMIN_SCOPE in set(auth["scopes"]):
            return docs
        return [self._redact_secret(doc) if doc["sensitivity"] == "secret" else doc for doc in docs]

    def history(self, failure_id: str, auth_context: Any) -> list[dict[str, Any]]:
        self._auth(auth_context, operation="read")
        if self.store.get(self.tenant_id, failure_id) is None:
            raise FailureNotFound(failure_id)
        return self.store.history(self.tenant_id, failure_id)

    def _query(self, auth_context: Any, **kwargs: Any) -> list[dict[str, Any]]:
        self._auth(auth_context, operation="read")
        return self.store.query(self.tenant_id, **kwargs)

    def correlate(self, failure_id: str, auth_context: Any) -> dict[str, Any]:
        target = self.get(failure_id, auth_context)
        docs = self._query(auth_context, limit=self.config.correlation_limit)
        nodes: dict[str, dict[str, Any]] = {target["failure_id"]: {"failure_id": target["failure_id"], "signature": target["failure_signature"], "component": target["where"].get("component")}}
        edges: list[dict[str, Any]] = []
        for doc in docs:
            if doc["failure_id"] == target["failure_id"]:
                continue
            matched: list[tuple[str, str]] = []
            if doc["failure_signature"] == target["failure_signature"]:
                matched.append(("signature", "same failure signature"))
            if doc["correlation_id"] == target["correlation_id"]:
                matched.append(("correlation", "same correlation group"))
            if doc.get("causation_id") == target["failure_id"] or doc.get("parent_failure_id") == target["failure_id"] or target.get("causation_id") == doc["failure_id"] or target.get("parent_failure_id") == doc["failure_id"]:
                matched.append(("causal", "causal lineage"))
            if self._within_window(target["when"]["observed_at"], doc["when"]["observed_at"], self.config.temporal_window_seconds):
                matched.append(("temporal", "temporal proximity"))
            if target["where"].get("component") and target["where"].get("component") == doc["where"].get("component"):
                matched.append(("component", "same component"))
            if target["where"].get("environment_hash") and target["where"].get("environment_hash") == doc["where"].get("environment_hash"):
                matched.append(("environment", "same environment"))
            if target.get("inputs_ref") and target.get("inputs_ref") == doc.get("inputs_ref"):
                matched.append(("input", "same input capture"))
            if matched:
                nodes[doc["failure_id"]] = {"failure_id": doc["failure_id"], "signature": doc["failure_signature"], "component": doc["where"].get("component")}
                for dimension, reason in sorted(matched):
                    edges.append({"from": target["failure_id"], "to": doc["failure_id"], "dimension": dimension, "reason": reason, "hypothesized": dimension in {"temporal", "component", "environment", "input"} and dimension != "causal"})
        graph_body = {
            "graph_id": self._uuid({"kind": "correlation_graph", "failure_id": failure_id, "nodes": sorted(nodes), "edges": edges}),
            "algorithm_version": self.analysis_version,
            "nodes": [nodes[k] for k in sorted(nodes)],
            "edges": sorted(edges, key=lambda x: (x["to"], x["dimension"])),
        }
        artifact = self._make_artifact(
            self._uuid({"kind": "correlation_graph_artifact", "failure_id": failure_id, "graph": graph_body}),
            graph_body,
            "correlation_graph",
            target,
        )
        self._validate_and_sign_plain_artifact(artifact, "correlation_graph")
        return artifact

    def group_by_signature(self, auth_context: Any, *, window: float | None = None) -> list[dict[str, Any]]:
        docs = self._query(auth_context, limit=5000)
        groups: dict[str, list[dict[str, Any]]] = {}
        for doc in docs:
            groups.setdefault(doc["failure_signature"], []).append(doc)
        result = []
        for signature, members in sorted(groups.items()):
            if window is not None:
                members = [doc for doc in members if self._within_window(members[0]["when"]["observed_at"], doc["when"]["observed_at"], float(window))]
            if not members:
                continue
            artifact = {
                "group_id": self._uuid({"kind": "signature_group", "signature": signature, "window": window}),
                "tenant_id": self.tenant_id,
                "signature": signature,
                "window_seconds": window,
                "failure_ids": sorted(doc["failure_id"] for doc in members),
                "count": len(members),
                "algorithm_version": self.analysis_version,
            }
            result.append(artifact)
        return result

    def cluster_temporal(self, auth_context: Any, *, window: float | None = None) -> list[dict[str, Any]]:
        win = float(window if window is not None else self.config.temporal_window_seconds)
        docs = sorted(self._query(auth_context, limit=5000), key=lambda d: (d["when"]["observed_at"], d["failure_id"]))
        clusters: list[dict[str, Any]] = []
        for doc in docs:
            if not clusters or not self._within_window(clusters[-1]["last_observed_at"], doc["when"]["observed_at"], win):
                clusters.append({"cluster_id": self._uuid({"kind": "temporal", "start": doc["when"]["observed_at"], "window": win}), "tenant_id": self.tenant_id, "window_seconds": win, "failure_ids": [doc["failure_id"]], "first_observed_at": doc["when"]["observed_at"], "last_observed_at": doc["when"]["observed_at"]})
            else:
                clusters[-1]["failure_ids"].append(doc["failure_id"])
                clusters[-1]["last_observed_at"] = doc["when"]["observed_at"]
        return clusters

    def _cascade_children(self, failure_id: str, docs: Sequence[Mapping[str, Any]]) -> list[str]:
        return sorted(str(doc["failure_id"]) for doc in docs if doc.get("parent_failure_id")==failure_id or doc.get("causation_id")==failure_id)
    def find_cascades(self, auth_context: Any) -> list[dict[str, Any]]:
        docs=self._query(auth_context,limit=None); children={str(d["failure_id"]):[] for d in docs}; parents={str(d["failure_id"]):str(d.get("parent_failure_id") or d.get("causation_id") or "") for d in docs}
        for d in docs:
            fid=str(d["failure_id"]); parent=parents[fid]
            if parent in children: children[parent].append(fid)
        for v in children.values(): v.sort()
        trees=[]; seen=set()
        for root in sorted(fid for fid in children if not parents[fid]):
            if not children[root]: seen.add(root); continue
            stack=[root]; nodes=[]; edges=[]
            while stack:
                fid=stack.pop()
                if fid in seen: continue
                seen.add(fid); nodes.append(fid)
                for child in children[fid]:
                    edges.append({"from":fid,"to":child,"hypothesized":False})
                    if child not in seen: stack.append(child)
            trees.append({"cascade_id":self._uuid({"kind":"cascade","root":root,"nodes":sorted(nodes)}),"root_failure_id":root,"failure_ids":sorted(nodes),"edges":sorted(edges,key=lambda x:(x["from"],x["to"])),"algorithm_version":self.analysis_version})
        for start_node in sorted(set(children)-seen):
            path=[]; positions={}; cur=start_node
            while cur in children and cur not in positions and cur not in seen:
                positions[cur]=len(path); path.append(cur); parent=parents[cur]
                if not parent or parent not in children: break
                cur=parent
            cycle=path[positions[cur]:] if cur in positions else []
            if cycle:
                nodes=sorted(set(cycle)); edges=[{"from":fid,"to":parents[fid],"hypothesized":False} for fid in nodes]
                trees.append({"cascade_id":self._uuid({"kind":"cascade_cycle","root":min(nodes),"nodes":nodes}),"root_failure_id":None,"failure_ids":nodes,"edges":sorted(edges,key=lambda x:(x["from"],x["to"])),"algorithm_version":self.analysis_version,"status":"cycle_detected","cycle_detected":True}); seen.update(nodes)
            else: seen.update(path)
        return trees

    def impact_analysis(self, failure_id: str, auth_context: Any) -> dict[str, Any]:
        target = self.get(failure_id, auth_context)
        docs = self._query(auth_context, limit=5000)
        affected = {"agents": set(target["affected"]["agents"]), "skills": set(target["affected"]["skills"]), "tools": set(target["affected"]["tools"]), "models": set(target["affected"]["models"]), "workflows": set(target["affected"]["workflows"]), "tenants": set(target["affected"]["tenants"])}
        causal = {target["failure_id"]}
        changed = True
        while changed:
            changed = False
            for doc in docs:
                if doc["failure_id"] in causal:
                    continue
                if doc.get("parent_failure_id") in causal or doc.get("causation_id") in causal:
                    causal.add(doc["failure_id"])
                    changed = True
                    for key in affected:
                        affected[key].update(doc["affected"].get(key, []))
        severity_rank = {"informational": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
        blast = "none"
        if len(causal) > 1 or target["affected"]["scope"] != "single_execution":
            blast = "local"
        if len(affected["agents"]) > 2 or target["affected"]["scope"] in {"multi_agent", "system_wide"}:
            blast = "regional"
        if target["severity"] == "critical" or target["affected"]["scope"] == "system_wide":
            blast = "global"
        report = {
            "failure_id": failure_id,
            "causal_failure_ids": sorted(causal),
            "affected": {key: sorted(value) for key, value in affected.items()},
            "severity": target["severity"],
            "blast_radius": blast,
            "severity_rank": severity_rank[target["severity"]],
            "algorithm_version": self.analysis_version,
        }
        return report

    @staticmethod
    def _within_window(a: str, b: str, seconds: float) -> bool:
        try:
            da = datetime.fromisoformat(str(a).replace("Z", "+00:00"))
            db = datetime.fromisoformat(str(b).replace("Z", "+00:00"))
            return abs((da - db).total_seconds()) <= float(seconds)
        except ValueError:
            return False

    def analyze(self, failure_id: str, auth_context: Any, *, methods: Sequence[str] = ANALYSIS_METHODS, baseline: Mapping[str, Any] | None = None, replay: Callable[[Mapping[str, Any]], bool] | None = None, manual: Sequence[Mapping[str, Any]] = ()) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="analyze", sensitivity=current["sensitivity"])
        selected = tuple(dict.fromkeys(str(x) for x in methods))
        if not selected or any(x not in ANALYSIS_METHODS for x in selected):
            raise FailureValidationError("invalid analysis method")
        budget = self.config.analysis_budget
        started = time.monotonic()
        hypotheses: list[dict[str, Any]] = []
        if "rule_based" in selected:
            hypotheses.extend(self._rule_hypotheses(current))
        if "correlation" in selected:
            hypotheses.extend(self._correlation_hypotheses(current, auth_context))
        if "differential" in selected and baseline is not None:
            hypotheses.extend(self._differential_hypotheses(current, baseline))
        if "replay" in selected and replay is not None:
            verified = bool(replay(copy.deepcopy(current)))
            hypotheses.append(self._hypothesis(current, f"Replay {'reproduced' if verified else 'did not reproduce'} the observed failure", current["cause"]["cause_class"], 0.95 if verified else 0.25, [], "replay", verified=verified, verification_ref=f"urn:jarvis:replay:{failure_id}" if verified else None))
        if "manual" in selected:
            for item in manual:
                hypotheses.append(self._manual_hypothesis(current, item))
        if "hybrid" in selected:
            combined = self._rule_hypotheses(current) + self._correlation_hypotheses(current, auth_context)
            hypotheses.extend(combined)
        dedup: dict[str, dict[str, Any]] = {}
        for hypothesis in hypotheses:
            dedup[hypothesis["hypothesis_id"]] = hypothesis
            if len(dedup) >= budget.max_hypotheses or time.monotonic() - started > budget.max_cpu_seconds:
                break
        ordered = sorted(dedup.values(), key=lambda h: (str(h["method"]), -float(h["confidence"]), str(h["hypothesis_id"])))
        root = next((h["hypothesis_text"] for h in ordered if h["verified"]), None)
        analysis_method = "hybrid" if len(set(h["method"] for h in ordered)) > 1 else ordered[0]["method"] if ordered else "rule_based"
        updated = self._append_version(
            current,
            lambda d: {
                **d,
                "state": "analyzed" if ordered else d["state"],
                "cause": {
                    **d["cause"],
                    "hypotheses": ordered,
                    "root_cause": root,
                    "analysis_method": analysis_method,
                    "analysis_version": self.analysis_version,
                },
            },
        )
        self._emit("HypothesisProposed", {"failure_id": failure_id, "failure_version": updated["failure_version"], "hypothesis_ids": [h["hypothesis_id"] for h in ordered]}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        for hypothesis in ordered:
            if hypothesis["verified"]:
                self._emit("HypothesisVerified", {"failure_id": failure_id, "hypothesis_id": hypothesis["hypothesis_id"], "verification_ref": hypothesis["verification_ref"]}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def _rule_hypotheses(self, record: Mapping[str, Any]) -> list[dict[str, Any]]:
        mapping = {
            "policy_denied": ("Authorization or policy configuration rejected the attempted action", 0.82),
            "missing_dependency": ("A required dependency was unavailable or absent", 0.86),
            "resource_exhausted": ("A configured execution or resource budget was exhausted", 0.84),
            "tool_timeout": ("The referenced tool did not complete within its permitted latency envelope", 0.81),
            "schema_violation": ("A producer violated a frozen schema or protocol contract", 0.9),
            "signature_failure": ("Cryptographic identity or integrity verification failed", 0.92),
            "model_hallucination": ("The model produced an unsupported or contradicted result", 0.62),
            "race_condition": ("Concurrent operations produced a timing-dependent inconsistent state", 0.55),
            "malformed_signal": ("The originating failure signal was malformed or incomplete", 0.98),
        }
        text, confidence = mapping.get(str(record["cause"]["cause_class"]), ("The failure cause remains unknown and requires additional evidence", 0.25))
        return [self._hypothesis(record, text, record["cause"]["cause_class"], confidence, list(record["cause"].get("evidence_refs", [])), "rule_based")]

    def _correlation_hypotheses(self, record: Mapping[str, Any], auth_context: Any) -> list[dict[str, Any]]:
        groups = self.group_by_signature(auth_context)
        match = next((group for group in groups if group["signature"] == record["failure_signature"]), None)
        if not match or int(match["count"]) < 2:
            return []
        text = f"Recurring signature observed across {match['count']} failures; shared failure pattern is a contributing cause candidate"
        return [self._hypothesis(record, text, record["cause"]["cause_class"], min(0.95, 0.45 + 0.05 * int(match["count"])), [f"urn:jarvis:failure-group:{match['group_id']}"], "correlation", supporting_failures=match["failure_ids"])]

    def _differential_hypotheses(self, record: Mapping[str, Any], baseline: Mapping[str, Any]) -> list[dict[str, Any]]:
        diff_keys = sorted(k for k in set(record.get("where", {})) | set(baseline.get("where", {})) if record.get("where", {}).get(k) != baseline.get("where", {}).get(k))
        if not diff_keys:
            return []
        return [self._hypothesis(record, f"Differential comparison isolates changed context fields: {', '.join(diff_keys)}", "unknown", 0.58, [f"urn:jarvis:differential:{hashlib.sha256(canonical_bytes({'failure': record['failure_id'], 'baseline': baseline})).hexdigest()}"], "differential")]

    def _manual_hypothesis(self, record: Mapping[str, Any], item: Mapping[str, Any]) -> dict[str, Any]:
        text = str(item.get("hypothesis_text") or "")
        cause = str(item.get("cause_class") or record["cause"]["cause_class"])
        confidence = float(item.get("confidence", 0.5))
        if not text.strip() or cause not in CAUSE_CLASSES or not 0.0 <= confidence <= 1.0:
            raise FailureValidationError("manual hypothesis is invalid")
        return self._hypothesis(record, text, cause, confidence, list(item.get("evidence_refs", [])), "manual", supporting_failures=list(item.get("supporting_failures", [])), verified=bool(item.get("verified", False)), verification_ref=item.get("verification_ref"))

    def _hypothesis(self, record: Mapping[str, Any], text: str, cause_class: str, confidence: float, evidence_refs: Sequence[str], method: str, *, supporting_failures: Sequence[str] = (), verified: bool = False, verification_ref: str | None = None) -> dict[str, Any]:
        evidence = sorted(set(str(x) for x in evidence_refs))
        support = sorted(set(str(x) for x in supporting_failures))
        payload = {"failure_id": record["failure_id"], "text": text, "cause_class": cause_class, "confidence": round(float(confidence), 8), "evidence_refs": evidence, "method": method, "supporting_failures": support, "verification_ref": verification_ref}
        return {
            "hypothesis_id": self._uuid({"kind": "hypothesis", **payload}),
            "hypothesis_text": text,
            "cause_class": cause_class,
            "confidence": round(float(confidence), 8),
            "evidence_refs": evidence,
            "method": method,
            "method_version": self.analysis_version,
            "supporting_failures": support,
            "contradicting_evidence": [],
            "verified": bool(verified),
            "verified_at": record["when"]["observed_at"] if verified else None,
            "verification_ref": verification_ref,
        }

    def verify_hypothesis(self, failure_id: str, hypothesis_id: str, verification_ref: str, auth_context: Any) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="analyze", sensitivity=current["sensitivity"])
        if not str(verification_ref).strip():
            raise FailurePolicyError("verification_ref is required")
        found = next((h for h in current["cause"]["hypotheses"] if h["hypothesis_id"] == hypothesis_id), None)
        if found is None:
            raise FailureNotFound(hypothesis_id)
        updated_hypotheses = [
            {**h, "verified": True, "verified_at": current["when"]["observed_at"], "verification_ref": verification_ref} if h["hypothesis_id"] == hypothesis_id else h
            for h in current["cause"]["hypotheses"]
        ]
        updated = self._append_version(current, lambda d: {**d, "state": "verified", "cause": {**d["cause"], "hypotheses": updated_hypotheses, "root_cause": found["hypothesis_text"]}, "remediation": {**d["remediation"], "verification_ref": verification_ref}})
        self._emit("HypothesisVerified", {"failure_id": failure_id, "failure_version": updated["failure_version"], "hypothesis_id": hypothesis_id, "verification_ref": verification_ref}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def propose_remediation(self, failure_id: str, auth_context: Any) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="generate", sensitivity=current["sensitivity"])
        if not current["cause"]["hypotheses"]:
            current = self.analyze(failure_id, auth_context, methods=("rule_based",))
        steps = self._remediation_steps(current)
        proposal_id = self._uuid({"kind": "remediation", "failure_id": failure_id, "failure_version": current["failure_version"], "steps": steps})
        proposal = {
            "artifact_id": proposal_id,
            "artifact_type": "remediation_proposal",
            "artifact_version": 1,
            "proposal_id": proposal_id,
            "proposal_version": 1,
            "failure_id": failure_id,
            "tenant_id": self.tenant_id,
            "status": "proposed",
            "steps": steps,
            "analysis_version": self.analysis_version,
            "created_at": current["when"]["observed_at"],
            "proposer": {"principal": "failure-intelligence", "key_id": self.writer_key_id},
            "signature": "",
            "integrity_hash": "",
        }
        signed = _sign_plain(proposal, self.signer)
        SchemaValidator(max_errors=64).validate_or_raise(signed, json.loads(REMEDIATION_SCHEMA.read_text(encoding="utf-8")))
        updated = self._append_version(current, lambda d: {**d, "state": "triaged", "remediation": {**d["remediation"], "status": "proposed", "steps": steps, "remediation_proposal_ref": proposal_id}})
        self._store_artifact_doc(signed, "remediation_proposal")
        self._emit("RemediationProposed", {"failure_id": failure_id, "failure_version": updated["failure_version"], "proposal_id": proposal_id}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return signed

    def _remediation_steps(self, record: Mapping[str, Any]) -> list[dict[str, Any]]:
        cause = str(record["cause"]["cause_class"])
        risk = "critical" if record["category"] in {"security", "integrity", "permission"} else "high" if record["severity"] in {"critical", "high"} else "medium"
        flags = {"requires_simulation": risk in {"high", "critical"}, "requires_verification": True, "requires_certification": risk in {"high", "critical"}}
        plans = {
            "policy_denied": ("policy_adjustment", "Review the affected policy/scope mapping for false denial; route a minimal signed policy proposal", "policy"),
            "missing_dependency": ("environment_fix", "Restore or pin the missing dependency in a certified environment", "environment"),
            "resource_exhausted": ("budget_adjustment", "Analyze budget utilization before changing limits; propose the smallest bounded adjustment", "execution.budget"),
            "tool_timeout": ("retry_policy_change", "Review tool timeout and retry policy against observed latency distribution", "tool"),
            "schema_violation": ("code_fix", "Correct the violating producer contract and add a regression case", "protocol"),
            "signature_failure": ("rollback", "Quarantine the affected artifact and route an integrity-preserving rollback candidate", "artifact"),
            "model_hallucination": ("model_swap", "Evaluate an evidence-constrained model or routing change under certification", "model"),
            "race_condition": ("code_fix", "Reproduce under deterministic scheduling and add a concurrency regression", "component"),
            "malformed_signal": ("code_fix", "Harden the signal parser and add malformed-input coverage", "ingestion"),
        }
        kind, description, target = plans.get(cause, ("code_fix", "Collect additional evidence before choosing a remediation", "component"))
        step = {
            "step_id": self._uuid({"kind": "remediation_step", "failure_id": record["failure_id"], "cause": cause}),
            "kind": kind,
            "description": description,
            "target_ref": f"urn:jarvis:failure-target:{target}",
            "proposed_change": {"action": kind, "reason": cause, "bounded": True},
            "risk_assessment": risk,
            "requires_simulation": flags["requires_simulation"],
            "requires_verification": flags["requires_verification"],
            "requires_certification": flags["requires_certification"],
            "rollback_plan_ref": None,
        }
        return [step]

    def generate_artifacts(self, failure_id: str, auth_context: Any, *, adversarial_benchmark_approval: Mapping[str, str] | None = None) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="generate", sensitivity=current["sensitivity"])
        generated: dict[str, list[str]] = {"regression_case_ids": [], "benchmark_case_ids": [], "warning_ids": [], "policy_proposal_ids": [], "diagnostic_ids": []}
        artifacts: list[dict[str, Any]] = []
        if current["reproducibility"] in {"always", "intermittent"} and all(current.get(ref) for ref in ("inputs_ref", "state_snapshot_ref", "environment_snapshot_ref")):
            case = self._regression_case(current)
            artifacts.append(case)
            generated["regression_case_ids"].append(case["artifact_id"])
        metric_violation = bool(current.get("execution_context", {}).get("budget_utilization")) or current["category"] in {"correctness", "latency", "resource", "security", "integrity"}
        if metric_violation and current["reproducibility"] in {"always", "intermittent", "input_dependent"}:
            adversarial_blocked = current["category"] == "security" and adversarial_benchmark_approval is None
            if not adversarial_blocked:
                benchmark = self._benchmark_case(current, adversarial_benchmark_approval)
                artifacts.append(benchmark)
                generated["benchmark_case_ids"].append(benchmark["artifact_id"])
        signature_count = len(next((g["failure_ids"] for g in self.group_by_signature(auth_context) if g["signature"] == current["failure_signature"]), []))
        if current["severity"] in {"critical", "high", "medium"} or signature_count >= self.config.warning_frequency_threshold:
            warning = self._warning(current, signature_count)
            artifacts.append(warning)
            generated["warning_ids"].append(warning["artifact_id"])
        if current["cause"]["cause_class"] in {"policy_denied", "schema_violation", "permission"}:
            self._auth(auth_context, operation="security_propose", sensitivity=current["sensitivity"], security_write=True)
            proposal = self._policy_proposal(current)
            artifacts.append(proposal)
            generated["policy_proposal_ids"].append(proposal["artifact_id"])
        diagnostic = self._diagnostic(current, auth_context)
        artifacts.append(diagnostic)
        generated["diagnostic_ids"].append(diagnostic["artifact_id"])
        for artifact in artifacts:
            self._persist_artifact(artifact)
        refreshed = self.store.get(self.tenant_id, failure_id)
        assert refreshed is not None
        updated = self._append_version(refreshed, lambda d: {**d, "generated": generated, "regression": self._update_regression(d, generated)})
        for artifact in artifacts:
            event_name = {
                "regression_case": "RegressionGenerated", "benchmark_case": "BenchmarkGenerated", "warning": "WarningEmitted", "policy_proposal": "PolicyProposed", "diagnostic": "DiagnosticGenerated"
            }[artifact["artifact_type"]]
            self._emit(event_name, {"failure_id": failure_id, "artifact_id": artifact["artifact_id"], "artifact_version": artifact["artifact_version"]}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return {"failure": updated, "artifacts": artifacts}

    def _update_regression(self, current: Mapping[str, Any], generated: Mapping[str, Sequence[str]]) -> dict[str, Any]:
        benchmark_ids = list(generated["benchmark_case_ids"])
        regression_ids = list(generated["regression_case_ids"])
        return {**current["regression"], "test_ref": regression_ids[0] if regression_ids else current["regression"].get("test_ref"), "benchmark_ref": benchmark_ids[0] if benchmark_ids else current["regression"].get("benchmark_ref"), "reproduces_at": current["reproducibility"] if regression_ids else current["regression"].get("reproduces_at")}

    def _regression_case(self, record: Mapping[str, Any]) -> dict[str, Any]:
        artifact_id = self._uuid({"kind": "regression_case", "failure_id": record["failure_id"], "version": record["failure_version"]})
        body = {
            "artifact_type": "regression_case",
            "case_id": artifact_id,
            "failure_id": record["failure_id"],
            "target_ref": self._target_ref(record),
            "inputs_ref": record["inputs_ref"],
            "expected_outcome": "fail_as_observed",
            "environment_ref": record["environment_snapshot_ref"],
            "state_snapshot_ref": record["state_snapshot_ref"],
            "seed": record["execution_context"].get("seed"),
            "determinism": "seeded" if record["execution_context"].get("seed") is not None else "deterministic" if record["reproducibility"] == "always" else "nondeterministic",
            "reproduces": record["reproducibility"],
            "run_contract": {"execution_mode": record["execution_context"].get("mode"), "requires_verification": True, "production_write": False},
        }
        return self._make_artifact(artifact_id, body, "regression_case", record)

    def _benchmark_case(self, record: Mapping[str, Any], approval: Mapping[str, str] | None) -> dict[str, Any]:
        artifact_id = self._uuid({"kind": "benchmark_case", "failure_id": record["failure_id"], "version": record["failure_version"]})
        adversarial = record["category"] in {"security", "integrity"}
        if adversarial and not approval:
            raise FailurePolicyError("adversarial benchmark requires explicit approval")
        body = {
            "artifact_type": "benchmark_case",
            "benchmark_id": f"bench.failure.{record['failure_signature'][:16]}",
            "failure_id": record["failure_id"],
            "dataset_ref": record["inputs_ref"],
            "metric_floor": {"category": record["category"], "severity_floor": record["severity"]},
            "thresholds": {"must_reproduce": record["reproducibility"] in {"always", "intermittent", "input_dependent"}},
            "adversarial": adversarial,
            "approval": dict(approval or {}),
        }
        return self._make_artifact(artifact_id, body, "benchmark_case", record)

    def _warning(self, record: Mapping[str, Any], signature_count: int) -> dict[str, Any]:
        artifact_id = self._uuid({"kind": "warning", "failure_id": record["failure_id"], "signature": record["failure_signature"], "count": signature_count})
        body = {
            "artifact_type": "warning",
            "warning_id": artifact_id,
            "failure_id": record["failure_id"],
            "failure_ids": [record["failure_id"]],
            "signature_group": record["failure_signature"],
            "message": f"Failure signature {record['failure_signature'][:16]} recurred {signature_count} time(s); severity={record['severity']}",
            "affected_refs": [self._target_ref(record)],
            "recommended_action": "Inspect diagnostic evidence and evaluate the signed remediation proposal before any change",
            "expires_at": None,
            "acknowledged_by": None,
            "acknowledged_at": None,
        }
        return self._make_artifact(artifact_id, body, "warning", record)

    def _policy_proposal(self, record: Mapping[str, Any]) -> dict[str, Any]:
        artifact_id = self._uuid({"kind": "policy_proposal", "failure_id": record["failure_id"], "failure_version": record["failure_version"]})
        body = {
            "artifact_type": "policy_proposal",
            "proposal_id": artifact_id,
            "failure_id": record["failure_id"],
            "target_ref": f"urn:jarvis:security-policy:{record['where'].get('component')}",
            "reason": record["cause"]["cause_class"],
            "proposed_patch": {"action": "review_and_adjust", "scope": "minimal", "automatic_apply": False},
            "requires_manual_approval": True,
            "security_scope": SECURITY_PUBLISH_SCOPE,
            "approval": None,
        }
        return self._make_artifact(artifact_id, body, "policy_proposal", record)

    def _diagnostic(self, record: Mapping[str, Any], auth_context: Any) -> dict[str, Any]:
        corr = self.correlate(record["failure_id"], auth_context)
        body = {
            "artifact_type": "diagnostic",
            "diagnostic_id": self._uuid({"kind": "diagnostic", "failure_id": record["failure_id"], "version": record["failure_version"]}),
            "failure_id": record["failure_id"],
            "summary": {"what_happened": record["what_happened"], "where": record["where"], "severity": record["severity"], "reproducibility": record["reproducibility"]},
            "correlated_failure_ids": sorted({node["failure_id"] for node in corr["nodes"]}),
            "hypotheses": copy.deepcopy(record["cause"]["hypotheses"]),
            "next_steps": self._diagnostic_steps(record),
            "evidence_refs": sorted(set(record["cause"].get("evidence_refs", [])) | {x for x in (record.get("logs_ref"), record.get("traces_ref"), record.get("state_snapshot_ref")) if x}),
        }
        return self._make_artifact(body["diagnostic_id"], body, "diagnostic", record)

    def _diagnostic_steps(self, record: Mapping[str, Any]) -> list[str]:
        steps = ["Confirm the failure signature against recent correlated records"]
        if record["reproducibility"] in {"always", "intermittent", "input_dependent", "environment_dependent"}:
            steps.append("Run the captured inputs through a non-production deterministic harness")
        if record["cause"]["root_cause"] is None:
            steps.append("Collect or verify evidence for the outstanding root-cause hypotheses")
        else:
            steps.append("Verify the proposed remediation against the captured regression case")
        return steps

    def _generate_diagnostic_internal(self, record: Mapping[str, Any], reason: str) -> None:
        body = {
            "artifact_type": "diagnostic",
            "diagnostic_id": self._uuid({"kind": "diagnostic", "failure_id": record["failure_id"], "reason": reason}),
            "failure_id": record["failure_id"],
            "summary": {"what_happened": record["what_happened"], "where": record["where"], "severity": record["severity"], "reproducibility": record["reproducibility"]},
            "correlated_failure_ids": [record["failure_id"]],
            "hypotheses": [],
            "next_steps": [reason],
            "evidence_refs": [],
        }
        artifact = self._make_artifact(body["diagnostic_id"], body, "diagnostic", record)
        self._persist_artifact(artifact)

    def _target_ref(self, record: Mapping[str, Any]) -> str:
        for field in ("agent_id", "skill_ref", "tool_ref", "model_ref", "workflow_ref"):
            if record["where"].get(field):
                return str(record["where"][field])
        return str(record["where"].get("component") or "unknown")

    def _make_artifact(self, artifact_id: str, body: Mapping[str, Any], artifact_type: str, record: Mapping[str, Any]) -> dict[str, Any]:
        document = {
            "artifact_id": artifact_id,
            "artifact_version": self._next_artifact_version(artifact_id),
            "artifact_type": artifact_type,
            "failure_id": record["failure_id"],
            "tenant_id": self.tenant_id,
            "created_at": record["when"]["observed_at"],
            **dict(body),
            "signature": "",
            "writer_key_id": self.writer_key_id,
            "writer_public_key": self.public_key_b64,
            "integrity_hash": "",
        }
        return _sign_plain(document, self.signer)

    def _next_artifact_version(self, artifact_id: str) -> int:
        history = self.store.artifact_history(self.tenant_id, artifact_id)
        return max((int(x["artifact_version"]) for x in history), default=0) + 1

    def _validate_and_sign_plain_artifact(self, doc: Mapping[str, Any], artifact_type: str) -> dict[str, Any]:
        schema = ARTIFACT_SCHEMAS[artifact_type]
        payload = {**dict(doc), "artifact_type": artifact_type, "signature": "", "writer_key_id": self.writer_key_id, "writer_public_key": self.public_key_b64, "integrity_hash": ""}
        signed = _sign_plain(payload, self.signer)
        SchemaValidator(max_errors=128).validate_or_raise(signed, json.loads(schema.read_text(encoding="utf-8")))
        return signed

    def _store_artifact_doc(self, doc: Mapping[str, Any], artifact_type: str) -> None:
        # Persist the complete signed document. The SQL column remains a secondary
        # integrity index; the JSON body itself must remain independently verifiable.
        self.store.append_artifact(self.tenant_id, dict(doc), signature=str(doc["signature"]), writer_key_id=self.writer_key_id)

    def _persist_artifact(self, artifact: Mapping[str, Any]) -> None:
        artifact_type = str(artifact["artifact_type"])
        if artifact_type in ARTIFACT_SCHEMAS:
            SchemaValidator(max_errors=128).validate_or_raise(dict(artifact), json.loads(ARTIFACT_SCHEMAS[artifact_type].read_text(encoding="utf-8")))
        self._store_artifact_doc(artifact, artifact_type)

    def verify_artifact(self, artifact: Mapping[str, Any]) -> bool:
        return _verify_plain_signature(artifact)

    def close(self, failure_id: str, auth_context: Any, *, verification_ref: str | None = None, manual_reason: str | None = None) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="close", sensitivity=current["sensitivity"])
        if not verification_ref and not manual_reason:
            raise FailurePolicyError("closure requires verified regression or signed manual reason")
        if verification_ref and verification_ref == current["remediation"].get("verification_ref"):
            new_state = "closed"
            reason = f"verified regression: {verification_ref}"
        elif manual_reason:
            new_state = "closed"
            reason = str(manual_reason)
        else:
            raise FailurePolicyError("verification_ref must match a signed verification artifact")
        updated = self._append_version(current, lambda d: {**d, "state": new_state, "closed_at": d["when"]["observed_at"], "closed_reason": reason})
        self._emit("Closed", {"failure_id": failure_id, "failure_version": updated["failure_version"], "closed_reason": reason}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def mark_non_actionable(self, failure_id: str, reason: str, actor: Mapping[str, str], auth_context: Any) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="close", sensitivity=current["sensitivity"])
        if reason not in NON_ACTIONABLE_REASONS:
            raise FailurePolicyError("non-actionable reason is not in frozen taxonomy")
        signed_reason = _sign_plain({"failure_id": failure_id, "reason": reason, "actor": dict(actor), "signed_at": current["when"]["observed_at"]}, self.signer)
        updated = self._append_version(current, lambda d: {**d, "state": "non_actionable", "closed_at": d["when"]["observed_at"], "closed_reason": canonical_json(signed_reason).decode("utf-8")})
        self._emit("NonActionable", {"failure_id": failure_id, "failure_version": updated["failure_version"], "reason": reason}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def reopen(self, failure_id: str, reason: str, auth_context: Any) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="close", sensitivity=current["sensitivity"])
        if current["state"] != "non_actionable" and current["state"] != "closed":
            raise FailurePolicyError("only closed or non-actionable failures can be reopened")
        updated = self._append_version(current, lambda d: {**d, "state": "open", "closed_at": None, "closed_reason": reason})
        self._emit("Reopened", {"failure_id": failure_id, "failure_version": updated["failure_version"], "reason": reason}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def update_remediation_status(self, failure_id: str, auth_context: Any, *, status: str, applied_by: Mapping[str, str] | None = None, verification_ref: str | None = None) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="generate", sensitivity=current["sensitivity"])
        if status not in REMEDIATION_STATUS:
            raise FailurePolicyError("invalid remediation status")
        return self._append_version(current, lambda d: {**d, "state": "remediated" if status == "applied" else d["state"], "remediation": {**d["remediation"], "status": status, "applied_by": dict(applied_by) if applied_by else d["remediation"].get("applied_by"), "verification_ref": verification_ref or d["remediation"].get("verification_ref"), "applied_at": d["when"]["observed_at"] if status == "applied" else d["remediation"].get("applied_at")}})

    def stats(self, auth_context: Any) -> dict[str, Any]:
        docs = self._query(auth_context, limit=5000)
        by_origin: dict[str, int] = {}
        by_category: dict[str, int] = {}
        by_severity: dict[str, int] = {}
        by_state: dict[str, int] = {}
        for doc in docs:
            for bucket, key in ((by_origin, doc["origin"]), (by_category, doc["category"]), (by_severity, doc["severity"]), (by_state, doc["state"])):
                bucket[key] = bucket.get(key, 0) + 1
        return {"tenant_id": self.tenant_id, "count": len(docs), "by_origin": dict(sorted(by_origin.items())), "by_category": dict(sorted(by_category.items())), "by_severity": dict(sorted(by_severity.items())), "by_state": dict(sorted(by_state.items())), "chain_verified": self.store.verify_chain(), "engine_version": self.engine_version, "analysis_version": self.analysis_version}

    def attach_event_bus(self, *, subscriber: SubscriberContext, ingest_auth_context: Any, event_types: Sequence[str] | None = None) -> tuple[SubscriptionHandle, ...]:
        """Attach to selected P2-U event families using caller-supplied authority.

        The engine does not mint subscriber scopes; the caller supplies a verified
        SubscriberContext and ingestion authorization context. Delivery is exactly-once
        ordered at the P2-U subscription boundary.
        """
        if self.event_bus is None:
            raise FailurePolicyError("event bus is not configured")
        if subscriber.tenant_id != self.tenant_id:
            raise FailureAccessDenied("subscriber tenant mismatch")
        if not isinstance(ingest_auth_context, Mapping):
            raise FailureAccessDenied("verified ingestion authorization context is required")
        if str(ingest_auth_context.get("tenant_id")) != self.tenant_id or not bool(ingest_auth_context.get("authorization_verified", False)):
            raise FailureAccessDenied("ingestion authorization is not verified")
        selected_types = tuple(event_types or sorted({spec["event_type"] for key, spec in EventTaxonomy.entries().items() if not key.startswith("Failure.")}))
        handles: list[SubscriptionHandle] = []
        for event_type in selected_types:
            def handler(event: Any, self=self, ingest_auth_context=ingest_auth_context) -> None:
                if event.event_type == "Failure":
                    return
                self.ingest_event(event, ingest_auth_context)
            handle = self.event_bus.subscribe(
                EventFilter(self.tenant_id, event_type=event_type),
                handler,
                delivery_mode="exactly_once_ordered",
                subscriber=subscriber,
            )
            handles.append(handle)
        self._subscriptions.extend(handles)
        return tuple(handles)

    def verify_regression_case(self, failure_id: str, test_ref: str, run_artifact_ref: str, auth_context: Any) -> dict[str, Any]:
        current = self.get(failure_id, auth_context)
        self._auth(auth_context, operation="analyze", sensitivity=current["sensitivity"])
        regression = self.store.artifact(self.tenant_id, test_ref)
        if regression is None or regression.get("artifact_type") != "regression_case" or str(regression.get("failure_id")) != str(failure_id) or not self.verify_artifact(regression):
            raise FailurePolicyError("regression test artifact is missing or invalid")
        updated = self._append_version(current, lambda d: {**d, "state": "verified", "remediation": {**d["remediation"], "verification_ref": run_artifact_ref}, "regression": {**d["regression"], "test_ref": test_ref, "reproduces_at": "no_longer"}})
        self._emit("HypothesisVerified", {"failure_id": failure_id, "failure_version": updated["failure_version"], "verification_ref": run_artifact_ref, "regression_case_id": test_ref}, correlation_id=updated["correlation_id"], causation_id=failure_id, sensitivity=updated["sensitivity"])
        return updated

    def acknowledge_warning(self, warning_id: str, principal: str, auth_context: Any) -> dict[str, Any]:
        current = self.store.artifact(self.tenant_id, warning_id)
        if current is None or current.get("artifact_type") != "warning":
            raise FailureNotFound(warning_id)
        self._auth(auth_context, operation="generate", sensitivity="internal")
        updated_body = {**current, "artifact_version": int(current.get("artifact_version", 1)) + 1, "acknowledged_by": {"principal": str(principal), "key_id": self.writer_key_id}, "acknowledged_at": current["created_at"]}
        signed = _sign_plain(updated_body, self.signer)
        self.store.append_artifact(self.tenant_id, signed, signature=signed["signature"], writer_key_id=self.writer_key_id)
        return signed

    def detach_event_bus(self) -> None:
        if self.event_bus is None:
            return
        for handle in tuple(self._subscriptions):
            self.event_bus.unsubscribe(handle)
        self._subscriptions.clear()

    def diagnostics(self, failure_id: str, auth_context: Any) -> list[dict[str, Any]]:
        self.get(failure_id, auth_context)
        return self.store.list_artifacts(self.tenant_id, failure_id, "diagnostic")

    def regression_cases(self, failure_id: str, auth_context: Any) -> list[dict[str, Any]]:
        self.get(failure_id, auth_context)
        return self.store.list_artifacts(self.tenant_id, failure_id, "regression_case")

    def benchmark_cases(self, failure_id: str, auth_context: Any) -> list[dict[str, Any]]:
        self.get(failure_id, auth_context)
        return self.store.list_artifacts(self.tenant_id, failure_id, "benchmark_case")


def _unsigned_record(doc: Mapping[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(dict(doc))
    result.pop("signature", None)
    result.pop("integrity_hash", None)
    return result


def _verify_signature(doc: Mapping[str, Any]) -> bool:
    try:
        public = base64.b64decode(str(doc["writer_public_key"]).encode("ascii"), validate=True)
        if hashlib.sha256(public).hexdigest() != str(doc["writer_key_id"]):
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(str(doc["signature"]).encode("ascii"), validate=True), canonical_bytes({**dict(doc), "signature": doc["signature"], "integrity_hash": doc["integrity_hash"]} if False else {**dict(doc), "signature": doc["signature"]}))
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError, base64.binascii.Error):
        return False


def _sign_plain(document: Mapping[str, Any], signer: Ed25519PrivateKey) -> dict[str, Any]:
    doc = copy.deepcopy(dict(document))
    doc.pop("signature", None)
    doc.pop("integrity_hash", None)
    public = signer.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    doc["writer_key_id"] = hashlib.sha256(public).hexdigest()
    doc["writer_public_key"] = base64.b64encode(public).decode("ascii")
    doc["integrity_hash"] = hashlib.sha256(canonical_bytes(doc)).hexdigest()
    doc["signature"] = base64.b64encode(signer.sign(canonical_bytes(doc))).decode("ascii")
    return doc


def _unsigned_plain(doc: Mapping[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(dict(doc))
    result.pop("signature", None)
    return result


def _verify_plain_signature(doc: Mapping[str, Any]) -> bool:
    try:
        public = base64.b64decode(str(doc["writer_public_key"]).encode("ascii"), validate=True)
        if hashlib.sha256(public).hexdigest() != str(doc["writer_key_id"]):
            return False
        unsigned = _unsigned_plain(doc)
        expected_integrity = str(doc.get("integrity_hash"))
        unsigned_no_integrity = dict(unsigned)
        unsigned_no_integrity.pop("integrity_hash", None)
        if hashlib.sha256(canonical_bytes(unsigned_no_integrity)).hexdigest() != expected_integrity:
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(base64.b64decode(str(doc["signature"]).encode("ascii"), validate=True), canonical_bytes(unsigned))
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError, base64.binascii.Error):
        return False


# Failure records sign the body including integrity_hash; verification uses the
# same canonical document, while the store independently verifies the hash.
# This function is intentionally kept separate so the canonical signing rule is
# obvious and auditable.
def verify_failure_signature(doc: Mapping[str, Any]) -> bool:
    try:
        public = base64.b64decode(str(doc["writer_public_key"]).encode("ascii"), validate=True)
        if hashlib.sha256(public).hexdigest() != str(doc["writer_key_id"]):
            return False
        Ed25519PublicKey.from_public_bytes(public).verify(
            base64.b64decode(str(doc["signature"]).encode("ascii"), validate=True),
            canonical_bytes({k: v for k, v in doc.items() if k != "signature"}),
        )
        return True
    except (InvalidSignature, ValueError, TypeError, KeyError, base64.binascii.Error):
        return False


# The internal aliases deliberately point to the single audited verifier.
_verify_signature = verify_failure_signature


def build_failure_record(**kwargs: Any) -> dict[str, Any]:
    """Small construction helper for deterministic integration tests."""
    required = {"failure_id", "failure_version", "tenant_id", "sensitivity", "origin", "category", "severity", "reproducibility", "failure_signature", "what_happened", "where", "when", "correlation_id", "causation_id", "parent_failure_id", "cause", "affected", "blast_radius", "execution_context", "environment_snapshot_ref", "inputs_ref", "logs_ref", "traces_ref", "state_snapshot_ref", "remediation", "regression", "generated", "failure_memory_id", "state", "closed_at", "closed_reason", "signature", "writer_key_id", "writer_public_key", "integrity_hash", "chain_prev_hash"}
    missing = sorted(required - set(kwargs))
    if missing:
        raise ValueError(f"missing failure record fields: {', '.join(missing)}")
    return dict(kwargs)


def validate_failure_record(record: Mapping[str, Any]) -> None:
    """Standalone schema validation helper."""
    SchemaValidator(max_errors=128).validate_or_raise(dict(record), json.loads(FAILURE_SCHEMA.read_text(encoding="utf-8")))

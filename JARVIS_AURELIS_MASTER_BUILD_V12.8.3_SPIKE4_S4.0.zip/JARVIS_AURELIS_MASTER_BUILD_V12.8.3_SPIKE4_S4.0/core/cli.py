"""Unified J.A.R.V.I.S. 12.8.0 operator command center."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import shutil
import sys
from pathlib import Path
from typing import Any

from .kernel_12_8_0 import JarvisKernelRuntime, SecurePythonSandbox
from .kernel_12_8_0.canonical import digest
from .kernel_12_8_0.certification import CertificationCenter
from .kernel_12_8_0.supply_chain import ArtifactVerifier, SecretScanner, generate_ml_bom, generate_provenance, generate_sbom
from .kernel_12_8_0.utility import ExactProofEngine, exact_fraction, exact_sympy

ROOT = Path(__file__).resolve().parents[1]


def _kernel() -> JarvisKernelRuntime:
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    kernel_cfg = dict(cfg.get("kernel", {}))
    cfg["kernel"] = kernel_cfg
    return JarvisKernelRuntime(cfg)


def _print(value: Any) -> None:
    if hasattr(value, "as_dict"):
        value = value.as_dict()
    print(json.dumps(value, indent=2, ensure_ascii=False, default=lambda obj: getattr(obj, "__dict__", str(obj))))


def _model_inventory() -> dict[str, Any]:
    models_root = ROOT / "data" / "models"
    if not models_root.is_dir():
        return {"status": "EMPTY", "models": [], "ml_bom": {"bomFormat": "CycloneDX", "specVersion": "1.6", "components": []}}
    artifacts = []
    verifier = ArtifactVerifier()
    for path in sorted(models_root.rglob("*")):
        if path.is_file() and path.suffix.lower() in {".gguf", ".safetensors", ".onnx", ".bin", ".pt", ".pth", ".ckpt"}:
            try:
                artifacts.append(verifier.inspect(path))
            except ValueError as exc:
                artifacts.append({"path": str(path), "status": "REJECTED", "reason": f"verification_error:{type(exc).__name__}"})
    manifests = [item.as_dict() if hasattr(item, "as_dict") else {k: getattr(item, k) for k in ("artifact_id", "path", "sha256", "media_type", "size_bytes", "metadata")} for item in artifacts if not isinstance(item, dict)]
    rejected = [item for item in artifacts if isinstance(item, dict)]
    return {"status": "READY", "models": manifests, "rejected": rejected, "ml_bom": generate_ml_bom([item for item in artifacts if not isinstance(item, dict)])}


def _skill_inventory() -> dict[str, Any]:
    from .skill_manifest import SkillManifestRegistry
    registry = SkillManifestRegistry()
    manifests = []
    for path in sorted((ROOT / "plugins").rglob("*.json")) if (ROOT / "plugins").is_dir() else []:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            required = {"name", "version", "runtime", "capabilities", "inputs", "outputs", "risk_level"}
            if required.issubset(data):
                from .skill_manifest import SkillManifest
                registry.register(SkillManifest(data["name"], data["version"], data["runtime"], tuple(data["capabilities"]), dict(data["inputs"]), dict(data["outputs"]), int(data["risk_level"]), tuple(data.get("dependencies", ()))))
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            continue
    manifests.extend(registry.snapshot()["skills"])
    return {"status": "READY", "skills": manifests}


def main(argv: list[str] | None = None) -> int:
    """Run one bounded operator command; state-changing operations remain approval-gated."""
    parser = argparse.ArgumentParser(prog="jarvis", description="J.A.R.V.I.S. 12.8.3 command center")
    sub = parser.add_subparsers(dest="command", required=True)
    profile = sub.add_parser("certify"); profile.add_argument("profile", nargs="?", default="full")
    trace = sub.add_parser("trace"); trace.add_argument("limit", nargs="?", type=int, default=100)
    mission = sub.add_parser("mission"); mission.add_argument("mission_id", nargs="?")
    recover = sub.add_parser("mission-recover"); recover.add_argument("mission_id")
    replay = sub.add_parser("replay"); replay.add_argument("path")
    diff = sub.add_parser("diff"); diff.add_argument("left"); diff.add_argument("right")
    prove = sub.add_parser("prove"); prove.add_argument("expression")
    provenance = sub.add_parser("provenance"); provenance.add_argument("artifact", nargs="?")
    for name in ("doctor", "recover", "budget", "memory-audit", "causal", "dream", "experiment", "model", "model-benchmark", "skill", "skill-audit", "trust", "policy", "redteam", "chaos", "supplychain", "sbom", "architecture", "contract", "fleet", "node", "hardware"):
        sub.add_parser(name)
    args = parser.parse_args(argv)
    k: JarvisKernelRuntime | None = None
    try:
        if args.command == "certify":
            results = CertificationCenter(ROOT).run(args.profile)
            _print([result.as_dict() for result in results])
            return 0 if all(result.status in {"PASS", "NOT_INSTALLED", "BLOCKED"} for result in results) and not any(result.status == "FAIL" for result in results) else 1
        if args.command == "doctor":
            import core.kernel_12_8_0
            _print({"version": "12.8.3", "python": sys.version, "platform": platform.platform(), "kernel_import": True, "sandbox_resource_limits": SecurePythonSandbox.resource_limits_available(), "sandbox_network_wrapper": SecurePythonSandbox.network_isolation_available(), "git": shutil.which("git") is not None})
            return 0
        if args.command == "sbom":
            _print(generate_sbom(ROOT)); return 0
        if args.command == "supplychain":
            findings = SecretScanner().scan_path(ROOT)
            _print({"status": "BLOCKED" if findings else "PASS", "secret_findings": [{"path": f.path, "line": f.line, "pattern": f.pattern} for f in findings]})
            return 1 if findings else 0
        if args.command == "provenance":
            if args.artifact:
                path = Path(args.artifact).resolve()
                if ROOT not in path.parents and path != ROOT:
                    raise ValueError("artifact must remain inside project root")
                artifact_hash = hashlib.sha256(path.read_bytes()).hexdigest()
                _print(generate_provenance(artifact_sha256=artifact_hash, source=str(path.relative_to(ROOT)), build_id=artifact_hash, inputs={"version": "12.8.3"}))
            else:
                _print(generate_provenance(artifact_sha256=hashlib.sha256((ROOT / "VERSION").read_bytes()).hexdigest(), source="workspace", build_id=digest({"version": "12.8.3", "root": str(ROOT)}), inputs={"version": "12.8.3"}))
            return 0
        if args.command == "architecture":
            graph = json.loads((ROOT / "data/dependency_graph.json").read_text(encoding="utf-8"))
            _print({"modules": graph.get("module_count"), "edges": graph.get("edge_count"), "cycles": graph.get("cycles", []), "orphans": graph.get("orphan_modules", []), "status": "PASS" if not graph.get("cycles") and not graph.get("orphan_modules") else "FAIL"})
            return 0 if not graph.get("cycles") and not graph.get("orphan_modules") else 1
        if args.command == "contract":
            _print({"version": "12.8.3", "kernel": "kernel-12.8.0", "contract_fingerprint": digest({"contract_id": "jarvis.command", "contract_version": "12.8.0", "schema_generation": 1, "capabilities": ["tools.read"]})})
            return 0
        if args.command == "prove":
            certificate = ExactProofEngine().prove(args.expression, exact_fraction, exact_sympy)
            _print(certificate); return 0 if certificate.verification else 1
        if args.command == "model" or args.command == "model-benchmark":
            inventory = _model_inventory()
            inventory["measurements"] = []
            inventory["benchmark_status"] = "ENGINE_UNAVAILABLE" if args.command == "model-benchmark" and not (ROOT / "data/models").exists() else "INVENTORY_ONLY"
            _print(inventory); return 0
        if args.command == "skill" or args.command == "skill-audit":
            inventory = _skill_inventory()
            if args.command == "skill-audit":
                findings = SecretScanner().scan_path(ROOT / "plugins") if (ROOT / "plugins").is_dir() else ()
                inventory["secret_findings"] = [{"path": f.path, "line": f.line, "pattern": f.pattern} for f in findings]
                inventory["audit_status"] = "PASS" if not findings else "BLOCKED"
            _print(inventory); return 0
        if args.command == "fleet" or args.command == "node":
            _print({"version": "12.8.3", "mode": "single-node", "node_id": "local-12.8.3", "distributed_enabled": False}); return 0
        if args.command == "hardware":
            try:
                import psutil
                _print({"platform": platform.platform(), "python": sys.version.split()[0], "cpu_percent": psutil.cpu_percent(interval=0.05), "ram_percent": psutil.virtual_memory().percent})
            except ImportError:
                _print({"platform": platform.platform(), "python": sys.version.split()[0], "psutil": False})
            return 0
        k = _kernel()
        if args.command == "trace": _print(k.events.tail(max(1, min(args.limit, 1000)))); return 0
        if args.command == "recover": _print({"event_chain": k.events.verify(), "evidence_chain": k.evidence.verify(), "resumable_missions": k.missions.resumable()}); return 0
        if args.command == "budget": _print(k.resources.snapshot()); return 0
        if args.command == "memory-audit": _print(k.memory.audit()); return 0
        if args.command == "mission":
            if args.mission_id:
                _print(k.missions.restore(args.mission_id) or {"mission_id": args.mission_id, "status": "not_found"})
            else:
                _print({"resumable_missions": k.missions.resumable()})
            return 0
        if args.command == "mission-recover":
            state = k.missions.restore(args.mission_id)
            if state is None: _print({"status": "not_found", "mission_id": args.mission_id}); return 1
            _print({"status": "recovery_ready", **state, "resume_point": k.missions.resume_point(args.mission_id)})
            return 0
        if args.command == "policy": _print({"allow": k.policy.allow, "approval_required": k.policy.approval_required}); return 0
        if args.command == "trust": _print({"identity_issuer": k.identity.issuer, "key_id": k.identity.key_id, "mcp_protocol": "2026-07-28", "a2a_protocol": "1.0", "delegation": "attenuating"}); return 0
        if args.command == "dream" or args.command == "experiment": _print({"experiments": k.experiments.list()}); return 0
        if args.command == "causal": _print({"memory_audit": k.memory.audit(), "principle": "causal links require explicit evidence"}); return 0
        if args.command == "redteam":
            probes = {"event_chain": k.events.verify(), "evidence_chain": k.evidence.verify(), "sandbox_dunder_rejected": False}
            try: SecurePythonSandbox().execute("print((()).__class__)")
            except PermissionError: probes["sandbox_dunder_rejected"] = True
            probes["status"] = "PASS" if all(probes.values()) else "FAIL"; _print(probes); return 0 if probes["status"] == "PASS" else 1
        if args.command == "chaos":
            with __import__("tempfile").TemporaryDirectory(prefix="jarvis-chaos-") as td:
                from .kernel_12_8_0 import EventStore
                store = EventStore(Path(td) / "events.db"); store.append(EventEnvelope("chaos", {"value": 1})); good = store.verify(); store.close()
            _print({"append_replay": good, "status": "PASS" if good else "FAIL"}); return 0 if good else 1
        if args.command == "replay":
            data = json.loads(Path(args.path).read_text(encoding="utf-8")); _print({"input_digest": digest(data), "event_count": len(data.get("events", [])) if isinstance(data, dict) else 0, "status": "loaded-and-digested"}); return 0
        if args.command == "diff":
            left = json.loads(Path(args.left).read_text(encoding="utf-8")); right = json.loads(Path(args.right).read_text(encoding="utf-8")); _print({"same": digest(left) == digest(right), "left_digest": digest(left), "right_digest": digest(right)}); return 0
        return 0
    finally:
        if k is not None:
            k.close()


if __name__ == "__main__":
    raise SystemExit(main())



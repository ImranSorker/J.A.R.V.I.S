"""Resource-aware system digital twin with anomaly and capacity reasoning."""
from __future__ import annotations

import statistics
import threading
from dataclasses import dataclass
from time import time
from typing import Any


@dataclass(frozen=True, slots=True)
class ResourceSnapshot:
    """One normalized host resource observation."""

    timestamp: float
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    gpu_percent: float = 0.0
    gpu_vram_percent: float = 0.0


class SystemDigitalTwin:
    """Retain bounded telemetry history and expose capacity/anomaly decisions."""

    def __init__(self, *, max_samples: int = 2048) -> None:
        self.max_samples = max(32, min(int(max_samples), 100_000))
        self._samples: list[ResourceSnapshot] = []
        self._lock = threading.RLock()

    def observe(self, *, cpu_percent: float, memory_percent: float, disk_percent: float, gpu_percent: float = 0.0, gpu_vram_percent: float = 0.0, timestamp: float | None = None) -> ResourceSnapshot:
        """Record a normalized telemetry sample."""
        values = [cpu_percent, memory_percent, disk_percent, gpu_percent, gpu_vram_percent]
        if any(float(value) < 0 or float(value) > 100 for value in values):
            raise ValueError("resource percentages must be between 0 and 100")
        sample = ResourceSnapshot(time() if timestamp is None else float(timestamp), *(float(value) for value in values))
        with self._lock:
            self._samples.append(sample)
            if len(self._samples) > self.max_samples:
                del self._samples[: len(self._samples) - self.max_samples]
        return sample

    def forecast_pressure(self, window: int = 32) -> dict[str, float]:
        """Estimate near-term pressure using a bounded linear slope."""
        with self._lock:
            rows = self._samples[-max(2, min(int(window), self.max_samples)) :]
        if len(rows) < 2:
            return {"cpu_slope": 0.0, "memory_slope": 0.0, "gpu_vram_slope": 0.0}
        def slope(values: list[float]) -> float:
            first, last = values[0], values[-1]
            return (last - first) / max(1, len(values) - 1)
        return {"cpu_slope": slope([row.cpu_percent for row in rows]), "memory_slope": slope([row.memory_percent for row in rows]), "gpu_vram_slope": slope([row.gpu_vram_percent for row in rows])}

    def anomalies(self, sigma: float = 3.0) -> list[dict[str, float | str]]:
        """Detect statistically unusual samples with a bounded z-score."""
        threshold = max(1.0, float(sigma))
        with self._lock:
            rows = list(self._samples)
        if len(rows) < 8:
            return []
        metrics = {"cpu_percent": [row.cpu_percent for row in rows], "memory_percent": [row.memory_percent for row in rows], "disk_percent": [row.disk_percent for row in rows], "gpu_vram_percent": [row.gpu_vram_percent for row in rows]}
        latest = rows[-1]
        findings: list[dict[str, float | str]] = []
        for name, values in metrics.items():
            mean = statistics.fmean(values)
            stdev = statistics.pstdev(values)
            if stdev > 0:
                value = float(getattr(latest, name))
                z = abs(value - mean) / stdev
                if z >= threshold:
                    findings.append({"metric": name, "value": value, "zscore": z})
        return findings

    def capacity(self) -> dict[str, float]:
        """Return latest resource headroom percentages."""
        with self._lock:
            latest = self._samples[-1] if self._samples else None
        if latest is None:
            return {"cpu_headroom": 100.0, "memory_headroom": 100.0, "disk_headroom": 100.0, "gpu_headroom": 100.0, "gpu_vram_headroom": 100.0}
        return {"cpu_headroom": 100.0 - latest.cpu_percent, "memory_headroom": 100.0 - latest.memory_percent, "disk_headroom": 100.0 - latest.disk_percent, "gpu_headroom": 100.0 - latest.gpu_percent, "gpu_vram_headroom": 100.0 - latest.gpu_vram_percent}

    def snapshot(self) -> dict[str, Any]:
        """Return compact twin state."""
        return {"samples": len(self._samples), "capacity": self.capacity(), "forecast": self.forecast_pressure(), "anomalies": self.anomalies()}



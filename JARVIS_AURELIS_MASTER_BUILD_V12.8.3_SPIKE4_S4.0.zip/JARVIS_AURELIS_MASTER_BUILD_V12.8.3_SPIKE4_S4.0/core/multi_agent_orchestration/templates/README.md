# P2-M Team Templates

Seed templates are declarative only. They contain no authorization, capability grants, agent identities, secrets, or policy overrides. Security Authority approval is required before a concrete team is formed.

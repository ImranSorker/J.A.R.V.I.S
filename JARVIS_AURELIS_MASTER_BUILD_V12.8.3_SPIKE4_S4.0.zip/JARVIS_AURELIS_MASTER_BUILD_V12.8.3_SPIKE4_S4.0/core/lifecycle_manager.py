"""Structured concurrency and bounded component lifecycle management."""
from __future__ import annotations
import asyncio
import inspect
import logging
import math
import threading
from collections.abc import Coroutine
from typing import Any

logger = logging.getLogger("jarvis.lifecycle")


class ManagedTaskGroup:
    """Own child tasks and bound cancellation wait time; timeouts remain INCOMPLETE."""
    def __init__(self, name: str = "jarvis", *, stop_timeout_seconds: float = 5.0) -> None:
        timeout = float(stop_timeout_seconds)
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("stop_timeout_seconds must be finite and > 0")
        self.name = name
        self.stop_timeout_seconds = timeout
        self._group: asyncio.TaskGroup | None = None
        self._tasks: set[asyncio.Task[Any]] = set()
        self._running = False
        self._shutdown_status = "stopped"
        self._pending_tasks: tuple[str, ...] = ()
        self._exit_task: asyncio.Task[Any] | None = None

    @property
    def running(self) -> bool:
        return self._running

    @property
    def shutdown_status(self) -> str:
        return self._shutdown_status

    @property
    def pending_tasks(self) -> tuple[str, ...]:
        return self._pending_tasks

    async def start(self) -> None:
        if self._running:
            return
        if self._exit_task is not None and not self._exit_task.done():
            raise RuntimeError(f"task group {self.name!r} still has tasks draining after timed-out stop")
        if self._shutdown_status == "incomplete":
            raise RuntimeError(f"task group {self.name!r} stopped incompletely and cannot restart safely")
        self._group = asyncio.TaskGroup()
        await self._group.__aenter__()
        self._running = True
        self._shutdown_status = "running"
        self._pending_tasks = ()
        logger.debug("task_group_started", extra={"component_name": self.name})

    def create_task(self, coro: Coroutine[Any, Any, Any], *, name: str | None = None) -> asyncio.Task[Any]:
        if not self._running or self._group is None:
            coro.close()
            raise RuntimeError(f"task group '{self.name}' is not running")
        task = self._group.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    def _finish_exit(self, task: asyncio.Task[Any]) -> None:
        try:
            task.result()
        except BaseException as exc:
            self._shutdown_status = "incomplete"
            logger.error("task_group_exit_failed", extra={"component_name": self.name, "error_type": type(exc).__name__})
            return
        self._group = None
        self._tasks.clear()
        self._pending_tasks = ()
        self._shutdown_status = "complete"

    async def stop(self) -> None:
        if not self._running and self._group is None:
            return
        self._running = False
        group = self._group
        if group is None:
            self._shutdown_status = "incomplete"
            return
        tasks = tuple(self._tasks)
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            done, pending = await asyncio.wait(tasks, timeout=self.stop_timeout_seconds)
        else:
            done, pending = set(), set()
        if pending:
            self._shutdown_status = "incomplete"
            self._pending_tasks = tuple(sorted(t.get_name() for t in pending))
            for task in pending:
                task.cancel()
            # Native TaskGroup exit can itself wait forever on cancellation-resistant children.
            # Isolate that wait so callers still receive a bounded, explicitly incomplete result.
            self._exit_task = asyncio.create_task(group.__aexit__(None, None, None), name=f"{self.name}:group-exit")
            self._exit_task.add_done_callback(self._finish_exit)
            logger.error("task_group_stop_timeout", extra={"component_name": self.name, "pending_count": len(pending)})
            return
        try:
            await group.__aexit__(None, None, None)
            self._group = None
            self._tasks.clear()
            self._pending_tasks = ()
            self._shutdown_status = "complete"
        except BaseException as exc:
            self._shutdown_status = "incomplete"
            logger.error("task_group_exit_failed", extra={"component_name": self.name, "error_type": type(exc).__name__})
            raise
        finally:
            logger.debug("task_group_stopped", extra={"component_name": self.name, "status": self._shutdown_status})

    async def restart(self) -> None:
        await self.stop()
        if self._shutdown_status != "complete":
            raise RuntimeError(f"task group {self.name!r} did not stop cleanly; restart denied")
        await self.start()


class LifecycleManager:
    """Own named lifecycle components and expose incomplete shutdowns."""
    def __init__(self, *, component_stop_timeout_seconds: float = 5.0, task_stop_timeout_seconds: float = 5.0) -> None:
        for name, value in (("component_stop_timeout_seconds", component_stop_timeout_seconds), ("task_stop_timeout_seconds", task_stop_timeout_seconds)):
            if not math.isfinite(float(value)) or float(value) <= 0:
                raise ValueError(f"{name} must be finite and > 0")
        self.component_stop_timeout_seconds = float(component_stop_timeout_seconds)
        self.task_stop_timeout_seconds = float(task_stop_timeout_seconds)
        self._components: dict[str, Any] = {}
        self._groups: dict[str, ManagedTaskGroup] = {}
        self._started = False
        self._shutdown_status = "stopped"
        self._stop_failures: list[str] = []

    def register(self, name: str, component: Any) -> None:
        if not name.strip(): raise ValueError("component name is required")
        if self._started: raise RuntimeError("components cannot be registered after lifecycle start")
        if name in self._components: raise ValueError(f"component already registered: {name}")
        self._components[name] = component

    def group(self, name: str) -> ManagedTaskGroup:
        if not name.strip(): raise ValueError("task group name is required")
        if self._started: raise RuntimeError("task groups cannot be added after lifecycle start")
        if name not in self._groups:
            self._groups[name] = ManagedTaskGroup(name, stop_timeout_seconds=self.task_stop_timeout_seconds)
        return self._groups[name]

    async def start(self) -> None:
        if self._started: return
        if self._shutdown_status == "incomplete":
            raise RuntimeError("previous lifecycle stop was incomplete; restart denied")
        started: list[Any] = []
        try:
            for group in self._groups.values(): await group.start()
            for component in self._components.values():
                method = getattr(component, "start", None)
                if callable(method):
                    result = method()
                    if inspect.isawaitable(result): await result
                    started.append(component)
            self._started = True
            self._shutdown_status = "running"
        except Exception:
            logger.exception("lifecycle_start_failed")
            for component in reversed(started): await self._call(component, "stop")
            for group in reversed(tuple(self._groups.values())): await group.stop()
            self._shutdown_status = "incomplete"
            raise

    async def _bounded_call(self, component: Any, method_name: str, timeout: float) -> bool:
        method = getattr(component, method_name, None)
        if not callable(method): return True
        result_box: list[BaseException] = []
        if inspect.iscoroutinefunction(method):
            try:
                awaitable = method()
                task = asyncio.create_task(awaitable, name=f"lifecycle:{type(component).__name__}:{method_name}")
                done, pending = await asyncio.wait({task}, timeout=timeout)
                if pending:
                    task.cancel()
                    task.add_done_callback(lambda finished: finished.exception() if not finished.cancelled() else None)
                    logger.error("lifecycle_component_timeout", extra={"component": type(component).__name__, "method": method_name})
                    return False
                try: task.result()
                except BaseException as exc: result_box.append(exc)
            except BaseException as exc:
                result_box.append(exc)
        else:
            finished = threading.Event()
            def invoke() -> None:
                try:
                    result = method()
                    if inspect.isawaitable(result):
                        raise TypeError("sync lifecycle method returned an awaitable; declare it async")
                except BaseException as exc:
                    result_box.append(exc)
                finally:
                    finished.set()
            worker = threading.Thread(target=invoke, name=f"lifecycle:{type(component).__name__}:{method_name}", daemon=True)
            worker.start()
            if not finished.wait(timeout):
                logger.error("lifecycle_component_timeout", extra={"component": type(component).__name__, "method": method_name})
                return False
        if result_box:
            logger.error("lifecycle_component_stop_failed", extra={"component": type(component).__name__, "error_type": type(result_box[0]).__name__})
            return False
        return True

    async def stop(self) -> None:
        if not self._started and not self._groups:
            if self._shutdown_status != "incomplete": self._shutdown_status = "complete"
            return
        self._started = False
        self._stop_failures = []
        for name, component in reversed(tuple(self._components.items())):
            ok = await self._bounded_call(component, "stop", self.component_stop_timeout_seconds)
            if not ok: self._stop_failures.append(f"component:{name}")
        for name, group in reversed(tuple(self._groups.items())):
            try: await group.stop()
            except Exception: self._stop_failures.append(f"task_group:{name}")
            if group.shutdown_status != "complete": self._stop_failures.append(f"task_group:{name}:{group.shutdown_status}")
        self._shutdown_status = "complete" if not self._stop_failures else "incomplete"
        if self._stop_failures:
            logger.error("lifecycle_stop_incomplete", extra={"failures": list(self._stop_failures)})

    async def restart(self) -> None:
        await self.stop()
        if self._shutdown_status != "complete":
            raise RuntimeError("lifecycle stop was incomplete; restart denied")
        await self.start()

    @property
    def started(self) -> bool:
        return self._started

    @property
    def shutdown_status(self) -> str:
        return self._shutdown_status

    @property
    def stop_failures(self) -> tuple[str, ...]:
        return tuple(self._stop_failures)

    def snapshot(self) -> dict[str, Any]:
        return {"started": self._started, "shutdown_status": self._shutdown_status,
                "stop_failures": list(self._stop_failures), "components": sorted(self._components),
                "task_groups": {name: group.running for name, group in sorted(self._groups.items())}}

    @staticmethod
    async def _call(component: Any, method_name: str) -> bool:
        method = getattr(component, method_name, None)
        if not callable(method): return True
        try:
            result = method()
            if inspect.isawaitable(result): await result
            return True
        except Exception:
            logger.exception("lifecycle_component_stop_failed", extra={"component": type(component).__name__})
            return False

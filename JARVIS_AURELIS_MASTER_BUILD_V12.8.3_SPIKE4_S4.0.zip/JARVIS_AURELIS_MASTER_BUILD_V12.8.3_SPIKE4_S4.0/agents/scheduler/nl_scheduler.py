"""Natural language task scheduler.

Accepts task descriptions in natural language, schedules them for
future execution, and manages a priority queue of pending tasks.
"""
from __future__ import annotations

import heapq
import logging
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jarvis.scheduler")


class Task:
    """A scheduled task with priority and metadata."""

    def __init__(self, description: str, priority: int = 5,
                 scheduled_at: Optional[float] = None):
        self.task_id = str(uuid.uuid4())[:8]
        self.description = description
        self.priority = priority  # 1 = highest, 10 = lowest
        self.status = "pending"  # pending, running, completed, failed
        self.created_at = time.time()
        self.scheduled_at = scheduled_at or self.created_at
        self.completed_at: Optional[float] = None
        self.result: Any = None
        self.error: Optional[str] = None
        self.retry_count = 0
        self.max_retries = 3

    def __lt__(self, other: Task) -> bool:
        """Compare for priority queue ordering."""
        return (self.priority, self.scheduled_at) < (other.priority, other.scheduled_at)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "description": self.description,
            "priority": self.priority,
            "status": self.status,
            "created_at": self.created_at,
            "scheduled_at": self.scheduled_at,
            "completed_at": self.completed_at,
            "retry_count": self.retry_count,
        }


class NLScheduler:
    """Priority task scheduler with natural language interface."""

    def __init__(self):
        self._queue: List[tuple] = []  # (priority, scheduled_at, task_id, task)
        self._tasks: Dict[str, Task] = {}
        self._lock = threading.RLock()
        self.enabled = False
        self._counter = 0

    def add_task(self, description: str, priority: int = 5,
                 delay_seconds: float = 0.0) -> str:
        """Add a task to the schedule.

        Args:
            description: Natural language task description.
            priority: 1 (highest) to 10 (lowest).
            delay_seconds: Delay before task becomes eligible.

        Returns:
            The task ID.
        """
        task = Task(description, priority)
        task.scheduled_at = time.time() + delay_seconds
        with self._lock:
            self._counter += 1
            heapq.heappush(
                self._queue,
                (priority, task.scheduled_at, self._counter, task.task_id)
            )
            self._tasks[task.task_id] = task
        logger.info("task_scheduled", extra={"task": task.to_dict()})
        return task.task_id

    def next_task(self) -> Optional[Task]:
        """Get the next eligible task without removing it.

        Returns None if no tasks are ready or scheduler is disabled.
        """
        if not self.enabled:
            return None
        with self._lock:
            now = time.time()
            while self._queue:
                priority, scheduled_at, counter, task_id = self._queue[0]
                if scheduled_at > now:
                    return None  # Next task is in the future
                task = self._tasks.get(task_id)
                if task and task.status == "pending":
                    task.status = "running"
                    return task
                # Task already processed or invalid — remove and continue
                heapq.heappop(self._queue)
            return None

    def complete_task(self, task_id: str, result: Any = None) -> None:
        """Mark a task as completed."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task:
                task.status = "completed"
                task.completed_at = time.time()
                task.result = result
                logger.info("task_completed", extra={"task_id": task_id})

    def fail_task(self, task_id: str, error: str) -> bool:
        """Mark a task as failed. Returns True if task should be retried."""
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            task.error = error
            task.retry_count += 1
            if task.retry_count <= task.max_retries:
                task.status = "pending"
                task.scheduled_at = time.time() + (2 ** task.retry_count)  # Exponential backoff
                self._counter += 1
                heapq.heappush(
                    self._queue,
                    (task.priority, task.scheduled_at, self._counter, task.task_id)
                )
                logger.info("task_retry_scheduled", extra={"task_id": task_id, "retry": task.retry_count})
                return True
            task.status = "failed"
            task.completed_at = time.time()
            logger.error("task_failed", extra={"task_id": task_id, "error": error})
            return False

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending task."""
        with self._lock:
            task = self._tasks.get(task_id)
            if task and task.status == "pending":
                task.status = "cancelled"
                return True
            return False

    def list_tasks(self, status: Optional[str] = None) -> List[Task]:
        """List tasks, optionally filtered by status."""
        with self._lock:
            tasks = list(self._tasks.values())
            if status:
                tasks = [t for t in tasks if t.status == status]
            return tasks

    def get_stats(self) -> Dict[str, Any]:
        """Return scheduler statistics."""
        with self._lock:
            return {
                "enabled": self.enabled,
                "total_tasks": len(self._tasks),
                "pending": sum(1 for t in self._tasks.values() if t.status == "pending"),
                "running": sum(1 for t in self._tasks.values() if t.status == "running"),
                "completed": sum(1 for t in self._tasks.values() if t.status == "completed"),
                "failed": sum(1 for t in self._tasks.values() if t.status == "failed"),
            }



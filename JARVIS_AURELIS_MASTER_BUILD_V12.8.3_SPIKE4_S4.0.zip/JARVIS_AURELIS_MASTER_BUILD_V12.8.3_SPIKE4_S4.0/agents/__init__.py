"""Agent management for JARVIS.

Provides specialist AI agents with capability-based task assignment,
execution tracking, and result verification.
"""
from agents.agent_manager import AgentManager, Agent
from agents.scheduler.nl_scheduler import NLScheduler, Task

__all__ = ["AgentManager", "Agent", "NLScheduler", "Task"]



"""Agent manager with capability-based routing and execution tracking.

Agents are specialist workers with declared capabilities. The manager
routes tasks to the most appropriate agent, tracks execution state,
and handles failures with fallback assignment.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger("jarvis.agents")


class Agent:
    """A specialist agent with capabilities and execution state."""

    def __init__(self, name: str, capabilities: List[str], description: str = ""):
        self.name = name
        self.capabilities = set(capabilities)
        self.description = description or f"Agent specializing in {', '.join(capabilities)}"
        self.status = "idle"  # idle, busy, error
        self.task_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.last_task_time: Optional[float] = None
        self._current_task: Optional[str] = None

    def can_handle(self, task_type: str) -> bool:
        """Check if this agent can handle a task type.

        Matching is fuzzy: checks if any capability keyword appears
        in the task type string.
        """
        task_lower = task_type.lower()
        return any(cap in task_lower for cap in self.capabilities)

    def assign(self, task_id: str, description: str) -> None:
        """Mark agent as busy with a task."""
        self.status = "busy"
        self._current_task = task_id
        self.task_count += 1
        self.last_task_time = time.time()
        logger.info("agent_assigned", extra={"agent": self.name, "task": task_id})

    def complete(self, success: bool = True) -> None:
        """Mark current task as completed."""
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        self.status = "idle"
        self._current_task = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "capabilities": list(self.capabilities),
            "description": self.description,
            "status": self.status,
            "task_count": self.task_count,
            "success_rate": self.success_count / max(self.task_count, 1),
            "current_task": self._current_task,
        }


class AgentManager:
    """Central registry and router for all agents."""

    def __init__(self):
        self.agents: Dict[str, Agent] = {}
        self._lock = threading.RLock()
        self._task_history: List[Dict[str, Any]] = []
        self._max_history = 1000

    def register(self, name: str, capabilities: List[str], description: str = "") -> Agent:
        """Register a new agent."""
        with self._lock:
            if name in self.agents:
                logger.warning("agent_reregistered", extra={"component_name": name})
            agent = Agent(name, capabilities, description)
            self.agents[name] = agent
            logger.info("agent_registered", extra={"component_name": name, "capabilities": capabilities})
            return agent

    def unregister(self, name: str) -> bool:
        """Remove an agent."""
        with self._lock:
            if name in self.agents:
                del self.agents[name]
                return True
            return False

    def list_agents(self) -> List[Agent]:
        """Return all registered agents."""
        with self._lock:
            return list(self.agents.values())

    def get_agent(self, name: str) -> Optional[Agent]:
        """Get agent by name."""
        with self._lock:
            return self.agents.get(name)

    def select_for_task(self, task_type: str, prefer_idle: bool = True) -> Optional[Agent]:
        """Select the best agent for a task.

        Selection criteria:
          1. Must have matching capabilities
          2. Prefer idle agents over busy ones
          3. Prefer agents with higher success rates
          4. Prefer agents with fewer total tasks (load balancing)
        """
        with self._lock:
            candidates = [a for a in self.agents.values() if a.can_handle(task_type)]
            if not candidates:
                return None

            def score(agent: Agent) -> tuple:
                idle_bonus = 0 if agent.status == "idle" else 1
                success_rate = -(agent.success_count / max(agent.task_count, 1))
                load = agent.task_count
                return (idle_bonus, success_rate, load)

            return min(candidates, key=score)

    def assign_task(self, agent_name: str, task_id: str, description: str) -> Dict[str, Any]:
        """Assign a task to a specific agent."""
        with self._lock:
            agent = self.agents.get(agent_name)
            if not agent:
                return {"ok": False, "error": f"Agent {agent_name} not found"}
            if agent.status == "busy":
                return {"ok": False, "error": f"Agent {agent_name} is busy"}
            agent.assign(task_id, description)
            self._task_history.append({
                "task_id": task_id,
                "agent": agent_name,
                "description": description,
                "assigned_at": time.time(),
            })
            if len(self._task_history) > self._max_history:
                self._task_history.pop(0)
            return {"ok": True, "agent": agent_name, "task_id": task_id}

    def complete_task(self, agent_name: str, task_id: str, success: bool = True,
                      result: Any = None) -> Dict[str, Any]:
        """Mark a task as completed."""
        with self._lock:
            agent = self.agents.get(agent_name)
            if not agent:
                return {"ok": False, "error": f"Agent {agent_name} not found"}
            agent.complete(success)
            for entry in self._task_history:
                if entry["task_id"] == task_id:
                    entry["completed_at"] = time.time()
                    entry["success"] = success
                    entry["result"] = result
                    break
            return {"ok": True}

    def get_stats(self) -> Dict[str, Any]:
        """Return aggregate agent statistics."""
        with self._lock:
            return {
                "total_agents": len(self.agents),
                "idle_agents": sum(1 for a in self.agents.values() if a.status == "idle"),
                "busy_agents": sum(1 for a in self.agents.values() if a.status == "busy"),
                "total_tasks": len(self._task_history),
                "agents": [a.to_dict() for a in self.agents.values()],
            }



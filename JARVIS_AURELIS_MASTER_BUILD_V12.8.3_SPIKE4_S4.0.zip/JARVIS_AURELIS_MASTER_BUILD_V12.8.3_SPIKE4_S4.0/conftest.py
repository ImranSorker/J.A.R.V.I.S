"""Repository-wide pytest path isolation.

Test directories named ``memory`` and ``tools`` must never shadow the
production top-level packages of the same names during collection.
"""
from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent
_TESTS = _ROOT / "tests"

def _under(path_text: str, parent: Path) -> bool:
    if not path_text:
        return False
    try:
        Path(path_text).resolve().relative_to(parent.resolve())
    except (ValueError, OSError):
        return False
    return True

sys.path[:] = [p for p in sys.path if not _under(p, _TESTS)]
if str(_ROOT) in sys.path:
    sys.path.remove(str(_ROOT))
sys.path.insert(0, str(_ROOT))

def pytest_sessionstart(session):
    """Reassert production import precedence after pytest plugin setup."""
    sys.path[:] = [p for p in sys.path if not _under(p, _TESTS)]
    if str(_ROOT) in sys.path:
        sys.path.remove(str(_ROOT))
    sys.path.insert(0, str(_ROOT))

# Turn 9 — Swallowed Exception Triage

| Site | Classification | Action |
|---|---|---|
| `core/a2a_verification.py:257` | Genuinely benign | Debug log; Event Fabric is transport-only and local signed ledger remains authoritative. |
| `core/a2a_verification.py:259` | Genuinely benign | Debug log; envelope-construction failure cannot invalidate the local authoritative artifact. |
| `core/a2a_verification.py:697` | Defect | Log at error level and raise `DelegationExpansionRejected` chained from the cancellation failure so cleanup failure is no longer silent. |
| `core/frontier_event_stream.py:44` | Genuinely benign | Debug log; subscriber callback failures are isolated so one subscriber cannot break stream dispatch. |
| `core/model_fabric.py:507` | Genuinely benign | Debug log; malformed inline-list syntax intentionally falls back to scalar parsing. |
| `core/security_evolution.py:155` | Genuinely benign | Debug log; secondary publish fallback is best-effort transport. |
| `core/security_evolution.py:156` | Genuinely benign | Debug log; event sink failure does not invalidate the authoritative security state. |
| `core/simulation_universe/engine.py:179` | Genuinely benign | Debug log; Event Fabric is a transport sink while the local simulation event log is canonical. |
| `core/world_model_3.py:981` | Genuinely benign | Debug log only; destructor cleanup remains non-throwing. |

The placeholder-only bare `pass` sites in `core/a2a_verification.py` overlapped the two Event Fabric catches above and were resolved in this same batch; no separate production bare `pass` remains in the inspected core tree.

# Python runtime policy — J.A.R.V.I.S. 12.8.3

- **Minimum supported version:** Python 3.11.
- **Supported range:** Python >=3.11,<3.14 (3.11, 3.12, and 3.13).
- **Primary engineering interpreter:** Python 3.13.5, recorded in `.python-version`.
- **Compatibility floor:** Python 3.11; syntax and API compatibility must be checked against this floor.
- **CI matrix:** Python 3.11, 3.12, and 3.13.
- **Package metadata:** `project.requires-python` must remain `>=3.11,<3.14`.
- **Static tooling:** Ruff targets `py311`; mypy targets Python 3.11.
- **Release rule:** a Python version is supported only when its CI job installs declared dependencies, collects/runs the regression suite, and passes the packaging smoke test. Environment-limited local runtime certification is recorded as such and is not represented as a PASS.

# Audit Amendment — P2Z_GATEWAY_TRANSPORT_COUPLING

**Severity:** medium-high  
**Status:** OPEN / DEFERRED TO SEPARATE WORKSTREAM  
**Version:** J.A.R.V.I.S. V12.8.3 / kernel 12.8.0  
**File:** `core/cognitive_command_center/gateway.py`

## Finding

The P2-Z gateway is not merely importing a web framework. It combines the transport/presentation layer with synchronous Command Center business logic. The inspected module contains FastAPI app construction, Starlette CORS middleware, HTTP middleware, REST route definitions, `HTTPException` handling, and live WebSocket lifecycle management including accept, polling, JSON send, disconnect handling, socket close, and `CommandCenter.StreamDisconnected` emission.

## Evidence

The Turn 8 Stream D investigation documented the transport symbols and their uses in `TURN8_GATEWAY_BOUNDARY_PLAN.md`. The gateway file remains byte-identical after Turn 9.

## Why this is a finding

Combining transport lifecycle with gateway control-plane logic increases coupling, makes the local/desktop boundary dependent on network/UI framework imports, and couples HTTP/WebSocket concerns to the P2-Z authorization/error-redaction surface.

## Disposition

No gateway source was changed in Turn 9. The extraction is deferred to a dedicated workstream with its own review cadence. The approved plan is `TURN8_GATEWAY_BOUNDARY_PLAN.md`.

The architecture test is tracked with `pytest.mark.xfail(strict=True)` so the current known failure is visible and an unexpected pass will force removal of the marker after the extraction lands.

# Turn 8 Stream D — Cognitive Command Center Gateway Boundary Plan

## Finding

`tests/architecture/test_boundaries.py::test_local_desktop_boundary_uses_no_internal_network_ui_imports` fails on `core/cognitive_command_center/gateway.py`. This is a genuine layering finding and is broader than a simple import statement: the gateway owns a FastAPI app factory, HTTP middleware/CORS policy, HTTP exception mapping, and an active WebSocket transport loop.

## Network/UI framework imports

All framework imports occur inside `create_app()` rather than at module import time:

- `core/cognitive_command_center/gateway.py:750` — `FastAPI`, `HTTPException`, `Request`, `WebSocket`, `WebSocketDisconnect`.
- `core/cognitive_command_center/gateway.py:751` — `JSONResponse` from Starlette.
- `core/cognitive_command_center/gateway.py:752` — `CORSMiddleware` from Starlette.

No Flask, Django, aiohttp, Tornado, or uvicorn import was found in this file.

## Uses by category

### Route/application definitions

`create_app()` builds a `FastAPI` instance at line 754 and declares the full HTTP surface at lines 777-847. The routes delegate to gateway methods such as `health`, `ready`, `open_session`, `refresh_session`, `close_session`, `get_session`, `view`, `act`, `confirm`, `cancel`, `status`, `stream`, `poll_stream`, `close_stream`, `query`, `export`, `history`, `request_authorization`, and `attach_authorization`.

### HTTP middleware / response handling

- `CORSMiddleware` at lines 755-762.
- `@app.middleware("http")` at line 764.
- `Request` is used by `harden()` at line 765.
- `JSONResponse` is returned at line 767 for failed mTLS verification.
- Response integrity headers are attached at lines 768-775.

### HTTP exception mapping

- `HTTPException` is used at line 787 to convert session-open failures into HTTP 403.
- There are no HTTP exception types used by the gateway's synchronous business methods themselves; the exception mapping lives in the nested API function.

### WebSocket lifecycle

This is the important scope expansion: the gateway contains a real WebSocket transport at lines 810-837. `WebSocket` is accepted, mTLS headers are checked, the socket is accepted, the gateway session/stream state is polled in a loop, messages are sent with `send_json`, the coroutine sleeps between polls, `WebSocketDisconnect` is handled, and `CommandCenter.StreamDisconnected` is emitted on disconnect/error. This is not merely route decoration.

### Dependency injection / background tasks

No `Depends`, `BackgroundTasks`, `Request`-scoped dependency injection container, or FastAPI background-task primitive was found. The only request object use is the middleware request type.

## Proposed extraction

### New file: `core/cognitive_command_center/api.py`

Own the presentation/transport layer:

- import `FastAPI`, `HTTPException`, `Request`, `WebSocket`, `WebSocketDisconnect`, `JSONResponse`, `CORSMiddleware`;
- define `create_app(gateway: CognitiveCommandCenterGateway)`;
- define all current HTTP routes and the WebSocket route;
- keep CORS and mTLS HTTP middleware in this API module;
- keep HTTP 403 conversion local to the API module;
- keep WebSocket polling/send/close behavior local to the API module;
- preserve `CommandCenter.StreamDisconnected` by calling the gateway's existing `emit()` method with the same payload;
- do not move any gateway business/state methods.

### `core/cognitive_command_center/gateway.py` after extraction

Remain HTTP-agnostic and retain: session management, authorization gating, phase dispatch, action records, stream manager coordination, audit/provenance integration, views, exports, query/history, signing, redaction, and client/surface verification. `create_app()` and all FastAPI/Starlette imports move out.

### Compatibility export

`core/cognitive_command_center/__init__.py` currently exports `create_app` from `.gateway`, and `core/__init__.py` re-exports it as well. Preserve that public API by re-exporting `create_app` from the new `.api` module, e.g. import `create_app` from `.api` in the package initializer. No caller signature needs to change.

## Blast radius

Current direct imports found in the tree:

- `core/cognitive_command_center/__init__.py:1` imports `create_app` from `.gateway`.
- `core/__init__.py:204` re-exports `create_app` from `core.cognitive_command_center`.
- `tests/test_p2_cognitive_command_center.py:308` imports `create_app` directly from `core.cognitive_command_center.gateway`.

The package-level imports can remain source-compatible through the initializer re-export. The direct test import must either change to the new API module or remain supported via a compatibility wrapper in `gateway.py`; the preferred clean architecture is to update the test import because `gateway.py` should no longer own HTTP transport. That test change belongs to the later approved extraction turn.

No other production direct import of `create_app` was found.

## Interaction with P2Z_SESSION_ERROR_DISCLOSURE

The extraction can collide with the already-landed disclosure fix because the HTTP 403 mapping is the surface where raw session-open exceptions were converted to the generic `session opening failed` message. The extraction must move that exact behavior unchanged into `api.py` rather than reintroducing `str(exc)`. Server-side `logger.exception(...)` must remain. The gateway's underlying `open_session()` business method should remain HTTP-agnostic.

## Sequencing

1. Create `api.py` by moving the existing `create_app()` transport code verbatim except for import paths and explicit references to the gateway type.
2. Preserve the generic session-open error mapping and server-side traceback logging.
3. Update package exports so `core.cognitive_command_center.create_app` remains stable.
4. Update the direct test import from `.gateway` to `.api`.
5. Remove the nested FastAPI/Starlette imports and `create_app()` from `gateway.py`.
6. Run the cognitive command center focused suite plus the architecture boundary test.
7. Verify no FastAPI/Starlette imports remain in `core/cognitive_command_center/gateway.py`.

## Status

**INVESTIGATION ONLY — NO SOURCE CHANGES MADE FOR STREAM D.**

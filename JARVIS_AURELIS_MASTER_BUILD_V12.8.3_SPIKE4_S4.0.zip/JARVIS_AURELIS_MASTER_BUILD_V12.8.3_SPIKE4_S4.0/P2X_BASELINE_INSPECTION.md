# J.A.R.V.I.S. V12.8.3 — P2-X Baseline Inspection

**Phase:** P2-X Provenance & Lineage Graph
**Kernel:** 12.8.0
**Baseline status:** `BASELINE_VERIFIED`
**Inspection:** 2026-10-02

## 1. Required release verification

| Phase | Archive | Bytes | SHA-256 | Status |
|---|---|---:|---|---|
| P2-A | `P2A.zip` | 3,844,713 | `b33d8c8b168a6526cc1c00c8a49cf9d986a34621ea384900e0b7a4f74db84567` | **VERIFIED** |
| P2-B | `P2B.zip` | 3,943,885 | `f552d368fd98b8f1c9a4d23eba6af100f05cf0dfd7703ded530e7eed5f81776c` | **VERIFIED** |
| P2-C | `P2C.zip` | 3,999,524 | `c83eb0e1921e0876fbb59ae5b1497972f56463e56b5bb24d1dc650bb8f750f13` | **VERIFIED** |
| P2-D | `P2D.zip` | 3,968,120 | `5ee3f885a46230eb0b5a4cff3f77eeea37f7802d70ec27465aedc3eb82247cc7` | **VERIFIED** |
| P2-E | `P2E.zip` | 3,889,862 | `47541a7c8492bdc66abfa0bee5bfe6662a331b1e94e5afffd723b5b3203b7b8f` | **VERIFIED** |
| P2-F | `P2F.zip` | 3,912,880 | `0b3f210c6a3e5ad6780906a1a091d3cec142f8cbfdc7052affd457257ff81274` | **VERIFIED** |
| P2-G | `P2G.zip` | 4,646,525 | `68f81ad89daa0523ebf21429d10d8f54b207c30b53cbfe48c8031c6e6996a960` | **VERIFIED** |
| P2-H | `P2H.zip` | 4,031,390 | `b94f42db0de8a82d2a5663a90597fcfba5216ad108ea20ae8d7f8346986bf55e` | **MISMATCH** |
| P2-I | `P2I.zip` | 4,068,619 | `e4db8353761f2cb2216255568174de20909991a8f4b3bb223d02cab522e8c011` | **VERIFIED** |
| P2-J | `P2J.zip` | 4,227,424 | `7c4b1729367f64f893a250f9d32c36b577611fb041a94db90d714629d3e52366` | **VERIFIED** |
| P2-K | `P2K.zip` | 4,250,855 | `50633b04f9d86f165d66b7c77e7e4a89ca67f445ce1d7a26905f3cfb23625358` | **VERIFIED** |
| P2-L | `P2L.zip` | 4,127,186 | `765788c3e6fe8903fb0220f78d00984014712f6439815c5534d21a7e1035c85a` | **VERIFIED** |
| P2-M | `P2M.zip` | 4,287,434 | `8ab6dd42e5fc8c712c24b5f6529b4dd75ebd5f34a9074d1ae2b2388f4506af1e` | **VERIFIED** |
| P2-N | `P2N.zip` | 4,473,067 | `ec228ca0c8d3f6036418f1421436cd16223450d38ee9ebc35f66c6b63d431d41` | **VERIFIED** |
| P2-O | `P2O.zip` | 4,102,075 | `e5aae1ef5b64f777cf3ee708b349cf4b75c06d0efc9b3e6734939a243c131ca0` | **VERIFIED** |
| P2-P | `P2P.zip` | 4,163,986 | `10a9287e60447b840197f25270e5e12651c5ee10c9ce9f914701827f53cac2ad` | **VERIFIED** |
| P2-Q | `P2Q.zip` | 4,207,082 | `4fb9e58f40c040f9e0a68a8e319a843443eea7ad0dc6da9bdda4a924cd8df63f` | **VERIFIED** |
| P2-R | `P2R.zip` | 4,408,408 | `e806cda79d49f15b1059ceafc684878d9a9e4cea2a9ba53dee16aa43d8f438e2` | **VERIFIED** |
| P2-S | `P2S.zip` | 4,609,078 | `1695fe9548f27e29c3d431dc555e7673eb2a6a0302969daf0e99e0a30836722a` | **VERIFIED** |
| P2-T | `P2T.zip` | 4,603,564 | `d825b90f47c8bbef7d3f4d7b61d4758be7fc45fe71eab67f2507fa2130918119` | **VERIFIED** |
| P2-U | `P2U.zip` | 3,863,288 | `d09f2ff63da9f22154a995123bfe42ac91cfbdeab2566e81c9b253f5fd29a983` | **VERIFIED** |
| P2-V | `P2V.zip` | 4,694,450 | `bee0b1fab0b49561e4440ab76df75202a1e5609ca73ae6f3c820a3e2adad26e6` | **VERIFIED** |
| P2-W | `P2W.zip` | 4,735,395 | `0f422fdec2a4c5b28dc13f94638b6df4b2ab3919e4321ff147e3a9904cff5d49` | **VERIFIED** |

**Verified predecessors:** 23/23

## 2. Source/interface inventory

P2-U is the primary event source. P2-W contributes request → decision → allocation → accounting → reconciliation lineage. P2-A supplies identity/signature/registry primitives. P2-E supplies execution/checkpoint/accounting lineage. P2-B/C/D/F/G/H/I/J/K/L/M/N/O/P/Q/R/S/T/V expose domain artifacts and lineage/provenance records that P2-X projects without mutating.

The predecessor source trees were extracted and scanned for lineage/provenance-bearing code, schemas, reports, and event structures. File counts ranged from 763 (P2-A) to 1,191 (P2-W); all required archives were readable.

## 3. Lineage-edge coverage

| Source | Required edge families | P2-X ingestion surface | Coverage |
|---|---|---|---|
| P2-A | genome→parent genome; key→signature; registry→record | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-B | IdeaSpec→build/test/evaluation/certification/package/staging | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-C | session→draft→candidate→promotion | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-D | lifecycle→snapshot→rollback; candidate→deployment | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-E | execution→accounting/telemetry; checkpoint→restore | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-F | skill→dependency/composition/certification | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-G | trigger→candidate→gate→certification→handoff; attribution/rollback | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-H | memory→source/derivation/contradiction | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-I | failure→hypothesis→remediation→verification/regression | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-J | entity→state transition/causal link; snapshots | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-K | universe→component/outcome→verification evidence | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-L | plan→subplan/task/action/contingency/rollback | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-M | team→member; delegation/message/review/challenge | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-N | verification request→record→evidence→decision | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-O | profile→artifact; adapter→base; routing→request | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-P | manifest→dependency/provenance; invocation→result | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-Q | composite→component; edge type-check; registration | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-R | question/claims/evidence/synthesis/proposals | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-S | profile/attestation/revocation/dependents | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-T | symptom→hypothesis→diagnosis→remediation→validation | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-U | event envelopes, correlation, causation, signed lineage | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-V | hypothesis→experiment→family→candidate→comparison→selection | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |
| P2-W | request→decision→allocation→accounting→reconciliation | EventEnvelope lineage + payload artifact/edge extraction + explicit signed edge verification | **covered** |

## 4. Gaps requiring P2-X-owned derivation

- Cross-phase causal joins are not uniformly emitted as a single edge; P2-X derives them only through signed, versioned rules.
- External producer/operator identity may be referenced but cannot be invented; unverified references are refused.
- Historical records without signed lineage remain outside the graph rather than being guessed into it.
- Cross-domain joins such as cost/execution/security/evidence/operator lineage require derived rules with retained evidence refs.

## 5. Frozen taxonomy

- Node kinds: 53
- Edge kinds: 36 (the supplied edge taxonomy enumerates 36 items)
- Confidence states: 5
- Verification states: 5
- Query kinds: 15 (matching the supplied query-kind list and success criterion).

## 6. Integration contract

- P2-X requires a valid P2-E ExecutionContext at the public API boundary in production wiring; the core module itself uses injected verifiers/resolvers for deterministic testing.
- P2-X never executes, deploys, mutates source artifacts, or bypasses predecessor gates.
- Unsigned/unverifiable events, artifacts, and explicit edges fail closed.

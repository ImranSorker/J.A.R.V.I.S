# J.A.R.V.I.S. V12.8.0 Language LOC Report

Counts exclude generated build/cache directories. Code LOC excludes blank/comment-only physical lines.

| Language | Files | Physical LOC | Code LOC |
|---|---:|---:|---:|
| C# | 1 | 68 | 57 |
| C++ | 4 | 343 | 310 |
| Dart | 14 | 2,680 | 2,418 |
| Go | 6 | 334 | 301 |
| Java | 1 | 110 | 96 |
| Kotlin | 1 | 73 | 65 |
| Protobuf | 1 | 59 | 47 |
| Python | 632 | 88,824 | 74,937 |
| Rust | 1 | 190 | 170 |
| TypeScript | 1 | 90 | 78 |
| **Total** | **662** | **92,771** | **78,479** |

# Turn 9 Report

## Stream A — swallowed exceptions

Classification: **8 genuinely benign / 1 defect / 0 ambiguous** across the nine non-test sites. The two placeholder-only `pass` statements in `core/a2a_verification.py` overlapped the Event Fabric catches and were fixed in the same batch.

The benign sites now emit debug-level diagnostics while preserving their best-effort semantics. The delegation-cancellation failure at `core/a2a_verification.py` is treated as a defect: it is logged at error level and surfaced through the existing `DelegationExpansionRejected` type with the cleanup failure chained as the cause.

## Stream B — hardcoded approval token

Classification: **opaque marker, not credential**. The compatibility `ExecutionBroker` is constructed without a permission engine, so `approval_token` is not verified as authorization on this path. The fixed code generates a fresh `secrets.token_urlsafe(32)` marker for every authorized call. No public API signature or broker interface changed.

## Stream C1 — self-knowledge artifact

Classification: **deferred build artifact**. `scripts/rebuild_self_knowledge.py` exists and explicitly generates `data/self_knowledge_graph.json`. The self-consistency audit fails closed when the artifact is absent. No hand-written artifact was fabricated or committed.

## Stream C2 — architecture boundary tracking

`test_local_desktop_boundary_uses_no_internal_network_ui_imports` now uses `pytest.mark.xfail(strict=True)` with the `P2Z_GATEWAY_TRANSPORT_COUPLING` reason and a reference to `TURN8_GATEWAY_BOUNDARY_PLAN.md`.

## Verification

Focused product/security suites:

`230 passed in 19.71s`

Covered:
- `tests/test_p2_a2a_verification.py`
- `tests/test_p2_event_fabric.py`
- `tests/test_p2_model_fabric.py`
- `tests/test_p2_security_evolution.py`
- `tests/test_p2_simulation_universe.py`
- `tests/test_p2_world_model_3.py`
- `tests/core/test_security.py`
- `tests/test_adversarial_security.py`

Architecture boundary suite:

`9 passed, 1 xfailed`

The only XFAIL is the intentionally deferred gateway transport-coupling test. No architecture failure remains from the unreachable baseline or placeholder-marker checks.

Self-consistency verification was also run and failed explicitly with:

`self-consistency: FAIL: missing artifact: data/self_knowledge_graph.json`

This is the expected declared artifact limitation, not a fabricated pass.

## Non-mutation / scope verification

`core/cognitive_command_center/gateway.py` is byte-identical to the Turn 8 checkpoint. No gateway source was modified.

Compared with a fresh extraction of the Turn 8 partial archive, the authorized changes are limited to the Turn 9 source/test files plus the four Turn 9 triage reports and the gateway finding/release-note amendments.

## Final Turn 9 tree hash

The final deterministic tree hash is recorded in the Turn 9 hash ledger alongside the fixed ZIP SHA-256. It is computed over sorted relative file paths and each file's SHA-256 digest.

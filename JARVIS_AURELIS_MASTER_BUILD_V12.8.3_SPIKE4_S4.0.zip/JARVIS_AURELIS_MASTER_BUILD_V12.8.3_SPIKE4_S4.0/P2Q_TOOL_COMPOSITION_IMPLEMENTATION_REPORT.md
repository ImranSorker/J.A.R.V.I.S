# J.A.R.V.I.S. V12.8.3 P2-Q — Tool Composition 2.0

## Completion

P2-Q is implemented as a canonical composition layer over P2-P Tool Fabric. The composition engine now creates signed, typed, bounded, lifecycle-aware composite tools and executes all component calls exclusively through the P2-P invocation boundary.

## Completed capabilities

- Sequence, parallel/join, branch, bounded loop, map and reduce execution.
- Transaction/saga/try-catch failure handling with compensation hooks.
- Retry policies with bounded exponential backoff.
- Safe condition evaluation without dynamic code execution.
- Typed binding and signed transform handling; the built-in identity transform is executable.
- Child-tool idempotency-key propagation.
- Compensation input mapping from prior step inputs/outputs.
- P2-K simulation handoff with simulation configuration and recorded outcome evidence.
- P2-N verification entry point.
- Plan and skill derivation through injectable resolvers.
- Component revocation propagation and composite lifecycle events.
- Runtime-owned P2-P/P2-Q integration in `SupremeRuntimeFabric`.
- Feature registry and composite schema coverage updated for P2-Q.

## Security correction

Composite required permissions and required scopes are the union of all component requirements. Intersection semantics would allow a caller that lacked a permission required by one component to invoke the composite, so P2-Q now enforces the conjunctive authorization surface.

## Verification

- P2-Q tests: 48/48 passed.
- P2-P Tool Fabric tests: 50/50 passed.
- DSec/DSH agent fabric: 20/20 passed.
- V12.8.2 real-execution regression: 9/9 passed.
- V12.8.3 nano-release checks: 2/2 passed.
- Release packaging checks: 2/2 passed.

The broader operational certification suite remains blocked by a pre-existing `main.JARVISCore` / `ToolRegistry` constructor mismatch (`permission_engine` is passed to a registry implementation that does not accept that parameter). This failure occurs before the P2-Q runtime path is exercised and was not introduced by the P2-Q changes.
